/* Boutons « Copier » et « Tester » pour les exemples du fichier d'aide (3.7.0).
 *
 * Script hôte injecté, comme aide-swift-kotlin.js : il n'exige aucune
 * modification du bundle minifié. Il surveille le DOM, repère les blocs de code
 * de l'aide et leur ajoute une barre de deux boutons.
 *
 * « Tester » envoie l'exemple à /api/aide/essayer, qui l'exécute dans un
 * dossier temporaire jetable (bac_a_sable.py) : limite de temps, sortie bornée,
 * ressources plafondées, réseau détourné vers un trou noir. Rien n'est écrit
 * dans le projet.
 */
(()=>{
  const VUS=new WeakSet();
  const LANG_PAR_CLASSE={python:'python',py:'python',javascript:'javascript',js:'javascript',
    typescript:'javascript',jsx:'javascript',pascal:'pascal',delphi:'pascal',c:'c',cpp:'cpp',
    'c++':'cpp',csharp:'csharp',cs:'csharp','c#':'csharp',java:'kotlin',kotlin:'kotlin',
    swift:'swift',go:'go',golang:'go',rust:'rust',ruby:'ruby',php:'php',perl:'perl',
    lua:'lua',ocaml:'ocaml',ml:'ocaml',fortran:'fortran',f90:'fortran',bash:'shell',
    sh:'shell',shell:'shell',zsh:'shell',makefile:'make',make:'make',cmake:'cmake',
    html:'html',htm:'html',xml:'xml',svg:'svg',css:'css',json:'json',latex:'latex',
    tex:'latex',markdown:'markdown',md:'markdown',basic:'basic',sql:'plaintext',yaml:'plaintext',
    /* Les dix langages ésotériques de la 3.8.0, avec les alias du registre
       (langages.py) : la classe du bloc de code peut porter le libellé affiché
       comme un alias, et le bouton « Tester » doit résoudre les deux. */
    brainfuck:'brainfuck',bf:'brainfuck',b:'brainfuck',oxblood:'brainfuck',
    whitespace:'whitespace',ws:'whitespace',espace:'whitespace',
    piet:'piet',mondrian:'piet',
    lolcode:'lolcode',lol:'lolcode',
    arnoldc:'arnoldc',arnold:'arnoldc',
    chef:'chef',recette:'chef',
    shakespeare:'shakespeare',spl:'shakespeare',
    intercal:'intercal','c-intercal':'intercal',
    fractran:'fractran',fra:'fractran',
    malbolge:'malbolge',mal:'malbolge'};

  function langueDe(bloc){
    const pre=bloc.tagName==='PRE'?bloc:bloc.closest('pre')||bloc;
    for(const n of [pre,pre.firstElementChild]){
      if(!n) continue;
      for(const c of n.classList||[]){
        const t=c.replace(/^language-/,'').toLowerCase();
        if(LANG_PAR_CLASSE[t]) return LANG_PAR_CLASSE[t];
      }
      const d=(n.dataset&&(n.dataset.lang||n.dataset.language))||'';
      if(LANG_PAR_CLASSE[d.toLowerCase()]) return LANG_PAR_CLASSE[d.toLowerCase()];
    }
    /* Repli : le titre de la fiche d'aide porte souvent le langage. */
    const fiche=pre.closest('[data-lang],[data-language],article,section,li,.help-item,.aide-fiche');
    const indice=fiche?((fiche.dataset&&(fiche.dataset.lang||fiche.dataset.language))||''):'';
    if(LANG_PAR_CLASSE[String(indice).toLowerCase()]) return LANG_PAR_CLASSE[String(indice).toLowerCase()];
    const entete=document.querySelector('.help-title,.aide-titre,#help-title');
    if(entete){
      const t=entete.textContent.toLowerCase();
      for(const [cle,val] of Object.entries(LANG_PAR_CLASSE))
        if(t.includes(cle)) return val;
    }
    return '';
  }

  function codeDe(bloc){
    const pre=bloc.tagName==='PRE'?bloc:bloc.closest('pre')||bloc;
    /* textContent, et non innerText : innerText reflète le rendu et peut
       normaliser les tabulations et les espaces. C'est décisif pour Whitespace,
       dont le programme n'est fait QUE d'espaces, de tabulations et de sauts de
       ligne — une normalisation le réduirait à du bruit. On travaille sur une
       copie pour ne pas compter le texte des boutons, ajoutés dans le <pre>. */
    const copie=pre.cloneNode(true);
    for(const b of copie.querySelectorAll('.ps-exemple-barre,.ps-exemple-resultat'))
      b.remove();
    return (copie.textContent||'').replace(/\n$/,'');
  }

  function entreeDe(code){
    /* Certaines fiches déclarent l'entrée standard avec laquelle leur exemple a
       été vérifié à la génération. Sans elle, un programme qui lit son entrée
       rendrait une sortie vide au clic, et contredirait la fiche. */
    const aide=window.PS_LANG_HELP;
    if(!aide||!Array.isArray(aide.articles)) return '';
    const voulu=String(code).replace(/\s+$/,'');
    for(const a of aide.articles){
      for(const b of (a&&a.blocks)||[]){
        if(!b||typeof b.code!=='string') continue;
        if(b.code.replace(/\s+$/,'')===voulu&&typeof b.entree==='string')
          return b.entree;
      }
    }
    return '';
  }

  async function copier(code,bouton){
    let fait=false;
    try{
      if(navigator.clipboard&&window.isSecureContext!==false){
        await navigator.clipboard.writeText(code); fait=true;
      }
    }catch(e){fait=false;}
    if(!fait){
      const z=document.createElement('textarea');
      z.value=code; z.setAttribute('readonly',''); 
      z.style.cssText='position:fixed;top:-1000px;opacity:0';
      document.body.appendChild(z); z.select();
      try{fait=document.execCommand('copy');}catch(e){fait=false;}
      z.remove();
    }
    const avant=bouton.textContent;
    bouton.textContent=fait?'✓ Copié':'✕ Échec';
    bouton.disabled=true;
    setTimeout(()=>{bouton.textContent=avant;bouton.disabled=false;},1400);
  }

  function panneauResultat(barre){
    let p=barre.parentElement.querySelector(':scope > .ps-exemple-resultat');
    if(!p){
      p=document.createElement('div'); p.className='ps-exemple-resultat';
      barre.parentElement.appendChild(p);
    }
    return p;
  }

  async function tester(code,langue,barre,bouton,entree){
    const p=panneauResultat(barre);
    bouton.disabled=true;
    p.className='ps-exemple-resultat ps-en-cours';
    p.textContent=entree
      ?'Exécution avec « '+entree.replace(/\n/g,'\\n')+' » comme entrée standard…'
      :'Exécution dans un dossier temporaire jetable…';
    try{
      const r=await fetch('/api/aide/essayer',{method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({code,langage:langue,entree:entree||''})});
      const d=await r.json();
      if(!r.ok) throw new Error(d.message||d.error||('HTTP '+r.status));
      const etats={succes:'ps-succes',echec:'ps-echec',delai:'ps-echec',
        indisponible:'ps-info',graphique:'ps-info',refuse:'ps-info'};
      p.className='ps-exemple-resultat '+(etats[d.etat]||'ps-info');
      let h='<b>'+esc(d.libelle||langue||'Exemple')+' — '+esc(d.etat)+
            '</b> <span class="ps-duree">'+(d.duree_ms||0)+' ms</span>';
      if(d.message) h+='<div class="ps-message">'+esc(d.message)+'</div>';
      if(d.sortie) h+='<pre class="ps-sortie">'+esc(d.sortie)+'</pre>';
      if(d.erreur) h+='<pre class="ps-erreur">'+esc(d.erreur)+'</pre>';
      if(!d.sortie&&!d.erreur&&d.etat==='succes')
        h+='<div class="ps-message">Aucune sortie.</div>';
      p.innerHTML=h;
    }catch(e){
      p.className='ps-exemple-resultat ps-echec';
      p.textContent='Test impossible : '+e.message;
    }finally{
      bouton.disabled=false;
    }
  }

  function esc(t){
    return String(t==null?'':t).replace(/[&<>]/g,
      c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
  }

  function dansAide(n){
    /* Ne décorer que l'aide, pas l'éditeur ni la console. */
    for(let e=n;e&&e!==document.body;e=e.parentElement){
      const c=(e.className&&typeof e.className==='string')?e.className:'';
      const i=(e.id||'')+' '+c;
      if(/aide|help|doc|fiche|article|exemple/i.test(i)) return true;
    }
    return false;
  }

  function decorer(pre){
    if(VUS.has(pre)) return;
    if(!dansAide(pre)) return;
    const code=codeDe(pre);
    if(!code.trim()||code.length>200000) return;
    VUS.add(pre);
    const langue=langueDe(pre);
    const barre=document.createElement('div');
    barre.className='ps-exemple-barre';
    const b1=document.createElement('button');
    b1.type='button'; b1.className='ps-exemple-copier'; b1.textContent='📋 Copier';
    b1.title='Copier cet exemple dans le presse-papiers';
    b1.addEventListener('click',()=>copier(code,b1));
    const b2=document.createElement('button');
    b2.type='button'; b2.className='ps-exemple-tester';
    b2.textContent=langue?'▶ Tester':'▶ Tester';
    b2.title=langue
      ?'Exécuter cet exemple ('+langue+') dans un dossier temporaire jetable, sans réseau'
      :'Langage non reconnu : le test utilisera le repli du serveur';
    const entree=entreeDe(code);
    if(entree) b2.title+=' — cet exemple lit « '+entree.replace(/\n/g,'\\n')
      +' » sur son entrée standard, elle est transmise automatiquement';
    b2.addEventListener('click',()=>tester(code,langue,barre,b2,entree));
    const et=document.createElement('span');
    et.className='ps-exemple-langue';
    et.textContent=langue||'langage non détecté';
    barre.append(et,b1,b2);
    pre.style.position='relative';
    pre.appendChild(barre);
  }

  function balayer(){
    document.querySelectorAll('pre, .help-code, .aide-code').forEach(decorer);
  }
  new MutationObserver(balayer).observe(document.documentElement,
    {subtree:true,childList:true});
  if(document.readyState==='loading')
    document.addEventListener('DOMContentLoaded',balayer);
  else balayer();
  window.PSAideExemples={balayer,copier,tester,langueDe,codeDe};
})();
