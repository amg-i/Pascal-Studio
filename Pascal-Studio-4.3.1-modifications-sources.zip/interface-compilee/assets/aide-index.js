/* Index des langages et recherche par fonctionnalité — aide des langages (3.8.0).
 *
 * Script hôte injecté, comme aide-exemples.js : aucune modification du bundle
 * minifié n'est nécessaire. Il surveille le DOM, repère le panneau d'aide et y
 * ajoute un index.
 *
 * Ce que le panneau d'aide savait déjà faire, et ce qui manquait :
 *
 *   déjà    la recherche est insensible aux accents (le bundle normalise en NFD
 *           et retire les diacritiques) et porte sur la fiche entière ;
 *   déjà    les groupes affichent leur nombre de fiches ;
 *   manquant la recherche était bornée au langage sélectionné — impossible de
 *           chercher « boucle » dans toute l'aide ;
 *   manquant les langages étaient un mur de boutons sans filtre ni compte : rien
 *           ne répondait à « quels langages ont une aide, et combien de pages » ;
 *   manquant aucune recherche par FONCTIONNALITÉ — « lesquels puis-je déboguer
 *           pas à pas ? », « où la complétion existe-t-elle ? ».
 *
 * Trois principes ont guidé l'écriture.
 *
 * 1. Ne jamais réécrire les nœuds de l'application. Les boutons de langages du
 *    bundle portent ses gestionnaires d'état React ; les recréer casserait la
 *    sélection. L'index les CACHE et les CLIQUE : il délègue, il ne se substitue
 *    pas. Si ce script n'est pas chargé, le panneau reste celui de la 3.7.0.
 *
 * 2. Les fonctionnalités viennent du serveur, pas d'une liste écrite à la main.
 *    /api/aide/capacites les construit depuis le registre, les capacités de
 *    débogage et l'état du bac à sable : quand un moteur ou un outil manque sur
 *    la machine, la facette disparaît au lieu de mentir.
 *
 * 3. Les comptes de fiches viennent des catalogues réellement chargés. Un script
 *    hôte ne voit que les articles publiés sur window par les fichiers d'aide
 *    injectés ; les fiches internes au bundle ne sont pas énumérables. Plutôt
 *    que d'afficher un faux zéro, l'index complète le compte d'un langage en
 *    lisant les totaux de groupes que le panneau affiche quand ce langage est
 *    ouvert, et le met en cache.
 */
(()=>{
  const PREFIXE='ps-aide-index';
  const MAX_RESULTATS=60;
  const MAX_EXCERPT=180;

  /* L'état vit ici, pas dans le DOM : le panneau est reconstruit dès que
   * l'application le remonte, et il doit retrouver filtre, facettes et portée. */
  let catalogue=null;
  let chargement=null;
  let filtre='';
  const facettes=new Set();
  let porteeGlobale=false;
  let indexArticles=null;
  const comptesAppris={};

  /* Garde-fous contre la cascade d'écritures.
   *
   * L'observateur de mutations voit nos propres écritures. Sans ces garde-fous,
   * chaque balayage reconstruisait l'index, ces écritures rappelaient
   * l'observateur, qui relançait un balayage — sans fin dès que le panneau
   * d'aide existait. C'est la panne qui faisait planter l'application à
   * l'ouverture de l'aide : le rendu tournait à plein régime sur des milliers
   * de nœuds créés et jetés, jusqu'à ce que le processus de rendu tombe.
   *
   *   signature       ce que le dernier affichage reflète ; identique, on ne
   *                   touche plus au DOM — même rôle que le WeakSet VUS dans
   *                   aide-exemples.js, qui est resté sain ;
   *   panneauCourant  l'élément construit ; s'il change, l'application a
   *                   remonté le panneau et tout est à refaire ;
   *   enCours         empêche un rappel imbriqué pendant nos écritures ;
   *   observateur     pour jeter nos propres enregistrements après écriture. */
  let signature=null;
  let panneauCourant=null;
  let enCours=false;
  let observateur=null;

  /* Seconde boucle, plus discrète : quand le serveur ne répond pas, l'échec
   * écrit un message dans le panneau, cette écriture rappelle l'observateur,
   * qui relance une requête, qui échoue, qui écrit… Sans délai, l'aide ouverte
   * sans serveur mitraillerait /api/aide/capacites indéfiniment. Un nouvel
   * essai est donc espacé, et remis à zéro quand le panneau est remonté :
   * rouvrir l'aide réessaie tout de suite. */
  const DELAI_REESSAI=5000;
  let dernierEssai=0;

  function normaliser(t){
    /* Même normalisation que le bundle : NFD puis retrait des diacritiques, donc
     * « déboguer » trouve « deboguer » et inversement. */
    return String(t==null?'':t).normalize('NFD')
      .replace(/[\u0300-\u036f]/g,'').toLowerCase();
  }

  function sources(){
    /* Les quatre globaux que le bundle consulte pour construire sa base d'aide.
     * PS_EXTRA_HELP n'a pas de clef « languages » : il n'apporte que des fiches. */
    return [window.PS_DB_HELP,window.PS_LANG_HELP,window.PS_EXTRA_HELP,
            window.PS_LATEX_HELP];
  }

  function articles(){
    const sortis=[];
    for(const s of sources())
      if(s&&Array.isArray(s.articles)) for(const a of s.articles) if(a) sortis.push(a);
    return sortis;
  }

  function comptes(){
    const c={};
    for(const a of articles()){
      const l=String(a.lang||'').trim();
      if(l) c[l]=(c[l]||0)+1;
    }
    /* Les comptes appris dans le DOM complètent sans jamais écraser un catalogue
     * publié : un fichier d'aide est plus exact qu'un total lu à l'écran. */
    for(const l of Object.keys(comptesAppris))
      if(!(l in c)) c[l]=comptesAppris[l];
    return c;
  }

  function texteDe(a){
    const morceaux=[a.lang,a.group,a.title,a.summary];
    if(a.intro&&a.blocks&&a.blocks[0]) morceaux.push(a.blocks[0].text);
    for(const b of (a.blocks||[])){
      if(!b) continue;
      if(b.title) morceaux.push(b.title);
      if(b.text) morceaux.push(b.text);
      if(b.code) morceaux.push(b.code);
    }
    return morceaux.filter(Boolean).join('\n');
  }

  function index(){
    /* Construit une fois : chercher dans toute l'aide à chaque frappe en
     * renormalisant des centaines de fiches coûterait plus que la frappe. */
    if(indexArticles) return indexArticles;
    indexArticles=articles().map(a=>({article:a,brut:texteDe(a),
                                      plat:normaliser(texteDe(a))}));
    return indexArticles;
  }

  function panneau(){
    const nav=document.querySelector('.language-help .lh-nav');
    if(!nav) return null;
    let p=nav.querySelector(':scope > .'+PREFIXE);
    if(p) return p;
    p=document.createElement('div');
    p.className=PREFIXE;

    /* --- filtre de langages --- */
    const zoneFiltre=document.createElement('div');
    zoneFiltre.className=PREFIXE+'-filtre';
    const etiquette=document.createElement('label');
    etiquette.setAttribute('for','ps-aide-filtre');
    etiquette.textContent='Trouver un langage';
    const champ=document.createElement('input');
    champ.id='ps-aide-filtre'; champ.type='search'; champ.value=filtre;
    champ.placeholder='Nom, extension…';
    champ.setAttribute('aria-describedby','ps-aide-nombre');
    champ.addEventListener('input',()=>{filtre=champ.value;maj();});
    const nombre=document.createElement('span');
    nombre.className=PREFIXE+'-nombre'; nombre.id='ps-aide-nombre';
    zoneFiltre.append(etiquette,champ,nombre);

    /* --- facettes --- */
    const zoneFacettes=document.createElement('div');
    zoneFacettes.className=PREFIXE+'-facettes';
    zoneFacettes.setAttribute('role','group');
    zoneFacettes.setAttribute('aria-label','Filtrer par fonctionnalité');

    /* --- index des langages --- */
    const langues=document.createElement('div');
    langues.className=PREFIXE+'-langues';

    /* --- recherche dans tous les langages --- */
    const global=document.createElement('div');
    global.className=PREFIXE+'-global';
    const bouton=document.createElement('button');
    bouton.type='button'; bouton.className=PREFIXE+'-global-bouton';
    const caseGlobal=document.createElement('input');
    caseGlobal.type='checkbox'; caseGlobal.checked=porteeGlobale;
    caseGlobal.id='ps-aide-portee';
    const texteGlobal=document.createElement('span');
    texteGlobal.className=PREFIXE+'-global-texte';
    const titreGlobal=document.createElement('strong');
    titreGlobal.textContent='Chercher dans tous les langages';
    const portee=document.createElement('span');
    portee.className=PREFIXE+'-portee';
    texteGlobal.append(titreGlobal,portee);
    bouton.append(caseGlobal,texteGlobal);
    bouton.addEventListener('click',e=>{
      /* La case est dans le bouton : laisser le clic la basculer deux fois
       * (une par le navigateur, une par nous) annulerait le changement. */
      if(e.target!==caseGlobal) caseGlobal.checked=!caseGlobal.checked;
      porteeGlobale=caseGlobal.checked;
      bouton.classList.toggle('actif',porteeGlobale);
      maj();
    });
    const resultats=document.createElement('div');
    resultats.className='ps-aide-resultats';
    global.append(bouton,resultats);

    p.append(zoneFiltre,zoneFacettes,langues,global);
    nav.insertBefore(p,nav.firstChild);
    p._champ=champ; p._nombre=nombre; p._facettes=zoneFacettes;
    p._langues=langues; p._portee=portee; p._resultats=resultats;
    p._boutonGlobal=bouton;
    return p;
  }

  function categorieDe(libelle){
    if(!catalogue) return 'classique';
    for(const f of catalogue.langages)
      if(f.libelle===libelle) return f.categorie||'classique';
    return 'classique';
  }

  function facettesDe(libelle){
    if(!catalogue) return [];
    for(const f of catalogue.langages)
      if(f.libelle===libelle) return f.facettes||[];
    return [];
  }

  function langagesDuPanneau(){
    const barre=document.querySelector('.language-help .lh-languages');
    if(!barre) return [];
    return [...barre.querySelectorAll('button')].map(b=>({
      nom:String(b.textContent||'').trim(),bouton:b,
      actif:b.classList.contains('selected')}));
  }

  function apprendreComptes(){
    /* Le langage ouvert affiche ses groupes et leurs totaux : c'est la seule
     * façon de compter les fiches internes au bundle. */
    const actif=langagesDuPanneau().find(l=>l.actif);
    if(!actif) return;
    let total=0,vus=0;
    for(const s of document.querySelectorAll('.language-help .lh-group summary')){
      const m=/\((\d+)\)/.exec(s.textContent||'');
      if(m){ total+=parseInt(m[1],10); vus++; }
    }
    if(vus) comptesAppris[actif.nom]=total;
  }

  function respecteFacettes(libelle){
    if(!facettes.size) return true;
    const offertes=new Set(facettesDe(libelle));
    for(const f of facettes) if(!offertes.has(f)) return false;
    return true;
  }

  function construireFacettes(p){
    const zone=p._facettes;
    zone.textContent='';
    if(!catalogue){
      const attente=document.createElement('span');
      attente.className=PREFIXE+'-attente';
      attente.textContent='Chargement des fonctionnalités…';
      zone.append(attente);
      return;
    }
    for(const f of catalogue.fonctionnalites){
      const n=catalogue.langages.filter(l=>(l.facettes||[]).includes(f.id)).length;
      const bouton=document.createElement('button');
      bouton.type='button';
      bouton.className=PREFIXE+'-facette'+(facettes.has(f.id)?' actif':'');
      bouton.setAttribute('aria-pressed',facettes.has(f.id)?'true':'false');
      bouton.title=n+' langage(s) sur '+catalogue.total+' : '+f.libelle;
      const lib=document.createElement('span');
      lib.textContent=f.libelle;
      const compte=document.createElement('span');
      compte.className='ps-aide-facette-nombre';
      compte.textContent=String(n);
      bouton.append(lib,compte);
      if(!n) bouton.disabled=true;
      bouton.addEventListener('click',()=>{
        if(facettes.has(f.id)) facettes.delete(f.id); else facettes.add(f.id);
        bouton.classList.toggle('actif',facettes.has(f.id));
        bouton.setAttribute('aria-pressed',facettes.has(f.id)?'true':'false');
        maj();
      });
      zone.append(bouton);
    }
  }

  function construireLangues(p){
    const zone=p._langues;
    zone.textContent='';
    const compte=comptes();
    const demande=normaliser(filtre.trim());
    const listes=langagesDuPanneau().filter(l=>{
      if(!l.nom) return false;
      if(demande){
        const ext=(catalogue?catalogue.langages.find(f=>f.libelle===l.nom):null);
        const extensions=ext?(ext.extensions||[]).join(' '):'';
        if(!normaliser(l.nom+' '+extensions).includes(demande)) return false;
      }
      return respecteFacettes(l.nom);
    });
    p._nombre.textContent=listes.length+' langage(s) sur '
      +langagesDuPanneau().length+(facettes.size?' · filtré par fonctionnalité':'');
    if(!listes.length){
      const vide=document.createElement('p');
      vide.className=PREFIXE+'-vide';
      vide.textContent=filtre.trim()||facettes.size
        ?'Aucun langage ne correspond à ce filtre.'
        :'Aucun langage d’aide n’est chargé.';
      zone.append(vide);
      return;
    }
    const categories=(catalogue&&catalogue.categories)?catalogue.categories
      :[{id:'classique',libelle:'Classiques'},{id:'esoterique',libelle:'Ésotériques'}];
    for(const c of categories){
      const membres=listes.filter(l=>categorieDe(l.nom)===c.id);
      if(!membres.length) continue;
      const groupe=document.createElement('div');
      groupe.className='ps-aide-categorie';
      groupe.setAttribute('data-categorie',c.id);
      const titre=document.createElement('p');
      titre.className='ps-aide-categorie-titre';
      titre.textContent=c.libelle+' ('+membres.length+')';
      groupe.append(titre);
      for(const l of membres){
        const bouton=document.createElement('button');
        bouton.type='button';
        bouton.className='ps-aide-langue'+(l.actif?' selected':'');
        bouton.setAttribute('aria-current',l.actif?'true':'false');
        bouton.setAttribute('data-langage',l.nom);
        const nom=document.createElement('span');
        nom.className='ps-aide-nom'; nom.textContent=l.nom;
        bouton.append(nom);
        const n=compte[l.nom];
        if(n){
          const badge=document.createElement('span');
          badge.className='ps-aide-compte';
          badge.textContent=String(n);
          badge.title=n+' fiche(s) d’aide pour '+l.nom;
          bouton.append(badge);
        }
        bouton.title=l.nom+(n?' — '+n+' fiche(s)':'')
          +(facettesDe(l.nom).length?' — '+facettesDe(l.nom).length+' fonctionnalité(s)':'');
        bouton.addEventListener('click',()=>{l.bouton.click();maj();});
        groupe.append(bouton);
      }
      zone.append(groupe);
    }
  }

  function resultatsGlobaux(requete){
    const q=normaliser(requete.trim());
    if(!q) return [];
    const sortis=[];
    index().forEach((entree,position)=>{
      const a=entree.article;
      const libelle=String(a.lang||'').trim();
      /* Un langage absent du catalogue des capacités ne peut rien revendiquer :
       * dès qu'une fonctionnalité est demandée, il sort des résultats. C'est
       * voulu — afficher une page d'un langage dont on ignore les capacités
       * sous une facette « débogage pas à pas » serait une promesse non tenue. */
      if(libelle&&!respecteFacettes(libelle)) return;
      /* Le titre d'abord, puis l'en-tête de la fiche, puis son corps : chercher
       * « boucle » doit remonter les fiches qui en parlent, pas celles qui
       * contiennent le mot une fois au détour d'un exemple. À score égal, c'est
       * l'ordre des catalogues qui tranche — il est stable, alors qu'un tri
       * alphabétique par langage ferait dépendre le premier résultat du nom du
       * langage et non de sa pertinence. */
      const score=normaliser(a.title).includes(q)?3
        :(normaliser([a.lang,a.group,a.summary].join(' ')).includes(q)?2
          :(entree.plat.includes(q)?1:0));
      if(!score) return;
      sortis.push({article:a,score,position,extrait:extraitDe(entree.brut,requete)});
    });
    sortis.sort((x,y)=>y.score-x.score||x.position-y.position);
    return sortis.slice(0,MAX_RESULTATS);
  }

  function extraitDe(brut,requete){
    const ou=normaliser(brut).indexOf(normaliser(requete.trim()));
    if(ou<0) return '';
    const debut=Math.max(0,ou-40);
    const morceau=brut.slice(debut,debut+MAX_EXCERPT).replace(/\s+/g,' ');
    return (debut>0?'…':'')+morceau.trim()+(debut+MAX_EXCERPT<brut.length?'…':'');
  }

  function definirValeur(input,valeur){
    /* Champ contrôlé par React : écrire .value ne suffit pas, l'état interne ne
     * verrait rien. Il faut passer par le setter du prototype puis émettre
     * « input », sinon la liste des fiches ne se filtre pas. */
    const proto=Object.getPrototypeOf(input);
    const desc=Object.getOwnPropertyDescriptor(proto,'value');
    if(!desc||!desc.set){input.value=valeur;return;}
    desc.set.call(input,valeur);
    input.dispatchEvent(new Event('input',{bubbles:true}));
  }

  async function ouvrirFiche(libelle,titre){
    const entree=langagesDuPanneau().find(l=>l.nom===libelle);
    /* Le champ de recherche du panneau borne la liste au langage courant : le
     * vider, sinon la fiche cherchée peut ne pas être rendue du tout. */
    const champ=document.getElementById('lh-find');
    if(champ&&champ.value) definirValeur(champ,'');
    if(entree) entree.bouton.click();
    for(let i=0;i<40;i++){
      await new Promise(r=>requestAnimationFrame(r));
      const bouton=[...document.querySelectorAll('.language-help .lh-group button')]
        .find(b=>String(b.textContent||'').trim()===String(titre||'').trim());
      if(bouton){bouton.click();return true;}
    }
    return false;
  }

  function construireResultats(p,requete){
    const zone=p._resultats;
    zone.textContent='';
    if(!porteeGlobale){
      p._portee.textContent='Portée : le langage sélectionné.';
      return;
    }
    const trouves=resultatsGlobaux(requete);
    p._portee.textContent=requete.trim()
      ?trouves.length+' résultat(s) dans '+index().length+' fiches indexées'
        +(trouves.length===MAX_RESULTATS?' (liste tronquée)':'')
      :'Portée : tous les langages. Saisissez un mot dans « Rechercher dans l’aide ».';
    if(!requete.trim()) return;
    if(!trouves.length){
      const vide=document.createElement('p');
      vide.className=PREFIXE+'-vide';
      vide.textContent='Aucune fiche ne contient « '+requete.trim()+' ».';
      zone.append(vide);
      return;
    }
    for(const r of trouves){
      const bouton=document.createElement('button');
      bouton.type='button'; bouton.className='ps-aide-resultat';
      bouton.setAttribute('data-langage',String(r.article.lang||''));
      bouton.setAttribute('data-titre',String(r.article.title||''));
      const chemin=document.createElement('span');
      chemin.className='ps-aide-resultat-chemin';
      chemin.textContent=[r.article.lang,r.article.group].filter(Boolean).join(' › ');
      const titre=document.createElement('span');
      titre.className='ps-aide-resultat-titre';
      titre.textContent=String(r.article.title||'(sans titre)');
      bouton.append(chemin,titre);
      if(r.extrait){
        const ex=document.createElement('span');
        ex.className='ps-aide-resultat-extrait';
        ex.textContent=r.extrait;
        bouton.append(ex);
      }
      bouton.addEventListener('click',()=>{ouvrirFiche(r.article.lang,r.article.title);});
      zone.append(bouton);
    }
  }

  function signatureDe(p,requete){
    /* Tout ce dont l'affichage dépend, et rien d'autre. Identique d'un balayage
     * à l'autre, rien n'est à reconstruire : c'est ce qui arrête la cascade.
     * Les comptes appris entrent dans la signature, donc apprendre un total
     * dans le DOM provoque exactement une reconstruction, pas une de plus. */
    const c=catalogue;
    return JSON.stringify({
      f:filtre,
      x:[...facettes].sort(),
      g:porteeGlobale,
      c:c?(c.langages.length+'/'+c.fonctionnalites.length+'/'
           +((c.categories||[]).length)):'-',
      l:langagesDuPanneau().map(l=>l.nom+(l.actif?'*':'')),
      n:comptes(),
      e:p._facettes.childElementCount===0,
      q:requete});
  }

  function maj(force){
    const p=panneau();
    if(!p) return;
    /* L'application peut démonter et remonter le panneau : le nouvel élément a
     * des zones vides, et une signature inchangée ne doit pas les laisser telles
     * quelles. Changer de panneau remet donc la signature à zéro. */
    if(p!==panneauCourant){panneauCourant=p;signature=null;dernierEssai=0;}
    apprendreComptes();
    const barre=document.querySelector('.language-help .lh-languages');
    /* La barre d'origine reste dans le DOM — ce sont ses boutons que l'index
     * clique — mais elle est masquée : deux listes de langages côte à côte ne
     * seraient pas une amélioration. Ajouter une classe n'est pas une mutation
     * de childList, donc cela ne rappelle pas l'observateur. */
    if(barre) barre.classList.add('ps-aide-index-cache');
    const champ=document.getElementById('lh-find');
    const requete=champ?champ.value:'';
    const etat=signatureDe(p,requete);
    if(!force&&etat===signature) return;
    signature=etat;
    if(p._facettes.childElementCount===0||catalogue) construireFacettes(p);
    construireLangues(p);
    construireResultats(p,requete);
    if(p._champ&&p._champ.value!==filtre) p._champ.value=filtre;
    if(p._boutonGlobal)
      p._boutonGlobal.classList.toggle('actif',porteeGlobale);
  }

  function surveillerRecherche(){
    /* La recherche du panneau est un champ contrôlé par l'application : c'est en
     * écoutant ses événements que la portée « tous les langages » suit la frappe,
     * sans dupliquer le champ. */
    const champ=document.getElementById('lh-find');
    if(!champ||champ._psAideIndexSuivi) return;
    champ._psAideIndexSuivi=true;
    champ.addEventListener('input',()=>{
      const p=panneau();
      if(p) construireResultats(p,champ.value);
    });
  }

  async function chargerCapacites(){
    if(catalogue) return catalogue;
    if(chargement) return chargement;
    dernierEssai=Date.now();
    chargement=(async()=>{
      try{
        const r=await fetch('/api/aide/capacites',{method:'POST',
          headers:{'Content-Type':'application/json'},body:'{}'});
        const d=await r.json();
        if(!r.ok) throw new Error(d.message||d.error||('HTTP '+r.status));
        if(d&&Array.isArray(d.langages)&&Array.isArray(d.fonctionnalites)){
          catalogue=d;
          const p=panneau();
          if(p) maj();
        }
      }catch(e){
        /* Sans serveur, l'index reste utilisable : les facettes sont alors
         * absentes, mais la liste des langages et la recherche fonctionnent. */
        catalogue=null;
        const p=panneau();
        if(p&&p._facettes){
          p._facettes.textContent='';
          const erreur=document.createElement('span');
          erreur.className=PREFIXE+'-erreur';
          erreur.textContent='Fonctionnalités indisponibles : '+e.message;
          p._facettes.append(erreur);
        }
      }finally{
        chargement=null;
      }
      return catalogue;
    })();
    return chargement;
  }

  function balayer(){
    /* Deux garde-fous, parce que la signature seule ne suffit pas : nos
     * écritures sont enregistrées par l'observateur PENDANT le rappel, et une
     * reconstruction légitime (filtre, facette, langage actif) en produit
     * toujours. Sans eux, l'observateur nous rappellerait pour notre propre
     * travail. */
    if(enCours) return;
    const aide=document.querySelector('.language-help');
    if(!aide) return;
    enCours=true;
    try{
      const p=panneau();
      if(!p) return;
      surveillerRecherche();
      maj();
      if(!catalogue&&!chargement&&Date.now()-dernierEssai>=DELAI_REESSAI)
        chargerCapacites();
    }finally{
      enCours=false;
      /* Jeter les enregistrements que nos écritures viennent de produire : ils
       * sont déjà reflétés à l'écran, les livrer relancerait un balayage. */
      if(observateur) observateur.takeRecords();
    }
  }

  observateur=new MutationObserver(balayer);
  observateur.observe(document.documentElement,{subtree:true,childList:true});
  if(document.readyState==='loading')
    document.addEventListener('DOMContentLoaded',balayer);
  else balayer();

  /* Exporté pour les bancs de fumée : ce sont les mêmes fonctions que celles
   * utilisées en production, pas des doublons de test. */
  window.PSAideIndex={balayer,maj,panneau,normaliser,articles,comptes,index,
    resultatsGlobaux,categorieDe,facettesDe,langagesDuPanneau,ouvrirFiche,
    definirValeur,chargerCapacites,apprendreComptes,extraitDe,
    etat:()=>({filtre,facettes:[...facettes],porteeGlobale,catalogue:!!catalogue,
               comptesAppris:Object.assign({},comptesAppris)}),
    regler:(options)=>{
      const o=options||{};
      if(typeof o.filtre==='string') filtre=o.filtre;
      if(Array.isArray(o.facettes)){facettes.clear();o.facettes.forEach(f=>facettes.add(f));}
      if(typeof o.porteeGlobale==='boolean') porteeGlobale=o.porteeGlobale;
      /* 'catalogue' dans o, et non o.catalogue : un banc doit pouvoir remettre
       * le catalogue à null pour tester la panne du serveur. */
      if('catalogue' in o) catalogue=o.catalogue;
      if(o.reinitialiserIndex) indexArticles=null;
      /* Forcé : un banc qui remet le même état doit quand même obtenir un
       * affichage reconstruit, sinon il mesurerait la garde-fou au lieu de la
       * fonction qu'il veut tester. */
      maj(true);
    }};
})();
