/* Tokenizer de l'assembleur x86-64 pour Pascal Studio — ENGENDRÉ par
   asm_studio.py depuis les tables d'assembleur.py. Ne pas modifier à la main :
   la modification serait perdue au prochain engendrement, et c'est voulu, pour
   que la coloration ne diverge jamais de l'analyseur.
   marqueur : ps-4.0.0-assembleur
   201 mnémoniques explicites, 203 registres,
   100 directives, et 7 familles régulières
   (jcc, setcc, cmovcc, SSE/AVX, opérations sur les chaînes, MMX). */
export const conf={
  comments:{lineComment:'#',blockComment:['/*','*/']},
  brackets:[['[',']'],['(',')']],
  autoClosingPairs:[
    {open:'"',close:'"'},
    {open:"'",close:"'"},
    {open:'[',close:']'},
    {open:'(',close:')'}
  ],
  surroundingPairs:[{open:'[',close:']'},{open:'(',close:')'},{open:'"',close:'"'}]
};

export const language={
  ignoreCase:true,
  /* Les mnémoniques hors familles régulières. */
  keywords:
    ('adc add and bsf bsr bswap bt btc btr bts call cbw cdq clc cld clflush cli cmc cmov cmp cpuid cqo' +
    ' cvtdq2ps cvtsd2ss cvtsi2sd cvtsi2ss cvtss2sd cvttps2dq cvttsd2si cvttss2si cwd cwde dec div emms' +
    ' enter fadd fcom fcomp fcompp fdiv fild finit fist fistp fld fldcw fldenv fmul fninit fnstcw fst' +
    ' fstcw fstenv fstp fsub fwait fxch hlt idiv imul inc int into iret iretq jcxz jecxz jmp jrcxz' +
    ' lahf lea leave lfence lgdt lidt loop loope loopne loopnz loopz lzcnt mfence mov movabs movdq' +
    ' movpd movps movsx movsxd movzx mul neg nop not or pand pause pcmpeqb pcmpeqd pcmpeqw pcmpgtb' +
    ' pcmpgtd pcmpgtw pdep pext pmovmskb pmulld pmullw pop popa popcnt popf popfq por prefetcht0' +
    ' pslldq psrldq punpckhqdq punpcklqdq push pusha pushf pushfq pxor rcl rcr rdmsr rdtsc rdtscp rep' +
    ' repe repne repnz repz ret retf rol ror sahf sal sar sbb setcc sfence sgdt shl shld shr shrd' +
    ' shufpd shufps sidt stc std sti sub syscall sysenter sysexit sysret test tzcnt ud2 unpckhps' +
    ' unpcklps vcvtdq2ps vcvtsd2ss vcvtsi2sd vcvtsi2ss vcvtss2sd vcvttps2dq vcvttsd2si vcvttss2si' +
    ' vmovdq vmovpd vmovps vpand vpcmpeqb vpcmpeqd vpcmpeqw vpcmpgtb vpcmpgtd vpcmpgtw vpmovmskb' +
    ' vpmulld vpmullw vpor vpslldq vpsrldq vpunpckhqdq vpunpcklqdq vpxor vshufpd vshufps vunpckhps' +
    ' vunpcklps wrmsr xadd xchg xor').split(' '),
  /* Les registres, toutes largeurs : rax, eax, ax, ah, r15d, xmm0, rip… */
  registers:
    ('ah al ax bh bl bp bpl bx ch cl cr0 cr2 cr3 cr4 cr8 cs cx dh di dil dl dr0 dr1 dr2 dr3 dr4 dr5' +
    ' dr6 dr7 ds dx eax ebp ebx ecx edi edx eip es esi esp fs gs ip mm0 mm1 mm2 mm3 mm4 mm5 mm6 mm7' +
    ' r10 r10b r10d r10w r11 r11b r11d r11w r12 r12b r12d r12w r13 r13b r13d r13w r14 r14b r14d r14w' +
    ' r15 r15b r15d r15w r8 r8b r8d r8w r9 r9b r9d r9w rax rbp rbx rcx rdi rdx rip rsi rsp si sil sp' +
    ' spl ss st st0 st1 st2 st3 st4 st5 st6 st7 xmm0 xmm1 xmm10 xmm11 xmm12 xmm13 xmm14 xmm15 xmm16' +
    ' xmm17 xmm18 xmm19 xmm2 xmm20 xmm21 xmm22 xmm23 xmm24 xmm25 xmm26 xmm27 xmm28 xmm29 xmm3 xmm30' +
    ' xmm31 xmm4 xmm5 xmm6 xmm7 xmm8 xmm9 ymm0 ymm1 ymm10 ymm11 ymm12 ymm13 ymm14 ymm15 ymm16 ymm17' +
    ' ymm18 ymm19 ymm2 ymm20 ymm21 ymm22 ymm23 ymm24 ymm25 ymm26 ymm27 ymm28 ymm29 ymm3 ymm30 ymm31' +
    ' ymm4 ymm5 ymm6 ymm7 ymm8 ymm9 zmm0 zmm1 zmm10 zmm11 zmm12 zmm13 zmm14 zmm15 zmm16 zmm17 zmm18' +
    ' zmm19 zmm2 zmm20 zmm21 zmm22 zmm23 zmm24 zmm25 zmm26 zmm27 zmm28 zmm29 zmm3 zmm30 zmm31 zmm4' +
    ' zmm5 zmm6 zmm7 zmm8 zmm9').split(' '),
  /* Directives des deux assembleurs, sans leur point : le point est reconnu
     séparément pour que « .text » et « section » soient tous les deux colorés. */
  directives:
    ('__FILE__ __LINE__ __SECT__ absolute align alignb arch ascii asciz at att_syntax balign bits bss' +
    ' bundle_align_mode byte code16 code32 code64 comm cpu data db dd def default dim do dq dt dw dy' +
    ' dz else elseif endef endif endm endr endstruc equ extern file fill float global globl hidden' +
    ' ident iend if ifdef ifndef incbin include int intel_syntax irp irpc istruc lcomm local long' +
    ' ltorg macro org p2align popsection previous pushsection quad rept resb resd resdq resq rest resw' +
    ' rodata scl section segment set size skip space string struc subsection text times type use16' +
    ' use32 use64 val value weak word zero').split(' '),
  tokenizer:{
    root:[
      /* Commentaires : « # » en GAS, « ; » en NASM. Les deux sont acceptés
         partout, parce qu'un fichier en cours de conversion emploie les deux. */
      [/[#;].*$/,'comment'],
      [/\/\*/,'comment','@commentaire'],

      /* Étiquette en début de ligne, avec ou sans deux-points (NASM écrit
         « msg db 1 » sans deux-points). */
      [/^[ \t]*[A-Za-z_.][\w.$]*(?=\s*:)/,'type.identifier'],
      [/^[ \t]*[A-Za-z_.][\w.$]*(?=\s+(?:db|dw|dd|dq|dt|equ|resb|resw|resd|resq|times)\b)/,
        'type.identifier'],

      /* Immédiat AT&T : « $1 », « $0x1f ». À reconnaître AVANT les registres,
         sinon le « $ » reste du texte et le nombre est colorié en identifiant. */
      [/\$-?(?:0[xX][0-9a-fA-F]+|0[bB][01]+|\d+)/,'number'],

      /* Registre AT&T préfixé par « % ». */
      [/%[A-Za-z][\w]*/,{cases:{'@registers':'variable.predefined',
                                  '@default':'identifier'}}],

      /* Directives, avec ou sans point. */
      [/\.[A-Za-z_][\w.]*/,{cases:{'@directives':'keyword',
                                     '@default':'metatag'}}],
      [/^(?:section|segment|global|extern|bits|default|struc|endstruc|istruc|iend|times|equ|db|dw|dd|dq|dt|resb|resw|resd|resq)\b/,'keyword'],

      /* Familles régulières : jcc, setcc, cmovcc, SSE/AVX, chaînes, MMX. */
    [/j(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\\b/,'keyword'],
    [/set(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\\b/,'keyword'],
    [/cmov(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\\b/,'keyword'],
    [/v?(?:add|sub|mul|div|sqrt|and|or|xor|cmp|min|max)(?:ss|sd|ps|pd)\\b/,'keyword'],
    [/v?mov(?:aps|ups|apd|upd|dqa|dqu|ss|sd|mskps|mskpd)\\b/,'keyword'],
    [/(?:rep|repe|repz|repne|repnz)?\s*(?:movs|stos|lods|cmps|scas)[bwlqd]\\b/,'keyword'],
    [/v?p(?:xor|or|and|add|sub|mul|cmp|madd|shuf|unpck|sll|srl|sra)[bwdq]\\b/,'keyword'],

      /* Mnémonique explicite, ou registre nu en syntaxe Intel, ou identifiant. */
      [/[A-Za-z][\w.]*/,{cases:{'@keywords':'keyword',
                                 '@registers':'variable.predefined',
                                 '@default':'identifier'}}],

      /* Nombres : hexadécimal, binaire, décimal, et la forme NASM « 0FFh ». */
      [/0[xX][0-9a-fA-F]+/,'number'],
      [/0[bB][01]+/,'number'],
      [/\d+[hHbBoOdDqQ]?/,'number'],

      [/"(?:[^"\\]|\\.)*"/,'string'],
      [/'(?:[^'\\]|\\.)*'/,'string'],

      [/[[\]()]/,'@brackets'],
      [/[,:+\-*\/<>&|^!~]/,'operator'],
      [/\s+/,'white']
    ],
    commentaire:[
      [/[^/*]+/,'comment'],
      [/\*\//,'comment','@pop'],
      [/[/*]/,'comment']
    ]
  }
};
