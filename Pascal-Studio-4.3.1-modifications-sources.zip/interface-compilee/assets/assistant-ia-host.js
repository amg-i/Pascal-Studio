/* Host de l'interface IA, chargée depuis le service privé sur la machine. */
(()=>{
 const seen=new WeakSet();
 async function attach(el){if(seen.has(el))return;seen.add(el);el.textContent='Démarrage de l’assistant IA local…';
  try{const r=await fetch('/api/assistant/location');const d=await r.json();if(!r.ok||!/^http:\/\/127\.0\.0\.1:\d+\/$/.test(d.url))throw Error('Service IA indisponible.');
   const frame=document.createElement('iframe');frame.title='Assistant IA local';frame.src=d.url;frame.setAttribute('sandbox','allow-scripts allow-same-origin allow-downloads allow-modals allow-popups');frame.className='ps-ai-frame';el.replaceChildren(frame);
  }catch(e){el.textContent='Assistant IA indisponible : '+e.message+' Fermez cet onglet et réessayez.'}}
 function scan(){document.querySelectorAll('.ps-ai-host').forEach(attach)}
 new MutationObserver(scan).observe(document.documentElement,{subtree:true,childList:true});scan();
})();
