/* Data panel for the compiled Pascal Studio desktop application.
   No project data is interpolated as HTML. All writes require a separate action. */
(()=>{
'use strict';
const formats=/\.(?:sqlite3?|db3?|csv|tsv|json|sql|xlsx|xlsm|ods|xml)$/i;
const icon='<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v7c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12v7c0 1.7 3.6 3 8 3s8-1.3 8-3v-7"/></svg>';
/* Une « surface » est l'endroit où l'éditeur est monté : soit un ONGLET
 * (hôte .ps-data-host créé par l'application pour un fichier de données), soit
 * la MODALE historique (sélecteur de fichiers et connexions PostgreSQL /
 * MySQL, qui n'ont pas de fichier à ouvrir en onglet).
 *
 * Les fonctions de rendu ne savent pas laquelle des deux elles dessinent :
 * elles passent toutes par `surf`. Une seule surface est active à la fois. */
let surf=null;
let files=[],lastFocused=null,body=null,sub=null;
function surfaceVide(){return{layer:null,body:null,sidebar:null,main:null,footer:null,sub:null,sources:[],selected:null,onglet:false,hote:null,chemin:null}}
function activerSurface(s){surf=s}
function aucuneSurface(){return surf===null||surf.layer===null}
activerSurface(surfaceVide());
const $=(sel,base=document)=>base.querySelector(sel);
function el(tag,attrs={},text){const e=document.createElement(tag);for(const [k,v] of Object.entries(attrs)){if(k==='class')e.className=v;else if(k==='title')e.title=v;else if(k==='disabled')e.disabled=v;else if(k==='type')e.type=v;else if(k==='value')e.value=v;else if(k==='placeholder')e.placeholder=v;else if(k==='checked')e.checked=v;else e.setAttribute(k,v)}if(text!==undefined)e.textContent=String(text);return e}
function button(text,fn,cls='',title=''){const b=el('button',{type:'button',class:cls,title},text);b.addEventListener('click',fn);return b}
async function api(path,data={}){const r=await fetch('/api/data/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});let j;try{j=await r.json()}catch{throw Error('Réponse invalide du serveur.')}if(!r.ok)throw Error(j.error||'Erreur du serveur');return j}
function status(msg,error=false){if(!surf.footer)return;surf.footer.textContent=msg||'';surf.footer.classList.toggle('psdata-error',!!error)}
function onerror(e){status(e?.message||String(e),true)}
function dirty(s){return !!(s&&(s.dirty||(s.pending&&Object.keys(s.pending).length)||(s.inserts&&s.inserts.length)))}
function hasUnsaved(s){return dirty(s)||!!s?.queryDirty}
function active(){return surf.sources.find(s=>s.id===surf.selected)}
function setDirty(s){s.dirty=true;const span=$('[data-dirty]',surf.layer);if(span)span.textContent='● Modifications non enregistrées';status('Modifications en attente — utilisez Enregistrer.')}
function format(v){if(v===null)return 'NULL';if(v&&typeof v==='object')return v.$kind==='binaire'?`Binaire · ${v.taille} octets`:v.$kind==='texte-long'?`${v.apercu}… (${v.taille} caractères)`:v.texte??JSON.stringify(v);return String(v)}
function isScalar(v){return v===null||typeof v==='string'||typeof v==='boolean'||(typeof v==='number'&&Number.isFinite(v)&&(!Number.isInteger(v)||Number.isSafeInteger(v)))}
function kindOf(v){return v===null?'null':typeof v==='number'?'number':typeof v==='boolean'?'boolean':'text'}
function parseValue(type,text){if(type==='null')return null;if(type==='text')return text;if(type==='boolean'){if(text!=='true'&&text!=='false')throw Error('Choisissez true ou false.');return text==='true'}if(type==='number'){if(!text.trim())throw Error('Saisissez un nombre.');const n=Number(text);if(!Number.isFinite(n)||(Number.isInteger(n)&&!Number.isSafeInteger(n)))throw Error('Nombre non pris en charge ou trop grand.');return n}throw Error('Type invalide.')}
function canonicalNumber(raw){
 const m=/^(-?)(\d+)(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/.exec(raw);if(!m||raw.length>10000||(m[4]||'').length>8)throw Error('Nombre JSON trop long.');let digits=(m[2]+(m[3]||'')).replace(/^0+/,'');if(!digits)return m[1]?'negative-zero':'zero';let exp=BigInt(m[4]||'0')-BigInt((m[3]||'').length);const trailing=(digits.match(/0+$/)||[''])[0].length;if(trailing){digits=digits.slice(0,-trailing);exp+=BigInt(trailing)}return m[1]+digits+'e'+exp;
}
function checkJSONNumbers(text){
 let inside=false,escape=false;
 for(let i=0;i<text.length;i++){
  const c=text[i];if(inside){if(escape)escape=false;else if(c==='\\')escape=true;else if(c==='"')inside=false;continue}if(c==='"'){inside=true;continue}
  if(c==='-'||(c>='0'&&c<='9')){const m=/^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/.exec(text.slice(i));if(!m)continue;const raw=m[0],n=Number(raw);if(!Number.isFinite(n)||(Number.isInteger(n)&&!Number.isSafeInteger(n))||Object.is(n,-0)||canonicalNumber(raw)!==canonicalNumber(String(n)))throw Error('Ce JSON contient un nombre dont la précision serait perdue. Utilisez la vue texte.');i+=raw.length-1}
 }
}
function assertJSONValid(s){if(s.jsonErrors&&Object.keys(s.jsonErrors).length)throw Error('Corrigez les cellules JSON invalides avant de continuer.');}
function field(card,labelText,input){const w=el('label',{class:'field'});w.append(el('span',{},labelText),input);card.append(w);return input}
function select(values,current){const s=el('select');for(const [v,t] of values){const o=el('option',{value:v},t);if(v===current)o.selected=true;s.append(o)}s.value=current;return s}
function dialog(title,description,build,onSubmit,submitText='Valider'){
 if(sub)sub.remove();sub=el('div',{class:'psdata-subdialog'});const card=el('form',{class:'psdata-card',role:'dialog','aria-label':title});card.append(el('h2',{},title));if(description)card.append(el('p',{},description));const message=el('p',{class:'psdata-error','aria-live':'polite'});let controls=build(card)||{};card.append(message);const actions=el('div',{class:'actions'}),cancel=button('Annuler',()=>{sub.remove();sub=null});const submit=el('button',{class:'primary',type:'submit'},submitText);actions.append(cancel,submit);card.append(actions);sub.append(card);surf.layer.append(sub);card.addEventListener('submit',async e=>{e.preventDefault();submit.disabled=true;try{await onSubmit(controls);sub.remove();sub=null}catch(err){message.textContent=err.message||String(err);submit.disabled=false}});setTimeout(()=>card.querySelector('input,textarea,select')?.focus(),30)
}
function connectionDialog(){
 dialog('Connexion à un serveur','Les identifiants restent uniquement en mémoire et sont supprimés à la fermeture. TLS vérifié est recommandé.',card=>{
  const type=field(card,'Système',select([['postgres','PostgreSQL'],['mysql','MySQL / MariaDB']],'postgres'));
  const host=field(card,'Hôte',el('input',{value:'localhost',required:'required'}));const port=field(card,'Port',el('input',{value:'5432',type:'number',min:'1',max:'65535',required:'required'}));
  type.addEventListener('change',()=>port.value=type.value==='postgres'?'5432':'3306');
  const db=field(card,'Base de données',el('input',{required:'required',placeholder:'Nom de la base'}));const user=field(card,'Utilisateur',el('input',{required:'required',autocomplete:'username'}));const password=field(card,'Mot de passe',el('input',{type:'password',autocomplete:'off'}));
  const tls=el('input',{type:'checkbox',checked:true});const note=el('label');note.append(tls,document.createTextNode(' TLS avec vérification du certificat'));card.append(note,el('p',{class:'psdata-warning'},'Sans TLS, seuls localhost, 127.0.0.1 et ::1 sont autorisés. Un serveur distant doit présenter un certificat reconnu.'));
  const ca=field(card,'Certificat CA personnalisé (facultatif)',el('input',{placeholder:'Chemin absolu vers le certificat PEM'}));const choose=button('Choisir le certificat…',async()=>{if(window.pascalDesktop?.chooseFile){const path=await window.pascalDesktop.chooseFile();if(path)ca.value=path}});card.append(choose);return {type,host,port,db,user,password,tls,ca};
 },async v=>{if(!v.tls.checked&&!confirm('Connexion locale sans chiffrement : le mot de passe et les données circuleront en clair sur la machine. Continuer ?'))throw Error('Connexion annulée.');const o=await api('connect',{kind:v.type.value,host:v.host.value,port:v.port.value,database:v.db.value,user:v.user.value,password:v.password.value,tls:v.tls.checked,ca_file:v.ca.value});v.password.value='';await addSource(o)},'Connecter')
}
function createSQLite(){dialog('Créer une base SQLite','Le fichier sera créé dans le projet ouvert. Un fichier existant ne sera jamais écrasé.',card=>({path:field(card,'Chemin relatif dans le projet',el('input',{value:'donnees.sqlite',required:'required'}))}),async v=>{const name=v.path.value.trim();const result=await api('create-sqlite',{path:name});await addSource(result);loadFiles()},'Créer')}
async function openNative(){try{if(!window.pascalDesktop?.chooseFile)throw Error('La sélection native est disponible dans l’application de bureau.');const path=await window.pascalDesktop.chooseFile();if(!path)return;status('Ouverture du fichier…');await addSource(await api('open-external',{path}))}catch(e){onerror(e)}}
async function loadFiles(){try{const r=await fetch('/api/tree');if(!r.ok)throw Error('Impossible de lire le projet.');const j=await r.json();files=[];const walk=nodes=>{for(const n of nodes){if(n.type==='folder')walk(n.children||[]);else if(formats.test(n.name))files.push(n.path)}};walk(j.tree||[]);renderSidebar()}catch(e){onerror(e)}}
async function openProject(path){try{status('Ouverture du fichier…');await addSource(await api('open',{path}))}catch(e){onerror(e)}}
async function addSource(o){const s={...o,dirty:false,offset:0,tables:o.tables||[],table:null,pending:{},inserts:[],queryText:'',result:null,firstHeader:true,csvPage:0,jsonMode:false};if(['sqlite','postgres','mysql'].includes(s.kind)){try{s.tables=(await api('tables',{id:s.id})).tables}catch(e){await api('close',{id:s.id}).catch(()=>{});throw e}}surf.sources.push(s);surf.selected=s.id;render();status('Source ouverte : '+s.label)}
async function closeSource(s){if(hasUnsaved(s)&&!confirm('Des modifications ne sont pas enregistrées. Fermer cette source et les abandonner ?'))return;try{await api('close',{id:s.id})}catch(e){onerror(e);return}surf.sources=surf.sources.filter(x=>x!==s);if(surf.selected===s.id)surf.selected=surf.sources.at(-1)?.id||null;render();status('Source fermée.')}
async function closeAll(){if(surf.sources.some(hasUnsaved)&&!confirm('Des modifications ne sont pas enregistrées. Fermer et les abandonner ?'))return;const closing=[...surf.sources];surf.sources=[];surf.selected=null;SESSIONS.forEach((v,k)=>{if(closing.includes(v))SESSIONS.delete(k)});if(surf.onglet){if(surf.layer)surf.layer.replaceChildren();hoteActif=null;surfaceOnglet=null}else{surf.layer?.remove();surfaceModale=null}surf.layer=null;body=surf.sidebar=surf.main=surf.footer=sub=null;for(const s of closing)api('close',{id:s.id}).catch(()=>{});activerSurface(surfaceOnglet&&surfaceOnglet.hote&&surfaceOnglet.hote.isConnected?surfaceOnglet:surfaceVide());if(surf.layer&&surf.layer.isConnected)render();if(lastFocused?.isConnected)lastFocused.focus()}
function openPanel(){
 if(surfaceModale&&surfaceModale.layer&&surfaceModale.layer.isConnected)return;
 lastFocused=document.activeElement;
 const s=surfaceModale||surfaceVide();
 surfaceModale=s;s.onglet=false;activerSurface(s);
 s.layer=el('div',{class:'psdata-overlay'});
 const box=el('section',{class:'psdata-modal',role:'dialog','aria-modal':'true','aria-label':'Données et bases SQL'});
 box.innerHTML='<header class="psdata-header"><div class="psdata-logo">'+icon+'</div><div><h1>Données & bases SQL</h1><small>SQLite · CSV · JSON · XLSX · ODS · XML · PostgreSQL · MySQL</small></div><div class="psdata-spacer"></div></header><div class="psdata-body"><aside class="psdata-sidebar"></aside><main class="psdata-main"></main></div><div class="psdata-footer" aria-live="polite">Les fichiers du projet s’ouvrent dans leur propre onglet. Ce panneau garde les connexions serveur et les fichiers hors projet.</div>';
 box.querySelector('header').append(button('Aide des données',()=>{const type=active()?.kind;const map={sqlite:'SQLite',postgres:'PostgreSQL',mysql:'MySQL / MariaDB',json:'JSON',csv:'CSV / TSV',sql:'SQL',xlsx:'Données · Studio',ods:'Données · Studio',xml:'Données · Studio'};window.PSOpenDbHelp?.(map[type]||'Données · Studio')},'','Ouvrir l’aide hors ligne des bases et fichiers'),button('Tout fermer',closeAll,'','Fermer toutes les sources de ce panneau'),button('✕',fermerModale,'','Fermer le panneau ; les connexions restent ouvertes'));
 s.layer.append(box);document.body.append(s.layer);
 s.sidebar=$('.psdata-sidebar',s.layer);s.main=$('.psdata-main',s.layer);s.footer=$('.psdata-footer',s.layer);
 render();loadFiles();
 s.layer.addEventListener('keydown',e=>{if(e.key==='Escape'&&!sub){e.preventDefault();fermerModale()}});
}
function renderSidebar(){if(!surf.sidebar)return;surf.sidebar.replaceChildren();surf.sidebar.append(button('＋ Ouvrir un fichier…',openNative,'primary'),button('＋ Créer une base SQLite…',createSQLite),button('↔ Connexion serveur…',connectionDialog));surf.sidebar.append(el('h3',{},'Sources ouvertes'));const sl=el('div',{class:'psdata-source-list'});if(!surf.sources.length)sl.append(el('div',{class:'psdata-count'},'Aucune source ouverte'));for(const s of surf.sources){const item=button((s===active()?'● ':'○ ')+s.label,()=>{surf.selected=s.id;render()},'psdata-item'+(s===active()?' active':''),s.location||'');sl.append(item)}surf.sidebar.append(sl,el('h3',{},'Fichiers du projet'));const list=el('div',{class:'psdata-project-list'});if(!files.length)list.append(el('div',{class:'psdata-count'},'Aucun fichier compatible détecté.'));for(const f of files.slice(0,1000))list.append(button(f,()=>ouvrirDansOnglet(f),'psdata-item',f));surf.sidebar.append(list,button('Actualiser la liste',loadFiles))}
function top(s,extra){const row=el('div',{class:'psdata-toolrow'});row.append(el('h2',{title:s.location||s.label},s.label),el('span',{class:'psdata-badge'},({sqlite:'SQLite',csv:'CSV / TSV',json:'JSON',sql:'Script SQL',postgres:'PostgreSQL',mysql:'MySQL / MariaDB',xlsx:'Classeur XLSX',ods:'Classeur ODS',xml:'XML'})[s.kind]||s.kind),el('span',{'data-dirty':''},dirty(s)?'● Modifications non enregistrées':''),el('span',{class:'psdata-spacer'}));if(extra)for(const x of extra)row.append(x);if(!surf.onglet)row.append(button('Fermer la source',()=>closeSource(s),'','Fermer cette source'));return row}
function render(){if(!surf.layer)return;renderSidebar();surf.main.replaceChildren();const s=active();if(!s){const empty=el('div',{class:'psdata-empty'});empty.append(el('h2',{},'Explorer et modifier vos données'),el('p',{},'Ouvrez un fichier du projet, choisissez un fichier sur l’ordinateur ou connectez-vous à un serveur PostgreSQL / MySQL.'),el('p',{class:'psdata-warning'},'Les modifications ne sont écrites qu’après confirmation. Faites une sauvegarde avant toute opération importante.'));surf.main.append(empty);return}if(s.kind==='csv')renderCSV(s);else if(s.kind==='json'||s.kind==='sql')renderText(s);else renderDB(s)}
async function saveFile(s){try{if(s.kind==='json'&&s.jsonMode){assertJSONValid(s);applyJSONGrid(s);}if(s.kind==='json')JSON.parse(s.text);if(!dirty(s)){status('Aucune modification à enregistrer.');return}if(!confirm('Enregistrer les modifications dans « '+s.label+' » ? Le fichier sera remplacé.'))return;const payload={id:s.id,revision:s.revision};if(s.kind==='csv')payload.rows=s.rows;else payload.text=s.text;const r=await api('save',payload);s.revision=r.revision;s.dirty=false;render();status('Fichier enregistré : '+s.label)}catch(e){onerror(e)}}
function renderCSV(s){surf.main.append(top(s,[button('＋ Ligne',()=>{const n=Math.max(1,...s.rows.map(r=>r.length));if(!s.rows.length&&s.firstHeader)s.rows.push(Array.from({length:n},(_,i)=>'Colonne '+(i+1)));s.rows.push(Array(n).fill(''));s.csvPage=Math.floor((s.rows.length-(s.firstHeader?2:1))/100);setDirty(s);render()},''),button('＋ Colonne',()=>dialog('Ajouter une colonne','Le CSV sera réécrit lors de l’enregistrement.',card=>({name:field(card,'Nom de la colonne',el('input',{value:'Nouvelle colonne'}))}),async v=>{if(!s.rows.length)s.rows.push([]);const n=Math.max(...s.rows.map(r=>r.length));for(const row of s.rows){while(row.length<n)row.push('');row.push('')}if(s.firstHeader)s.rows[0][n]=v.name.value;setDirty(s);render()},'Ajouter')),button('Enregistrer',()=>saveFile(s),'primary')]));
 const opts=el('div',{class:'psdata-toolrow'});const chk=el('input',{type:'checkbox',checked:s.firstHeader});chk.addEventListener('change',()=>{s.firstHeader=chk.checked;s.csvPage=0;render()});const lab=el('label');lab.append(chk,document.createTextNode(' Première ligne comme en-têtes'));const separator=select([[',','Virgule'],[';','Point-virgule'],['\t','Tabulation'],['|','Barre verticale']],s.delimiter);separator.setAttribute('aria-label','Séparateur CSV');separator.addEventListener('change',async()=>{if(s.dirty&&!confirm('Changer le séparateur recharge le fichier et abandonne les modifications non enregistrées. Continuer ?')){separator.value=s.delimiter;return}try{const r=await api('reparse-csv',{id:s.id,delimiter:separator.value});s.rows=r.rows;s.revision=r.revision;s.delimiter=r.delimiter;s.dirty=false;s.csvPage=0;render();status('Fichier relu avec le séparateur choisi.')}catch(e){separator.value=s.delimiter;onerror(e)}});opts.append(lab,el('span',{class:'psdata-count'},'Séparateur :'),separator,el('span',{class:'psdata-spacer'}));const start=s.firstHeader?1:0,total=Math.max(0,s.rows.length-start),pages=Math.max(1,Math.ceil(total/100));s.csvPage=Math.max(0,Math.min(s.csvPage,pages-1));opts.append(button('‹',()=>{s.csvPage--;render()}),el('span',{class:'psdata-count'},`Page ${s.csvPage+1} / ${pages} · ${total} lignes`),button('›',()=>{s.csvPage++;render()}));surf.main.append(opts,el('p',{class:'psdata-hint'},'Modifiez les cellules directement. L’enregistrement réécrit le fichier CSV et conserve son séparateur.'));
 const wrap=el('div',{class:'psdata-scroll'}),table=el('table',{class:'psdata-grid'}),head=el('tr');head.append(el('th',{class:'rowctl'},'#'));const count=Math.max(1,...s.rows.map(r=>r.length));for(let i=0;i<count;i++){const th=el('th');if(s.firstHeader&&s.rows.length){const input=el('input',{value:s.rows[0][i]||'','aria-label':`En-tête ${i+1}`});input.addEventListener('input',()=>{while(s.rows[0].length<=i)s.rows[0].push('');s.rows[0][i]=input.value;setDirty(s)});th.append(input)}else th.textContent='Colonne '+(i+1);head.append(th)}table.append(el('thead',{}));table.tHead.append(head);const tb=el('tbody');const from=start+s.csvPage*100;for(let row=from;row<Math.min(s.rows.length,from+100);row++){const tr=el('tr'),ctl=el('td',{class:'rowctl'});ctl.append(button('×',()=>{s.rows.splice(row,1);setDirty(s);render()},'danger','Supprimer cette ligne'));tr.append(ctl);for(let col=0;col<count;col++){const td=el('td'),input=el('input',{value:s.rows[row][col]??'','aria-label':`Ligne ${row+1}, colonne ${col+1}`});input.addEventListener('input',()=>{while(s.rows[row].length<=col)s.rows[row].push('');s.rows[row][col]=input.value;setDirty(s)});td.append(input);tr.append(td)}tb.append(tr)}table.append(tb);wrap.append(table);surf.main.append(wrap)}
function sendScript(s){const dbs=surf.sources.filter(x=>['sqlite','postgres','mysql'].includes(x.kind));if(!dbs.length){status('Ouvrez d’abord une base ou une connexion SQL.',true);return}dialog('Charger le script SQL','Le texte sera copié dans l’éditeur de requête ; il ne sera pas exécuté.',card=>({target:field(card,'Connexion',select(dbs.map(x=>[x.id,x.label+' · '+x.kind]),dbs[0].id))}),async v=>{const target=dbs.find(x=>x.id===v.target.value);if(dirty(target)&&!confirm('Abandonner les modifications de table en attente sur cette connexion ?'))throw Error('Chargement annulé.');target.pending={};target.inserts=[];target.queryText=s.text;target.queryDirty=true;target.result=null;target.table=null;target.mode='query';surf.selected=target.id;render();status('Script chargé, sans exécution.')},'Charger')}
function jsonGridOpen(s){try{checkJSONNumbers(s.text);const x=JSON.parse(s.text);if(!Array.isArray(x)||x.some(v=>!v||typeof v!=='object'||Array.isArray(v)))throw Error('La vue tableau demande une liste d’objets JSON. Utilisez la vue texte pour les autres structures.');if(x.length>5000)throw Error('La vue tableau est limitée à 5 000 objets.');const keys=[...new Set(x.flatMap(Object.keys))];if(keys.length>200)throw Error('La vue tableau est limitée à 200 colonnes.');if(!confirm('La vue tableau reformate le JSON lors d’une modification ; les clés dupliquées ne sont pas conservées. Continuer ?'))return;s.jsonRows=x;s.jsonKeys=keys;s.jsonPage=0;s.jsonErrors={};s.jsonInvalidRaw={};s.jsonMode=true;render()}catch(e){onerror(e)}}
function applyJSONGrid(s){assertJSONValid(s);s.text=JSON.stringify(s.jsonRows,null,2)+'\n';s.jsonMode=false}
function renderText(s){const opts=[button('Enregistrer',()=>saveFile(s),'primary')];if(s.kind==='sql'){opts.unshift(button('Insérer une instruction…',()=>instructionSQL(s),'','Rédiger CREATE TABLE, ALTER TABLE ou DROP TABLE dans le script'));opts.unshift(button('Charger dans une connexion…',()=>sendScript(s)))}if(s.kind==='json')opts.unshift(button(s.jsonMode?'Vue texte':'Vue tableau',()=>{try{if(s.jsonMode){assertJSONValid(s);if(s.dirty)applyJSONGrid(s);else s.jsonMode=false;render()}else jsonGridOpen(s)}catch(e){onerror(e)}}));surf.main.append(top(s,opts));
 if(s.kind==='json'&&s.jsonMode){renderJSONGrid(s);return}
 const hint=el('p',{class:'psdata-hint'},s.kind==='json'?'JSON UTF-8 : validation avant l’enregistrement. La vue tableau accepte une liste d’objets.':'Script SQL UTF-8 : éditez et enregistrez le fichier. Pour l’exécuter, ouvrez une base et utilisez son onglet Requête SQL.');surf.main.append(hint);const area=el('textarea',{class:'psdata-editor','aria-label':s.kind==='json'?'Éditeur JSON':'Éditeur SQL'});area.value=s.text;area.addEventListener('input',()=>{s.text=area.value;setDirty(s)});surf.main.append(area);if(s.kind==='json')surf.main.append(button('Formater le JSON',()=>{try{if(!confirm('Le formatage peut supprimer les clés JSON dupliquées. Continuer ?'))return;checkJSONNumbers(s.text);s.text=JSON.stringify(JSON.parse(s.text),null,2)+'\n';setDirty(s);render()}catch(e){onerror(e)}}))}
function renderJSONGrid(s){const row=el('div',{class:'psdata-toolrow'});row.append(button('＋ Objet',()=>{try{assertJSONValid(s)}catch(e){onerror(e);return}s.jsonRows.push({});s.jsonPage=Math.floor((s.jsonRows.length-1)/100);setDirty(s);render()}),button('＋ Propriété',()=>{try{assertJSONValid(s)}catch(e){onerror(e);return}dialog('Ajouter une propriété','La propriété sera ajoutée aux colonnes du tableau.',card=>({name:field(card,'Nom',el('input',{required:'required'}))}),async v=>{const name=v.name.value;if(s.jsonKeys.includes(name))throw Error('Cette propriété existe déjà.');s.jsonKeys.push(name);setDirty(s);render()},'Ajouter')},''),el('span',{class:'psdata-spacer'}));const pages=Math.max(1,Math.ceil(s.jsonRows.length/100));s.jsonPage=Math.max(0,Math.min(s.jsonPage,pages-1));row.append(button('‹',()=>{try{assertJSONValid(s)}catch(e){onerror(e);return}s.jsonPage--;render()}),el('span',{class:'psdata-count'},`Page ${s.jsonPage+1} / ${pages}`),button('›',()=>{try{assertJSONValid(s)}catch(e){onerror(e);return}s.jsonPage++;render()}));surf.main.append(row,el('p',{class:'psdata-hint'},'Saisissez des valeurs JSON : "texte", 12, true, null, objets ou tableaux. Une cellule vide signifie propriété absente.'));
 const wrap=el('div',{class:'psdata-scroll'}),table=el('table',{class:'psdata-grid'}),thead=el('thead'),h=el('tr');h.append(el('th',{class:'rowctl'},'#'));for(const k of s.jsonKeys)h.append(el('th',{},k));thead.append(h);table.append(thead);const tb=el('tbody');for(let i=s.jsonPage*100;i<Math.min(s.jsonRows.length,(s.jsonPage+1)*100);i++){const tr=el('tr'),ctl=el('td',{class:'rowctl'});ctl.append(button('×',()=>{try{assertJSONValid(s)}catch(e){onerror(e);return}s.jsonRows.splice(i,1);setDirty(s);render()},'danger','Supprimer cet objet'));tr.append(ctl);for(const key of s.jsonKeys){const td=el('td'),input=el('input',{'aria-label':`Objet ${i+1}, ${key}`});const cellKey=JSON.stringify([i,key]);input.value=Object.hasOwn(s.jsonInvalidRaw,cellKey)?s.jsonInvalidRaw[cellKey]:(Object.prototype.hasOwnProperty.call(s.jsonRows[i],key)?JSON.stringify(s.jsonRows[i][key]):'');if(s.jsonErrors[cellKey])input.style.color='#ff9c9c';input.addEventListener('input',()=>{setDirty(s);try{if(!input.value.trim())delete s.jsonRows[i][key];else{checkJSONNumbers(input.value);const value=JSON.parse(input.value);Object.defineProperty(s.jsonRows[i],key,{value,configurable:true,writable:true,enumerable:true})}delete s.jsonErrors[cellKey];delete s.jsonInvalidRaw[cellKey];input.style.color=''}catch(e){s.jsonErrors[cellKey]=true;s.jsonInvalidRaw[cellKey]=input.value;input.style.color='#ff9c9c';status('Valeur JSON invalide ou imprécise dans « '+key+' ». Corrigez-la avant de continuer.',true)}});td.append(input);tr.append(td)}tb.append(tr)}table.append(tb);wrap.append(table);surf.main.append(wrap)}
function renderDB(s){surf.main.append(top(s,[button('Actualiser les tables',async()=>{try{s.tables=(await api('tables',{id:s.id})).tables;render()}catch(e){onerror(e)}})]));const split=el('div',{class:'psdata-table-split'}),list=el('div',{class:'psdata-tables'});list.append(el('h3',{class:'psdata-count'},'TABLES ET VUES'));for(const t of s.tables){const label=(t.schema?t.schema+'.':'')+t.name+(t.type==='view'?' · vue':'');list.append(button(label,()=>selectTable(s,t),s.table?.name===t.name&&s.table?.schema===t.schema?'active':'',label))}list.append(el('hr'),button('＋ Table…',()=>creerTable(s),'',peutCreerTable(s)?'Créer une table'+(estMiroir(s)?' (nouvelle feuille)':''):'Un document XML ne peut pas recevoir de nouvelle table'),button('⌘ Requête SQL',()=>{if(dirty(s)&&!confirm('Abandonner les modifications non enregistrées de la table ?'))return;s.pending={};s.inserts=[];s.table=null;s.mode='query';render()},s.mode==='query'?'active':''));const panel=el('div',{class:'psdata-table-panel'});split.append(list,panel);surf.main.append(split);if(s.mode==='query'){renderQuery(s,panel);return}if(!s.table){panel.append(el('div',{class:'psdata-empty'},'Choisissez une table ou une vue à gauche.'));return}renderDBGrid(s,panel)}
async function selectTable(s,t){if(dirty(s)&&!confirm('Abandonner les modifications non enregistrées de la table ?'))return;s.pending={};s.inserts=[];s.table=t;s.mode='table';s.offset=0;s.data=null;render();await loadRows(s)}
async function loadRows(s){try{status('Lecture de la table…');s.data=await api('rows',{id:s.id,schema:s.table.schema,table:s.table.name,offset:s.offset});render();status(s.data.editable?'Table prête à modifier.':(s.data.raison_lecture_seule?'Lecture seule : '+s.data.raison_lecture_seule:'Lecture seule : une clé primaire est nécessaire.'))}catch(e){onerror(e)}}
function record(s,index){return s.pending[index]||(s.pending[index]={original:s.data.rows[index],changes:{},delete:false})}
function updateCell(s,index,col){const c=s.data.columns[col],r=s.data.rows[index];if(c.pk||c.generated||!isScalar(r[col]))return;const item=s.pending[index],current=item&&Object.hasOwn(item.changes,c.name)?item.changes[c.name]:r[col];dialog('Modifier : '+c.name,'La modification sera mise en attente jusqu’à Enregistrer.',card=>{const type=field(card,'Type',select([['text','Texte'],['number','Nombre'],['boolean','Booléen'],['null','NULL']],kindOf(current)));const value=field(card,'Valeur',el('input',{value:current===null?'':String(current)}));type.addEventListener('change',()=>{value.disabled=type.value==='null';if(type.value==='boolean'&&!['true','false'].includes(value.value))value.value='true'});value.disabled=type.value==='null';return {type,value}},async v=>{const val=parseValue(v.type.value,v.value.value);const item=record(s,index);if(Object.is(val,r[col]))delete item.changes[c.name];else item.changes[c.name]=val;if(!item.delete&&!Object.keys(item.changes).length)delete s.pending[index];render();status('Modification en attente.')},'Appliquer')}
function insertDialog(s){dialog('Ajouter une ligne','Laissez « Défaut » pour utiliser la valeur par défaut de la base. L’insertion ne sera faite qu’après Enregistrer.',card=>{const entries=[];for(const c of s.data.columns){if(c.generated)continue;const row=el('div',{class:'psdata-insert-row'}),label=el('label',{title:c.type},c.name),type=select([['default','Défaut'],['text','Texte'],['number','Nombre'],['boolean','Booléen'],['null','NULL']],'default'),input=el('input',{placeholder:c.type||'Valeur'});input.disabled=true;type.addEventListener('change',()=>{input.disabled=['default','null'].includes(type.value);if(type.value==='boolean'&&!['true','false'].includes(input.value))input.value='true'});row.append(label,type,input);card.append(row);entries.push({c,type,input})}return entries},async entries=>{const data={};for(const x of entries)if(x.type.value!=='default')data[x.c.name]=parseValue(x.type.value,x.input.value);s.inserts.push({insert:data});render();status('Insertion en attente.')},'Ajouter')}
// ---------------------------------------------------------------------------
// Opérations de structure : créer et supprimer des tables et des colonnes.
//
// Les mêmes boutons pour tous les formats, et c'est le serveur qui dit ce que
// chaque format sait faire : une base reçoit CREATE TABLE / ALTER TABLE, un
// classeur reçoit une feuille, un document XML refuse d'en créer une et explique
// pourquoi. Un bouton qui n'existe que pour certains formats ferait croire que
// l'opération est impossible partout ailleurs.
// ---------------------------------------------------------------------------
const MIROIRS=['xlsx','ods','xml'];
const TYPES_SQL=[['TEXT','TEXT'],['INTEGER','INTEGER'],['REAL','REAL'],['NUMERIC','NUMERIC'],['BOOLEAN','BOOLÉEN'],['VARCHAR(255)','VARCHAR(255)'],['NUMERIC(10,2)','NUMERIC(10,2)'],['DATE','DATE'],['TIMESTAMP','TIMESTAMP'],['BLOB','BLOB']];
function estMiroir(s){return MIROIRS.includes(s.kind)}
function peutCreerTable(s){return s.kind!=='xml'}
function nomTable(s,t){return t?((t.schema?t.schema+'.':'')+t.name):''}
async function structure(s,payload){
 const r=await api('structure',Object.assign({id:s.id},payload));
 if(r.tables)s.tables=r.tables;
 if(r.revision)s.revision=r.revision;
 // Les modifications en attente portaient sur l'état d'avant : les garder
 // ferait envoyer des lignes originales périmées, donc des conflits en série.
 s.pending={};s.inserts=[];
 if(s.table&&!s.tables.some(t=>t.name===s.table.name&&(t.schema||'')===(s.table.schema||'')))s.table=null;
 render();
 if(s.table)await loadRows(s);
 // Dit APRÈS le rechargement : loadRows() écrit lui aussi dans le pied de page,
 // et l'annonce de ce qui vient d'être fait serait effacée avant d'être lue.
 status(r.instruction?String(r.instruction):'Opération effectuée.');
 return r}
async function structureDirecte(s,payload){try{await structure(s,payload)}catch(e){onerror(e)}}
function creerTable(s){
 if(!peutCreerTable(s)){status('Un document XML ne peut pas recevoir une nouvelle table : une table y est une famille d’éléments répétés, et rien ne dit où placer les nouveaux éléments. Ouvrez le fichier comme texte pour le faire.',true);return}
 const miroir=estMiroir(s);
 dialog('Créer une table',miroir?'Une feuille vide sera ajoutée au classeur et le fichier sera réécrit immédiatement.':'La table sera créée dans la base par une instruction CREATE TABLE, exécutée et validée immédiatement.',card=>{
  const name=field(card,'Nom de la table',el('input',{required:'required',value:miroir?'Nouvelle feuille':'nouvelle_table'}));
  card.append(el('p',{class:'psdata-hint'},miroir?'Un classeur n’a pas de types : les colonnes sont du texte, et les nombres reconnus à la saisie.':'Choisissez un type simple : TEXT, INTEGER, REAL, NUMERIC(10,2), VARCHAR(255), TIMESTAMP…'));
  const zone=el('div',{class:'psdata-colonnes'});card.append(zone);
  const colonnes=[];
  const ajouter=(nom)=>{
   const ligne=el('div',{class:'psdata-insert-row'}),champ=el('input',{value:nom||'',placeholder:'nom de la colonne'});
   ligne.append(el('label',{},'Colonne'),champ);
   let type=null;
   if(!miroir){type=select(TYPES_SQL,'TEXT');ligne.append(type)}
   const retirer=button('×',()=>{const i=colonnes.indexOf(entree);if(i>=0)colonnes.splice(i,1);ligne.remove()},'danger','Retirer cette colonne');
   ligne.append(retirer);zone.append(ligne);
   const entree={champ,type};colonnes.push(entree);
   return entree};
  ajouter('id');ajouter('');
  card.append(button('＋ Colonne',()=>ajouter('')));
  return {name,colonnes,ajouter}},
  async v=>{
   const nom=v.name.value.trim();
   if(!nom)throw Error('Donnez un nom à la table.');
   const colonnes=v.colonnes.map(c=>({name:c.champ.value.trim(),type:c.type?c.type.value:'TEXT'})).filter(c=>c.name);
   if(!colonnes.length)throw Error('Une table demande au moins une colonne.');
   if(miroir&&nom.length>31)throw Error('Un nom de feuille est limité à 31 caractères.');
   await structure(s,{action:'create_table',schema:s.table?s.table.schema:'',name:nom,columns:colonnes});},
  'Créer')}
function supprimerTable(s){
 const t=s.table;if(!t)return;
 const miroir=estMiroir(s);
 if(!confirm(`Supprimer la table « ${nomTable(s,t)} » ?\n\n${miroir?'La feuille sera retirée du classeur et le fichier sera réécrit.':'Un DROP TABLE sera exécuté et validé.'} Cette suppression est définitive : les données qu'elle contient seront perdues.`))return;
 structureDirecte(s,{action:'drop_table',schema:t.schema||'',name:t.name})}
function ajouterColonne(s){
 const t=s.table;if(!t)return;
 const miroir=estMiroir(s),xml=s.kind==='xml';
 dialog('Ajouter une colonne',miroir?'La colonne sera ajoutée à toutes les lignes existantes, puis le fichier sera réécrit.':'Un ALTER TABLE … ADD COLUMN sera exécuté et validé immédiatement.',card=>{
  const column=field(card,'Nom de la colonne',el('input',{required:'required',value:'nouvelle_colonne'}));
  let type=null,defaut=null,attribut=null;
  if(miroir){
   defaut=field(card,'Valeur pour les lignes existantes',el('input',{value:'',placeholder:'vide'}));
   if(xml)attribut=field(card,'Ranger la colonne dans',select([['enfant','un élément enfant'],['attribut','un attribut (@)']],'enfant'));
  }else{
   type=field(card,'Type',select(TYPES_SQL,'TEXT'));}
  return {column,type,defaut,attribut}},
  async v=>{
   const colonne=v.column.value.trim();
   if(!colonne)throw Error('Donnez un nom à la colonne.');
   const payload={action:'add_column',schema:t.schema||'',name:t.name,column:colonne};
   if(v.type)payload.type=v.type.value;
   if(v.defaut&&v.defaut.value!=='')payload.default=v.defaut.value;
   if(v.attribut)payload.attribut=v.attribut.value==='attribut';
   await structure(s,payload);},
  'Ajouter')}
function supprimerColonne(s){
 const t=s.table;if(!t||!s.data||!s.data.columns.length)return;
 if(s.data.columns.length<=1){status('Cette table n’a qu’une seule colonne : la supprimer la viderait. Supprimez la table entière.',true);return}
 dialog('Supprimer une colonne',estMiroir(s)?'La colonne sera retirée de toutes les lignes et le fichier sera réécrit. Les valeurs qu’elle contient seront perdues.':'Un ALTER TABLE … DROP COLUMN sera exécuté et validé. Les valeurs de cette colonne seront perdues.',
  card=>({column:field(card,'Colonne',select(s.data.columns.map(c=>[c.name,c.name+(c.pk?' 🔑':'')]),s.data.columns[s.data.columns.length-1].name))}),
  async v=>{await structure(s,{action:'drop_column',schema:t.schema||'',name:t.name,column:v.column.value})},
  'Supprimer')}
function decouperColonnes(texte){
 /* Une virgule sépare deux colonnes, SAUF à l'intérieur d'une précision de type :
  * NUMERIC(10,2) est un type. Découper sur toutes les virgules produirait une
  * colonne « 2) » et un type tronqué — du SQL invalide, écrit sans erreur. */
 const morceaux=[];let profondeur=0,courant='';
 for(const c of String(texte)){
  if(c==='(')profondeur++;
  else if(c===')')profondeur=Math.max(0,profondeur-1);
  if(c===','&&profondeur===0){morceaux.push(courant);courant='';continue}
  courant+=c}
 morceaux.push(courant);
 return morceaux.map(x=>x.trim()).filter(Boolean)}
// Un script .sql est du texte : les boutons ne peuvent pas y « exécuter » une
// instruction, ils la RÉDIGENT. Le dire évite de laisser croire que la base a
// changé alors que seul le fichier l'est.
function instructionSQL(s){
 const types=[['CREATE TABLE','CREATE TABLE'],['ALTER TABLE … ADD COLUMN','ADD COLUMN'],['ALTER TABLE … DROP COLUMN','DROP COLUMN'],['DROP TABLE','DROP TABLE']];
 dialog('Insérer une instruction','L’instruction sera ajoutée au script, à enregistrer ensuite. Rien n’est exécuté : un script SQL est du texte. Pour l’exécuter, utilisez « Charger dans une connexion ».',
  card=>{
   const quoi=field(card,'Instruction',select(types,'CREATE TABLE'));
   const table=field(card,'Table',el('input',{value:'nouvelle_table'}));
   const colonne=field(card,'Colonne',el('input',{value:'nouvelle_colonne'}));
   const type=field(card,'Type',select(TYPES_SQL,'TEXT'));
   const colonnes=field(card,'Colonnes (séparées par des virgules)',el('input',{value:'id INTEGER, nom TEXT'}));
   return {quoi,table,colonne,type,colonnes}},
  async v=>{
   const q=(x)=>'"'+String(x).replace(/"/g,'""')+'"';
   const table=v.table.value.trim(),colonne=v.colonne.value.trim();
   if(!table)throw Error('Donnez un nom de table.');
   let texte='';
   if(v.quoi.value==='CREATE TABLE'){
    const paires=decouperColonnes(v.colonnes.value);
    if(!paires.length)throw Error('Une table demande au moins une colonne.');
    const corps=paires.map(p=>{const m=p.split(/\s+/);return q(m[0])+' '+(m.slice(1).join(' ')||'TEXT')}).join(',\n  ');
    texte='CREATE TABLE '+q(table)+' (\n  '+corps+'\n);';
   }else if(v.quoi.value==='ADD COLUMN'){
    if(!colonne)throw Error('Donnez un nom de colonne.');
    texte='ALTER TABLE '+q(table)+' ADD COLUMN '+q(colonne)+' '+v.type.value+';';
   }else if(v.quoi.value==='DROP COLUMN'){
    if(!colonne)throw Error('Donnez un nom de colonne.');
    texte='ALTER TABLE '+q(table)+' DROP COLUMN '+q(colonne)+';';
   }else if(v.quoi.value==='DROP TABLE'){
    texte='DROP TABLE '+q(table)+';';
   }else{
    // Tomber sur DROP TABLE par défaut serait la pire des surprises : c'est la
    // seule instruction du lot qui détruit. Un choix non reconnu est refusé.
    throw Error('Choisissez l’instruction à rédiger.');}
   s.text=(s.text.trimEnd()?s.text.trimEnd()+'\n\n':'')+texte+'\n';
   setDirty(s);render();
   status('Instruction insérée dans le script — enregistrez pour l’écrire dans le fichier.');},
  'Insérer')}
async function saveDB(s){try{const edits=[...Object.values(s.pending).filter(x=>x.delete||Object.keys(x.changes).length),...s.inserts];if(!edits.length){status('Aucune modification en attente.');return}if(!confirm(`Enregistrer ${edits.length} modification(s) dans « ${s.table.name} » ? `+(estMiroir(s)?'Le fichier sera réécrit avec ces modifications ; les suppressions sont définitives.':'Les suppressions sont définitives et les déclencheurs SQL peuvent s’exécuter.')))return;const r=await api('apply',{id:s.id,schema:s.table.schema,table:s.table.name,edits});if(r.revision)s.revision=r.revision;s.pending={};s.inserts=[];await loadRows(s);status(`${r.changed} modification(s) enregistrée(s).`)}catch(e){onerror(e)}}
function renderDBGrid(s,panel){if(!s.data){panel.append(el('div',{class:'psdata-empty'},'Chargement…'));return}const d=s.data,row=el('div',{class:'psdata-toolrow'});row.append(el('strong',{},(s.table.schema?s.table.schema+'.':'')+s.table.name),el('span',{class:'psdata-badge'},d.editable?'Modifiable':'Lecture seule'),el('span',{class:'psdata-spacer'}));if(d.editable){row.append(button('＋ Ligne',()=>insertDialog(s)),button('＋ Colonne…',()=>ajouterColonne(s)),button('－ Colonne…',()=>supprimerColonne(s)),button('－ Table',()=>supprimerTable(s),'danger','Supprimer toute la table'),button('Enregistrer',()=>saveDB(s),'primary'))}row.append(button('‹',()=>pageDB(s,-1)),el('span',{class:'psdata-count'},`Lignes ${s.offset+1}–${s.offset+d.rows.length}`),button('›',()=>pageDB(s,1)));panel.append(row,el('p',{class:'psdata-hint'},d.editable?'Cliquez sur une cellule pour la modifier. Les clés primaires, valeurs complexes et colonnes générées sont en lecture seule. Les modifications concurrentes sont détectées.':(d.raison_lecture_seule?'Lecture seule : '+d.raison_lecture_seule:'Lecture seule : une table avec clé primaire est requise pour modifier les lignes.')));
 if(s.inserts.length)panel.append(el('p',{class:'psdata-hint'},`${s.inserts.length} insertion(s) en attente. Enregistrez ou changez de table pour les abandonner.`));const wrap=el('div',{class:'psdata-scroll'}),table=el('table',{class:'psdata-grid'}),thead=el('thead'),tr=el('tr');tr.append(el('th',{class:'rowctl'},'#'));for(const c of d.columns)tr.append(el('th',{title:c.type},c.name+(c.pk?' 🔑':'')));thead.append(tr);table.append(thead);const tb=el('tbody');d.rows.forEach((r,i)=>{const pending=s.pending[i],line=el('tr',{class:pending?.delete?'deleted':''}),ctl=el('td',{class:'rowctl'});const rowEditable=d.editable&&d.columns.every((c,j)=>!c.pk||isScalar(r[j]));if(rowEditable){ctl.append(button(pending?.delete?'↶':'×',()=>{const p=record(s,i);p.delete=!p.delete;if(!p.delete&&!Object.keys(p.changes).length)delete s.pending[i];render()},'danger',pending?.delete?'Annuler la suppression':'Marquer pour suppression'))}else ctl.textContent=String(s.offset+i+1);line.append(ctl);r.forEach((orig,j)=>{const c=d.columns[j],v=pending&&Object.hasOwn(pending.changes,c.name)?pending.changes[c.name]:orig,td=el('td'),cell=button(format(v),()=>updateCell(s,i,j),'psdata-cell'+(v===null?' null':'')+(pending&&Object.hasOwn(pending.changes,c.name)?' changed':''),`${c.name} · ${c.type||'valeur'}`);cell.disabled=!rowEditable||c.pk||c.generated||!isScalar(orig);td.append(cell);line.append(td)});tb.append(line)});table.append(tb);wrap.append(table);panel.append(wrap)}
async function pageDB(s,delta){if((delta<0&&s.offset===0)||(delta>0&&!s.data.more))return;if(dirty(s)&&!confirm('Abandonner les modifications non enregistrées avant de changer de page ?'))return;s.pending={};s.inserts=[];s.offset=Math.max(0,s.offset+100*delta);await loadRows(s)}
function renderQuery(s,panel){const row=el('div',{class:'psdata-toolrow'});row.append(el('strong',{},'Requête SQL'),el('span',{class:'psdata-spacer'}),button('Exécuter puis annuler si possible',()=>runQuery(s,false)),button('Exécuter et valider',()=>runQuery(s,true),'primary'));if(s.miroir)panel.append(el('p',{class:'psdata-warning'},'Copie de travail en mémoire : ce format n’a pas de moteur SQL. Les lectures s’exécutent sur un miroir SQLite reconstruit à chaque requête ; toute requête qui modifierait les données est refusée parce qu’elle n’écrirait rien dans le fichier. Créez, modifiez et supprimez avec les boutons de la grille, puis Enregistrer.'));
 panel.append(row,el('p',{class:'psdata-hint'},'Le mode « annuler » effectue un rollback si possible : certaines commandes DDL MySQL, fonctions ou effets externes peuvent rester irréversibles. Exécutez uniquement du SQL de confiance.'));const area=el('textarea',{class:'psdata-editor psdata-query','aria-label':'Requête SQL'});area.value=s.queryText;area.placeholder='SELECT * FROM …';area.addEventListener('input',()=>{s.queryText=area.value;s.queryDirty=true});panel.append(area);if(s.result&&s.result.erreur){panel.append(el('p',{class:'psdata-warning'},'Requête refusée — '+s.result.erreur))}else if(s.result){const r=s.result;panel.append(el('p',{class:'psdata-hint'},r.columns.length?`${r.rows.length} ligne(s) affichée(s)${r.more?' (résultats supplémentaires non affichés)':''}.`:`Lignes affectées : ${r.count}.`));if(r.columns.length){const wrap=el('div',{class:'psdata-scroll'}),table=el('table',{class:'psdata-grid'}),head=el('thead'),tr=el('tr');for(const c of r.columns)tr.append(el('th',{},c));head.append(tr);table.append(head);const tb=el('tbody');for(const vals of r.rows){const tr2=el('tr');for(const v of vals){const td=el('td');td.append(el('div',{class:'psdata-cell'},format(v)));tr2.append(td)}tb.append(tr2)}table.append(tb);wrap.append(table);panel.append(wrap)}}}
async function runQuery(s,commit){if(!s.queryText.trim()){status('Saisissez une requête SQL.',true);return}if(!confirm(commit?'Exécuter et valider cette requête ? Elle peut modifier ou supprimer des données.':'Exécuter cette requête ? Un rollback sera tenté, mais certaines opérations et effets externes sont irréversibles.'))return;try{status('Exécution de la requête…');s.result=await api('query',{id:s.id,sql:s.queryText,commit});render();status(commit?'Requête exécutée et validée.':'Requête exécutée ; rollback demandé.')}catch(e){const msg=e&&e.message?e.message:String(e);s.result={erreur:msg};render();onerror(e)}}
/* ================= 4.0.0 : les fichiers de données s'ouvrent dans un ONGLET =================
 *
 * L'application crée un élément vide `.ps-data-host` portant `data-path` dès
 * qu'un fichier de données devient l'onglet actif — exactement le mécanisme
 * déjà utilisé pour `.ps-document-host` (PDF et documents manuscrits) et
 * `.ps-ai-host` (assistant). Ce script observe le document, ouvre une session
 * serveur pour ce chemin, puis monte l'éditeur dans l'hôte.
 *
 * Ce qui reste dans la modale historique : les connexions PostgreSQL et MySQL,
 * qui n'ont aucun fichier à ouvrir en onglet, et le sélecteur de fichiers. Une
 * seule surface est active à la fois ; `surf` désigne celle qu'il faut dessiner.
 *
 * Les sessions sont conservées par chemin dans SESSIONS. L'application ne
 * demande aucune confirmation avant de fermer un onglet de données : garder la
 * session est la seule façon de ne pas perdre silencieusement des modifications
 * en attente — rouvrir le fichier les retrouve telles quelles.
 */
const SESSIONS=new Map();
let surfaceOnglet=null,surfaceModale=null,hoteActif=null,montageEnCours=false,observateur=null;

/* Un chemin virtuel commençant par « @ » n'est pas un fichier du projet :
 * l'application l'utilise pour ses propres onglets synthétiques et pour les
 * sources distantes non téléchargées. */
function cheminOnglet(hote){return hote&&hote.dataset?hote.dataset.path||'':''}

async function sessionPour(chemin){
 if(SESSIONS.has(chemin))return SESSIONS.get(chemin);
 const brut=await api('open',{path:chemin});
 const s={...brut,chemin,dirty:false,offset:0,tables:[],table:null,pending:{},inserts:[],queryText:'',result:null,firstHeader:true,csvPage:0,jsonMode:false};
 if(['sqlite','postgres','mysql','xlsx','ods','xml'].includes(s.kind)){
  const t=await api('tables',{id:s.id});
  s.tables=t.tables||[];
  if(t.miroir!==undefined)s.miroir=!!t.miroir;
 }
 SESSIONS.set(chemin,s);
 return s
}

function oublierSession(chemin){
 const s=SESSIONS.get(chemin);
 if(!s)return;
 SESSIONS.delete(chemin);
 api('close',{id:s.id}).catch(()=>{});
}

/* ---- Repli texte : un fichier annoncé comme base mais qui n'en est pas une ----
 * La session serveur a échoué, donc il n'y a ni `id` ni `revision` : on passe
 * par les routes générales de l'éditeur (/api/file et /api/save), celles-là
 * mêmes que Monaco utilise. Le fichier reste ainsi lisible ET modifiable au
 * lieu de se terminer en impasse. */
async function texteBrutLire(chemin){
 const r=await fetch('/api/file?path='+encodeURIComponent(chemin));
 let j=null;
 try{j=await r.json()}catch(e){j=null}
 if(!r.ok)throw Error(j&&j.error?j.error:'Le serveur n’a pas pu lire ce fichier (HTTP '+r.status+').');
 if(typeof j.content!=='string')throw Error('Ce fichier n’est pas du texte : il contient des octets non décodables en UTF-8.');
 return j.content
}

async function texteBrutEcrire(chemin,texte){
 const r=await fetch('/api/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({path:chemin,content:texte})});
 let j=null;
 try{j=await r.json()}catch(e){j=null}
 if(!r.ok)throw Error(j&&j.error?j.error:'Le serveur a refusé l’écriture (HTTP '+r.status+').');
 return j
}

function vueTexteBrut(s){
 surf.main.replaceChildren();
 const row=el('div',{class:'psdata-toolrow'});
 row.append(el('h2',{title:s.chemin||s.label||''},s.label||s.chemin||'Fichier'),
  el('span',{class:'psdata-badge'},'Texte'),
  el('span',{'data-dirty':''},s.dirty?'● Modifications non enregistrées':''),
  el('span',{class:'psdata-spacer'}),
  button('Enregistrer',async()=>{
   if(!s.dirty){status('Aucune modification à enregistrer.');return}
   if(!confirm('Enregistrer ce fichier comme texte ? Le contenu sera remplacé.'))return;
   try{status('Enregistrement…');await texteBrutEcrire(s.chemin,s.text);s.dirty=false;render();status('Fichier enregistré.')}catch(e){onerror(e)}
  },'primary','Écrire le texte dans le fichier'));
 surf.main.append(row);
 surf.main.append(el('p',{class:'psdata-warning'},s.raisonTexte||'Ce fichier n’est pas une base de données reconnue : il est édité comme texte brut.'));
 const area=el('textarea',{class:'psdata-editor psdata-texte','aria-label':'Contenu du fichier'});
 area.value=s.text||'';
 area.addEventListener('input',()=>{s.text=area.value;s.dirty=true;setDirty(s)});
 surf.main.append(area);
}

async function ouvrirCommeTexte(chemin,raison){
 const s=surfaceOnglet;
 if(!s)return;
 try{
  status('Lecture du fichier comme texte…');
  const texte=await texteBrutLire(chemin);
  if(hoteActif!==s.hote)return;
  s.texteSeul={chemin,label:chemin.split('/').pop(),text:texte,dirty:false,raisonTexte:raison};
  vueTexteBrut(s.texteSeul);
  status('Fichier ouvert comme texte brut.');
 }catch(e){
  onerror(e);
  surf.main.append(el('p',{class:'psdata-warning'},'Le contenu n’a pas pu être affiché : '+(e&&e.message?e.message:String(e))));
 }
}

/* ---- Montage de l'éditeur dans l'onglet ---- */
async function monterDansOnglet(hote){
 const chemin=cheminOnglet(hote);
 const s=surfaceVide();
 s.onglet=true;s.hote=hote;s.chemin=chemin;s.layer=hote;
 hoteActif=hote;
 activerSurface(s);
 surfaceOnglet=s;
 /* La modale des connexions ne doit pas rester par-dessus l'onglet : on la
  * détache sans fermer ses sessions, elle se reconstruira au prochain clic. */
 if(surfaceModale&&surfaceModale.layer&&surfaceModale.layer.isConnected)detacherModale();
 hote.replaceChildren();
 if(chemin.charAt(0)==='@'||!chemin){
  const boite=el('section',{class:'psdata-modal psdata-embed'});
  boite.innerHTML='<div class="psdata-body"><main class="psdata-main"></main></div><div class="psdata-footer" aria-live="polite"></div>';
  hote.append(boite);
  s.main=$('.psdata-main',hote);s.footer=$('.psdata-footer',hote);s.sidebar=null;
  s.main.append(el('div',{class:'psdata-empty'},
   chemin?'Cet onglet ne désigne pas un fichier du projet : « '+chemin+' » est un emplacement synthétique ou une source distante non téléchargée. Téléchargez d’abord le fichier pour l’éditer ici.'
         :'Aucun fichier n’est associé à cet onglet.'));
  status(chemin?'Emplacement non éditable comme base de données.':'Onglet de données vide.',true);
  return
 }
 const boite=el('section',{class:'psdata-modal psdata-embed'});
 boite.innerHTML='<div class="psdata-body"><main class="psdata-main"></main></div><div class="psdata-footer" aria-live="polite">Ouverture…</div>';
 hote.append(boite);
 s.main=$('.psdata-main',hote);
 s.footer=$('.psdata-footer',hote);
 s.sidebar=null;
 try{
  const src=await sessionPour(chemin);
  if(hoteActif!==hote)return;                    // l'onglet a changé pendant l'attente
  s.sources=[src];s.selected=src.id;
  render();
  if(src.miroir)status('Copie de travail en mémoire — utilisez Enregistrer pour écrire dans « '+src.label+' ».');
  else status('Source ouverte : '+src.label);
 }catch(e){
  if(hoteActif!==hote)return;
  const msg=e&&e.message?e.message:String(e);
  s.main.replaceChildren();
  const vide=el('div',{class:'psdata-empty'});
  vide.append(el('h2',{},'Ce fichier n’a pas pu être ouvert comme base de données'),
   el('p',{class:'psdata-warning'},msg),
   el('p',{},'Il reste consultable et modifiable comme texte brut.'),
   button('Ouvrir comme texte',()=>ouvrirCommeTexte(chemin,msg),'primary','Afficher et modifier le contenu brut du fichier'));
  s.main.append(vide);
  status(msg,true);
 }
}

function detacherModale(){
 if(!surfaceModale)return;
 if(surfaceModale.layer)surfaceModale.layer.remove();
 surfaceModale.layer=null;
 body=null;sub=null;
}

function fermerModale(){
 detacherModale();
 activerSurface(surfaceOnglet&&surfaceOnglet.hote&&surfaceOnglet.hote.isConnected?surfaceOnglet:surfaceVide());
 if(surf.layer&&surf.layer.isConnected)render();
 if(lastFocused&&lastFocused.isConnected)lastFocused.focus();
}

/* L'observateur se déclenche sur toutes les mutations du document, y compris
 * celles que ce script provoque lui-même : sans garde de réentrance il
 * rebouclerait indéfiniment. `takeRecords()` jette en plus les notifications
 * déjà en file pour le montage en cours. */
function synchroniserOnglets(){
 if(montageEnCours)return;
 const hote=document.querySelector('.ps-data-host');
 if(!hote){
  if(hoteActif){
   hoteActif=null;
   if(surf&&surf.onglet)activerSurface(surfaceModale&&surfaceModale.layer?surfaceModale:surfaceVide());
  }
  return
 }
 const chemin=cheminOnglet(hote);
 if(hoteActif===hote&&surfaceOnglet&&surfaceOnglet.chemin===chemin&&surfaceOnglet.layer&&hote.firstChild)return;
 montageEnCours=true;
 if(observateur){try{observateur.takeRecords()}catch(e){}}
 try{
  const p=monterDansOnglet(hote);
  if(p&&typeof p.then==='function')p.catch(e=>{onerror(e)}).then(()=>{montageEnCours=false});
  else montageEnCours=false;
 }catch(e){
  montageEnCours=false;
  onerror(e);
 }
}

function suivreHote(selecteur,rappel){
 /* Un seul observateur pour toute l'application : cinq observateurs sur
  * document.documentElement plus cinq sondes à 2 s saturaient le fil
  * principal, et un bouton latéral mettait plusieurs secondes à agir. */
 const arret={disconnect:function(){},takeRecords:function(){return [];}};
 if(window.PSHotes&&window.PSHotes.suivre){arret.disconnect=window.PSHotes.suivre(selecteur,rappel);return arret;}
 if(typeof MutationObserver!=='function'){if(typeof setInterval==='function'){const s=setInterval(rappel,5000);arret.disconnect=function(){clearInterval(s);};}return arret;}
 const o=new MutationObserver(rappel);
 o.observe(document.documentElement,{subtree:true,childList:true});
 const f=typeof setInterval==='function'?setInterval(rappel,5000):null;
 arret.disconnect=function(){o.disconnect();if(f)clearInterval(f);};
 return arret;
}
function observerOnglets(){
 if(observateur)return;
 observateur=suivreHote('.ps-document-host',synchroniserOnglets);
}

/* Ouvre un fichier de données dans son propre onglet. `PSFMActivate` est le
 * crochet que l'application expose déjà au gestionnaire de fichiers : il crée
 * l'onglet s'il n'existe pas et l'active dans tous les cas. Le contenu est
 * laissé vide — c'est ce script qui le charge, octet par octet si nécessaire,
 * ce qu'un éditeur de texte ne pourrait pas faire. */
function ouvrirDansOnglet(chemin){
 if(typeof window.PSFMActivate!=='function'){
  status('Cette interface n’expose pas l’ouverture en onglet ; le fichier reste éditable dans ce panneau.',true);
  return false
 }
 window.PSFMActivate({path:chemin,content:''});
 fermerModale();
 return true
}
function attach(){
 const bar=$('.activitybar');
 if(bar&&!bar.querySelector('.psdata-launch')){
  const b=el('button',{class:'psdata-launch',title:'Données et bases SQL','aria-label':'Données et bases SQL'});
  b.innerHTML=icon;b.addEventListener('click',openPanel);bar.append(b)
 }
 observerOnglets();
 synchroniserOnglets();
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',attach,{once:true});else attach();if(window.PSHotes)suivreHote('.ps-data-host',attach);else if(typeof setInterval==='function')setInterval(attach,5000);
})();
