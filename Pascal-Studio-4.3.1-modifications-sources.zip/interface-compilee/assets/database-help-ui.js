/* Interface contextuelle de l’aide, partageant le catalogue avec l’aide des langages. */
(()=>{'use strict';
const $=(t,cls,text)=>{const n=document.createElement(t);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
const normalize=s=>s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
window.PSOpenDbHelp=function(initial){
 const original=window.PS_DB_HELP;if(!original)return;const data={...original,articles:[...original.articles,...(window.PS_EXTRA_HELP?.articles||[]).filter(a=>original.languages.includes(a.lang))]};
 if(document.querySelector('.dbhelp-overlay'))return;
 const focus=document.activeElement,overlay=$('div','dbhelp-overlay');
 const panel=$('section','dbhelp-panel');panel.setAttribute('role','dialog');panel.setAttribute('aria-modal','true');panel.setAttribute('aria-label','Aide des données et bases SQL');
 const head=$('header','dbhelp-header'),heading=$('div');heading.append($('small','', 'RÉFÉRENCE HORS LIGNE'),$('h1','','Aide des données et bases SQL'));
 const close=$('button','','Fermer ✕');close.type='button';close.setAttribute('aria-label','Fermer l’aide');const onKey=e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();close.click()}};close.addEventListener('click',()=>{document.removeEventListener('keydown',onKey,true);overlay.remove();if(focus?.isConnected)focus.focus()});document.addEventListener('keydown',onKey,true);head.append(heading,close);
 const languages=$('div','dbhelp-languages');languages.setAttribute('aria-label','Domaines de l’aide');
 const layout=$('div','dbhelp-layout'),nav=$('nav','dbhelp-nav');nav.setAttribute('aria-label','Sommaire de l’aide');const searchLabel=$('label','','Rechercher dans cette rubrique'),search=$('input');search.type='search';search.placeholder='Ex. clé primaire, date, json…';search.setAttribute('aria-label','Rechercher dans cette rubrique');searchLabel.append(search);const index=$('div','dbhelp-index');nav.append(searchLabel,index);
 const article=$('article','dbhelp-article');article.tabIndex=-1;layout.append(nav,article);panel.append(head,languages,layout);overlay.append(panel);document.body.append(overlay);
 let lang=data.languages.includes(initial)?initial:data.languages[0],id=null,expanded=new Set();
 function chooseLanguage(l){lang=l;search.value='';expanded=new Set(['Introduction']);id=(data.articles.find(a=>a.lang===lang&&a.intro)||data.articles.find(a=>a.lang===lang)).id;render()}
 function render(){
  languages.replaceChildren();for(const name of data.languages){const b=$('button',name===lang?'selected':'',name);b.type='button';b.setAttribute('aria-pressed',name===lang?'true':'false');b.addEventListener('click',()=>chooseLanguage(name));languages.append(b)}
  const query=normalize(search.value.trim()),list=data.articles.filter(a=>a.lang===lang&&(!query||normalize(JSON.stringify(a)).includes(query))),groups=[...new Set(list.map(a=>a.group))];index.replaceChildren();
  if(!groups.length)index.append($('p','dbhelp-empty','Aucun résultat.'));
  for(const g of groups){const details=$('details','dbhelp-group');details.open=!!query||expanded.has(g);details.addEventListener('toggle',()=>{if(!search.value.trim()){if(details.open)expanded.add(g);else expanded.delete(g)}});const members=list.filter(a=>a.group===g);details.append($('summary','',g+' ('+members.length+')'));for(const a of members){const b=$('button',a.id===id?'selected':'',a.title);b.type='button';b.addEventListener('click',()=>{id=a.id;render();article.scrollTop=0;article.focus({preventScroll:true})});details.append(b)}index.append(details)}
  const a=data.articles.find(x=>x.id===id&&x.lang===lang)||data.articles.find(x=>x.lang===lang);article.replaceChildren();article.append($('div','dbhelp-breadcrumb',lang+' › '+a.group),$('h2','',a.title));
  if(a.intro){for(const p of a.blocks[0].text.split('\n\n'))article.append($('p','',p))}
  else {for(const b of a.blocks){const section=$('section');section.append($('h3','',b.title));for(const p of b.text.split('\n'))if(p)section.append($('p','',p));if(b.code){const pre=$('pre'),code=$('code','',b.code);pre.append(code);section.append(pre)}article.append(section)}}
  article.append($('footer','','Référence pratique hors ligne · Vérifiez la version du moteur et sauvegardez vos données.'));
 }
 search.addEventListener('input',render);
 chooseLanguage(lang);search.focus();
};
})();
