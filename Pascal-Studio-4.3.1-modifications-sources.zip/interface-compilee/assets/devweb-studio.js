/* Panneau dev web de Pascal Studio (4.0.0).
 *
 * Un seul panneau, sept sections, parce que le travail de développement web est
 * une boucle et non une suite d'outils séparés : on écrit, on aperçoit, on lit
 * la console, on audite, on corrige, on génère ce qui manque. Chacune de ces
 * étapes est une section de la barre latérale ; ce qui est lourd à lire
 * (résultats d'audit, fichier généré, corps d'une réponse HTTP) s'ouvre dans
 * une fenêtre flottante, déplaçable et redimensionnable, au-dessus de l'éditeur
 * — jamais à sa place : on corrige du code en regardant le diagnostic.
 *
 * Ce que ce panneau NE FAIT PAS, et pourquoi :
 *   - il n'écrit aucun fichier sans que l'utilisateur ait écrit un nom de
 *     fichier et validé ; un fichier généré est d'abord du texte à copier ;
 *   - il ne contacte aucune adresse distante sauf sur demande explicite
 *     (section Requêtes, ou l'option « vérifier les liens distants » de
 *     l'audit) ;
 *   - il ne devine pas : quand une information manque (aperçu non démarré,
 *     aucun fichier HTML dans le projet, journal vide en mode PHP), il le dit
 *     dans la zone d'état plutôt que de laisser une zone blanche.
 *
 * Aucune ressource externe : pas de police distante, pas d'icône en image, pas
 * de CDN. Les icônes sont des SVG en ligne.
 */
(() => {
'use strict';

const API = '/api/devweb';
const HOTE = '.ps-devweb-host';
/* 4.3.0 : le panneau passe devant les fichiers ouverts, comme la
 * rétro-ingénierie. Même mécanisme, mêmes garanties. */
const ID_VUE = 'devweb';
const TITRE_VUE = 'Dev web';
const ICONE_VUE = '</>';
const MAX_JOURNAL_AFFICHE = 400;
const SONDE_JOURNAL = 1200;          // ms entre deux lectures du journal
const RETARD_RECHERCHE = 350;        // anti-rebond des champs de recherche
const CLE_GEOMETRIE = 'ps-devweb-fenetre';
const LARGEUR_MIN = 360;             // en dessous, un rapport n'est plus lisible
const HAUTEUR_MIN = 220;

/* ------------------------------------------------------------------- DOM ---- */
const $ = (sel, base) => (base || document).querySelector(sel);
const $$ = (sel, base) => Array.from((base || document).querySelectorAll(sel));

/* el(tag, attributs, ...enfants) — TOUS les arguments après le deuxième sont
 * des enfants. Une version précédente d'un script hôte de ce projet ignorait
 * silencieusement le quatrième argument et au-delà : le rendu était incomplet
 * sans qu'aucune erreur n'apparaisse nulle part. */
function el(tag, attrs) {
  const noeud = document.createElement(tag);
  const proprietes = attrs || {};
  Object.keys(proprietes).forEach(cle => {
    const valeur = proprietes[cle];
    if (valeur === null || valeur === undefined || valeur === false) return;
    if (cle === 'class') noeud.className = valeur;
    else if (cle === 'text') noeud.textContent = String(valeur);
    else if (cle === 'html') noeud.innerHTML = String(valeur);
    else if (cle.slice(0, 2) === 'on' && typeof valeur === 'function') {
      noeud.addEventListener(cle.slice(2).toLowerCase(), valeur);
    } else if (valeur === true) noeud.setAttribute(cle, '');
    else noeud.setAttribute(cle, String(valeur));
  });
  for (let i = 2; i < arguments.length; i++) ajouter(noeud, arguments[i]);
  return noeud;
}

function ajouter(parent, valeur) {
  if (valeur === null || valeur === undefined || valeur === false) return parent;
  if (Array.isArray(valeur)) { valeur.forEach(v => ajouter(parent, v)); return parent; }
  /* Un nœud se reconnaît à nodeType OU à la présence d'appendChild : se fier au
   * seul nodeType transformerait silencieusement chaque élément en texte
   * (« [object Object] ») dans un DOM qui ne l'expose pas. Même précaution que
   * dans navigateur-studio.js. */
  const estNoeud = valeur && (valeur.nodeType || typeof valeur.appendChild === 'function');
  parent.append(estNoeud ? valeur : document.createTextNode(String(valeur)));
  return parent;
}

function vider(noeud) { if (noeud) noeud.replaceChildren(); return noeud; }

function bouton(titre, action, classe, infobulle) {
  return el('button', {
    type: 'button', class: 'psdw-btn' + (classe ? ' ' + classe : ''),
    title: infobulle || titre, 'aria-label': infobulle || titre, onClick: action,
  }, titre);
}

function icone(chemin, taille) {
  const s = taille || 16;
  return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s +
    '" fill="none" stroke="currentColor" stroke-width="1.7" ' +
    'stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
    chemin + '</svg>';
}

const ICONES = {
  apercu: '<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M3 9h18M8 21h8"/>',
  journal: '<path d="M4 6h16M4 12h16M4 18h10"/>',
  audit: '<path d="M9 11l3 3 5-6"/><path d="M20 12v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h9"/>',
  generer: '<path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5L18 18M18 6l-2.5 2.5M8.5 15.5L6 18"/>',
  extrait: '<path d="M8 6l-5 6 5 6M16 6l5 6-5 6"/>',
  requete: '<path d="M4 12h16M14 6l6 6-6 6"/>',
  projet: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  fermer: '<path d="M6 6l12 12M18 6L6 18"/>',
  jouer: '<path d="M7 4l12 8-12 8z"/>',
  arreter: '<rect x="6" y="6" width="12" height="12" rx="1"/>',
  copie: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',
  vider: '<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/>',
  agrandir: '<path d="M4 9V4h5M20 15v5h-5M15 4h5v5M9 20H4v-5"/>',
};

/* ------------------------------------------------------------------ état ---- */
let capacites = null;
let hote = null;
let ouvert = {};                       // section -> bool
let apercu = null;                     // {url, mode, port, root, path}
let viewport = null;                   // identifiant du viewport choisi
let depuis = 0;                        // identifiant de la dernière entrée lue
let entrees = [];
let filtreJournal = 'tous';
let dernierAudit = null;
let fichiers = [];                     // aplati de /api/tree
let minuteurs = {};
let fenetre = null;
let statutTexte = '';

function differe(nom, fn, delai) {
  if (minuteurs[nom]) clearTimeout(minuteurs[nom]);
  minuteurs[nom] = setTimeout(() => { delete minuteurs[nom]; fn(); },
                              delai === undefined ? RETARD_RECHERCHE : delai);
}

/* --------------------------------------------------------------- serveur ---- */
/* Toute réponse du serveur porte soit un contenu utile, soit `error` (routes
 * historiques de server.py), soit `erreur` (modules devweb), soit `ok:false`.
 * Ignorer l'un de ces trois champs ferait afficher « réussi » sur un échec :
 * c'est un défaut déjà rencontré dans ce projet, et il est invisible à l'œil
 * puisque la zone de résultat reste simplement vide. */
async function api(action, champs) {
  const reponse = await fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.assign({ action: action }, champs || {})),
  });
  let donnees = null;
  try { donnees = await reponse.json(); } catch (e) { donnees = null; }
  if (!reponse.ok) {
    const raison = (donnees && (donnees.error || donnees.erreur)) ||
      ('HTTP ' + reponse.status);
    throw new Error(raison);
  }
  if (donnees && donnees.error) throw new Error(donnees.error);
  if (donnees && donnees.erreur && donnees.ok !== true) throw new Error(donnees.erreur);
  return donnees || {};
}

async function getApi(chemin) {
  const reponse = await fetch(chemin);
  let donnees = null;
  try { donnees = await reponse.json(); } catch (e) { donnees = null; }
  if (!reponse.ok) {
    /* Le corps d'une réponse d'erreur porte la RAISON : s'en tenir au code
     * afficherait « HTTP 500 sur /api/devweb » là où le serveur dit « les
     * modules devweb sont absents ». C'est exactement l'information qui permet
     * à l'utilisateur de réparer. */
    const raison = (donnees && (donnees.error || donnees.erreur)) ||
      ('HTTP ' + reponse.status + ' sur ' + chemin);
    throw new Error(raison);
  }
  return donnees || {};
}

async function lireCapacites() {
  if (capacites) return capacites;
  capacites = await getApi(API);
  /* Un tableau VIDE faisait lever ici (« Cannot read properties of undefined
   * (reading 'id') ») : `find()` rend undefined, `[6]` et `[0]` aussi. Le
   * panneau affichait alors son message d'indisponibilité alors que le serveur
   * répondait très bien — une panne inventée par le client. */
  const vues = (capacites && capacites.viewports) || [];
  const preferee = vues.find(function (v) { return v && v.id === 'portable'; }) ||
    vues[6] || vues[0];
  viewport = viewport || (preferee && preferee.id) || '';
  return capacites;
}

function statut(message, niveau) {
  statutTexte = message || '';
  const zone = $('.psdw-statut', hote);
  if (!zone) return;
  zone.textContent = statutTexte;
  zone.className = 'psdw-statut' + (niveau ? ' psdw-' + niveau : '');
}

function erreur(e) {
  statut(e && e.message ? e.message : String(e), 'erreur');
}

function agir(fn, message) {
  return Promise.resolve().then(fn).then(r => { if (message) statut(message); return r; })
    .catch(erreur);
}

/* ------------------------------------------------- fenêtre flottante -------- */
/* La géométrie est conservée dans localStorage, et c'est le seul état du
 * panneau qui le soit : une taille de fenêtre préférée n'est pas une donnée
 * utilisateur (contrairement aux signets du navigateur, eux gardés côté
 * serveur), et sa perte ne coûte qu'un redimensionnement. L'accès est protégé
 * parce que localStorage LÈVE quand le stockage du site est bloqué. */
function lireGeometrie() {
  try {
    const brut = localStorage.getItem(CLE_GEOMETRIE);
    if (!brut) return null;
    const g = JSON.parse(brut);
    return (g && typeof g.largeur === 'number' && typeof g.hauteur === 'number') ? g : null;
  } catch (e) { return null; }
}

function ecrireGeometrie(g) {
  try { localStorage.setItem(CLE_GEOMETRIE, JSON.stringify(g)); } catch (e) { /* ignoré */ }
}

function ouvrirFenetre(titre, construit) {
  if (!fenetre || !fenetre.isConnected) {
    fenetre = el('div', { class: 'psdw-fenetre', role: 'dialog',
      'aria-label': titre });
    const geometrie = lireGeometrie();
    if (geometrie) {
      fenetre.style.width = geometrie.largeur + 'px';
      fenetre.style.height = geometrie.hauteur + 'px';
      if (geometrie.gauche !== undefined) fenetre.style.left = geometrie.gauche + 'px';
      if (geometrie.haut !== undefined) fenetre.style.top = geometrie.haut + 'px';
    }
    document.body.append(fenetre);
  }
  vider(fenetre);
  const barre = el('div', { class: 'psdw-barre' },
    el('span', { class: 'psdw-logo', html: icone(ICONES.audit, 14) }),
    el('strong', { text: titre }),
    el('span', { class: 'psdw-pousse' }),
    bouton('', () => basculerPlein(), 'psdw-ic', 'Agrandir ou réduire'),
    bouton('', () => fermerFenetre(), 'psdw-ic', 'Fermer la fenêtre'));
  barre.querySelector('.psdw-btn').innerHTML = icone(ICONES.agrandir, 14);
  barre.querySelectorAll('.psdw-btn')[1].innerHTML = icone(ICONES.fermer, 14);
  const corps = el('div', { class: 'psdw-corps' });
  fenetre.append(barre, corps);
  /* Poignée de déplacement et poignées de redimensionnement sont réinstallées à
   * CHAQUE ouverture : vider() supprime les enfants de la fenêtre, donc les
   * installer une seule fois à la création laissait une fenêtre qu'on ne pouvait
   * plus redimensionner dès le second contenu affiché. Les nœuds étant neufs à
   * chaque fois, aucun écouteur ne s'accumule. */
  rendreDeplacable(fenetre);
  rendreRedimensionnable(fenetre);
  if (construit) construit(corps);
  return corps;
}

function basculerPlein() {
  if (!fenetre) return;
  fenetre.classList.toggle('psdw-plein');
  ecrireGeometrie(geometrieCourante());
}

function fermerFenetre() {
  if (!fenetre) return;
  ecrireGeometrie(geometrieCourante());
  fenetre.remove();
  fenetre = null;
}

function geometrieCourante() {
  if (!fenetre) return null;
  const cadre = fenetre.getBoundingClientRect();
  return { gauche: Math.round(cadre.left), haut: Math.round(cadre.top),
    largeur: Math.round(cadre.width), hauteur: Math.round(cadre.height) };
}

/* Le déplacement est RELATIF au pointeur : exiger une coordonnée absolue
 * ferait sauter la fenêtre au coin du curseur dès le premier mouvement. */
/* 4.3.1 : une fenêtre déléguée à un onglet ne se déplace plus — la zone des vues
 * possède la géométrie du noeud qu'on lui confie. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function rendreDeplacable(panneau) {
  const poignee = $('.psdw-barre', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(panneau)) return;
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psdw-plein')) return;
    const depart = panneau.getBoundingClientRect();
    const dx = ev.clientX - depart.left, dy = ev.clientY - depart.top;
    const bouger = e => {
      panneau.style.left = Math.max(0, Math.min(window.innerWidth - 120,
        e.clientX - dx)) + 'px';
      panneau.style.top = Math.max(0, Math.min(window.innerHeight - 40,
        e.clientY - dy)) + 'px';
      panneau.style.right = 'auto';
      panneau.style.bottom = 'auto';
    };
    const finir = () => {
      window.removeEventListener('pointermove', bouger);
      window.removeEventListener('pointerup', finir);
      ecrireGeometrie(geometrieCourante());
    };
    window.addEventListener('pointermove', bouger);
    window.addEventListener('pointerup', finir);
    ev.preventDefault();
  });
}

function rendreRedimensionnable(panneau) {
  /* Le point de départ est la POSITION DU POINTEUR au moment de l'appui, pas le
   * coin de la fenêtre : partir du coin ferait sauter la largeur de la valeur de
   * `left` dès le premier mouvement (et doublerait la taille d'une fenêtre déjà
   * déplacée). Même modèle que le panneau navigateur, avec les cinq côtés. */
  for (const cote of ['e', 's', 'se', 'w', 'n']) {
    const poignee = el('div', { class: 'psdw-poignee psdw-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (dansUneColonne(panneau)) return;
      if (panneau.classList.contains('psdw-plein')) return;
      const cadre = panneau.getBoundingClientRect();
      const depart = { x: ev.clientX, y: ev.clientY, gauche: cadre.left,
        haut: cadre.top, largeur: cadre.width, hauteur: cadre.height };
      const bouger = e => {
        const dx = e.clientX - depart.x, dy = e.clientY - depart.y;
        if (cote.indexOf('e') >= 0) {
          panneau.style.width = Math.max(LARGEUR_MIN,
            Math.min(window.innerWidth - 20, depart.largeur + dx)) + 'px';
        }
        if (cote.indexOf('s') >= 0) {
          panneau.style.height = Math.max(HAUTEUR_MIN,
            Math.min(window.innerHeight - 20, depart.hauteur + dy)) + 'px';
        }
        if (cote.indexOf('w') >= 0) {
          const largeur = Math.max(LARGEUR_MIN, depart.largeur - dx);
          panneau.style.width = largeur + 'px';
          panneau.style.left = (depart.gauche + depart.largeur - largeur) + 'px';
        }
        if (cote === 'n') {
          const hauteur = Math.max(HAUTEUR_MIN, depart.hauteur - dy);
          panneau.style.height = hauteur + 'px';
          panneau.style.top = (depart.haut + depart.hauteur - hauteur) + 'px';
        }
      };
      const lacher = () => {
        window.removeEventListener('pointermove', bouger);
        window.removeEventListener('pointerup', lacher);
        ecrireGeometrie(geometrieCourante());
      };
      window.addEventListener('pointermove', bouger);
      window.addEventListener('pointerup', lacher);
      ev.preventDefault();
      ev.stopPropagation();
    });
    panneau.append(poignee);
  }
}

/* ----------------------------------------------------------------- aperçu --- */
function urlApercu() { return apercu ? apercu.url : ''; }

async function demarrerApercu(chemin) {
  if (!chemin) { statut('Choisissez d’abord un fichier à apercevoir.', 'erreur'); return; }
  const mode = /\.php$/i.test(chemin) ? 'php' : 'static';
  const info = await api2('/api/web/start', { path: chemin, mode: mode });
  apercu = info;
  depuis = 0; entrees = [];
  statut('Aperçu démarré : ' + info.url + (mode === 'php'
    ? ' — en mode PHP le script de capture n’est pas injecté, le journal restera vide.'
    : ''), mode === 'php' ? 'avertissement' : 'ok');
  rendreSection('apercu');
  if (ouvert.journal) sonderJournal();
}

/* Les routes de l'aperçu ne sont pas /api/devweb : un second appel est
 * nécessaire, et il doit dire lequel a échoué. */
async function api2(action, champs) {
  const reponse = await fetch(action, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(champs || {}),
  });
  let donnees = null;
  try { donnees = await reponse.json(); } catch (e) { donnees = null; }
  if (!reponse.ok) {
    throw new Error((donnees && (donnees.error || donnees.erreur)) ||
      ('HTTP ' + reponse.status + ' sur ' + action));
  }
  if (donnees && donnees.error) throw new Error(donnees.error);
  return donnees || {};
}

async function arreterApercu() {
  await api2('/api/web/stop', {});
  apercu = null;
  statut('Aperçu arrêté.');
  rendreSection('apercu');
}

function ouvrirFenetreApercu() {
  if (!apercu) { statut('Démarrez d’abord l’aperçu.', 'erreur'); return; }
  const vp = (capacites && capacites.viewports || []).find(v => v.id === viewport);
  const corps = ouvrirFenetre('Aperçu — ' + (apercu.path || ''), c => {
    const barre = el('div', { class: 'psdw-sousbarre' },
      el('span', { class: 'psdw-url', text: apercu.url }),
      el('span', { class: 'psdw-pousse' }),
      el('label', { class: 'psdw-champ-mini' }, 'Viewport ',
        construireSelecteurViewport(() => {
          appliquerViewport();
        })),
      bouton('Recharger', () => {
        const cadre = $('#psdw-cadre', c);
        if (cadre) cadre.src = apercu.url;
      }),
      bouton('Ouvrir dans le navigateur', () => {
        if (window.PSNavigateur && window.PSNavigateur.ouvrir) {
          window.PSNavigateur.ouvrir();
          setTimeout(() => window.PSNavigateur.naviguer(apercu.url), 400);
        } else window.open(apercu.url, '_blank', 'noopener');
      }));
    const zone = el('div', { class: 'psdw-cadre-zone' });
    const cadre = el('iframe', {
      id: 'psdw-cadre', class: 'psdw-cadre', src: apercu.url,
      sandbox: 'allow-scripts allow-same-origin allow-forms allow-popups-to-escape-sandbox',
      referrerpolicy: 'no-referrer', title: 'Aperçu du projet',
    });
    zone.append(cadre);
    c.append(barre, zone);
    appliquerViewport();
  });
  return corps;
}

function construireSelecteurViewport(changement) {
  const select = el('select', { class: 'psdw-select',
    onChange: ev => { viewport = ev.target.value; if (changement) changement(); } });
  /* Les groupes sont tenus dans un objet plutôt que retrouvés par un sélecteur
   * d'attribut : un sélecteur que l'hôte DOM de test ne sait pas résoudre ne
   * renverrait rien, et les viewports seraient tous à plat sans message. */
  const groupes = {};
  ((capacites && capacites.viewports) || []).forEach(v => {
    const nom = v.categorie || 'autre';
    if (!groupes[nom]) {
      groupes[nom] = el('optgroup', { label: nom });
      select.append(groupes[nom]);
    }
    groupes[nom].append(el('option', {
      value: v.id, text: v.nom + ' — ' + v.largeur + '×' + v.hauteur,
      selected: v.id === viewport }));
  });
  if (viewport) select.value = viewport;
  return select;
}

/* Le viewport change la taille du CADRE, pas celle de la fenêtre : c'est la
 * largeur disponible pour la page qui doit correspondre à l'appareil choisi,
 * sinon on mesure une mise en page qui n'est celle d'aucun appareil réel. */
function appliquerViewport() {
  if (!fenetre) return;
  const cadre = $('#psdw-cadre', fenetre);
  const zone = $('.psdw-cadre-zone', fenetre);
  if (!cadre || !zone) return;
  const vp = ((capacites && capacites.viewports) || []).find(v => v.id === viewport);
  if (!vp) { cadre.style.width = '100%'; return; }
  cadre.style.width = vp.largeur + 'px';
  cadre.style.height = vp.hauteur + 'px';
  cadre.setAttribute('data-dpr', String(vp.dpr || 1));
  zone.classList.add('psdw-cadre-centre');
  const etiquette = $('.psdw-vp-etiquette', fenetre);
  if (etiquette) etiquette.textContent = vp.nom + ' · ' + vp.largeur + '×' + vp.hauteur +
    ' · dpr ' + (vp.dpr || 1);
}

/* ----------------------------------------------------------------- journal -- */
async function sonderJournal() {
  try {
    const r = await api('journal', { depuis: depuis, limite: 200 });
    if (r && Array.isArray(r.entrees) && r.entrees.length) {
      entrees = entrees.concat(r.entrees);
      if (entrees.length > MAX_JOURNAL_AFFICHE) entrees = entrees.slice(-MAX_JOURNAL_AFFICHE);
      depuis = r.suivant || depuis;
      rendreSection('journal');
    } else if (r && typeof r.suivant === 'number') depuis = r.suivant;
    const badge = $('.psdw-badge-journal', hote);
    if (badge) badge.textContent = String((r && r.total) || entrees.length);
  } catch (e) { /* le panneau continue : une sonde en échec n'est pas une faute
                   de la page aperçue, et noyer l'utilisateur d'erreurs de sonde
                   masquerait les vraies */ }
}

function demarrerSonde() {
  if (minuteurs.sonde) return;
  minuteurs.sonde = setInterval(() => {
    if (!ouvert.journal || document.hidden) return;
    sonderJournal();
  }, SONDE_JOURNAL);
}

function arretSonde() {
  if (minuteurs.sonde) { clearInterval(minuteurs.sonde); delete minuteurs.sonde; }
}

function heure(ms) {
  const d = new Date(ms || Date.now());
  const p = n => String(n).padStart(2, '0');
  return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds());
}

function filtre(e) {
  if (filtreJournal === 'tous') return true;
  if (filtreJournal === 'problemes') return e.type === 'erreur' ||
    (e.type === 'console' && (e.niveau === 'error' || e.niveau === 'warn'));
  return e.type === filtreJournal;
}

function detailEntree(e) {
  ouvrirFenetre('Entrée du journal — ' + (e.type || '') + (e.niveau ? ' / ' + e.niveau : ''),
    c => {
      const grille = el('div', { class: 'psdw-grille' });
      [['type', e.type], ['niveau', e.niveau], ['horodatage', heure(e.horodatage)],
        ['page', e.page], ['url', e.url], ['ressource', e.ressource],
        ['statut', e.statut], ['ligne', e.ligne], ['colonne', e.colonne],
        ['octets transférés', e.octets_transferes], ['octets bruts', e.octets_bruts],
        ['durée (ms)', e.duree], ['ttfb', e.ttfb], ['initiateur', e.initiateur],
        ['méthode', e.methode]]
        .forEach(p => {
          if (p[1] === undefined || p[1] === null || p[1] === '') return;
          grille.append(el('div', { class: 'psdw-cle', text: p[0] }),
                       el('div', { class: 'psdw-valeur', text: String(p[1]) }));
        });
      c.append(grille);
      if (e.message) c.append(el('h4', { text: 'Message' }),
        el('pre', { class: 'psdw-pre', text: e.message }));
      if (e.arguments) c.append(el('h4', { text: 'Arguments' }),
        el('pre', { class: 'psdw-pre', text: e.arguments }));
      if (e.pile) c.append(el('h4', { text: 'Pile d’appel' }),
        el('pre', { class: 'psdw-pre psdw-pile', text: e.pile }));
      /* L'aperçu n'est pas nécessaire : l'URL d'une ressource en faute est un
       * chemin du projet, et exiger un aperçu démarré priverait du bouton dans
       * le cas le plus courant (une erreur lue dans le journal d'une page
       * ouverte plus tôt). */
      if (e.url && e.ligne) {
        c.append(bouton('Ouvrir ' + e.url + ' dans un onglet', () => {
          const chemin = e.url.replace(/^\/+/, '').split('#')[0].split('?')[0];
          ouvrirFichier(chemin, e.ligne);
        }));
      }
    });
}

function ouvrirFichier(chemin, ligne) {
  if (typeof window.PSFMActivate !== 'function') {
    statut('Cette interface n’expose pas l’ouverture en onglet : le chemin est ' +
      chemin + (ligne ? ', ligne ' + ligne : '') + '.', 'avertissement');
    return;
  }
  /* PSFMActivate crée l'onglet s'il n'existe pas et l'active dans tous les cas.
   * Le contenu est laissé vide : c'est l'application qui le charge. La ligne ne
   * peut pas être imposée depuis un script hôte — elle est donc rappelée dans
   * la zone d'état plutôt que perdue. */
  window.PSFMActivate({ path: chemin, content: '' });
  statut('Ouvert : ' + chemin + (ligne ? ' (ligne ' + ligne + ')' : ''));
}

async function copier(texte, btn) {
  try {
    if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(texte);
    else {
      const zone = document.createElement('textarea');
      zone.value = texte;
      zone.setAttribute('readonly', '');
      zone.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.append(zone); zone.select();
      const ok = document.execCommand('copy'); zone.remove();
      if (!ok) throw new Error('copie refusée');
    }
    if (btn) {
      const avant = btn.textContent;
      btn.textContent = 'Copié';
      setTimeout(() => { btn.textContent = avant; }, 1400);
    }
    return true;
  } catch (e) {
    statut('La copie a été refusée par le navigateur : sélectionnez le texte ' +
      'manuellement.', 'erreur');
    return false;
  }
}

/* ------------------------------------------------------------------ audits -- */
async function lancerAudit(cible) {
  const champs = {};
  if (cible && cible.url) { champs.url = cible.url; champs.cible = cible.url; }
  else if (cible && cible.path) { champs.path = cible.path; }
  else throw new Error('Aucune cible : démarrez l’aperçu ou choisissez un fichier.');
  champs.options = {};
  $$('.psdw-opt', hote).forEach(c => {
    champs.options[c.getAttribute('data-opt')] = c.checked;
  });
  $$('.psdw-opt[data-opt-champ]', hote).forEach(c => {
    const nom = c.getAttribute('data-opt-champ');
    const valeur = Number(c.value);
    if (nom && valeur > 0) champs.options[nom] = valeur;
  });
  /* Un audit décoché n'est PAS envoyé : le serveur rend alors les six sections,
   * et un rapport complet alors que l'utilisateur n'en a demandé qu'une partie
   * est une réponse fausse. */
  const choisis = $$('.psdw-audit-case', hote).filter(c => c.checked).map(c => c.value);
  if (choisis.length && choisis.length < ((capacites && capacites.audits) || []).length) {
    champs.seulement = choisis;
  } else if (!choisis.length) {
    throw new Error('Au moins un audit doit être choisi.');
  }
  statut('Audit en cours…');
  const r = await api('auditer', champs);
  dernierAudit = r;
  statut(r.ok ? 'Audit terminé : note globale ' + r.note_globale + '/100.'
    : 'Audit refusé : ' + (r.erreur || 'raison inconnue'), r.ok ? 'ok' : 'erreur');
  rendreSection('audits');
  return r;
}

function badgeGravite(g) {
  return el('span', { class: 'psdw-grav psdw-g-' + g, title: g,
    text: g === 'erreur' ? '✕' : g === 'avertissement' ? '!' : g === 'info' ? 'i' : '✓' });
}

function rendreRapport(rapport, conteneur) {
  vider(conteneur);
  if (!rapport || !rapport.ok) {
    conteneur.append(el('p', { class: 'psdw-vide',
      text: 'Aucun audit : ' + ((rapport && rapport.erreur) || 'lancez un audit.') }));
    return;
  }
  const resume = rapport.resume || {};
  const entete = el('div', { class: 'psdw-note' },
    el('div', { class: 'psdw-note-chiffre', text: String(rapport.note_globale) }),
    el('div', null,
      el('b', { text: 'Note globale sur 100' }),
      el('div', { class: 'psdw-note-detail',
        text: (resume._global ? resume._global.erreur + ' erreur(s), ' +
          resume._global.avertissement + ' avertissement(s), ' +
          resume._global.info + ' info(s), ' + resume._global.ok + ' point(s) conforme(s).' : '') }),
      el('div', { class: 'psdw-note-detail', text: 'Cible : ' + (rapport.cible || '') +
        (rapport.encodage ? ' · encodage ' + rapport.encodage : '') })));
  conteneur.append(entete);
  if (rapport.notes && rapport.notes.length) {
    conteneur.append(el('ul', { class: 'psdw-notes' },
      rapport.notes.map(n => el('li', { text: n }))));
  }
  const filtres = el('div', { class: 'psdw-filtres' });
  let graviteFiltre = 'toutes';
  ['toutes', 'erreur', 'avertissement', 'info', 'ok'].forEach(g => {
    filtres.append(el('button', {
      type: 'button', class: 'psdw-filtre' + (g === 'toutes' ? ' psdw-actif' : ''),
      text: g === 'toutes' ? 'Tout' : g,
      onClick: ev => {
        graviteFiltre = g;
        $$('.psdw-filtre', filtres).forEach(b => b.classList.remove('psdw-actif'));
        ev.target.classList.add('psdw-actif');
        rendreListe();
      },
    }));
  });
  conteneur.append(filtres);
  const liste = el('div', { class: 'psdw-liste' });
  conteneur.append(liste);

  function rendreListe() {
    vider(liste);
    (capacites.audits || []).forEach(a => {
      const constats = (rapport.audits || {})[a.id] || [];
      const visibles = constats.filter(c => graviteFiltre === 'toutes' || c.gravite === graviteFiltre);
      const compte = resume[a.id] || {};
      const bloc = el('section', { class: 'psdw-bloc' },
        el('h4', null, a.nom,
          el('span', { class: 'psdw-note-mini',
            text: ' · ' + (compte.note === undefined ? '—' : compte.note) + '/100 · ' +
              constats.length + ' constat(s)' })),
        a.resume ? el('p', { class: 'psdw-resume', text: a.resume }) : null);
      if (!visibles.length) {
        bloc.append(el('p', { class: 'psdw-vide',
          text: constats.length ? 'Aucun constat de cette gravité.' : 'Rien à signaler.' }));
      }
      visibles.forEach(c => {
        bloc.append(el('article', { class: 'psdw-constat psdw-c-' + c.gravite },
          badgeGravite(c.gravite),
          el('div', { class: 'psdw-constat-corps' },
            el('div', { class: 'psdw-constat-msg', text: c.message }),
            c.conseil ? el('div', { class: 'psdw-constat-conseil',
              text: '→ ' + c.conseil }) : null,
            el('div', { class: 'psdw-constat-pied' },
              el('code', { text: c.code }),
              c.ligne ? el('span', { text: 'ligne ' + c.ligne }) : null,
              c.element ? el('span', { class: 'psdw-elem', text: c.element }) : null,
              c.extrait ? el('span', { class: 'psdw-extrait', text: c.extrait }) : null))));
      });
      liste.append(bloc);
    });
  }
  rendreListe();
}

/* --------------------------------------------------------------- générateurs - */
function construireParametres(generateur, valeurs) {
  const sortie = [];
  (generateur.parametres || []).forEach(p => {
    const valeur = (valeurs && valeurs[p.nom] !== undefined) ? valeurs[p.nom] : p.defaut;
    let champ = null;
    const nom = 'psdw-p-' + p.nom;
    if (p.type === 'zone' || p.type === 'liste') {
      champ = el('textarea', { id: nom, class: 'psdw-textarea', rows: p.type === 'liste' ? 3 : 5,
        value: '', placeholder: p.type === 'liste' ? 'Une valeur par ligne' : '' });
      champ.value = Array.isArray(valeur) ? valeur.join('\n') : (valeur === undefined || valeur === null ? '' : String(valeur));
    } else if (p.type === 'case') {
      champ = el('input', { id: nom, type: 'checkbox', checked: !!valeur });
    } else if (p.type === 'choix') {
      champ = el('select', { id: nom, class: 'psdw-select' },
        (p.options || []).map(o => el('option', { value: o, text: o, selected: o === valeur })));
    } else if (p.type === 'couleur') {
      champ = el('input', { id: nom, type: 'color', class: 'psdw-couleur',
        value: /^#[0-9a-f]{6}$/i.test(String(valeur || '')) ? valeur : '#1f5fd0' });
    } else {
      champ = el('input', { id: nom, class: 'psdw-input',
        type: p.type === 'nombre' ? 'number' : p.type === 'url' ? 'url' : 'text',
        value: valeur === undefined || valeur === null ? '' : String(valeur) });
    }
    sortie.push(el('div', { class: 'psdw-param' },
      el('label', { for: nom, text: p.libelle || p.nom }),
      champ,
      p.aide ? el('small', { class: 'psdw-aide', text: p.aide }) : null));
  });
  return sortie;
}

function lireParametres(generateur, racine) {
  const valeurs = {};
  (generateur.parametres || []).forEach(p => {
    const champ = $('#psdw-p-' + p.nom, racine);
    if (!champ) return;
    if (p.type === 'case') valeurs[p.nom] = champ.checked;
    else if (p.type === 'liste') valeurs[p.nom] = champ.value.split('\n').map(s => s.trim()).filter(Boolean);
    else valeurs[p.nom] = champ.value;
  });
  return valeurs;
}

function ouvrirGenerateur(id) {
  const g = ((capacites && capacites.generateurs) || []).find(x => x.id === id);
  if (!g) { statut('Générateur introuvable : ' + id, 'erreur'); return; }
  const corps = ouvrirFenetre('Générer — ' + g.nom, c => {
    c.append(el('p', { class: 'psdw-resume', text: g.description }));
    const forme = el('form', { class: 'psdw-forme', onSubmit: ev => ev.preventDefault() },
      construireParametres(g, null));
    c.append(forme);
    const resultat = el('div', { class: 'psdw-resultat' });
    const lancer = async () => {
      const parametres = lireParametres(g, forme);
      try {
        statut('Génération de « ' + g.nom + ' »…');
        const r = await api('generer', { generateur: g.id, parametres: parametres });
        if (!r.ok) { statut(r.erreur || 'Génération refusée.', 'erreur'); return; }
        statut('Généré : ' + r.fichier + ' (' + r.octets + ' octets).');
        vider(resultat);
        if (r.notes && r.notes.length) {
          resultat.append(el('div', { class: 'psdw-notes-titre',
            text: 'À savoir avant de publier ce fichier' }),
            el('ul', { class: 'psdw-notes' }, r.notes.map(n => el('li', { text: n }))));
        }
        const pre = el('pre', { class: 'psdw-pre psdw-code', text: r.contenu });
        resultat.append(pre);
        const nomFichier = el('input', { class: 'psdw-input', value: r.fichier,
          placeholder: 'chemin/du/fichier', 'aria-label': 'Nom du fichier à enregistrer' });
        const actions = el('div', { class: 'psdw-actions' });
        const bCopier = bouton('Copier', () => copier(r.contenu, bCopier));
        const bOnglet = bouton('Ouvrir dans un onglet', () => {
          if (typeof window.PSFMActivate !== 'function') {
            statut('Cette interface n’expose pas l’ouverture en onglet.', 'erreur'); return;
          }
          /* Le contenu généré est passé à l'onglet : `saved` est aligné sur
           * `content` pour que le point de « modifié » ne s'allume pas sur un
           * fichier que l'utilisateur n'a pas encore touché. */
          window.PSFMActivate({ path: nomFichier.value || r.fichier,
            content: r.contenu, saved: r.contenu });
        });
        const bEnregistrer = bouton('Enregistrer dans le projet', async () => {
          const chemin = (nomFichier.value || r.fichier).trim();
          if (!chemin) { statut('Donnez un chemin de fichier.', 'erreur'); return; }
          try {
            await api2('/api/create', { path: chemin, content: r.contenu });
            statut('Fichier créé : ' + chemin, 'ok');
            rafraichirArbre();
          } catch (e) {
            /* « x » mode d'ouverture échoue si le fichier existe : le dire et
             * proposer l'écrasement explicite, plutôt que d'écraser en silence. */
            const ecraser = bouton('Écraser ' + chemin + ' ?', async () => {
              try {
                await api2('/api/save', { path: chemin, content: r.contenu });
                statut('Fichier écrasé : ' + chemin, 'ok');
                ecraser.remove();
                rafraichirArbre();
              } catch (e2) { erreur(e2); }
            }, 'psdw-danger');
            erreur(e);
            actions.append(ecraser);
          }
        }, 'psdw-primaire');
        actions.append(bCopier, bOnglet, bEnregistrer, nomFichier);
        resultat.append(actions);
      } catch (e) { erreur(e); }
    };
    forme.append(el('div', { class: 'psdw-actions' },
      bouton('Générer', lancer, 'psdw-primaire'),
      bouton('Réinitialiser', () => {
        vider(forme); forme.append(construireParametres(g, null));
        forme.append(el('div', { class: 'psdw-actions' },
          bouton('Générer', lancer, 'psdw-primaire')));
      })));
    c.append(resultat);
  });
  return corps;
}

/* ----------------------------------------------------------------- extraits - */
function ouvrirExtrait(id) {
  const e = ((capacites && capacites.extraits) || []).find(x => x.id === id);
  if (!e) { statut('Extrait introuvable : ' + id, 'erreur'); return; }
  api('extraits', { extrait: id }).then(r => {
    const complet = (r && r.extrait) || e;
    ouvrirFenetre(complet.titre, c => {
      c.append(el('p', { class: 'psdw-resume', text: complet.description }));
      const pre = el('pre', { class: 'psdw-pre psdw-code', text: complet.code });
      c.append(pre);
      const b = bouton('Copier l’extrait', () => copier(complet.code, b), 'psdw-primaire');
      c.append(el('div', { class: 'psdw-actions' }, b,
        el('span', { class: 'psdw-aide',
          text: 'langage : ' + complet.langage + ' · ' + (complet.code || '').length + ' caractères' })));
    });
  }).catch(erreur);
}

/* ----------------------------------------------------------------- requêtes - */
function ouvrirRequete(urlInitiale) {
  ouvrirFenetre('Requête HTTP', c => {
    const url = el('input', { class: 'psdw-input', value: urlInitiale || '',
      placeholder: 'https://exemple.fr/api/…', 'aria-label': 'Adresse' });
    const methode = el('select', { class: 'psdw-select', 'aria-label': 'Méthode' },
      ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS']
        .map(m => el('option', { value: m, text: m })));
    const entetes = el('textarea', { class: 'psdw-textarea', rows: 3,
      placeholder: 'Accept: application/json\nX-Clef: valeur' });
    const corps = el('textarea', { class: 'psdw-textarea', rows: 4,
      placeholder: 'Corps de la requête (JSON ou texte)' });
    const delai = el('input', { class: 'psdw-input psdw-court', type: 'number',
      value: '15', min: '1', max: '120', 'aria-label': 'Délai en secondes' });
    const suivre = el('input', { type: 'checkbox', checked: true });
    const tls = el('input', { type: 'checkbox', checked: true });
    const resultat = el('div', { class: 'psdw-resultat' });
    const envoyer = async () => {
      if (!url.value.trim()) { statut('Donnez une adresse.', 'erreur'); return; }
      const lignes = entetes.value.split('\n').map(l => l.trim()).filter(Boolean);
      const dictionnaire = {};
      let malformed = null;
      lignes.forEach(l => {
        const i = l.indexOf(':');
        if (i <= 0) { malformed = l; return; }
        dictionnaire[l.slice(0, i).trim()] = l.slice(i + 1).trim();
      });
      if (malformed) {
        statut('En-tête mal formé : « ' + malformed + ' ». Le format attendu ' +
          'est « Nom: valeur », un par ligne.', 'erreur');
        return;
      }
      try {
        statut('Requête en cours…');
        const champs = { url: url.value.trim(), methode: methode.value,
          entetes: dictionnaire, delai: Number(delai.value) || 15,
          suivre: suivre.checked, verifier_tls: tls.checked };
        if (corps.value.trim() && methode.value !== 'GET' && methode.value !== 'HEAD') {
          let parsed = null;
          try { parsed = JSON.parse(corps.value); } catch (e) { parsed = null; }
          champs.corps = parsed === null ? corps.value : parsed;
        }
        const r = await api('requeter', champs);
        statut(r.ok ? ('Réponse ' + r.statut + ' ' + (r.raison || '') + ' en ' +
          r.duree_ms + ' ms.') : ('Échec : ' + (r.erreur || 'raison inconnue')),
          r.ok ? 'ok' : 'erreur');
        vider(resultat);
        resultat.append(el('div', { class: 'psdw-ligne-statut' },
          el('span', { class: 'psdw-code-statut psdw-s-' +
            (r.statut ? String(r.statut)[0] : 'x'), text: String(r.statut || '—') }),
          el('b', { text: (r.methode || '') + ' ' + (r.url || '') }),
          el('span', { class: 'psdw-aide', text: (r.raison || '') + ' · ' +
            (r.duree_ms || 0) + ' ms · ' + (r.octets || 0) + ' octets' +
            (r.tronque ? ' (tronqué)' : '') })));
        if (r.erreur) resultat.append(el('p', { class: 'psdw-erreur', text: r.erreur }));
        if (!r.tls_verifie) resultat.append(el('p', { class: 'psdw-avertissement',
          text: 'Le certificat TLS n’a pas été vérifié : la connexion n’est ' +
            'pas authentifiée. À réserver à un serveur local en certificat ' +
            'auto-signé.' }));
        if (r.locale) resultat.append(el('p', { class: 'psdw-aide',
          text: 'Adresse locale : la requête reste sur cette machine.' }));
        if ((r.chaine || []).length > 1) {
          resultat.append(el('h4', { text: 'Chaîne de redirections' }),
            el('ol', { class: 'psdw-notes' }, r.chaine.map(e =>
              el('li', { text: (e.statut || '—') + ' · ' + e.url }))));
        }
        const noms = Object.keys(r.entetes || {}).sort();
        if (noms.length) {
          const grille = el('div', { class: 'psdw-grille' });
          noms.forEach(n => {
            const v = r.entetes[n];
            grille.append(el('div', { class: 'psdw-cle', text: n }),
              el('div', { class: 'psdw-valeur', text: Array.isArray(v) ? v.join(' | ') : String(v) }));
          });
          resultat.append(el('h4', { text: 'En-têtes de la réponse (' + noms.length + ')' }), grille);
        }
        if (r.binaire) resultat.append(el('p', { class: 'psdw-aide',
          text: 'Corps binaire (' + (r.octets || 0) + ' octets), rendu en ' +
            'base64 tronqué. ' + ((r.base64 || '').length) + ' caractères base64.' }));
        else if (r.corps) {
          resultat.append(el('h4', { text: 'Corps de la réponse' }),
            el('pre', { class: 'psdw-pre psdw-code', text: r.corps }));
        }
        if (r.apercu) resultat.append(el('details', null,
          el('summary', { text: 'Aperçu texte complet' }),
          el('pre', { class: 'psdw-pre', text: r.apercu })));
      } catch (e) { erreur(e); }
    };
    c.append(el('div', { class: 'psdw-forme' },
      el('div', { class: 'psdw-param' }, el('label', { text: 'Adresse' }), url),
      el('div', { class: 'psdw-ligne' },
        el('div', { class: 'psdw-param' }, el('label', { text: 'Méthode' }), methode),
        el('div', { class: 'psdw-param' }, el('label', { text: 'Délai (s)' }), delai)),
      el('div', { class: 'psdw-param' }, el('label', { text: 'En-têtes (un par ligne)' }), entetes),
      el('div', { class: 'psdw-param' }, el('label', { text: 'Corps' }), corps),
      el('div', { class: 'psdw-cases' },
        el('label', null, suivre, ' Suivre les redirections'),
        el('label', null, tls, ' Vérifier le certificat TLS')),
      el('div', { class: 'psdw-actions' }, bouton('Envoyer', envoyer, 'psdw-primaire'),
        bouton('Copier en cURL', () => {
          const lignes = entetes.value.split('\n').map(l => l.trim()).filter(Boolean);
          const cmd = ['curl', '-i', '-X', methode.value]
            .concat(lignes.map(l => '-H ' + JSON.stringify(l)))
            .concat(corps.value.trim() ? ['--data ' + JSON.stringify(corps.value)] : [])
            .concat(suivre.checked ? ['-L'] : [])
            .concat(tls.checked ? [] : ['-k'])
            .concat([JSON.stringify(url.value.trim())]);
          copier(cmd.join(' '), null);
        }))),
      resultat);
  });
}

/* ------------------------------------------------------------------ projet -- */
function aplatirArbre(noeuds, sortie, prefixe) {
  (noeuds || []).forEach(n => {
    const chemin = n.path || ((prefixe ? prefixe + '/' : '') + n.name);
    if (n.type === 'file' || !n.children) sortie.push({ nom: n.name, chemin: chemin });
    if (n.children) aplatirArbre(n.children, sortie, chemin);
  });
  return sortie;
}

async function rafraichirArbre() {
  try {
    const arbre = await getApi('/api/tree');
    fichiers = aplatirArbre(arbre && (arbre.tree || arbre.children || arbre), []);
    rendreSection('apercu');
    if (ouvert.projet) rendreSection('projet');
  } catch (e) { /* l'arbre n'est pas indispensable au panneau */ }
}

function selecteurFichiers(cible) {
  const select = el('select', { class: 'psdw-select',
    'aria-label': 'Fichier du projet',
    onChange: ev => { cible.value = ev.target.value; } });
  select.append(el('option', { value: '', text: '— choisir un fichier du projet —' }));
  const pages = fichiers.filter(f => /\.(html?|xhtml|svg|xml|php|css)$/i.test(f.nom));
  (pages.length ? pages : fichiers).forEach(f => {
    select.append(el('option', { value: f.chemin, text: f.chemin }));
  });
  if (cible.value) select.value = cible.value;
  return select;
}

/* ---------------------------------------------------------------- sections -- */
const SECTIONS = [
  { id: 'apercu', titre: 'Aperçu', icone: ICONES.apercu },
  { id: 'journal', titre: 'Journal de la page', icone: ICONES.journal, badge: true },
  { id: 'audits', titre: 'Audits', icone: ICONES.audit },
  { id: 'generer', titre: 'Générer', icone: ICONES.generer },
  { id: 'extraits', titre: 'Extraits', icone: ICONES.extrait },
  { id: 'requetes', titre: 'Requêtes HTTP', icone: ICONES.requete },
  { id: 'projet', titre: 'Projet', icone: ICONES.projet },
];

function construireSection(id, conteneur) {
  vider(conteneur);
  if (id === 'apercu') sectionApercu(conteneur);
  else if (id === 'journal') sectionJournal(conteneur);
  else if (id === 'audits') sectionAudits(conteneur);
  else if (id === 'generer') sectionGenerer(conteneur);
  else if (id === 'extraits') sectionExtraits(conteneur);
  else if (id === 'requetes') sectionRequetes(conteneur);
  else if (id === 'projet') sectionProjet(conteneur);
}

function rendreSection(id) {
  if (!hote) return;
  const conteneur = $('.psdw-corps-' + id, hote);
  if (conteneur && ouvert[id]) construireSection(id, conteneur);
}

function sectionApercu(c) {
  const chemin = el('input', { class: 'psdw-input', value: (apercu && apercu.path) || '',
    placeholder: 'chemin/vers/index.html', 'aria-label': 'Fichier à apercevoir' });
  c.append(el('label', { class: 'psdw-label', text: 'Fichier à publier' }), chemin);
  if (fichiers.length) c.append(selecteurFichiers(chemin));
  c.append(el('div', { class: 'psdw-actions' },
    bouton('Démarrer', () => agir(() => demarrerApercu(chemin.value.trim())), 'psdw-primaire'),
    apercu ? bouton('Arrêter', () => agir(arreterApercu), 'psdw-danger') : null,
    apercu ? bouton('Fenêtre d’aperçu', () => ouvrirFenetreApercu()) : null));
  if (apercu) {
    c.append(el('div', { class: 'psdw-info' },
      el('div', null, el('b', { text: 'En cours' }), ' · mode ' + apercu.mode +
        ' · port ' + apercu.port),
      el('div', { class: 'psdw-url', text: apercu.url }),
      el('div', { class: 'psdw-actions' },
        bouton('Auditer cette page', () => agir(() =>
          lancerAudit({ url: apercu.url }).then(r => {
            if (r && r.ok) ouvrirFenetre('Audit — ' + (r.cible || ''),
              cc => rendreRapport(r, cc));
          }))),
        bouton('Ouvrir l’adresse', () => { window.open(apercu.url, '_blank', 'noopener'); }))));
    if (apercu.mode === 'php') {
      c.append(el('p', { class: 'psdw-avertissement',
        text: 'En mode PHP, c’est php -S qui sert les fichiers : le script de ' +
          'capture n’est pas injecté et le journal reste vide. Les audits, ' +
          'générateurs et requêtes fonctionnent normalement.' }));
    }
  } else {
    c.append(el('p', { class: 'psdw-vide',
      text: 'Aucun aperçu en cours. L’aperçu est servi sur une origine séparée ' +
        '(127.0.0.1, port libre) et n’est accessible que depuis cette machine.' }));
  }
  c.append(el('label', { class: 'psdw-label', text: 'Viewport de la fenêtre d’aperçu' }),
    construireSelecteurViewport(() => appliquerViewport()));
}

function sectionJournal(c) {
  const comptes = {};
  entrees.forEach(e => { comptes[e.type] = (comptes[e.type] || 0) + 1; });
  const total = entrees.length;
  c.append(el('div', { class: 'psdw-filtres' },
    ['tous', 'problemes', 'console', 'erreur', 'reseau', 'navigation', 'systeme']
      .map(t => el('button', {
        type: 'button',
        class: 'psdw-filtre' + (t === filtreJournal ? ' psdw-actif' : ''),
        text: t === 'tous' ? 'Tout (' + total + ')'
          : t === 'problemes' ? 'Problèmes'
            : t + ' (' + (comptes[t] || 0) + ')',
        onClick: () => { filtreJournal = t; rendreSection('journal'); },
      }))));
  const visibles = entrees.filter(filtre);
  if (!visibles.length) {
    c.append(el('p', { class: 'psdw-vide',
      text: total ? 'Aucune entrée pour ce filtre.'
        : (apercu ? 'Le journal est vide : rechargez la page aperçue, ou ' +
           'ouvrez la console de la page.'
          : 'Démarrez l’aperçu d’une page HTML : le script de capture y est ' +
            'injecté et envoie ici les messages console, les erreurs et les ' +
            'requêtes réseau de la page.') }));
  }
  const liste = el('div', { class: 'psdw-journal' });
  visibles.slice(-120).reverse().forEach(e => {
    liste.append(el('div', {
      class: 'psdw-entree psdw-e-' + (e.niveau || e.type),
      role: 'button', tabIndex: '0',
      onClick: () => detailEntree(e),
      onKeydown: ev => { if (ev.key === 'Enter') detailEntree(e); },
    },
      el('span', { class: 'psdw-heure', text: heure(e.horodatage) }),
      el('span', { class: 'psdw-type', text: e.type }),
      el('span', { class: 'psdw-msg', text: e.message || e.ressource || '(sans message)' })));
  });
  c.append(liste);
  c.append(el('div', { class: 'psdw-actions' },
    bouton('Actualiser', () => agir(sonderJournal)),
    bouton('Vider', () => agir(async () => {
      await api('journal-vider', { raison: 'Journal vidé depuis le panneau dev web' });
      depuis = 0; entrees = []; rendreSection('journal');
    }), 'psdw-danger'),
    bouton('Copier', () => copier(entrees.map(e =>
      '[' + heure(e.horodatage) + '] ' + e.type + (e.niveau ? '/' + e.niveau : '') +
      ' ' + (e.message || '')).join('\n'))),
    el('span', { class: 'psdw-aide',
      text: total + ' entrée(s) en mémoire' +
        ((capacites && capacites.journal && entrees.length >= capacites.journal.capacite)
          ? ' — le tampon est plein, les plus anciennes sont perdues' : '') })));
  demarrerSonde();
}

function sectionAudits(c) {
  const chemin = el('input', { class: 'psdw-input', value: '',
    placeholder: 'chemin/vers/index.html', 'aria-label': 'Fichier à auditer' });
  c.append(el('label', { class: 'psdw-label', text: 'Auditer un fichier du projet' }), chemin);
  if (fichiers.length) c.append(selecteurFichiers(chemin));
  const cases = el('div', { class: 'psdw-cases' });
  (capacites && capacites.audits || []).forEach(a => {
    cases.append(el('label', { title: a.resume },
      el('input', { type: 'checkbox', class: 'psdw-audit-case', value: a.id, checked: true }),
      ' ' + a.nom));
  });
  c.append(cases);
  /* Les seules options que le serveur connaît sont verifier_distant et
   * delai_distant. Le poids des ressources LOCALES est toujours mesuré : une
   * case à cocher pour une option inexistante afficherait un réglage qui ne
   * commande rien. */
  const options = el('div', { class: 'psdw-cases' },
    el('label', { title: 'Contacte les adresses externes trouvées dans la page' },
      el('input', { type: 'checkbox', class: 'psdw-opt', 'data-opt': 'verifier_distant' }),
      ' Vérifier les liens distants (trafic sortant)'),
    el('label', null, 'Délai par adresse distante (s) ',
      el('input', { class: 'psdw-input psdw-court', type: 'number', value: '8',
        min: '1', max: '30', 'data-opt-champ': 'delai_distant' })));
  c.append(options);
  c.append(el('p', { class: 'psdw-aide',
    text: 'Le poids des ressources locales est toujours mesuré ; seules les ' +
      'adresses distantes exigent votre accord explicite.' }));
  c.append(el('div', { class: 'psdw-actions' },
    bouton('Auditer le fichier', () => agir(() =>
      lancerAudit({ path: chemin.value.trim() }).then(r => {
        if (r && r.ok) ouvrirFenetre('Audit — ' + (r.cible || ''), cc => rendreRapport(r, cc));
      })), 'psdw-primaire'),
    apercu ? bouton('Auditer l’aperçu', () => agir(() =>
      lancerAudit({ url: apercu.url }).then(r => {
        if (r && r.ok) ouvrirFenetre('Audit — ' + (r.cible || ''), cc => rendreRapport(r, cc));
      })), 'psdw-primaire') : null,
    dernierAudit ? bouton('Rouvrir le dernier rapport', () =>
      ouvrirFenetre('Audit — ' + (dernierAudit.cible || ''), cc =>
        rendreRapport(dernierAudit, cc))) : null));
  if (dernierAudit && dernierAudit.ok) {
    const resume = dernierAudit.resume || {};
    c.append(el('div', { class: 'psdw-note psdw-note-mini-bloc' },
      el('div', { class: 'psdw-note-chiffre', text: String(dernierAudit.note_globale) }),
      el('div', null, el('b', { text: dernierAudit.cible || '' }),
        el('div', { class: 'psdw-note-detail', text: (resume._global
          ? resume._global.erreur + ' erreur(s) · ' + resume._global.avertissement +
            ' avertissement(s) · ' + resume._global.info + ' info(s)' : '') }))));
    const lignes = el('div', { class: 'psdw-mini' });
    (capacites.audits || []).forEach(a => {
      const compte = resume[a.id] || {};
      lignes.append(el('button', {
        type: 'button', class: 'psdw-mini-ligne',
        onClick: () => ouvrirFenetre('Audit — ' + a.nom, cc => rendreRapport(dernierAudit, cc)),
      }, el('span', { text: a.nom }),
         el('span', { class: 'psdw-mini-note', text: String(compte.note === undefined ? '—' : compte.note) }),
         el('span', { class: 'psdw-mini-erreurs',
           text: (compte.erreur || 0) + '✕ ' + (compte.avertissement || 0) + '!' })));
    });
    c.append(lignes);
  } else {
    c.append(el('p', { class: 'psdw-vide',
      text: 'Six audits : accessibilité, sécurité, liens, poids, métadonnées et ' +
        'validation. Chaque constat explique pourquoi c’est un problème et quoi ' +
        'faire ; ce qui ne peut pas être vérifié (une ressource distante, un ' +
        'contraste exprimé en variables CSS) est dit comme tel plutôt ' +
        'qu’approximé.' }));
  }
}

function sectionGenerer(c) {
  const groupes = {};
  ((capacites && capacites.generateurs) || []).forEach(g => {
    (groupes[g.groupe] = groupes[g.groupe] || []).push(g);
  });
  Object.keys(groupes).sort().forEach(groupe => {
    c.append(el('div', { class: 'psdw-groupe-titre', text: groupe }));
    groupes[groupe].forEach(g => {
      c.append(el('button', {
        type: 'button', class: 'psdw-ligne', title: g.description,
        onClick: () => ouvrirGenerateur(g.id),
      }, el('span', { class: 'psdw-ligne-titre', text: g.nom }),
         el('span', { class: 'psdw-ligne-det', text: g.fichier })));
    });
  });
  c.append(el('p', { class: 'psdw-aide',
    text: 'Un générateur produit du TEXTE : rien n’est écrit dans le projet ' +
      'tant que vous n’avez pas donné un nom de fichier et validé. Les notes ' +
      'qui accompagnent chaque fichier disent ce qui reste à personnaliser.' }));
}

function sectionExtraits(c) {
  const recherche = el('input', { class: 'psdw-input', placeholder: 'Chercher dans le code…',
    'aria-label': 'Recherche d’extrait',
    onInput: ev => differe('extrait', () => charger(ev.target.value, select.value)) });
  const select = el('select', { class: 'psdw-select', 'aria-label': 'Groupe d’extrait',
    onChange: () => charger(recherche.value, select.value) },
    [el('option', { value: '', text: 'Tous les groupes' })].concat(
      ((capacites && capacites.groupes_extraits) || [])
        .map(g => el('option', { value: g, text: g }))));
  const liste = el('div', { class: 'psdw-liste-extraits' });
  c.append(recherche, select, liste);
  function charger(q, groupe) {
    api('extraits', { recherche: q || '', groupe: groupe || '' }).then(r => {
      vider(liste);
      const extraits = (r && r.extraits) || [];
      if (!extraits.length) {
        liste.append(el('p', { class: 'psdw-vide',
          text: 'Aucun extrait ne correspond. La recherche porte sur le titre, ' +
            'la description ET le code.' }));
        return;
      }
      extraits.forEach(e => {
        liste.append(el('button', { type: 'button', class: 'psdw-ligne',
          title: e.description, onClick: () => ouvrirExtrait(e.id) },
          el('span', { class: 'psdw-ligne-titre', text: e.titre }),
          el('span', { class: 'psdw-ligne-det', text: e.groupe + ' · ' + e.langage })));
      });
    }).catch(erreur);
  }
  charger('', '');
}

function sectionRequetes(c) {
  c.append(el('p', { class: 'psdw-vide',
    text: 'Envoyez une requête HTTP depuis Pascal Studio et lisez la réponse ' +
      'complète : statut, durée, chaîne de redirections, en-têtes et corps. ' +
      'Utile pour vérifier une API avant d’écrire le code qui l’appelle.' }));
  const url = el('input', { class: 'psdw-input', placeholder: 'https://…',
    'aria-label': 'Adresse à interroger' });
  c.append(url, el('div', { class: 'psdw-actions' },
    bouton('Ouvrir l’éditeur de requête', () => ouvrirRequete(url.value.trim()), 'psdw-primaire'),
    apercu ? bouton('Interroger l’aperçu', () => ouvrirRequete(apercu.url)) : null));
  c.append(el('p', { class: 'psdw-aide',
    text: 'Le trafic sortant n’a lieu que sur votre demande explicite. Les ' +
      'adresses hors HTTP/HTTPS sont refusées, les identifiants inclus dans une ' +
      'adresse sont masqués dans l’affichage, et un certificat refusé est ' +
      'expliqué plutôt que contourné en silence.' }));
}

function sectionProjet(c) {
  const lancer = async () => {
    try {
      statut('Inventaire du projet…');
      const r = await api('inventaire', {});
      if (!r.ok) { statut(r.erreur || 'Inventaire refusé.', 'erreur'); return; }
      statut(r.nombre_fichiers + ' fichier(s), ' + r.nombre_pages + ' page(s), ' +
        Math.round(r.octets / 1024) + ' Ko.');
      vider(c);
      c.append(el('div', { class: 'psdw-info' },
        el('div', null, el('b', { text: String(r.nombre_fichiers) }), ' fichiers · ',
          String(Math.round(r.octets / 1024)), ' Ko'),
        r.page_accueil ? el('div', { class: 'psdw-url',
          text: 'accueil supposé : ' + r.page_accueil }) : null,
        el('div', { class: 'psdw-actions' },
          r.page_accueil ? bouton('Apercevoir l’accueil', () =>
            agir(() => demarrerApercu(r.page_accueil)), 'psdw-primaire') : null,
          r.page_accueil ? bouton('Auditer l’accueil', () => agir(() =>
            lancerAudit({ path: r.page_accueil }).then(rr => {
              if (rr && rr.ok) ouvrirFenetre('Audit — ' + rr.cible, cc => rendreRapport(rr, cc));
            }))) : null,
          bouton('Refaire l’inventaire', lancer))));
      const grille = el('div', { class: 'psdw-grille' });
      (r.categories || []).forEach(cat => {
        grille.append(el('div', { class: 'psdw-cle', text: cat.groupe }),
          el('div', { class: 'psdw-valeur', text: cat.nombre + ' · ' +
            Math.round(cat.octets / 1024) + ' Ko · ' +
            Object.keys(cat.extensions || {}).slice(0, 4).join(', ') }));
      });
      c.append(el('h4', { text: 'Par catégorie' }), grille);
      if ((r.pages || []).length) {
        c.append(el('h4', { text: 'Pages (' + r.nombre_pages + ')' }));
        const liste = el('div', { class: 'psdw-liste-extraits' });
        r.pages.slice(0, 120).forEach(p => {
          liste.append(el('div', { class: 'psdw-ligne' },
            el('span', { class: 'psdw-ligne-titre', text: p.chemin }),
            el('span', { class: 'psdw-ligne-det', text: Math.round(p.octets / 1024) + ' Ko' }),
            bouton('Aperçu', () => agir(() => demarrerApercu(p.chemin))),
            bouton('Audit', () => agir(() => lancerAudit({ path: p.chemin }).then(rr => {
              if (rr && rr.ok) ouvrirFenetre('Audit — ' + rr.cible, cc => rendreRapport(rr, cc));
            })))));
        });
        c.append(liste);
      }
      if (r.ignores) c.append(el('p', { class: 'psdw-aide',
        text: r.ignores + ' entrée(s) ignorée(s) : dossiers cachés, node_modules.' }));
    } catch (e) { erreur(e); }
  };
  c.append(el('p', { class: 'psdw-vide',
    text: 'L’inventaire liste les fichiers du projet par catégorie, mesure leur ' +
      'poids et propose les pages trouvées à l’aperçu et à l’audit.' }),
    bouton('Faire l’inventaire', lancer, 'psdw-primaire'));
}

/* ------------------------------------------------------------ barre latérale */
function rendre() {
  if (!hote) return;
  /* Le panneau écrit dans le DOM, donc son propre MutationObserver voit ses
   * écritures : sans takeRecords(), chaque rendu déclencherait le suivant. */
  vider(hote);
  const panneau = el('div', { class: 'psdw-panneau' });
  panneau.append(el('div', { class: 'psdw-tete' },
    el('span', { class: 'psdw-logo', html: icone(ICONES.audit, 14) }),
    el('b', { text: 'Dev web' }),
    el('span', { class: 'psdw-pousse' }),
    bouton('', () => agir(async () => {
      capacites = null;
      await lireCapacites();
      await rafraichirArbre();
      rendre();
      statut('Capacités rechargées.');
    }), 'psdw-ic', 'Recharger les capacités')));
  const btn = panneau.querySelector('.psdw-btn');
  if (btn) btn.innerHTML = icone(ICONES.journal, 13);

  SECTIONS.forEach(s => {
    const corps = el('div', { class: 'psdw-section-corps psdw-corps-' + s.id,
      hidden: !ouvert[s.id] });
    const entete = el('button', {
      type: 'button', class: 'psdw-section-tete' + (ouvert[s.id] ? ' psdw-ouverte' : ''),
      'aria-expanded': ouvert[s.id] ? 'true' : 'false',
      onClick: () => {
        ouvert[s.id] = !ouvert[s.id];
        entete.classList.toggle('psdw-ouverte', ouvert[s.id]);
        entete.setAttribute('aria-expanded', ouvert[s.id] ? 'true' : 'false');
        corps.hidden = !ouvert[s.id];
        if (ouvert[s.id]) {
          construireSection(s.id, corps);
          if (s.id === 'journal') { demarrerSonde(); sonderJournal(); }
          if (s.id === 'apercu' && !fichiers.length) rafraichirArbre();
          if (s.id === 'extraits' || s.id === 'generer') { /* déjà chargés */ }
        } else if (s.id === 'journal') {
          /* Refermer la section arrête la sonde : interroger le serveur toutes
           * les 1,2 s pour une liste que personne ne regarde est du bruit. */
          arretSonde();
        }
      },
    }, el('span', { class: 'psdw-section-icone', html: icone(s.icone, 14) }),
       el('span', { class: 'psdw-section-titre', text: s.titre }),
       s.badge ? el('span', { class: 'psdw-badge psdw-badge-journal', text: '0' }) : null,
       el('span', { class: 'psdw-chevron', text: '›' }));
    panneau.append(entete, corps);
    if (ouvert[s.id]) construireSection(s.id, corps);
  });

  panneau.append(el('div', { class: 'psdw-statut', text: statutTexte || 'Prêt.' }));
  /* 4.3.0 : le panneau passe devant les fichiers ouverts. S'il n'y a pas de
   * mécanisme de vues, il reste dans la barre latérale comme avant. */
  if (!ouvrirVue(panneau)) hote.append(panneau);
  else rendreQuai(hote);
  if (observateurHote && typeof observateurHote.takeRecords === 'function') {
    try { observateurHote.takeRecords(); } catch (e) { /* ignoré */ }
  }
}

/* ------------------------------------------------------- vue plein écran -- */
let vueOuverte = false;

function ouvrirVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    vueOuverte = window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud
    }) === true;
    return vueOuverte;
  } catch (exc) {
    vueOuverte = false;
    return false;
  }
}

function fermerVue() {
  vueOuverte = false;
  if (!window.PSVues || typeof window.PSVues.fermer !== 'function') return;
  try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
}

/* Le quai : la barre latérale ne reste jamais vide ni muette. */
function rendreQuai(cible) {
  if (!cible || !vueOuverte) return;
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return;
  vider(cible);
  const disposition = (typeof window.PSVues.disposition === 'function')
    ? window.PSVues.disposition() : { mode: 'plein' };
  const partage = disposition.mode === 'partage';
  const quai = el('div', { class: 'ps-vues-quai' },
    el('p', { class: 'ps-vues-quai-titre', text: 'Dev web' }),
    el('p', { class: 'ps-vues-quai-texte',
      text: 'Le panneau est affiché devant les fichiers ouverts.' }),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'mode' }),
      el('b', { text: partage ? 'côte à côte' : 'plein écran' })),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'statut' }),
      el('b', { text: (statutTexte || 'Prêt.').slice(0, 42) })),
    boutonQuai('Replier le panneau', 'replier', function () {
      fermerVue();
      if (typeof arretSonde === 'function') arretSonde();
    }),
    boutonQuai(partage ? 'Passer en plein écran' : 'Garder l’éditeur à gauche',
      'basculer', function () {
        if (typeof window.PSVues.mode === 'function') {
          window.PSVues.mode(partage ? 'plein' : 'partage');
        }
        rendreQuai($(HOTE));
      }));
  cible.append(quai);
}

function boutonQuai(texte, acte, rappel) {
  const b = el('button', { type: 'button', 'data-acte': acte, title: texte });
  b.textContent = texte;
  b.addEventListener('click', function (evt) {
    if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
    try { rappel(); } catch (exc) { statut(String(exc), 'erreur'); }
  });
  return b;
}

let observateurHote = null;

function attach() {
  const cible = $(HOTE);
  if (cible && cible !== hote) {
    hote = cible;
    if (!capacites) {
      lireCapacites().then(() => { rafraichirArbre(); rendre(); })
        .catch(e => {
          /* Sans capacités, le panneau ne peut rien afficher d'utile : il dit
           * pourquoi au lieu de rester vide. */
          hote.replaceChildren(el('div', { class: 'psdw-panneau' },
            el('p', { class: 'psdw-erreur',
              text: 'Le panneau dev web n’a pas pu lire ses capacités : ' +
                (e && e.message ? e.message : String(e)) }),
            el('p', { class: 'psdw-aide',
              text: 'Vérifiez que les modules devweb sont présents à côté de ' +
                'server.py, puis rechargez l’application.' })));
        });
    } else rendre();
    observerHote();
  }
  if (!cible && hote) { hote = null; arretSonde(); fermerVue(); }
}

/* L'hôte n'existe que lorsque la barre latérale est ouverte sur ce panneau :
 * l'observer évite de sonder le DOM en permanence, et le filet setInterval
 * couvre le cas où l'observateur serait installé avant la création de l'hôte. */
/* Un seul observateur pour toute l'application, via ps-hotes.js. Cinq
 * observateurs sur document.documentElement plus cinq sondes à 2 s
 * saturaient le fil principal : chaque mutation du DOM — une frappe dans
 * Monaco, une ligne de terminal, un diagnostic — réveillait les cinq, et un
 * bouton latéral mettait plusieurs secondes à changer l'affichage. Le repli
 * ci-dessous sert aux bancs, qui jouent ce script seul, sans PSHotes. */
function suivreHote(selecteur, rappel) {
  /* L'objet rendu a les deux méthodes d'un MutationObserver : les scripts
   * existants appellent .disconnect() pour écarter leurs propres écritures
   * et .takeRecords() quand il existe. Rendre une simple fonction d'arrêt
   * casserait ces appels — c'est ce qu'a fait la première version. */
  const arret = { disconnect: function () {},
    takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const observateur = new MutationObserver(rappel);
  observateur.observe(document.documentElement,
    { subtree: true, childList: true });
  const filet = typeof setInterval === 'function'
    ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () {
    observateur.disconnect();
    if (filet) clearInterval(filet);
  };
  return arret;
}
function observerHote() {
  if (observateurHote) return;
  observateurHote = suivreHote('.ps-devweb-host',
    () => { differe('hote', attach, 120); });
}

window.PSDevWeb = {
  capacites: () => capacites,
  apercu: () => apercu,
  journal: () => entrees.slice(),
  demarrer: chemin => demarrerApercu(chemin).catch(erreur),
  arreter: () => arreterApercu().catch(erreur),
  auditer: cible => lancerAudit(cible || (apercu ? { url: apercu.url } : null)).catch(erreur),
  generer: id => ouvrirGenerateur(id),
  extrait: id => ouvrirExtrait(id),
  requete: url => ouvrirRequete(url),
  ouvrir: section => {
    if (section) ouvert[section] = true;
    rendre();
  },
  fermer: fermerFenetre,
  etat: () => ({ hote: !!hote, sections: Object.keys(ouvert).filter(k => ouvert[k]),
    entrees: entrees.length, apercu: apercu ? apercu.url : null,
    viewport: viewport, dernierAudit: dernierAudit ? dernierAudit.note_globale : null }),
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', attach, { once: true });
} else attach();
if (!window.PSHotes) setInterval(attach, 5000);
})();
