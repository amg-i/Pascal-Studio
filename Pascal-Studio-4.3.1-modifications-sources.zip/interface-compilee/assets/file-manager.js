/* Gestionnaire local et distant : connexions fournies par GVFS du système. */
(()=>{
'use strict';
const S={local:{kind:'local',path:'',items:[],selected:null},remote:{kind:'remote',id:null,path:'',items:[],selected:null},profiles:[],connections:new Map(),pending:new Set(),host:null,job:null,dialog:null,cancelDialog:null,questionShown:false,monitoring:new Set()};
const el=(tag,cls='',text)=>{let n=document.createElement(tag);if(cls)n.className=cls;if(text!==undefined)n.textContent=text;return n};
const btn=(text,fn,cls='')=>{let n=el('button',cls,text);n.type='button';n.onclick=()=>Promise.resolve().then(fn).catch(error);return n};
async function api(path,data){let res=await fetch('/api/'+path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),j=await res.json();if(!res.ok)throw Error(j.error||'Erreur du gestionnaire');return j}
function tell(msg,bad=false){let e=S.host?.querySelector('.psfm-status');if(e){e.textContent=msg;e.classList.toggle('bad',bad)}}
function error(e){tell(e?.message||String(e),true);alert(e?.message||String(e))}
function form(title,fields,accept='Valider'){
 return new Promise(resolve=>{
  if(!S.host?.isConnected){resolve(null);return}
  let shade=el('div','psfm-overlay'),box=el('form','psfm-dialog');box.append(el('h3','',title));if(title.includes('coffre'))box.append(el('p','psfm-message','Ancien coffre : saisissez son mot de passe maître une dernière fois pour activer le déverrouillage automatique. La clé locale permettra ensuite à toute personne ou programme ayant accès à votre compte Linux de récupérer les mots de passe enregistrés.'));let inputs={};
  for(const f of fields){let label=el('label','psfm-label',f.label);let input=f.type==='select'?el('select'):el('input');if(f.type==='select')for(const opt of f.options||[]){let o=el('option','',opt.label);o.value=opt.value;input.append(o)}else input.type=f.type||'text';input.name=f.name;if(f.type==='password')input.autocomplete='new-password';if(f.type==='checkbox')input.checked=!!f.value;else input.value=f.value||'';if(f.placeholder)input.placeholder=f.placeholder;if(f.required)input.required=true;label.append(input);box.append(label);inputs[f.name]=input}
  S.cancelDialog=()=>{shade.remove();S.dialog=null;S.cancelDialog=null;resolve(null)};let actions=el('div','psfm-actions');actions.append(btn('Annuler',S.cancelDialog));let submit=el('button','',accept);submit.type='submit';actions.append(submit);box.append(actions);box.onsubmit=e=>{e.preventDefault();let values={};for(let [key,input] of Object.entries(inputs))values[key]=input.type==='checkbox'?input.checked:input.value;shade.remove();S.dialog=null;S.cancelDialog=null;resolve(values)};shade.append(box);S.host.append(shade);S.dialog=shade;setTimeout(()=>Object.values(inputs)[0]?.focus(),0)
 })
}
async function askQuestion(j){if(S.questionShown||!j.question||!S.host?.isConnected)return;S.questionShown=true;try{let q=j.question,answer=null;if(q.type==='choice'){
  answer=await new Promise(resolve=>{let shade=el('div','psfm-overlay'),box=el('div','psfm-dialog');box.append(el('h3','','Vérification du serveur'),el('p','psfm-message',q.message));S.cancelDialog=()=>{shade.remove();S.dialog=null;S.cancelDialog=null;resolve(null)};let actions=el('div','psfm-actions');q.choices.forEach((text,i)=>actions.append(btn(text,()=>{shade.remove();S.dialog=null;S.cancelDialog=null;resolve(i)})));actions.append(btn('Annuler',S.cancelDialog));box.append(actions);shade.append(box);S.host.append(shade);S.dialog=shade})
 }else{let values=await form(q.message,[{name:'username',label:'Utilisateur',value:q.username},{name:'domain',label:'Domaine (SMB)',value:q.domain},{name:'password',label:'Mot de passe demandé par le serveur',type:'password'}], 'Connexion');answer=values}
 await api('fm/respond',{id:j.id,answer});}finally{S.questionShown=false}}
async function monitor(id=S.job){if(!id||S.monitoring.has(id))return;S.monitoring.add(id);try{let j=await api('fm/job?id='+encodeURIComponent(id));let known=S.connections.get(id);if(j.state==='question'){tell('La connexion attend votre réponse.');await askQuestion(j)}else if(j.state==='connected'){S.pending.delete(id);if(!known){S.connections.set(j.id,{id:j.id,uri:j.uri,path:'',items:[],selected:null,state:'connected'});switchConnection(j.id);await profiles();await load(S.remote);if(j.warning)tell(j.warning,true)}else if(known.state!=='connected'){known.state='connected';if(S.remote.id===id)await load(S.remote);tell('Connexion rétablie : '+j.uri)}}else if(j.state==='error'){if(known){if(known.state!=='error')tell('Connexion interrompue : '+j.error+' Utilisez Réessayer.',true);known.state='error'}else if(S.pending.has(id)){S.pending.delete(id);if(S.job===id)S.job=null;tell('Connexion impossible : '+j.error,true);alert('Connexion impossible : '+j.error)}}else{if(known)known.state='connecting';tell('Connexion ou reconnexion en cours…')}}catch(e){tell('Affichage du serveur impossible : '+e.message+' — cliquez sur Actualiser dans le panneau Serveur distant.',true)}finally{S.monitoring.delete(id)}}
setInterval(()=>{for(let id of new Set([...S.connections.keys(),...S.pending]))monitor(id)},2000);
async function profiles(){let r=await api('fm/profiles');S.profiles=r.profiles;S.home=r.home;if(!S.local.path)S.local.path=r.workspace||r.home;renderProfiles()}
async function forgetProfile(p){if(!confirm('Oublier cette connexion et supprimer son mot de passe enregistré ?'))return;let v=await api('fm/vault-status');if(v.exists&&!await unlockVault())return;await api('fm/forget',{uri:p.uri,deletePassword:v.exists});await profiles();tell('Connexion oubliée.')}
function renderProfiles(){
 let select=S.host?.querySelector('.psfm-profiles');if(select){select.replaceChildren(el('option','','Accès enregistrés…'));for(let p of S.profiles){let o=el('option','',p.uri);o.value=p.uri;select.append(o)}}
 let card=S.host?.querySelector('.psfm-saved');if(!card)return;card.replaceChildren(el('strong','','Connexions enregistrées'));
 card.append(el('p','psfm-saved-note',S.profiles.length?'Sélectionnez une connexion ci-dessous. Une configuration enregistrée n’est pas nécessairement validée par le serveur.':'Aucune connexion enregistrée. Cliquez sur Nouvelle connexion… et laissez « Enregistrer la connexion » coché : elle restera visible même si la connexion échoue.'));
 for(let p of S.profiles){let row=el('div','psfm-saved-row'),info=el('div','psfm-saved-info');info.append(el('strong','',p.uri),el('span','',p.username?'Utilisateur : '+p.username:'Utilisateur non renseigné'));row.append(info,btn('Se connecter',()=>connectSaved(p)),btn('Modifier',()=>connect(p)),btn('Oublier',()=>forgetProfile(p)));card.append(row)}
}
function dirname(p){if(!p)return '';if(p==='/')return '/';let i=p.lastIndexOf('/');return i<0?'':i===0?'/':p.slice(0,i)}
function full(p,name){return p.kind==='local'?(p.path==='/'?'/'+name:p.path+'/'+name):(p.path?p.path+'/':'')+name}
async function load(p){
 if(p.kind==='remote'&&!p.id){p.items=[];p.failed='';render(p);return}
 if(p.kind==='remote')tell('Lecture du dossier distant '+(p.path||'/')+'…');
 try{let r=await api('fm/list',{kind:p.kind,id:p.id,path:p.path});p.items=r.items;p.path=r.path;p.selected=null;p.failed='';render(p);
 if(r.truncated)tell('Liste limitée aux 10 000 premiers éléments.');else if(p.kind==='remote')tell(r.items.length?'Dossier distant '+(p.path||'/')+' : '+r.items.length+' élément(s). Double-cliquez sur un dossier pour y entrer.':'Le dossier distant '+(p.path||'/')+' est vide. Vérifiez le dossier initial ou les droits ; cliquez sur Actualiser pour réessayer.');else if(!S.remote.id)tell('Prêt.')
 }catch(e){if(p.kind==='remote'){p.items=[];p.failed=e.message;render(p);tell('Lecture du dossier distant impossible : '+e.message+'. Vérifiez le chemin et les droits, puis cliquez sur Actualiser.',true)}throw e}
}
function render(p){let card=S.host?.querySelector('[data-pane="'+p.kind+'"]');if(!card)return;let path=card.querySelector('.psfm-path');path.value=p.path||(p.kind==='remote'?'/':'');let list=card.querySelector('.psfm-list');list.replaceChildren();if(!p.items.length){list.append(el('div','psfm-empty',p.kind==='remote'&&!p.id?'Aucune connexion sélectionnée. Cliquez sur Nouvelle connexion…':p.failed?'Impossible de lire ce dossier : '+p.failed+' — vérifiez le chemin et les droits.':'Aucun élément à afficher dans ce dossier.'));}for(const item of p.items){let row=el('button','psfm-row');row.type='button';row.append(el('span','psfm-icon',item.type==='folder'?'📁':item.type==='link'?'↗':item.type==='unknown'?'?':'▤'),el('span','psfm-name',item.name),el('span','psfm-size',item.type==='file'?formatSize(item.size):item.type==='link'?'lien':item.type==='unknown'?'type inconnu':''));if(p.selected===item.name)row.classList.add('selected');row.onclick=()=>{p.selected=item.name;render(p)};row.ondblclick=()=>{p.selected=item.name;open(p).catch(error)};list.append(row)}}
function formatSize(n){if(n==null)return '';return n<1024?n+' o':n<1048576?(n/1024).toFixed(1)+' Ko':(n/1048576).toFixed(1)+' Mo'}
function selected(p){let v=p.items.find(x=>x.name===p.selected);if(!v)throw Error('Sélectionnez un fichier ou un dossier.');return v}
async function open(p){let item=selected(p),path=full(p,item.name);if(item.type==='folder'){p.path=path;await load(p);return}if(item.type==='link')throw Error('Les liens ne sont pas ouverts depuis ce gestionnaire.');if(item.type==='unknown')throw Error('Le serveur ne fournit pas le type de cet élément. Actualisez ; vérifiez les droits et, si nécessaire, utilisez un autre client FTP.');if(p.kind==='local'){let entry=await api('external/open',{path});window.PSFMActivate(entry)}else{
 if(/\.(pdf|psnote)$/i.test(item.name))throw Error('Téléchargez d’abord les PDF et PSNote pour les ouvrir localement.');let key='@remote:'+p.id+'/'+path;if(window.PSFMOpenTabs?.().includes(key)){window.PSFMActivate({path:key});return}let entry=await api('fm/open',{id:p.id,path});window.PSFMActivate(entry)
 }}
async function create(p,type){if(p.kind==='remote'&&!p.id)throw Error('Connectez d’abord un accès distant.');let r=await form(type==='folder'?'Nouveau dossier':'Nouveau fichier',[{name:'name',label:'Nom',required:true}],'Créer');if(!r)return;await api('fm/operation',{kind:p.kind,id:p.id,path:p.path,action:'create',name:r.name,target:type});await load(p);tell('Élément créé.')}
function openConflict(p,path){let tabs=window.PSFMOpenTabs?.()||[],root=window.PSFMWorkspace?.()||'';return tabs.some(k=>{let candidate=k.startsWith('@external:')?k.slice(10):k.startsWith('@remote:')?k:root+'/'+k;let actual=p.kind==='remote'?'@remote:'+p.id+'/'+path:path;return candidate===actual||candidate.startsWith(actual+'/')})}
async function operate(p,action){let item=selected(p),path=full(p,item.name);if(openConflict(p,path))throw Error('Fermez d’abord les onglets de ce fichier ou de ce dossier avant de le modifier.');if(action==='delete'){
 if(!confirm('Supprimer définitivement « '+item.name+' » ? Les dossiers doivent être vides.'))return;await api('fm/operation',{kind:p.kind,id:p.id,path,action});
 }else{let r=await form('Renommer',[{name:'name',label:'Nouveau nom',value:item.name,required:true}],'Renommer');if(!r||r.name===item.name)return;await api('fm/operation',{kind:p.kind,id:p.id,path,action,name:r.name})}await load(p);tell('Opération terminée.')}
async function transfer(from,to){if(!S.remote.id)throw Error('Connectez d’abord un accès distant.');let item=selected(from);if(item.type!=='file')throw Error('Sélectionnez un fichier ordinaire ; les dossiers et les liens ne sont pas transférés.');let srcPath=full(from,item.name);tell('Transfert en cours : '+item.name+'…');await api('fm/transfer',{srcKind:from.kind,srcId:from.id,srcPath,dstKind:to.kind,dstId:to.id,dstDir:to.path,name:item.name});await load(to);tell('Transfert terminé : '+item.name)}
function connectionForm(profile){
 return new Promise(resolve=>{
  if(!S.host?.isConnected){resolve(null);return}
  let url;try{url=new URL(profile?.uri||'sftp://example.invalid/')}catch{url=new URL('sftp://example.invalid/')}
  let proto=['ftp:','ftps:','ftpis:','sftp:','smb:'].includes(url.protocol)?url.protocol.slice(0,-1):'sftp',ports={ftp:'21',ftps:'21',ftpis:'990',sftp:'22',smb:'445'};
  let shade=el('div','psfm-overlay'),box=el('form','psfm-dialog');box.append(el('h3','','Connexion distante'),el('p','psfm-message','Choisissez le protocole, puis saisissez le nom du serveur sans préfixe. FTPS et SFTP chiffrent la connexion si le serveur les prend en charge. FTPS ne revient jamais automatiquement au FTP simple.'));
  let choices=el('div','psfm-protocols'),buttons={};let port,share,folder,testButton;
  function choose(name){let old=proto;proto=name;for(let [k,b] of Object.entries(buttons)){b.classList.toggle('selected',k===name);b.setAttribute('aria-pressed',String(k===name))}if(port&&(!port.value||port.value===ports[old]))port.value=ports[name];if(share)share.parentElement.hidden=name!=='smb';if(folder)folder.parentElement.hidden=name==='smb';if(testButton)testButton.hidden=!['ftp','ftps','ftpis'].includes(name)}
  for(const name of ['ftp','ftps','ftpis','sftp','smb']){let labels={ftp:'FTP simple',ftps:'FTPS explicite',ftpis:'FTPS implicite',sftp:'SFTP',smb:'SMB'};let b=el('button','',labels[name]);b.type='button';b.onclick=()=>choose(name);buttons[name]=b;choices.append(b)}box.append(choices);
  function field(label,type,value,required=false){let l=el('label','psfm-label',label),x=el('input');x.type=type;x.value=value||'';x.required=required;l.append(x);box.append(l);return x}
  let host=field('Serveur (exemple : ftp.cluster027.hosting.ovh.net)','text',profile?url.hostname:'',true);
  port=field('Port','number',url.port||ports[proto],true);port.min='1';port.max='65535';
  share=field('Partage SMB (et sous-dossier éventuel)','text',proto==='smb'?decodeURIComponent(url.pathname.replace(/^\/+|\/+$/g,'')):'');
  folder=field('Dossier initial (facultatif)','text',proto!=='smb'?decodeURIComponent(url.pathname.replace(/^\/+|\/+$/g,'')):'');
  let username=field('Utilisateur FTP, SFTP ou SMB','text',profile?.username||decodeURIComponent(url.username||''));
  let domain=field('Domaine SMB (facultatif)','text',profile?.domain||'');
  let password=field('Mot de passe du serveur (ou vide pour une clé SSH ou un mot de passe enregistré)','password','');
  let remember=field('Enregistrer la connexion (même en cas d’échec)','checkbox','');remember.checked=true;
  let savePassword=field('Mémoriser le mot de passe sans saisie au démarrage','checkbox','');savePassword.checked=true;
  box.append(el('p','psfm-message','Les mots de passe sont chiffrés, mais la clé est enregistrée sur ce compte Linux : toute personne ou tout programme ayant accès au compte peut les récupérer. Après « Connecter », le mot de passe n’est enregistré que si la connexion a réussi. « Enregistrer sans connecter » l’enregistre sans vérifier sa validité.'));
  let testResult=el('p','psfm-test-result');box.append(testResult);
  function values(){
   let raw=host.value.trim();if(!raw)throw Error('Indiquez le nom du serveur.');
   if(/^[a-z][a-z0-9+.-]*:\/\//i.test(raw)){let pasted=new URL(raw);if(pasted.username||pasted.password||pasted.search||pasted.hash||pasted.pathname!=='/'&&pasted.pathname!=='')throw Error('Saisissez seulement le nom du serveur, sans chemin ni identifiants.');raw=pasted.hostname;if(pasted.port)port.value=pasted.port}
   if(/[\/@?#\s]/.test(raw))throw Error('Nom de serveur invalide.');
   let n=Number(port.value);if(!Number.isInteger(n)||n<1||n>65535)throw Error('Port invalide.');
   let relative=(proto==='smb'?share.value:folder.value).trim().replace(/^\/+|\/+$/g,'');
   if((proto==='smb'&&!relative)||(relative&&relative.split('/').some(x=>!x||x==='.'||x==='..')))throw Error(proto==='smb'?'Indiquez un partage SMB valide.':'Dossier initial invalide.');
   let path=relative?relative.split('/').map(encodeURIComponent).join('/'):'';
   let authority=raw.includes(':')&&!raw.startsWith('[')?'['+raw+']':raw;
   if(['ftp','ftps','ftpis'].includes(proto)&&username.value)authority=encodeURIComponent(username.value)+'@'+authority;
   let uri=proto+'://'+authority+':'+n+'/'+path;
   if(profile&&url.protocol===proto+':'&&url.hostname===raw&&Number(url.port||ports[proto])===n&&decodeURIComponent(url.pathname.replace(/^\/+|\/+$/g,''))===relative&&(profile.username||decodeURIComponent(url.username||''))===username.value)uri=profile.uri;
   return {uri,username:username.value,domain:domain.value.trim(),password:password.value,remember:remember.checked,savePassword:savePassword.checked}
  }
  S.cancelDialog=()=>{password.value='';shade.remove();S.dialog=null;S.cancelDialog=null;resolve(null)};let actions=el('div','psfm-actions');actions.append(btn('Annuler',S.cancelDialog));
  testButton=btn('Tester la connexion FTP / FTPS',async()=>{
   let r=values();if(!['ftp','ftps','ftpis'].includes(proto))throw Error('Choisissez FTP ou FTPS pour ce test.');
   if(!confirm(proto==='ftp'?'Ce test effectue une seule tentative FTP. Les identifiants circuleront sans chiffrement. Continuer ?':'Ce test effectue une seule tentative FTPS chiffrée et vérifie le certificat du serveur. Continuer ?'))return;
   if(!r.password&&profile){let status=await api('fm/vault-status');if(status.mode==='master')throw Error('Pour utiliser l’ancien mot de passe enregistré, fermez ce formulaire et cliquez d’abord sur Se connecter dans Connexions enregistrées afin de migrer le coffre. Vous pouvez aussi saisir le mot de passe serveur ici.');if(status.mode!=='auto'||!status.unlocked)throw Error('Aucun coffre automatique disponible : saisissez le mot de passe serveur pour ce test.');r.useSavedPassword=true}
   testButton.disabled=true;testResult.textContent='Test FTP / FTPS en cours…';testResult.classList.remove('bad');
   try{let result=await api('fm/ftp-test',r);testResult.textContent=result.message;testResult.classList.toggle('bad',!result.ok)}catch(err){testResult.textContent=err.message;testResult.classList.add('bad')}finally{r.password='';testButton.disabled=false}
  });actions.append(testButton);actions.append(btn('Enregistrer sans connecter',()=>{let result=values();result.saveOnly=true;result.remember=true;password.value='';shade.remove();S.dialog=null;S.cancelDialog=null;resolve(result)}));let submit=el('button','','Connecter');submit.type='submit';actions.append(submit);box.append(actions);choose(proto);
  box.onsubmit=e=>{e.preventDefault();try{let result=values();password.value='';shade.remove();S.dialog=null;S.cancelDialog=null;resolve(result)}catch(err){alert(err.message)}};shade.append(box);S.host.append(shade);S.dialog=shade;host.focus()
 })
}
async function unlockVault(){
 let status=await api('fm/vault-status');
 if(status.mode==='auto'&&status.unlocked)return true;
 if(status.mode==='none'||status.unlocked){await api('fm/vault-auto',{});return true}
 while(true){
  let values=await form('Ancien coffre : saisie unique du mot de passe maître',[{name:'master',label:'Mot de passe maître de la version précédente',type:'password',required:true}],'Activer le déverrouillage automatique');if(!values)return false;
  try{await api('fm/vault-auto',{master:values.master});values.master='';return true}
  catch(e){values.master='';alert(e.message);await new Promise(r=>setTimeout(r,700))}
 }
}
async function importFileZilla(){
 if(!confirm('Lire les sites et connexions récentes de FileZilla sur cet ordinateur pour en choisir un ? Aucun mot de passe ne sera affiché. Le dossier initial et les réglages avancés ne sont pas importés.'))return;
 let r=await api('fm/filezilla-sites');if(!r.sites.length)throw Error('Aucun site compatible trouvé dans la configuration locale de FileZilla. Les fichiers de sites enregistrés ou de connexions récentes doivent être accessibles sur ce compte. '+(r.warnings||[]).join(' '));
 let opts=r.sites.map(x=>({value:x.token,label:x.name+' — '+x.uri+' — '+x.source+' — '+x.protocol}));
 let v=await form('Importer une connexion FileZilla',[{name:'token',label:'Site à importer (mot de passe jamais affiché)',type:'select',options:opts,value:opts[0].value,required:true}],'Importer');if(!v)return;
 let site=r.sites.find(x=>x.token===v.token);if(!site)throw Error('Site introuvable ; recommencez l’import.');
 let plain=false;
 if(site.opportunistic){plain=confirm('FileZilla essaie TLS puis peut revenir au FTP non chiffré. Pascal Studio va importer ce site en FTP SIMPLE, sans essayer TLS : le mot de passe et les fichiers circuleront en clair. Acceptez-vous explicitement ce mode ? Pour exiger TLS, annulez et créez une connexion FTPS explicite.');if(!plain)return}
 else if(site.uri.startsWith('ftp://')&&!confirm('Ce site sera importé en FTP simple : mot de passe et données circuleront en clair. Continuer ?'))return;
 if(site.password_state==='base64'){
  if(!confirm('Importer aussi le mot de passe enregistré par FileZilla dans le coffre local de Pascal Studio ? Si le même accès y existe déjà, son mot de passe sera remplacé.'))return;
  if(!await unlockVault())return
 }else if(!confirm(site.password_state==='chiffre'?'Le mot de passe FileZilla est protégé par son mot de passe maître et ne peut pas être importé automatiquement. Importer uniquement les paramètres ?':'Aucun mot de passe importable n’a été trouvé pour ce site. Importer uniquement les paramètres ?'))return;
 let out=await api('fm/filezilla-import',{token:site.token,plainAcknowledged:plain});await profiles();tell(out.passwordImported?'Site FileZilla et mot de passe importés localement. Sélectionnez Se connecter.':'Site FileZilla importé sans mot de passe. Cliquez sur Modifier pour le saisir.');alert(out.passwordImported?'Site et mot de passe importés sans les afficher. Retrouvez la ligne dans Connexions enregistrées et cliquez sur Se connecter.':'Site importé sans mot de passe. Retrouvez-le dans Connexions enregistrées, puis cliquez sur Modifier pour saisir le mot de passe.');
}
async function startConnection(r){
 if(r.uri.toLowerCase().startsWith('ftp://')&&!confirm('FTP transmet les identifiants et données sans chiffrement. Utilisez FTPS ou SFTP si possible. Continuer ?'))return;
 if(r.uri.toLowerCase().startsWith('smb://')&&!confirm('Le chiffrement SMB dépend du serveur et de sa configuration. Continuer ?'))return;
 let j=await api('fm/connect',r);r.password='';await profiles();S.job=j.id;S.pending.add(j.id);tell('Connexion en cours…');await monitor(j.id)
}
async function connect(profile){
 let r=await connectionForm(profile);if(!r)return;
 if(r.saveOnly){
  if(r.savePassword&&r.password&&!await unlockVault()){r.password='';tell('Enregistrement annulé : ancien coffre non déverrouillé.',true);return}
  await api('fm/save-profile',r);r.password='';await profiles();tell('Connexion enregistrée sans vérification du serveur.');return
 }
 if(r.savePassword){let ok=await unlockVault();if(!ok){if(!confirm('Coffre non déverrouillé. Se connecter sans enregistrer ni utiliser le mot de passe du coffre ?'))return;r.savePassword=false}else if(!r.password)r.useSavedPassword=true}
 await startConnection(r)
}
async function connectSaved(profile){
 if(!profile)throw Error('Sélectionnez une connexion enregistrée.');
 let status=await api('fm/vault-status');let unlocked=false;
 if(status.exists){unlocked=await unlockVault();if(!unlocked)return}
 else {return connect(profile)}
 await startConnection({uri:profile.uri,username:profile.username||'',domain:profile.domain||'',password:'',remember:true,savePassword:unlocked,useSavedPassword:unlocked})
}

function switchConnection(id){
 if(S.remote.id&&S.connections.has(S.remote.id)){let old=S.connections.get(S.remote.id);old.path=S.remote.path;old.items=S.remote.items;old.selected=S.remote.selected}
 let next=S.connections.get(id);Object.assign(S.remote,next?{id:next.id,path:next.path,items:next.items,selected:next.selected}:{id:null,path:'',items:[],selected:null});renderConnections();render(S.remote)
}
function renderConnections(){let select=S.host?.querySelector('.psfm-active');if(!select)return;select.replaceChildren(el('option','','Connexions actives…'));for(let c of S.connections.values()){let o=el('option','',c.uri);o.value=c.id;select.append(o)}select.value=S.remote.id||''}
async function retryConnection(){if(!S.remote.id)throw Error('Choisissez une connexion.');let j=await api('fm/reconnect',{id:S.remote.id});S.job=j.id;S.pending.add(j.id);tell('Reconnexion en cours…');await monitor(j.id)}
async function disconnect(){let id=S.remote.id;if(!id)return;if(!await window.PSSaveAll?.())throw Error('Enregistrez les fichiers ouverts avant de fermer la connexion.');if((window.PSFMOpenTabs?.()||[]).some(x=>x.startsWith('@remote:'+id+'/')))throw Error('Fermez les fichiers distants ouverts avant de fermer la connexion.');await api('fm/disconnect',{id});S.connections.delete(id);S.pending.delete(id);if(S.job===id)S.job=null;S.remote.id=null;switchConnection(S.connections.keys().next().value);tell('Connexion retirée du gestionnaire ; le montage GVFS partagé peut rester actif.')}
function help(){if(S.dialog)return;let shade=el('div','psfm-overlay'),box=el('div','psfm-dialog');box.append(el('h3','','Aide · Gestionnaire de fichiers et accès distants'));let entries=(window.PS_LATEX_HELP?.articles||[]).filter(x=>x.lang==='Gestionnaire de fichiers');if(entries.length){let last='';for(let item of entries){if(item.group!==last){last=item.group;box.append(el('h3','',last))}let section=el('section','psfm-help-section');section.append(el('h4','',item.title));for(let block of item.blocks||[]){if(block.text)section.append(el('p','psfm-message',block.text));if(block.code)section.append(el('pre','psfm-help-code',block.code))}box.append(section)}}else box.append(el('p','psfm-message','La documentation du gestionnaire est indisponible. Consultez le guide fourni.'));let done=()=>{shade.remove();S.dialog=null;S.cancelDialog=null};S.cancelDialog=done;box.append(btn('Fermer',done));shade.append(box);S.host.append(shade);S.dialog=shade}
async function openRemoteProject(){
 if(!S.remote.id)throw Error('Connectez d’abord un accès distant.');
 let folder=S.remote.path||'/';
 if(!confirm('Ouvrir le dossier distant « '+folder+' » comme projet ? Une copie locale sera créée et synchronisée. Les conflits seront conservés pour votre choix.'))return;
 let j=await api('remote-project/prepare',{id:S.remote.id,path:S.remote.path});let initialId=j.id;
 while(j.phase==='preparation'){
  tell(j.progress||'Préparation de la copie locale…');await new Promise(r=>setTimeout(r,700));j=await api('remote-project/job?id='+encodeURIComponent(j.id||initialId))
 }
 if(j.phase==='error')throw Error(j.error);
 if(!j.workspace)throw Error('Copie locale indisponible.');
 tell('Copie prête. Ouverture du projet…');await window.PSFMSetProject(j.workspace)
}
function projectHelp(){alert('OUVRIR UN PROJET EXISTANT\n1. Connectez-vous au serveur.\n2. Dans le panneau de droite, double-cliquez sur le dossier qui contient votre projet (vous pouvez entrer dans plusieurs sous-dossiers).\n3. Cliquez sur « Ouvrir ce dossier comme projet ». Attendez la copie locale.\n\nCRÉER UN PROJET\nOuvrez d’abord le dossier parent sur le serveur, puis cliquez sur « Créer un projet distant… » et donnez-lui un nom. Un dossier et un fichier main.pas seront créés.\n\nLa compilation se fait sur le PC ; le badge Projet distant indique les conflits, les erreurs et la synchronisation. Consultez ? Aide pour les limites et les sauvegardes.')}
async function createRemoteProject(){
 let p=S.remote;if(!p.id)throw Error('Connectez-vous d’abord, puis ouvrez le dossier parent à droite.');
 let r=await form('Créer un projet distant',[{name:'name',label:'Nom du nouveau dossier de projet',required:true}],'Créer');if(!r)return;
 let name=r.name.trim();if(!name||name==='.'||name==='..'||name.includes('/')||name.includes('\\'))throw Error('Nom de projet invalide.');
 let parent=p.path,project=parent?parent+'/'+name:name;
 await api('fm/operation',{kind:'remote',id:p.id,path:parent,action:'create',name,target:'folder'});
 try{
  await api('fm/operation',{kind:'remote',id:p.id,path:project,action:'create',name:'main.pas',target:'file'});
  let entry=await api('fm/open',{id:p.id,path:project+'/main.pas'});
  await api('save',{path:entry.path,content:"program MonProgramme;\n\n{$mode objfpc}{$H+}\n\nbegin\n  WriteLn('Bonjour Pascal !');\nend.\n"})
 }catch(e){throw Error('Dossier créé, mais fichier initial non créé : '+e.message+'. Vous pouvez ouvrir ce dossier et ajouter vos fichiers.')}
 p.path=project;await load(p);await openRemoteProject()
}
function panel(p){let card=el('section','psfm-panel');card.dataset.pane=p.kind;let top=el('div','psfm-title');top.append(el('strong','',p.kind==='local'?'Ordinateur':'Serveur distant'));let tools=el('div','psfm-tools');tools.append(btn('↑',async()=>{p.path=dirname(p.path);await load(p)}),btn('Actualiser',()=>load(p)),btn('+ Fichier',()=>create(p,'file')),btn('+ Dossier',()=>create(p,'folder')),btn('Renommer',()=>operate(p,'rename')),btn('Supprimer',()=>operate(p,'delete')));let path=el('input','psfm-path');path.placeholder=p.kind==='local'?'/home/utilisateur':'/';path.onkeydown=e=>{if(e.key==='Enter'){p.path=p.kind==='remote'?path.value.replace(/^\/+|\/+$/g,''):path.value;load(p).catch(error)}};let list=el('div','psfm-list');card.append(top,tools,path);if(p.kind==='remote'){let bar=el('div','psfm-project-actions');bar.append(btn('Ouvrir ce dossier comme projet',openRemoteProject,'psfm-primary'),btn('Créer un projet distant…',createRemoteProject),btn('? Projet distant',projectHelp));card.append(bar)}card.append(list,btn('Ouvrir la sélection',()=>open(p),'psfm-open'));return card}
function mount(){let host=document.querySelector('.psfm-host');if(!host){S.cancelDialog?.();S.host=null;return}if(host===S.host)return;S.host=host;S.dialog=null;host.replaceChildren();let header=el('div','psfm-header');header.append(el('h2','','Gestionnaire de fichiers'),btn('Nouvelle connexion…',()=>connect(null)),btn('Importer depuis FileZilla…',importFileZilla));let select=el('select','psfm-profiles');let active=el('select','psfm-active');active.onchange=()=>{switchConnection(active.value);if(S.remote.id)load(S.remote).catch(error)};header.append(active,btn('Réessayer',retryConnection),btn('Fermer la connexion',disconnect),select,btn('Connecter l’accès',()=>connectSaved(S.profiles.find(x=>x.uri===select.value))),btn('Modifier l’accès…',()=>{let profile=S.profiles.find(x=>x.uri===select.value);if(!profile)throw Error('Sélectionnez une connexion enregistrée.');return connect(profile)}),btn('? Aide',help),btn('Oublier l’accès',async()=>{let uri=select.value;if(!uri)return;if(!confirm('Oublier cette connexion et supprimer son mot de passe du coffre de Pascal Studio ? Les secrets éventuellement présents dans le trousseau système ne sont pas supprimés.'))return;let v=await api('fm/vault-status');if(v.exists&&!await unlockVault())return;await api('fm/forget',{uri,deletePassword:v.exists});await profiles()}));let sub=el('p','psfm-sub','1. Connectez-vous.  2. À droite, double-cliquez sur le dossier du projet.  3. Cliquez sur « Ouvrir ce dossier comme projet » ; ou choisissez « Créer un projet distant ». Le code, LaTeX et PSNote seront utilisés depuis une copie locale synchronisée.');let panes=el('div','psfm-panes');panes.append(panel(S.local),panel(S.remote));let xfer=el('div','psfm-transfers');xfer.append(btn('Envoyer vers le serveur →',()=>transfer(S.local,S.remote)),btn('← Télécharger vers l’ordinateur',()=>transfer(S.remote,S.local)));let status=el('div','psfm-status','Initialisation…');let saved=el('section','psfm-saved');host.append(header,saved,sub,panes,xfer,status);renderConnections();profiles().then(()=>Promise.all([load(S.local),load(S.remote)])).then(()=>monitor()).catch(error)}
new MutationObserver(mount).observe(document.documentElement,{childList:true,subtree:true});mount();
})();
