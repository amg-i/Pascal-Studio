/* Visionneuse d'images de Pascal Studio (4.3.0).
 *
 * POURQUOI
 *   Ouvrir une image donnait un éditeur de texte plein d'octets illisibles : le
 *   bundle ne connaît pas les images, et `.png` est même l'extension de Piet.
 *   Un fichier qu'on ne peut pas voir n'est pas un fichier qu'on peut utiliser.
 *
 * OÙ ÇA S'AFFICHE
 *   Dans un VRAI onglet : patch_interface_4.3.py ajoute au bundle la branche qui
 *   rend `.ps-image-host[data-path]` pour les extensions d'images, exactement
 *   comme il rend déjà `.ps-document-host` pour les PDF et `.ps-data-host` pour
 *   les bases. Double-cliquer une image dans l'arborescence l'ouvre donc comme
 *   n'importe quel autre fichier, avec son onglet, sa croix et son raccourci.
 *   Le SVG reste dans Monaco : c'est du texte, et le lui voler serait une perte.
 *
 *   Si le bundle n'est PAS patché (base antérieure, patch refusé), la visionneuse
 *   s'ouvre quand même, en vue déléguée par window.PSVues : PSImages.ouvrir().
 *   Une fonctionnalité ne doit pas disparaître parce qu'un autre morceau manque.
 *
 * CE QUE CE SCRIPT NE FAIT PAS, ET POURQUOI
 *   Il ne redessine jamais l'image. Les dimensions viennent de l'en-tête du
 *   fichier (module images.py, sans bibliothèque d'images), et le
 *   redimensionnement est laissé au navigateur : le faire côté serveur
 *   produirait une image dégradée que l'utilisateur prendrait pour l'originale.
 *
 * Aucune ressource externe : pas de police distante, pas d'icône en image.
 */
(() => {
'use strict';

const API = '/api/image';
const HOTE = '.ps-image-host';
const ID_VUE = 'images';
const TITRE_VUE = 'Images';
const ICONE_VUE = '▣';
const ZOOMS = [0.1, 0.25, 0.5, 0.75, 1, 1.5, 2, 3, 4, 8];
const FONDS = ['damier', 'sombre', 'clair'];

const $ = (s, b) => (b || document).querySelector(s);

function el(nom, attributs) {
  const n = document.createElement(nom);
  const reste = Array.prototype.slice.call(arguments, 2);
  if (attributs) {
    Object.keys(attributs).forEach(function (cle) {
      const v = attributs[cle];
      if (v === null || v === undefined || v === false) return;
      if (cle === 'class') n.className = String(v);
      else if (cle === 'texte') n.textContent = String(v);
      else if (cle === 'html') n.innerHTML = String(v);
      else if (cle.slice(0, 2) === 'on' && typeof v === 'function') n.addEventListener(cle.slice(2), v);
      else n.setAttribute(cle, String(v));
    });
  }
  reste.forEach(function (e) {
    if (e === null || e === undefined || e === false) return;
    n.appendChild(typeof e === 'object' ? e : document.createTextNode(String(e)));
  });
  return n;
}

function vider(n) {
  if (!n) return n;
  if (typeof n.replaceChildren === 'function') { try { n.replaceChildren(); return n; } catch (e) {} }
  while (n.firstChild) {
    const f = n.firstChild;
    if (n.removeChild) { try { n.removeChild(f); continue; } catch (e) {} }
    if (f.remove) f.remove(); else break;
  }
  return n;
}

function boutons(titre, action, classe, infobulle) {
  const b = el('button', { class: 'psim-btn' + (classe ? ' ' + classe : ''),
    type: 'button', title: infobulle || titre, 'aria-label': infobulle || titre });
  b.textContent = titre;
  b.addEventListener('click', function (evt) {
    if (evt && evt.stopPropagation) evt.stopPropagation();
    action();
  });
  return b;
}

function octetsLisibles(n) {
  if (!(n > 0)) return '0 o';
  const unites = ['o', 'Ko', 'Mo', 'Go'];
  let i = 0, v = n;
  while (v >= 1024 && i < unites.length - 1) { v /= 1024; i += 1; }
  return (i === 0 ? v : v.toFixed(1)) + ' ' + unites[i];
}

/* --------------------------------------------------------------- l'état ---- */
/* Par chemin : le zoom et le fond sont propres à chaque image, et doivent
 * survivre au changement d'onglet. Un état global ferait qu'ouvrir une seconde
 * image réinitialise la première — ce qui se remarque immédiatement. */
const etats = Object.create(null);
let hote = null;
let cheminCourant = null;
let chargements = Object.create(null);

function etatPour(chemin) {
  if (!etats[chemin]) {
    etats[chemin] = { chemin: chemin, zoom: 'ajuster', fond: 'damier',
      image: null, voisins: [], position: -1, message: '', niveau: 'info',
      chargee: false };
  }
  return etats[chemin];
}

function apiServeur(action, champs) {
  const corps = Object.assign({ action: action }, champs || {});
  return fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(corps)
  }).then(function (reponse) {
    return reponse.json().catch(function () {
      throw new Error('Réponse illisible (HTTP ' + reponse.status + ').');
    }).then(function (json) {
      if (!reponse.ok) {
        throw new Error((json && (json.error || json.erreur)) ||
          ('Le serveur a répondu HTTP ' + reponse.status + '.'));
      }
      if (json && json.ok === false) {
        throw new Error(json.erreur || json.error || json.message ||
          'Refusé par le serveur.');
      }
      return json;
    });
  });
}

function statut(chemin, message, niveau) {
  const et = etatPour(chemin);
  et.message = String(message || '');
  et.niveau = niveau || 'info';
  if (cheminCourant === chemin) rendre();
}

/* ------------------------------------------------------------------ rendu -- */

function construire(chemin) {
  const et = etatPour(chemin);
  const racine = el('div', { class: 'psim', 'data-chemin': chemin });

  const entete = el('div', { class: 'psim-entete' },
    el('span', { class: 'psim-icone', texte: '▣' }),
    el('b', { class: 'psim-nom', texte: et.image ? et.image.nom : chemin.split('/').pop() }),
    el('span', { class: 'psim-pousse' }));

  const barre = el('div', { class: 'psim-barre' });
  const info = et.image;
  if (info && info.ok) {
    const morceaux = [];
    if (info.format) morceaux.push(info.format);
    if (info.dimensions_connues) morceaux.push(info.largeur + ' × ' + info.hauteur + ' px');
    else morceaux.push('dimensions inconnues');
    morceaux.push(octetsLisibles(info.taille));
    if (info.modifie) morceaux.push('modifiée le ' + info.modifie);
    barre.append(el('span', { class: 'psim-meta', texte: morceaux.join(' · ') }));
  }

  /* Le zoom. « Ajuster » et « 100 % » sont deux besoins différents : l'un pour
   * voir l'image entière, l'autre pour juger un pixel. Les deux doivent être à
   * un clic. */
  const zoom = el('div', { class: 'psim-zoom' },
    boutons('−', function () { changerZoom(chemin, -1); }, '', 'Dézoomer'),
    el('span', { class: 'psim-zoom-val',
      texte: et.zoom === 'ajuster' ? 'ajustée' : Math.round(et.zoom * 100) + ' %' }),
    boutons('+', function () { changerZoom(chemin, 1); }, '', 'Zoomer'),
    boutons('1:1', function () { et.zoom = 1; rendre(); }, '', 'Taille réelle (100 %)'),
    boutons('Ajuster', function () { et.zoom = 'ajuster'; rendre(); }, '',
      'Ajuster à la fenêtre'));

  const fond = el('div', { class: 'psim-fond' });
  FONDS.forEach(function (f) {
    fond.append(boutons(f.charAt(0).toUpperCase() + f.slice(1), function () {
      et.fond = f; rendre();
    }, et.fond === f ? 'psim-actif' : '', 'Fond ' + f + ' — utile pour juger la transparence'));
  });

  const navigation = el('div', { class: 'psim-nav' });
  if (et.voisins.length > 1) {
    navigation.append(
      boutons('‹', function () { naviguer(chemin, -1); }, '', 'Image précédente du dossier'),
      el('span', { class: 'psim-nav-val',
        texte: (et.position + 1) + '/' + et.voisins.length }),
      boutons('›', function () { naviguer(chemin, 1); }, '', 'Image suivante du dossier'));
  } else {
    navigation.append(el('span', { class: 'psim-meta',
      texte: 'Seule image du dossier' }));
  }

  entete.append(barre);
  racine.append(entete,
    el('div', { class: 'psim-outils' }, zoom, fond, navigation));

  /* Le PNG peut être un programme Piet. Le dire est utile ; proposer la
   * conversion en source texte l'est davantage : un programme doit pouvoir
   * s'éditer comme un programme. */
  if (info && info.piet && info.piet.est_piet) {
    racine.append(el('div', { class: 'psim-piet' },
      el('span', { class: 'psim-piet-texte',
        texte: 'Ce PNG est un programme Piet : ' + info.piet.couleurs +
          ' couleur(s) dans la palette, codel de ' + info.piet.codel + ' px.' }),
      boutons('Convertir en source texte (.piett)', function () {
        convertir(chemin);
      }, 'psim-primaire', 'Écrit le fichier .piett correspondant et l’ouvre')));
  } else if (info && info.piet && info.piet.raison) {
    racine.append(el('div', { class: 'psim-piet psim-piet-non' },
      el('span', { class: 'psim-piet-texte', texte: info.piet.raison })));
  }

  const corps = el('div', { class: 'psim-corps psim-fond-' + et.fond });
  if (info && info.ok && info.uri) {
    const img = el('img', { class: 'psim-img', src: info.uri,
      alt: 'Image ' + (info.nom || chemin) });
    if (et.zoom === 'ajuster') {
      img.classList.add('psim-ajustee');
    } else {
      img.classList.add('psim-reelle');
      img.style.width = Math.round((info.largeur || 0) * et.zoom) + 'px';
      img.style.height = Math.round((info.hauteur || 0) * et.zoom) + 'px';
    }
    img.addEventListener('error', function () {
      statut(chemin, 'Le navigateur n’a pas pu afficher cette image, alors que ' +
        'son en-tête est lisible. Le format est peut-être pris en charge par le ' +
        'module mais pas par cette version d’Electron.', 'erreur');
    });
    corps.append(img);
  } else if (info && !info.ok) {
    corps.append(el('div', { class: 'psim-refus' },
      el('p', { class: 'psim-refus-titre', texte: 'Image non affichée' }),
      el('p', { class: 'psim-refus-texte', texte: info.erreur || 'Raison inconnue.' }),
      el('p', { class: 'psim-meta',
        texte: info.taille ? 'Taille sur disque : ' + octetsLisibles(info.taille) : '' })));
  } else if (et.chargee === false) {
    corps.append(el('div', { class: 'psim-meta', texte: 'Lecture en cours…' }));
  }

  racine.append(corps);
  racine.append(el('div', { class: 'psim-statut psim-' + et.niveau,
    texte: et.message || '' }));
  return racine;
}

function changerZoom(chemin, sens) {
  const et = etatPour(chemin);
  const courant = et.zoom === 'ajuster' ? 1 : et.zoom;
  let index = -1;
  for (let i = 0; i < ZOOMS.length; i += 1) {
    if (Math.abs(ZOOMS[i] - courant) < 0.001) { index = i; break; }
  }
  if (index < 0) {
    index = sens > 0 ? ZOOMS.length - 1 : 0;
    for (let i = 0; i < ZOOMS.length; i += 1) {
      if (sens > 0 ? ZOOMS[i] > courant : ZOOMS[i] < courant) { index = i; break; }
    }
  } else {
    index = Math.min(ZOOMS.length - 1, Math.max(0, index + sens));
  }
  et.zoom = ZOOMS[index];
  rendre();
}

function naviguer(chemin, sens) {
  const et = etatPour(chemin);
  if (!et.voisins.length) return;
  const base = et.position >= 0 ? et.position : 0;
  const cible = (base + sens + et.voisins.length) % et.voisins.length;
  const nom = et.voisins[cible];
  const dossier = chemin.slice(0, chemin.length - chemin.split('/').pop().length);
  ouvrirFichier(dossier + nom);
}

function convertir(chemin) {
  statut(chemin, 'Conversion du PNG en source texte…', 'info');
  apiServeur('convertir-piet', { chemin: chemin }).then(function (json) {
    const destination = (json && (json.destination || json.chemin)) || '';
    statut(chemin, 'Source Piet écrite : ' + destination +
      ' — ouverture dans l’éditeur Piet.', 'ok');
    ouvrirFichier(destination);
  }).catch(function (exc) {
    statut(chemin, 'Conversion impossible : ' +
      (exc && exc.message ? exc.message : String(exc)), 'erreur');
  });
}

/* Ouvre un fichier dans un onglet, par le canal du bundle s'il existe. */
function ouvrirFichier(chemin) {
  if (!chemin) return;
  if (typeof window.PSFMOpenTabs === 'function') {
    try { window.PSFMOpenTabs([chemin]); return; } catch (exc) { /* repli */ }
  }
  if (window.PSVues && window.PSVues.ouvrir) {
    charger(chemin);
    window.PSVues.ouvrir({ id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE,
      noeud: construire(chemin) });
  }
}

function charger(chemin) {
  const et = etatPour(chemin);
  if (chargements[chemin]) return chargements[chemin];
  const promesse = apiServeur('lire', { chemin: chemin }).then(function (json) {
    et.image = json || null;
    et.chargee = true;
    if (json && json.voisins && json.voisins.images) {
      et.voisins = json.voisins.images;
      et.position = json.voisins.position;
    }
    if (json && json.ok === false) {
      et.message = json.erreur || 'Image non lisible.';
      et.niveau = 'erreur';
    }
    delete chargements[chemin];
    if (cheminCourant === chemin) rendre();
    return json;
  }).catch(function (exc) {
    delete chargements[chemin];
    et.chargee = true;
    et.image = { ok: false, erreur: (exc && exc.message) ? exc.message : String(exc),
      nom: chemin.split('/').pop(), taille: 0 };
    et.message = et.image.erreur;
    et.niveau = 'erreur';
    if (cheminCourant === chemin) rendre();
  });
  chargements[chemin] = promesse;
  return promesse;
}

function rendre() {
  if (!hote) return;
  const chemin = hote.getAttribute ? hote.getAttribute('data-path') : cheminCourant;
  if (!chemin) return;
  cheminCourant = chemin;
  const et = etatPour(chemin);
  /* Le panneau écrit dans le DOM : son propre observateur verrait ses
   * écritures. On écarte ses enregistrements avant et après, comme les autres
   * panneaux le font depuis la 4.0.0. */
  if (observateur && observateur.takeRecords) {
    try { observateur.takeRecords(); } catch (exc) { /* ignoré */ }
  }
  vider(hote);
  hote.appendChild(construire(chemin));
  if (observateur && observateur.takeRecords) {
    try { observateur.takeRecords(); } catch (exc) { /* ignoré */ }
  }
  if (!et.chargee) charger(chemin);
}

let observateur = null;

function suivreHote(selecteur, rappel) {
  const arret = { disconnect: function () {}, takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    if (window.PSHotes.suivre.length) { /* contrat inchangé */ }
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const obs = new MutationObserver(rappel);
  obs.observe(document.documentElement, { subtree: true, childList: true });
  const filet = typeof setInterval === 'function' ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () { obs.disconnect(); if (filet) clearInterval(filet); };
  return arret;
}

function attache(noeud) {
  if (!noeud) return false;
  if (typeof noeud.isConnected === 'boolean') return noeud.isConnected;
  return !!noeud.parentNode;
}

function attach() {
  const cible = $(HOTE);
  if (!cible) {
    if (hote && !attache(hote)) { hote = null; cheminCourant = null; }
    return;
  }
  if (cible === hote && attache(cible.firstChild)) {
    /* Même hôte, même chemin : rien à refaire. Sans ce garde, chaque passage de
     * l'observateur reconstruirait l'image et la rechargerait. */
    const chemin = cible.getAttribute ? cible.getAttribute('data-path') : '';
    if (chemin && cheminCourant === chemin && etatPour(chemin).chargee) return;
  }
  hote = cible;
  rendre();
  if (!observateur) observateur = suivreHote(HOTE, attach);
}

/* ------------------------------------------------------------------- API --- */

window.PSImages = {
  marqueur: 'ps-4.3.0-images',
  ouvrir: function (chemin) {
    if (!chemin) return false;
    if (typeof window.PSFMOpenTabs === 'function') {
      try { window.PSFMOpenTabs([chemin]); return true; } catch (exc) { /* repli */ }
    }
    /* Repli : vue déléguée. Mieux qu'une fonctionnalité absente. */
    if (window.PSVues && window.PSVues.ouvrir) {
      cheminCourant = chemin;
      charger(chemin);
      window.PSVues.ouvrir({ id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE,
        noeud: construire(chemin) });
      return true;
    }
    return false;
  },
  fermer: function () {
    if (window.PSVues && window.PSVues.fermer) window.PSVues.fermer(ID_VUE);
    return true;
  },
  recharger: function () {
    const chemin = cheminCourant;
    if (!chemin) return false;
    etatPour(chemin).chargee = false;
    return !!charger(chemin);
  },
  zoom: function (valeur) {
    const chemin = cheminCourant;
    if (!chemin) return null;
    const et = etatPour(chemin);
    if (valeur === 'ajuster' || typeof valeur === 'number') et.zoom = valeur;
    rendre();
    return et.zoom;
  },
  fond: function (valeur) {
    const chemin = cheminCourant;
    if (!chemin) return null;
    const et = etatPour(chemin);
    if (FONDS.indexOf(valeur) >= 0) et.fond = valeur;
    rendre();
    return et.fond;
  },
  etat: function () {
    const chemin = cheminCourant;
    if (!chemin) return { ouvert: false };
    const et = etatPour(chemin);
    return { ouvert: true, chemin: chemin, zoom: et.zoom, fond: et.fond,
      voisins: et.voisins.length, position: et.position,
      image: et.image ? { ok: !!et.image.ok, format: et.image.format || '',
        largeur: et.image.largeur || 0, hauteur: et.image.hauteur || 0,
        taille: et.image.taille || 0,
        dimensions_connues: !!et.image.dimensions_connues,
        erreur: et.image.erreur || '',
        piet: et.image.piet ? { est_piet: !!et.image.piet.est_piet,
          codel: et.image.piet.codel || 0,
          couleurs: et.image.piet.couleurs || 0,
          hors_palette: et.image.piet.hors_palette || 0 } : null } : null };
  },
  /* Ce qui est garanti, pour les bancs et pour le guide. */
  garanties: function () {
    return { onglet_reel: !!$(HOTE), repli_vues: !!(window.PSVues),
      svg_laisse_a_monaco: true, redimensionnement_serveur: false,
      fond_transparence: FONDS.slice(), zooms: ZOOMS.slice() };
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', attach, { once: true });
} else attach();
})();
