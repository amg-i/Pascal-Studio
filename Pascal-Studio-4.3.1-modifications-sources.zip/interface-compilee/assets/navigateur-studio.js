/* Panneau navigateur intégré de Pascal Studio (4.0.0).
 *
 * Ce n'est PAS Firefox, Chrome ou Edge mis dans la fenêtre : Pascal Studio est
 * déjà une application Electron, donc le moteur de rendu Chromium est déjà
 * présent. Ce qui manquait, c'était le droit de s'en servir comme d'un
 * navigateur — `webviewTag:true` dans desktop/main.cjs — et un panneau pour
 * s'en servir. C'est le rôle de patch_desktop_navigateur.py et de ce fichier.
 *
 * Forme du panneau : une fenêtre FLOTTANTE, déplaçable et redimensionnable, et
 * non une modale plein écran. Un navigateur qui cache tout l'éditeur ne sert à
 * rien : on le consulte en regardant son code, surtout pour l'aperçu d'un
 * projet en cours d'écriture. La géométrie est persistée côté serveur.
 *
 * Persistance côté serveur, pas dans localStorage : l'application choisit un
 * port libre au démarrage, donc son origine change d'un lancement à l'autre et
 * des signets enregistrés un jour auraient disparu le lendemain sans qu'aucune
 * erreur n'apparaisse.
 *
 * Trois états d'indisponibilité, chacun nommé précisément plutôt que laissé en
 * zone blanche :
 *   1. hors application de bureau  -> la balise <webview> n'existe pas ;
 *   2. application, webviewTag absent -> c'est un correctif à appliquer, et le
 *      panneau dit lequel ;
 *   3. invité créé mais muet -> l'URL est refusée ou injoignable, et la raison
 *      vient de did-fail-load, pas d'une supposition.
 *
 * Aucune ressource externe : pas de police, pas d'icône distante, pas de CDN.
 */
(() => {
'use strict';

const PARTITION = 'persist:pascal-navigateur';
const PAGE_ACCUEIL = 'about:blank';
const MAX_CONSOLE = 300;
const MAX_HISTORIQUE_AFFICHE = 200;

/* ------------------------------------------------------------------ DOM ---- */
const $ = (sel, base) => (base || document).querySelector(sel);
const $$ = (sel, base) => Array.from((base || document).querySelectorAll(sel));

function el(tag, attrs) {
  const noeud = document.createElement(tag);
  if (attrs) for (const cle in attrs) {
    if (attrs[cle] === null || attrs[cle] === undefined || attrs[cle] === false) continue;
    if (cle === 'class') noeud.className = attrs[cle];
    else if (cle === 'style' && typeof attrs[cle] === 'object') Object.assign(noeud.style, attrs[cle]);
    else if (cle.slice(0, 2) === 'on') noeud.addEventListener(cle.slice(2), attrs[cle]);
    else noeud.setAttribute(cle, attrs[cle] === true ? '' : String(attrs[cle]));
  }
  /* Tout argument suivant est un enfant : nœud, tableau de nœuds, ou texte.
   * Une première version n'acceptait qu'un texte et IGNORAIT silencieusement
   * le reste — les boutons de zoom passés en 4e et 5e arguments n'étaient
   * jamais ajoutés, et le troisième était rendu « [object Object] ». Un oubli
   * d'argument ne doit pas produire un panneau amputé sans erreur. */
  for (let i = 2; i < arguments.length; i++) ajouter(noeud, arguments[i]);
  return noeud;
}

function ajouter(parent, valeur) {
  if (valeur === undefined || valeur === null || valeur === false) return;
  if (Array.isArray(valeur)) { for (const v of valeur) ajouter(parent, v); return; }
  if (typeof valeur === 'object' && typeof valeur.appendChild === 'function') {
    parent.appendChild(valeur);
    return;
  }
  parent.appendChild(document.createTextNode(String(valeur)));
}

function bouton(titre, action, classe, infobulle) {
  const b = el('button', { class: 'psnav-btn' + (classe ? ' ' + classe : ''),
    type: 'button', title: infobulle || titre, 'aria-label': infobulle || titre }, titre);
  b.addEventListener('click', action);
  return b;
}

function icone(chemin) {
  return '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" '
       + 'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
       + chemin + '</svg>';
}
const I = {
  retour: icone('<path d="M15 18l-6-6 6-6"/>'),
  avant: icone('<path d="M9 6l6 6-6 6"/>'),
  recharger: icone('<path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 3v6h-6"/>'),
  stop: icone('<path d="M18 6L6 18M6 6l12 12"/>'),
  maison: icone('<path d="M3 10l9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>'),
  etoile: icone('<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>'),
  loupe: icone('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
  plus: icone('<path d="M12 5v14M5 12h14"/>'),
  outils: icone('<path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.4-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4.6a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.2l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4z"/>'),
  historique: icone('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  console: icone('<path d="M8 9l-4 3 4 3M16 9l4 3-4 3M13 6l-2 12"/>'),
  telechargements: icone('<path d="M12 3v12M7 11l5 5 5-5M4 21h16"/>'),
  externe: icone('<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>'),
  corbeille: icone('<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/>'),
  fermer: icone('<path d="M18 6L6 18M6 6l12 12"/>'),
  agrandir: icone('<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>'),
};

/* ---------------------------------------------------------------- état ---- */
let panneau = null;
/* 4.3.0 : identité de la vue déléguée. Le navigateur s'ouvre comme un onglet. */
const ID_VUE = 'navigateur';
const TITRE_VUE = 'Navigateur';
const ICONE_VUE = '⌾';
let enVue = false;
let fermetureEnCours = false;

function monterVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    enVue = window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud,
      /* La croix de la vignette doit faire ce que faisait la croix de la fenêtre
       * flottante : persister les onglets et la géométrie, couper le relais. */
      surFermeture: function () { enVue = false; fermerPanneau(true); }
    }) === true;
    return enVue;
  } catch (exc) {
    enVue = false;
    return false;
  }
}

function activerVue() {
  if (!enVue || !window.PSVues || typeof window.PSVues.activer !== 'function') {
    return false;
  }
  try { return window.PSVues.activer(ID_VUE) === true; } catch (exc) { return false; }
}

let onglets = [];
let actif = null;
let compteur = 0;
let etat = { historique: [], signets: [], geometrie: {}, capacites: {} };
let tiroir = null;            // 'historique' | 'signets' | 'console' | 'telechargements'
let journalConsole = [];
let telechargements = [];
let webviewSonde = null;      // null = non sondé, true/false après sondage
let relais = [];              // désinscrits à la fermeture
let minuteurs = {};

function apiServeur(action, champs) {
  return fetch('/api/navigateur', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(Object.assign({ action: action }, champs || {})),
  }).then(r => r.json().then(j => (r.ok ? j : Promise.reject(new Error(j.error || 'Erreur du serveur')))));
}

function lireEtat() {
  return fetch('/api/navigateur').then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  });
}

/* Différer les écritures : déplacer une fenêtre produit des dizaines
 * d'événements par seconde, et chacun ne doit pas coûter un aller-retour. */
function differe(nom, fn, delai) {
  if (minuteurs[nom]) clearTimeout(minuteurs[nom]);
  minuteurs[nom] = setTimeout(() => { delete minuteurs[nom]; fn(); }, delai || 600);
}

/* -------------------------------------------------- disponibilité webview -- */
function estApplication() {
  return !!window.pascalDesktop || /Electron\//i.test(navigator.userAgent || '');
}

function sonderWebview() {
  /* Un navigateur classique rend un HTMLUnknownElement. Electron SANS
   * webviewTag rend un élément inerte : la balise existe, aucune méthode ne
   * répond, et rien ne signale l'échec — d'où ce sondage plutôt qu'un test
   * sur le nom de la balise. L'élément est attaché hors écran parce que
   * l'API n'est installée qu'une fois l'élément connecté au document. */
  if (webviewSonde !== null) return Promise.resolve(webviewSonde);
  return new Promise(resoudre => {
    try {
      const sonde = el('webview', { class: 'psnav-sonde', partition: PARTITION });
      sonde.setAttribute('src', 'about:blank');
      document.body.appendChild(sonde);
      setTimeout(() => {
        const operationnel = typeof sonde.loadURL === 'function'
          || typeof sonde.getURL === 'function';
        sonde.remove();
        webviewSonde = !!operationnel;
        resoudre(webviewSonde);
      }, 120);
    } catch (e) {
      webviewSonde = false;
      resoudre(false);
    }
  });
}

/* ------------------------------------------------------------- messages -- */
function statut(message, niveau) {
  if (!panneau) return;
  const barre = $('.psnav-status', panneau);
  if (!barre) return;
  barre.textContent = message || '';
  barre.className = 'psnav-status' + (niveau ? ' psnav-' + niveau : '');
}

function erreur(e) { statut(e && e.message ? e.message : String(e), 'erreur'); }

/* --------------------------------------------------------------- onglets -- */
function creerOnglet(url, titre) {
  compteur += 1;
  const cible = url || PAGE_ACCUEIL;
  const onglet = {
    id: 'onglet-' + compteur,
    url: cible,
    titre: titre || cible,
    vue: null,
    pret: false,
    chargement: false,
    zoom: 1,
    historique: [],
    indexHistorique: -1,
    favori: false,
  };
  onglets.push(onglet);
  construireVue(onglet);
  activerOnglet(onglet);
  rendreOnglets();
  persisterOnglets();
  return onglet;
}

function construireVue(onglet) {
  const vue = el('webview', {
    class: 'psnav-vue', partition: PARTITION, 'data-onglet': onglet.id,
  });
  /* `allowpopups` n'est PAS demandé : le processus principal refuse déjà toute
   * fenêtre popup et relaie l'URL au panneau, qui l'ouvre comme un onglet.
   * Autoriser les popups ici court-circuiterait cette garde. */
  vue.setAttribute('src', onglet.url);
  vue.addEventListener('did-start-loading', () => { onglet.chargement = true; rendreBarre(onglet); });
  vue.addEventListener('did-stop-loading', () => { onglet.chargement = false; rendreBarre(onglet); });
  vue.addEventListener('load-commit', ev => {
    if (ev && ev.url) onglet.url = ev.url;
    if (actif === onglet) rendreAdresse(onglet);
  });
  vue.addEventListener('did-navigate', ev => {
    onglet.url = (ev && ev.url) || onglet.url;
    onglet.titre = onglet.titre || onglet.url;
    noterVisite(onglet.url, onglet.titre);
    if (actif === onglet) { rendreAdresse(onglet); rendreSecurite(onglet); }
    rendreOnglets();
  });
  vue.addEventListener('page-title-updated', ev => {
    onglet.titre = (ev && ev.title) || onglet.url;
    rendreOnglets();
    if (actif === onglet) rendreBarre(onglet);
  });
  vue.addEventListener('dom-ready', () => {
    onglet.pret = true;
    if (actif === onglet) statut('Page prête : ' + onglet.url, 'ok');
  });
  vue.addEventListener('did-fail-load', ev => {
    /* C'est ici que se joue l'honnêteté du panneau : sans ce relais, un nom de
     * domaine injoignable ou un certificat refusé se traduit par une page
     * blanche et l'utilisateur croit que le navigateur est cassé. */
    onglet.chargement = false;
    const code = ev ? ev.errorCode : 0;
    if (code === -3) return;            // ERR_ABORTED : navigation interrompue, normale
    const raison = (ev && ev.errorDescription) || 'raison inconnue';
    const ou = (ev && ev.validatedURL) || onglet.url;
    statut('Chargement refusé (' + code + ' ' + raison + ') : ' + ou, 'erreur');
    if (actif === onglet) rendreBarre(onglet);
  });
  vue.addEventListener('crashed', () => statut('Le rendu de cette page a planté. Rechargez l’onglet.', 'erreur'));
  vue.addEventListener('unresponsive', () => statut('La page ne répond plus.', 'avertissement'));
  vue.addEventListener('console-message', ev => {
    if (!ev) return;
    journalConsole.push({
      niveau: ['info', 'avertissement', 'erreur', 'debogage'][ev.level] || 'info',
      message: String(ev.message || ''),
      source: String(ev.sourceId || ''), ligne: ev.line || 0,
      url: onglet.url, quand: Date.now(),
    });
    if (journalConsole.length > MAX_CONSOLE) journalConsole.shift();
    if (tiroir === 'console') rendreTiroir();
  });
  vue.addEventListener('found-in-page', ev => {
    if (!ev || !ev.result) return;
    const r = ev.result;
    const info = $('.psnav-find-info', panneau);
    if (info) info.textContent = r.matches ? (r.activeMatchOrdinal + ' / ' + r.matches) : 'aucun résultat';
  });
  vue.addEventListener('enter-html-full-screen', () => statut('La page a demandé le plein écran HTML.', 'info'));
  onglet.vue = vue;
  return vue;
}

function activerOnglet(onglet) {
  actif = onglet;
  if (!panneau) return;
  const zone = $('.psnav-vues', panneau);
  if (!zone) return;
  for (const o of onglets) {
    if (!o.vue) continue;
    if (o === onglet) {
      if (o.vue.parentNode !== zone) zone.appendChild(o.vue);
      o.vue.classList.remove('cachee');
    } else if (o.vue.parentNode === zone) {
      /* Les vues inactives restent attachées mais masquées : les détacher
       * rechargerait la page à chaque changement d'onglet. */
      o.vue.classList.add('cachee');
    }
  }
  rendreAdresse(onglet);
  rendreSecurite(onglet);
  rendreBarre(onglet);
  rendreOnglets();
}

function fermerOnglet(onglet) {
  const i = onglets.indexOf(onglet);
  if (i < 0) return;
  try { if (onglet.vue) onglet.vue.remove(); } catch (e) { /* déjà détaché */ }
  onglets.splice(i, 1);
  if (actif === onglet) {
    actif = onglets[Math.min(i, onglets.length - 1)] || null;
    if (actif) activerOnglet(actif);
    else { statut('Aucun onglet ouvert.', 'info'); rendreBarre(null); }
  }
  rendreOnglets();
  persisterOnglets();
}

function persisterOnglets() {
  differe('onglets', () => {
    apiServeur('onglets', {
      onglets: onglets.map(o => ({ url: o.url, titre: o.titre })),
    }).catch(() => {});
  }, 900);
}

function noterVisite(url, titre) {
  if (!url || url === 'about:blank') return;
  differe('visite-' + url, () => {
    apiServeur('visite', { url: url, titre: titre || '' }).then(j => {
      etat.historique = j.historique || [];
      if (tiroir === 'historique') rendreTiroir();
    }).catch(() => {});
  }, 700);
}

/* -------------------------------------------------------------- rendu ---- */
function rendreOnglets() {
  if (!panneau) return;
  const barre = $('.psnav-tabs', panneau);
  if (!barre) return;
  barre.replaceChildren();
  for (const o of onglets) {
    const nom = o.titre || o.url || 'Nouvel onglet';
    const ongletEl = el('div', {
      class: 'psnav-tab' + (o === actif ? ' active' : ''),
      title: o.url || nom, role: 'tab', 'aria-selected': o === actif ? 'true' : 'false',
    });
    ongletEl.append(
      el('span', { class: 'psnav-tab-ico' }, o.chargement ? '◌' : (o.favori ? '★' : '·')),
      el('span', { class: 'psnav-tab-nom' }, nom));
    const fermer = el('button', { class: 'psnav-tab-x', type: 'button',
      title: 'Fermer cet onglet', 'aria-label': 'Fermer ' + nom });
    fermer.innerHTML = I.fermer;
    fermer.addEventListener('click', ev => { ev.stopPropagation(); fermerOnglet(o); });
    ongletEl.append(fermer);
    ongletEl.addEventListener('click', () => activerOnglet(o));
    ongletEl.addEventListener('auxclick', ev => { if (ev.button === 1) { ev.preventDefault(); fermerOnglet(o); } });
    barre.append(ongletEl);
  }
  const neuf = el('button', { class: 'psnav-tab-new', type: 'button',
    title: 'Nouvel onglet', 'aria-label': 'Nouvel onglet' });
  neuf.innerHTML = I.plus;
  neuf.addEventListener('click', () => { const o = creerOnglet(PAGE_ACCUEIL); focusAdresse(); });
  barre.append(neuf);
}

function rendreAdresse(o) {
  if (!panneau) return;
  const champ = $('.psnav-url', panneau);
  if (!champ) return;
  if (document.activeElement !== champ) champ.value = o && o.url ? o.url : '';
  const liste = $('.psnav-suggestions', panneau);
  if (liste) {
    liste.replaceChildren();
    const vus = new Set();
    for (const s of (etat.signets || [])) {
      if (vus.has(s.url)) continue;
      vus.add(s.url);
      liste.append(el('option', { value: s.url }, (s.titre || s.url) + ' — signet'));
    }
    for (const h of (etat.historique || []).slice(0, 40)) {
      if (vus.has(h.url)) continue;
      vus.add(h.url);
      liste.append(el('option', { value: h.url }, (h.titre || h.url) + ' — visité ' + (h.visites || 1) + '×'));
    }
  }
}

function securiteDe(url) {
  if (!url || url === 'about:blank') return { niveau: 'neutre', texte: 'page vide' };
  if (/^https:\/\/(127\.0\.0\.1|localhost)(:|\/|$)/i.test(url)) return { niveau: 'local', texte: 'serveur local chiffré' };
  if (/^http:\/\/(127\.0\.0\.1|localhost)(:|\/|$)/i.test(url)) return { niveau: 'local', texte: 'serveur local, non chiffré' };
  if (/^https:/i.test(url)) return { niveau: 'sur', texte: 'connexion chiffrée' };
  if (/^http:/i.test(url)) return { niveau: 'clair', texte: 'NON chiffré : ce qui transite est lisible' };
  return { niveau: 'neutre', texte: url.split(':')[0] };
}

function rendreSecurite(o) {
  if (!panneau) return;
  const pastille = $('.psnav-securite', panneau);
  if (!pastille) return;
  const s = securiteDe(o ? o.url : '');
  pastille.textContent = s.texte;
  pastille.className = 'psnav-securite psnav-sec-' + s.niveau;
  pastille.title = 'Adresse : ' + (o ? o.url : '') + '\n' + s.texte;
}

function rendreBarre(o) {
  if (!panneau) return;
  const vue = o && o.vue;
  const arriere = $('.psnav-back', panneau), avant = $('.psnav-forward', panneau);
  const recharger = $('.psnav-reload', panneau);
  let peutArriere = false, peutAvant = false;
  try { peutArriere = !!(vue && vue.canGoBack && vue.canGoBack()); } catch (e) { peutArriere = false; }
  try { peutAvant = !!(vue && vue.canGoForward && vue.canGoForward()); } catch (e) { peutAvant = false; }
  if (arriere) arriere.disabled = !peutArriere;
  if (avant) avant.disabled = !peutAvant;
  if (recharger) {
    recharger.disabled = !vue;
    recharger.innerHTML = (o && o.chargement) ? I.stop : I.recharger;
    recharger.title = (o && o.chargement) ? 'Arrêter le chargement' : 'Recharger';
  }
  const zoom = $('.psnav-zoom-val', panneau);
  if (zoom) {
    let facteur = o ? o.zoom : 1;
    try { if (vue && vue.getZoomFactor) facteur = vue.getZoomFactor(); } catch (e) { /* non prêt */ }
    if (o) o.zoom = facteur;
    zoom.textContent = Math.round((facteur || 1) * 100) + ' %';
  }
  const titre = $('.psnav-titre-page', panneau);
  if (titre) titre.textContent = o ? (o.titre || o.url || '') : '';
  const favori = $('.psnav-favori', panneau);
  if (favori) {
    favori.classList.toggle('actif', !!(o && etat.signets && etat.signets.some(s => s.url === o.url)));
  }
  for (const b of $$('.psnav-btn[data-require-vue]', panneau)) b.disabled = !vue;
}

function rendreTiroir() {
  if (!panneau) return;
  const zone = $('.psnav-drawer', panneau);
  if (!zone) return;
  zone.replaceChildren();
  if (!tiroir) { zone.classList.add('cachee'); return; }
  zone.classList.remove('cachee');
  const entete = el('div', { class: 'psnav-drawer-head' });
  const titres = { historique: 'Historique', signets: 'Signets', console: 'Console de la page',
    telechargements: 'Téléchargements' };
  entete.append(el('strong', {}, titres[tiroir] || tiroir), el('span', { class: 'psnav-spacer' }));
  if (tiroir === 'historique') {
    entete.append(bouton('Effacer l’historique', () => {
      apiServeur('historique-effacer').then(j => { etat.historique = j.historique || []; rendreTiroir(); statut('Historique effacé.', 'ok'); }).catch(erreur);
    }, 'danger', 'Supprimer l’historique enregistré sur cette machine'));
  }
  if (tiroir === 'console') {
    entete.append(bouton('Vider', () => { journalConsole = []; rendreTiroir(); }, '', 'Vider le journal affiché'));
  }
  const fermer = el('button', { class: 'psnav-btn', type: 'button', title: 'Fermer ce volet' });
  fermer.innerHTML = I.fermer;
  fermer.addEventListener('click', () => { tiroir = null; rendreTiroir(); });
  entete.append(fermer);
  zone.append(entete);

  const liste = el('div', { class: 'psnav-drawer-list' });
  if (tiroir === 'historique') {
    const entrees = etat.historique || [];
    if (!entrees.length) liste.append(el('p', { class: 'psnav-vide' }, 'Aucune visite enregistrée. L’historique est conservé sur cette machine, dans le répertoire de configuration de Pascal Studio.'));
    for (const h of entrees.slice(0, MAX_HISTORIQUE_AFFICHE)) {
      const ligne = el('button', { class: 'psnav-entree', type: 'button', title: h.url });
      ligne.append(el('span', { class: 'psnav-entree-titre' }, h.titre || h.url),
        el('span', { class: 'psnav-entree-url' }, h.url),
        el('span', { class: 'psnav-entree-meta' }, (h.visites || 1) + '× · ' + new Date((h.vu || 0) * 1000).toLocaleString('fr-FR')));
      ligne.addEventListener('click', () => naviguer(h.url));
      liste.append(ligne);
    }
  } else if (tiroir === 'signets') {
    const entrees = etat.signets || [];
    if (!entrees.length) liste.append(el('p', { class: 'psnav-vide' }, 'Aucun signet. Utilisez l’étoile de la barre d’adresse pour enregistrer la page courante.'));
    for (const s of entrees) {
      const ligne = el('div', { class: 'psnav-entree-ligne' });
      const ouvrir = el('button', { class: 'psnav-entree', type: 'button', title: s.url });
      ouvrir.append(el('span', { class: 'psnav-entree-titre' }, (s.groupe ? s.groupe + ' · ' : '') + (s.titre || s.url)),
        el('span', { class: 'psnav-entree-url' }, s.url));
      ouvrir.addEventListener('click', () => naviguer(s.url));
      const oter = el('button', { class: 'psnav-btn psnav-btn-mini', type: 'button', title: 'Retirer ce signet' });
      oter.innerHTML = I.corbeille;
      oter.addEventListener('click', () => {
        apiServeur('signet-supprimer', { url: s.url }).then(j => { etat.signets = j.signets || []; rendreTiroir(); rendreBarre(actif); }).catch(erreur);
      });
      ligne.append(ouvrir, oter);
      liste.append(ligne);
    }
  } else if (tiroir === 'console') {
    if (!journalConsole.length) liste.append(el('p', { class: 'psnav-vide' }, 'Aucun message. La console affiche ce que la page écrit ; elle ne remplace pas les outils de développement, ouverts par le menu.'));
    for (const m of journalConsole) {
      liste.append(el('div', { class: 'psnav-console psnav-c-' + m.niveau },
        '[' + m.niveau + '] ' + m.message + (m.source ? '  — ' + m.source + ':' + m.ligne : '')));
    }
  } else if (tiroir === 'telechargements') {
    if (!telechargements.length) liste.append(el('p', { class: 'psnav-vide' }, 'Aucun téléchargement dans cette session. Chaque téléchargement demande où l’enregistrer : rien n’est écrit en silence.'));
    for (const t of telechargements) {
      liste.append(el('div', { class: 'psnav-entree' },
        el('span', { class: 'psnav-entree-titre' }, t.nom),
        el('span', { class: 'psnav-entree-url' }, t.chemin || ''),
        el('span', { class: 'psnav-entree-meta' }, t.state || t.etat || '')));
    }
  }
  zone.append(liste);
}

function basculerTiroir(nom) {
  tiroir = (tiroir === nom) ? null : nom;
  rendreTiroir();
}

/* ----------------------------------------------------------- navigation -- */
/* Le moteur de recherche est Qwant, à la demande explicite de l'utilisateur
 * (4.2.0). Aucun moteur n'était branché auparavant, et ce n'était pas un oubli :
 * envoyer une saisie à un tiers à l'insu de l'utilisateur n'est pas acceptable
 * par défaut. Ce n'est plus à son insu — le nom du moteur est écrit dans la
 * barre d'adresse, dans l'infobulle du bouton d'accueil et dans le guide.
 * Qwant ne profile pas et héberge en Europe, ce qui en fait un choix raisonnable
 * pour un moteur imposé par défaut. */
const MOTEUR = {
  nom: 'Qwant',
  accueil: 'https://www.qwant.com/',
  recherche: 'https://www.qwant.com/?q='
};

function interpreterAdresse(saisie) {
  const brut = String(saisie || '').trim();
  if (!brut) return null;
  if (/^(https?:|about:blank)/i.test(brut)) return brut;
  /* Un mot qui ressemble à un domaine est complété en https:// : c'était déjà le
   * comportement, et le garder évite d'envoyer « exemple.fr » au moteur. */
  if (/^[^\s/]+\.[^\s/]{2,}/.test(brut)) return 'https://' + brut;
  /* Le reste part chez le moteur. L'encodage est fait par encodeURIComponent :
   * une saisie contenant « & » ou « # » ne doit pas couper la requête. */
  return MOTEUR.recherche + encodeURIComponent(brut);
}

function naviguer(url) {
  if (!actif) { creerOnglet(url); return; }
  const cible = interpreterAdresse(url);
  if (!cible) {
    statut('Adresse incomplète : saisissez une URL, un nom de domaine, ou les '
      + 'mots à chercher chez ' + MOTEUR.nom + '.', 'avertissement');
    focusAdresse();
    return;
  }
  const vue = actif.vue;
  if (!vue) return;
  if (!actif.pret || typeof vue.loadURL !== 'function') {
    /* L'API n'est installée qu'une fois l'élément connecté : passer par src
     * évite un échec silencieux sur un onglet fraîchement créé. */
    vue.setAttribute('src', cible);
  } else {
    try { vue.loadURL(cible); } catch (e) { vue.setAttribute('src', cible); }
  }
  actif.url = cible;
  rendreAdresse(actif);
  rendreSecurite(actif);
  statut('Chargement de ' + cible, 'info');
}

function focusAdresse() {
  const champ = $('.psnav-url', panneau);
  if (!champ) return;
  champ.focus();
  champ.select();
}

function zoomer(delta) {
  if (!actif || !actif.vue) return;
  let facteur = actif.zoom || 1;
  try { facteur = actif.vue.getZoomFactor(); } catch (e) { /* non prêt */ }
  const cible = Math.min(5, Math.max(0.25, Math.round((facteur + delta) * 100) / 100));
  try { actif.vue.setZoomFactor(cible); } catch (e) { erreur(e); return; }
  actif.zoom = cible;
  rendreBarre(actif);
}

function agir(fn, message) {
  if (!actif || !actif.vue) { statut('Aucun onglet actif.', 'avertissement'); return; }
  try { fn(actif.vue); if (message) statut(message, 'info'); } catch (e) { erreur(e); }
}

/* ------------------------------------------------------------ fenêtre ---- */
function geometrieCourante() {
  if (!panneau) return {};
  const r = panneau.getBoundingClientRect();
  return { x: Math.round(r.left), y: Math.round(r.top),
    largeur: Math.round(r.width), hauteur: Math.round(r.height),
    plein: panneau.classList.contains('psnav-plein') };
}

function appliquerGeometrie(g) {
  if (!panneau || !g || !g.largeur) return;
  if (g.plein) { panneau.classList.add('psnav-plein'); return; }
  panneau.classList.remove('psnav-plein');
  panneau.style.left = g.x + 'px';
  panneau.style.top = g.y + 'px';
  panneau.style.width = g.largeur + 'px';
  panneau.style.height = g.hauteur + 'px';
}

function persisterGeometrie() {
  differe('geometrie', () => {
    apiServeur('geometrie', { geometrie: geometrieCourante() }).catch(() => {});
  }, 800);
}

/* 4.3.1 : délégué à un onglet, le panneau n'est plus une fenêtre — c'est la zone
 * des vues qui possède sa géométrie. Écrire left/top/width/height en ligne sur un
 * noeud en colonne l'arrachait à sa colonne. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function rendreDeplacable() {
  const poignee = $('.psnav-titlebar', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(panneau)) return;
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psnav-plein')) return;
    const depart = { x: ev.clientX, y: ev.clientY,
      gauche: panneau.offsetLeft, haut: panneau.offsetTop };
    const bouger = e => {
      panneau.style.left = Math.max(-panneau.offsetWidth + 120,
        Math.min(window.innerWidth - 80, depart.gauche + e.clientX - depart.x)) + 'px';
      panneau.style.top = Math.max(0,
        Math.min(window.innerHeight - 40, depart.haut + e.clientY - depart.y)) + 'px';
      persisterGeometrie();
    };
    const lacher = () => {
      window.removeEventListener('pointermove', bouger);
      window.removeEventListener('pointerup', lacher);
      persisterGeometrie();
    };
    window.addEventListener('pointermove', bouger);
    window.addEventListener('pointerup', lacher);
    ev.preventDefault();
  });
}

function rendreRedimensionnable() {
  for (const cote of ['e', 's', 'se', 'w', 'n']) {
    const poignee = el('div', { class: 'psnav-resize psnav-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (dansUneColonne(panneau)) return;
      if (panneau.classList.contains('psnav-plein')) return;
      const r = panneau.getBoundingClientRect();
      const depart = { x: ev.clientX, y: ev.clientY, g: r.left, h: r.top, l: r.width, ht: r.height };
      const bouger = e => {
        const dx = e.clientX - depart.x, dy = e.clientY - depart.y;
        if (cote.indexOf('e') >= 0) panneau.style.width = Math.max(420, depart.l + dx) + 'px';
        if (cote.indexOf('s') >= 0) panneau.style.height = Math.max(260, depart.ht + dy) + 'px';
        if (cote.indexOf('w') >= 0) {
          const l = Math.max(420, depart.l - dx);
          panneau.style.width = l + 'px';
          panneau.style.left = (depart.g + depart.l - l) + 'px';
        }
        if (cote === 'n') {
          const ht = Math.max(260, depart.ht - dy);
          panneau.style.height = ht + 'px';
          panneau.style.top = (depart.h + depart.ht - ht) + 'px';
        }
        persisterGeometrie();
      };
      const lacher = () => {
        window.removeEventListener('pointermove', bouger);
        window.removeEventListener('pointerup', lacher);
        persisterGeometrie();
      };
      window.addEventListener('pointermove', bouger);
      window.addEventListener('pointerup', lacher);
      ev.preventDefault();
      ev.stopPropagation();
    });
    panneau.append(poignee);
  }
}

/* ------------------------------------------------------------- panneau --- */
function construire() {
  panneau = el('section', { class: 'psnav-panel', role: 'dialog',
    'aria-label': 'Navigateur intégré' });

  const titre = el('div', { class: 'psnav-titlebar' });
  const logo = el('span', { class: 'psnav-logo' });
  logo.innerHTML = icone('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18"/>');
  titre.append(logo, el('strong', {}, 'Navigateur'));
  titre.append(el('span', { class: 'psnav-titre-page' }));
  titre.append(el('span', { class: 'psnav-spacer' }));
  const plein = el('button', { class: 'psnav-btn', type: 'button', title: 'Occuper toute la fenêtre' });
  plein.innerHTML = I.agrandir;
  plein.addEventListener('click', () => {
    panneau.classList.toggle('psnav-plein');
    if (!panneau.classList.contains('psnav-plein')) appliquerGeometrie(etat.geometrie || {});
    persisterGeometrie();
  });
  const reduire = bouton('—', () => { panneau.classList.toggle('psnav-reduit'); }, '', 'Réduire le panneau');
  const fermer = el('button', { class: 'psnav-btn', type: 'button', title: 'Fermer le panneau (les onglets sont conservés)' });
  fermer.innerHTML = I.fermer;
  fermer.addEventListener('click', fermerPanneau);
  titre.append(plein, reduire, fermer);
  panneau.append(titre);

  panneau.append(el('div', { class: 'psnav-tabs', role: 'tablist' }));

  const barre = el('div', { class: 'psnav-toolbar' });
  const back = el('button', { class: 'psnav-btn psnav-back', type: 'button', title: 'Page précédente' });
  back.innerHTML = I.retour;
  back.addEventListener('click', () => agir(v => v.goBack(), 'Page précédente.'));
  const forward = el('button', { class: 'psnav-btn psnav-forward', type: 'button', title: 'Page suivante' });
  forward.innerHTML = I.avant;
  forward.addEventListener('click', () => agir(v => v.goForward(), 'Page suivante.'));
  const reload = el('button', { class: 'psnav-btn psnav-reload', type: 'button', title: 'Recharger' });
  reload.innerHTML = I.recharger;
  reload.addEventListener('click', () => {
    if (actif && actif.chargement) agir(v => v.stop(), 'Chargement arrêté.');
    else agir(v => v.reload(), 'Rechargement.');
  });
  /* « Accueil » mène à la page d'accueil du moteur, comme demandé. L'aperçu du
   * projet servi par Pascal Studio garde son propre bouton, juste à côté :
   * déplacer une fonctionnalité ne doit pas la faire perdre. */
  const home = el('button', { class: 'psnav-btn psnav-home', type: 'button',
    title: 'Page d’accueil de ' + MOTEUR.nom + ' — ' + MOTEUR.accueil });
  home.innerHTML = I.maison;
  home.addEventListener('click', () => {
    naviguer(MOTEUR.accueil);
    statut('Page d’accueil de ' + MOTEUR.nom + ' : ' + MOTEUR.accueil, 'info');
  });
  /* 4.3.0 : le second bouton « maison » est supprimé, comme demandé. Il menait
   * à l'origine de l'application — donc à http://localhost:PORT — et deux
   * boutons maison identiques côte à côte ne se distinguaient pas. L'aperçu du
   * projet servi par Pascal Studio reste accessible par le panneau dev web, qui
   * est son vrai point d'entrée : rien n'est perdu, seulement dédoublonné. */

  const champ = el('input', { class: 'psnav-url', type: 'text', list: 'psnav-suggestions',
    placeholder: 'Adresse, domaine, ou mots à chercher chez ' + MOTEUR.nom,
    'aria-label': 'Adresse de la page ou mots à chercher',
    spellcheck: 'false', autocomplete: 'off' });
  champ.addEventListener('keydown', ev => {
    if (ev.key === 'Enter') { ev.preventDefault(); naviguer(champ.value); champ.blur(); }
    else if (ev.key === 'Escape') { ev.preventDefault(); rendreAdresse(actif); champ.blur(); }
  });
  champ.addEventListener('focus', () => champ.select());
  const liste = el('datalist', { id: 'psnav-suggestions', class: 'psnav-suggestions' });

  const favori = el('button', { class: 'psnav-btn psnav-favori', type: 'button', title: 'Ajouter ou retirer cette page des signets' });
  favori.innerHTML = I.etoile;
  favori.addEventListener('click', () => {
    if (!actif || !actif.url || actif.url === 'about:blank') { statut('Rien à enregistrer sur une page vide.', 'avertissement'); return; }
    const deja = (etat.signets || []).some(s => s.url === actif.url);
    const promesse = deja
      ? apiServeur('signet-supprimer', { url: actif.url })
      : apiServeur('signet', { url: actif.url, titre: actif.titre || '' });
    promesse.then(j => {
      etat.signets = j.signets || [];
      rendreBarre(actif);
      if (tiroir === 'signets') rendreTiroir();
      statut(deja ? 'Signet retiré.' : 'Signet enregistré.', 'ok');
    }).catch(erreur);
  });

  const chercher = el('button', { class: 'psnav-btn', type: 'button', title: 'Chercher dans la page' });
  chercher.innerHTML = I.loupe;
  chercher.addEventListener('click', basculerRecherche);

  const moins = bouton('−', () => zoomer(-0.1), '', 'Dézoomer');
  const valeur = el('span', { class: 'psnav-zoom-val', title: 'Zoom de la page' }, '100 %');
  const plusB = bouton('+', () => zoomer(0.1), '', 'Zoomer');
  valeur.addEventListener('click', () => agir(v => { v.setZoomFactor(1); actif.zoom = 1; rendreBarre(actif); }, 'Zoom réinitialisé.'));

  const menu = el('button', { class: 'psnav-btn', type: 'button', title: 'Outils du navigateur' });
  menu.innerHTML = I.outils;
  menu.addEventListener('click', ev => ouvrirMenu(menu));

  barre.append(back, forward, reload, home, champ, favori, chercher,
    el('span', { class: 'psnav-zoom' }, moins, valeur, plusB), menu, liste);
  panneau.append(barre);

  const recherche = el('div', { class: 'psnav-find cachee' });
  const champRecherche = el('input', { class: 'psnav-find-input', type: 'text',
    placeholder: 'Chercher dans la page', 'aria-label': 'Chercher dans la page' });
  champRecherche.addEventListener('input', () => {
    const texte = champRecherche.value;
    if (!actif || !actif.vue) return;
    try {
      if (!texte) actif.vue.stopFindInPage('clearActiveMatch');
      else actif.vue.findInPage(texte, { forward: true, findNext: false });
    } catch (e) { /* invité pas encore prêt */ }
  });
  champRecherche.addEventListener('keydown', ev => {
    if (ev.key === 'Enter') {
      ev.preventDefault();
      try { actif.vue.findInPage(champRecherche.value, { forward: !ev.shiftKey, findNext: true }); } catch (e) { erreur(e); }
    } else if (ev.key === 'Escape') { ev.preventDefault(); fermerRecherche(); }
  });
  const info = el('span', { class: 'psnav-find-info' }, '');
  recherche.append(champRecherche, info,
    bouton('↑', () => { try { actif.vue.findInPage(champRecherche.value, { forward: false, findNext: true }); } catch (e) { erreur(e); } }, '', 'Occurrence précédente'),
    bouton('↓', () => { try { actif.vue.findInPage(champRecherche.value, { forward: true, findNext: true }); } catch (e) { erreur(e); } }, '', 'Occurrence suivante'),
    bouton('Fermer', fermerRecherche, '', 'Fermer la recherche'));
  panneau.append(recherche);

  const corps = el('div', { class: 'psnav-corps' });
  corps.append(el('div', { class: 'psnav-vues' }), el('div', { class: 'psnav-drawer cachee' }));
  panneau.append(corps);

  const securite = el('span', { class: 'psnav-securite psnav-sec-neutre' }, 'page vide');
  const status = el('span', { class: 'psnav-status' }, '');
  panneau.append(el('div', { class: 'psnav-statusbar' }, securite, el('span', { class: 'psnav-spacer' }), status));

  /* Raccourcis, limités au panneau : les mêmes touches servent à l'éditeur,
   * et les lui voler rendrait le reste de l'application inutilisable. */
  panneau.addEventListener('keydown', ev => {
    const ctrl = ev.ctrlKey || ev.metaKey;
    if (!ctrl) return;
    const cle = (ev.key || '').toLowerCase();
    if (cle === 'l') { ev.preventDefault(); focusAdresse(); }
    else if (cle === 't') { ev.preventDefault(); creerOnglet(PAGE_ACCUEIL); focusAdresse(); }
    else if (cle === 'w') { ev.preventDefault(); if (actif) fermerOnglet(actif); }
    else if (cle === 'r') { ev.preventDefault(); agir(v => v.reload(), 'Rechargement.'); }
    else if (cle === 'f') { ev.preventDefault(); basculerRecherche(); }
  });

  /* 4.3.0 : le navigateur est un ONGLET, plus une fenêtre flottante. La fenêtre
   * flottante recouvrait l'éditeur, devait être déplacée à la main, et sa
   * géométrie était persistée pour rien. En vue déléguée, elle a sa vignette
   * dans la barre d'onglets, se ferme par la croix, et peut être mise côte à
   * côte avec l'éditeur ou avec un autre panneau. */
  if (monterVue(panneau)) return panneau;
  rendreDeplacable();
  rendreRedimensionnable();
  document.body.append(panneau);
  return panneau;
}

function basculerRecherche() {
  const zone = $('.psnav-find', panneau);
  if (!zone) return;
  const cache = zone.classList.toggle('cachee');
  if (!cache) { const c = $('.psnav-find-input', zone); if (c) c.focus(); }
  else fermerRecherche();
}

function fermerRecherche() {
  const zone = $('.psnav-find', panneau);
  if (zone) zone.classList.add('cachee');
  try { if (actif && actif.vue) actif.vue.stopFindInPage('clearActiveMatch'); } catch (e) { /* non prêt */ }
}

function ouvrirMenu(ancre) {
  fermerMenu();
  const menu = el('div', { class: 'psnav-menu', role: 'menu' });
  const items = [
    ['Outils de développement de la page', () => agir(v => {
      if (v.isDevToolsOpened && v.isDevToolsOpened()) v.closeDevTools();
      else v.openDevTools({ mode: 'detach' });
    }, 'Outils de développement : fenêtre séparée, ils inspectent la PAGE, pas l’interface.')],
    ['Recharger en ignorant le cache', () => agir(v => v.reloadIgnoringCache(), 'Rechargement sans cache.')],
    ['Historique', () => basculerTiroir('historique')],
    ['Signets', () => basculerTiroir('signets')],
    ['Console de la page', () => basculerTiroir('console')],
    ['Téléchargements', () => basculerTiroir('telechargements')],
    ['Copier l’adresse', () => {
      const url = actif ? actif.url : '';
      if (!url) { statut('Aucune adresse à copier.', 'avertissement'); return; }
      if (window.pascalDesktop && window.pascalDesktop.clipboardWrite) window.pascalDesktop.clipboardWrite(url);
      else if (navigator.clipboard) navigator.clipboard.writeText(url);
      statut('Adresse copiée : ' + url, 'ok');
    }],
    ['Ouvrir dans le navigateur du système', () => {
      const url = actif ? actif.url : '';
      if (!/^https?:/i.test(url)) { statut('Seule une adresse http ou https peut être ouverte dehors.', 'avertissement'); return; }
      /* Le processus principal ouvre déjà dans le navigateur du système toute
       * URL https demandée par window.open : on passe par ce chemin existant
       * plutôt que d'ajouter un canal IPC. */
      window.open(url, '_blank');
      statut('Demande transmise au navigateur du système : ' + url, 'info');
    }],
    ['Nouvel onglet', () => { creerOnglet(PAGE_ACCUEIL); focusAdresse(); }],
    ['Dupliquer l’onglet', () => { if (actif) { creerOnglet(actif.url, actif.titre); } }],
  ];
  for (const [libelle, action] of items) {
    const item = el('button', { class: 'psnav-menu-item', type: 'button', role: 'menuitem' }, libelle);
    item.addEventListener('click', () => { fermerMenu(); action(); });
    menu.append(item);
  }
  menu.append(el('hr'));
  menu.append(el('p', { class: 'psnav-menu-note' },
    'La page affichée est du contenu tiers : elle est rendue dans une partition '
    + 'séparée, sans script de preload, sans intégration Node, et ses demandes '
    + 'de caméra, micro ou géolocalisation sont refusées.'));
  const r = ancre.getBoundingClientRect();
  menu.style.top = (r.bottom + 4) + 'px';
  menu.style.left = Math.max(8, Math.min(r.left - 220, window.innerWidth - 320)) + 'px';
  document.body.append(menu);
  setTimeout(() => document.addEventListener('pointerdown', fermerMenu, { once: true }), 0);
}

function fermerMenu() {
  const m = $('.psnav-menu');
  if (m) m.remove();
}

/* ------------------------------------------------- relais du processus ---- */
function brancherRelais() {
  const d = window.pascalDesktop;
  if (!d) return;
  if (typeof d.onNavigateurPopup === 'function') {
    relais.push(d.onNavigateurPopup(url => {
      /* Un popup est refusé par le processus principal, puis relayé ici : le
       * panneau l'ouvre comme un onglet, ce qui le garde sous ses gardes. */
      statut('Fenêtre popup bloquée et ouverte dans un onglet : ' + url, 'info');
      const cible = interpreterAdresse(url) || url;
      creerOnglet(cible);
    }));
  }
  if (typeof d.onNavigateurDownload === 'function') {
    relais.push(d.onNavigateurDownload(info => {
      if (!info) return;
      telechargements.unshift({ nom: info.nom || 'telechargement', chemin: info.chemin || '',
        state: info.state || '', quand: Date.now() });
      if (telechargements.length > 50) telechargements.pop();
      statut(info.state === 'completed'
        ? 'Téléchargement enregistré : ' + (info.chemin || info.nom)
        : 'Téléchargement ' + (info.state || 'en cours') + ' : ' + (info.nom || ''),
        info.state === 'completed' ? 'ok' : 'info');
      if (tiroir === 'telechargements') rendreTiroir();
    }));
  }
  if (typeof d.onNavigateurPermission === 'function') {
    relais.push(d.onNavigateurPermission(info => {
      if (!info) return;
      statut('Permission refusée à la page : ' + (info.permission || 'inconnue')
        + '. Caméra, micro et géolocalisation ne sont pas accordés dans ce panneau.', 'avertissement');
    }));
  }
}

function debrancherRelais() {
  for (const desinscrire of relais) { try { desinscrire(); } catch (e) { /* déjà retiré */ } }
  relais = [];
}

/* --------------------------------------------------------- indisponible -- */
function rendreIndisponible(raison, detail) {
  const zone = $('.psnav-vues', panneau);
  if (!zone) return;
  zone.replaceChildren();
  const boite = el('div', { class: 'psnav-indisponible' });
  boite.append(el('h2', {}, raison));
  if (detail) boite.append(el('p', {}, detail));
  boite.append(el('p', { class: 'psnav-note' },
    'Ce panneau n’installe aucun navigateur : il se sert du moteur de rendu déjà '
    + 'présent dans Pascal Studio, qui est une application Electron. Il faut '
    + 'seulement que la balise <webview> y soit activée.'));
  const champ = el('input', { class: 'psnav-url', type: 'text',
    placeholder: 'Adresse à ouvrir ailleurs', 'aria-label': 'Adresse' });
  const dehors = bouton('Ouvrir cette adresse dans le navigateur du système', () => {
    const url = interpreterAdresse(champ.value);
    if (!url) { statut('Adresse incomplète.', 'avertissement'); return; }
    window.open(url, '_blank');
    statut('Demande transmise au navigateur du système : ' + url, 'info');
  }, 'primary');
  boite.append(el('div', { class: 'psnav-ligne' }, champ, dehors));
  zone.append(boite);
}

/* ------------------------------------------------------------- ouverture -- */
async function ouvrirPanneau() {
  /* En onglet, « ouvrir » une seconde fois veut dire « remettre au premier
   * plan », pas « reconstruire » : reconstruire perdrait la page en cours. */
  if (panneau && panneau.isConnected && activerVue()) return;
  if (panneau && panneau.isConnected) { panneau.classList.remove('psnav-reduit'); panneau.focus(); return; }
  construire();
  brancherRelais();
  statut('Chargement de l’état du navigateur…', 'info');
  try {
    etat = await lireEtat();
  } catch (e) {
    etat = { historique: [], signets: [], onglets: [], geometrie: {}, capacites: {} };
    statut('État du navigateur illisible (' + (e.message || e) + ') : le panneau démarre à vide.', 'avertissement');
  }
  appliquerGeometrie(etat.geometrie || {});

  const operationnel = await sonderWebview();
  if (!operationnel) {
    if (!estApplication()) {
      rendreIndisponible('Le navigateur intégré fonctionne dans l’application de bureau',
        'Cette page tourne dans un navigateur classique, où la balise <webview> '
        + 'n’existe pas : c’est une balise Electron, pas une balise du web. '
        + 'Lancez Pascal Studio depuis son AppImage pour disposer du panneau.');
    } else {
      rendreIndisponible('La balise <webview> n’est pas activée dans cette installation',
        'L’application est bien Electron, mais webviewTag n’est pas activé dans '
        + 'desktop/main.cjs : la balise existe et reste muette, sans erreur nulle '
        + 'part. Appliquez patch_desktop_navigateur.py sur desktop/main.cjs puis '
        + 'reconstruisez l’image — c’est ce que fait reconditionner-4.0.0.sh.');
    }
    statut('Navigateur indisponible : voir le message dans le panneau.', 'erreur');
    return;
  }

  const sauves = (etat.onglets || []).filter(o => o && o.url);
  if (sauves.length) {
    for (const o of sauves.slice(0, 8)) creerOnglet(o.url, o.titre);
    statut(sauves.length + ' onglet(s) retrouvé(s) depuis la dernière session.', 'ok');
  } else {
    creerOnglet(PAGE_ACCUEIL);
    /* 4.3.0 : ce message renvoyait vers « le bouton « maison » » pour l'aperçu du
     * projet. Ce second bouton maison — celui qui menait à l'origine de
     * l'application, http://localhost:PORT — a été supprimé sur demande : deux
     * boutons maison identiques côte à côte ne se distinguaient pas. Un message
     * qui pointe vers un bouton disparu est pire que pas de message du tout,
     * parce qu'il envoie l'utilisateur chercher quelque chose qui n'existe pas.
     * L'aperçu du projet garde son vrai point d'entrée : le panneau dev web, qui
     * le démarre, l'arrête et journalise ce qu'il sert. */
    statut('Aucun onglet enregistré : un onglet vide est ouvert. L’aperçu du '
           + 'projet servi par Pascal Studio se démarre depuis le panneau dev web.', 'info');
  }
  if (!(etat.capacites || {}).persistant) {
    statut('Persistance désactivée (PS_NAVIGATEUR_PERSIST=0) : historique et signets ne survivront pas à ce lancement.', 'avertissement');
  }
}

function fermerPanneau(depuisVue) {
  if (!panneau) return;
  /* Garde anti-récursion : fermerPanneau() retire la vue, dont la fermeture
   * rappelle surFermeture, qui rappelle fermerPanneau(). Sans cette garde, la
   * boucle ne s'arrête que par chance. */
  if (fermetureEnCours) return;
  fermetureEnCours = true;
  try {
    persisterOnglets();
  apiServeur('geometrie', { geometrie: geometrieCourante() }).catch(() => {});
  debrancherRelais();
  for (const cle in minuteurs) if (minuteurs[cle]) clearTimeout(minuteurs[cle]);
    minuteurs = {};
    if (enVue && !depuisVue && window.PSVues &&
        typeof window.PSVues.fermer === 'function') {
      enVue = false;
      try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
    }
    if (panneau && typeof panneau.remove === 'function') panneau.remove();
    panneau = null;
    enVue = false;
  } finally {
    fermetureEnCours = false;
  }
}

/* -------------------------------------------------------- barre d'activité */
function attach() {
  const barre = $('.activitybar');
  if (barre && !barre.querySelector('.psnav-launch')) {
    const b = el('button', { class: 'psnav-launch', type: 'button',
      title: 'Navigateur intégré', 'aria-label': 'Navigateur intégré' });
    b.innerHTML = icone('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18"/>');
    b.addEventListener('click', () => { ouvrirPanneau().catch(erreur); });
    barre.append(b);
  }
}

window.PSNavigateur = {
  ouvrir: () => ouvrirPanneau().catch(erreur),
  fermer: fermerPanneau,
  naviguer: url => naviguer(url),
  onglet: url => creerOnglet(url),
  etat: () => ({ onglets: onglets.map(o => ({ url: o.url, titre: o.titre })),
    actif: actif ? actif.url : null, webview: webviewSonde }),
};

/* Un seul observateur pour toute l'application, via ps-hotes.js. Cinq
 * observateurs sur document.documentElement plus cinq sondes à 2 s
 * saturaient le fil principal : chaque mutation du DOM — une frappe dans
 * Monaco, une ligne de terminal, un diagnostic — réveillait les cinq, et un
 * bouton latéral mettait plusieurs secondes à changer l'affichage. Le repli
 * ci-dessous sert aux bancs, qui jouent ce script seul, sans PSHotes. */
function suivreHote(selecteur, rappel) {
  /* L'objet rendu a les deux méthodes d'un MutationObserver : les scripts
   * existants appellent .disconnect() pour écarter leurs propres écritures
   * et .takeRecords() quand il existe. Rendre une simple fonction d'arrêt
   * casserait ces appels — c'est ce qu'a fait la première version. */
  const arret = { disconnect: function () {},
    takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const observateur = new MutationObserver(rappel);
  observateur.observe(document.documentElement,
    { subtree: true, childList: true });
  const filet = typeof setInterval === 'function'
    ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () {
    observateur.disconnect();
    if (filet) clearInterval(filet);
  };
  return arret;
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', attach, { once: true });
else attach();
suivreHote('.ps-navigateur-ancre', attach);
})();
