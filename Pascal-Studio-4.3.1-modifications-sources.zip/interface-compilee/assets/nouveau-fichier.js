/* Pascal Studio — dialogue « Nouveau fichier » avec choix du type.
 *
 * Remplace la simple invite texte : l'utilisateur choisit un langage dans une
 * liste (logo + nom + extension) et n'a plus à saisir l'extension. Le nom saisi
 * peut contenir des sous-dossiers (« src/outils/tri »).
 *
 * Aucune dépendance à React : ce fichier est chargé depuis index.html, comme
 * assistant-ia-host.js. Il expose window.PSNewFileDialog() qui rend
 * {path, content} ou null si l'utilisateur annule.
 *
 * Le contenu initial proposé est un point de départ modifiable, jamais exécuté
 * ici : la création passe par l'API /api/create existante.
 */
(() => {
  'use strict';

  // Un seul emplacement décrit chaque type : logo, libellé, extension, modèle.
  // « logo » correspond au fichier dans /assets/logos-langages/ ; à défaut, la
  // lettre de repli est affichée (mêmes cas que le badge de l'arborescence).
  const TYPES = [
    { id: 'pascal', label: 'Pascal', ext: '.pas', logo: null, lettre: 'P',
      modele: 'program NouveauProgramme;\n\n{$mode objfpc}{$H+}\n\nbegin\n  WriteLn(\'Bonjour Pascal !\');\nend.\n' },
    /* Assembleur x86-64 (4.0.0). Pas de logo libre : la lettre de repli est
       employée, comme pour les autres langages sans logo. Le modèle est un
       programme Linux RÉELLEMENT assemblable et exécutable : un modèle qui ne
       s'assemble pas apprendrait que l'assembleur est cassé. Les extensions
       .s, .S et .nasm sont reconnues à l'ouverture, mais c'est .asm qui est
       proposé à la création. */
    { id: 'asm', label: 'Assembleur x86-64', ext: '.asm', logo: null, lettre: 'A',
      modele: '        .section .data\n'
            + 'message: .ascii "Bonjour assembleur\\n"\n'
            + '        .equ    LONGUEUR, . - message\n'
            + '\n'
            + '        .section .text\n'
            + '        .globl  main\n'
            + 'main:\n'
            + '        movq    $1, %rax            /* write */\n'
            + '        movq    $1, %rdi            /* stdout */\n'
            + '        leaq    message(%rip), %rsi\n'
            + '        movq    $LONGUEUR, %rdx\n'
            + '        syscall\n'
            + '        xorl    %eax, %eax          /* code de retour 0 */\n'
            + '        ret\n' },
    /* Fichier sans extension (4.2.0) : `ext` vide, donc rien n'est ajouté au
       nom saisi. Le code qui complète le nom teste déjà `type.ext`. */
    { id: 'texte', label: 'Texte sans extension', ext: '', logo: null,
      lettre: 'T', modele: '' },
    /* Programme Piet en format TEXTE (4.3.0). Piet est défini comme une image :
       un programme est un PNG. `.piett` en est la SOURCE — une cellule par
       codel, en deux lettres — et le PNG devient la forme compilée que le
       moteur Piet existant exécute. Le bundle route les `.piett` vers
       `.ps-piet-host`, où piet-studio.js rend la grille à peindre, la palette
       des 20 couleurs, l'aperçu PNG et l'exécution.
       Le modèle ci-dessous EST l'exemple que piet_texte.exemple() rend et que
       l'autocontrôle du module exécute : il écrit « 1 ». Les deux sont
       confrontés par ce correctif, donc ils ne peuvent pas diverger en
       silence. */
    { id: 'piett', label: 'Programme Piet (texte)', ext: '.piett', logo: null,
      lettre: '▦',
      modele: '# Programme Piet — format texte de Pascal Studio.\n'
            + '# Une cellule = un codel. Codes : bl (blanc), no (noir), et\n'
            + '# <teinte><luminosité> avec teinte r j v c b m (rouge jaune vert\n'
            + '# cyan bleu magenta) et luminosité c n s (claire normale sombre).\n'
            + '# La commande dépend du CHANGEMENT de couleur entre deux blocs.\n'
            + '# Ci-dessous : rouge claire -> rouge normale = push(1),\n'
            + '# puis rouge normale -> magenta sombre = out(number). Sortie : 1.\n'
            + 'piet 1\n'
            + 'codel 4\n'
            + 'grille 3 1\n'
            + 'rc rn ms\n' },
    { id: 'swift', label: 'Swift', ext: '.swift', logo: 'swift',
      modele: 'import Foundation\n\nprint("Bonjour Swift")\n' },
    { id: 'kotlin', label: 'Kotlin', ext: '.kt', logo: 'kotlin',
      modele: 'fun main() {\n    println("Bonjour Kotlin")\n}\n' },
    { id: 'python', label: 'Python', ext: '.py', logo: 'python',
      modele: '#!/usr/bin/env python3\n\nprint("Bonjour Python")\n' },
    { id: 'c', label: 'C', ext: '.c', logo: 'c',
      modele: '#include <stdio.h>\n\nint main(void) {\n    printf("Bonjour C\\n");\n    return 0;\n}\n' },
    { id: 'cpp', label: 'C++', ext: '.cpp', logo: 'cpp',
      modele: '#include <iostream>\n\nint main() {\n    std::cout << "Bonjour C++" << std::endl;\n    return 0;\n}\n' },
    { id: 'csharp', label: 'C#', ext: '.cs', logo: 'csharp',
      modele: 'using System;\n\nclass Programme {\n    static void Main() {\n        Console.WriteLine("Bonjour C#");\n    }\n}\n' },
    { id: 'javascript', label: 'JavaScript', ext: '.js', logo: 'javascript',
      modele: 'console.log("Bonjour JavaScript");\n' },
    { id: 'html', label: 'HTML', ext: '.html', logo: 'html',
      modele: '<!doctype html>\n<html lang="fr">\n<head>\n  <meta charset="utf-8">\n  <title>Nouvelle page</title>\n</head>\n<body>\n  <h1>Bonjour</h1>\n</body>\n</html>\n' },
    { id: 'css', label: 'CSS', ext: '.css', logo: 'css',
      modele: 'body {\n  font-family: system-ui, sans-serif;\n  margin: 2rem;\n}\n' },
    { id: 'php', label: 'PHP', ext: '.php', logo: 'php',
      modele: '<?php\n\necho "Bonjour PHP\\n";\n' },
    { id: 'rust', label: 'Rust', ext: '.rs', logo: 'rust',
      modele: 'fn main() {\n    println!("Bonjour Rust");\n}\n' },
    { id: 'go', label: 'Go', ext: '.go', logo: 'go',
      modele: 'package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Bonjour Go")\n}\n' },
    { id: 'ruby', label: 'Ruby', ext: '.rb', logo: 'ruby',
      modele: 'puts "Bonjour Ruby"\n' },
    { id: 'fortran', label: 'Fortran', ext: '.f90', logo: 'fortran',
      modele: 'program bonjour\n  implicit none\n  print *, "Bonjour Fortran"\nend program bonjour\n' },
    { id: 'perl', label: 'Perl', ext: '.pl', logo: 'perl',
      modele: 'use strict;\nuse warnings;\n\nprint "Bonjour Perl\\n";\n' },
    { id: 'basic', label: 'Yabasic', ext: '.bas', logo: null, lettre: 'Ba',
      modele: 'print "Bonjour BASIC"\nend\n' },
    { id: 'ocaml', label: 'OCaml', ext: '.ml', logo: 'ocaml',
      modele: 'let () = print_endline "Bonjour OCaml"\n' },
    { id: 'lua', label: 'Lua', ext: '.lua', logo: 'lua',
      modele: 'print("Bonjour Lua")\n' },
    { id: 'latex', label: 'LaTeX', ext: '.tex', logo: 'latex',
      modele: '\\documentclass{article}\n\\usepackage[utf8]{inputenc}\n\\usepackage[french]{babel}\n\n\\begin{document}\n\nBonjour LaTeX.\n\n\\end{document}\n' },
    { id: 'markdown', label: 'Markdown', ext: '.md', logo: 'markdown',
      modele: '# Titre\n\nTexte.\n' },
    { id: 'xml', label: 'XML', ext: '.xml', logo: 'xml',
      modele: '<?xml version="1.0" encoding="UTF-8"?>\n<racine>\n</racine>\n' },
    { id: 'makefile', label: 'Makefile', ext: '', logo: null, lettre: 'M', nomFixe: 'Makefile',
      autresNoms: ['makefile', 'GNUmakefile'],
      modele: 'all:\n\t@echo "Bonjour Make"\n' },
    { id: 'cmake', label: 'CMake', ext: '', logo: 'cmake', nomFixe: 'CMakeLists.txt',
      modele: 'cmake_minimum_required(VERSION 3.16)\nproject(NouveauProjet C)\n' },
    { id: 'plaintext', label: 'Texte brut', ext: '.txt', logo: null, lettre: 'TXT', modele: '' },
    // --------------------------------------------------------
    // Les dix langages ésotériques (3.8.0). Le modèle de chacun
    // est le programme d'aperçu validé par tests/smoke_facade.py :
    // il s'exécute réellement et se termine sur « success ».
    // --------------------------------------------------------
    { id: "brainfuck", label: "Brainfuck", ext: ".bf", logo: null, lettre: "BF",
      modele: "++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++." },
    { id: "whitespace", label: "Whitespace", ext: ".ws", logo: null, lettre: "WS",
      modele: "   \t  \t   \n\t\n     \t\t \t  \t\n\t\n  \n\n\n" },
    // Piet : le programme EST une image. Le fichier reçoit un data URI, à la
    // fois exécutable par le moteur et affichable par l'aperçu.
    { id: "piet", label: "Piet", ext: ".png", logo: null, lettre: "PI",
      modele: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAABCAIAAAAKOIRDAAAAEklEQVR42mP4z8Aw1NEBEPkfAJkjQ34qNXjxAAAAAElFTkSuQmCC" },
    { id: "lolcode", label: "LOLCODE", ext: ".lol", logo: null, lettre: "LOL",
      modele: "HAI 1.2\n  VISIBLE \"Hello, world!\"\nKTHXBYE\n" },
    { id: "arnoldc", label: "ArnoldC", ext: ".arnoldc", logo: null, lettre: "AC",
      modele: "IT'S SHOWTIME\nTALK TO THE HAND \"Hello, world!\"\nYOU HAVE BEEN TERMINATED\n" },
    { id: "chef", label: "Chef", ext: ".chef", logo: null, lettre: "CH",
      modele: "Hello World!.\n\nIngredients.\n72 ml h\n101 ml e\n108 ml l1\n108 ml l2\n111 ml o1\n32 ml sp\n119 ml w\n111 ml o2\n114 ml r\n108 ml l3\n100 ml d\n33 ml bang\n\nMethod.\nPut bang into the mixing bowl.\nPut d into the mixing bowl.\nPut l3 into the mixing bowl.\nPut r into the mixing bowl.\nPut o2 into the mixing bowl.\nPut w into the mixing bowl.\nPut sp into the mixing bowl.\nPut o1 into the mixing bowl.\nPut l2 into the mixing bowl.\nPut l1 into the mixing bowl.\nPut e into the mixing bowl.\nPut h into the mixing bowl.\nPour contents of the mixing bowl into the baking dish.\n\nServes 1.\n" },
    { id: "shakespeare", label: "Shakespeare", ext: ".spl", logo: null, lettre: "SPL",
      modele: "Hello.\n\nRomeo, a young man with a remarkable patience.\nJuliet, a likewise young woman of remarkable grace.\n\nAct I: The only act.\n\nScene I: The only scene.\n\n[Enter Romeo and Juliet]\n\nRomeo:\n Thou art as good as the sum of a big big big big big big tree and a tree!\n Speak thy mind!\n\n[Exeunt]\n" },
    { id: "intercal", label: "INTERCAL", ext: ".i", logo: null, lettre: "IN",
      modele: "DO .1 <- #72\nDO .2 <- #33\nPLEASE READ OUT .1\nDO .3 <- #0\nPLEASE READ OUT .2\nDO .1 <- #0\nDO .2 <- #0\nDO GIVE UP\n" },
    { id: "fractran", label: "FRACTRAN", ext: ".fra", logo: null, lettre: "FR",
      modele: "# FRACTRAN n'imprime rien : le r\u00e9sultat est l'\u00e9tat n, visible\n# dans l'inspecteur de variables. Ici 2 -> 3 -> 1, puis aucune\n# fraction ne s'applique et le programme s'arr\u00eate.\nn = 2\n3/2\n1/3\n" },
    { id: "malbolge", label: "Malbolge", ext: ".mal", logo: null, lettre: "MB",
      modele: "('&%:9]!~}|z2Vxwv-,POqponl$Hjig%eB@@>}=<M:9wv6WsU2T|nm-,jcL(I&%$#\"`CB]V?Tx<uVtT`Rpo3NlF.Jh++FdbCBA@?]!~|4XzyTT43Qsqq(Lnmkj\"Fhg${z@>" },
  ];

  // Catégories des onglets. « Tous » reste l'onglet par défaut : les 25 types
  // historiques y sont accessibles exactement comme avant, rien n'est caché.
  const ESOTERIQUES = new Set(["brainfuck", "whitespace", "piet", "lolcode", "arnoldc", "chef", "shakespeare", "intercal", "fractran", "malbolge"]);
  TYPES.forEach(t => { t.categorie = ESOTERIQUES.has(t.id) ? 'esoterique' : 'classique'; });
  const ONGLETS = [
    { id: 'tous', label: 'Tous' },
    { id: 'classique', label: 'Classiques' },
    { id: 'esoterique', label: 'Ésotériques' },
  ];

  // Extensions déjà reconnues : si l'utilisateur en saisit une, on ne double pas.
  const KNOWN_EXT = new Set();
  TYPES.forEach(t => { if (t.ext) KNOWN_EXT.add(t.ext.toLowerCase()); });
  ['.pp', '.p', '.lpr', '.inc', '.kts', '.cc', '.cxx', '.c++', '.hpp', '.hh', '.hxx', '.h',
   '.mjs', '.cjs', '.jsx', '.htm', '.phtml', '.pyw', '.sty', '.markdown', '.mdown',
   '.f', '.for', '.ftn', '.f77', '.f95', '.f03', '.f08', '.fpp', '.pm', '.yab', '.mli',
   '.csx', '.cake', '.mk', '.psnote'].forEach(e => KNOWN_EXT.add(e));

  const INVALID = /[\\\x00]/;
  const RESERVED = ['.', '..'];

  function extensionOf(name) {
    const base = String(name || '').split('/').pop();
    const i = base.lastIndexOf('.');
    return i > 0 ? base.slice(i).toLowerCase() : '';
  }

  // Extensions secondaires rattachées à un type déjà proposé. Elles servent au
  // modèle de repli et à la resynchronisation du type quand l'utilisateur saisit
  // lui-même un nom complet (« build.gradle.kts » reste du Kotlin).
  const ALIAS = {
    '.pp': 'pascal', '.p': 'pascal', '.lpr': 'pascal', '.inc': 'pascal',
    '.kts': 'kotlin',
    '.cc': 'cpp', '.cxx': 'cpp', '.c++': 'cpp', '.hpp': 'cpp', '.hh': 'cpp', '.hxx': 'cpp',
    '.h': 'c',
    '.mjs': 'javascript', '.cjs': 'javascript',
    '.htm': 'html',
    '.f': 'fortran', '.for': 'fortran', '.ftn': 'fortran', '.f77': 'fortran',
    '.f95': 'fortran', '.f03': 'fortran', '.f08': 'fortran', '.fpp': 'fortran',
    '.pm': 'perl', '.yab': 'basic', '.mli': 'ocaml',
    '.csx': 'csharp', '.cake': 'csharp',
    '.sty': 'latex', '.markdown': 'markdown', '.mdown': 'markdown',
    '.mk': 'makefile', '.psnote': 'plaintext',
  };

  function typeForName(name) {
    const base = String(name || '').split('/').pop();
    // Les noms imposés passent avant l'extension : « CMakeLists.txt » est du
    // CMake, pas du texte brut, exactement comme le fait vr() dans le bundle.
    const minuscule = base.toLowerCase();
    const fixe = TYPES.find(t => t.nomFixe &&
      (minuscule === t.nomFixe.toLowerCase() ||
       (t.autresNoms || []).some(autre => autre.toLowerCase() === minuscule)));
    if (fixe) return fixe;
    const ext = extensionOf(name);
    if (!ext) return null;
    return TYPES.find(t => t.ext && t.ext.toLowerCase() === ext)
        || TYPES.find(t => t.id === ALIAS[ext])
        || null;
  }

  // Retourne le chemin final : l'extension du type est ajoutée seulement si le
  // nom n'en porte pas déjà une reconnue. Pour Makefile et CMakeLists.txt le nom
  // est imposé : ce qui est saisi désigne le dossier, le dernier segment est
  // remplacé (« src/build » + Makefile donne « src/Makefile »). Un slash final
  // (« projet/ ») demande explicitement un sous-dossier.
  function finalPath(name, type) {
    const brut = String(name == null ? '' : name).trim();
    const dossier = /\/$/.test(brut);
    const parts = brut.replace(/^\/+/, '').split('/')
                      .filter(part => part !== '' && part !== '.');
    if (parts.some(part => RESERVED.includes(part) || INVALID.test(part))) return null;
    if (!parts.length) return (type && type.nomFixe) ? type.nomFixe : null;
    if (type && type.nomFixe) {
      if (dossier) parts.push(type.nomFixe);
      else parts[parts.length - 1] = type.nomFixe;
      return parts.join('/');
    }
    const clean = parts.join('/');
    if (type && type.ext && !KNOWN_EXT.has(extensionOf(clean))) return clean + type.ext;
    return clean;
  }

  function logoElement(type, extraClass) {
    const span = document.createElement('span');
    span.className = 'ps-newfile-logo' + (type.logo ? ' psl-' + type.logo : ' ps-logo-lettre') +
                     (extraClass ? ' ' + extraClass : '');
    span.setAttribute('aria-hidden', 'true');
    // Texte de repli uniquement pour les langages sans logo officiel libre.
    span.textContent = type.logo ? '' : (type.lettre || type.label.slice(0, 2));
    return span;
  }

  function buildDialog() {
    const overlay = document.createElement('div');
    overlay.className = 'overlay prompt-overlay ps-newfile-overlay';

    const form = document.createElement('form');
    form.className = 'modal prompt-modal ps-newfile-modal';

    const head = document.createElement('div');
    head.className = 'modal-head';
    const headText = document.createElement('div');
    const eyebrow = document.createElement('span');
    eyebrow.className = 'modal-eyebrow';
    eyebrow.textContent = 'PASCAL STUDIO';
    const title = document.createElement('h2');
    title.textContent = 'Nouveau fichier';
    headText.append(eyebrow, title);
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'ps-newfile-close';
    close.textContent = '✕';
    close.title = 'Fermer';
    head.append(headText, close);

    const caption = document.createElement('p');
    caption.className = 'ps-newfile-caption';
    caption.textContent = 'Choisissez un type : l’extension est ajoutée automatiquement. ' +
                          'Vous pouvez préciser un sous-dossier, par exemple « src/outils/tri ». ' +
                          'Pour Makefile et CMake, le nom du fichier est imposé : saisissez ' +
                          'seulement le dossier, par exemple « projet/ ».';

    const input = document.createElement('input');
    input.className = 'palette-input ps-newfile-name';
    input.type = 'text';
    input.placeholder = 'Nom du fichier';
    input.autocomplete = 'off';
    input.spellcheck = false;

    const preview = document.createElement('div');
    preview.className = 'ps-newfile-preview';

    // Onglets « Tous / Classiques / Ésotériques ». « Tous » reste l'onglet par
    // défaut : les types historiques y sont accessibles exactement comme avant.
    const tabs = document.createElement('div');
    tabs.className = 'ps-newfile-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'Catégorie de fichier');

    const grid = document.createElement('div');
    grid.className = 'ps-newfile-grid';
    grid.setAttribute('role', 'radiogroup');
    grid.setAttribute('aria-label', 'Type de fichier');

    const buttons = document.createElement('div');
    buttons.className = 'prompt-buttons';
    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.textContent = 'Annuler';
    const submit = document.createElement('button');
    submit.type = 'submit';
    submit.textContent = 'Créer le fichier';
    buttons.append(cancel, submit);

    form.append(head, caption, input, preview, tabs, grid, buttons);
    overlay.append(form);
    return { overlay, form, input, preview, tabs, grid, close, cancel };
  }

  function open(options) {
    const opts = options || {};
    return new Promise(resolve => {
      const { overlay, form, input, preview, tabs, grid, close, cancel } =
          buildDialog();
      let onglet = 'tous';
      const previousFocus = document.activeElement;
      let selected = TYPES.find(t => t.id === (opts.defaultType || 'pascal')) || TYPES[0];
      let settled = false;

      function finish(value) {
        if (settled) return;
        settled = true;
        document.removeEventListener('keydown', onGlobalKey, true);
        overlay.remove();
        // Rend le focus à l'élément qui l'avait, comme le fait l'invite d'origine.
        if (previousFocus && previousFocus.focus && document.contains(previousFocus)) {
          try { previousFocus.focus(); } catch (e) { /* élément devenu inactif */ }
        }
        resolve(value);
      }

      function renderPreview() {
        const path = finalPath(input.value, selected);
        preview.replaceChildren();
        const label = document.createElement('span');
        label.className = 'ps-newfile-preview-label';
        label.textContent = 'Fichier créé :';
        const value = document.createElement('b');
        value.className = path ? 'ok' : 'ko';
        value.textContent = path || 'Nom invalide';
        preview.append(label, value);
        const submitButton = form.querySelector('button[type=submit]');
        if (submitButton) submitButton.disabled = !path;
      }

      // La sélection est mise à jour en place : les boutons ne sont pas
      // reconstruits, donc la position et le focus clavier sont conservés.
      function typesVisibles() {
        return onglet === 'tous' ? TYPES
                                 : TYPES.filter(t => t.categorie === onglet);
      }

      // La sélection est repérée par identifiant et non par index : la grille ne
      // contient qu'une partie de TYPES dès qu'un onglet est actif.
      function majSelection() {
        Array.from(grid.children).forEach(bouton => {
          const actif = bouton.dataset.id === selected.id;
          bouton.className = 'ps-newfile-type' + (actif ? ' actif' : '');
          bouton.setAttribute('aria-checked', actif ? 'true' : 'false');
          bouton.tabIndex = actif ? 0 : -1;
        });
      }

      function renderTabs() {
        tabs.replaceChildren();
        ONGLETS.forEach(o => {
          const compte = o.id === 'tous' ? TYPES.length
                         : TYPES.filter(t => t.categorie === o.id).length;
          const bouton = document.createElement('button');
          bouton.type = 'button';
          bouton.className = 'ps-newfile-tab' + (o.id === onglet ? ' actif' : '');
          bouton.setAttribute('role', 'tab');
          bouton.setAttribute('aria-selected', o.id === onglet ? 'true' : 'false');
          bouton.tabIndex = o.id === onglet ? 0 : -1;
          const nom = document.createElement('span');
          nom.textContent = o.label;
          const badge = document.createElement('em');
          badge.className = 'ps-newfile-tab-count';
          badge.textContent = String(compte);
          bouton.append(nom, badge);
          bouton.addEventListener('click', () => {
            if (onglet === o.id) return;
            onglet = o.id;
            // Si le type sélectionné n'est pas dans cet onglet, on prend le
            // premier visible plutôt que de laisser une sélection invisible.
            if (!typesVisibles().some(t => t.id === selected.id)) {
              selected = typesVisibles()[0] || TYPES[0];
              renderPreview();
            }
            renderTabs();
            renderGrid();
          });
          tabs.append(bouton);
        });
      }

      function renderGrid() {
        grid.replaceChildren();
        typesVisibles().forEach(type => {
          const button = document.createElement('button');
          button.type = 'button';
          button.className = 'ps-newfile-type' + (type.id === selected.id ? ' actif' : '');
          button.dataset.id = type.id;
          button.setAttribute('role', 'radio');
          button.setAttribute('aria-checked', type.id === selected.id ? 'true' : 'false');
          button.tabIndex = type.id === selected.id ? 0 : -1;
          button.title = type.label + (type.nomFixe ? ' (' + type.nomFixe + ')'
                                                    : (type.ext ? ' (' + type.ext + ')' : ''));
          button.append(logoElement(type));
          const text = document.createElement('span');
          text.className = 'ps-newfile-type-text';
          const name = document.createElement('b');
          name.textContent = type.label;
          const ext = document.createElement('small');
          ext.textContent = type.nomFixe || type.ext || 'nom imposé';
          text.append(name, ext);
          button.append(text);
          button.addEventListener('click', () => {
            selected = type;
            // Nom imposé (Makefile, CMakeLists.txt) : on l'affiche dans le champ
            // pour que le résultat soit visible ; il ne reste qu'à préciser le
            // dossier si besoin.
            if (type.nomFixe && !input.value.trim()) input.value = type.nomFixe;
            majSelection();
            renderPreview();
            input.focus();
          });
          grid.append(button);
        });
      }

      function onGlobalKey(event) {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); finish(null); }
      }

      form.addEventListener('submit', event => {
        event.preventDefault();
        const path = finalPath(input.value, selected);
        if (!path) return;
        finish({ path, content: selected.modele || '', type: selected.id });
      });
      close.addEventListener('click', () => finish(null));
      cancel.addEventListener('click', () => finish(null));
      overlay.addEventListener('mousedown', event => { if (event.target === overlay) finish(null); });
      input.addEventListener('input', renderPreview);
      // Si le nom saisi porte déjà une extension connue, le type suit.
      input.addEventListener('change', () => {
        const found = typeForName(input.value);
        if (found && found.id !== selected.id) {
          selected = found;
          // « essai.spl » désigne du Shakespeare : si l'onglet actif ne le
          // montre pas, on bascule pour que la sélection reste visible.
          if (onglet !== 'tous' && found.categorie !== onglet) {
            onglet = found.categorie;
            renderTabs();
            renderGrid();
          } else {
            majSelection();
          }
        }
        renderPreview();
      });
      document.addEventListener('keydown', onGlobalKey, true);

      renderTabs();
      renderGrid();
      renderPreview();
      document.body.append(overlay);
      input.focus();
      if (opts.initialName) { input.value = opts.initialName; renderPreview(); }
    });
  }

  // API utilisée par le bundle React compilé (voir patch_langages_3.6.py).
  window.PSNewFileDialog = open;
  window.PSNewFileTypes = TYPES.map(t => ({ id: t.id, label: t.label, ext: t.ext,
                                            nomFixe: t.nomFixe || null,
                                            logo: !!t.logo,
                                            categorie: t.categorie,
                                            modele: t.modele || '' }));
  window.PSNewFileCategories = ONGLETS.map(o => o.id);
  // Sert aussi quand le fichier est créé sans passer par ce dialogue.
  window.PSNewFileTemplate = path => {
    const found = typeForName(path);
    return found ? (found.modele || '') : '';
  };
})();
