/* Section « Outils et dépendances » de la fenêtre Paramètres (4.1.0).
 *
 * POURQUOI CETTE SECTION EXISTE
 *   Pascal Studio parle à des dizaines d'outils externes : quarante langages,
 *   donc des compilateurs, des serveurs de langage, des adaptateurs de débogage,
 *   et pour la rétro-ingénierie binutils, Ghidra et un JDK. Aucun n'est livré
 *   dans l'AppImage. Jusqu'ici, chaque panneau affichait la commande à taper et
 *   s'arrêtait là : il fallait ouvrir un terminal, copier, coller, recommencer,
 *   et deviner l'ordre. Cette section fait l'inventaire COMPLET, dit ce qui
 *   manque, et installe ce qui peut l'être.
 *
 * CE QUI EST DEMANDÉ AVANT D'AGIR
 *   Une installation peut demander les droits root (apt). Rien n'est lancé sans
 *   un clic, la commande exacte est affichée AVANT, et c'est le système — polkit
 *   — qui demande le mot de passe : cette interface ne le voit jamais. Pour
 *   « Tout installer », une case à cocher séparée autorise les étapes en root ;
 *   sans elle, ces étapes sont sautées et leur commande reste affichée.
 *
 * CE QUE CETTE SECTION NE FAIT PAS
 *   - elle n'invente aucune adresse : les tailles et les URL viennent des API
 *     de GitHub et d'Adoptium, résolues au moment du clic. Un poids recopié
 *     périrait à la prochaine publication ;
 *   - elle n'affiche jamais un succès que le serveur n'a pas confirmé : après
 *     chaque installation le module RE-DÉTECTE le binaire, et une installation
 *     qui n'a rien donné est un échec nommé ;
 *   - elle ne cache pas les remarques : un outil non téléchargeable dit
 *     POURQUOI (pas de publication, archive .vsix, SDK hors Debian) et donne la
 *     page à consulter ;
 *   - elle ne laisse pas une tâche tourner sans bouton d'arrêt : un
 *     téléchargement de 570 Mo dure des minutes.
 *
 * Aucune ressource externe : pas de police distante, pas d'icône en image, pas
 * de CDN.
 */
(() => {
'use strict';

const API = '/api/outils';
const MARQUEUR = 'ps-4.1.0-outils';
const FAMILLES = ['compilateurs', 'serveurs de langage', 'débogage',
  'rétro-ingénierie', 'analyse avancée', 'bibliothèques Python',
  'construction', 'gestionnaires'];
const DELAI_SUIVI = 1200;

const $ = (sel, base) => (base || document).querySelector(sel);

let capacites = null;
let etat = null;
let taches = [];
let suivi = null;
let planification = null;
let confirmation = null;
let filtre = 'manquants';
let famille = 'toutes';
let avis = null;
let sonde = null;
let autoriseRacine = false;
let hote = null;
let racine = null;
let observateur = null;
let chargement = null;
let statut = null;        /* ce que le dernier geste a fait, toujours visible */
let dernierCode = null;   /* le code HTTP de la dernière requête */
let flottant = null;      /* le panneau de secours, si l'hôte n'existe pas */
let delegation = false;

/* ------------------------------------------------------------ utilitaires -- */

function el(nom, attributs) {
  const noeud = document.createElement(nom);
  const reste = Array.prototype.slice.call(arguments, 2);
  if (attributs) {
    Object.keys(attributs).forEach(function (cle) {
      const valeur = attributs[cle];
      if (valeur === null || valeur === undefined || valeur === false) return;
      if (cle === 'class') noeud.className = String(valeur);
      else if (cle === 'texte') noeud.textContent = String(valeur);
      else if (cle === 'html') noeud.innerHTML = String(valeur);
      else if (cle.slice(0, 2) === 'on' && typeof valeur === 'function') {
        noeud.addEventListener(cle.slice(2), valeur);
      } else noeud.setAttribute(cle, String(valeur));
    });
  }
  reste.forEach(function (enfant) {
    if (enfant === null || enfant === undefined || enfant === false) return;
    noeud.appendChild(typeof enfant === 'object' ? enfant
      : document.createTextNode(String(enfant)));
  });
  return noeud;
}

function contient(parent, enfant) {
  /* document.contains n'existe pas partout (et pas dans le harnais DOM des
   * bancs) : la remontée manuelle est équivalente et ne dépend de rien. */
  if (parent && typeof parent.contains === 'function') {
    try { return parent.contains(enfant); } catch (exc) { /* repli */ }
  }
  let noeud = enfant;
  while (noeud) {
    if (noeud === parent) return true;
    noeud = noeud.parentNode;
  }
  return false;
}

/* replaceChildren() et pas une boucle sur firstChild/removeChild : c'est la
 * convention des autres scripts hôtes de ce produit (re-studio.js,
 * data-studio.js), et removeChild n'existe pas dans le harnais DOM des bancs. */
function vider(noeud) { if (noeud) noeud.replaceChildren(); return noeud; }

function octets(n) {
  let v = Number(n || 0);
  const unites = ['o', 'Ko', 'Mo', 'Go', 'To'];
  let i = 0;
  while (Math.abs(v) >= 1024 && i < unites.length - 1) { v /= 1024; i += 1; }
  return (i === 0 ? String(Math.round(v)) : v.toFixed(1)) + ' ' + unites[i];
}

function dire(ton, texte) {
  avis = { ton: ton, texte: texte };
  statut = { ton: ton, texte: texte, heure: new Date().toLocaleTimeString() };
  /* La ligne d'état est mise à jour PAR TEXTE, sans reconstruction : un clic
   * qui tombe pendant un rendu complet ne perd pas sa réponse, et la réponse
   * reste en tête de section, donc visible dans une fenêtre modale étroite. */
  const ligne = racine ? racine.querySelector('.psoutils-statut-texte') : null;
  if (ligne) {
    ligne.textContent = statut.heure + ' — ' + texte;
    ligne.setAttribute('data-ton', ton);
  } else rendre();
}

function expliquerStatut(code) {
  /* Un code brut ne dit rien. Les trois cas réels sont distingués, parce que
   * leurs remèdes n'ont rien à voir entre eux. */
  if (code === 404) return 'le serveur ne connaît pas /api/outils : cette '
    + 'image ne porte pas la route (construction antérieure à la 4.1.0).';
  if (code === 403 || code === 401) return 'la requête a été refusée par la '
    + 'garde locale du serveur.';
  if (code >= 500) return 'le serveur a échoué (code ' + code + ').';
  return 'le serveur a répondu ' + code + '.';
}

async function appeler(action, donnees) {
  const corps = Object.assign({ action: action }, donnees || {});
  try {
    const reponse = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(corps)
    });
    dernierCode = reponse.status;
    let lu = null;
    try { lu = await reponse.json(); } catch (exc) { lu = null; }
    if (!reponse.ok) {
      /* Le serveur écrit `error` quand une branche lève (400) et `erreur` dans
       * un refus métier. Ne garder que l'un des deux perdrait la raison, qui
       * est précisément ce que l'utilisateur doit lire. */
      return { ok: false, code: reponse.status,
        error: (lu && (lu.error || lu.erreur))
          || ('Action « ' + action + ' » : ' + expliquerStatut(reponse.status)) };
    }
    return lu;
  } catch (exc) {
    dernierCode = 0;
    return { ok: false, code: 0,
      error: 'La requête « ' + action + ' » n’a pas abouti : ' + exc
        + '. Le serveur de Pascal Studio répond-il sur ' + API + ' ?' };
  }
}

async function lire() {
  try {
    const reponse = await fetch(API);
    const lu = await reponse.json();
    if (!reponse.ok) {
      capacites = null;
      dernierCode = reponse.status;
      dire('echec', 'L’inventaire n’a pas pu être lu : '
        + ((lu && (lu.error || lu.erreur)) || expliquerStatut(reponse.status)));
      return false;
    }
    dernierCode = reponse.status;
    capacites = lu;
    etat = lu.etat || null;
    taches = lu.taches || [];
    const active = taches.filter(function (t) {
      return t.etat === 'en cours' || t.etat === 'en attente';
    });
    if (active.length && !sonde) demarrerSuivi(active[0].sid);
    rendre();
    return true;
  } catch (exc) {
    dernierCode = 0;
    dire('echec', 'L’inventaire n’a pas pu être lu : ' + exc
      + '. Le serveur de Pascal Studio répond-il sur ' + API + ' ?');
    return false;
  }
}

/* ------------------------------------------------------------------ actions -- */

async function verifierVersions() {
  dire('info', 'Lecture des versions : chaque outil présent est lancé avec '
    + '`--version`. Cela peut prendre une minute.');
  const lu = await appeler('versions', {});
  if (lu && lu.ok === false) { dire('echec', lu.error || 'Vérification '
    + 'impossible.'); return; }
  if (lu && lu.liste) {
    etat = lu;
    dire('ok', lu.resume || 'Inventaire vérifié.');
  }
}

async function preparerTout() {
  dire('info', 'Résolution des adresses et des tailles : cela interroge les '
    + 'API de publication. Rien n’est encore téléchargé.');
  const lu = await appeler('plan', { tout: true, resoudre: true,
    racine_autorisee: autoriseRacine });
  if (!lu || lu.ok === false) {
    dire('echec', (lu && (lu.error || lu.erreur)) || 'Le plan n’a pas pu être '
      + 'établi.');
    return;
  }
  /* Le plan EST la confirmation : ses étapes affichent les commandes exactes
   * et le bouton « Lancer ce plan » est le second clic. Poser aussi un bloc de
   * confirmation masquerait le plan, puisque la section n'en rend qu'un des
   * deux. */
  planification = lu;
  confirmation = null;
  avis = null;
  rendre();
}

async function installerUn(id) {
  const outil = outilParId(id);
  if (!outil) { dire('echec', 'Outil inconnu : ' + id); return; }
  if (outil.racine && !autoriseRacine) {
    confirmation = { tout: false, ids: [id], racine: true, outil: outil };
    avis = null;
    rendre();
    return;
  }
  await lancer([id], false, outil.racine && autoriseRacine);
}

async function lancer(ids, tout, racine) {
  confirmation = null;
  planification = null;
  dire('info', 'Installation démarrée. Le journal s’affiche ci-dessous, et '
    + 'l’arrêt est possible à tout moment.');
  const lu = await appeler('installer', {
    identifiants: ids || [], tout: !!tout,
    racine_autorisee: !!racine, resoudre: true, agent: 'parametres'
  });
  if (!lu || lu.ok === false) {
    dire('echec', (lu && (lu.error || lu.erreur)) || 'L’installation n’a pas '
      + 'pu démarrer.');
    if (lu && lu.plan && lu.plan.resume) avis.texte += ' — ' + lu.plan.resume;
    rendre();
    return;
  }
  dire('info', lu.resume || 'Installation en cours.');
  demarrerSuivi(lu.sid);
}

function demarrerSuivi(sid) {
  if (!sid) return;
  arreterSuivi();
  suivi = { sid: sid, depuis: 0, lignes: [], etat: 'en cours',
    progression: null, tronque: 0, resultats: [] };
  rendre();
  sonde = setInterval(async function () { await suivre(); }, DELAI_SUIVI);
  suivre();
}

function arreterSuivi() {
  if (sonde) { clearInterval(sonde); sonde = null; }
}

async function suivre() {
  if (!suivi) return;
  const lu = await appeler('suivre', { sid: suivi.sid, depuis: suivi.depuis });
  if (!lu || lu.ok === false) {
    arreterSuivi();
    dire('echec', (lu && lu.error) || 'Le suivi de la tâche a échoué.');
    return;
  }
  suivi.depuis = lu.depuis || suivi.depuis;
  suivi.etat = lu.etat;
  suivi.progression = lu.progression || null;
  suivi.tronque = lu.journal_tronque || 0;
  suivi.resultats = lu.resultats || [];
  if (lu.lignes && lu.lignes.length) {
    suivi.lignes = suivi.lignes.concat(lu.lignes);
    if (suivi.lignes.length > 800) suivi.lignes = suivi.lignes.slice(-800);
  }
  if (lu.etat !== 'en cours' && lu.etat !== 'en attente') {
    arreterSuivi();
    const echecs = suivi.resultats.filter(function (r) { return !r.ok; });
    const ton = lu.etat === 'terminé' ? 'ok' : (echecs.length ? 'echec' : 'info');
    dire(ton, 'Tâche ' + lu.etat + ' — ' + suivi.resultats.length
      + ' étape(s), ' + echecs.length + ' échec(s).'
      + (echecs.length ? ' Première raison : '
        + (echecs[0].erreur || 'non précisée') : ''));
    await lire();
    return;
  }
  rendre();
}

async function arreterTache() {
  if (!suivi) return;
  const lu = await appeler('arreter', { sid: suivi.sid });
  dire(lu && lu.ok ? 'info' : 'echec',
    (lu && (lu.error || 'Arrêt demandé.')) || 'Arrêt impossible.');
  await suivre();
}

async function copier(texte) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(texte);
      dire('ok', 'Commande copiée dans le presse-papiers.');
      return;
    }
  } catch (exc) { /* la zone de texte ci-dessous reste le repli */ }
  dire('info', 'Le presse-papiers n’est pas accessible d’ici : la commande '
    + 'est affichée, sélectionnez-la.');
}

function outilParId(id) {
  if (!etat || !etat.liste) return null;
  for (let i = 0; i < etat.liste.length; i += 1) {
    if (etat.liste[i].id === id) return etat.liste[i];
  }
  return null;
}

/* ------------------------------------------------------------------- rendu -- */

function construire() {
  return el('div', { class: 'psoutils', 'data-marqueur': MARQUEUR });
}

function rendre() {
  if (!racine || !hote || !contient(document.documentElement, hote)) return;
  vider(racine);
  racine.appendChild(ligneEtat());
  racine.appendChild(entete());
  if (capacites && capacites.dossier) racine.appendChild(dossier());
  if (!etat) {
    racine.appendChild(el('div', { class: 'psoutils-vide',
      texte: chargement ? 'Inventaire en cours de lecture…'
        : 'L’inventaire n’a pas encore pu être lu.' }));
  } else {
    racine.appendChild(filtres());
    if (confirmation) racine.appendChild(blocConfirmation());
    else if (planification) racine.appendChild(blocPlan());
    racine.appendChild(liste());
  }
  if (suivi) racine.appendChild(journal());
  if (avis) racine.appendChild(el('div', { class: 'psoutils-avis',
    'data-ton': avis.ton, texte: avis.texte }));
}

function ligneEtat() {
  /* Toujours présente, même vide : c'est l'endroit où un clic vient écrire ce
   * qu'il a fait. Sans elle, un échec silencieux ressemble à un bouton mort. */
  const texte = statut ? (statut.heure + ' — ' + statut.texte)
    : 'Aucune action pour l’instant. Les boutons ci-dessous écrivent ici ce '
      + 'qu’ils font.';
  return el('div', { class: 'psoutils-statut' },
    el('span', { class: 'psoutils-statut-texte',
      'data-ton': statut ? statut.ton : 'info', texte: texte }),
    dernierCode === null ? null
      : el('span', { class: 'psoutils-code',
        texte: 'dernière réponse : ' + (dernierCode || 'aucune') }));
}

function entete() {
  const resume = etat ? etat.resume : 'Inventaire des outils externes de '
    + 'Pascal Studio.';
  return el('div', { class: 'psoutils-head' },
    el('span', { class: 'psoutils-eyebrow', texte: 'OUTILS ET DÉPENDANCES' }),
    el('h3', { class: 'psoutils-titre',
      texte: 'Ce qui manque, et comment l’obtenir' }),
    el('p', { class: 'psoutils-resume', texte: resume }),
    el('div', { class: 'psoutils-actions' },
      el('button', { type: 'button', 'data-acte': 'verifier',
        title: 'Lance chaque outil présent avec --version pour lire sa '
          + 'version. Lent, mais réel.' }, 'Vérifier les versions'),
      el('button', { type: 'button', 'data-acte': 'preparer',
        title: 'Résout les adresses et les tailles, puis affiche le plan. '
          + 'Rien n’est téléchargé à cette étape.' }, 'Préparer'),
      el('button', { type: 'button', class: 'psoutils-primaire',
        'data-acte': 'tout',
        title: 'Affiche le plan de tout ce qui manque, puis le lance après '
          + 'confirmation.' }, 'Tout installer…'),
      el('button', { type: 'button', 'data-acte': 'actualiser',
        title: 'Relit l’inventaire.' }, 'Actualiser'),
      autorisationRacine()),
    explication());
}

function autorisationRacine() {
  const boite = el('input', { type: 'checkbox', id: 'psoutils-racine',
    checked: autoriseRacine,
    onchange: function (evt) {
      autoriseRacine = !!(evt.target && evt.target.checked);
      if (planification) preparerTout();
      else rendre();
    } });
  return el('label', { class: 'psoutils-racine',
    title: 'Sans cette case, les paquets Debian ne sont pas installés : leur '
      + 'commande reste affichée pour que vous la tapiez vous-même. Avec, '
      + 'c’est le système qui demande le mot de passe.' },
  boite, ' Autoriser les installations qui demandent les droits root');
}

function explication() {
  if (!capacites) return null;
  return el('p', { class: 'psoutils-role', texte: 'Aucune adresse n’est '
    + 'inventée : les tailles et les URL sont résolues au moment du clic '
    + 'auprès des publications GitHub et de l’API Adoptium. Ce qui ne peut pas '
    + 'être installé d’ici le dit, avec la raison et la page à consulter.' });
}

function dossier() {
  const d = capacites.dossier;
  return el('div', { class: 'psoutils-dossier' },
    'Dossier des outils : ', el('code', { texte: d.dossier }),
    ' — ', d.dans_path ? 'dans PATH' : 'PAS dans PATH',
    ' — place libre : ' + octets(d.libre_octets),
    d.variable ? ' (variable ' + d.variable + ')' : '');
}

function filtres() {
  const boutons = [];
  [['manquants', 'Manquants'], ['tous', 'Tous'], ['presents', 'Présents'],
    ['installables', 'Installables d’ici']].forEach(function (pair) {
    boutons.push(el('button', { type: 'button',
      'aria-pressed': String(filtre === pair[0]),
      'data-acte': 'filtrer', 'data-valeur': pair[0],
      texte: pair[1] }));
  });
  const familles = el('select', {
    onchange: function (evt) { famille = evt.target.value; rendre(); }
  }, el('option', { value: 'toutes', texte: 'Toutes les familles' }));
  FAMILLES.forEach(function (f) {
    const compte = etat.familles && etat.familles[f] ? etat.familles[f] : null;
    familles.appendChild(el('option', { value: f,
      texte: f + (compte ? ' (' + compte.manquants + '/' + compte.total + ')'
        : '') }));
  });
  familles.value = famille;
  return el('div', { class: 'psoutils-filtres' }, boutons, familles);
}

function selection() {
  const liste = (etat && etat.liste) || [];
  return liste.filter(function (o) {
    if (famille !== 'toutes' && o.famille !== famille) return false;
    if (filtre === 'manquants') return !o.present;
    if (filtre === 'presents') return o.present;
    if (filtre === 'installables') return !o.present && o.telechargeable;
    return true;
  });
}

function liste() {
  const outils = selection();
  if (!outils.length) {
    return el('div', { class: 'psoutils-vide',
      texte: 'Aucun outil dans cette sélection.' });
  }
  const bloc = el('div', { class: 'psoutils-liste' });
  let courante = null;
  outils.forEach(function (o) {
    if (o.famille !== courante) {
      courante = o.famille;
      bloc.appendChild(el('div', { class: 'psoutils-famille',
        texte: courante }));
    }
    bloc.appendChild(ligne(o));
  });
  return bloc;
}

function ligne(o) {
  const installe = suivi && suivi.resultats ? suivi.resultats.filter(
    function (r) { return r.outils && r.outils.indexOf(o.id) >= 0; }) : [];
  const ton = installe.length ? (installe[0].ok ? 'oui' : 'echec') : '';
  const boutons = [];
  if (!o.present && o.telechargeable) {
    boutons.push(el('button', { type: 'button', 'data-acte': 'installer',
      'data-id': o.id,
      title: o.racine ? 'Demande les droits root : la commande est affichée '
        + 'avant, et c’est le système qui demande le mot de passe.'
        : 'Installé dans le dossier des outils, sans droits root.' },
    o.racine ? 'Installer (root)' : 'Installer'));
  }
  const commande = o.commande || '';
  if (commande) {
    boutons.push(el('button', { type: 'button', 'data-acte': 'copier',
      'data-id': o.id,
      title: 'Copie la commande à taper vous-même.' }, 'Copier'));
  }
  const morceaux = [
    el('span', { class: 'psoutils-puce',
      texte: o.present ? '✓' : (o.telechargeable ? '⚠' : '·'),
      title: o.present ? 'Présent' : 'Manquant' }),
    el('span', { class: 'psoutils-nom' }, o.nom,
      el('span', { class: 'psoutils-voie', texte: o.voie })),
    el('span', { class: 'psoutils-role', texte: o.role || '' }),
    el('span', { class: 'psoutils-outils' }, boutons)
  ];
  if (commande) {
    morceaux.push(el('code', { class: 'psoutils-commande', texte: commande }));
  }
  const versions = (o.detection || []).filter(function (d) {
    return d.present && d.version;
  }).map(function (d) { return d.nom + ' ' + d.version; });
  const notes = (o.notes || []).concat(versions.length
    ? ['Présent : ' + versions.join(', ')] : []);
  if (!o.present && o.manquants && o.manquants.length) {
    notes.unshift('Absent(s) : ' + o.manquants.join(', ') + '.');
  }
  if (notes.length) {
    morceaux.push(el('ul', { class: 'psoutils-notes' },
      notes.slice(0, 4).map(function (n) {
        return el('li', { texte: n });
      })));
  }
  return el('div', { class: 'psoutils-ligne', 'data-id': o.id,
    'data-present': String(!!o.present), 'data-installe': ton,
    'data-voie': o.voie }, morceaux);
}

function blocConfirmation() {
  const ids = confirmation.ids || [];
  const racine = !!confirmation.racine;
  const outils = ids.map(outilParId).filter(function (o) { return !!o; });
  const commandes = outils.map(function (o) { return o.commande || o.id; });
  return el('div', { class: 'psoutils-confirm', 'data-racine': String(racine) },
    el('b', { texte: racine ? 'Cette installation demande les droits root.'
      : 'Confirmer l’installation.' }),
    el('p', { texte: racine
      ? 'Le système affichera sa propre fenêtre d’authentification. Pascal '
        + 'Studio ne voit jamais le mot de passe. Seuls les verbes '
        + 'd’installation sont employés : jamais remove, purge, autoremove ni '
        + 'upgrade.'
      : 'Rien ne demande les droits root : tout est rangé dans le dossier des '
        + 'outils.' }),
    el('code', { texte: commandes.join('\n') }),
    el('div', { class: 'psoutils-actions' },
      el('button', { type: 'button', class: 'psoutils-primaire',
        'data-acte': 'confirmer', texte: 'Confirmer' }),
      el('button', { type: 'button', 'data-acte': 'annuler',
        texte: 'Annuler' }),
      racine && !autoriseRacine ? el('span', {
        texte: ' La case « Autoriser les installations qui demandent les '
          + 'droits root » n’est pas cochée : cette étape sera sautée et la '
          + 'commande restera affichée.' }) : null));
}

function blocPlan() {
  const etapes = planification.etapes || [];
  return el('div', { class: 'psoutils-etapes' },
    el('b', { texte: planification.resume || '' }),
    el('div', {}, etapes.map(function (e) {
      return el('div', { class: 'psoutils-etape',
        'data-racine': String(!!e.racine), 'data-voie': e.voie },
      el('div', {}, (e.racine ? 'root · ' : '') + e.voie + ' · '
        + (e.outils || []).length + ' outil(s)'
        + (e.taille_attendue ? ' · ' + octets(e.taille_attendue) : '')),
      el('code', { texte: e.commande_texte || '' }),
      (e.notes || []).slice(0, 3).map(function (n) {
        return el('div', { class: 'psoutils-role', texte: n });
      }),
      e.executable === false ? el('div', { class: 'psoutils-commande',
        texte: 'Cette étape ne sera pas exécutée. À taper vous-même : '
          + (e.commande_manuelle || '') }) : null);
    })),
    (planification.notes || []).length ? el('ul', { class: 'psoutils-notes' },
      planification.notes.slice(0, 12).map(function (n) {
        return el('li', { texte: n });
      })) : null,
    el('div', { class: 'psoutils-actions' },
      el('button', { type: 'button', class: 'psoutils-primaire',
        'data-acte': 'lancer', texte: 'Lancer ce plan' }),
      el('button', { type: 'button', 'data-acte': 'annuler',
        texte: 'Annuler' })));
}

function journal() {
  const p = suivi.progression || {};
  const pourcentage = typeof p.pourcentage === 'number' ? p.pourcentage : null;
  const tete = el('div', { class: 'psoutils-journal-tete' },
    el('span', { texte: 'Tâche ' + suivi.sid + ' — ' + suivi.etat
      + (pourcentage === null ? '' : ' — ' + pourcentage.toFixed(1) + ' %')
      + (p.vitesse ? ' — ' + octets(p.vitesse) + '/s' : '')
      + (p.reste ? ' — reste ' + p.reste + ' s' : '') }),
    suivi.etat === 'en cours' || suivi.etat === 'en attente'
      ? el('button', { type: 'button', 'data-acte': 'arreter',
        texte: 'Arrêter' }) : null);
  const lignes = el('div', { class: 'psoutils-lignes' });
  suivi.lignes.slice(-400).forEach(function (l) {
    lignes.appendChild(el('div', { 'data-niveau': l.niveau,
      texte: l.texte }));
  });
  if (!suivi.lignes.length) {
    lignes.appendChild(el('div', { texte: 'Aucune ligne pour l’instant.' }));
  }
  return el('div', { class: 'psoutils-journal' }, tete,
    el('div', { class: 'psoutils-barre' },
      el('span', { style: 'width:' + (pourcentage === null ? 0 : pourcentage)
        + '%' })),
    lignes,
    suivi.tronque ? el('div', { class: 'psoutils-commande',
      texte: suivi.tronque + ' ligne(s) plus ancienne(s) ont été jetées : le '
        + 'journal est borné.' }) : null);
}

/* ------------------------------------------------------------- attachement -- */

function agirDepuisEvenement(evt) {
  /* Un seul écouteur pour toute la section. Les boutons sont recréés à chaque
   * rendu : un écouteur posé sur un bouton disparaît avec lui, et un clic qui
   * arrive pendant la reconstruction ne trouve plus personne. L'événement
   * remonte jusqu'à la racine, qui, elle, ne bouge pas. */
  const cible = evt && evt.target;
  let noeud = cible;
  while (noeud && noeud !== racine) {
    const acte = noeud.getAttribute && noeud.getAttribute('data-acte');
    if (acte) {
      const id = noeud.getAttribute('data-id') || '';
      const valeur = noeud.getAttribute('data-valeur') || '';
      if (typeof evt.preventDefault === 'function') evt.preventDefault();
      dispatch(acte, id, { valeur: valeur });
      return;
    }
    noeud = noeud.parentNode;
  }
}

function dispatch(acte, id, evtValeur) {
  if (acte === 'verifier') return verifierVersions();
  if (acte === 'preparer') return preparerTout();
  if (acte === 'tout') { confirmation = null; return preparerTout(); }
  if (acte === 'actualiser') return lire();
  if (acte === 'installer') return installerUn(id);
  if (acte === 'copier') {
    const outil = outilParId(id);
    return copier((outil && outil.commande) || '');
  }
  if (acte === 'confirmer') {
    if (!confirmation) return dire('echec', 'Rien à confirmer.');
    return lancer(confirmation.ids, !!confirmation.tout,
      confirmation.racine && autoriseRacine);
  }
  if (acte === 'annuler') {
    confirmation = null;
    planification = null;
    return rendre();
  }
  if (acte === 'lancer') {
    if (!planification) return dire('echec', 'Aucun plan à lancer.');
    return lancer(planification.identifiants || [], true,
      planification.racine && autoriseRacine);
  }
  if (acte === 'arreter') return arreterTache();
  if (acte === 'filtrer') {
    filtre = (evtValeur && evtValeur.valeur) || 'manquants';
    return rendre();
  }
  if (acte === 'fermer-flottant') return fermerFlottant();
  dire('info', 'Action inconnue : ' + acte);
  return null;
}

function attacher() {
  const cible = $('.ps-outils-host');
  if (!cible) {
    if (hote && !contient(document.documentElement, hote)) {
      hote = null; racine = null;
    }
    return;
  }
  if (cible === hote && racine && contient(cible, racine)) return;
  hote = cible;
  vider(hote);
  racine = construire();
  if (!delegation) {
    racine.addEventListener('click', agirDepuisEvenement);
    delegation = true;
  }
  hote.appendChild(racine);
  /* Un script hôte qui écrit dans le DOM doit écarter ses propres
   * enregistrements : sinon l'observateur se réveille sur ses propres
   * modifications et la boucle ne s'arrête plus. */
  if (observateur && observateur.takeRecords) observateur.takeRecords();
  if (!capacites && !chargement) {
    chargement = true;
    rendre();
    lire().then(function () { chargement = false; rendre(); });
  } else rendre();
}

/* Un seul observateur pour toute l'application, via ps-hotes.js. Cinq
 * observateurs sur document.documentElement plus cinq sondes à 2 s
 * saturaient le fil principal : chaque mutation du DOM — une frappe dans
 * Monaco, une ligne de terminal, un diagnostic — réveillait les cinq, et un
 * bouton latéral mettait plusieurs secondes à changer l'affichage. Le repli
 * ci-dessous sert aux bancs, qui jouent ce script seul, sans PSHotes. */
function suivreHote(selecteur, rappel) {
  /* L'objet rendu a les deux méthodes d'un MutationObserver : les scripts
   * existants appellent .disconnect() pour écarter leurs propres écritures
   * et .takeRecords() quand il existe. Rendre une simple fonction d'arrêt
   * casserait ces appels — c'est ce qu'a fait la première version. */
  const arret = { disconnect: function () {},
    takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const observateur = new MutationObserver(rappel);
  observateur.observe(document.documentElement,
    { subtree: true, childList: true });
  const filet = typeof setInterval === 'function'
    ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () {
    observateur.disconnect();
    if (filet) clearInterval(filet);
  };
  return arret;
}
function demarrerObservateur() {
  if (observateur) return;
  observateur = suivreHote('.ps-outils-host', attacher);
}

/* ---- le panneau de secours ------------------------------------------------
 * Si l'hôte .ps-outils-host n'apparaît pas — bundle non patché, fenêtre des
 * paramètres jamais ouverte — la section serait introuvable et l'utilisateur
 * conclurait que la fonctionnalité n'existe pas. Huit secondes après le
 * chargement, un bouton fixe apparaît en bas à droite ; il ouvre la section
 * dans un panneau flottant, et dit pourquoi il est là.
 */
let delaiSecours = null;

function ouvrirFlottant() {
  if (flottant && contient(document.documentElement, flottant)) return;
  flottant = el('div', { class: 'psoutils-flottant' },
    el('div', { class: 'psoutils-flottant-tete' },
      el('b', { texte: 'Outils et dépendances' }),
      el('button', { type: 'button', 'data-acte': 'fermer-flottant',
        texte: '×' })),
    el('p', { class: 'psoutils-role',
      texte: 'La fenêtre des paramètres de cette interface ne porte pas '
        + 'l’élément .ps-outils-host : ce panneau de secours la remplace. '
        + 'Le contenu est le même.' }));
  const corps = el('div', { class: 'psoutils-flottant-corps' });
  flottant.appendChild(corps);
  flottant.addEventListener('click', function (evt) {
    const saved = racine;
    racine = corps;
    agirDepuisEvenement(evt);
    racine = saved;
  });
  document.body.appendChild(flottant);
  const saved = racine;
  const savedHote = hote;
  racine = corps;
  hote = flottant;
  if (!capacites && !chargement) {
    chargement = true;
    rendre();
    lire().then(function () { chargement = false; rendre(); });
  } else rendre();
  racine = saved;
  hote = savedHote;
}

function fermerFlottant() {
  if (flottant && typeof flottant.remove === 'function') flottant.remove();
  flottant = null;
}

function surveillerSecours() {
  if (delaiSecours) return;
  delaiSecours = setTimeout(function () {
    delaiSecours = null;
    if (!$('.ps-outils-host') && !flottant) {
      const bouton = el('button', { class: 'psoutils-secours', type: 'button',
        title: 'La fenêtre des paramètres de cette interface ne porte pas '
          + 'l’élément attendu : ce bouton ouvre la section dans un panneau '
          + 'flottant.',
        onclick: ouvrirFlottant }, 'Outils et dépendances');
      document.body.appendChild(bouton);
    }
  }, 8000);
}

window.PSOutils = {
  marqueur: MARQUEUR,
  api: API,
  familles: FAMILLES,
  lire: lire,
  rendre: rendre,
  appeler: appeler,
  verifierVersions: verifierVersions,
  preparerTout: preparerTout,
  installerUn: installerUn,
  lancer: lancer,
  arreterTache: arreterTache,
  demarrerSuivi: demarrerSuivi,
  arreterSuivi: arreterSuivi,
  copier: copier,
  octets: octets,
  attacher: attacher,
  ouvrirFlottant: ouvrirFlottant,
  fermerFlottant: fermerFlottant,
  dispatch: dispatch,
  diagnostic: function () {
    return { hote_present: !!$('.ps-outils-host'), section_rendue: !!racine,
      dernier_code: dernierCode, statut: statut,
      capacites_lues: !!capacites, inventaire_lu: !!etat,
      outils: etat && etat.liste ? etat.liste.length : 0,
      manquants: etat ? etat.manquants : null,
      tache: suivi ? { sid: suivi.sid, etat: suivi.etat } : null,
      delegation: delegation };
  },
  autoriserRacine: function (valeur) { autoriseRacine = !!valeur; rendre(); },
  filtrer: function (quoi, quelle) {
    if (quoi === 'filtre') filtre = quelle;
    if (quoi === 'famille') famille = quelle;
    rendre();
  },
  etat: function () {
    return { capacites: capacites, etat: etat, suivi: suivi,
      planification: planification, confirmation: confirmation,
      filtre: filtre, famille: famille, avis: avis,
      autoriseRacine: autoriseRacine, taches: taches };
  },
  injecter: function (donnees) {
    capacites = donnees.capacites || capacites;
    etat = donnees.etat || etat;
    suivi = donnees.suivi || suivi;
    planification = donnees.planification || planification;
    confirmation = donnees.confirmation || confirmation;
    avis = donnees.avis || avis;
    rendre();
  }
};

/* Le démarrage est enveloppé : une exception ici écrivait dans la console et
 * nulle part ailleurs, donc la section n'apparaissait pas sans aucune trace. */
try {
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attacher, { once: true });
    document.addEventListener('DOMContentLoaded', surveillerSecours,
      { once: true });
  } else {
    attacher();
    surveillerSecours();
  }
  demarrerObservateur();
  if (!window.PSHotes) setInterval(attacher, 5000);
} catch (exc) {
  if (typeof console !== 'undefined' && console.error) {
    console.error('[outils-studio] démarrage impossible :', exc);
  }
  try {
    const hote = document.querySelector('.ps-outils-host');
    if (hote) {
      hote.textContent = 'La section « Outils et dépendances » n’a pas pu '
        + 'démarrer : ' + exc;
    }
  } catch (interne) { /* rien d'autre à tenter */ }
}
})();
