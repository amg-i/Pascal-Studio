/* Éditeur graphique de Piet (4.3.0) — format texte `.piett`.
 *
 * POURQUOI
 *   Piet est défini comme une image : jusqu'ici un programme Piet était un PNG.
 *   Le moteur savait le LIRE (decoder_png, sans bibliothèque d'images), mais
 *   personne ne savait l'ÉCRIRE : peindre un PNG à la main n'est pas éditer un
 *   programme, et un PNG ne se diff pas, ne se corrige pas d'une case.
 *
 *   `piet_texte.py` définit la SOURCE : un format texte où une cellule = un
 *   codel, en deux lettres (`rc` = rouge claire, `bl` = blanc, `no` = noir). Le
 *   PNG devient la forme compilée, que le moteur Piet EXISTANT exécute — pas un
 *   second interpréteur, ce qui ferait un second endroit où se tromper.
 *
 * CE SCRIPT
 *   Rend l'éditeur graphique : la grille à peindre, la palette des 20 couleurs,
 *   la taille de codel, le texte, l'aperçu PNG, l'exécution et l'enregistrement.
 *   Il s'affiche dans un VRAI onglet (patch_interface_4.3.py route les `.piett`
 *   vers `.ps-piet-host[data-path]`), et se rabat sur une vue déléguée si le
 *   bundle n'est pas patché.
 *
 * LE POINT PÉDAGOGIQUE, ET POURQUOI IL EST ICI
 *   En Piet, la commande exécutée dépend du CHANGEMENT de teinte et de
 *   luminosité entre le bloc quitté et le bloc rejoint — jamais de la couleur
 *   elle-même. C'est la première difficulté du langage. L'éditeur affiche donc
 *   en permanence « de <couleur précédente> à <couleur choisie> → <commande> » :
 *   peindre devient lire le programme au lieu de deviner.
 *
 * Aucune ressource externe : pas de police distante, pas d'icône en image.
 */
(() => {
'use strict';

const API = '/api/piet';
const HOTE = '.ps-piet-host';
const ID_VUE = 'piet';
const TITRE_VUE = 'Éditeur Piet';
const ICONE_VUE = '▦';
const CODELS = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32];
const HISTORIQUE_MAX = 60;

const $ = (s, b) => (b || document).querySelector(s);

function el(nom, attributs) {
  const n = document.createElement(nom);
  const reste = Array.prototype.slice.call(arguments, 2);
  if (attributs) {
    Object.keys(attributs).forEach(function (cle) {
      const v = attributs[cle];
      if (v === null || v === undefined || v === false) return;
      if (cle === 'class') n.className = String(v);
      else if (cle === 'texte') n.textContent = String(v);
      else if (cle === 'html') n.innerHTML = String(v);
      else if (cle.slice(0, 2) === 'on' && typeof v === 'function') n.addEventListener(cle.slice(2), v);
      else n.setAttribute(cle, String(v));
    });
  }
  reste.forEach(function (e) {
    if (e === null || e === undefined || e === false) return;
    n.appendChild(typeof e === 'object' ? e : document.createTextNode(String(e)));
  });
  return n;
}

function vider(n) {
  if (!n) return n;
  if (typeof n.replaceChildren === 'function') { try { n.replaceChildren(); return n; } catch (e) {} }
  while (n.firstChild) {
    const f = n.firstChild;
    if (n.removeChild) { try { n.removeChild(f); continue; } catch (e) {} }
    if (f.remove) f.remove(); else break;
  }
  return n;
}

function bouton(titre, action, classe, infobulle) {
  const b = el('button', { class: 'pspi-btn' + (classe ? ' ' + classe : ''),
    type: 'button', title: infobulle || titre, 'aria-label': infobulle || titre });
  b.textContent = titre;
  b.addEventListener('click', function (evt) {
    if (evt && evt.stopPropagation) evt.stopPropagation();
    action();
  });
  return b;
}

/* ---------------------------------------------------------------- l'état --- */
let hote = null;
let cheminCourant = null;
let palette = [];
let commandes = [];
let grille = [['rc', 'rn', 'ms']];
let codel = 4;
let pinceau = 'rc';
let precedente = null;      /* la couleur du dernier bloc peint : sert au rappel */
let historique = [];
let futur = [];
let texteLibre = null;      /* le texte, quand il diffère de la grille */
let apercuUri = '';
let sortie = '';
let compteRendu = null;
let diagnostics = [];
let message = '';
let niveau = 'info';
let modifie = false;
let chargement = false;
let peinture = false;

/* `refusCommeDonnee` : certaines actions du serveur répondent HTTP 200 avec
 * `ok:false` parce que le module NE LÈVE JAMAIS — c'est le cas de
 * piet_texte.decoder(), qui rend des diagnostics ligne/colonne, et de
 * l'exécution d'un programme qui se termine en erreur. Lever là-dessus
 * transformerait un résultat normal en panne : « Décodage impossible : Refusé. »
 * au lieu de la vraie raison, et surtout le texte que l'utilisateur vient
 * d'écrire serait perdu. */
function apiServeur(action, champs, refusCommeDonnee) {
  const corps = Object.assign({ action: action }, champs || {});
  return fetch(API, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(corps)
  }).then(function (reponse) {
    return reponse.json().catch(function () {
      throw new Error('Réponse illisible (HTTP ' + reponse.status + ').');
    }).then(function (json) {
      if (!reponse.ok) {
        throw new Error((json && (json.error || json.erreur)) ||
          ('Le serveur a répondu HTTP ' + reponse.status + '.'));
      }
      if (json && json.ok === false && !refusCommeDonnee) {
        throw new Error(json.erreur || json.error || json.message || 'Refusé.');
      }
      return json;
    });
  });
}

function dire(texte, niveauMessage) {
  message = String(texte || '');
  niveau = niveauMessage || 'info';
  rendre();
}

function couleur(code) {
  for (let i = 0; i < palette.length; i += 1) {
    if (palette[i].code === code) return palette[i];
  }
  return { code: code, nom: code, hexa: '#808080' };
}

function commande(depuis, vers) {
  const a = couleur(depuis), b = couleur(vers);
  if (a.teinte === null || a.teinte === undefined ||
      b.teinte === null || b.teinte === undefined) return null;
  const dt = (b.teinte - a.teinte + 6) % 6;
  const dl = (b.luminosite - a.luminosite + 3) % 3;
  for (let i = 0; i < commandes.length; i += 1) {
    if (commandes[i].delta_teinte === dt && commandes[i].delta_luminosite === dl) {
      return commandes[i];
    }
  }
  return { commande: 'rien', libelle: 'aucune' };
}

/* ---------------------------------------------------------------- actions -- */

function pousserHistorique() {
  historique.push({ grille: grille.map(function (l) { return l.slice(); }),
    codel: codel });
  if (historique.length > HISTORIQUE_MAX) historique.shift();
  futur = [];
}

function annuler() {
  if (!historique.length) { dire('Rien à annuler.', 'info'); return; }
  futur.push({ grille: grille.map(function (l) { return l.slice(); }), codel: codel });
  const etat = historique.pop();
  grille = etat.grille;
  codel = etat.codel;
  modifie = true;
  texteLibre = null;
  rafraichirApercu();
  rendre();
}

function retablir() {
  if (!futur.length) { dire('Rien à rétablir.', 'info'); return; }
  historique.push({ grille: grille.map(function (l) { return l.slice(); }), codel: codel });
  const etat = futur.pop();
  grille = etat.grille;
  codel = etat.codel;
  modifie = true;
  texteLibre = null;
  rafraichirApercu();
  rendre();
}

function peindre(x, y, code) {
  if (y < 0 || y >= grille.length) return false;
  if (x < 0 || x >= grille[y].length) return false;
  if (grille[y][x] === code) return false;
  pousserHistorique();
  precedente = grille[y][x];
  grille[y][x] = code;
  modifie = true;
  texteLibre = null;
  return true;
}

function redimensionner(largeur, hauteur) {
  largeur = Math.max(1, Math.min(128, largeur | 0));
  hauteur = Math.max(1, Math.min(128, hauteur | 0));
  pousserHistorique();
  const neuve = [];
  for (let y = 0; y < hauteur; y += 1) {
    const ligne = [];
    for (let x = 0; x < largeur; x += 1) {
      ligne.push((grille[y] && grille[y][x]) ? grille[y][x] : 'bl');
    }
    neuve.push(ligne);
  }
  grille = neuve;
  modifie = true;
  texteLibre = null;
  rafraichirApercu();
  rendre();
}

function texteDeLaGrille() {
  if (texteLibre !== null) return texteLibre;
  let texte = '# Programme Piet — format texte de Pascal Studio.\n';
  texte += 'piet 1\ncodel ' + codel + '\ngrille ' +
    (grille[0] ? grille[0].length : 0) + ' ' + grille.length + '\n';
  grille.forEach(function (ligne) { texte += ligne.join(' ') + '\n'; });
  return texte;
}

function rafraichirApercu() {
  apercuUri = '';
  apiServeur('png', { texte: texteDeLaGrille() }).then(function (json) {
    apercuUri = (json && json.uri) || '';
    if (cheminCourant || hote) rendre();
  }).catch(function (exc) {
    dire('Aperçu PNG indisponible : ' + (exc.message || exc), 'avertissement');
  });
}

function executer() {
  dire('Exécution…', 'info');
  const entree = ($('.pspi-entree') && $('.pspi-entree').value) || '';
  apiServeur('executer', { texte: texteDeLaGrille(), entree: entree }, true)
    .then(function (json) {
      compteRendu = json || null;
      sortie = (json && (json.sortie || json.output)) || '';
      diagnostics = (json && json.diagnostics) || [];
      dire(json && json.message ? json.message :
        ('Exécution terminée en ' + ((json && json.pas) || 0) + ' pas.'),
        json && json.ok === false ? 'erreur' : 'ok');
    })
    .catch(function (exc) {
      compteRendu = null;
      sortie = '';
      dire('Exécution impossible : ' + (exc.message || exc), 'erreur');
    });
}

function enregistrer() {
  if (!cheminCourant) { dire('Aucun fichier à enregistrer.', 'avertissement'); return; }
  dire('Enregistrement…', 'info');
  apiServeur('ecrire', { chemin: cheminCourant, texte: texteDeLaGrille() })
    .then(function () {
      modifie = false;
      dire('Enregistré : ' + cheminCourant, 'ok');
    })
    .catch(function (exc) {
      dire('Enregistrement refusé : ' + (exc.message || exc), 'erreur');
    });
}

function exporterPng() {
  if (!cheminCourant) { dire('Aucun fichier de départ : enregistrez d’abord.', 'avertissement'); return; }
  apiServeur('exporter-png', { chemin: cheminCourant, texte: texteDeLaGrille() })
    .then(function (json) {
      dire('PNG écrit : ' + ((json && json.destination) || '') +
        ' — c’est la forme que n’importe quel interpréteur Piet sait lire.', 'ok');
    })
    .catch(function (exc) {
      dire('Export PNG impossible : ' + (exc.message || exc), 'erreur');
    });
}

function charger(chemin) {
  chargement = true;
  return apiServeur('lire', { chemin: chemin }).then(function (json) {
    chargement = false;
    const texte = (json && json.texte) || '';
    texteLibre = null;
    appliquerTexte(texte, true);
    dire('Chargé : ' + chemin, 'ok');
  }).catch(function (exc) {
    chargement = false;
    dire('Lecture impossible : ' + (exc.message || exc), 'erreur');
  });
}

function appliquerTexte(texte, silencieux) {
  return apiServeur('decoder', { texte: texte }, true).then(function (json) {
    if (json && json.ok && json.cellules && json.cellules.length) {
      grille = json.cellules;
      codel = json.codel || 1;
      texteLibre = null;
      modifie = false;
      rafraichirApercu();
      if (!silencieux) dire('Texte appliqué à la grille.', 'ok');
      else rendre();
    } else {
      /* Le texte est refusé : on le GARDE tel quel et on affiche pourquoi. Le
       * jeter ferait perdre ce que l'utilisateur vient d'écrire. */
      texteLibre = texte;
      modifie = true;
      diagnostics = (json && json.diagnostics) || [];
      rendre();
      if (!silencieux) {
        dire(diagnostics.length ? diagnostics[0].message :
          'Texte refusé : aucune grille trouvée.', 'erreur');
      }
    }
    return json;
  }).catch(function (exc) {
    /* Même en cas de panne de transport, le texte n'est PAS jeté : l'utilisateur
     * le retrouvera dans la zone une fois le serveur revenu. */
    texteLibre = texte;
    diagnostics = [];
    rendre();
    dire('Décodage impossible : ' + (exc.message || exc), 'erreur');
  });
}

function chargerCatalogue() {
  return apiServeur('catalogue').then(function (json) {
    palette = (json && json.palette) || [];
    commandes = (json && json.commandes) || [];
    return json;
  }).catch(function (exc) {
    /* Sans palette venue du serveur, l'éditeur ne peut pas colorer : il faut le
     * dire, pas afficher une grille grise sans explication. */
    dire('Le catalogue des couleurs Piet est inaccessible : ' +
      (exc.message || exc) + ' — vérifiez que piet_texte.py est présent à côté ' +
      'de server.py.', 'erreur');
  });
}

/* ------------------------------------------------------------------ rendu -- */

function construire() {
  const racine = el('div', { class: 'pspi' });
  const largeur = grille[0] ? grille[0].length : 0;

  /* --- barre d'outils -------------------------------------------------- */
  const outils = el('div', { class: 'pspi-outils' });
  outils.append(
    bouton('↶ Annuler', annuler, '', 'Annuler la dernière modification'),
    bouton('↷ Rétablir', retablir, '', 'Rétablir la dernière modification annulée'),
    el('span', { class: 'pspi-sep' }),
    el('label', { class: 'pspi-champ' }, 'codel',
      (function () {
        const sel = el('select', { class: 'pspi-select', 'aria-label': 'Taille d’un codel en pixels' });
        CODELS.forEach(function (c) {
          const opt = el('option', { value: String(c), texte: c + ' px' });
          if (c === codel) opt.setAttribute('selected', 'selected');
          sel.appendChild(opt);
        });
        sel.addEventListener('change', function () {
          pousserHistorique();
          codel = parseInt(sel.value, 10) || 1;
          modifie = true;
          texteLibre = null;
          rafraichirApercu();
          rendre();
        });
        return sel;
      })()),
    el('span', { class: 'pspi-champ' }, 'grille',
      (function () {
        const champL = el('input', { class: 'pspi-nombre', type: 'number',
          min: '1', max: '128', value: String(largeur),
          'aria-label': 'Largeur en codels' });
        const champH = el('input', { class: 'pspi-nombre', type: 'number',
          min: '1', max: '128', value: String(grille.length),
          'aria-label': 'Hauteur en codels' });
        const appliquer = function () {
          redimensionner(parseInt(champL.value, 10) || largeur,
            parseInt(champH.value, 10) || grille.length);
        };
        champL.addEventListener('change', appliquer);
        champH.addEventListener('change', appliquer);
        return el('span', { class: 'pspi-dimensions' }, champL, '×', champH);
      })()),
    el('span', { class: 'pspi-sep' }),
    bouton('Enregistrer', enregistrer, 'pspi-primaire',
      'Écrire le fichier .piett'),
    bouton('Exécuter', executer, 'pspi-primaire', 'Exécuter le programme'),
    bouton('Aperçu', rafraichirApercu, '', 'Reconstruire l’aperçu PNG'),
    bouton('Exporter en PNG', exporterPng, '',
      'Écrire le PNG compilé à côté du .piett'),
    el('span', { class: 'pspi-pousse' }),
    el('span', { class: 'pspi-etat' + (modifie ? ' pspi-etat-modifie' : ''),
      texte: modifie ? 'modifié, non enregistré' : 'enregistré' }));

  racine.append(outils);

  /* --- le rappel pédagogique, toujours visible -------------------------- */
  const rappel = precedente ? commande(precedente, pinceau) : null;
  racine.append(el('div', { class: 'pspi-rappel' },
    el('span', { class: 'pspi-rappel-couleur',
      style: 'background:' + couleur(precedente || pinceau).hexa }),
    el('span', { class: 'pspi-rappel-texte',
      texte: precedente
        ? ('de « ' + couleur(precedente).nom + ' » à « ' + couleur(pinceau).nom +
          ' » → ' + (rappel ? rappel.libelle : 'aucune commande (blanc ou noir)'))
        : ('Pinceau : ' + couleur(pinceau).nom +
          ' — la commande dépend du CHANGEMENT de couleur entre blocs, jamais de ' +
          'la couleur elle-même.') })));

  /* --- corps : grille + colonnes --------------------------------------- */
  const corps = el('div', { class: 'pspi-corps' });

  const colonneGrille = el('div', { class: 'pspi-colonne' },
    el('div', { class: 'pspi-titre-colonne', texte: 'Grille (cliquer pour peindre, glisser pour plusieurs cases)' }));
  const tableau = el('div', { class: 'pspi-grille',
    style: '--pspi-cols:' + Math.max(1, largeur) });
  grille.forEach(function (ligne, y) {
    ligne.forEach(function (code, x) {
      const c = couleur(code);
      const caseEl = el('div', { class: 'pspi-case', 'data-x': String(x),
        'data-y': String(y), title: c.nom + ' (' + code + ') — ligne ' +
          (y + 1) + ', colonne ' + (x + 1),
        style: 'background:' + c.hexa });
      tableau.appendChild(caseEl);
    });
  });
  /* La peinture se fait par DÉLÉGATION sur la grille : une case par codel
   * avec son propre écouteur ferait des milliers d'écouteurs sur un grand
   * programme, et c'est exactement le genre de coût qui rend une interface
   * lente sans qu'aucune erreur n'apparaisse. */
  tableau.addEventListener('pointerdown', function (evt) {
    const cible = evt.target;
    if (!cible || !cible.getAttribute) return;
    const x = cible.getAttribute('data-x'), y = cible.getAttribute('data-y');
    if (x === null || y === null) return;
    peinture = true;
    if (peindre(parseInt(x, 10), parseInt(y, 10), pinceau)) rendre();
    if (evt.preventDefault) evt.preventDefault();
  });
  tableau.addEventListener('pointerover', function (evt) {
    if (!peinture) return;
    const cible = evt.target;
    if (!cible || !cible.getAttribute) return;
    const x = cible.getAttribute('data-x'), y = cible.getAttribute('data-y');
    if (x === null || y === null) return;
    if (peindre(parseInt(x, 10), parseInt(y, 10), pinceau)) rendre();
  });
  colonneGrille.append(tableau);
  corps.append(colonneGrille);

  /* --- palette ---------------------------------------------------------- */
  const colonnePalette = el('div', { class: 'pspi-colonne pspi-colonne-etroite' },
    el('div', { class: 'pspi-titre-colonne', texte: 'Palette (20 couleurs)' }));
  const paletteEl = el('div', { class: 'pspi-palette' });
  palette.forEach(function (c) {
    const b = el('button', { class: 'pspi-couleur' + (c.code === pinceau ? ' pspi-couleur-active' : ''),
      type: 'button', title: c.nom + ' — ' + c.code, 'data-code': c.code,
      'aria-label': 'Pinceau ' + c.nom, style: 'background:' + c.hexa },
    el('span', { class: 'pspi-couleur-code', texte: c.code }));
    b.addEventListener('click', function () {
      precedente = pinceau;
      pinceau = c.code;
      rendre();
    });
    paletteEl.appendChild(b);
  });
  colonnePalette.append(paletteEl);

  /* La table des commandes : ce que l'utilisateur doit avoir sous les yeux
   * pour ne pas apprendre les 17 combinaisons par cœur. */
  colonnePalette.append(el('div', { class: 'pspi-titre-colonne',
    texte: 'Les 17 commandes' }));
  const table = el('div', { class: 'pspi-commandes' });
  commandes.forEach(function (c) {
    table.append(el('div', { class: 'pspi-commande',
      title: 'Δ teinte ' + c.delta_teinte + ', Δ luminosité ' + c.delta_luminosite },
    el('span', { class: 'pspi-commande-d', texte: '+' + c.delta_teinte + '/+' + c.delta_luminosite }),
    el('b', { texte: c.libelle || c.commande })));
  });
  colonnePalette.append(table);
  corps.append(colonnePalette);

  /* --- texte, aperçu, exécution ---------------------------------------- */
  const colonneDroite = el('div', { class: 'pspi-colonne' },
    el('div', { class: 'pspi-titre-colonne', texte: 'Source texte (.piett)' }));
  const zone = el('textarea', { class: 'pspi-texte', spellcheck: 'false',
    'aria-label': 'Source texte du programme Piet',
    rows: '10' });
  zone.value = texteDeLaGrille();
  zone.addEventListener('input', function () { texteLibre = zone.value; modifie = true; });
  colonneDroite.append(zone,
    el('div', { class: 'pspi-ligne-boutons' },
      bouton('Appliquer le texte à la grille', function () {
        appliquerTexte(zone.value, false);
      }, '', 'Décode le texte et met la grille à jour'),
      bouton('Réécrire depuis la grille', function () {
        texteLibre = null;
        rendre();
      }, '', 'Écrase le texte avec la grille actuelle'),
      bouton('Exemple qui écrit « 1 »', function () {
        apiServeur('exemple').then(function (json) {
          appliquerTexte((json && json.texte) || '', false);
        }).catch(function (exc) { dire(String(exc.message || exc), 'erreur'); });
      }, '', 'Le plus petit programme qui produit une sortie vérifiable')));

  colonneDroite.append(el('div', { class: 'pspi-titre-colonne',
    texte: 'Aperçu PNG (la forme compilée)' }));
  colonneDroite.append(apercuUri
    ? el('img', { class: 'pspi-apercu', src: apercuUri, alt: 'Aperçu du programme Piet' })
    : el('div', { class: 'pspi-meta', texte: 'Aperçu non construit.' }));

  colonneDroite.append(el('div', { class: 'pspi-titre-colonne', texte: 'Exécution' }));
  const entree = el('textarea', { class: 'pspi-entree', rows: '3',
    'aria-label': 'Entrée du programme',
    placeholder: 'Entrée du programme (in number / in char)' });
  colonneDroite.append(entree,
    el('pre', { class: 'pspi-sortie', texte: sortie || '(aucune sortie)' }));
  if (compteRendu) {
    colonneDroite.append(el('div', { class: 'pspi-meta',
      texte: 'pas : ' + (compteRendu.pas || 0) + ' · terminé : ' +
        (compteRendu.termine ? 'oui' : 'non') +
        (compteRendu.message ? ' · ' + compteRendu.message : '') }));
  }
  if (diagnostics && diagnostics.length) {
    const liste = el('ul', { class: 'pspi-diagnostics' });
    diagnostics.slice(0, 40).forEach(function (d) {
      liste.append(el('li', { class: 'pspi-diagnostic pspi-sev-' +
        (d.severity || 'info'),
      texte: (d.ligne ? 'ligne ' + d.ligne + (d.colonne ? ', colonne ' + d.colonne : '') + ' : ' : '') +
        d.message }));
    });
    colonneDroite.append(liste);
  }
  corps.append(colonneDroite);

  racine.append(corps);
  racine.append(el('div', { class: 'pspi-statut pspi-' + niveau, texte: message }));
  return racine;
}

let observateur = null;

function suivreHote(selecteur, rappel) {
  const arret = { disconnect: function () {}, takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const obs = new MutationObserver(rappel);
  obs.observe(document.documentElement, { subtree: true, childList: true });
  const filet = typeof setInterval === 'function' ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () { obs.disconnect(); if (filet) clearInterval(filet); };
  return arret;
}

function attache(noeud) {
  if (!noeud) return false;
  if (typeof noeud.isConnected === 'boolean') return noeud.isConnected;
  return !!noeud.parentNode;
}

function rendre() {
  if (!hote) return;
  if (observateur && observateur.takeRecords) {
    try { observateur.takeRecords(); } catch (exc) { /* ignoré */ }
  }
  vider(hote);
  hote.appendChild(construire());
  if (observateur && observateur.takeRecords) {
    try { observateur.takeRecords(); } catch (exc) { /* ignoré */ }
  }
}

function attach() {
  const cible = $(HOTE);
  if (!cible) {
    if (hote && !attache(hote)) { hote = null; cheminCourant = null; }
    return;
  }
  const chemin = cible.getAttribute ? cible.getAttribute('data-path') : '';
  if (cible === hote && chemin && chemin === cheminCourant && palette.length) return;
  hote = cible;
  cheminCourant = chemin || cheminCourant;
  if (!observateur) observateur = suivreHote(HOTE, attach);
  const demarrage = palette.length ? Promise.resolve() : chargerCatalogue();
  demarrage.then(function () {
    rendre();
    if (cheminCourant && /\.piett$/i.test(cheminCourant)) return charger(cheminCourant);
    if (!palette.length) return null;
    return null;
  });
  if (!apercuUri) rafraichirApercu();
}

/* -------------------------------------------------------------------- API -- */

window.PSPiet = {
  marqueur: 'ps-4.3.0-piet',
  format: '.piett',
  ouvrir: function (chemin) {
    if (typeof window.PSFMOpenTabs === 'function') {
      try { window.PSFMOpenTabs([chemin || 'programme.piett']); return true; } catch (exc) { /* repli */ }
    }
    if (window.PSVues && window.PSVues.ouvrir) {
      cheminCourant = chemin || null;
      const demarrage = palette.length ? Promise.resolve() : chargerCatalogue();
      demarrage.then(function () {
        window.PSVues.ouvrir({ id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE,
          noeud: (function () { hote = null; return construire(); })() });
      });
      return true;
    }
    return false;
  },
  nouveau: function () {
    pousserHistorique();
    grille = [['rc', 'rn', 'ms']];
    codel = 4;
    texteLibre = null;
    modifie = true;
    rafraichirApercu();
    rendre();
    dire('Nouveau programme : l’exemple qui écrit « 1 ». Peignez pour continuer.', 'ok');
    return true;
  },
  grille: function () { return grille.map(function (l) { return l.slice(); }); },
  texte: function () { return texteDeLaGrille(); },
  appliquerTexte: function (texte) { return appliquerTexte(String(texte || ''), false); },
  pinceau: function (code) {
    if (code) { precedente = pinceau; pinceau = String(code); rendre(); }
    return pinceau;
  },
  peindre: function (x, y, code) {
    const fait = peindre(x | 0, y | 0, code || pinceau);
    if (fait) { rafraichirApercu(); rendre(); }
    return fait;
  },
  executer: executer,
  enregistrer: enregistrer,
  annuler: annuler,
  retablir: retablir,
  etat: function () {
    return { chemin: cheminCourant, codel: codel, pinceau: pinceau,
      largeur: grille[0] ? grille[0].length : 0, hauteur: grille.length,
      modifie: modifie, couleurs: palette.length, commandes: commandes.length,
      historique: historique.length, sortie: sortie,
      message: message, niveau: niveau };
  },
  garanties: function () {
    return { onglet_reel: !!$(HOTE), repli_vues: !!(window.PSVues),
      moteur: 'langages_esoteriques.Piet (inchangé)',
      format: '.piett', execution_reelle: true,
      historique: HISTORIQUE_MAX };
  }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', attach, { once: true });
} else attach();
})();
