/* Registre partagé des hôtes de Pascal Studio (4.2.0).
 *
 * POURQUOI CE FICHIER EXISTE
 *   Cinq scripts injectés — data-studio, navigateur-studio, devweb-studio,
 *   re-studio et outils-studio — posaient CHACUN un MutationObserver sur
 *   document.documentElement avec subtree:true, et CHACUN un
 *   setInterval(attach, 2000). Cinq observateurs et cinq sondes.
 *
 *   Une seule frappe dans Monaco, une ligne de terminal, un diagnostic de
 *   serveur de langage, un rafraîchissement Git : chaque mutation du DOM
 *   réveillait les cinq observateurs, et chacun faisait un querySelector sur
 *   tout le document, parfois suivi d'un rendu complet. Résultat mesuré par
 *   l'utilisateur : « les boutons latéraux mettent plusieurs secondes à changer
 *   l'affichage », et des clics qui ne produisaient rien parce que l'interface
 *   était encore en train de reconstruire ce qu'il venait de cliquer.
 *
 *   Ce fichier remplace les cinq par UN observateur et UNE sonde, et regroupe
 *   les rappels : au plus un passage par image, quel que soit le nombre de
 *   mutations. Cinq observateurs qui se réveillent chacun cinquante fois par
 *   seconde deviennent un observateur qui joue cinq rappels une fois par image.
 *
 * CE QUE CE FICHIER NE FAIT PAS
 *   Il ne décide pas QUAND un panneau doit se rendre : il ne fait que prévenir.
 *   Chaque rappel reste idempotent et doit revenir immédiatement s'il n'y a
 *   rien à faire — c'est ce qui empêche la boucle (un rendu produit des
 *   mutations, qui réveillent l'observateur, qui rappelle le rendu…).
 *   Il n'avale pas les erreurs en silence : un rappel qui lève est écrit sur la
 *   console et n'empêche pas les autres de jouer. Un panneau cassé ne doit pas
 *   casser les quatre autres, mais il ne doit pas non plus disparaître sans
 *   trace.
 *
 * Aucune ressource externe.
 */
(() => {
'use strict';

const MARQUEUR = 'ps-4.2.0-hotes';
const DELAI_FILET = 5000;   /* sonde de secours, en ms */
const LIMITE_ERREURS = 12;  /* au-delà, un rappel fautif est mis en veille */

const enregistrements = [];
let observateur = null;
let sonde = null;
let demande = false;
let passes = 0;
let demarrage = 0;

function jouer() {
  demande = false;
  passes += 1;
  /* Écarter nos propres écritures AVANT de jouer les rappels : sinon le
   * rendu d'un panneau réveille l'observateur et la boucle ne s'arrête qu'au
   * prochain tour, ce qui double le travail à chaque mutation. */
  if (observateur && typeof observateur.takeRecords === 'function') {
    try { observateur.takeRecords(); } catch (exc) { /* sans objet */ }
  }
  for (let i = 0; i < enregistrements.length; i += 1) {
    const enregistrement = enregistrements[i];
    if (enregistrement.endormi) continue;
    try {
      enregistrement.rappel();
      enregistrement.erreurs = 0;
    } catch (exc) {
      enregistrement.erreurs = (enregistrement.erreurs || 0) + 1;
      if (typeof console !== 'undefined' && console.error) {
        console.error('[PSHotes] le rappel de ' + enregistrement.selecteur
          + ' a levé :', exc);
      }
      if (enregistrement.erreurs >= LIMITE_ERREURS) {
        enregistrement.endormi = true;
        if (typeof console !== 'undefined' && console.error) {
          console.error('[PSHotes] ' + enregistrement.selecteur + ' mis en '
            + 'veille après ' + LIMITE_ERREURS + ' erreurs : ce panneau ne '
            + 'réagit plus au DOM. Les autres continuent.');
        }
      }
    }
  }
}

function demander() {
  if (demande) return;
  demande = true;
  /* Au plus un passage par image. Sans ce regroupement, N mutations
   * produiraient N passages — exactement ce que les cinq observateurs
   * faisaient chacun de leur côté. */
  if (typeof requestAnimationFrame === 'function') requestAnimationFrame(jouer);
  else setTimeout(jouer, 16);
}

function demarrer() {
  if (observateur) return;
  demarrage = Date.now();
  const cible = document.body || document.documentElement;
  if (typeof MutationObserver === 'function' && cible) {
    observateur = new MutationObserver(demander);
    try {
      observateur.observe(cible, { subtree: true, childList: true });
    } catch (exc) {
      observateur = null;
    }
  }
  /* La sonde de secours couvre deux cas réels : un observateur installé avant
   * que l'hôte n'existe, et un DOM remplacé en bloc (React remonte un
   * sous-arbre entier, ce qu'aucune mutation isolée ne signale utilement).
   * Cinq secondes et non deux : le filet n'a pas à être nerveux, c'est le rôle
   * de l'observateur. */
  if (typeof setInterval === 'function') {
    sonde = setInterval(demander, DELAI_FILET);
  }
  demander();
}

function suivre(selecteur, rappel) {
  if (typeof rappel !== 'function') {
    throw new TypeError('PSHotes.suivre attend une fonction');
  }
  const enregistrement = { selecteur: String(selecteur || ''), rappel: rappel,
    erreurs: 0, endormi: false };
  enregistrements.push(enregistrement);
  demarrer();
  /* Le nouvel arrivant est joué tout de suite : un panneau qui s'enregistre
   * alors que son hôte existe déjà ne doit pas attendre la prochaine mutation. */
  demander();
  return function arreter() {
    const place = enregistrements.indexOf(enregistrement);
    if (place >= 0) enregistrements.splice(place, 1);
  };
}

function statistiques() {
  return {
    marqueur: MARQUEUR,
    enregistrements: enregistrements.map(function (e) {
      return { selecteur: e.selecteur, endormi: !!e.endormi,
        erreurs: e.erreurs || 0 };
    }),
    observateurs: observateur ? 1 : 0,
    sondes: sonde ? 1 : 0,
    passes: passes,
    delai_filet: DELAI_FILET,
    uptime: demarrage ? Date.now() - demarrage : 0
  };
}

window.PSHotes = {
  marqueur: MARQUEUR,
  suivre: suivre,
  forcer: jouer,
  demander: demander,
  statistiques: statistiques,
  /* Ce que l'ancienne architecture coûtait, pour que la comparaison reste
   * lisible dans les bancs et dans le guide. */
  avant: { observateurs: 5, sondes: 5, delai_sonde: 2000 }
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', demarrer, { once: true });
} else demarrer();
})();
