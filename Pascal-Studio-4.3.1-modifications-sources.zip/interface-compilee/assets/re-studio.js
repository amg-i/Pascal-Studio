/* Panneau rétro-ingénierie de Pascal Studio (4.0.0).
 *
 * Ce panneau existe parce que la rétro-ingénierie est un travail de LECTURE, pas
 * d'exécution : on ouvre un binaire, on regarde sa structure, on désassemble, on
 * cherche des symboles et des chaînes, on lit du code décompilé. Rien de tout
 * cela n'exécute le fichier analysé, et le panneau le dit.
 *
 * Il est organisé en huit sections :
 *   1. Environnement — ce qui est installé, ce qui manque, et COMMENT l'installer.
 *      Ghidra pèse environ 570 Mo et exige un JDK 21 : Pascal Studio ne peut pas
 *      le livrer, donc le panneau le détecte et, s'il est absent, nomme
 *      précisément ce qui manque (Ghidra, le JDK, le venv PyGhidra) avec les
 *      vraies commandes. Un panneau qui afficherait seulement « Ghidra
 *      introuvable » laisserait croire que rien n'est possible ici : la section
 *      liste donc aussi ce qui reste utilisable sans Ghidra.
 *   2. Analyse — la structure du fichier : famille, en-têtes, sections,
 *      segments, entropie, imports, heuristiques d'empaquetage.
 *   3. Symboles — nm et la table du fichier, avec la distinction défini /
 *      non défini et le démangling.
 *   4. Chaînes — avec leur décalage, et l'attribution à une section.
 *   5. Désassemblage — AT&T ou Intel, borné en lignes, avec l'annonce des
 *      substitutions d'options.
 *   6. Ghidra — les dix opérations, en arrière-plan, avec le cache de projet.
 *   7. Widgets — quinze convertisseurs et tables qui ne touchent pas au disque.
 *   8. Fiches — vingt-huit fiches documentaires, cherchables, dont chaque fait
 *      est vérifié par l'autocontrôle du module Python.
 *
 * Ce que ce panneau NE FAIT PAS, et pourquoi :
 *   - il n'exécute jamais le binaire analysé. `capacites()` l'affirme
 *     (`execute_des_binaires: false`) et le panneau affiche cette affirmation ;
 *   - il ne lance Ghidra que sur demande explicite, et toute tâche est
 *     arrêtable : l'analyse peut durer des minutes ;
 *   - il n'invente aucun octet. Un vidage qui dépasse la fin du fichier rend
 *     « absent du fichier », pas des zéros ; une RVA qui ne tombe dans aucune
 *     section rend null avec une note, pas 0 ;
 *   - il ne devine pas : quand une information manque, il le dit dans la zone
 *     d'état plutôt que de laisser une zone blanche.
 *
 * Aucune ressource externe : pas de police distante, pas d'icône en image, pas
 * de CDN. Les icônes sont des SVG en ligne.
 */
(() => {
'use strict';

const API = '/api/re';
const HOTE = '.ps-re-host';
/* 4.3.0 : le panneau passe devant les fichiers ouverts. Ces trois constantes
 * sont la seule identité de la vue — le contenu, lui, reste construit par
 * `construire()` et n'est jamais recopié. */
const ID_VUE = 'retro';
const TITRE_VUE = 'Rétro-ingénierie';
const ICONE_VUE = '0x';
const CLE_GEOMETRIE = 'ps-re-fenetre';
const LARGEUR_MIN = 380;
const HAUTEUR_MIN = 240;
const SONDE_TACHES = 2500;           // ms entre deux lectures des tâches Ghidra
const RETARD_RECHERCHE = 350;        // anti-rebond du champ de recherche
const MAX_LIGNES_DESASS = 20000;     // borne du module Python, rappelée ici
const OCTETS_VIDAGE = 512;           // vidage initial

/* Les sections, dans l'ordre d'affichage. `ghidra` est désactivée quand le pont
 * n'est pas prêt, mais elle reste VISIBLE : cacher la section ferait croire que
 * la fonctionnalité n'existe pas, alors qu'elle existe et qu'il manque une
 * installation. */
const SECTIONS = [
  { id: 'environnement', titre: 'Environnement', icone: 'outils' },
  { id: 'analyse', titre: 'Analyse', icone: 'binaire' },
  { id: 'symboles', titre: 'Symboles', icone: 'symbole' },
  { id: 'chaines', titre: 'Chaînes', icone: 'texte' },
  { id: 'desassemblage', titre: 'Désassemblage', icone: 'code' },
  { id: 'ghidra', titre: 'Ghidra', icone: 'ghidra' },
  { id: 'widgets', titre: 'Widgets', icone: 'calcul' },
  { id: 'fiches', titre: 'Fiches', icone: 'livre' },
];

const ICONES = {
  outils: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M11.7 1.3a3.6 3.6 0 0 0-4.6 4.4L1.6 11.2a1.4 1.4 0 0 0 2 2l5.5-5.5a3.6 3.6 0 0 0 4.4-4.6l-2.1 2.1-1.9-.5-.5-1.9z" fill="currentColor"/></svg>',
  binaire: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M2 2h5v5H2zm7 0h5v5H9zM2 9h5v5H2zm7 0h5v5H9z" fill="none" stroke="currentColor" stroke-width="1.3"/></svg>',
  symbole: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M3 3h10M3 8h7M3 13h10" stroke="currentColor" stroke-width="1.4" fill="none"/><circle cx="13" cy="8" r="1.6" fill="currentColor"/></svg>',
  texte: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M2 3h12M2 6.5h9M2 10h12M2 13.5h6" stroke="currentColor" stroke-width="1.3" fill="none"/></svg>',
  code: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M5.5 3.5 2 8l3.5 4.5M10.5 3.5 14 8l-3.5 4.5" stroke="currentColor" stroke-width="1.4" fill="none"/></svg>',
  ghidra: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><circle cx="8" cy="8" r="5.6" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M8 4.2v3.8l2.6 1.6" stroke="currentColor" stroke-width="1.3" fill="none"/></svg>',
  calcul: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><rect x="2.5" y="1.8" width="11" height="12.4" rx="1.4" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M5 5h6M5 8h2.5M5 11h2.5M10 8v3" stroke="currentColor" stroke-width="1.2" fill="none"/></svg>',
  livre: '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true"><path d="M2.5 2.5h4.2c.9 0 1.3.5 1.3 1.3v9.2c0-.7-.5-1.1-1.3-1.1H2.5zM13.5 2.5H9.3c-.9 0-1.3.5-1.3 1.3v9.2c0-.7.5-1.1 1.3-1.1h4.2z" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>',
};

/* ------------------------------------------------------------------- DOM ---- */
const $ = (sel, base) => (base || document).querySelector(sel);
const $$ = (sel, base) => Array.from((base || document).querySelectorAll(sel));

/* el(tag, attributs, ...enfants) — TOUS les arguments après le deuxième sont des
 * enfants. Une version précédente d'un script hôte de ce projet ignorait
 * silencieusement le quatrième argument et au-delà : le rendu était incomplet
 * sans qu'aucune erreur n'apparaisse nulle part. */
function el(tag, attrs) {
  const noeud = document.createElement(tag);
  const proprietes = attrs || {};
  Object.keys(proprietes).forEach(cle => {
    const valeur = proprietes[cle];
    if (valeur === null || valeur === undefined || valeur === false) return;
    if (cle === 'class') noeud.className = valeur;
    else if (cle === 'text') noeud.textContent = String(valeur);
    else if (cle === 'html') noeud.innerHTML = String(valeur);
    else if (cle.slice(0, 2) === 'on' && typeof valeur === 'function') {
      noeud.addEventListener(cle.slice(2).toLowerCase(), valeur);
    } else if (valeur === true) noeud.setAttribute(cle, '');
    else noeud.setAttribute(cle, String(valeur));
  });
  for (let i = 2; i < arguments.length; i++) ajouter(noeud, arguments[i]);
  return noeud;
}

/* ajouter() accepte une chaîne (texte), un tableau, un nœud, null. Un objet
 * ordinaire passé par erreur produirait sinon « [object Object] » dans le DOM :
 * c'est un défaut déjà rencontré dans ce projet, donc il est refusé ici. */
/* ajouter(parent, ...enfants) — VARIADIQUE, comme el().
 *
 * Une première version prenait (parent, enfant) au singulier, et les appels
 * `ajouter(conteneur, entete, barre, corps, etat)` ne posaient que le DEUXIÈME
 * argument : le panneau se construisait avec son en-tête et sans sa barre
 * d'onglets, sans lever aucune erreur. Un argument ignoré en silence est le
 * défaut le plus coûteux à trouver dans un script d'interface, donc la forme
 * variadique est la seule acceptée ici — la même que celle d'el(), justement
 * parce qu'une version antérieure d'un autre script hôte de ce projet avait ce
 * bug. */
function ajouter(parent) {
  for (let i = 1; i < arguments.length; i++) ajouterUn(parent, arguments[i]);
  return parent;
}

function ajouterUn(parent, enfant) {
  if (enfant === null || enfant === undefined || enfant === false) return parent;
  if (Array.isArray(enfant)) {
    enfant.forEach(item => ajouterUn(parent, item));
    return parent;
  }
  if (typeof enfant === 'string' || typeof enfant === 'number') {
    parent.appendChild(document.createTextNode(String(enfant)));
    return parent;
  }
  if (enfant.nodeType !== 1 && enfant.nodeType !== 3 && enfant.nodeType !== 11) {
    throw new TypeError('ajouter() attend un nœud, pas ' + typeof enfant);
  }
  parent.appendChild(enfant);
  return parent;
}

/* replaceChildren() et pas une boucle sur firstChild/removeChild : c'est la
 * forme qu'utilisent les autres panneaux de ce projet (devweb-studio.js,
 * data-studio.js), donc le harnais DOM des bancs la couvre. Une boucle
 * removeChild fonctionne dans un navigateur mais pas dans le harnais, et un
 * panneau qu'on ne peut pas tester est un panneau qu'on ne peut pas garantir. */
function vider(noeud) { if (noeud) noeud.replaceChildren(); return noeud; }

function svg(nom) {
  const boite = el('span', { class: 'ps-re-icone', html: ICONES[nom] || '' });
  return boite;
}

/* ------------------------------------------------------------------ ÉTAT ---- */
let hote = null;
let racine = null;
let capacites = null;
let binaire = null;              // le chemin du fichier analysé
let analyse = null;              // le dernier résultat d'analyse
let taches = [];                 // les tâches Ghidra connues
let sondes = null;               // l'intervalle de sondage des tâches
let ouvert = { environnement: true };
let categorieFiches = '';
let rechercheFiches = '';
let ficheCourante = null;
let widgetCourant = null;
/* Le catalogue des widgets vient de retro_fiches.WIDGETS : il est FIXE pour la
 * durée de la session. Le recharger à chaque ouverture de widget ajoutait un
 * aller-retour réseau par clic, visible comme un clignotement du formulaire. */
let catalogueWidgets = null;
let entreesWidgets = {};
let derniereErreur = '';
let compteurErreurs = 0;
/* Les messages d'erreur sont gardés, pas seulement comptés : un compteur ne dit
 * pas si l'erreur vient d'un refus attendu ou d'une requête cassée. */
let journalErreurs = [];
let compteurAppels = 0;

/* ------------------------------------------------------------ COMMUNICATION - */
async function appeler(action, donnees) {
  compteurAppels += 1;
  try {
    const reponse = await fetch(API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(Object.assign({ action: action }, donnees || {})),
    });
    const corps = await reponse.json();
    if (!reponse.ok) {
      /* server.py répond 400 avec {'error': ...} quand la route lève, mais la
       * façade retro.py rend aussi des refus métier en HTTP 200 avec
       * {ok:false, erreur, remede}. Jeter le corps sur un statut non-200
       * perdrait le REMÈDE, qui est la partie utile du refus : un panneau qui
       * affiche « HTTP 400 » au lieu de « le fichier n'existe pas, vérifiez le
       * chemin » est une impasse pour l'utilisateur. */
      if (corps && (corps.erreur || corps.remede)) return corps;
      return { ok: false, erreur: (corps && (corps.error || corps.erreur)) ||
        ('HTTP ' + reponse.status) };
    }
    return corps;
  } catch (exc) {
    /* Une erreur réseau ne doit pas casser le panneau : elle est rendue comme
     * un échec nommé, avec la cause, pour que la zone d'état l'affiche. */
    return { ok: false, erreur: 'Le serveur n’a pas répondu : ' + exc.message };
  }
}

function erreur(message) {
  /* erreur('') EFFACE l'état d'erreur : c'est l'appel que font les chemins qui
   * réussissent. Compter ces appels comme des erreurs gonflait le compteur de
   * trois unités par parcours réussi, et un compteur faux est pire qu'un
   * compteur absent : il fait croire à des échecs qui n'ont pas eu lieu, et il
   * noie les vrais. */
  const texte = String(message || '');
  derniereErreur = texte;
  if (texte) {
    compteurErreurs += 1;
    journalErreurs.push(texte);
    if (journalErreurs.length > 40) journalErreurs.shift();
  }
  const zone = $('.ps-re-etat', racine);
  if (zone) rendreEtat();
  return derniereErreur;
}

function refus(resultat, defaut) {
  /* Un refus du serveur porte `erreur` et souvent `remede`. Les deux sont
   * affichés : un refus sans remède est une impasse pour l'utilisateur. */
  if (resultat && resultat.ok === false) {
    erreur(resultat.erreur || defaut || 'Refusé.');
    return resultat;
  }
  return resultat;
}

/* Le chemin du fichier analysé vient de l'onglet actif du bundle, et à défaut
 * d'un champ de saisie. Le bundle publie PSFMWorkspace ; s'il est absent (page
 * ouverte hors application), le champ suffit. */
function cheminCourant() {
  const champ = $('.ps-re-chemin', racine);
  if (champ && champ.value && champ.value.trim()) return champ.value.trim();
  try {
    const espace = window.PSFMWorkspace && window.PSFMWorkspace();
    const actif = espace && (espace.actif || espace.active || espace.ongletActif);
    if (actif && typeof actif === 'string') return actif;
    if (actif && actif.path) return actif.path;
    if (espace && typeof espace === 'string') return espace;
  } catch (exc) { /* le bundle n'est pas tenu d'exposer cet état */ }
  return '';
}

function nomCourt(chemin) {
  const texte = String(chemin || '');
  const parties = texte.split('/');
  return parties[parties.length - 1] || texte;
}

/* ---------------------------------------------------------------- FENÊTRE --- */
/* Ce qui est lourd à lire (désassemblage, décompilation, contenu d'une fiche,
 * résultat d'un widget) s'ouvre dans une fenêtre flottante au-dessus de
 * l'éditeur — jamais à sa place : on compare du code au binaire. */
let fenetre = null;

function geometrie() {
  try {
    return JSON.parse(localStorage.getItem(CLE_GEOMETRIE) || 'null');
  } catch (exc) { return null; }
}

function memoriserGeometrie() {
  if (!fenetre) return;
  try {
    localStorage.setItem(CLE_GEOMETRIE, JSON.stringify({
      x: fenetre.offsetLeft, y: fenetre.offsetTop,
      largeur: fenetre.offsetWidth, hauteur: fenetre.offsetHeight,
    }));
  } catch (exc) { /* un stockage plein ne doit pas casser le panneau */ }
}

/* 4.3.1 : une fenêtre déléguée à un onglet ne se déplace plus — la zone des vues
 * possède la géométrie du noeud qu'on lui confie. Les fenêtres de dialogue du
 * panneau restent dans document.body et gardent leur glisser. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function deplacable(noeud, poignee) {
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(noeud)) return;
    ev.preventDefault();
    const departX = ev.clientX, departY = ev.clientY;
    const gauche = noeud.offsetLeft, haut = noeud.offsetTop;
    function bouger(e) {
      noeud.style.left = Math.max(0, gauche + e.clientX - departX) + 'px';
      noeud.style.top = Math.max(0, haut + e.clientY - departY) + 'px';
    }
    function finir() {
      window.removeEventListener('pointermove', bouger);
      window.removeEventListener('pointerup', finir);
      memoriserGeometrie();
    }
    window.addEventListener('pointermove', bouger);
    window.addEventListener('pointerup', finir);
  });
}

function redimensionnable(noeud) {
  const poignee = el('div', { class: 'ps-re-redim', title: 'Redimensionner' });
  noeud.appendChild(poignee);
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(noeud)) return;
    ev.preventDefault(); ev.stopPropagation();
    const departX = ev.clientX, departY = ev.clientY;
    const largeur = noeud.offsetWidth, hauteur = noeud.offsetHeight;
    function bouger(e) {
      noeud.style.width = Math.max(LARGEUR_MIN, largeur + e.clientX - departX) + 'px';
      noeud.style.height = Math.max(HAUTEUR_MIN, hauteur + e.clientY - departY) + 'px';
    }
    function lacher() {
      window.removeEventListener('pointermove', bouger);
      window.removeEventListener('pointerup', lacher);
      memoriserGeometrie();
    }
    window.addEventListener('pointermove', bouger);
    window.addEventListener('pointerup', lacher);
  });
}

function fermerFenetre() {
  /* `remove()` et pas `parentNode.removeChild()` : les deux existent dans un
   * navigateur, mais c'est la forme que couvre le harnais DOM des bancs. Une
   * fenêtre qu'on ne peut pas fermer dans un banc est une fenêtre dont on ne
   * peut pas tester la réouverture. */
  if (fenetre && typeof fenetre.remove === 'function') fenetre.remove();
  fenetre = null;
}

function ouvrirFenetre(titre, contenu) {
  fermerFenetre();
  const corps = el('div', { class: 'ps-re-fenetre-corps' }, contenu);
  const barre = el('div', { class: 'ps-re-fenetre-barre' },
    el('span', { class: 'ps-re-fenetre-titre', text: titre }),
    el('button', {
      class: 'ps-re-bouton ps-re-bouton-fermer', type: 'button',
      text: 'Fermer', title: 'Fermer cette fenêtre (Échap)',
      onclick: fermerFenetre,
    }));
  fenetre = el('div', { class: 'ps-re-fenetre', role: 'dialog' }, barre, corps);
  const memo = geometrie();
  if (memo && memo.largeur) {
    fenetre.style.left = Math.max(0, memo.x || 60) + 'px';
    fenetre.style.top = Math.max(0, memo.y || 60) + 'px';
    fenetre.style.width = Math.max(LARGEUR_MIN, memo.largeur) + 'px';
    fenetre.style.height = Math.max(HAUTEUR_MIN, memo.hauteur) + 'px';
  }
  document.body.appendChild(fenetre);
  deplacable(fenetre, barre);
  redimensionnable(fenetre);
  return corps;
}

document.addEventListener('keydown', ev => {
  if (ev.key === 'Escape' && fenetre) { ev.stopPropagation(); fermerFenetre(); }
});

/* ------------------------------------------------------------------ RENDU --- */
function rendreEtat() {
  if (!racine) return;
  const zone = $('.ps-re-etat', racine);
  if (!zone) return;
  vider(zone);
  const enCours = taches.filter(t => t.etat === 'en_cours' || t.etat === 'lance');
  const morceaux = [];
  if (binaire) morceaux.push('Fichier : ' + nomCourt(binaire));
  if (analyse && analyse.famille) morceaux.push('Famille : ' + analyse.famille);
  if (enCours.length) morceaux.push(enCours.length + ' tâche(s) Ghidra en cours');
  if (capacites && !capacites.pret_pour_ghidra) morceaux.push('Ghidra non prêt');
  morceaux.push(compteurAppels + ' appel(s)');
  if (compteurErreurs) morceaux.push(compteurErreurs + ' erreur(s)');
  ajouter(zone, el('span', { class: 'ps-re-etat-ligne', text: morceaux.join(' · ') }));
  if (derniereErreur) {
    ajouter(zone, el('span', { class: 'ps-re-etat-erreur', text: derniereErreur }));
  }
}

function notes(resultat) {
  /* Les notes sont la partie du résultat qui dit ce qui N'A PAS pu être lu.
   * Les ignorer reviendrait à présenter un résultat partiel comme complet. */
  const liste = (resultat && resultat.notes) || [];
  if (!Array.isArray(liste) || !liste.length) return null;
  return el('div', { class: 'ps-re-notes' },
    liste.map(note => el('div', { class: 'ps-re-note', text: String(note) })));
}

function pre(texte, classe) {
  return el('pre', { class: 'ps-re-pre ' + (classe || ''), text: String(texte || '') });
}

function refusBloc(resultat) {
  const boite = el('div', { class: 'ps-re-refus' },
    el('div', { class: 'ps-re-refus-titre', text: (resultat && resultat.erreur) || 'Refusé.' }));
  if (resultat && resultat.remede) {
    ajouter(boite, el('div', { class: 'ps-re-refus-remede', text: resultat.remede }));
  }
  return boite;
}

function tableau(lignes, entetes) {
  if (!lignes || !lignes.length) {
    return el('div', { class: 'ps-re-vide', text: 'Aucune ligne.' });
  }
  const cles = entetes || Object.keys(lignes[0]);
  const tete = el('tr', {}, cles.map(c => el('th', { text: String(c) })));
  const corps = lignes.map(ligne => el('tr', {}, cles.map(c => {
    const valeur = ligne[c];
    const texte = (valeur === null || valeur === undefined) ? '' : String(valeur);
    return el('td', { text: texte, title: texte.length > 60 ? texte : null });
  })));
  return el('div', { class: 'ps-re-table-boite' },
    el('table', { class: 'ps-re-table' }, el('thead', {}, tete), el('tbody', {}, corps)));
}

function boutons(liste) {
  return el('div', { class: 'ps-re-boutons' }, liste.filter(Boolean).map(b => b));
}

function bouton(titre, action, options) {
  const opts = options || {};
  return el('button', {
    class: 'ps-re-bouton' + (opts.primaire ? ' ps-re-primaire' : ''),
    type: 'button', text: titre, title: opts.title || titre,
    disabled: !!opts.disabled, onclick: action,
  });
}

/* ---------------------------------------------------------------- SECTIONS -- */
function rendre() {
  if (!racine) return;
  const corps = $('.ps-re-corps', racine);
  if (!corps) return;
  vider(corps);
  const barre = $('.ps-re-barre', racine);
  if (barre) {
    vider(barre);
    SECTIONS.forEach(section => {
      const actif = !!ouvert[section.id];
      const indisponible = section.id === 'ghidra' && capacites &&
        !capacites.pret_pour_ghidra;
      ajouter(barre, el('button', {
        class: 'ps-re-onglet' + (actif ? ' ps-re-onglet-actif' : '') +
          (indisponible ? ' ps-re-onglet-indisponible' : ''),
        type: 'button', title: indisponible ?
          'Ghidra n’est pas prêt ici : la section explique ce qui manque' : section.titre,
        onclick: () => basculer(section.id),
      }, svg(section.icone), el('span', { text: section.titre })));
    });
  }
  SECTIONS.forEach(section => {
    if (!ouvert[section.id]) return;
    /* La section porte DEUX marques : `data-section` pour le CSS et les
     * outils externes, et une classe propre `ps-re-section-<id>` pour les
     * bancs. Le harnais DOM de ce projet ne sait pas apparier un sélecteur
     * combinant classe et attribut, et un banc incapable de retrouver une
     * section ne peut pas la tester. */
    ajouter(corps, el('section', {
      class: 'ps-re-section ps-re-section-' + section.id,
      'data-section': section.id,
    },
      el('h3', { class: 'ps-re-titre', text: section.titre }),
      rendreSection(section.id)));
  });
  rendreEtat();
}

function basculer(id) {
  ouvert[id] = !ouvert[id];
  /* Une seule section lourde ouverte à la fois : ouvrir Analyse et
   * Désassemblage ensemble rend le panneau illisible dans 238 px. */
  rendre();
}

function rendreSection(id) {
  switch (id) {
    case 'environnement': return sectionEnvironnement();
    case 'analyse': return sectionAnalyse();
    case 'symboles': return sectionSymboles();
    case 'chaines': return sectionChaines();
    case 'desassemblage': return sectionDesassemblage();
    case 'ghidra': return sectionGhidra();
    case 'widgets': return sectionWidgets();
    case 'fiches': return sectionFiches();
    default: return el('div', { class: 'ps-re-vide', text: 'Section inconnue.' });
  }
}

/* Le champ de chemin est partagé par toutes les sections : un panneau qui fait
 * re-saisir le fichier à chaque section n'est pas utilisable. */
function champChemin() {
  return el('div', { class: 'ps-re-ligne' },
    el('label', { class: 'ps-re-etiquette', text: 'Fichier' }),
    el('input', {
      class: 'ps-re-chemin ps-re-saisie', type: 'text',
      value: binaire || '', placeholder: '/chemin/du/binaire',
      spellcheck: 'false',
      onchange: ev => { binaire = ev.target.value.trim() || null; rendreEtat(); },
    }),
    bouton('Depuis l’onglet', () => {
      const chemin = cheminCourant();
      if (!chemin) { erreur('Aucun onglet actif dont reprendre le chemin.'); return; }
      binaire = chemin;
      const champ = $('.ps-re-chemin', racine);
      if (champ) champ.value = chemin;
      rendreEtat();
    }, { title: 'Reprendre le chemin du fichier ouvert dans l’éditeur' }));
}

/* ---------------------------------------------------- 1. ENVIRONNEMENT ------ */
function sectionEnvironnement() {
  const boite = el('div', { class: 'ps-re-env' });
  if (!capacites) {
    ajouter(boite, el('div', { class: 'ps-re-vide', text: 'Capacités non chargées.' }));
    return boite;
  }
  const ghidra = capacites.ghidra || {};
  const pret = !!capacites.pret_pour_ghidra;

  ajouter(boite, el('div', {
    class: 'ps-re-bandeau ' + (pret ? 'ps-re-bandeau-ok' : 'ps-re-bandeau-absent'),
  },
    el('strong', { text: pret ? 'Ghidra est prêt' : 'Ghidra n’est pas installé' }),
    el('span', { text: ghidra.raison || (pret ? '' : 'Raison inconnue.') })));

  /* Ce qui reste possible SANS Ghidra est affiché en premier : c'est la réponse
   * utile à « Ghidra absent ». */
  const repli = capacites.sans_ghidra || [];
  if (repli.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Possible ici, sans Ghidra' }),
      el('ul', { class: 'ps-re-liste' }, repli.map(item => el('li', { text: String(item) })))));
  }

  const manquants = capacites.manquants || [];
  if (manquants.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Ce qui manque' }),
      el('ul', { class: 'ps-re-liste ps-re-liste-absente' },
        manquants.map(item => el('li', { text: String(item) })))));
  }

  const outils = capacites.outils_disponibles || [];
  const absents = capacites.outils_absents || [];
  ajouter(boite, el('div', { class: 'ps-re-bloc' },
    el('h4', { text: 'Outils en ligne de commande' }),
    el('div', { class: 'ps-re-pastilles' },
      outils.map(o => el('span', { class: 'ps-re-pastille ps-re-pastille-ok', text: String(o) })),
      absents.map(o => el('span', {
        class: 'ps-re-pastille ps-re-pastille-non', text: String(o),
        title: 'Absent : installez-le ou utilisez un autre outil',
      })))));

  /* Les voies d'installation sont le cœur de cette section. Chacune porte ses
   * commandes PRÊTES À COPIER : recopier une commande à la main depuis un texte
   * est la première cause d'échec d'installation. */
  const installations = ghidra.installations_commandes || ghidra.installations || [];
  if (installations.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Installer ce qui manque' }),
      installations.map(voie => {
        const commandes = Array.isArray(voie.commandes) ? voie.commandes :
          (voie.commandes && voie.commandes.length !== undefined ?
            Array.from(voie.commandes) : []);
        return el('details', { class: 'ps-re-voie' },
          el('summary', {},
            el('strong', { text: voie.nom || voie.id || 'Voie' }),
            voie.installe_dans ? el('code', { text: voie.installe_dans }) : null),
          voie.resume ? el('p', { class: 'ps-re-resume', text: voie.resume }) : null,
          commandes.map(c => el('div', { class: 'ps-re-commande' },
            el('code', { text: String(c) }),
            bouton('Copier', () => copier(String(c)), { title: 'Copier cette commande' }))),
          voie.source ? el('p', { class: 'ps-re-source' },
            el('span', { text: 'Source : ' }),
            el('code', { text: String(voie.source) })) : null);
      })));
  }

  ajouter(boite, boutons([
    bouton('Relire l’environnement', () => chargerCapacites(true), { primaire: true }),
    bouton('Voir le postScript Ghidra', () => ouvrirPostScript()),
    bouton('Ce que le panneau n’exécute jamais', () => ouvrirNonExecution()),
  ]));
  return boite;
}

function copier(texte) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(texte).then(
        () => erreur(''),
        () => erreur('Le presse-papiers a refusé l’écriture ; la commande est affichée, copiez-la à la main.'));
      return;
    }
  } catch (exc) { /* repli ci-dessous */ }
  /* Sans presse-papiers (page non sécurisée, permissions refusées), la commande
   * est ouverte dans une fenêtre avec un bouton de sélection : l'utilisateur
   * peut toujours la copier. */
  const corps = ouvrirFenetre('Commande à copier',
    el('div', {}, pre(texte), el('p', {
      class: 'ps-re-note',
      text: 'Le presse-papiers n’est pas accessible ici : sélectionnez le texte ci-dessus.',
    })));
  const zone = $('pre', corps);
  if (zone) {
    const plage = document.createRange();
    plage.selectNodeContents(zone);
    const selection = window.getSelection();
    if (selection) { selection.removeAllRanges(); selection.addRange(plage); }
  }
}

function ouvrirNonExecution() {
  ouvrirFenetre('Ce que le panneau n’exécute jamais', el('div', {},
    el('p', {}, 'Aucun binaire analysé n’est exécuté. Le panneau lit des octets ' +
      'et appelle des outils de lecture : objdump, readelf, nm, strings, file, od.'),
    el('p', {}, 'La seule exécution est celle de Ghidra lui-même, dans un ' +
      'processus séparé, sur une copie du projet. Une tâche Ghidra est ' +
      'toujours arrêtable, et son identifiant est affiché.'),
    el('p', {}, 'Le panneau déclare cette propriété : '),
    pre('execute_des_binaires : ' + (capacites ? capacites.execute_des_binaires : '?')),
    el('p', { class: 'ps-re-note' }, 'Un vidage qui dépasse la fin du fichier ' +
      'rend « absent du fichier » et jamais des zéros inventés. Une RVA qui ne ' +
      'tombe dans aucune section rend null avec une note, et jamais 0.')));
}

async function ouvrirPostScript() {
  const resultat = refus(await appeler('postscript'));
  if (!resultat || !resultat.ok) { ouvrirFenetre('postScript Ghidra', refusBloc(resultat || {})); return; }
  ouvrirFenetre('postScript envoyé à Ghidra (' + resultat.octets + ' octets)', el('div', {},
    el('p', { class: 'ps-re-note' }, 'Ce script est le seul code que le panneau ' +
      'fait exécuter par Ghidra. Il est affiché ici pour qu’il puisse être lu : ' +
      'il n’écrit que du JSON, encadré par deux marqueurs.'),
    el('div', {}, 'Début : ', el('code', { text: resultat.marqueur_debut || '?' }),
      '  Fin : ', el('code', { text: resultat.marqueur_fin || '?' })),
    pre(resultat.postscript)));
}

async function chargerCapacites(rafraichir) {
  const resultat = await appeler('capacites', rafraichir ? { rafraichir: true } : {});
  if (resultat && resultat.ok !== false) {
    capacites = resultat;
    /* Les tâches ne sont sondées que si Ghidra est prêt : sonder sans pont
     * produirait une erreur toutes les 2,5 s dans la zone d'état. */
    if (resultat.pret_pour_ghidra) demarrerSonde(); else arreterSonde();
  } else {
    erreur((resultat && resultat.erreur) || 'Les capacités n’ont pas pu être lues.');
  }
  rendre();
}

function demarrerSonde() {
  arreterSonde();
  sondes = setInterval(async () => {
    const resultat = await appeler('taches');
    if (resultat && resultat.ok) {
      const avant = taches.filter(t => t.etat === 'en_cours').map(t => t.id).join(',');
      taches = resultat.taches || [];
      const apres = taches.filter(t => t.etat === 'en_cours').map(t => t.id).join(',');
      if (avant !== apres) rendre(); else rendreEtat();
    }
  }, SONDE_TACHES);
}

function arreterSonde() {
  if (sondes) { clearInterval(sondes); sondes = null; }
}

window.PSRetro = {
  capacites: () => capacites,
  analyse: () => analyse,
  taches: () => taches.slice(),
  etat: () => ({
    hote: !!hote, binaire: binaire,
    sections: Object.keys(ouvert).filter(k => ouvert[k]),
    appels: compteurAppels, erreurs: compteurErreurs,
    messages: journalErreurs.slice(),
    ghidra: capacites ? !!capacites.pret_pour_ghidra : false,
    widgets: capacites ? capacites.nombre_widgets : 0,
    fiches: capacites ? capacites.fiches : 0,
  }),
  ouvrir: section => { if (section) ouvert[section] = true; rendre(); },
  fermer: fermerFenetre,
  analyser: chemin => lancerAnalyse(chemin),
  fiche: id => ouvrirFiche(id),
  widget: id => ouvrirWidget(id),
  erreur: message => erreur(message),
};

/* ------------------------------------------------------------ 2. ANALYSE ---- */
function sectionAnalyse() {
  const boite = el('div', {});
  ajouter(boite, champChemin());
  ajouter(boite, boutons([
    bouton('Analyser', () => lancerAnalyse(), { primaire: true }),
    bouton('Vidage', () => lancerVidage()),
    bouton('Famille', () => lancerFamille()),
    bouton('Ouvrir le rapport', () => ouvrirAnalyse(),
      { disabled: !analyse }),
  ]));
  if (!analyse) {
    ajouter(boite, el('div', { class: 'ps-re-vide' },
      'Aucun fichier analysé. Saisissez un chemin, ou reprenez celui de ' +
      'l’onglet actif, puis lancez l’analyse.'));
    return boite;
  }
  ajouter(boite, resumeAnalyse(analyse));
  return boite;
}

function resumeAnalyse(resultat) {
  const lignes = [];
  const pousser = (cle, valeur) => {
    if (valeur === null || valeur === undefined || valeur === '') return;
    lignes.push({ propriété: cle, valeur: String(valeur) });
  };
  pousser('Famille', resultat.famille);
  pousser('Nom', resultat.nom);
  pousser('Taille', resultat.taille ? resultat.taille + ' octets' : '');
  pousser('Machine', (resultat.elf && resultat.elf.machine) ||
    (resultat.pe && resultat.pe.machine) || '');
  pousser('Boutisme', (resultat.elf && resultat.elf.boutisme) || '');
  pousser('Classe', (resultat.elf && resultat.elf.classe) || '');
  pousser('Entrée', resultat.entree || (resultat.elf && resultat.elf.entree) || '');
  pousser('Sections', (resultat.sections || []).length);
  pousser('Segments', (resultat.segments || []).length);
  pousser('Symboles', (resultat.symboles || []).length);
  pousser('Chaînes', (resultat.chaines || []).length);
  pousser('Entropie globale', resultat.entropie !== undefined &&
    resultat.entropie !== null ? Number(resultat.entropie).toFixed(4) : '');
  if (resultat.ambiguite) pousser('Ambiguïté', resultat.raison || 'signalée');
  const boite = el('div', { class: 'ps-re-bloc' },
    el('h4', { text: 'Résumé' }), tableau(lignes));
  const indices = resultat.heuristiques || [];
  if (indices.length) {
    /* Chaque heuristique porte sa confiance et sa raison : les afficher sans
     * ces deux champs ferait prendre une hypothèse pour un fait. */
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Indices (' + indices.length + ')' }),
      indices.map(i => el('div', { class: 'ps-re-indice ps-re-conf-' + (i.confiance || 'faible') },
        el('strong', { text: i.quoi || '?' }),
        el('span', { class: 'ps-re-confiance', text: '[' + (i.confiance || '?') + ']' }),
        el('div', { class: 'ps-re-raison', text: i.raison || '' }),
        i.commande ? el('div', { class: 'ps-re-commande' },
          el('code', { text: i.commande }),
          bouton('Copier', () => copier(String(i.commande)))) : null,
        i.installation ? el('div', { class: 'ps-re-source', text: i.installation }) : null))));
  }
  ajouter(boite, notes(resultat));
  return boite;
}

async function lancerAnalyse(chemin) {
  const cible = chemin || binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier : saisissez un chemin ou ouvrez un fichier.'); return null; }
  binaire = cible;
  const champ = $('.ps-re-chemin', racine);
  if (champ) champ.value = cible;
  rendreEtat();
  const resultat = refus(await appeler('analyser', { chemin: cible }));
  if (!resultat || resultat.ok === false) {
    ouvrirFenetre('Analyse refusée', refusBloc(resultat || {}));
    return null;
  }
  analyse = resultat;
  rendre();
  ouvrirAnalyse();
  return resultat;
}

function ouvrirAnalyse() {
  if (!analyse) return;
  const contenu = el('div', {});
  ajouter(contenu, resumeAnalyse(analyse));
  const sections = analyse.sections || [];
  if (sections.length) {
    ajouter(contenu, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Sections (' + sections.length + ')' }),
      tableau(sections.map(s => ({
        nom: s.nom, type: s.type, adresse: s.adresse,
        décalage: s.decalage, taille: s.taille,
        droits: s.drapeaux_texte || s.drapeaux || '',
        entropie: (s.entropie === null || s.entropie === undefined) ?
          (s.note || 'absente du fichier') : Number(s.entropie).toFixed(3),
      })))));
  }
  const segments = analyse.segments || [];
  if (segments.length) {
    ajouter(contenu, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Segments (' + segments.length + ')' }),
      tableau(segments.map(sg => ({
        type: sg.type, droits: sg.drapeaux_texte || sg.drapeaux || '',
        adresse: sg.adresse, décalage: sg.decalage,
        taille_fichier: sg.taille_fichier, taille_mémoire: sg.taille_memoire,
      })))));
  }
  if (analyse.pe) {
    ajouter(contenu, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'En-tête PE' }),
      tableau([{
        machine: analyse.pe.machine, caractéristiques: analyse.pe.caracteristiques_texte ||
          analyse.pe.caracteristiques || '',
        protections: (analyse.pe.protections || []).join(', ') || 'aucune',
        sous_système: analyse.pe.sous_systeme || '',
        horodatage: analyse.pe.horodatage_texte || analyse.pe.horodatage || '',
      }])));
  }
  if (analyse.imports && analyse.imports.length) {
    ajouter(contenu, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Bibliothèques importées' }),
      tableau(analyse.imports.map(i => (typeof i === 'string' ? { bibliothèque: i } : {
        bibliothèque: i.nom, fonctions: (i.fonctions || []).length,
        détail: (i.fonctions || []).slice(0, 8).join(', '),
      })))));
  }
  ajouter(contenu, notes(analyse));
  ouvrirFenetre('Analyse de ' + nomCourt(binaire), contenu);
}

async function lancerVidage() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier à vidanger.'); return; }
  const resultat = refus(await appeler('vidage', { chemin: cible, longueur: OCTETS_VIDAGE }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Vidage refusé', refusBloc(resultat || {})); return; }
  const texte = resultat.lignes ? resultat.lignes.join('\n') : (resultat.texte || '');
  ouvrirFenetre('Vidage de ' + nomCourt(cible) + ' (début ' + (resultat.debut || 0) + ')',
    el('div', {},
      pre(texte || '(vide)'),
      resultat.tronque ? el('div', { class: 'ps-re-note' },
        'Le vidage s’arrête à la fin du fichier : aucun octet n’est inventé ' +
        'au-delà.') : null,
      notes(resultat),
      boutons([bouton('Copier le vidage', () => copier(texte)),
        bouton('Coller dans le widget hexdump', () => {
          ouvrirWidget('hexdump', texte);
        })])));
}

async function lancerFamille() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier dont reconnaître la famille.'); return; }
  const resultat = refus(await appeler('famille', { chemin: cible }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Famille', refusBloc(resultat || {})); return; }
  ouvrirFenetre('Famille de ' + nomCourt(cible), el('div', {},
    el('div', { class: 'ps-re-famille' },
      el('strong', { text: resultat.famille || 'inconnue' }),
      el('span', { text: resultat.nom || '' })),
    resultat.ambiguite ? el('div', { class: 'ps-re-note' },
      'Signature ambiguë : ' + (resultat.raison || '')) : null,
    resultat.raison ? el('div', {}, el('code', { text: resultat.raison })) : null,
    notes(resultat)));
}

/* ----------------------------------------------------------- 3. SYMBOLES ---- */
function sectionSymboles() {
  const boite = el('div', {});
  ajouter(boite, champChemin());
  ajouter(boite, el('div', { class: 'ps-re-ligne' },
    el('label', { class: 'ps-re-case' },
      el('input', { class: 'ps-re-case-input', type: 'checkbox', checked: true,
        onchange: ev => { etatCases.demangler = ev.target.checked; } }),
      el('span', { text: 'Démangler (C++)' })),
    el('label', { class: 'ps-re-case' },
      el('input', { class: 'ps-re-case-input', type: 'checkbox', checked: true,
        onchange: ev => { etatCases.taille = ev.target.checked; } }),
      el('span', { text: 'Avec la taille' })),
    el('label', { class: 'ps-re-case' },
      el('input', { class: 'ps-re-case-input', type: 'checkbox',
        onchange: ev => { etatCases.definis = ev.target.checked; } }),
      el('span', { text: 'Seulement les définis' }))));
  ajouter(boite, boutons([
    bouton('Lire les symboles', () => lancerSymboles(), { primaire: true }),
    bouton('Ouvrir la liste', () => ouvrirSymboles(), { disabled: !dernieresSymboles }),
  ]));
  if (!dernieresSymboles) {
    ajouter(boite, el('div', { class: 'ps-re-vide' }, 'Aucun symbole lu.'));
  } else {
    ajouter(boite, el('div', { class: 'ps-re-compte' },
      (dernieresSymboles.symboles || []).length + ' symbole(s) — ' +
      (dernieresSymboles.source || 'source inconnue')));
    ajouter(boite, notes(dernieresSymboles));
  }
  return boite;
}

const etatCases = { demangler: true, taille: true, definis: false };
let dernieresSymboles = null;

async function lancerSymboles() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier dont lire les symboles.'); return; }
  binaire = cible;
  const resultat = refus(await appeler('symboles', {
    chemin: cible, seulement_definis: etatCases.definis,
    demangler: etatCases.demangler, taille: etatCases.taille,
  }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Symboles refusés', refusBloc(resultat || {})); return; }
  dernieresSymboles = resultat;
  rendre();
  ouvrirSymboles();
}

function ouvrirSymboles() {
  if (!dernieresSymboles) return;
  const symboles = dernieresSymboles.symboles || [];
  const corps = el('div', {});
  ajouter(corps, el('div', { class: 'ps-re-ligne' },
    el('input', {
      class: 'ps-re-saisie', type: 'text', placeholder: 'Filtrer les symboles…',
      spellcheck: 'false',
      oninput: ev => filtrerSymboles(corps, symboles, ev.target.value),
    })));
  ajouter(corps, el('div', { class: 'ps-re-symboles' }, tableau(symboles.map(s => ({
    nom: s.nom, type: s.type, liaison: s.liaison, section: s.section,
    valeur: s.valeur, taille: s.taille,
  })))));
  ajouter(corps, notes(dernieresSymboles));
  ouvrirFenetre('Symboles de ' + nomCourt(binaire) + ' (' + symboles.length + ')', corps);
}

let retardSymboles = null;
function filtrerSymboles(corps, symboles, motif) {
  clearTimeout(retardSymboles);
  retardSymboles = setTimeout(() => {
    const zone = $('.ps-re-symboles', corps);
    if (!zone) return;
    const aiguille = String(motif || '').toLowerCase();
    const gardes = aiguille ? symboles.filter(s =>
      String(s.nom || '').toLowerCase().indexOf(aiguille) >= 0) : symboles;
    vider(zone);
    ajouter(zone, el('div', { class: 'ps-re-compte' },
      gardes.length + ' sur ' + symboles.length));
    ajouter(zone, tableau(gardes.map(s => ({
      nom: s.nom, type: s.type, liaison: s.liaison, section: s.section,
      valeur: s.valeur, taille: s.taille,
    }))));
  }, RETARD_RECHERCHE);
}

/* ------------------------------------------------------------ 4. CHAÎNES ---- */
function sectionChaines() {
  const boite = el('div', {});
  ajouter(boite, champChemin());
  ajouter(boite, el('div', { class: 'ps-re-ligne' },
    el('label', { class: 'ps-re-etiquette', text: 'Longueur minimale' }),
    el('input', {
      class: 'ps-re-saisie ps-re-saisie-courte', type: 'number', value: 5, min: 2, max: 64,
      onchange: ev => { etatChaines.minimum = ev.target.value; },
    }),
    el('label', { class: 'ps-re-etiquette', text: 'Limite' }),
    el('input', {
      class: 'ps-re-saisie ps-re-saisie-courte', type: 'number', value: 2000,
      min: 1, max: 200000,
      onchange: ev => { etatChaines.limite = ev.target.value; },
    })));
  ajouter(boite, boutons([
    bouton('Chercher les chaînes', () => lancerChaines(), { primaire: true }),
    bouton('Ouvrir la liste', () => ouvrirChaines(), { disabled: !dernieresChaines }),
  ]));
  if (!dernieresChaines) ajouter(boite, el('div', { class: 'ps-re-vide' }, 'Aucune chaîne lue.'));
  else {
    ajouter(boite, el('div', { class: 'ps-re-compte' },
      (dernieresChaines.chaines || []).length + ' chaîne(s) — ' +
      (dernieresChaines.octets_lus || 0) + ' octets parcourus'));
    ajouter(boite, notes(dernieresChaines));
  }
  return boite;
}

const etatChaines = { minimum: 5, limite: 2000 };
let dernieresChaines = null;

async function lancerChaines() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier où chercher des chaînes.'); return; }
  binaire = cible;
  const resultat = refus(await appeler('chaines', {
    chemin: cible, minimum: etatChaines.minimum, limite: etatChaines.limite,
  }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Chaînes refusées', refusBloc(resultat || {})); return; }
  dernieresChaines = resultat;
  rendre();
  ouvrirChaines();
}

function ouvrirChaines() {
  if (!dernieresChaines) return;
  const chaines = dernieresChaines.chaines || [];
  const corps = el('div', {});
  /* Le nombre d'octets PARCOURUS est affiché avec le nombre de chaînes : sans
   * lui, « 1 chaîne trouvée » et « 1 chaîne trouvée sur 4 Mo lus » se
   * ressemblent, et le deuxième dit quelque chose de beaucoup plus fort. Une
   * liste vide parcourue sur tout le fichier est un résultat ; une liste vide
   * parce que la lecture s'est arrêtée au premier koctet en est un autre. */
  if (dernieresChaines.octets_lus !== undefined) {
    ajouter(corps, el('div', { class: 'ps-re-compte' },
      chaines.length + ' chaîne(s) sur ' + dernieresChaines.octets_lus +
      ' octets parcourus (longueur minimale ' +
      (dernieresChaines.minimum !== undefined ? dernieresChaines.minimum
        : etatChaines.minimum) + ')'));
  }
  ajouter(corps, el('div', { class: 'ps-re-ligne' },
    el('input', {
      class: 'ps-re-saisie', type: 'text', placeholder: 'Filtrer les chaînes…',
      spellcheck: 'false',
      oninput: ev => filtrerChaines(corps, chaines, ev.target.value),
    }),
    bouton('Copier la liste', () => copier(chaines.map(c =>
      (c.decalage !== undefined ? '0x' + Number(c.decalage).toString(16) + '  ' : '') +
      (c.texte !== undefined ? c.texte : c)).join('\n')))));
  ajouter(corps, el('div', { class: 'ps-re-chaines' }, rendreChaines(chaines)));
  ajouter(corps, notes(dernieresChaines));
  ouvrirFenetre('Chaînes de ' + nomCourt(binaire) + ' (' + chaines.length + ')', corps);
}

function rendreChaines(chaines) {
  return tableau(chaines.map(c => {
    if (typeof c === 'string') return { texte: c };
    return {
      décalage: c.decalage !== undefined ? '0x' + Number(c.decalage).toString(16) : '',
      encodage: c.encodage || '',
      section: c.section || '',
      texte: c.texte !== undefined ? c.texte : String(c),
    };
  }));
}

let retardChaines = null;
function filtrerChaines(corps, chaines, motif) {
  clearTimeout(retardChaines);
  retardChaines = setTimeout(() => {
    const zone = $('.ps-re-chaines', corps);
    if (!zone) return;
    const aiguille = String(motif || '').toLowerCase();
    const gardes = aiguille ? chaines.filter(c => {
      const texte = typeof c === 'string' ? c : String(c.texte || '');
      return texte.toLowerCase().indexOf(aiguille) >= 0;
    }) : chaines;
    vider(zone);
    ajouter(zone, el('div', { class: 'ps-re-compte' }, gardes.length + ' sur ' + chaines.length));
    ajouter(zone, rendreChaines(gardes));
  }, RETARD_RECHERCHE);
}

/* ------------------------------------------------------- 5. DÉSASSEMBLAGE --- */
function sectionDesassemblage() {
  const boite = el('div', {});
  ajouter(boite, champChemin());
  ajouter(boite, el('div', { class: 'ps-re-ligne' },
    el('label', { class: 'ps-re-etiquette', text: 'Syntaxe' }),
    el('select', {
      class: 'ps-re-saisie', onchange: ev => { etatDesass.syntaxe = ev.target.value; },
    },
      el('option', { value: 'att', text: 'AT&T (objdump par défaut)' }),
      el('option', { value: 'intel', text: 'Intel (x86 seulement)' })),
    el('label', { class: 'ps-re-etiquette', text: 'Lignes' }),
    el('input', {
      class: 'ps-re-saisie ps-re-saisie-courte', type: 'number', value: 200,
      min: 1, max: MAX_LIGNES_DESASS,
      onchange: ev => { etatDesass.lignes = ev.target.value; },
    }),
    el('label', { class: 'ps-re-etiquette', text: 'Symbole' }),
    el('input', {
      class: 'ps-re-saisie', type: 'text', placeholder: 'main', spellcheck: 'false',
      onchange: ev => { etatDesass.symbole = ev.target.value.trim(); },
    })));
  ajouter(boite, el('div', { class: 'ps-re-note' },
    'L’option « -M intel » n’existe que sur x86. Sur une autre architecture, ' +
    'objdump échoue : le module réessaie sans l’option et LE DIT dans les ' +
    'notes. Un désassemblage AT&T présenté comme de l’Intel serait une ' +
    'information fausse.'));
  ajouter(boite, boutons([
    bouton('Désassembler', () => lancerDesassemblage(), { primaire: true }),
    bouton('Ouvrir', () => ouvrirDesassemblage(), { disabled: !dernierDesass }),
  ]));
  if (!dernierDesass) ajouter(boite, el('div', { class: 'ps-re-vide' }, 'Aucun désassemblage.'));
  else ajouter(boite, notes(dernierDesass));
  return boite;
}

const etatDesass = { syntaxe: 'att', lignes: 200, symbole: '' };
let dernierDesass = null;

async function lancerDesassemblage() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier à désassembler.'); return; }
  binaire = cible;
  const resultat = refus(await appeler('desassembler', {
    chemin: cible, syntaxe: etatDesass.syntaxe, lignes: etatDesass.lignes,
    symbole: etatDesass.symbole || null,
  }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Désassemblage refusé', refusBloc(resultat || {})); return; }
  dernierDesass = resultat;
  rendre();
  ouvrirDesassemblage();
}

function ouvrirDesassemblage() {
  if (!dernierDesass) return;
  const texte = dernierDesass.texte || (dernierDesass.lignes || []).join('\n') || '';
  ouvrirFenetre('Désassemblage de ' + nomCourt(binaire), el('div', {},
    el('div', { class: 'ps-re-compte' },
      (dernierDesass.syntaxe_reelle || dernierDesass.syntaxe || etatDesass.syntaxe) +
      ' · ' + (dernierDesass.nombre_lignes || (texte ? texte.split('\n').length : 0)) + ' ligne(s)'),
    dernierDesass.substitution ? el('div', { class: 'ps-re-note' },
      'Substitution : ' + dernierDesass.substitution) : null,
    pre(texte || '(aucune instruction rendue)'),
    notes(dernierDesass),
    boutons([bouton('Copier', () => copier(texte)),
      bouton('Ouvrir comme fichier .s', () => ouvrirCommeAssembleur(texte))])));
}

/* Le désassemblage est du texte assembleur : le rendre dans l'éditeur avec le
 * langage `asm` de la 4.0.0 donne la coloration, l'aide et la complétion. Sans
 * cette passerelle, le résultat resterait du texte mort dans une fenêtre. */
/* Le seul canal vers l'éditeur est window.PSFMOpenTabs, exporté par le bundle.
 * Il n'existe AUCUNE action serveur pour créer un fichier : /api/re ne connaît
 * que les vingt entrées de la façade retro.py, et « creer » n'en fait pas
 * partie. L'appeler faisait répondre 400 « Action de rétro-ingénierie inconnue :
 * creer », rendu comme un échec du panneau — une impasse qui ressemble à un
 * bogue. Quand le pont est absent, on le DIT, avec le remède, et le texte reste
 * visible et copiable dans la fenêtre, qui n'est donc pas fermée. */
function ouvrirDansEditeur(nom, texte, langage) {
  if (window.PSFMOpenTabs && typeof window.PSFMOpenTabs === 'function') {
    try {
      window.PSFMOpenTabs([{ path: nom, content: texte, language: langage }]);
      fermerFenetre();
      erreur('');
      return true;
    } catch (exc) {
      erreur('L’éditeur a refusé l’ouverture de « ' + nom + ' » (' +
        ((exc && exc.message) || exc) + ') ; le texte reste copiable ' +
        'ci-dessous.');
      return false;
    }
  }
  erreur('Le pont vers l’éditeur (PSFMOpenTabs) est absent : « ' + nom +
    ' » ne peut pas être ouvert en onglet. Le texte reste copiable ci-dessous. ' +
    'Ouvrez le panneau depuis un projet chargé pour que le bundle expose ce ' +
    'pont.');
  return false;
}
function ouvrirCommeAssembleur(texte) {
  return ouvrirDansEditeur(nomCourt(binaire || 'binaire') + '.s', texte, 'asm');
}

/* ------------------------------------------------------------- 6. GHIDRA ---- */
function sectionGhidra() {
  const boite = el('div', {});
  const pret = capacites && capacites.pret_pour_ghidra;
  ajouter(boite, champChemin());

  if (!pret) {
    /* Le pont n'est pas prêt : la section reste ouverte et explique, au lieu de
     * disparaître. Une section absente laisse croire que la fonctionnalité
     * n'existe pas. */
    const ghidra = (capacites && capacites.ghidra) || {};
    ajouter(boite, el('div', { class: 'ps-re-bandeau ps-re-bandeau-absent' },
      el('strong', { text: 'Le pont Ghidra n’est pas prêt ici' }),
      el('span', { text: ghidra.raison || 'Raison inconnue.' })));
    ajouter(boite, el('div', { class: 'ps-re-note' },
      'Ouvrez la section Environnement : elle liste ce qui manque exactement ' +
      '(Ghidra, le JDK, le venv PyGhidra) et les commandes qui l’installent. ' +
      'En attendant, les sections Analyse, Symboles, Chaînes et Désassemblage ' +
      'fonctionnent sans Ghidra.'));
    ajouter(boite, boutons([
      bouton('Voir ce qui manque', () => basculerVers('environnement'), { primaire: true }),
      bouton('Voir le postScript', () => ouvrirPostScript()),
    ]));
    return boite;
  }

  const operations = (capacites && capacites.operations_detail) || {};
  const noms = (capacites && capacites.operations) || Object.keys(operations);
  ajouter(boite, el('div', { class: 'ps-re-ligne' },
    el('label', { class: 'ps-re-etiquette', text: 'Opération' }),
    el('select', {
      class: 'ps-re-saisie', onchange: ev => { etatGhidra.operation = ev.target.value; rendre(); },
    }, noms.map(nom => el('option', {
      value: nom, text: nom,
      selected: nom === etatGhidra.operation,
    }))),
    el('label', { class: 'ps-re-etiquette', text: 'Arguments' }),
    el('input', {
      class: 'ps-re-saisie', type: 'text', spellcheck: 'false',
      placeholder: 'main 60', value: etatGhidra.arguments,
      onchange: ev => { etatGhidra.arguments = ev.target.value; },
    })));
  const detail = operations[etatGhidra.operation] || {};
  if (detail.resume || detail.description) {
    ajouter(boite, el('div', { class: 'ps-re-note' },
      detail.resume || detail.description));
  }
  if (detail.arguments !== undefined) {
    ajouter(boite, el('div', { class: 'ps-re-compte' },
      'Arguments attendus : ' + JSON.stringify(detail.arguments)));
  }
  ajouter(boite, boutons([
    bouton('Lancer en arrière-plan', () => lancerGhidra(), { primaire: true }),
    bouton('Relire les tâches', () => relireTaches()),
  ]));
  ajouter(boite, rendreTaches());
  return boite;
}

function basculerVers(id) {
  ouvert[id] = true;
  rendre();
  const noeud = $('.ps-re-section-' + id, racine);
  if (noeud && noeud.scrollIntoView) noeud.scrollIntoView({ block: 'nearest' });
}

const etatGhidra = { operation: 'info', arguments: '' };

function rendreTaches() {
  if (!taches || !taches.length) {
    return el('div', { class: 'ps-re-vide' }, 'Aucune tâche Ghidra connue.');
  }
  return el('div', { class: 'ps-re-bloc' },
    el('h4', { text: 'Tâches (' + taches.length + ')' }),
    taches.map(t => el('div', { class: 'ps-re-tache ps-re-tache-' + (t.etat || 'inconnu') },
      el('div', { class: 'ps-re-tache-ligne' },
        el('strong', { text: t.operation || '?' }),
        el('code', { text: String(t.id || '').slice(0, 24) }),
        el('span', { class: 'ps-re-etat', text: t.etat || 'inconnu' })),
      el('div', { class: 'ps-re-tache-fichier', text: nomCourt(t.binaire || '') }),
      t.erreur ? el('div', { class: 'ps-re-erreur', text: String(t.erreur) }) : null,
      boutons([
        bouton('Résultat', () => lireResultat(t.id), { disabled: !(t.termine || t.etat === 'termine' || t.etat === 'fini') }),
        bouton('Arrêter', () => arreterTache(t.id), { disabled: !(t.etat === 'en_cours' || t.etat === 'lance') }),
      ]))));
}

async function lancerGhidra() {
  const cible = binaire || cheminCourant();
  if (!cible) { erreur('Aucun fichier à analyser avec Ghidra.'); return; }
  binaire = cible;
  // `arguments` est réservé en mode strict : le nommer ainsi est une erreur de
  // compilation, pas seulement une mauvaise habitude.
  const args = String(etatGhidra.arguments || '').split(/\s+/).filter(Boolean);
  const resultat = refus(await appeler('ghidra-lancer', {
    chemin: cible, operation: etatGhidra.operation, arguments: args,
  }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Lancement refusé', refusBloc(resultat || {})); return; }
  erreur('');
  await relireTaches();
}

async function relireTaches() {
  const resultat = await appeler('ghidra-taches');
  if (resultat && resultat.ok) { taches = resultat.taches || []; rendre(); }
  else erreur((resultat && resultat.erreur) || 'Les tâches n’ont pas pu être lues.');
}

async function arreterTache(id) {
  const resultat = refus(await appeler('ghidra-arreter', { identifiant: id }));
  if (!resultat || resultat.ok === false) { erreur((resultat && resultat.erreur) || 'Arrêt refusé.'); return; }
  erreur('');
  await relireTaches();
}

async function lireResultat(id) {
  const resultat = refus(await appeler('ghidra-resultat', { identifiant: id }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Résultat', refusBloc(resultat || {})); return; }
  const donnees = resultat.donnees;
  const contenu = el('div', {});
  if (resultat.tronque) {
    ajouter(contenu, el('div', { class: 'ps-re-note' },
      'La sortie était trop longue : seule la fin est rendue (' +
      (resultat.longueur_queue || 0) + ' derniers caractères).'));
  }
  if (resultat.note) ajouter(contenu, el('div', { class: 'ps-re-note' }, resultat.note));
  if (donnees && typeof donnees === 'object') {
    ajouter(contenu, rendreDonneesGhidra(donnees));
  } else {
    ajouter(contenu, pre(typeof donnees === 'string' ? donnees : JSON.stringify(donnees, null, 2)));
  }
  ajouter(contenu, notes(resultat));
  ouvrirFenetre('Résultat Ghidra — ' + (resultat.operation || id), contenu);
}

/* Les dix opérations ne rendent pas la même forme : un rendu unique en JSON
 * brut rendrait une liste de fonctions illisible. Chaque forme connue a son
 * rendu, et l'inconnu retombe sur le JSON. */
function rendreDonneesGhidra(donnees) {
  const boite = el('div', {});
  if (Array.isArray(donnees.functions) && donnees.functions.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Fonctions (' + donnees.functions.length + ')' }),
      tableau(donnees.functions.map(f => ({
        nom: f.nom || f.name, adresse: f.adresse || f.address,
        taille: f.taille || f.size, appels: f.appels || f.calls || '',
      })))));
  }
  if (donnees.decompilation || donnees.code) {
    const code = donnees.decompilation || donnees.code;
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Décompilation' }), pre(code),
      boutons([bouton('Copier', () => copier(code)),
        bouton('Ouvrir comme fichier .c', () => ouvrirCommeC(code))])));
  }
  if (Array.isArray(donnees.instructions) && donnees.instructions.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Instructions (' + donnees.instructions.length + ')' }),
      pre(donnees.instructions.map(i => (typeof i === 'string' ? i :
        (i.adresse || '') + '  ' + (i.mnemonique || i.texte || ''))).join('\n'))));
  }
  if (Array.isArray(donnees.xrefs) && donnees.xrefs.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Références croisées (' + donnees.xrefs.length + ')' }),
      tableau(donnees.xrefs.map(x => ({
        depuis: x.depuis || x.from, vers: x.vers || x.to, type: x.type || '',
      })))));
  }
  if (Array.isArray(donnees.chaines) && donnees.chaines.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Chaînes (' + donnees.chaines.length + ')' }),
      rendreChaines(donnees.chaines)));
  }
  if (Array.isArray(donnees.appels) && donnees.appels.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Appels (' + donnees.appels.length + ')' }),
      tableau(donnees.appels.map(a => (typeof a === 'string' ? { appel: a } : {
        fonction: a.fonction || a.nom, depuis: a.depuis || '', type: a.type || '',
      })))));
  }
  if (donnees.info && typeof donnees.info === 'object') {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Informations' }),
      tableau(Object.keys(donnees.info).map(c => ({ propriété: c, valeur: String(donnees.info[c]) })))));
  }
  /* `children` et pas `childNodes` : c'est la propriété que couvre le harnais
   * DOM des bancs, et ici on ne construit que des éléments — aucun nœud texte
   * n'est ajouté directement à cette boîte. */
  if (!(boite.children || []).length) {
    ajouter(boite, pre(JSON.stringify(donnees, null, 2)));
  }
  return boite;
}

function ouvrirCommeC(code) {
  return ouvrirDansEditeur(nomCourt(binaire || 'binaire') + '-decompile.c',
    code, 'c');
}

/* ------------------------------------------------------------- 7. WIDGETS --- */
function sectionWidgets() {
  const boite = el('div', {});
  const liste = (capacites && capacites.widgets) || [];
  if (!liste.length) {
    ajouter(boite, el('div', { class: 'ps-re-vide' },
      'Les widgets n’ont pas pu être listés. Relisez l’environnement.'));
    ajouter(boite, boutons([bouton('Relire', () => chargerCapacites(true), { primaire: true })]));
    return boite;
  }
  ajouter(boite, el('div', { class: 'ps-re-note' },
    'Les widgets ne lisent AUCUN fichier : ce sont des convertisseurs et des ' +
    'tables. Chaque exemple déclaré est vérifié par l’autocontrôle du module ' +
    'Python, donc ce que le widget annonce est ce qu’il rend.'));
  ajouter(boite, el('div', { class: 'ps-re-pastilles' }, liste.map(id =>
    bouton(id, () => ouvrirWidget(id), { title: 'Ouvrir le widget « ' + id + ' »' }))));
  if (widgetCourant) ajouter(boite, rendreWidgetCourant());
  return boite;
}

let widgetSpec = null;
let widgetResultat = null;

async function ouvrirWidget(id, texteInitial) {
  widgetCourant = id;
  widgetSpec = null;
  widgetResultat = null;
  if (!ouvert.widgets) { ouvert.widgets = true; }
  rendre();
  if (!catalogueWidgets) {
    const resultat = await appeler('widgets');
    if (resultat && resultat.ok && Array.isArray(resultat.widgets)) {
      catalogueWidgets = resultat.widgets;
    } else if (resultat && resultat.erreur) {
      /* Un catalogue illisible ne doit pas laisser un formulaire vide sans
       * explication : c'est le refus du serveur qu'il faut montrer. */
      erreur((resultat.erreur || 'Le catalogue des widgets est illisible.') +
        (resultat.remede ? ' ' + resultat.remede : ''));
      rendre();
      return;
    }
  }
  if (catalogueWidgets) {
    widgetSpec = catalogueWidgets.filter(w => w.id === id)[0] || null;
  }
  if (texteInitial && widgetSpec) {
    const premiere = (widgetSpec.entrees || [])[0];
    if (premiere) {
      entreesWidgets[id] = Object.assign({}, entreesWidgets[id]);
      entreesWidgets[id][premiere.nom] = texteInitial;
    }
  }
  rendre();
}

function rendreWidgetCourant() {
  const boite = el('div', { class: 'ps-re-widget' });
  if (!widgetSpec) {
    ajouter(boite, el('div', { class: 'ps-re-vide' },
      'La description du widget « ' + widgetCourant + ' » n’a pas pu être lue.'));
    return boite;
  }
  ajouter(boite, el('h4', { text: widgetSpec.nom || widgetCourant }));
  if (widgetSpec.resume) ajouter(boite, el('div', { class: 'ps-re-resume' }, widgetSpec.resume));
  const memoire = entreesWidgets[widgetCourant] || {};
  (widgetSpec.entrees || []).forEach(champ => {
    const valeur = memoire[champ.nom] !== undefined ? memoire[champ.nom] :
      (champ.defaut !== undefined ? champ.defaut : '');
    const ligne = el('div', { class: 'ps-re-ligne' },
      el('label', { class: 'ps-re-etiquette', text: champ.nom + (champ.unite ? ' (' + champ.unite + ')' : '') }));
    let saisie;
    if (champ.type === 'zone') {
      saisie = el('textarea', {
        class: 'ps-re-saisie ps-re-zone', rows: 4, spellcheck: 'false',
        placeholder: champ.aide || '', text: valeur === null || valeur === undefined ? '' : String(valeur),
        onchange: ev => memoriserEntree(champ.nom, ev.target.value),
      });
    } else if (champ.type === 'choix' && Array.isArray(champ.choix)) {
      saisie = el('select', {
        class: 'ps-re-saisie', onchange: ev => memoriserEntree(champ.nom, ev.target.value),
      }, champ.choix.map(c => {
        const valeurChoix = (c && typeof c === 'object') ? (c.valeur !== undefined ? c.valeur : c.id) : c;
        const libelle = (c && typeof c === 'object') ? (c.libelle || c.nom || valeurChoix) : c;
        return el('option', { value: valeurChoix, text: libelle, selected: String(valeurChoix) === String(valeur) });
      }));
    } else {
      saisie = el('input', {
        class: 'ps-re-saisie', type: champ.type === 'nombre' ? 'number' : 'text',
        spellcheck: 'false', placeholder: champ.aide || '',
        value: valeur === null || valeur === undefined ? '' : String(valeur),
        onchange: ev => memoriserEntree(champ.nom, ev.target.value),
      });
    }
    ajouter(ligne, saisie);
    ajouter(boite, ligne);
    if (champ.aide) ajouter(boite, el('div', { class: 'ps-re-aide', text: champ.aide }));
  });
  ajouter(boite, boutons([
    bouton('Exécuter', () => executerWidgetCourant(), { primaire: true }),
    bouton('Exemple vérifié', () => montrerExemple(), { disabled: !widgetSpec.exemple }),
    widgetResultat ? bouton('Ouvrir le résultat', () => ouvrirWidgetResultat()) : null,
  ]));
  if (widgetResultat) ajouter(boite, rendreWidgetResultat(widgetResultat));
  return boite;
}

function memoriserEntree(nom, valeur) {
  if (!widgetCourant) return;
  entreesWidgets[widgetCourant] = Object.assign({}, entreesWidgets[widgetCourant]);
  entreesWidgets[widgetCourant][nom] = valeur;
}

async function executerWidgetCourant() {
  if (!widgetCourant) return;
  const entrees = Object.assign({}, entreesWidgets[widgetCourant]);
  const resultat = refus(await appeler('widget', { identifiant: widgetCourant, entrees: entrees }));
  widgetResultat = resultat;
  if (!resultat || resultat.ok === false) {
    erreur((resultat && resultat.erreur) || 'Le widget a refusé.');
  } else erreur('');
  rendre();
}

function montrerExemple() {
  if (!widgetSpec || !widgetSpec.exemple) return;
  const exemple = widgetSpec.exemple;
  entreesWidgets[widgetCourant] = Object.assign({}, exemple.entrees || {});
  ouvrirFenetre('Exemple vérifié du widget « ' + widgetCourant + ' »', el('div', {},
    el('p', { class: 'ps-re-note' },
      'Cet exemple est EXÉCUTÉ par l’autocontrôle du module Python à chaque ' +
      'démarrage : si le widget cessait de rendre ce qui est annoncé ici, ' +
      'l’autocontrôle échouerait. Les entrées ont été reprises dans le ' +
      'formulaire.'),
    el('div', {}, el('strong', { text: 'Entrées : ' }),
      pre(JSON.stringify(exemple.entrees || {}, null, 2))),
    el('div', {}, el('strong', { text: 'Annoncé : ' }),
      pre(JSON.stringify(exemple.attendu || {}, null, 2))),
    boutons([bouton('Exécuter ces entrées', () => { fermerFenetre(); executerWidgetCourant(); },
      { primaire: true })])));
  rendre();
}

function rendreWidgetResultat(resultat) {
  const boite = el('div', { class: 'ps-re-bloc' });
  if (resultat.ok === false) { ajouter(boite, refusBloc(resultat)); return boite; }
  const donnees = resultat.resultat;
  if (donnees && typeof donnees === 'object') {
    if (donnees.source) {
      /* Un widget qui délègue à un autre module déclare sa source : c'est ce
       * qui rend visible un repli silencieux sur une table locale. */
      ajouter(boite, el('div', { class: 'ps-re-source' }, 'Source : ' + donnees.source));
    }
    const cles = Object.keys(donnees);
    const simples = cles.filter(c => {
      const v = donnees[c];
      return v === null || typeof v !== 'object';
    });
    if (simples.length) {
      ajouter(boite, tableau(simples.map(c => ({
        propriété: c, valeur: donnees[c] === null ? 'null' : String(donnees[c]),
      }))));
    }
    cles.filter(c => simples.indexOf(c) < 0).forEach(c => {
      ajouter(boite, el('div', { class: 'ps-re-bloc' },
        el('h4', { text: c }),
        Array.isArray(donnees[c]) && donnees[c].length && typeof donnees[c][0] === 'object' ?
          tableau(donnees[c]) : pre(JSON.stringify(donnees[c], null, 2))));
    });
  } else {
    ajouter(boite, pre(String(donnees)));
  }
  ajouter(boite, notes(resultat));
  return boite;
}

function ouvrirWidgetResultat() {
  if (!widgetResultat) return;
  ouvrirFenetre('Widget « ' + widgetCourant + ' »', rendreWidgetResultat(widgetResultat));
}

/* -------------------------------------------------------------- 8. FICHES --- */
function sectionFiches() {
  const boite = el('div', {});
  ajouter(boite, el('div', { class: 'ps-re-ligne' },
    el('input', {
      class: 'ps-re-saisie', type: 'text', placeholder: 'Chercher dans les fiches…',
      spellcheck: 'false', value: rechercheFiches,
      oninput: ev => { rechercheFiches = ev.target.value; retardRecherche(); },
    }),
    el('select', {
      class: 'ps-re-saisie ps-re-saisie-courte',
      onchange: ev => { categorieFiches = ev.target.value; chargerFiches(); },
    }, [el('option', { value: '', text: 'Toutes catégories', selected: !categorieFiches })]
      .concat((listeCategories || []).map(c => el('option', {
        value: c.id || c.categorie, text: (c.titre || c.id || c.categorie) +
          (c.nombre ? ' (' + c.nombre + ')' : ''),
        selected: (c.id || c.categorie) === categorieFiches,
      }))))));
  if (resultatRecherche) {
    ajouter(boite, el('div', { class: 'ps-re-compte' },
      resultatRecherche.nombre + ' résultat(s) pour « ' + rechercheFiches + ' »'));
  }
  ajouter(boite, el('div', { class: 'ps-re-pastilles' },
    (listeFiches || []).map(f => bouton(f.titre || f.id, () => ouvrirFiche(f.id),
      { title: f.resume || f.id }))));
  if (!(listeFiches || []).length) {
    ajouter(boite, el('div', { class: 'ps-re-vide' }, 'Aucune fiche à afficher.'));
  }
  ajouter(boite, el('div', { class: 'ps-re-note' },
    'Chaque fiche porte des FAITS vérifiés par l’autocontrôle du module : une ' +
    'affirmation fausse fait échouer le démarrage. C’est ce contrôle qui a ' +
    'contredit « 0x4160 contient DYNAMIC_BASE » — la valeur réellement ' +
    'protégée est 0x060b.'));
  return boite;
}

let listeFiches = [];
let listeCategories = [];
let resultatRecherche = null;
let retardFiches = null;

function retardRecherche() {
  clearTimeout(retardFiches);
  const motif = rechercheFiches.trim();
  if (!motif) { resultatRecherche = null; chargerFiches(); return; }
  retardFiches = setTimeout(async () => {
    const resultat = await appeler('chercher', { motif: motif });
    if (resultat && resultat.ok !== false) {
      resultatRecherche = resultat;
      listeFiches = resultat.fiches || resultat.resultats || [];
      rendre();
    } else erreur((resultat && resultat.erreur) || 'La recherche a échoué.');
  }, RETARD_RECHERCHE);
}

async function chargerFiches() {
  resultatRecherche = null;
  const resultat = await appeler('fiches', { categorie: categorieFiches || null });
  if (resultat && resultat.ok !== false) {
    listeFiches = resultat.fiches || resultat || [];
    if (!Array.isArray(listeFiches)) listeFiches = [];
  } else {
    listeFiches = [];
    erreur((resultat && resultat.erreur) || 'Les fiches n’ont pas pu être lues.');
  }
  if (!listeCategories.length) {
    const cats = await appeler('categories');
    if (cats && cats.ok !== false) listeCategories = cats.categories || [];
  }
  rendre();
}

async function ouvrirFiche(id) {
  if (!id) return;
  const resultat = refus(await appeler('fiche', { identifiant: id }));
  if (!resultat || resultat.ok === false) { ouvrirFenetre('Fiche', refusBloc(resultat || {})); return; }
  ficheCourante = resultat.fiche || resultat;
  ouvrirFenetre(ficheCourante.titre || id, rendreFiche(ficheCourante));
}

function rendreFiche(fiche) {
  const boite = el('div', { class: 'ps-re-fiche' });
  ajouter(boite, el('div', { class: 'ps-re-fiche-meta' },
    el('span', { class: 'ps-re-pastille', text: fiche.categorie || '' }),
    fiche.mots_cles && fiche.mots_cles.length ?
      el('span', { class: 'ps-re-mots', text: fiche.mots_cles.join(' · ') }) : null));
  if (fiche.resume) ajouter(boite, el('p', { class: 'ps-re-resume' }, fiche.resume));
  (fiche.sections || []).forEach(section => {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: section.titre || '' }),
      section.texte ? el('p', { text: section.texte }) : null,
      section.code ? pre(section.code) : null,
      section.liste ? el('ul', { class: 'ps-re-liste' },
        section.liste.map(item => el('li', { text: String(item) }))) : null));
  });
  /* Les faits sont montrés avec leur expression : ce sont des affirmations
   * VÉRIFIÉES, et montrer la vérification est ce qui les distingue d'une
   * opinion. */
  if (fiche.faits && fiche.faits.length) {
    ajouter(boite, el('details', { class: 'ps-re-voie' },
      el('summary', {}, el('strong', { text: 'Faits vérifiés (' + fiche.faits.length + ')' })),
      el('p', { class: 'ps-re-note' },
        'Chaque fait ci-dessous est évalué par l’autocontrôle du module Python ' +
        'et doit valoir vrai. Un fait devenu faux fait échouer le démarrage du ' +
        'module, donc cette liste ne peut pas dériver en silence.'),
      fiche.faits.map(f => el('div', { class: 'ps-re-fait' },
        el('div', { text: '✓ ' + (f[0] || '') }),
        el('code', { class: 'ps-re-fait-code', text: f[1] || '' })))));
  }
  if (fiche.outils && fiche.outils.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Outils' }),
      el('div', { class: 'ps-re-pastilles' }, fiche.outils.map(o =>
        el('code', { class: 'ps-re-pastille', text: String(o) })))));
  }
  if (fiche.liens && fiche.liens.length) {
    ajouter(boite, el('div', { class: 'ps-re-bloc' },
      el('h4', { text: 'Voir aussi' }),
      boutons(fiche.liens.map(l => bouton(l, () => ouvrirFiche(l))))));
  }
  return boite;
}

/* ------------------------------------------------------------- ATTACHE ------ */
function construire() {
  const conteneur = el('div', { class: 'ps-re' });
  const entete = el('div', { class: 'ps-re-entete' },
    el('div', { class: 'ps-re-entete-titre' }, svg('binaire'),
      el('span', { text: 'Rétro-ingénierie' })),
    el('div', { class: 'ps-re-entete-actions' },
      bouton('Actualiser', () => chargerCapacites(true), { title: 'Relire l’environnement et les capacités' }),
      bouton('Tout réduire', () => {
        ouvert = {};
        rendre();
      })));
  const barre = el('div', { class: 'ps-re-barre', role: 'tablist' });
  const corps = el('div', { class: 'ps-re-corps' });
  const etat = el('div', { class: 'ps-re-etat' });
  ajouter(conteneur, entete, barre, corps, etat);
  return conteneur;
}

let observateurHote = null;

/* encoreAttache(noeud) — `Node.contains` n'existe pas dans tous les
 * environnements où ce script est chargé (le harnais DOM des bancs, un
 * conteneur sandboxé). `isConnected` est la propriété standard et elle est
 * disponible partout ici ; c'est aussi ce qu'utilise devweb-studio.js, donc les
 * deux panneaux se comportent de la même façon. */
/* ------------------------------------------------------- vue plein écran --
 * Trois fonctions, et une seule règle : si window.PSVues manque, on rend
 * `false` et le panneau reprend sa place dans la barre latérale. */
function racineAttachee() {
  if (!racine) return false;
  if (typeof racine.isConnected === 'boolean') return racine.isConnected;
  return !!racine.parentNode;
}

function ouvrirVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    return window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud,
      surFermeture: function () { racine = null; }
    }) === true;
  } catch (exc) {
    return false;
  }
}

function fermerVue() {
  if (!window.PSVues || typeof window.PSVues.fermer !== 'function') return;
  try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
}

/* Le quai : la barre latérale ne reste jamais vide ni muette. */
function rendreQuai(cible) {
  if (!cible) return;
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return;
  vider(cible);
  const disposition = (typeof window.PSVues.disposition === 'function')
    ? window.PSVues.disposition() : { mode: 'plein', colonnes: [] };
  const partage = disposition.mode === 'partage';
  const quai = el('div', { class: 'ps-vues-quai' },
    el('p', { class: 'ps-vues-quai-titre', text: 'Rétro-ingénierie' }),
    el('p', { class: 'ps-vues-quai-texte',
      text: 'Le panneau est affiché devant les fichiers ouverts.' }),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'mode' }),
      el('b', { text: partage ? 'côte à côte' : 'plein écran' })),
    boutonQuai('Replier le panneau', 'replier', function () { fermerVue(); }),
    boutonQuai(partage ? 'Passer en plein écran' : 'Garder l’éditeur à gauche',
      'basculer', function () {
        if (typeof window.PSVues.mode === 'function') {
          window.PSVues.mode(partage ? 'plein' : 'partage');
        }
        rendreQuai($(HOTE));
      }));
  cible.appendChild(quai);
}

function boutonQuai(texte, acte, rappel) {
  const b = el('button', { type: 'button', 'data-acte': acte, title: texte });
  b.textContent = texte;
  b.addEventListener('click', function (evt) {
    if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
    try { rappel(); } catch (exc) { statut && statut(String(exc), 'erreur'); }
  });
  return b;
}

function encoreAttache(noeud) {
  if (!noeud) return false;
  if (typeof noeud.isConnected === 'boolean') return noeud.isConnected;
  if (document.body && typeof document.body.contains === 'function') {
    return document.body.contains(noeud);
  }
  return false;
}

function contient(parent, enfant) {
  if (!parent || !enfant) return false;
  if (typeof parent.contains === 'function') return parent.contains(enfant);
  let noeud = enfant;
  while (noeud) {
    if (noeud === parent) return true;
    noeud = noeud.parent || noeud.parentNode || null;
  }
  return false;
}

function attach() {
  const cible = $(HOTE);
  if (!cible) {
    /* L'hôte n'existe que quand la vue est active : c'est le mécanisme par
     * lequel le bundle délègue. Son absence n'est donc pas une erreur. */
    if (hote && !encoreAttache(hote)) {
      hote = null; racine = null;
      /* Le bouton de la barre d'activité a été désactivé : la vue suit. Sans
       * cet appel, le panneau resterait affiché devant les fichiers alors que
       * l'utilisateur vient de le refermer. */
      fermerVue();
    }
    return;
  }
  /* Avec une vue, la racine n'est plus dans l'hôte latéral : sans le second
   * membre, ce garde ne se déclencherait jamais et le panneau serait reconstruit
   * à chaque passage de l'observateur, en perdant son état. */
  if (cible === hote && racine && (contient(cible, racine) || racineAttachee())) {
    /* L'hôte latéral a pu être recréé par React : le quai, lui, doit suivre. */
    rendreQuai(cible);
    return;
  }
  hote = cible;
  vider(hote);
  racine = construire();
  if (ouvrirVue(racine)) rendreQuai(hote);
  else hote.appendChild(racine);
  /* Un script hôte qui écrit dans le DOM doit être idempotent et écarter ses
   * propres enregistrements : sinon l'observateur se réveille sur ses propres
   * modifications et la boucle ne s'arrête plus. */
  if (observateurHote) observateurHote.disconnect();
  if (!capacites) chargerCapacites(false);
  else rendre();
  if (!listeFiches.length) chargerFiches();
  const prises = (observateurHote && observateurHote.takeRecords) ?
    observateurHote.takeRecords() : [];
  if (prises && prises.length) { /* écartées volontairement */ }
  rendre();
}

/* Un seul observateur pour toute l'application, via ps-hotes.js. Cinq
 * observateurs sur document.documentElement plus cinq sondes à 2 s
 * saturaient le fil principal : chaque mutation du DOM — une frappe dans
 * Monaco, une ligne de terminal, un diagnostic — réveillait les cinq, et un
 * bouton latéral mettait plusieurs secondes à changer l'affichage. Le repli
 * ci-dessous sert aux bancs, qui jouent ce script seul, sans PSHotes. */
function suivreHote(selecteur, rappel) {
  /* L'objet rendu a les deux méthodes d'un MutationObserver : les scripts
   * existants appellent .disconnect() pour écarter leurs propres écritures
   * et .takeRecords() quand il existe. Rendre une simple fonction d'arrêt
   * casserait ces appels — c'est ce qu'a fait la première version. */
  const arret = { disconnect: function () {},
    takeRecords: function () { return []; } };
  if (window.PSHotes && window.PSHotes.suivre) {
    arret.disconnect = window.PSHotes.suivre(selecteur, rappel);
    return arret;
  }
  if (typeof MutationObserver !== 'function') {
    if (typeof setInterval === 'function') {
      const sonde = setInterval(rappel, 5000);
      arret.disconnect = function () { clearInterval(sonde); };
    }
    return arret;
  }
  const observateur = new MutationObserver(rappel);
  observateur.observe(document.documentElement,
    { subtree: true, childList: true });
  const filet = typeof setInterval === 'function'
    ? setInterval(rappel, 5000) : null;
  arret.disconnect = function () {
    observateur.disconnect();
    if (filet) clearInterval(filet);
  };
  return arret;
}
function demarrerObservateur() {
  if (observateurHote) return;
  observateurHote = suivreHote('.ps-re-host', attach);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', attach, { once: true });
} else attach();
demarrerObservateur();
if (!window.PSHotes) setInterval(attach, 5000);
})();
