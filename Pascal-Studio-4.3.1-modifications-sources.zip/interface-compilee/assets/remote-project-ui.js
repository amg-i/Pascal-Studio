/* État de la copie locale et résolution prudente des conflits. */
(()=>{
'use strict';
async function api(path,data){let r=await fetch('/api/remote-project/'+path,data===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}),j=await r.json();if(!r.ok)throw Error(j.error||'Erreur de synchronisation');return j}
const E=(tag,text)=>{let e=document.createElement(tag);if(text)e.textContent=text;return e};
const B=(text,fn)=>{let b=E('button',text);b.onclick=()=>Promise.resolve(fn()).catch(e=>alert(e.message));return b};
let state={phase:'aucun'},busy=false,pill=E('button');pill.id='ps-remote-indicator';pill.style.display='none';document.body.append(pill);pill.onclick=()=>details();
const opened=()=>window.PSFMOpenTabs?.()||[];
async function poll(){if(busy)return;busy=true;try{state=await api('status');let labels={attente:'Projet distant : en attente',synchronisation:'Projet distant : synchronisation…',synchronise:'Projet distant : synchronisé',conflit:'Projet distant : conflits',erreur:'Projet distant : erreur', 'hors-ligne':'Projet distant : hors ligne'};pill.style.display=labels[state.phase]?'block':'none';pill.textContent=labels[state.phase]||'';pill.dataset.phase=state.phase;pill.title=state.error||'Cliquer pour voir les détails';}catch(e){pill.style.display='block';pill.textContent='Projet distant : état indisponible';pill.dataset.phase='erreur'}finally{busy=false}}
async function refresh(){if(window.PSSaveAll&&!await window.PSSaveAll())throw Error('Enregistrement local impossible.');await api('refresh',{opened:opened()});await poll()}
function details(){let shade=E('div');shade.className='psrp-overlay';let box=E('div');box.className='psrp-dialog';box.append(E('h3','Projet distant'),E('p','État : '+state.phase),E('p','Copie locale : '+(state.workspace||'')));
 if(state.remote)box.append(E('p','Dossier serveur : '+state.remote));if(state.last_sync)box.append(E('p','Dernière vérification : '+new Date(state.last_sync*1000).toLocaleString()));
 if(state.error)box.append(E('p',state.error));
 if(state.phase==='hors-ligne')box.append(E('p','La copie reste sur votre PC. Dans le gestionnaire, reconnectez-vous et ouvrez à nouveau le même dossier distant comme projet.'));
 let conflicts=state.conflicts||[];
 if(conflicts.length){box.append(E('h4',conflicts.length+' conflit(s) — aucune version écrasée automatiquement'));for(let c of conflicts){let item=E('div');item.className='psrp-conflict';item.append(E('strong',c.path),E('p',c.reason));
  for(let [label,choice] of [['Garder la version locale','local'],['Garder la version serveur','server']])item.append(B(label,async()=>{if(!confirm('Une copie de l’autre version sera conservée sur le PC et sur le serveur. Continuer ?'))return;if(window.PSSaveAll&&!await window.PSSaveAll())throw Error('Enregistrement local impossible.');let r=await api('resolve',{path:c.path,choice,opened:opened()});alert('Choix appliqué. Autre version conservée : '+r.backup);shade.remove();await poll()}));box.append(item)}
  box.append(E('p','Pour une suppression ou un déplacement, conservez ou restaurez le fichier manuellement dans le gestionnaire. Pour garder la version serveur, fermez d’abord son onglet. Les conflits internes à .git doivent être résolus avec Git.'))}
 if(state.phase!=='hors-ligne')box.append(B('Enregistrer et synchroniser',async()=>{shade.remove();await refresh()}));box.append(B('Fermer',()=>shade.remove()));shade.append(box);document.body.append(shade)}
 window.PSRemoteBeforeClose=async()=>{
  await poll();if(state.phase==='aucun')return true;
  if(state.phase==='hors-ligne')return confirm('Le projet distant est hors ligne. Les fichiers enregistrés restent sur le PC, sans être envoyés au serveur. Fermer quand même ?');
  try{let requested=await api('refresh',{opened:opened()});for(let i=0;i<15;i++){await new Promise(r=>setTimeout(r,400));await poll();if(state.cycle>requested.cycle&&state.phase==='synchronise')return true;if(['erreur','conflit'].includes(state.phase))break}}
  catch(e){}
  return confirm('La synchronisation distante n’est pas terminée ou présente un conflit. Les fichiers enregistrés restent sur le PC. Fermer quand même ?')
 };
 setInterval(poll,2500);poll();
})();
