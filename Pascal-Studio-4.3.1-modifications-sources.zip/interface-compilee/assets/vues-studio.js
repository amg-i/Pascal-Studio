/* Vues déléguées de Pascal Studio (4.3.0) : onglets dans la barre, plein
 * écran devant les fichiers, et splittage.
 *
 * POURQUOI CE FICHIER EXISTE
 *   Jusqu'ici, les panneaux ajoutés par Pascal Studio vivaient soit dans la
 *   barre latérale de 238 pixels (rétro-ingénierie, dev web), soit dans une
 *   fenêtre flottante par-dessus le reste (navigateur). Le signal était net :
 *   « que l'onglet rétro-ingénierie ne soit pas juste un bandeau mais quelque
 *   chose qui passe devant les fichiers ouverts », et « le navigateur doit
 *   s'ouvrir comme un onglet, plus comme une fenêtre ».
 *
 *   Ce fichier est le mécanisme commun. Le bundle pose un élément vide,
 *   `.ps-onglets-host`, DANS sa barre d'onglets (patch_interface_4.3.py) : les
 *   vignettes que ce script y rend portent la classe `tab` du bundle, donc elles
 *   ressemblent aux onglets de fichiers et vivent à côté d'eux. La vue elle-même
 *   s'affiche dans une zone qui couvre la zone d'édition.
 *
 * LE SPLITTING, ET SA LIMITE HONNÊTE
 *   La zone peut afficher plusieurs vues CÔTE À CÔTE, avec des séparateurs
 *   déplaçables : c'est le splittage demandé pour tout ce qui s'ouvre dans ces
 *   onglets (navigateur, images, Piet, rétro-ingénierie, dev web, données).
 *   Elle peut aussi ne prendre qu'une partie de la largeur et laisser l'éditeur
 *   visible à gauche. Cela fonctionne avec Monaco parce que le bundle crée
 *   l'éditeur avec `automaticLayout:!0` : quand la largeur de son conteneur
 *   change, Monaco se redessine seul. Ce script ne touche donc jamais à
 *   l'éditeur — il change la largeur de son conteneur, ce qui est la seule
 *   prise sûre sur un bundle minifié.
 *   En revanche, scinder DEUX FICHIERS DE CODE l'un à côté de l'autre reste
 *   impossible sans une seconde instance de Monaco, que seul le bundle sait
 *   créer : ce point est dit dans le guide plutôt que simulé.
 *
 * CE QUI EST GARANTI, ET POURQUOI
 *   - La barre d'onglets et la barre d'activité restent cliQUABLES. Une vue
 *     pleine qui les couvrirait empêcherait de la refermer : l'utilisateur
 *     serait piégé. La zone est donc décalée SOUS la barre d'onglets et le fil
 *     d'Ariane, hauteur MESURÉE au rendu et jamais devinée en pixels.
 *   - La barre latérale est masquée en mode plein, mais la BARRE D'ACTIVITÉ ne
 *     l'est jamais : c'est elle qui porte le bouton qui referme le panneau.
 *   - Cliquer sur un onglet de FICHIER rend la main à l'éditeur en mode plein :
 *     la vue est masquée, pas détruite. En mode partagé elle reste visible,
 *     puisque c'est précisément ce que l'utilisateur a demandé.
 *   - Les noeuds des vues inactives restent attachés et masqués. Un <webview>
 *     détaché du DOM est détruit par Electron : « économiser » en détachant
 *     ferait perdre la page en cours.
 *   - Un seul observateur, via ps-hotes.js : ce script n'est pas une exception à
 *     la règle posée en 4.2.0 après que cinq observateurs eurent ralenti toute
 *     l'application.
 *
 * Aucune ressource externe.
 */
(() => {
'use strict';

const MARQUEUR = 'ps-4.3.0-vues';
const HOTE = '.ps-onglets-host';
const PRINCIPAL = '.studio-main';
const BARRE = '.tabbar';
const ARIANE = '.breadcrumb';
const LATÉRALE = '.sidebar';
const CLASSE_RACINE = 'ps-vues-actif';
const CLASSE_PARTAGE = 'ps-vues-partage';
const CLASSE_LATÉRALE = 'ps-vues-latérale-masquée';

const $ = (sel, base) => (base || document).querySelector(sel);
const nombre = (v, plancher, plafond, repli) => {
  const n = typeof v === 'number' ? v : parseFloat(v);
  if (!isFinite(n)) return repli;
  return Math.min(plafond, Math.max(plancher, n));
};

function contient(parent, enfant) {
  if (parent && typeof parent.contains === 'function') {
    try { return parent.contains(enfant); } catch (exc) { /* repli */ }
  }
  let noeud = enfant;
  while (noeud) { if (noeud === parent) return true; noeud = noeud.parentNode; }
  return false;
}

function detacher(noeud) {
  if (!noeud) return;
  const parent = noeud.parentNode;
  if (parent && typeof parent.removeChild === 'function') {
    try { parent.removeChild(noeud); return; } catch (exc) { /* repli */ }
  }
  if (typeof noeud.remove === 'function') { try { noeud.remove(); } catch (e) {} }
}

function vider(noeud) {
  if (!noeud) return;
  if (typeof noeud.replaceChildren === 'function') {
    try { noeud.replaceChildren(); return; } catch (exc) { /* repli */ }
  }
  while (noeud.firstChild) detacher(noeud.firstChild);
}

function el(nom, attributs) {
  const noeud = document.createElement(nom);
  const reste = Array.prototype.slice.call(arguments, 2);
  if (attributs) {
    Object.keys(attributs).forEach(function (cle) {
      const valeur = attributs[cle];
      if (valeur === null || valeur === undefined || valeur === false) return;
      if (cle === 'class') noeud.className = String(valeur);
      else if (cle === 'texte') noeud.textContent = String(valeur);
      else if (cle === 'html') noeud.innerHTML = String(valeur);
      else if (cle.slice(0, 2) === 'on' && typeof valeur === 'function') {
        noeud.addEventListener(cle.slice(2), valeur);
      } else noeud.setAttribute(cle, String(valeur));
    });
  }
  reste.forEach(function (enfant) {
    if (enfant === null || enfant === undefined || enfant === false) return;
    noeud.appendChild(typeof enfant === 'object' ? enfant
      : document.createTextNode(String(enfant)));
  });
  return noeud;
}

/* ------------------------------------------------------------------ l'état -- */

let vues = [];        /* { id, titre, icone, noeud, fermable, surFermeture } */
let colonnes = [];    /* [{ id, largeur }] ; id = identifiant de la vue affichée */
let active = null;    /* vue au premier plan */
let mode = 'plein';   /* 'plein' = devant les fichiers ; 'partage' = à côté */
let zone = null;
let hote = null;
let barre = null;
let entrainDeGlisser = false;
let partageLargeur = 55;   /* % pris par la zone en mode 'partage' */
/* 4.3.1 : l'affichage suit l'INTENTION de l'utilisateur, pas l'état brut de la
 * barre d'onglets. `masqueeSurFichier` est le verrou posé par un changement
 * d'onglet de FICHIER ; `cleFichierVue` est la clé du dernier onglet de fichier
 * vu au premier plan, pour ne pas confondre un vrai changement de fichier avec
 * un simple rafraîchissement de la barre par React. */
let masqueeSurFichier = false;
let cleFichierVue = null;

const LARGEUR_MIN = 12;   /* % : en dessous, une colonne devient inutilisable */
const LARGEUR_MAX = 92;   /* % : laisser toujours un peu d'éditeur visible */

function vue(id) {
  return vues.filter(function (v) { return v.id === String(id); })[0] || null;
}
function colonne(id) {
  return colonnes.filter(function (c) { return c.id === String(id); })[0] || null;
}

function principales() { return $(PRINCIPAL); }

function decalageHaut() {
  /* Mesuré, jamais deviné : la hauteur de la barre d'onglets et du fil d'Ariane
   * dépend de la police, du zoom et de la présence d'un second rang d'onglets. */
  const racine = principales();
  if (!racine) return 0;
  let haut = 0;
  [BARRE, ARIANE].forEach(function (sel) {
    const noeud = $(sel, racine);
    if (noeud && typeof noeud.offsetHeight === 'number') haut += noeud.offsetHeight;
  });
  return haut;
}

function assurerZone() {
  const racine = principales();
  if (!racine) return null;
  if (zone && contient(racine, zone)) return zone;
  zone = el('div', { class: 'ps-vues-zone', 'data-marqueur': MARQUEUR,
    'data-mode': mode });
  try { racine.appendChild(zone); } catch (exc) { zone = null; return null; }
  return zone;
}

/* ------------------------------------------------------------ les colonnes -- */

function normaliserLargeurs() {
  if (!colonnes.length) return;
  const total = colonnes.reduce(function (s, c) { return s + (c.largeur || 0); }, 0);
  if (Math.abs(total - 100) < 0.5) return;
  const part = 100 / colonnes.length;
  colonnes.forEach(function (c) { c.largeur = part; });
}

/* ps-hotes.js observe document.body en childList+subtree et regroupe ses rappels
 * sur une image. Son contrat est écrit dans son en-tête : un rappel doit être
 * idempotent et revenir immédiatement s'il n'y a rien à faire, sinon le rendu
 * produit des mutations qui réveillent l'observateur qui rappelle le rendu. La
 * 4.3.0 vidait la zone et recréait chaque colonne à chaque passage — 24 éléments
 * par passage, indéfiniment, dès qu'une vue était ouverte. Le <webview> du
 * navigateur était détaché puis rattaché à chaque image, ce qu'Electron traduit
 * par un rechargement permanent, et le curseur était recalculé sur des noeuds
 * déjà remplacés. Le rendu est donc RÉCONCILIÉ : ce qui est en place est
 * réutilisé, et rien n'est écrit quand rien n'a changé (4.3.1). */
let compteurNoeuds = 0;
let signatureRendu = '';
let signatureOnglets = '';
let rendu = null;

function identite(noeud) {
  if (!noeud) return '-';
  if (!noeud.__psVuesId) {
    compteurNoeuds += 1;
    noeud.__psVuesId = compteurNoeuds;
  }
  return String(noeud.__psVuesId);
}

function enfantsDe(noeud) {
  if (!noeud || !noeud.children) return [];
  return Array.prototype.slice.call(noeud.children);
}

/* Déplacer un noeud seulement s'il n'est pas déjà à sa place : un noeud déplacé
 * dans le DOM est un <webview> rechargé par Electron. */
function placer(noeud, parent) {
  if (!noeud || !parent) return;
  if (noeud.parentNode === parent) return;
  if (noeud.parentNode) detacher(noeud);
  parent.appendChild(noeud);
}

/* Tout ce qui joue sur le rendu des colonnes, y compris l'identité du noeud
 * confié par le panneau : un panneau reconstruit par son propre script doit
 * être repris même si l'identifiant de la vue n'a pas changé. */
function signatureColonnes() {
  const parts = ['a=' + (active || ''), 'n=' + colonnes.length];
  colonnes.forEach(function (c) {
    const v = vue(c.id);
    parts.push('c=' + c.id + ':' + nombre(c.largeur, LARGEUR_MIN, 100, 50)
      + ':' + (active === c.id ? 1 : 0)
      + ':' + (v ? v.titre : c.id) + ':' + (v ? v.icone : '◆')
      + ':' + (v && v.fermable === false ? 0 : 1)
      + ':' + identite(v && v.noeud));
  });
  vues.forEach(function (v) {
    if (v.noeud && !colonne(v.id)) {
      parts.push('h=' + v.id + ':' + identite(v.noeud));
    }
  });
  return parts.join('#');
}

/* La signature peut être juste et le DOM ne plus l'être : React remonte des
 * sous-arbres entiers, et la zone peut avoir été vidée sans qu'aucun état ait
 * changé. On revérifie donc ce qui est réellement attaché. */
function renduIntacte(conteneur) {
  if (!rendu) return false;
  const enfants = enfantsDe(conteneur);
  if (enfants.length !== rendu.enfants.length) return false;
  for (let i = 0; i < enfants.length; i += 1) {
    if (enfants[i] !== rendu.enfants[i]) return false;
  }
  const ids = Object.keys(rendu.colonnes);
  for (let i = 0; i < ids.length; i += 1) {
    const colonneEl = rendu.colonnes[ids[i]];
    const corps = colonneEl && colonneEl.__psCorps;
    const attendu = rendu.corps[ids[i]];
    if (attendu && (!corps || corps.firstChild !== attendu)) return false;
    if (!attendu && corps && corps.firstChild) return false;
  }
  return true;
}

function majEntete(entete, c, v) {
  const signature = [v ? v.titre : c.id, v ? v.icone : '◆',
    colonnes.length > 1 ? 1 : 0,
    v && v.fermable === false ? 0 : 1].join('|');
  if (entete.__psSignature === signature) return;
  entete.__psSignature = signature;
  const enfants = [
    el('span', { class: 'ps-vues-entete-icone', texte: v ? v.icone : '◆' }),
    el('b', { class: 'ps-vues-entete-titre', texte: v ? v.titre : c.id }),
    colonnes.length > 1 ? el('button', { class: 'ps-vues-mini', type: 'button',
      'data-fusion': c.id,
      title: 'Refermer cette colonne et garder sa vue en vignette',
      texte: '⤡' }) : null,
    el('button', { class: 'ps-vues-mini', type: 'button', 'data-scinder': c.id,
      title: 'Ouvrir une colonne à droite de celle-ci', texte: '⧉' }),
    v && v.fermable === false ? null : el('button', {
      class: 'ps-vues-mini ps-vues-x', type: 'button', 'data-fermer': c.id,
      title: 'Fermer ' + (v ? v.titre : c.id),
      'aria-label': 'Fermer ' + (v ? v.titre : c.id), texte: '×' }),
  ].filter(function (n) { return !!n; });
  /* replaceChildren sur L'ENTÊTE seulement. Le corps de la colonne, qui porte le
   * noeud du panneau, n'est jamais retiré : dans un vrai navigateur, retirer
   * puis réinsérer un élément recharge le <webview> qu'il contient. Et les
   * valeurs nulles sont filtrées : replaceChildren(null) insérerait le texte
   * « null ». */
  entete.replaceChildren.apply(entete, enfants);
}

function construireColonne(c, v) {
  const entete = el('div', { class: 'ps-vues-entete' });
  const corps = el('div', { class: 'ps-vues-corps' });
  const colonneEl = el('div', { class: 'ps-vues-colonne', 'data-colonne': c.id },
    entete, corps);
  colonneEl.__psCorps = corps;
  majEntete(entete, c, v);
  return colonneEl;
}

function majColonne(colonneEl, c, v) {
  const avant = active === c.id ? 'true' : 'false';
  if (colonneEl.getAttribute('data-avant') !== avant) {
    colonneEl.setAttribute('data-avant', avant);
  }
  const base = 'calc(' + nombre(c.largeur, LARGEUR_MIN, 100, 50) + '% - 4px)';
  if (colonneEl.style.flexBasis !== base) colonneEl.style.flexBasis = base;
  const entete = colonneEl.querySelector('.ps-vues-entete');
  if (entete) majEntete(entete, c, v);
  const corps = colonneEl.__psCorps;
  if (!corps) return;
  const noeud = v && v.noeud ? v.noeud : null;
  if (corps.firstChild !== noeud) {
    if (corps.firstChild) vider(corps);
    if (noeud) placer(noeud, corps);
  }
  if (!noeud) return;
  /* Le noeud peut revenir d'une période masquée (vue refermée puis rouverte) :
   * son display:none en ligne survivrait à l'attachement et la colonne
   * s'afficherait vide. Le remettre à '' rend la main à la feuille de style. */
  if (noeud.style.display !== '') noeud.style.display = '';
  if (noeud.classList && noeud.classList.contains('ps-vues-contenu')) {
    noeud.classList.remove('ps-vues-contenu');
  }
}

/* Remettre les enfants directs de la zone dans l'ordre voulu, sans toucher à ce
 * qui y est déjà. */
function aligner(conteneur, voulus) {
  const actuels = enfantsDe(conteneur);
  let identique = actuels.length === voulus.length;
  if (identique) {
    for (let i = 0; i < voulus.length; i += 1) {
      if (actuels[i] !== voulus[i]) { identique = false; break; }
    }
  }
  if (identique) return;
  actuels.forEach(function (n) { if (voulus.indexOf(n) < 0) detacher(n); });
  if (typeof conteneur.replaceChildren === 'function') {
    conteneur.replaceChildren.apply(conteneur, voulus);
  } else {
    vider(conteneur);
    voulus.forEach(function (n) { placer(n, conteneur); });
  }
}

function rendreColonnes() {
  const conteneur = assurerZone();
  if (!conteneur) return;
  const attendue = signatureColonnes();
  if (attendue === signatureRendu && renduIntacte(conteneur)) return;

  const existants = {};
  const seps = [];
  enfantsDe(conteneur).forEach(function (n) {
    if (!n.getAttribute) return;
    const id = n.getAttribute('data-colonne');
    if (id) existants[id] = n;
    if (n.getAttribute('data-sep') !== null) seps.push(n);
  });

  const voulus = [];
  const colonnesRendues = {};
  const corpsRendus = {};
  colonnes.forEach(function (c, index) {
    if (index > 0) {
      /* Le séparateur appartient à la colonne de DROITE : glisser vers la gauche
       * agrandit la colonne précédente. Il est réutilisé d'un passage à l'autre,
       * et son écoute de pointerdown reste posée à la création : un écouteur
       * posé sur un noeud remplacé ne serait jamais joué. */
      let sep = seps[index - 1] || null;
      if (!sep) {
        sep = el('div', { class: 'ps-vues-sep', role: 'separator',
          title: 'Glisser pour répartir la largeur' });
        sep.addEventListener('pointerdown', surSeparateur);
      }
      if (sep.getAttribute('data-sep') !== String(index)) {
        sep.setAttribute('data-sep', String(index));
      }
      voulus.push(sep);
    }
    const v = vue(c.id);
    let colonneEl = existants[c.id] || null;
    if (colonneEl && !colonneEl.__psCorps) colonneEl = null;
    if (!colonneEl) colonneEl = construireColonne(c, v);
    majColonne(colonneEl, c, v);
    colonnesRendues[c.id] = colonneEl;
    corpsRendus[c.id] = v && v.noeud ? v.noeud : null;
    voulus.push(colonneEl);
  });
  /* Les noeuds des vues qui ne sont dans AUCUNE colonne restent attachés à la
   * zone, masqués : les détacher détruirait un <webview> en cours de navigation. */
  vues.forEach(function (v) {
    if (!v.noeud || colonne(v.id)) return;
    placer(v.noeud, conteneur);
    if (v.noeud.classList && !v.noeud.classList.contains('ps-vues-contenu')) {
      v.noeud.classList.add('ps-vues-contenu');
    }
    if (v.noeud.style.display !== 'none') v.noeud.style.display = 'none';
    voulus.push(v.noeud);
  });
  aligner(conteneur, voulus);
  signatureRendu = attendue;
  rendu = { signature: attendue, enfants: voulus.slice(),
    colonnes: colonnesRendues, corps: corpsRendus };
}

function appliquerRacine() {
  const racine = principales();
  const conteneur = assurerZone();
  if (!racine || !conteneur) return;
  const ouverte = !!active;
  conteneur.setAttribute('data-mode', mode);
  conteneur.setAttribute('data-active', active || '');
  conteneur.setAttribute('data-colonnes', String(colonnes.length));
  conteneur.style.top = decalageHaut() + 'px';
  if (!ouverte) {
    conteneur.style.display = 'none';
    conteneur.style.left = '0';
    conteneur.style.right = '0';
  } else if (mode === 'partage') {
    const largeur = nombre(partageLargeur, LARGEUR_MIN, LARGEUR_MAX, 55);
    conteneur.style.display = 'block';
    conteneur.style.left = (100 - largeur) + '%';
    conteneur.style.right = '0';
  } else {
    conteneur.style.display = 'block';
    conteneur.style.left = '0';
    conteneur.style.right = '0';
  }
  if (racine.classList) {
    if (ouverte) racine.classList.add(CLASSE_RACINE);
    else racine.classList.remove(CLASSE_RACINE);
    /* En mode partagé, l'éditeur doit rétrécir pour que Monaco se redessine
     * (automaticLayout) au lieu de passer sous le panneau. */
    if (ouverte && mode === 'partage') racine.classList.add(CLASSE_PARTAGE);
    else racine.classList.remove(CLASSE_PARTAGE);
    racine.setAttribute('data-ps-vues-largeur',
      String(nombre(partageLargeur, LARGEUR_MIN, LARGEUR_MAX, 55)));
  }
  /* La barre latérale est masquée en mode plein — mais JAMAIS la barre
   * d'activité : c'est elle qui porte le bouton qui referme le panneau. */
  const laterale = $(LATÉRALE);
  if (laterale && laterale.classList) {
    if (ouverte && mode === 'plein') laterale.classList.add(CLASSE_LATÉRALE);
    else laterale.classList.remove(CLASSE_LATÉRALE);
  }
}

/* --------------------------------------------------------------- les onglets -- */

function rendreOnglets() {
  if (!hote || !contient(document.documentElement, hote)) return;
  /* La barre de vignettes n'est reconstruite que si une vignette a vraiment
   * changé. La reconstruire à chaque passage faisait disparaître le noeud sous
   * le curseur au moment du clic : c'est « une fois fermé, on ne peut plus le
   * rouvrir ». */
  const attendue = signatureVignettes();
  if (attendue === signatureOnglets && enfantsDe(hote).length === vues.length) {
    return;
  }
  signatureOnglets = attendue;
  vider(hote);
  vues.forEach(function (v) {
    const dansUneColonne = !!colonne(v.id);
    const onglet = el('div', {
      class: 'tab ps-vue-onglet'
        + (active === v.id && dansUneColonne ? ' active' : ''),
      'data-vue': v.id, role: 'tab',
      'aria-selected': String(active === v.id && dansUneColonne),
      title: v.titre + (dansUneColonne ? '' : ' (masqué — cliquer pour l’afficher)')
    },
    el('span', { class: 'ps-vue-icone', texte: v.icone || '◆' }),
    el('span', { class: 'ps-vue-titre', texte: v.titre }),
    el('button', { class: 'ps-vue-scinder', type: 'button',
      'data-scinder-vue': v.id,
      title: 'Afficher dans une nouvelle colonne, à droite', texte: '⧉' }),
    v.fermable === false ? null : el('button', {
      class: 'ps-vue-x', type: 'button', 'data-fermer': v.id,
      'aria-label': 'Fermer ' + v.titre, texte: '×'
    }));
    if (!dansUneColonne) onglet.className += ' ps-vue-masquee';
    hote.appendChild(onglet);
  });
}

function surClicOnglet(evt) {
  if (!hote) return;
  let noeud = evt && evt.target;
  while (noeud && noeud !== hote) {
    const at = noeud.getAttribute ? noeud.getAttribute.bind(noeud) : null;
    if (!at) break;
    const fermer = at('data-fermer');
    const scinderVue = at('data-scinder-vue');
    if (scinderVue) {
      evt.preventDefault && evt.preventDefault();
      evt.stopPropagation && evt.stopPropagation();
      api.scinder(scinderVue);
      return;
    }
    if (fermer) {
      evt.preventDefault && evt.preventDefault();
      evt.stopPropagation && evt.stopPropagation();
      api.fermer(fermer);
      return;
    }
    const id = at('data-vue');
    if (id) {
      evt.preventDefault && evt.preventDefault();
      intentionVoir();
      api.activer(id);
      return;
    }
    noeud = noeud.parentNode;
  }
}

function surClicZone(evt) {
  if (!zone) return;
  let noeud = evt && evt.target;
  while (noeud && noeud !== zone) {
    const at = noeud.getAttribute ? noeud.getAttribute.bind(noeud) : null;
    if (!at) break;
    const fermer = at('data-fermer');
    const scinder = at('data-scinder');
    const fusion = at('data-fusion');
    if (scinder) { api.scinder(scinder); return; }
    if (fusion) { api.fusionner(fusion); return; }
    if (fermer) { api.fermerColonne(fermer); return; }
    const col = at('data-colonne');
    if (col && active !== col) { active = col; appliquerRacine(); rendreOnglets();
      rendreEntetes(); return; }
    noeud = noeud.parentNode;
  }
}

function rendreEntetes() {
  if (!zone) return;
  const entetes = zone.querySelectorAll ? zone.querySelectorAll('.ps-vues-colonne') : [];
  for (let i = 0; i < entetes.length; i += 1) {
    const id = entetes[i].getAttribute('data-colonne');
    if (active === id) entetes[i].classList.add('ps-vues-avant');
    else entetes[i].classList.remove('ps-vues-avant');
  }
}

/* ------------------------------------------------------------------ glisser -- */

function surSeparateur(evt) {
  if (!zone || colonnes.length < 2) return;
  const sep = evt && evt.currentTarget;
  const index = sep ? parseInt(sep.getAttribute('data-sep'), 10) : NaN;
  if (!isFinite(index) || index < 1 || index >= colonnes.length) return;
  const gauche = colonnes[index - 1], droite = colonnes[index];
  const largeurZone = zone.getBoundingClientRect
    ? zone.getBoundingClientRect().width : 0;
  if (!largeurZone) return;
  const departX = evt.clientX || 0;
  const departGauche = gauche.largeur, departDroite = droite.largeur;
  entrainDeGlisser = true;
  zone.classList.add('ps-vues-glisse');

  const bouger = function (e) {
    const dx = ((e && e.clientX) || 0) - departX;
    const delta = (dx / largeurZone) * 100;
    let g = nombre(departGauche + delta, LARGEUR_MIN, departGauche + departDroite - LARGEUR_MIN, departGauche);
    gauche.largeur = g;
    droite.largeur = nombre(departGauche + departDroite - g, LARGEUR_MIN, 100, departDroite);
    rendreColonnes();
    appliquerRacine();
  };
  const finir = function () {
    entrainDeGlisser = false;
    if (zone) zone.classList.remove('ps-vues-glisse');
    document.removeEventListener('pointermove', bouger);
    document.removeEventListener('pointerup', finir);
    document.removeEventListener('pointercancel', finir);
  };
  document.addEventListener('pointermove', bouger);
  document.addEventListener('pointerup', finir);
  document.addEventListener('pointercancel', finir);
  if (typeof evt.preventDefault === 'function') evt.preventDefault();
}

/* Un onglet de FICHIER devenu actif rend la main à l'éditeur en mode plein : la
 * vue est masquée, pas détruite. Sans cela, ouvrir un fichier laisserait le
 * panneau par-dessus et l'utilisateur croirait l'éditeur cassé. */
function ongletFichierActifNoeud() {
  if (!barre || !barre.querySelectorAll) return null;
  const onglets = barre.querySelectorAll('.tab');
  for (let i = 0; i < onglets.length; i += 1) {
    const classe = String(onglets[i].className || '');
    if (classe.indexOf('ps-vue-onglet') >= 0) continue;
    if (classe.indexOf('active') >= 0) return onglets[i];
  }
  return null;
}

function ongletFichierActif() { return !!ongletFichierActifNoeud(); }

/* La clé d'un onglet de fichier, pour distinguer un vrai changement de fichier
 * d'un rafraîchissement de la barre par React. Le chemin affiché est plus stable
 * que l'identité du noeud, que React remplace librement. Les puces de fichier
 * modifié sont retirées pour la même raison. */
function cleOngletFichier(noeud) {
  if (!noeud) return null;
  const at = function (nom) {
    return (noeud.getAttribute && noeud.getAttribute(nom)) || '';
  };
  const brut = at('title') || at('data-path') || at('aria-label') || at('id')
    || noeud.textContent || '';
  const cle = String(brut).replace(/[\s\u2022\u00b7*]/g, '');
  return cle;
}

/* Vouloir montrer une vue : ouvrir un panneau, cliquer sa vignette, la scinder
 * ou la recoller sont des demandes explicites, donc la zone s'affiche même si un
 * onglet de fichier est actif. Sans cela, ouvrir un panneau pendant qu'un
 * fichier était ouvert le masquait aussitôt — ouvrir() et activer() rappellent
 * synchroniser(), et la barre garde un onglet actif en permanence : c'était
 * « les panneaux ne se chargent plus, et une fois fermés on ne peut plus les
 * rouvrir ». */
function intentionVoir() {
  barre = $(BARRE);
  masqueeSurFichier = false;
  cleFichierVue = cleOngletFichier(ongletFichierActifNoeud());
}

/* Un clic sur un onglet de FICHIER rend la main à l'éditeur. Les vignettes de
 * vues portent elles aussi la classe `tab` du bundle : elles sont écartées
 * d'abord, sinon cliquer une vignette masquerait le panneau qu'elle ouvre. */
function surClicBarreFichiers(evt) {
  if (!barre) return;
  let noeud = evt && evt.target;
  while (noeud && noeud !== barre) {
    const classes = String(noeud.className || '').split(/\s+/);
    if (classes.indexOf('ps-vue-onglet') >= 0) return;
    if (classes.indexOf('tab') >= 0) {
      masqueeSurFichier = true;
      cleFichierVue = cleOngletFichier(noeud);
      synchroniser();
      return;
    }
    noeud = noeud.parentNode;
  }
}

function signatureVignettes() {
  return vues.map(function (v) {
    const affichee = !!colonne(v.id);
    return [v.id, v.titre, v.icone || '◆',
      active === v.id && affichee ? 1 : 0, affichee ? 1 : 0,
      v.fermable === false ? 0 : 1].join('|');
  }).join('#');
}

function synchroniser() {
  const trouve = $(HOTE);
  if (trouve && trouve !== hote) {
    hote = trouve;
    /* Un hôte neuf est vide : la signature des vignettes doit être rejouée. */
    signatureOnglets = '';
    if (!hote.__psVuesEcoute) {
      hote.addEventListener('click', surClicOnglet);
      hote.__psVuesEcoute = true;
    }
  }
  if (!trouve && hote && !contient(document.documentElement, hote)) hote = null;
  barre = $(BARRE);
  if (barre && !barre.__psVuesEcouteBarre) {
    /* Un clic sur un onglet de FICHIER rend la main à l'éditeur. Sans cette
     * écoute, un second clic sur le même onglet ne changeait aucune clé et la
     * zone restait par-dessus le fichier. */
    barre.addEventListener('click', surClicBarreFichiers);
    barre.__psVuesEcouteBarre = true;
  }
  /* Un AUTRE fichier passé au premier plan (clic, clavier, explorateur) : la
   * zone s'efface devant lui. Le même fichier qui reste actif ne change rien,
   * et l'absence d'onglet de fichier rend la main aux panneaux. */
  const cle = cleOngletFichier(ongletFichierActifNoeud());
  if (cle !== cleFichierVue) {
    cleFichierVue = cle;
    masqueeSurFichier = cle !== null;
  }
  const conteneur = assurerZone();
  if (conteneur && !conteneur.__psVuesEcoute) {
    conteneur.addEventListener('click', surClicZone);
    conteneur.__psVuesEcoute = true;
  }
  normaliserLargeurs();
  appliquerRacine();
  rendreColonnes();
  rendreOnglets();
  rendreEntetes();
  if (mode === 'plein' && active && masqueeSurFichier) {
    /* L'utilisateur est allé sur un onglet de fichier : on masque sans fermer. */
    const z = assurerZone();
    if (z) z.style.display = 'none';
    const racine = principales();
    if (racine && racine.classList) {
      racine.classList.remove(CLASSE_RACINE);
      racine.classList.remove(CLASSE_PARTAGE);
    }
    const laterale = $(LATÉRALE);
    if (laterale && laterale.classList) laterale.classList.remove(CLASSE_LATÉRALE);
  }
}

/* --------------------------------------------------------------------- l'API -- */

const api = {
  marqueur: MARQUEUR,

  /* Ouvrir une vue, ou la mettre à jour si elle existe déjà. Le noeud passé est
   * celui que le panneau a construit : ce script ne recopie jamais le contenu
   * d'un panneau, il lui donne seulement une place. */
  ouvrir: function (options) {
    const opts = options || {};
    if (!opts.id) return false;
    let v = vue(opts.id);
    if (!v) {
      v = { id: String(opts.id), titre: String(opts.titre || opts.id),
        icone: opts.icone || '◆', noeud: null,
        fermable: opts.fermable !== false,
        surFermeture: typeof opts.surFermeture === 'function' ? opts.surFermeture : null };
      vues.push(v);
    }
    if (opts.titre) v.titre = String(opts.titre);
    if (opts.icone) v.icone = String(opts.icone);
    if (opts.fermable !== undefined) v.fermable = opts.fermable !== false;
    if (opts.noeud && opts.noeud !== v.noeud) {
      detacher(v.noeud);
      v.noeud = opts.noeud;
    }
    if (opts.surFermeture !== undefined) {
      v.surFermeture = typeof opts.surFermeture === 'function' ? opts.surFermeture : null;
    }
    if (!colonne(v.id)) {
      /* La nouvelle vue prend la place de la colonne active si elle est vide,
       * sinon elle ouvre sa propre colonne à droite. */
      const vide = colonnes.filter(function (c) { return !vue(c.id); });
      if (vide.length) vide[0].id = v.id;
      else colonnes.push({ id: v.id, largeur: 100 / (colonnes.length + 1) });
      normaliserLargeurs();
    }
    active = v.id;
    if (opts.mode) api.mode(opts.mode, opts.largeur);
    intentionVoir();
    synchroniser();
    return true;
  },

  fermer: function (id) {
    const v = vue(id);
    if (!v) return false;
    vues.splice(vues.indexOf(v), 1);
    detacher(v.noeud);
    v.noeud = null;
    api.fermerColonne(v.id, true);
    if (v.surFermeture) {
      try { v.surFermeture(); } catch (exc) { /* une vue ne bloque pas les autres */ }
    }
    synchroniser();
    return true;
  },

  /* Refermer une colonne sans détruire la vue : elle redevient une vignette
   * masquée, son état est conservé. */
  fermerColonne: function (id, dejaFait) {
    const c = colonne(id);
    if (!c) return false;
    const place = colonnes.indexOf(c);
    colonnes.splice(place, 1);
    normaliserLargeurs();
    if (active === id) {
      active = colonnes.length ? colonnes[Math.max(0, place - 1)].id : null;
    }
    if (!dejaFait) synchroniser();
    return true;
  },

  activer: function (id) {
    const v = vue(id);
    if (!v) return false;
    if (!colonne(id)) {
      colonnes.push({ id: v.id, largeur: 100 / (colonnes.length + 1) });
      normaliserLargeurs();
    }
    active = v.id;
    intentionVoir();
    synchroniser();
    return true;
  },

  /* Scinder : mettre une vue dans une NOUVELLE colonne à droite de la colonne
   * active. C'est le splittage demandé — plusieurs panneaux côte à côte. */
  scinder: function (id, aDroite) {
    const v = vue(id || active);
    if (!v) return false;
    const deja = colonne(v.id);
    const place = deja && aDroite !== false ? colonnes.indexOf(deja) + 1
      : colonnes.length;
    if (deja) colonnes.splice(colonnes.indexOf(deja), 1);
    const neuve = { id: v.id, largeur: 0 };
    colonnes.splice(Math.min(place, colonnes.length), 0, neuve);
    normaliserLargeurs();
    active = v.id;
    intentionVoir();
    synchroniser();
    return true;
  },

  /* Recoller une colonne : la vue redevient une vignette, les autres colonnes
   * se répartissent la largeur. */
  fusionner: function (id) { return api.fermerColonne(id); },

  /* 'plein' : la zone couvre toute la zone d'édition et masque la barre
   * latérale. 'partage' : elle ne prend que `largeur` % à droite et l'éditeur
   * garde le reste — Monaco se redessine seul grâce à automaticLayout. */
  mode: function (nouveau, largeur) {
    if (nouveau === 'plein' || nouveau === 'partage') mode = nouveau;
    if (largeur !== undefined && largeur !== null) {
      partageLargeur = nombre(largeur, LARGEUR_MIN, LARGEUR_MAX, partageLargeur);
    }
    synchroniser();
    return { mode: mode, largeur: partageLargeur };
  },
  largeur: function (v) {
    if (v === undefined) return partageLargeur;
    partageLargeur = nombre(v, LARGEUR_MIN, LARGEUR_MAX, partageLargeur);
    synchroniser();
    return partageLargeur;
  },

  masquer: function () {
    active = null;
    synchroniser();
    return true;
  },

  vues: function () {
    return vues.map(function (v) {
      return { id: v.id, titre: v.titre, icone: v.icone, fermable: v.fermable,
        active: v.id === active, affichée: !!colonne(v.id),
        attachee: !!(v.noeud && v.noeud.parentNode) };
    });
  },
  colonnes: function () {
    return colonnes.map(function (c) {
      const v = vue(c.id);
      return { id: c.id, titre: v ? v.titre : c.id, largeur: c.largeur,
        avant: c.id === active };
    });
  },
  active: function () { return active; },
  disposition: function () {
    return { mode: mode, largeur: partageLargeur, colonnes: api.colonnes(),
      decalage_haut: decalageHaut() };
  },

  /* Ce que le mécanisme garantit : pour les bancs, et pour le guide qui doit
   * dire la vérité sur ce qui est protégé. */
  garanties: function () {
    return {
      barre_onglets_cliquable: true,
      barre_activite_cliquable: true,
      barre_laterale_masquee_en_plein: mode === 'plein',
      noeuds_conserves_masques: true,
      observateurs: 1,
      decalage_mesure: decalageHaut(),
      zone_dans: principales() ? PRINCIPAL : null,
      splittage: colonnes.length > 1,
      editeur_partage_possible: mode === 'partage'
    };
  },
  synchroniser: synchroniser,
  _test: {
    vues: vues, colonnes: colonnes,
    setZone: function (z) { zone = z; },
    setHote: function (h) { hote = h; },
    setBarre: function (b) { barre = b; },
    get mode() { return mode; }
  }
};

window.PSVues = api;

function demarrer() {
  synchroniser();
  if (window.PSHotes && window.PSHotes.suivre) {
    window.PSHotes.suivre(HOTE, synchroniser);
    /* La zone est créée par CE script : elle n'a pas besoin d'être observée,
     * mais la barre latérale et la barre d'onglets sont recréées par React à
     * chaque changement de vue, donc un rappel large est nécessaire. */
    window.PSHotes.suivre(PRINCIPAL, synchroniser);
  } else if (typeof MutationObserver === 'function') {
    const observateur = new MutationObserver(synchroniser);
    observateur.observe(document.documentElement, { subtree: true, childList: true });
    if (typeof setInterval === 'function') setInterval(synchroniser, 5000);
  }
  /* Le redimensionnement change le décalage : sans ce rappel, la zone laisserait
   * voir l'éditeur sous la barre d'onglets après un changement de fenêtre ou de
   * zoom. */
  if (typeof window.addEventListener === 'function') {
    window.addEventListener('resize', function () {
      if (entrainDeGlisser) return;
      synchroniser();
    });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', demarrer, { once: true });
} else demarrer();
})();
