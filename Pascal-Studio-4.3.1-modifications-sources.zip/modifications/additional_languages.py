"""Five language integrations: single-file builds and non-executing live checks.
The checkers are not sandboxes. Compiling or running untrusted code is unsafe.
"""
import hashlib,json,os,re,shutil,subprocess,sys,tempfile
from pathlib import Path
KINDS={'fortran':('.f','.for','.ftn','.f77','.f90','.f95','.f03','.f08','.fpp'), 'perl':('.pl','.pm'), 'basic':('.bas','.yab'), 'ocaml':('.ml','.mli'), 'lua':('.lua',)}
TOOLS={'fortran':('gfortran','gfortran'), 'perl':('perl','perl'), 'basic':('yabasic','yabasic'), 'ocaml':('ocamlc','ocaml'), 'lua':('lua5.4','lua5.4')}
def kind(path):
 suffix=Path(path).suffix.lower()
 return next((name for name,exts in KINDS.items() if suffix in exts),None)
def executable(kind):
 name,package=TOOLS[kind];exe=shutil.which(name)
 if not exe and kind=='lua':exe=shutil.which('lua')
 if not exe:raise ValueError('Installez '+package+' : sudo apt install '+package)
 return exe

def invoke(cmd,cwd,input=None,timeout=15):
 try:
  p=subprocess.run(cmd,cwd=cwd,input=input,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=timeout,env={**os.environ,'LC_ALL':'C.UTF-8','TERM':'dumb'})
  return p.returncode,(p.stdout+p.stderr)[-100000:]
 except subprocess.TimeoutExpired:raise ValueError('Analyse interrompue après '+str(timeout)+' secondes.')

def utf16col(content,row,col):
 lines=content.splitlines();line=lines[row-1] if 0<row<=len(lines) else ''
 return len(line[:max(0,col-1)].encode('utf-16-le'))//2+1

def parse_diagnostics(k,output,key,content):
 rows=[]
 def add(line,col,msg,sev='error'):
  line=max(1,int(line));col=utf16col(content,line,max(1,int(col)));items=content.splitlines()
  if line>max(1,len(items)):line=max(1,len(items));col=1
  rows.append({'file':key,'line':line,'column':col,'severity':sev,'message':msg[:800]})
 if k=='fortran':
  # gfortran: file:line:column:, caret/source, then Error:/Warning:.
  matches=list(re.finditer(r'^(.+?):(\d+):(\d+):\s*$',output,re.M))
  for idx,m in enumerate(matches):
   tail=output[m.end():matches[idx+1].start() if idx+1<len(matches) else len(output)]
   message=re.search(r'^(Fatal Error|Error|Warning):\s*(.+)$',tail,re.M|re.I)
   if message:add(m.group(2),m.group(3),message.group(2),'warning' if message.group(1).lower()=='warning' else 'error')
 elif k=='ocaml':
  for m in re.finditer(r'File "[^"]+", lines? (\d+)(?:-\d+)?, characters? (\d+)-(\d+):\s*\n((?:.|\n)*?)(?=\nFile "|\Z)',output):
   msg=re.search(r'(?:Error|Warning\s+\d+):\s*(.*)',m.group(4));
   if msg:add(m.group(1),int(m.group(2))+1,msg.group(1),'warning' if 'Warning ' in msg.group(0) else 'error')
 elif k=='basic':
  for m in re.finditer(r'---Error in .*?, line (\d+):\s*\n---Error:\s*(.*)',output):add(m.group(1),1,m.group(2))
 elif k=='lua':
  for m in re.finditer(r'(?:stdin|<stdin>|[^\s:]+\.lua):(\d+):\s*(.*)',output):add(m.group(1),1,m.group(2))
 return rows[:100]

def analyze(k,path,key,content):
 if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
 p=Path(path);k=kind(p) if not k else k
 if k=='perl':
  script=Path(__file__).resolve().parent/'perl_static_check.py'
  try:
   code,out=invoke([sys.executable,'-I',str(script)],p.parent,content,timeout=8)
   if code:raise ValueError('Analyseur Perl indisponible.')
   rows=json.loads(out)
   for r in rows:r['file']=key
   return {'state':'ready','ok':not rows,'diagnostics':rows,'message':'Analyse Perl statique indicative ; certaines syntaxes peuvent être mal reconnues.','output':''}
  except (ValueError,json.JSONDecodeError):return {'state':'unavailable','ok':False,'diagnostics':[],'message':'Analyse Perl statique indisponible ; le programme reste exécutable.','output':''}
 try:exe=executable(k)
 except ValueError as e:return {'state':'unavailable','ok':False,'diagnostics':[],'message':str(e),'output':''}
 with tempfile.TemporaryDirectory(prefix='ps-newlang-') as temp:
  temp=Path(temp);src=temp/('source'+(p.suffix or '.txt'));src.write_text(content,encoding='utf8')
  if k=='fortran':cmd=[exe]+(['-x','f77-cpp-input' if p.suffix=='.F77' else 'f77'] if p.suffix.lower()=='.f77' else [])+['-fsyntax-only','-fdiagnostics-color=never','-fmax-errors=30','-J',str(temp),'-I',str(p.parent),str(src)]
  elif k=='ocaml':cmd=[exe,'-stop-after','parsing','-c',str(src)]
  elif k=='basic':cmd=[exe,'--check',str(src)]
  elif k=='lua':
   luac=shutil.which('luac5.4') or shutil.which('luac')
   if not luac:return {'state':'unavailable','ok':False,'diagnostics':[],'message':'Installez lua5.4 et luac5.4 pour l’analyse.','output':''}
   cmd=[luac,'-p','-']
  else:return {'state':'unsupported','diagnostics':[],'message':'Analyse indisponible.'}
  try:code,out=invoke(cmd,p.parent,content if k=='lua' else None)
  except ValueError as e:return {'state':'timeout','ok':False,'diagnostics':[],'message':str(e),'output':''}
  out=out.replace(str(src),str(p));found=parse_diagnostics(k,out,key,content)
  if code and not found:found=[{'file':key,'line':1,'column':1,'severity':'error','message':(out.strip().splitlines()[-1] if out.strip() else 'Analyse interrompue.')[:800]}]
  return {'state':'ready','ok':code==0,'diagnostics':found,'message':None if code or found else 'Analyse syntaxique à jour.','output':out}

def build(root,build_dir,path,key,debug=False):
 p=Path(path).resolve();k=kind(p);content=p.read_text(encoding='utf8');exe=executable(k);base={'kind':k,'diagnostics':[],'cwd':str(p.parent)}
 if k=='ocaml' and p.suffix.lower()=='.mli':return {**base,'ok':False,'output':'Une interface .mli ne s’exécute pas. Sélectionnez un fichier .ml.','binary':None}
 if k in ('perl','lua','basic'):
  result=analyze(k,p,key,content)
  # Tree-sitter Perl is approximate: never block execution of valid Perl on it.
  if k=='perl':return {**base,'ok':True,'output':'Perl : analyse statique indicative, sans exécuter les blocs BEGIN.\n','diagnostics':result.get('diagnostics',[]),'command':[exe,str(p)]}
  if result['state']!='ready':raise ValueError(result.get('message','Analyse indisponible.'))
  return {**base,'ok':result['ok'],'output':result.get('output') or ('Syntaxe correcte.\n' if result['ok'] else 'Syntaxe invalide.\n'),'diagnostics':result['diagnostics'],'command':[exe,str(p)] if result['ok'] else None}
 binary=Path(build_dir)/('newlang-'+hashlib.sha256(str(p).encode()).hexdigest()[:20]);binary.unlink(missing_ok=True)
 with tempfile.TemporaryDirectory(prefix='ps-newbuild-',dir=str(build_dir)) as temp:
  temp=Path(temp)
  if k=='fortran':cmd=[exe]+(['-x','f77-cpp-input' if p.suffix=='.F77' else 'f77'] if p.suffix.lower()=='.f77' else [])+['-g','-O0','-fdiagnostics-color=never','-J',str(temp),'-I',str(p.parent),str(p),'-o',str(binary)]
  else:
   # OCaml emits intermediate files next to its input; compile a copy in cache.
   src=temp/p.name;src.write_text(content,encoding='utf8');cmd=[exe,'-g','-I',str(p.parent),'-o',str(binary),str(src)]
  code,out=invoke(cmd,p.parent,timeout=120)
  if k=='ocaml':out=out.replace(str(src),str(p))
  found=parse_diagnostics(k,out,key,content)
  return {**base,'ok':code==0 and binary.is_file(),'output':out or ('Compilation réussie.\n' if code==0 else 'Compilation impossible.\n'),'diagnostics':found,'binary':str(binary) if code==0 and binary.is_file() else None}
