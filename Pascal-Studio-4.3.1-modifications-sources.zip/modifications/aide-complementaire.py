"""Nouvelles fiches transversales, chacune avec explication et exemple.
Les exemples sont des extraits à adapter, pas tous des programmes complets.
"""
import json
from pathlib import Path
from collections import Counter
articles=[]
def add(lang,group,items):
 for title,explanation,example in items:
  articles.append({'id':f'ps-extra-{len(articles):04d}','lang':lang,'group':group,'title':title,'summary':explanation,'blocks':[{'title':'Explication','text':explanation,'code':''},{'title':'Exemple','text':'Extrait à adapter au contexte et aux versions utilisées.','code':example}]})
add('Pascal','Compléments pratiques',[
('Vérifier une conversion numérique',"TryStrToInt distingue une entrée invalide du nombre zéro, contrairement à une conversion implicite. Elle appartient à SysUtils.","uses SysUtils;\nvar n: Integer;\nbegin\n  if TryStrToInt('42', n) then WriteLn(n)\n  else WriteLn('Entrée invalide');\nend."),
('Protéger une ressource avec finally',"finally s’exécute après le bloc try même lorsqu’une exception se produit. Libérez-y les objets construits avant le try.","liste := TStringList.Create;\ntry\n  liste.LoadFromFile('notes.txt');\nfinally\n  liste.Free;\nend;"),
('Tableau dynamique',"SetLength fixe la longueur d’un tableau dynamique. La première case a l’indice zéro.","var notes: array of Integer;\nbegin\n  SetLength(notes, 2);\n  notes[0] := 12;\nend."),
('Passage par référence var',"Un paramètre var permet à la procédure de modifier la variable transmise ; l’argument doit être compatible.","procedure Incrementer(var n: Integer);\nbegin\n  Inc(n);\nend;"),
('Chemins et fichiers',"FileExists permet de vérifier la présence d’un fichier avant de le lire, mais une modification concurrente reste possible.","if FileExists('notes.txt') then\n  WriteLn('Fichier présent');"),
('Erreurs de compilation et exécution',"Une erreur de syntaxe ou de type est détectée par le compilateur ; une division par une variable nulle peut ne survenir qu’à l’exécution. Utilisez les points d’arrêt pour inspecter les valeurs.","if diviseur <> 0 then\n  WriteLn(valeur div diviseur);"),
])
add('C','Compléments pratiques',[
('Vérifier malloc',"malloc renvoie NULL si l’allocation échoue. Libérez une allocation réussie une seule fois et ne l’utilisez plus après free.","int *p = malloc(10 * sizeof *p);\nif (p == NULL) return 1;\nfree(p);"),
('Lire une ligne avec fgets',"fgets limite le nombre de caractères copiés et conserve éventuellement le saut de ligne. Vérifiez son résultat avant d’utiliser le tampon.",'char ligne[128];\nif (fgets(ligne, sizeof ligne, stdin))\n    printf("%s", ligne);'),
('snprintf et taille du tampon',"snprintf limite l’écriture à la taille du tampon, zéro final compris ; son résultat indique la taille qui aurait été nécessaire.",'char buf[32];\nint n = snprintf(buf, sizeof buf, "%d", 42);\nif (n < 0 || (size_t)n >= sizeof buf) { /* erreur ou troncature */ }'),
('const et pointeurs',"const int * interdit de modifier l’entier par ce pointeur ; int *const interdit de changer le pointeur lui-même.",'int x = 3;\nconst int *lecture = &x;\nint *const adresse = &x;'),
('Diagnostiquer une compilation',"Les avertissements -Wall et -Wextra révèlent des problèmes fréquents sans garantir la correction ; -g ajoute des informations utiles au débogueur.",'gcc -g -O0 -Wall -Wextra main.c -o programme'),
])
add('C++','Compléments pratiques',[
('RAII et std::unique_ptr',"unique_ptr détruit automatiquement l’objet possédé à la sortie de portée. Il exprime une possession unique.",'#include <memory>\nauto p = std::make_unique<int>(42);'),
('std::vector et accès contrôlé',"at vérifie l’indice et lève std::out_of_range en cas d’erreur ; operator[] ne réalise pas cette vérification.",'std::vector<int> v{2, 4};\nint premier = v.at(0);'),
('Boucle for sur une collection',"Une référence const évite la copie de chaque élément et empêche sa modification dans la boucle.",'for (const auto& valeur : valeurs) {\n    std::cout << valeur << "\\n";\n}'),
('std::optional',"optional représente une valeur facultative sans utiliser une valeur sentinelle. Vérifiez sa présence avant de la lire.",'std::optional<int> n = 42;\nif (n) std::cout << *n;'),
('Exceptions et ressources',"Une exception remonte la pile jusqu’à un catch compatible. Les destructeurs des objets locaux sont appelés pendant cette remontée.",'try {\n    operation();\n} catch (const std::exception& e) {\n    std::cerr << e.what();\n}'),
])
add('C#','Compléments pratiques',[
('using et IDisposable',"using garantit l’appel de Dispose à la sortie de portée, y compris en cas d’exception.",'using var lecteur = new StreamReader("notes.txt");\nstring texte = lecteur.ReadToEnd();'),
('TryParse',"TryParse signale l’échec sans exception pour une entrée incorrecte et fournit la valeur via out.",'if (int.TryParse("42", out int n))\n    Console.WriteLine(n);'),
('Types nullables',"Un type valeur suivi de ? accepte aussi null ; l’opérateur ?? fournit une valeur de repli.",'int? nombre = null;\nConsole.WriteLine(nombre ?? 0);'),
('async et await',"await attend une opération asynchrone sans bloquer nécessairement le thread appelant. Les exceptions restent à traiter.",'async Task<string> LireAsync() =>\n    await File.ReadAllTextAsync("notes.txt");'),
('LINQ Where et Select',"Where filtre une séquence ; Select transforme ses éléments. L’évaluation est souvent différée jusqu’à l’énumération.",'var doubles = nombres.Where(n => n > 0).Select(n => n * 2);'),
])
add('Python','Compléments pratiques',[
('with et fermeture de fichier',"with ferme automatiquement le fichier à la sortie du bloc, même si une exception survient.",'with open("notes.txt", encoding="utf-8") as fichier:\n    texte = fichier.read()'),
('Exceptions ciblées',"Interceptez les exceptions attendues et gardez le bloc try court pour ne pas masquer d’autres défauts.",'try:\n    nombre = int(texte)\nexcept ValueError:\n    print("Entier invalide")'),
('Arguments mutables par défaut',"Les valeurs par défaut sont créées à la définition de la fonction ; utilisez None pour construire une nouvelle liste à chaque appel.",'def ajouter(valeur, liste=None):\n    if liste is None:\n        liste = []\n    liste.append(valeur)\n    return liste'),
('Générateurs',"Une expression génératrice produit ses valeurs à la demande, utile pour éviter de construire une grande liste.",'total = sum(n * n for n in range(1000))'),
('Annotations de type',"Les annotations documentent les valeurs attendues ; Python ne les fait pas respecter automatiquement à l’exécution.",'def saluer(nom: str) -> str:\n    return f"Bonjour {nom}"'),
('Déboguer une erreur dynamique',"Une erreur non interceptée produit un traceback. La dernière ligne indique le type d’exception et les cadres indiquent les appels ; l’analyse statique ne peut pas tout anticiper.",'diviseur = 0\nprint(10 / diviseur)  # ZeroDivisionError'),
])
add('JavaScript','Compléments pratiques',[
('let et const',"const interdit la réaffectation de la liaison, mais ne rend pas immuable le contenu d’un objet.",'const personne = { nom: "Ada" };\npersonne.nom = "Grace";'),
('async, await et erreurs',"await récupère la valeur d’une Promise ou relance son rejet ; utilisez try/catch pour traiter l’échec.",'try {\n  const reponse = await fetch(url);\n  if (!reponse.ok) throw new Error(reponse.status);\n} catch (e) { console.error(e); }'),
('Égalité stricte',"=== compare sans conversion implicite de type ; préférez-le lorsque la conversion ne fait pas partie du comportement recherché.",'console.log(0 === "0"); // false'),
('Chaînage optionnel et valeur par défaut',"?. arrête l’accès si la valeur est null ou undefined ; ?? fournit un repli pour ces deux valeurs seulement.",'const ville = utilisateur?.adresse?.ville ?? "inconnue";'),
('Modules import et export',"Les modules ES exportent explicitement leurs valeurs. Leur chargement dépend de l’environnement et, pour Node, du type de module.",'export function carre(n) { return n * n; }\n// Dans un autre module : import { carre } from "./calcul.js";'),
])
add('PHP','Compléments pratiques',[
('Requêtes PDO préparées',"Une requête préparée sépare les valeurs de la requête SQL ; elle ne permet pas de paramétrer directement les noms de tables ou colonnes.",'$stmt = $pdo->prepare("SELECT nom FROM users WHERE id = :id");\n$stmt->execute(["id" => 42]);'),
('Échapper du texte HTML',"htmlspecialchars réduit les risques d’injection HTML lorsqu’il est utilisé avec le bon encodage et le bon contexte de sortie.",'echo htmlspecialchars($nom, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");'),
('Exceptions try et finally',"finally s’exécute lorsque le bloc try se termine, même si une exception remonte.",'$f = null;\ntry {\n    $f = fopen("notes.txt", "r");\n    // utiliser $f\n} finally {\n    if (is_resource($f)) fclose($f);\n}'),
('Comparaison stricte',"=== compare aussi le type ; == peut effectuer des conversions qui surprennent.",'var_dump(0 === "0"); // false'),
('CLI et serveur web',"PHP CLI exécute un script dans un processus local ; les variables et requêtes HTTP d’un serveur ne sont pas automatiquement présentes.",'php -l main.php\nphp main.php'),
])
add('HTML','Compléments pratiques',[
('Libellé associé à un champ',"Un label dont for correspond à l’id du champ améliore l’utilisation au clavier et avec les technologies d’assistance.",'<label for="nom">Nom</label>\n<input id="nom" name="nom" autocomplete="name">'),
('Texte alternatif d’image',"alt décrit l’information apportée par une image ; pour une image purement décorative, un alt vide peut convenir.",'<img src="schema.png" alt="Schéma du réseau local">'),
('Structure sémantique',"main, nav et les titres structurent le document ; utilisez-les selon le sens du contenu plutôt que pour leur apparence.",'<nav aria-label="Navigation">…</nav>\n<main><h1>Guide</h1><p>Bonjour.</p></main>'),
('Formulaire et méthode',"La méthode POST place les champs dans le corps de la requête ; le serveur doit valider toutes les données reçues.",'<form method="post" action="/enregistrer">\n  <label>Nom <input name="nom"></label>\n  <button type="submit">Envoyer</button>\n</form>'),
])
add('CSS','Compléments pratiques',[
('Spécificité et cascade',"La cascade combine origine, importance, spécificité et ordre ; une règle plus spécifique peut l’emporter sur une règle plus tardive.",'.carte p { color: purple; }\np { color: black; }'),
('Flexbox et retour à la ligne',"flex-wrap autorise les éléments à passer sur plusieurs lignes ; gap définit l’espace entre eux.",'.liste { display: flex; flex-wrap: wrap; gap: 1rem; }'),
('Grid responsive',"repeat et minmax créent des colonnes qui s’adaptent à la place disponible.",'.grille { display: grid; grid-template-columns: repeat(auto-fit, minmax(15rem, 1fr)); gap: 1rem; }'),
('Focus visible',"Un indicateur visible au focus aide la navigation au clavier ; ne supprimez pas le contour sans solution de remplacement.",'button:focus-visible { outline: 2px solid #bd93f9; outline-offset: 3px; }'),
])
add('Markdown','Compléments pratiques',[
('Bloc de code avec langage',"Trois accents graves entourent un bloc ; le nom du langage aide les moteurs compatibles à colorer le code.",'```python\nprint("Bonjour")\n```'),
('Liens et images',"Un lien utilise [texte](adresse) ; une image ajoute ! et son texte entre crochets sert d’alternative.",'[Documentation](https://example.com)\n![Schéma du projet](schema.png)'),
('Tableaux et compatibilité',"Les tableaux à barres verticales sont une extension courante, pas une garantie de tous les moteurs Markdown.",'| Nom | Score |\n| --- | ---: |\n| Ada | 42 |'),
('Listes et indentation',"Indentez les éléments imbriqués de façon cohérente ; une ligne vide peut influencer le rendu selon le moteur.",'- Projet\n  - Sources\n  - Tests'),
])
add('Makefile','Compléments pratiques',[
('Cibles .PHONY',"Une cible phony est toujours considérée comme une action, même si un fichier porte le même nom.",'.PHONY: clean\nclean:\n\trm -f programme'),
('Variables automatiques',"$@ désigne la cible, $< la première dépendance et $^ toutes les dépendances sans doublon.",'programme: main.c\n\t$(CC) $(CFLAGS) $< -o $@'),
('Dépendances et recompilation',"Make reconstruit une cible si une dépendance est plus récente ou si la cible manque ; déclarez aussi les en-têtes pertinents.",'main.o: main.c calcul.h\n\t$(CC) -c main.c -o main.o'),
('Tabulation des recettes',"Par défaut, chaque ligne de commande d’une recette commence par une tabulation, non par des espaces.",'bonjour:\n\t@echo Bonjour'),
])
add('CMake','Compléments pratiques',[
('Construire hors du dossier source',"Une construction séparée évite de mélanger fichiers générés et sources ; utilisez cmake --build pour l’outil choisi.",'cmake -S . -B build\ncmake --build build'),
('Bibliothèque et liaison',"add_library crée une cible ; target_link_libraries exprime ses dépendances et leur visibilité.",'add_library(calcul calcul.cpp)\nadd_executable(app main.cpp)\ntarget_link_libraries(app PRIVATE calcul)'),
('Version du langage',"Les propriétés de cible définissent le standard souhaité ; REQUIRED demande au compilateur de le respecter.",'set_target_properties(app PROPERTIES CXX_STANDARD 17 CXX_STANDARD_REQUIRED YES)'),
('Chemins d’inclusion ciblés',"target_include_directories attache des répertoires d’en-têtes à une cible, avec visibilité PRIVATE, PUBLIC ou INTERFACE.",'target_include_directories(app PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/include)'),
])
add('Rust','Débogage et vérifications',[
('Déboguer avec GDB',"Compilez avec informations de débogage et posez un point d’arrêt sur une ligne exécutable. L’IDE utilise GDB ; les types et macros complexes peuvent être difficiles à inspecter.",'rustc -g --edition=2021 main.rs -o programme\ngdb ./programme'),
('Éviter unwrap sur une entrée externe',"unwrap provoque une panique si le résultat est Err ; traiter l’erreur donne un message utile et permet de continuer ou de quitter proprement.",'match "abc".parse::<i32>() {\n    Ok(n) => println!("{n}"),\n    Err(e) => eprintln!("Entrée invalide : {e}"),\n}'),
('Assertions et tests',"assert! vérifie une condition ; les tests Cargo utilisent #[test] et sont exécutés par cargo test.",'#[test]\nfn addition() { assert_eq!(2 + 2, 4); }'),
('Détection à la frappe',"L’analyse rustc du tampon détecte plusieurs erreurs de syntaxe et de type, mais le contexte de dépendances peut différer de Cargo. Ne considérez pas tous les diagnostics comme définitifs.",'fn main() { let n = variable_inconnue; }'),
])
add('Go','Débogage et vérifications',[
('Déboguer avec Delve',"Delve comprend les goroutines et les symboles Go. Pour un binaire construit séparément, désactivez optimisations et inlining pour faciliter le pas à pas.",'go build -gcflags=all="-N -l" -o programme main.go\ndlv exec ./programme'),
('Syntaxe et types',"gofmt vérifie la syntaxe ; les erreurs de type, de noms et d’imports sont notamment détectées par go build. Une vérification de syntaxe réussie ne suffit pas à garantir la compilation.",'gofmt -e main.go\ngo build main.go'),
('Test unitaire',"Les tests Go utilisent le paquet testing et des fonctions nommées Test... dans des fichiers _test.go.",'func TestAddition(t *testing.T) {\n    if 2+2 != 4 { t.Fatal("addition") }\n}'),
('Gestion explicite des erreurs',"Testez les erreurs retournées avant d’utiliser la valeur. Ajoutez un contexte avec %w si l’appelant doit pouvoir retrouver l’erreur originale.",'if err != nil {\n    return fmt.Errorf("lecture : %w", err)\n}'),
])
add('Ruby','Débogage et vérifications',[
('Déboguer avec rdbg',"rdbg appartient à la gem debug. Les points d’arrêt et les variables dépendent de la version installée ; l’IDE utilise une connexion locale privée.",'rdbg main.rb'),
('Vérifier la syntaxe',"ruby -c analyse la syntaxe sans exécuter le programme. Cela ne prédit pas les erreurs de méthode ou de données à l’exécution.",'ruby -c main.rb'),
('Intercepter une erreur précise',"rescue sans type intercepte StandardError et ses descendants ; préférez un type précis lorsque vous connaissez l’échec attendu.",'begin\n  Integer(texte)\nrescue ArgumentError\n  warn "Entier invalide"\nend'),
('Prévenir les entrées nil',"gets renvoie nil en fin de fichier ; vérifiez ce cas avant d’appeler chomp ou strip.",'ligne = gets\nputs ligne.chomp if ligne'),
])
add('SQL','Compléments pratiques',[
('Paramétrer les valeurs',"Les paramètres évitent de concaténer des valeurs dans une requête. La syntaxe exacte dépend du pilote ; les identifiants nécessitent une validation séparée.",'SELECT nom FROM personnes WHERE id = ?;'),
('NULL et IS NULL',"NULL représente une valeur inconnue ou absente. Utilisez IS NULL ou IS NOT NULL plutôt que = NULL.",'SELECT * FROM personnes WHERE email IS NULL;'),
('LEFT JOIN et filtres',"Un filtre sur la table de droite dans WHERE peut exclure les lignes sans correspondance ; placez-le dans ON si vous souhaitez conserver ces lignes.",'SELECT c.nom, p.montant\nFROM clients c LEFT JOIN paiements p\n  ON p.client_id = c.id AND p.montant > 0;'),
('Transaction',"Une transaction regroupe des opérations ; COMMIT valide et ROLLBACK annule les modifications transactionnelles prises en charge par le moteur.",'BEGIN;\nUPDATE comptes SET solde = solde - 10 WHERE id = 1;\nROLLBACK;'),
])
add('SQLite','Compléments pratiques',[
('Activer les clés étrangères',"Les contraintes de clé étrangère doivent être activées pour chaque connexion SQLite lorsque nécessaire.",'PRAGMA foreign_keys = ON;'),
('Inspecter le plan',"EXPLAIN QUERY PLAN décrit notamment les accès aux tables et index ; interprétez le plan selon la version de SQLite.",'EXPLAIN QUERY PLAN SELECT * FROM clients WHERE id = 1;'),
('Importances des transactions',"Une transaction réduit les écritures répétées et rend un ensemble de modifications atomique si les opérations concernées sont transactionnelles.",'BEGIN;\nINSERT INTO mesures(valeur) VALUES (1);\nINSERT INTO mesures(valeur) VALUES (2);\nCOMMIT;'),
('Limites du typage dynamique',"SQLite associe un type à chaque valeur et une affinité à la colonne ; une table STRICT applique des contraintes de types supplémentaires.",'CREATE TABLE exemple (id INTEGER PRIMARY KEY, nom TEXT NOT NULL) STRICT;'),
])
add('PostgreSQL','Compléments pratiques',[
('RETURNING',"RETURNING renvoie des valeurs des lignes modifiées ; l’outil de données peut imposer ses propres limites sur les modifications.",'INSERT INTO personnes(nom) VALUES (\'Ada\') RETURNING id;'),
('JSONB',"jsonb permet de stocker et interroger des documents JSON structurés ; ->> extrait une valeur textuelle.","SELECT profil->>'ville' FROM personnes;"),
('EXPLAIN ANALYZE',"EXPLAIN ANALYZE exécute réellement la requête pour mesurer son plan ; prenez des précautions particulières avec les modifications.",'EXPLAIN ANALYZE SELECT * FROM personnes WHERE id = 1;'),
('Rôles et privilèges',"Accordez seulement les droits nécessaires au rôle utilisé par une application ; adaptez noms et schémas à votre serveur.",'GRANT SELECT ON TABLE personnes TO lecteur;'),
])
add('MySQL / MariaDB','Compléments pratiques',[
('Transactions et moteur de stockage',"Les transactions dépendent du moteur de stockage : InnoDB les prend en charge ; certaines commandes DDL entraînent une validation implicite.",'START TRANSACTION;\nUPDATE comptes SET solde = 0 WHERE id = 1;\nROLLBACK;'),
('EXPLAIN',"EXPLAIN présente le plan estimé et aide à observer l’usage possible d’index ; la sortie varie selon le serveur et sa version.",'EXPLAIN SELECT * FROM personnes WHERE id = 1;'),
('utf8mb4',"utf8mb4 permet de stocker les caractères Unicode sur quatre octets ; vérifiez aussi la collation et la configuration de connexion.",'CREATE TABLE messages (texte VARCHAR(200)) CHARACTER SET utf8mb4;'),
('Sauvegarde avant modification',"Une sauvegarde doit être adaptée au serveur, vérifiée et protégée ; ne placez pas de mot de passe dans l’historique de commandes.",'mysqldump --user=utilisateur --password base > sauvegarde.sql'),
])
add('CSV / TSV','Compléments pratiques',[
('Champs contenant un séparateur',"Un champ contenant un séparateur ou un saut de ligne doit généralement être encadré de guillemets ; un guillemet interne est doublé.",'nom,remarque\n"Ada","bonjour, monde"\n"Grace","elle dit ""oui"""'),
('Séparateurs et encodage',"Le CSV n’impose pas un séparateur universel ; TSV utilise des tabulations. Vérifiez aussi l’encodage avant d’importer.",'nom;score\nAda;42'),
('Formules dans les tableurs',"Certains tableurs interprètent comme formule une cellule commençant par =, +, - ou @. Traitez les données non fiables avant export et partage.",'nom,valeur\nAlice,42'),
('Nombres et zéros initiaux',"Un tableur peut transformer un identifiant comme 0012 en nombre 12. Importez explicitement la colonne comme texte si ces zéros comptent.",'identifiant\n0012'),
])
add('JSON','Compléments pratiques',[
('Valeurs JSON valides',"JSON accepte objets, tableaux, chaînes, nombres, true, false et null ; les commentaires et virgules finales ne font pas partie du format standard.",'{"nom":"Ada","actif":true,"score":null}'),
('Échapper une chaîne',"Un guillemet ou une barre oblique inverse dans une chaîne doit être échappé. Utilisez un encodeur JSON plutôt que la concaténation manuelle.",'{"message":"Elle dit \\"bonjour\\""}'),
('Clés dupliquées',"Le comportement des consommateurs face aux clés dupliquées varie ; évitez-les, surtout avant une transformation en vue tableau.",'{"id":1,"nom":"Ada"}'),
('Grands entiers',"Certains environnements JavaScript ne représentent pas exactement tous les grands entiers. Encodez les identifiants très grands comme chaînes lorsque le contrat le permet.",'{"identifiant":"9007199254740993"}'),
])
add('Données · Studio','Compléments pratiques',[
('Enregistrer et détecter un conflit',"L’enregistrement des données est explicite. L’outil détecte certains changements externes, mais ne remplace pas une sauvegarde ni une opération atomique entre processus.",'Ouvrir une source → modifier → Enregistrer → confirmer'),
('Connexion sécurisée',"Pour un serveur distant, utilisez TLS avec vérification du certificat ; configurez le certificat d’autorité si nécessaire et utilisez un compte à droits minimaux.",'PostgreSQL / MySQL → Connexion serveur → TLS activé'),
('Clé primaire et grille',"La grille doit identifier chaque ligne pour la modifier sûrement ; une table sans clé primaire reste en lecture seule.",'CREATE TABLE clients (id INTEGER PRIMARY KEY, nom TEXT NOT NULL);'),
('Requêtes prudentes',"Le rollback ne peut pas annuler tous les effets externes et certaines instructions DDL. Testez sur une copie et limitez les résultats volumineux.",'SELECT * FROM clients LIMIT 100;'),
])
assert len({a['id'] for a in articles})==len(articles)
out=Path(__file__).with_name('aide-complementaire.js');out.write_text('/* Fiches supplémentaires : source aide-complementaire.py. */\nwindow.PS_EXTRA_HELP='+json.dumps({'articles':articles},ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf8')
print('Fiches complémentaires:',len(articles),dict(Counter(a['lang'] for a in articles)))
