"""Catalogue hors ligne : Swift et Kotlin. Génère aide-swift-kotlin.js.

Même contrat que aide_cinq_langages.py : le fichier produit AJOUTE ses fiches à
window.PS_LANG_HELP sans écraser celles des autres langages, donc l'ordre de
chargement dans index.html n'a pas d'importance.

Les fiches décrivent le comportement réel de Pascal Studio 3.6.0 :
* Swift — l'analyse pendant la saisie appelle swiftc -typecheck, qui vérifie
  types et syntaxe sans jamais exécuter le programme ; la compilation produit un
  binaire nommé swift-<empreinte>.
* Kotlin — la compilation produit kotlin-<empreinte>.jar lancé par la JVM.
  L'analyse pendant la saisie est volontairement désactivée : démarrer kotlinc à
  chaque frappe coûterait plusieurs secondes.
* Aucun des deux n'est pris en charge par le débogueur intégré.
"""
import json
from collections import Counter
from pathlib import Path

articles = []


def intro(lang, texte):
    articles.append(dict(id='sk-%s-intro' % lang.lower(), lang=lang, group='Introduction',
                         title='Utilité et présentation', summary='', intro=True,
                         blocks=[dict(title='', text=texte, code='')]))


def add(lang, group, rows):
    for title, text, code in rows:
        articles.append(dict(
            id='sk-%s-%d' % (lang.lower(), len(articles)), lang=lang, group=group, title=title,
            summary=text,
            blocks=[dict(title='Explication', text=text, code=''),
                    dict(title='Exemple',
                         text='Exemple à adapter au contexte ; certains extraits supposent '
                              'des imports ou une fonction englobante.',
                         code=code)]))


# --------------------------------------------------------------------- Swift
intro('Swift',
      "Swift sert aux applications Apple (iOS, iPadOS, macOS, watchOS, tvOS), aux services "
      "côté serveur avec Vapor, aux outils en ligne de commande et au calcul avec Swift for "
      "TensorFlow ou les bindings scientifiques. Son typage fort, son inférence et le "
      "traitement explicite de l'absence de valeur en font un langage sûr à lire comme à "
      "écrire.\n\n"
      "Présenté par Apple en 2014, Swift est open source depuis 2015 et piloté depuis par un "
      "projet communautaire ; il existe donc officiellement sous Linux. Ces fiches visent "
      "Swift 5.9 et Swift 6, dont la principale nouveauté est le contrôle strict de la "
      "concurrence.\n\n"
      "Dans cet IDE, un fichier .swift est vérifié pendant la saisie avec swiftc -typecheck : "
      "la syntaxe et les types sont contrôlés, le programme n'est jamais exécuté par cette "
      "vérification. Le bouton de compilation produit un binaire exécutable. Les paquets "
      "SwiftPM et leurs dépendances ne sont pas construits par ce bouton : utilisez swift "
      "build dans un terminal. Installation sur Debian : sudo apt install swiftlang. Aucun "
      "débogueur intégré ; swift-lldb est fourni par le paquet si vous voulez l'utiliser dans "
      "le terminal. La référence n'est pas exhaustive : consultez "
      "https://docs.swift.org/swift-book/ et https://developer.apple.com/documentation/swift.")

add('Swift', 'Bases et types', [
    ('print et commentaires', "print écrit sur la sortie standard. // commence un commentaire "
     "d'une ligne ; /* … */ en délimite un bloc, et ces blocs peuvent s'imbriquer.",
     '// TODO: compléter\nprint("Bonjour Swift")\n/* commentaire\n   sur plusieurs lignes */'),
    ('let et var', "let crée une constante : sa valeur ne change plus. var crée une variable. "
     "Préférez let partout où c'est possible, le compilateur signale le reste.",
     'let nom = "Ada"\nvar age = 36\nage += 1'),
    ('Inférence de type', "Le type est déduit de la valeur initiale. On peut aussi l'écrire "
     "explicitement avec deux-points, ce qui est nécessaire quand aucune valeur n'est fournie.",
     'let entier = 42            // Int\nlet reel = 2.5              // Double\nlet texte: String = "Ada"'),
    ('Int, Double et Bool', "Int est l'entier par défaut, Double le flottant par défaut. Les "
     "conversions entre types numériques sont toujours explicites : Swift ne mélange jamais "
     "Int et Double tout seul.",
     'let n = 7\nlet x = 1.5\nlet total = Double(n) + x\nlet pret: Bool = true'),
    ('String et interpolation', "Une chaîne s'écrit entre guillemets doubles. \\( … ) insère "
     "une expression dans la chaîne. Les chaînes sont des valeurs : les affecter copie leur "
     "contenu.",
     'let nom = "Ada"\nprint("Bonjour \\(nom), \\(nom.count) lettres")'),
    ('Chaînes multilignes', "Trois guillemets ouvrent une chaîne multiligne. L'indentation de "
     "la ligne de clôture est retirée de toutes les lignes, ce qui permet d'aligner le texte "
     "dans le code.",
     'let texte = """\n    ligne 1\n    ligne 2\n    """\nprint(texte)'),
    ('Character', "Character représente un caractère Unicode complet, éventuellement composé de "
     "plusieurs scalaires. Les apostrophes l'entourent.",
     'let lettre: Character = "é"\nlet emoji: Character = "👩‍💻"'),
    ('Optionals', "Un type suivi de ? admet l'absence de valeur, notée nil. Un optional doit "
     "être déballé avant usage : c'est la principale protection de Swift contre les accès "
     "invalides.",
     'var trouve: Int? = nil\ntrouve = 42\nif trouve != nil { print(trouve!) }   // ! à éviter'),
    ('if let et guard let', "if let déballle un optional pour la durée du bloc. guard let "
     "vérifie une condition et sort sinon ; la valeur déballée reste utilisable après le "
     "guard, ce qui évite d'imbriquer les blocs.",
     'let saisie: String? = "42"\nif let texte = saisie, let n = Int(texte) {\n    print(n * 2)\n}\nguard let t = saisie else { print("absent"); }\nprint(t)'),
    ('nil et ??', "L'opérateur ?? fournit une valeur de repli quand l'optional est nil. "
     "Il évite la plupart des ! forcés.",
     'let nom: String? = nil\nprint("Bonjour " + (nom ?? "inconnu"))'),
    ('Tuple', "Un tuple regroupe plusieurs valeurs, éventuellement nommées. Pratique pour "
     "renvoyer deux résultats sans définir de type.",
     'let point = (x: 3, y: 4)\nprint(point.x, point.y)\nlet (a, b) = (1, 2)'),
    ('Tableaux', "Un tableau est une valeur ordonnée et typée. [] le crée vide, append ajoute "
     "en fin, count donne la taille. Les indices commencent à 0.",
     'var nombres = [1, 2, 3]\nnombres.append(4)\nprint(nombres.count, nombres[0])\nlet vide: [Int] = []'),
    ('Dictionnaires', "Un dictionnaire associe des clés à des valeurs. La lecture renvoie un "
     "optional : nil signifie « clé absente », ce qui distingue l'absence d'une valeur nil "
     "stockée.",
     'var ages = ["Ada": 36, "Alan": 41]\nages["Grace"] = 45\nprint(ages["Ada"] ?? -1)\nages["Alan"] = nil'),
    ('Ensembles', "Set stocke des valeurs uniques sans ordre. Il sert aux tests d'appartenance "
     "rapides et aux opérations union, intersection et soustraction.",
     'let a: Set<Int> = [1, 2, 3]\nlet b: Set<Int> = [3, 4]\nprint(a.intersection(b), a.union(b))'),
])

add('Swift', 'Contrôle, fonctions et types', [
    ('if et else', "La condition doit être un Bool : Swift n'accepte ni 0 ni nil comme "
     "faux. else if enchaîne les cas.",
     'let note = 12\nif note >= 16 { print("très bien") }\nelse if note >= 10 { print("admis") }\nelse { print("ajourné") }'),
    ('switch', "switch doit couvrir tous les cas, d'où l'usage fréquent de default. Il n'y a "
     "pas de passage au cas suivant implicite. Un case peut filtrer avec where et lier des "
     "valeurs.",
     'let point = (2, 0)\nswitch point {\ncase (0, 0): print("origine")\ncase (let x, 0): print("sur l’axe X en \\(x)")\ncase (_, let y) where y > 0: print("au-dessus")\ndefault: print("ailleurs")\n}'),
    ('for-in', "for-in parcourt une séquence, un intervalle ou un dictionnaire. stride sert "
     "aux pas différents de 1, et l'intervalle fermé s'écrit ...",
     'for i in 1...3 { print(i) }\nfor i in stride(from: 0, through: 10, by: 5) { print(i) }\nfor (cle, valeur) in ["a": 1] { print(cle, valeur) }'),
    ('while et repeat', "while teste la condition avant chaque tour ; repeat…while l'exécute au "
     "moins une fois. break sort de la boucle, continue passe au tour suivant.",
     'var n = 3\nwhile n > 0 { print(n); n -= 1 }\nrepeat { n += 1 } while n < 2'),
    ('Fonctions', "func définit une fonction. Les paramètres portent une étiquette externe "
     "lisible à l'appel ; _ la supprime. -> annonce le type de retour.",
     'func saluer(_ nom: String, fois: Int = 1) -> String {\n    return String(repeating: "Bonjour \\(nom) ", count: fois)\n}\nprint(saluer("Ada", fois: 2))'),
    ('Plusieurs valeurs et variadique', "Une fonction peut renvoyer un tuple. Un paramètre "
     "variadique ... accepte zéro, un ou plusieurs arguments et se voit comme un tableau.",
     'func extremes(_ xs: Int...) -> (min: Int, max: Int)? {\n'
     '    guard let premier = xs.first else { return nil }\n'
     '    var lo = premier, hi = premier\n'
     '    for x in xs { lo = min(lo, x); hi = max(hi, x) }\n'
     '    return (lo, hi)\n'
     '}\n'
     'if let r = extremes(3, 1, 4) { print(r.min, r.max) }'),
    ('Closures', "Une closure est une fonction anonyme. { x in … } nomme le paramètre ; "
     "trailing closure permet de sortir le dernier argument fonction du parenthésage.",
     'let carre = { (x: Int) -> Int in x * x }\nprint(carre(4))\nlet nombres = [3, 1, 2]\nprint(nombres.sorted { $0 < $1 })'),
    ('struct', "struct définit un type valeur : chaque affectation copie. C'est le type à "
     "choisir par défaut en Swift. mutating autorise une méthode à modifier ses propres "
     "champs.",
     'struct Point {\n    var x: Double\n    var y: Double\n    mutating func deplacer(dx: Double) { x += dx }\n}\nvar p = Point(x: 1, y: 2)\np.deplacer(dx: 3)\nprint(p.x)'),
    ('class et référence', "class définit un type référence : plusieurs noms peuvent désigner "
     "la même instance. init est l'initialiseur, deinit le finaliseur.",
     'class Compteur {\n    private(set) var valeur = 0\n    init(valeur: Int = 0) { self.valeur = valeur }\n    func incrementer() { valeur += 1 }\n}\nlet c = Compteur(); c.incrementer(); print(c.valeur)'),
    ('enum et valeurs associées', "enum définit un choix fini de cas. Chaque cas peut porter "
     "des valeurs associées, et un type brut permet une conversion depuis un Int ou un String.",
     'enum Resultat {\n    case succes(valeur: Int)\n    case echec(code: String)\n}\nlet r = Resultat.echec(code: "E42")\nswitch r {\ncase .succes(let v): print("ok \\(v)")\ncase .echec(let c): print("échec \\(c)")\n}'),
    ('protocol', "protocol décrit des exigences (méthodes, propriétés) sans les implémenter. "
     "Un type peut en adopter plusieurs. some Protocol désigne une valeur opaque respectant "
     "le protocole.",
     'protocol Decrivable {\n    var description: String { get }\n}\nstruct Livre: Decrivable {\n    let titre: String\n    var description: String { "Livre : \\(titre)" }\n}\nfunc afficher(_ d: some Decrivable) { print(d.description) }\nafficher(Livre(titre: "Swift"))'),
    ('extension', "extension ajoute des méthodes ou des conformances à un type existant, y "
     "compris aux types de la bibliothèque standard, sans toucher à sa définition.",
     'extension Int {\n    var carre: Int { self * self }\n    func fois(_ corps: () -> Void) { for _ in 0..<self { corps() } }\n}\nprint(5.carre)\n3.fois { print("x") }'),
    ('Erreurs : throw et do-catch', "Une fonction qui peut échouer est marquée throws et son "
     "appel est précédé de try. do-catch intercepte l'erreur. try? convertit l'échec en nil, "
     "try! l'interdit.",
     'enum ErreurLecture: Error { case fichierAbsent(String) }\nfunc lire(_ chemin: String) throws -> String {\n    guard !chemin.isEmpty else { throw ErreurLecture.fichierAbsent(chemin) }\n    return "contenu"\n}\ndo { print(try lire("a.txt")) }\ncatch ErreurLecture.fichierAbsent(let c) { print("absent : \\(c)") }\ncatch { print(error) }'),
])

add('Swift', 'Bibliothèque, collections et outils', [
    ('map et compactMap', "map transforme chaque élément. compactMap transforme puis écarte "
     "les nil, ce qui combine conversion et filtrage.",
     'let nombres = ["1", "x", "3"]\nlet entiers = nombres.compactMap { Int($0) }\nprint(entiers, nombres.map { $0.count })'),
    ('filter et reduce', "filter garde les éléments vérifiant une condition ; reduce les "
     "combine en une seule valeur à partir d'un accumulateur.",
     'let xs = [1, 2, 3, 4]\nprint(xs.filter { $0 % 2 == 0 })\nprint(xs.reduce(0, +))'),
    ('sorted et first', "sorted renvoie un nouveau tableau trié ; sort trie sur place une "
     "variable. first et last renvoient des optionals, donc nil sur un tableau vide.",
     'var xs = [3, 1, 2]\nprint(xs.sorted())\nxs.sort()\nprint(xs.first ?? -1)'),
    ('firstIndex et contains', "firstIndex(of:) renvoie l'indice optionnel d'une valeur ; "
     "contains teste l'appartenance. Les deux existent aussi avec une closure.",
     'let xs = ["a", "b"]\nprint(xs.firstIndex(of: "b") ?? -1)\nprint(xs.contains { $0 == "a" })'),
    ('Méthodes de String', "hasPrefix, hasSuffix, split, joined et trimmingCharacters couvrent "
     "l'essentiel du traitement de texte. Foundation fournit la plupart des dernières.",
     'import Foundation\nlet s = "  Ada Lovelace  "\nlet propre = s.trimmingCharacters(in: .whitespaces)\nprint(propre.split(separator: " "), propre.hasPrefix("Ada"))'),
    ('FileManager', "FileManager lit et écrit des fichiers, crée des dossiers et teste leur "
     "existence. Les méthodes sont lançantes : elles s'utilisent avec try.",
     'import Foundation\nlet fm = FileManager.default\nlet url = URL(fileURLWithPath: "notes.txt")\ntry? "bonjour".write(to: url, atomically: true, encoding: .utf8)\nprint((try? String(contentsOf: url, encoding: .utf8)) ?? "vide")'),
    ('CommandLine et exit', "CommandLine.arguments contient le chemin du programme puis les "
     "arguments. exit termine avec le code choisi.",
     'import Foundation\nfor (i, a) in CommandLine.arguments.enumerated() { print(i, a) }\nexit(0)'),
    ('JSON', "JSONEncoder et JSONDecoder traduisent entre JSON et types Codable. Un type est "
     "Codable dès qu'il est Decodable et Encodable, ce qui suffit pour les structures simples.",
     'import Foundation\nstruct Personne: Codable { let nom: String; let age: Int }\nlet data = try JSONEncoder().encode(Personne(nom: "Ada", age: 36))\nprint(String(data: data, encoding: .utf8) ?? "")\nlet relu = try JSONDecoder().decode(Personne.self, from: data)\nprint(relu.nom)'),
    ('async, await et Task', "Une fonction async peut suspendre sans bloquer de thread ; await "
     "marque le point de suspension. Task lance un travail concurrent. En Swift 6, l'isolement "
     "des acteurs est vérifié à la compilation.",
     'import Foundation\nfunc attendre(_ secondes: UInt64) async {\n    try? await Task.sleep(nanoseconds: secondes * 1_000_000_000)\n}\nlet t = Task { await attendre(1); print("fini") }\nawait t.value'),
    ('acteurs', "actor isole un état mutable : ses méthodes sont appelées avec await depuis "
     "l'extérieur, ce qui supprime les courses aux données sur cet état.",
     'actor Compteur {\n    private var n = 0\n    func incrementer() { n += 1 }\n    var valeur: Int { n }\n}\nlet c = Compteur()\nawait c.incrementer()\nprint(await c.valeur)'),
    ('Attributs et directives', "@available conditionne l'usage d'une API à une version. "
     "#if active une compilation conditionnelle. @_silgen_name et les attributs de propriété "
     "(@Published, @State) dépendent du cadre utilisé.",
     '@available(macOS 12, iOS 15, *)\nfunc nouveaute() { print("récent") }\n#if os(Linux)\nprint("Linux")\n#else\nprint("autre système")\n#endif'),
    ('Commandes swiftc et swift', "swiftc -typecheck vérifie sans produire de fichier ; "
     "swiftc -O compile en mode optimisé ; swift run exécute un paquet SwiftPM. swift "
     "build construit le paquet courant.",
     'swiftc -typecheck main.swift\nswiftc -O main.swift -o programme\n./programme\nswift build && swift run'),
])

# -------------------------------------------------------------------- Kotlin
intro('Kotlin',
      "Kotlin sert au développement Android — c'est le langage recommandé par Google depuis "
      "2019 —, aux services côté serveur avec Ktor ou Spring Boot, aux scripts .kts et à la "
      "compilation multiplateforme avec Kotlin Multiplatform. Il tourne sur la machine "
      "virtuelle Java et interopère avec les bibliothèques Java existantes.\n\n"
      "Conçu chez JetBrains à partir de 2011, stable en 1.0 depuis 2016, Kotlin vise la "
      "concision, la sécurité contre les erreurs de pointeur nul et l'inférence de types, tout "
      "en restant entièrement compatible avec l'écosystème Java.\n\n"
      "Dans cet IDE, un fichier .kt est compilé par kotlinc en kotlin-<empreinte>.jar, que la "
      "JVM exécute ensuite ; un fichier .kts est lancé comme script avec kotlinc -script. "
      "L'analyse pendant la saisie est volontairement désactivée pour ce langage : démarrer la "
      "JVM à chaque frappe coûterait plusieurs secondes, la vérification se fait donc à la "
      "compilation. Les projets Gradle ou Maven et leurs dépendances ne sont pas construits "
      "par ce bouton : utilisez le terminal. Installation sur Debian : sudo apt install "
      "kotlin, avec une JVM (sudo apt install default-jre-headless). Aucun débogueur intégré. "
      "La référence n'est pas exhaustive : consultez https://kotlinlang.org/docs/home.html.")

add('Kotlin', 'Bases et types', [
    ('main et println', "fun main est le point d'entrée. println écrit une ligne, print "
     "n'ajoute pas de retour. Un fichier .kts s'exécute comme script sans fonction main.",
     'fun main() {\n    println("Bonjour Kotlin")\n}'),
    ('val et var', "val crée une référence immuable, comparable à final en Java ; var crée une "
     "référence réassignable. Préférez val par défaut. L'objet pointé par un val peut rester "
     "modifiable.",
     'val nom = "Ada"\nvar age = 36\nage += 1'),
    ('Inférence de type', "Le type est déduit de l'initialisation. On peut l'écrire avec "
     "deux-points, ce qui est requis pour une déclaration sans valeur initiale.",
     'val entier = 42           // Int\nval reel = 2.5             // Double\nval texte: String = "Ada"\nvar tardif: Int'),
    ('Int, Long, Double, Boolean', "Les types numériques ne se convertissent pas "
     "implicitement, même de Int vers Long : toLong(), toDouble() etc. sont explicites. "
     "Les littéraux acceptent _ comme séparateur.",
     'val n: Int = 1_000\nval grand: Long = n.toLong()\nval x: Double = 1.5\nval pret: Boolean = true'),
    ('Char et String', "Un caractère utilise des apostrophes, une chaîne des guillemets. "
     "Une chaîne est immuable ; + concatène et les méthodes renvoient de nouvelles valeurs.",
     'val lettre: Char = \'é\'\nval nom: String = "Ada"\nprintln(nom.uppercase() + lettre)'),
    ('Gabarits de chaîne', "$nom insère une variable, ${expression} insère un calcul. Les "
     "chaînes brutes entre triples guillemets conservent les retours à la ligne et n'échappent "
     "rien.",
     'val nom = "Ada"\nval age = 36\nprintln("$nom a $age ans, dans 10 ans : ${age + 10}")\nval brut = """\n  ligne 1\n  ligne 2\n""".trimIndent()'),
    ('Nullabilité', "Un type suivi de ? accepte null. L'appel ?. renvoie null si le receveur "
     "est null, ?: fournit un repli, et !! force en levant une exception en cas de null. C'est "
     "la principale différence avec Java.",
     'var trouve: Int? = null\ntrouve = 42\nprintln(trouve?.times(2))\nval nom: String? = null\nprintln(nom ?: "inconnu")'),
    ('Tableaux et listes', "arrayOf crée un tableau de taille fixe, listOf une liste immuable "
     "et mutableListOf une liste modifiable. Les indices commencent à 0.",
     'val tableau = arrayOf(1, 2, 3)\nval liste = listOf("a", "b")\nval modifiable = mutableListOf(1)\nmodifiable.add(2)\nprintln(tableau[0], liste.size, modifiable)'),
    ('Maps et sets', "mapOf et setOf créent des collections immuables ; mutableMapOf et "
     "mutableSetOf leurs équivalents modifiables. La lecture d'une clé absente renvoie null.",
     'val ages = mapOf("Ada" to 36, "Alan" to 41)\nval modifiable = mutableMapOf<String, Int>()\nmodifiable["Grace"] = 45\nprintln(ages["Ada"], modifiable.keys)'),
    ('Plages et progression', ".. crée une plage inclusive, until exclut la borne haute, "
     "downTo inverse et step change le pas. Les plages servent aussi bien aux boucles qu'aux "
     "tests d'appartenance.",
     'for (i in 1..3) print(i)\nfor (i in 0 until 10 step 5) print(i)\nfor (i in 5 downTo 1) print(i)\nprintln(2 in 1..3)'),
    ('data class', "data class génère equals, hashCode, toString, copy et les destructurations "
     "à partir des seules propriétés du constructeur. C'est le moyen idiomatique de porter des "
     "données.",
     'data class Point(val x: Int, val y: Int)\nval p = Point(1, 2)\nval q = p.copy(x = 9)\nval (a, b) = q\nprintln(p, q, a, b)'),
    ('sealed class et enum class', "enum class liste des cas sans données ; sealed class "
     "restreint une hiérarchie à un ensemble connu de sous-types, ce qui permet au when "
     "d'être exhaustif sans branche else.",
     'enum class Couleur { ROUGE, VERT }\nsealed class Resultat {\n    data class Succes(val valeur: Int) : Resultat()\n    data class Echec(val code: String) : Resultat()\n}\nval r: Resultat = Resultat.Echec("E42")'),
])

add('Kotlin', 'Contrôle, fonctions et objets', [
    ('if comme expression', "if renvoie une valeur quand ses branches en produisent une, ce "
     "qui remplace l'opérateur ternaire de Java. Les conditions doivent être des Boolean.",
     'val note = 12\nval mention = if (note >= 16) "très bien" else if (note >= 10) "admis" else "ajourné"\nprintln(mention)'),
    ('when', "when remplace switch et accepte des valeurs, des plages, des types et des "
     "conditions arbitraires. Sur un sealed class il est exhaustif sans else.",
     'val x: Any = 3\nwhen (x) {\n    1, 2 -> println("petit")\n    in 3..9 -> println("dans la plage")\n    is String -> println("texte")\n    else -> println("autre")\n}'),
    ('for et while', "for parcourt toute collection itérable ; withIndex donne l'indice, "
     "indices les positions. while et do…while fonctionnent comme ailleurs, break et exit "
     "inclus.",
     'for ((i, v) in listOf("a", "b").withIndex()) println("$i -> $v")\nvar n = 3\nwhile (n > 0) { println(n); n-- }\ndo { n++ } while (n < 2)'),
    ('Fonctions', "fun définit une fonction. Les paramètres peuvent avoir des valeurs par "
     "défaut et être passés par nom. Une fonction d'une seule expression s'écrit avec =, le "
     "type de retour étant alors déduit.",
     'fun saluer(nom: String, fois: Int = 1): String = "Bonjour $nom ".repeat(fois)\nfun somme(vararg xs: Int): Int = xs.sum()\nprintln(saluer("Ada"), saluer(nom = "Alan", fois = 2), somme(1, 2, 3))'),
    ('Lambdas et it', "Une lambda s'écrit entre accolades. Un seul paramètre non nommé devient "
     "it. La dernière expression est la valeur renvoyée. Une lambda peut être passée hors "
     "parenthèses quand c'est le dernier paramètre.",
     'val carre = { x: Int -> x * x }\nprintln(carre(4))\nval nombres = listOf(3, 1, 2)\nprintln(nombres.map { it * 2 })\nprintln(nombres.sortedBy { it })'),
    ('Fonctions d\'extension', "Une fonction d'extension ajoute une méthode à un type existant "
     "sans le modifier ni hériter de lui. this désigne le receveur dans le corps.",
     'fun Int.carre(): Int = this * this\nfun String.crie(): String = uppercase() + "!"\nprintln(5.carre(), "ada".crie())'),
    ('Fonctions de portée', "let, run, with, apply et also exécutent un bloc sur un objet. "
     "let et run renvoient le résultat du bloc et exposent it ou this ; apply et also "
     "renvoient l'objet, le premier avec this, le second avec it.",
     'val liste = mutableListOf(1).apply { add(2) }\nval longueur = "Ada".let { it.length }\nval configure = StringBuilder().also { it.append("x") }\nprintln(liste, longueur, configure)'),
    ('Classes et héritage', "Une classe est finale par défaut : open autorise l'héritage et la "
     "redéfinition. Le constructeur primaire suit le nom ; init et les propriétés initialisées "
     "s'exécutent dans l'ordre.",
     'open class Animal(val nom: String) {\n    open fun crier(): String = "..."\n}\nclass Chien(nom: String) : Animal(nom) {\n    override fun crier(): String = "Waf"\n}\nprintln(Chien("Rex").crier())'),
    ('object et companion', "object déclare un singleton. companion object porte les membres "
     "statiques d'une classe ; ses fonctions factory sont souvent préférées aux constructeurs "
     "surchargés.",
     'object Registre {\n    val elements = mutableListOf<String>()\n}\nclass Mesure private constructor(val valeur: Int) {\n    companion object {\n        fun depuis(texte: String): Mesure? = texte.toIntOrNull()?.let { Mesure(it) }\n    }\n}\nRegistre.elements.add("a")\nprintln(Mesure.depuis("42")?.valeur)'),
    ('Interfaces et propriétés', "Une interface peut fournir des implémentations par défaut et "
     "des propriétés calculées. Une classe peut en implémenter plusieurs et doit lever les "
     "ambiguïtés avec super@Nom.",
     'interface Decrivable {\n    val titre: String\n    fun decrire(): String = "Décrit $titre"\n}\nclass Livre(override val titre: String) : Decrivable\nprintln(Livre("Kotlin").decrire())'),
    ('Délégation', "by délègue l'implémentation d'une interface à un objet, ou la gestion "
     "d'une propriété à un délégué. lazy calcule une valeur au premier accès ; observable "
     "notifie les changements.",
     'class SonParDefaut { fun jouer() = println("son") }\nclass Lecteur(son: SonParDefaut) : SonParDefaut() by son\nval lourd: Int by lazy { println("calcul"); 42 }\nprintln(lourd)'),
    ('Exceptions et ressources', "try-catch-finally gère les erreurs ; use ferme "
     "automatiquement toute ressource Closeable. Rien n'est vérifié à la compilation : aucune "
     "exception n'est « checked » en Kotlin.",
     'val n = try { "abc".toInt() } catch (e: NumberFormatException) { 0 }\nprintln(n)\njava.io.File("notes.txt").bufferedReader().use { println(it.readText()) }'),
])

add('Kotlin', 'Bibliothèque, collections et outils', [
    ('map, filter et fold', "map transforme, filter garde, fold combine avec un accumulateur "
     "initial. Les versions Lazy de ces opérations sur les grandes séquences s'obtiennent avec "
     "asSequence().",
     'val xs = listOf(1, 2, 3, 4)\nprintln(xs.map { it * 2 })\nprintln(xs.filter { it % 2 == 0 })\nprintln(xs.fold(0) { acc, v -> acc + v })'),
    ('sortedBy et groupBy', "sortedBy trie selon une clé calculée, sortedByDescending inverse. "
     "groupBy produit une Map de listes, associateBy une Map de valeurs.",
     'data class P(val nom: String, val age: Int)\nval gens = listOf(P("Ada", 36), P("Alan", 41), P("Grace", 45))\nprintln(gens.sortedBy { it.age }.first())\nprintln(gens.groupBy { it.age >= 40 })'),
    ('first, single et find', "first et last lèvent une exception sur une collection vide, "
     "firstOrNull et lastOrNull renvoient null. find cherche le premier élément vérifiant une "
     "condition, any, all et none testent des prédicats.",
     'val xs = listOf(1, 2, 3)\nprintln(xs.firstOrNull { it > 2 })\nprintln(xs.any { it > 2 }, xs.all { it > 0 }, xs.none { it > 9 })'),
    ('Méthodes de String', "split, joinToString, substring, replace, trim et toIntOrNull "
     "couvrent l'essentiel du traitement de texte. Les fonctions toXxxOrNull évitent les "
     "exceptions sur une saisie invalide.",
     'val s = "  a,b,c  "\nprintln(s.trim().split(","))\nprintln(listOf("x", "y").joinToString(" - "))\nprintln("42".toIntOrNull(), "abc".toIntOrNull())'),
    ('Construire des collections', "buildList et buildString exécutent un bloc sur une "
     "collection modifiable puis renvoient le résultat immuable, ce qui évite les variables "
     "intermédiaires.",
     'val xs = buildList { add(1); add(2); addAll(listOf(3, 4)) }\nval texte = buildString { append("a"); append(1) }\nprintln(xs, texte)'),
    ('Lecture et écriture de fichiers', "File fournit readText, readLines, writeText et "
     "appendText. use ferme le flux. bufferedWriter convient aux écritures volumineuses.",
     'val f = java.io.File("notes.txt")\nf.writeText("bonjour\\n")\nf.appendText("ligne 2\\n")\nprintln(f.readLines())\nf.bufferedWriter().use { it.write("remplace\\n") }'),
    ('readLine et arguments', "readlnOrNull lit une ligne depuis l'entrée standard et renvoie "
     "null en fin de flux. args de la fonction main contient les arguments, sans le nom du "
     "programme. exitProcess fixe le code de retour.",
     'fun main(args: Array<String>) {\n    println("arguments : ${args.toList()}")\n    print("Nom ? ")\n    val ligne = readlnOrNull()\n    println("Bonjour ${ligne ?: "inconnu"}")\n    kotlin.system.exitProcess(0)\n}'),
    ('Interopérabilité Java', "Toute classe Java est utilisable directement, et le code Kotlin "
     "compile vers du bytecode Java. Les types Java sans annotation apparaissent comme des "
     "« types plateforme » : leur nullabilité n'est pas vérifiée.",
     'val liste = java.util.ArrayList<String>()\nliste.add("a")\nval maintenant = java.time.LocalDateTime.now()\nprintln(liste, maintenant.year)'),
    ('Coroutines', "suspend marque une fonction qui peut suspendre sans bloquer de thread. "
     "runBlocking attend la fin dans un programme court ; launch et async organisent le travail "
     "concurrent. La bibliothèque kotlinx-coroutines doit être sur le classpath.",
     'import kotlinx.coroutines.*\nfun main() = runBlocking {\n    launch { delay(10); println("tâche") }\n    val reponse = async { delay(5); 42 }\n    println("résultat : ${reponse.await()}")\n}'),
    ('Scripts .kts', "Un fichier .kts s'exécute directement, sans fonction main ni "
     "compilation en jar. Il sert aux tâches d'automatisation et aux feuilles de calcul "
     "scriptées.",
     'val xs = listOf(1, 2, 3)\nprintln("somme = ${xs.sum()}")\nprintln(java.io.File(".").listFiles()?.size ?: 0)'),
    ('Commandes kotlinc et kotlin', "kotlinc compile en jar, kotlin l'exécute, kotlinc -script "
     "lance un .kts. -include-runtime produit un jar autonome. Le premier lancement démarre la "
     "JVM : comptez quelques secondes.",
     'kotlinc main.kt -include-runtime -d programme.jar\njava -jar programme.jar\nkotlinc -script calcul.kts'),
    ('Gradle et dépendances', "Un projet réel se construit avec Gradle ou Maven, pas avec le "
     "bouton de compilation de l'IDE. gradle build compile et teste ; les dépendances "
     "déclarées dans build.gradle.kts sont résolues par Gradle.",
     '// build.gradle.kts\nplugins { kotlin("jvm") version "1.9.0"; application }\napplication { mainClass.set("MainKt") }\n// puis dans le terminal :\n// gradle build && gradle run'),
])

# ------------------------------------------------------------- sortie
assert len({a['id'] for a in articles}) == len(articles), 'identifiants de fiches en double'
resultat = {'languages': ['Swift', 'Kotlin'], 'articles': articles}
sortie = Path(__file__).with_name('aide-swift-kotlin.js')
sortie.write_text(
    '/* Catalogue Swift et Kotlin — source : aide-swift-kotlin.py.\n'
    '   Ajoute ses fiches à window.PS_LANG_HELP sans écraser les autres langages. */\n'
    '(function(){const a=' + json.dumps(resultat, ensure_ascii=False, separators=(',', ':')) + ';'
    'window.PS_LANG_HELP=window.PS_LANG_HELP||{languages:[],articles:[]};'
    'window.PS_LANG_HELP.languages.push(...a.languages);'
    'window.PS_LANG_HELP.articles.push(...a.articles)})();\n',
    encoding='utf8')
print('Aide Swift et Kotlin :', len(articles), 'fiches',
      dict(Counter(a['lang'] for a in articles)), '->', sortie.name)
