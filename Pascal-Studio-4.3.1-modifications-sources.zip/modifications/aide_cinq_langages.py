#!/usr/bin/env python3
"""Catalogue d'aide hors ligne complémentaire pour Pascal Studio 3.3."""
import json,sys
from pathlib import Path
languages={}
def language(id,title,intro,reference):
 d={'title':title,'intro':intro+'\n\nRéférence officielle : '+reference,'sections':[]};languages[id]=d;return d
def section(lang,title,rows):
 lang['sections'].append({'title':title,'articles':[{'title':t,'body':b+'\n\nExemple :\n'+e} for t,b,e in rows]})
f=language('fortran','Fortran',"Fortran sert principalement au calcul scientifique et numérique : simulation, physique, climat et ingénierie. Sa gestion des tableaux et ses compilateurs optimisés en font un choix courant pour les calculs intensifs.\n\nCréé chez IBM dans les années 1950, FORTRAN signifie historiquement Formula Translation. Le langage a beaucoup évolué : les sources modernes en forme libre (.f90…) coexistent avec la forme fixe historique (.f, .for). GNU Fortran détermine la forme d’après l’extension ; les majuscules peuvent activer le préprocesseur. Dans l’IDE la compilation et l’exécution portent sur le fichier sélectionné ; les modules externes et bibliothèques nécessitent une construction adaptée dans le terminal. GDB permet le débogage si installé.", 'https://gcc.gnu.org/onlinedocs/gfortran/')
section(f,'Premiers pas',[
('Programme','program et end program délimitent le programme principal. implicit none impose de déclarer les variables et évite certaines fautes de frappe.', 'program bonjour\n  implicit none\n  print *, "Bonjour !"\nend program bonjour'),
('Commentaires','Le point d’exclamation commence un commentaire en forme libre. Les sources historiques en forme fixe suivent des règles de colonnes différentes.','! TODO: améliorer ce calcul\nprint *, 42'),
('integer','Un entier représente une valeur entière ; kind peut choisir la capacité selon le compilateur.','integer :: nombre = 42\nprint *, nombre'),
('real et précision','real représente un nombre approché ; iso_fortran_env fournit des kinds portables, comme real64.','use iso_fortran_env, only: real64\nreal(real64) :: x = 1.25_real64'),
('logical','Un booléen vaut .true. ou .false. ; les opérateurs logiques comprennent .and., .or. et .not..','logical :: pret = .true.\nif (pret) print *, "Prêt"'),
('character','Une chaîne de longueur fixe peut être raccourcie ou complétée par des espaces ; trim retire les espaces finaux.','character(len=20) :: nom = "Ada"\nprint *, trim(nom)'),
('complex','Un complexe possède une partie réelle et une partie imaginaire ; cmplx construit une valeur.','complex :: z\nz = cmplx(1.0, 2.0)\nprint *, z'),
('Constantes et types dérivés','parameter définit une constante ; type regroupe plusieurs champs accessibles avec %.','type :: point\n  real :: x, y\nend type\ntype(point) :: p\np%x = 2.0')])
section(f,'Structures et procédures',[
('Conditions','if, else if et else sélectionnent des instructions. Les comparaisons modernes utilisent notamment ==, /=, < et >=.','if (n > 0) then\n  print *, "positif"\nelse\n  print *, "nul ou négatif"\nend if'),
('Boucles do','do parcourt une plage, cycle passe à l’itération suivante et exit quitte la boucle.','integer :: i\ndo i = 1, 3\n  print *, i\nend do'),
('Tableaux','Les tableaux Fortran sont généralement indexés à partir de 1 ; les opérations peuvent porter sur tout un tableau.','integer :: a(3) = [1, 2, 3]\nprint *, a * 2'),
('Tableaux allocatables','allocate crée un tableau de taille choisie à l’exécution ; deallocate libère explicitement son stockage.','real, allocatable :: a(:)\nallocate(a(10))\na = 0.0\ndeallocate(a)'),
('Procédures internes','Une function renvoie une valeur ; contains permet de la définir dans le même fichier.','program test\n  implicit none\n  print *, carre(4)\ncontains\n  integer function carre(x)\n    integer, intent(in) :: x\n    carre = x*x\n  end function carre\nend program test'),
('Modules','Un module rassemble des déclarations réutilisables et use les rend accessibles. Les dépendances entre fichiers ne sont pas construites automatiquement par ce bouton.','module mesures\n  implicit none\n  real, parameter :: pi = 3.14159\nend module mesures'),
('Lecture et écriture','read et print effectuent des entrées-sorties. Un programme interactif attend une réponse dans la console intégrée.','integer :: n\nread *, n\nprint *, "Valeur :", n')])
section(f,'Fonctions intrinsèques',[(t,b,e) for t,b,e in [
('abs','Valeur absolue.','print *, abs(-3)'),('sqrt','Racine carrée, en général avec un argument réel non négatif.','print *, sqrt(9.0)'),('sin / cos','Fonctions trigonométriques ; les angles sont exprimés en radians.','print *, sin(0.0), cos(0.0)'),('exp / log','Exponentielle et logarithme naturel ; log exige une valeur réelle positive dans ce cas.','print *, exp(1.0), log(2.0)'),('min / max','Plus petite ou plus grande valeur parmi plusieurs arguments compatibles.','print *, min(2, 5), max(2, 5)'),('sum / size','Somme des éléments et nombre d’éléments d’un tableau.','print *, sum([1,2,3]), size([1,2,3])'),('trim / len_trim','Retire les espaces finaux ou calcule la longueur sans eux.','print *, trim("Ada   "), len_trim("Ada   ")')]])
p=language('perl','Perl',"Perl est particulièrement utile pour les scripts système, la manipulation de texte, les expressions régulières et l’automatisation. Il se prête au traitement rapide de fichiers et de flux.\n\nCréé par Larry Wall en 1987, Perl privilégie des solutions expressives et offre de nombreuses bibliothèques via CPAN. Les sigils $, @ et % indiquent le contexte des variables. Dans l’IDE, l’analyse pendant la saisie utilise une grammaire Tree-sitter approximative, sans exécuter le code : elle peut manquer des erreurs ou produire de fausses alertes. La vérification n’emploie volontairement pas perl -c, qui peut exécuter des blocs BEGIN. L’exécution réelle, elle, lance votre programme normalement ; les dépendances doivent être installées. Pas de débogueur dédié intégré.", 'https://perldoc.perl.org/')
section(p,'Premiers pas et types',[
('Programme strict','strict et warnings signalent de nombreuses erreurs courantes. Les instructions se terminent normalement par un point-virgule.','use strict;\nuse warnings;\nprint "Bonjour !\\n";'),
('Scalaires','Un scalaire $ peut contenir un nombre, une chaîne, une référence ou undef. my déclare une variable lexicale.','my $nom = "Ada";\nmy $age = 36;\nprint "$nom : $age\\n";'),
('Tableaux','Un tableau @ contient une liste ordonnée. Un élément est un scalaire et s’écrit avec $.','my @nombres = (10, 20, 30);\nprint "$nombres[0]\\n";'),
('Tables de hachage','Un hash % associe des clés à des valeurs ; accéder à un élément utilise le sigil $.','my %personne = (nom => "Ada", age => 36);\nprint "$personne{nom}\\n";'),
('undef et défini','undef indique une valeur indéfinie. defined teste sa présence sans confondre avec zéro.','my $x;\nprint "absent\\n" unless defined $x;'),
('Chaînes et interpolation','Les guillemets doubles interpolent les variables ; les apostrophes produisent généralement une chaîne littérale. L’opérateur . concatène.','my $nom = "Ada";\nprint "Bonjour " . $nom . "\\n";'),
('Références','Une référence permet de stocker une structure dans un scalaire ou de la transmettre.','my $liste = [1, 2, 3];\nprint $liste->[0], "\\n";')])
section(p,'Structures et texte',[
('Conditions','if / elsif / else choisissent une branche ; unless signifie si la condition est fausse.','if ($x > 0) { print "positif\\n"; }\nelse { print "autre\\n"; }'),
('Boucles','for / foreach parcourent des listes ; while répète tant que la condition est vraie.','for my $n (1..3) { print "$n\\n"; }'),
('Sous-programmes','sub définit une fonction ; ses arguments sont dans @_. return renvoie une valeur.','sub carre {\n  my ($x) = @_;\n  return $x * $x;\n}\nprint carre(4), "\\n";'),
('Expressions régulières','L’opérateur =~ applique une expression régulière ; les métacaractères ont un sens particulier.','my $texte = "bonjour";\nprint "oui\\n" if $texte =~ /jour/;'),
('Substitution','s/motif/remplacement/g remplace toutes les correspondances dans la variable visée.','my $texte = "chat chat";\n$texte =~ s/chat/chien/g;\nprint "$texte\\n";'),
('Fichiers','open avec trois arguments et un handle lexical sépare clairement mode et chemin. Toujours vérifier les erreurs et fermer le fichier.','open my $fh, "<", "donnees.txt" or die $!;\nwhile (my $ligne = <$fh>) { print $ligne; }\nclose $fh;')])
section(p,'Fonctions usuelles',[(t,b,e) for t,b,e in [
('print / say','print écrit les arguments ; say ajoute un saut de ligne et nécessite la fonctionnalité appropriée.','use feature "say";\nsay "Bonjour";'),('chomp','Retire le séparateur de fin de ligne courant en place.','my $s = "abc\\n"; chomp $s;'),('length / substr','length donne la longueur ; substr extrait une partie à partir d’un indice zéro.','print length("bonjour"), " ", substr("bonjour", 0, 3);'),('split / join','split découpe selon une expression régulière ; join assemble une liste avec un séparateur.','my @mots = split /,/, "a,b,c";\nprint join("-", @mots);'),('push / pop','push ajoute en fin de tableau et pop retire le dernier élément.','my @a = (1,2); push @a, 3; my $fin = pop @a;'),('keys / values','Récupèrent les clés ou les valeurs d’un hash ; leur ordre n’est pas garanti.','my %h = (a=>1,b=>2);\nprint join(",", sort keys %h);'),('map / grep','map transforme les éléments ; grep filtre selon une condition.','my @pairs = grep { $_ % 2 == 0 } (1..6);\nmy @doubles = map { $_ * 2 } @pairs;'),('die / eval','die signale une erreur ; eval en bloc peut intercepter une exception. Évitez eval sur des données non fiables.','eval { die "erreur" };\nwarn $@ if $@;')]])
b=language('basic','Yabasic (BASIC)',"BASIC est une famille de langages conçus pour apprendre la programmation et écrire des programmes accessibles. Ici, le dialecte pris en charge est précisément Yabasic : les programmes destinés à d’autres BASIC ne sont pas forcément compatibles.\n\nBASIC apparaît en 1964 au Dartmouth College ; Yabasic est un interpréteur BASIC indépendant avec sous-programmes, tableaux et fonctions. Les variables numériques et chaînes se distinguent notamment par le suffixe $. L’IDE exécute le fichier .bas ou .yab avec yabasic ; ses imports et fichiers associés doivent être disponibles. La vérification --check ne lance pas le programme ; aucun débogueur dédié n’est intégré.", 'https://2484.de/yabasic/yabasic.htm')
section(b,'Premiers pas et données',[
('Premier programme','print affiche une valeur ; rem ou le symbole # introduisent un commentaire.','rem TODO: compléter\nprint "Bonjour !"'),
('Variables numériques','Une variable sans suffixe $ contient un nombre ; une affectation lui donne une valeur.','age = 36\nprint age'),
('Chaînes','Une variable dont le nom se termine par $ contient une chaîne ; + concatène des chaînes.','nom$ = "Ada"\nprint "Bonjour " + nom$'),
('Booléens','Les conditions utilisent true et false et les comparaisons =, <>, <, >, <= et >=.','ok = true\nif (ok) print "Prêt"'),
('Tableaux','dim crée un tableau ; les indices et dimensions doivent correspondre à sa déclaration.','dim a(3)\na(1) = 10\nprint a(1)'),
('Entrée utilisateur','input lit une valeur ; l’exécution reste en attente tant que l’utilisateur ne répond pas.','input "Votre nom : " nom$\nprint "Bonjour ", nom$')])
section(b,'Contrôle et sous-programmes',[
('Conditions','if, then, else et endif permettent de choisir une branche.','if (age >= 18) then\n  print "majeur"\nelse\n  print "mineur"\nendif'),
('Boucle for','for…to…step…next répète des instructions pour une plage numérique.','for i = 1 to 3\n  print i\nnext i'),
('Boucle while','while et wend répètent tant que la condition reste vraie.','n = 3\nwhile (n > 0)\n  print n\n  n = n - 1\nwend'),
('Sous-programme','sub définit une routine ; les paramètres sont locaux et return peut fournir une valeur.','print double(21)\nsub double(x)\n  return x * 2\nend sub'),
('Variables locales','local réserve une variable à la routine ; évite de modifier accidentellement une globale.','sub demo()\n  local n\n  n = 3\n  print n\nend sub\ndemo()'),
('Données intégrées','data stocke des valeurs dans le programme et read les consomme successivement.','read a\nread b\nprint a + b\ndata 2, 3')])
section(b,'Fonctions usuelles',[(t,d,e) for t,d,e in [
('len','Compte les caractères d’une chaîne.','print len("Ada")'),('left$ / right$','Extrait un nombre de caractères au début ou à la fin.','print left$("bonjour", 3), right$("bonjour", 4)'),('mid$','Extrait une portion d’une chaîne ; la position commence à 1.','print mid$("bonjour", 2, 3)'),('upper$ / lower$','Change la casse des caractères.','print upper$("bonjour"), lower$("BONJOUR")'),('str$ / val','Convertit un nombre en chaîne ou une chaîne numérique en nombre.','print str$(42)\nprint val("42") + 1'),('sqrt / abs','Racine carrée et valeur absolue.','print sqrt(9), abs(-3)'),('sin / cos','Fonctions trigonométriques ; les angles sont en radians.','print sin(0), cos(0)'),('int / ran','int prend la partie entière selon les règles Yabasic ; ran produit une valeur pseudo-aléatoire.','print int(ran(10))')]])
o=language('ocaml','OCaml',"OCaml est utilisé pour les compilateurs, l’analyse de programmes, la vérification et des logiciels où la sûreté des types est importante. Il associe programmation fonctionnelle, impérative et système de modules.\n\nIssu de la famille ML et développé notamment à l’INRIA, Objective Caml devient OCaml ; son inférence de types et son filtrage par motifs sont caractéristiques. L’IDE compile un .ml isolé avec ocamlc ; .mli est une interface non exécutable. Les dépendances entre fichiers et bibliothèques exigent une construction manuelle, par exemple avec dune dans le terminal. L’analyse en direct vérifie la syntaxe sans vérifier tous les types ; la compilation vérifie les types. Aucun débogueur dédié n’est intégré.", 'https://ocaml.org/docs')
section(o,'Premiers pas et types',[
('Programme','Une liaison let donne un nom à une valeur ; let () exécute une expression de type unit au chargement.','let message = "Bonjour !"\nlet () = print_endline message'),
('int et float','Les entiers et flottants ont des opérateurs distincts : + pour int, +. pour float.','let n = 2 + 3\nlet x = 1.5 +. 2.0'),
('bool','bool vaut true ou false. && et || combinent des conditions.','let pret = true\nlet ok = pret && (3 > 1)'),
('char et string','Un caractère utilise des apostrophes et une chaîne des guillemets. ^ concatène les chaînes.','let c = \'A\'\nlet nom = "Ada" ^ " Lovelace"'),
('unit','unit représente notamment l’absence de résultat intéressant ; sa valeur est ().','let () = print_endline "Bonjour"'),
('Tuple','Un tuple rassemble des valeurs éventuellement de types différents.','let personne = ("Ada", 36)\nlet (nom, age) = personne'),
('Liste et tableau','Une liste est immuable et s’écrit [1; 2] ; un tableau mutable s’écrit [|1; 2|].','let xs = [1; 2; 3]\nlet a = [|1; 2|]\nlet () = a.(0) <- 10'),
('option','option représente explicitement une valeur présente avec Some ou absente avec None.','let chercher = Some 42\nlet absent = None'),
('Variants et enregistrements','type définit des alternatives ou des champs nommés, vérifiés par le compilateur.','type couleur = Rouge | Bleu\ntype point = { x : int; y : int }\nlet p = { x = 1; y = 2 }')])
section(o,'Structures et fonctions',[
('Fonctions','Une fonction se définit avec let ; les arguments se suivent sans virgule, et le dernier résultat est renvoyé.','let carre x = x * x\nlet () = print_int (carre 4)'),
('Récursion','let rec rend le nom de la fonction accessible dans sa propre définition.','let rec somme n =\n  if n <= 0 then 0 else n + somme (n-1)'),
('Filtrage match','match examine les constructeurs ; traiter tous les cas rend le code plus robuste.','let texte = function\n  | Some n -> string_of_int n\n  | None -> "absent"'),
('Modules et interfaces','Un fichier .ml définit une implémentation de module ; .mli peut exposer son interface. Le nom du module correspond au nom du fichier capitalisé.','module Salutation = struct\n  let bonjour () = print_endline "Bonjour"\nend\nlet () = Salutation.bonjour ()'),
('Exceptions','try…with intercepte une exception. Préférez les types option ou result lorsque l’absence est attendue.','let n = try int_of_string "abc" with Failure _ -> 0'),
('Références','ref crée une cellule mutable ; ! lit sa valeur et := la modifie.','let compteur = ref 0\nlet () = compteur := !compteur + 1')])
section(o,'Bibliothèque standard',[(t,d,e) for t,d,e in [
('print_endline / print_int','Affichent respectivement une chaîne avec saut de ligne ou un entier.','let () = print_endline "Bonjour"; print_int 42'),('string_of_int / int_of_string','Convertissent entre entier et chaîne ; int_of_string peut lever Failure.','let s = string_of_int 42\nlet n = int_of_string s'),('List.map','Construit une nouvelle liste en appliquant une fonction à chaque élément.','let doubles = List.map (fun x -> x * 2) [1;2;3]'),('List.fold_left','Combine les éléments de gauche à droite à partir d’un accumulateur.','let total = List.fold_left ( + ) 0 [1;2;3]'),('List.iter','Applique une opération à chaque élément, par exemple pour l’affichage.','let () = List.iter print_int [1;2;3]'),('Array.length / Array.map','Mesure un tableau ou crée un nouveau tableau transformé.','let a = [|1;2|]\nlet taille = Array.length a\nlet b = Array.map (( * ) 2) a'),('String.length / String.sub','Calcule la longueur en octets ou extrait une portion ; indices et longueur doivent être valides.','let n = String.length "bonjour"\nlet s = String.sub "bonjour" 0 3')]])
l=language('lua','Lua',"Lua sert notamment à embarquer des scripts dans des applications et des jeux, ainsi qu’à automatiser des tâches. Son interpréteur léger et ses tables polyvalentes facilitent son intégration.\n\nCréé au Brésil en 1993 à la PUC-Rio, Lua est dynamique et emploie des tables pour représenter listes, dictionnaires et modules. Ce support vise Lua 5.4 lorsque disponible. L’IDE lance le fichier .lua choisi ; require dépend du chemin de recherche et des modules installés. luac -p vérifie la syntaxe sans exécuter le script. Aucun débogueur dédié n’est intégré.", 'https://www.lua.org/manual/5.4/')
section(l,'Premiers pas et types',[
('Premier programme','local déclare une variable locale ; -- commence un commentaire.','-- TODO: personnaliser\nlocal nom = "Ada"\nprint("Bonjour " .. nom)'),
('nil et boolean','nil représente l’absence de valeur ; false et nil seuls sont faux dans un test, contrairement à 0 et à la chaîne vide.','local absent = nil\nlocal pret = true\nif pret then print("prêt") end'),
('number','Lua 5.4 distingue entiers et flottants à l’intérieur du type number ; / divise et // effectue une division entière.','local n = 7\nprint(n / 2, n // 2)'),
('string','Les chaînes sont immuables ; .. les concatène. La longueur # compte les octets.','local nom = "Ada"\nprint("Bonjour " .. nom, #nom)'),
('table','Une table représente une séquence ou un dictionnaire ; les séquences commencent conventionnellement à 1.','local t = {"a", "b", nom = "Ada"}\nprint(t[1], t.nom)'),
('Fonction comme valeur','Les fonctions peuvent être stockées, passées en argument et renvoyées.','local function carre(x)\n  return x * x\nend\nprint(carre(4))'),
('Portée locale','Utiliser local évite de créer accidentellement une variable globale.','local x = 1\ndo\n  local x = 2\n  print(x)\nend\nprint(x)')])
section(l,'Structures et modules',[
('Conditions','if, elseif et else choisissent une branche, terminée par end.','if n > 0 then\n  print("positif")\nelse\n  print("autre")\nend'),
('Boucles numériques','for parcourt une plage ; while et repeat permettent d’autres conditions.','for i = 1, 3 do\n  print(i)\nend'),
('Parcours de tables','ipairs parcourt une séquence jusqu’au premier indice absent ; pairs parcourt les clés sans ordre garanti.','local t = {"a", "b"}\nfor i, v in ipairs(t) do print(i, v) end'),
('Modules','require charge un module accessible par package.path ou package.cpath.','local math = require("math")\nprint(math.sqrt(9))'),
('Erreurs protégées','pcall intercepte une erreur et renvoie un booléen puis le résultat ou le message.','local ok, valeur = pcall(function() error("oups") end)\nprint(ok, valeur)'),
('Métatables','Une métatable personnalise certaines opérations ; __index permet notamment un repli.','local t = setmetatable({}, {__index = {nom="Ada"}})\nprint(t.nom)')])
section(l,'Bibliothèque standard',[(t,d,e) for t,d,e in [
('print / type','print affiche des valeurs ; type renvoie leur catégorie.','print("Bonjour", type(42))'),('tonumber / tostring','Convertissent en nombre lorsque possible ou en représentation textuelle.','print(tonumber("42") + 1, tostring(12))'),('string.sub / string.format','Extrait une portion ou formate des valeurs ; les positions de chaînes commencent à 1.','print(string.sub("bonjour", 1, 3))\nprint(string.format("%04d", 42))'),('string.find / string.gsub','Cherche un motif Lua ou le remplace ; les motifs Lua ne sont pas des expressions régulières complètes.','print(string.gsub("chat chat", "chat", "chien"))'),('table.insert / table.remove','Ajoute ou retire un élément d’une séquence.','local t = {1,2}\ntable.insert(t, 3)\ntable.remove(t, 1)'),('table.sort / table.concat','Trie une séquence ou assemble ses éléments avec un séparateur.','local t = {"b", "a"}\ntable.sort(t)\nprint(table.concat(t, ", "))'),('math.sqrt / math.abs','Calculent la racine carrée et la valeur absolue.','print(math.sqrt(9), math.abs(-3))'),('io.open','Ouvre un fichier ; vérifier le résultat puis fermer le handle.','local f, err = io.open("donnees.txt", "r")\nif f then print(f:read("a")); f:close() else print(err) end')]])
catalogue={'languages':[], 'articles':[]}
for key,item in languages.items():
 title=item['title'];catalogue['languages'].append(title)
 catalogue['articles'].append({'id':'ps33-'+key+'-intro','lang':title,'group':'Introduction','title':'Découvrir '+title,'summary':'Utilité, histoire et utilisation dans Pascal Studio.','intro':True,'blocks':[{'title':'Introduction','text':item['intro'],'code':''}]})
 index=0
 for group in item['sections']:
  for article in group['articles']:
   index+=1
   desc,code=article['body'].split('\n\nExemple :\n',1)
   catalogue['articles'].append({'id':'ps33-'+key+'-'+str(index),'lang':title,'group':group['title'],'title':article['title'],'summary':desc,'intro':False,'blocks':[{'title':'Explication','text':desc,'code':''},{'title':'Exemple','text':'Exemple à adapter au contexte.','code':code}]})
out='(function(){const a='+json.dumps(catalogue,ensure_ascii=False,separators=(',',':'))+';window.PS_LANG_HELP=window.PS_LANG_HELP||{languages:[],articles:[]};window.PS_LANG_HELP.languages.push(...a.languages);window.PS_LANG_HELP.articles.push(...a.articles)})();\n' 
Path(sys.argv[1]).write_text(out,encoding='utf8')
print('Aide :',sum(len(sec['articles']) for x in languages.values() for sec in x['sections']),'articles')
