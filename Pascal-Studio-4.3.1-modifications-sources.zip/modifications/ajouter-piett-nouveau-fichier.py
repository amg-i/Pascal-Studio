#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Ajouter le type « Programme Piet (texte) » au dialogue Nouveau fichier (4.3.0).

POURQUOI
  L'éditeur graphique de Piet édite des sources `.piett`. Sans entrée dans le
  dialogue « Nouveau fichier », le seul moyen d'en créer une serait d'écrire le
  fichier à la main dans un terminal — donc de ne jamais découvrir la
  fonctionnalité. Le dialogue liste déjà 37 types ; celui-ci est le 38e.

LE MODÈLE EST UN PROGRAMME QUI TOURNE
  Le modèle proposé est `rc rn ms` : rouge claire -> rouge normale (push de la
  taille du bloc, donc 1) -> magenta sombre (delta teinte 5, delta luminosité 1
  = out(number)), qui écrit « 1 ». C'est exactement l'exemple que
  `piet_texte.exemple()` rend et que l'autocontrôle du module exécute. Un modèle
  qui ne s'exécute pas apprendrait que l'éditeur est cassé — c'est la raison
  pour laquelle le modèle d'assembleur ajouté en 4.0.0 est réellement
  assemblable.

  Le modèle est vérifié ICI, à la génération du correctif, par le module Python
  lui-même : si un jour les deux divergent, ce script échoue au lieu de livrer
  un modèle que l'éditeur refuserait.

IDEMPOTENCE
  La signature est le texte ajouté (`id: 'piett'`), jamais l'ancre.

Usage :
    python3 ajouter-piett-nouveau-fichier.py [--verifier]
"""

import io
import os
import subprocess
import sys

RACINE = os.path.dirname(os.path.abspath(__file__))
CIBLE = os.path.join(RACINE, 'nouveau-fichier.js')

ANCRE = """    /* Fichier sans extension (4.2.0) : `ext` vide, donc rien n'est ajouté au
       nom saisi. Le code qui complète le nom teste déjà `type.ext`. */
    { id: 'texte', label: 'Texte sans extension', ext: '', logo: null,
      lettre: 'T', modele: '' },
"""

NOUVEAU = ANCRE + """    /* Programme Piet en format TEXTE (4.3.0). Piet est défini comme une image :
       un programme est un PNG. `.piett` en est la SOURCE — une cellule par
       codel, en deux lettres — et le PNG devient la forme compilée que le
       moteur Piet existant exécute. Le bundle route les `.piett` vers
       `.ps-piet-host`, où piet-studio.js rend la grille à peindre, la palette
       des 20 couleurs, l'aperçu PNG et l'exécution.
       Le modèle ci-dessous EST l'exemple que piet_texte.exemple() rend et que
       l'autocontrôle du module exécute : il écrit « 1 ». Les deux sont
       confrontés par ce correctif, donc ils ne peuvent pas diverger en
       silence. */
    { id: 'piett', label: 'Programme Piet (texte)', ext: '.piett', logo: null,
      lettre: '▦',
      modele: '# Programme Piet — format texte de Pascal Studio.\\n'
            + '# Une cellule = un codel. Codes : bl (blanc), no (noir), et\\n'
            + '# <teinte><luminosité> avec teinte r j v c b m (rouge jaune vert\\n'
            + '# cyan bleu magenta) et luminosité c n s (claire normale sombre).\\n'
            + '# La commande dépend du CHANGEMENT de couleur entre deux blocs.\\n'
            + '# Ci-dessous : rouge claire -> rouge normale = push(1),\\n'
            + '# puis rouge normale -> magenta sombre = out(number). Sortie : 1.\\n'
            + 'piet 1\\n'
            + 'codel 4\\n'
            + 'grille 3 1\\n'
            + 'rc rn ms\\n' },
"""

SIGNATURE = "id: 'piett'"


def modele_depuis_le_texte_js(texte):
    """Extrait le modèle Piet du fichier JS pour le faire valider par le module.

    Recopier le modèle en Python à côté du JS créerait deux sources de vérité :
    l'une finirait par diverger, et le dialogue proposerait alors un fichier que
    l'éditeur refuse. On lit donc le JS, on assemble les morceaux, et c'est
    `piet_texte.decoder()` qui juge.
    """
    debut = texte.index(SIGNATURE)
    fin = texte.index('},\n', texte.index('modele:', debut))
    bloc = texte[debut:fin]
    morceaux = []
    for ligne in bloc.splitlines():
        ligne = ligne.strip()
        if not ligne.startswith("+ '") and not ligne.startswith("modele: '"):
            continue
        debut_chaine = ligne.index("'") + 1
        fin_chaine = ligne.rindex("'")
        morceaux.append(ligne[debut_chaine:fin_chaine])
    return ''.join(morceaux).encode('utf8').decode('unicode_escape')


def verifier(chemin):
    if not os.path.isfile(chemin):
        return 2, ['%s : introuvable.' % chemin]
    texte = io.open(chemin, encoding='utf-8').read()
    lignes = ['%s : %d caractères' % (os.path.basename(chemin), len(texte))]
    if SIGNATURE in texte:
        lignes.append('  type .piett             appliqué')
        try:
            modele = modele_depuis_le_texte_js(texte)
        except ValueError as exc:
            lignes.append('  MODÈLE ILLISIBLE : %s' % exc)
            return 2, lignes
        sys.path.insert(0, RACINE)
        try:
            import piet_texte
        except Exception as exc:                              # noqa: BLE001
            lignes.append('  piet_texte.py importable ? non (%s)' % exc)
            return 2, lignes
        decode = piet_texte.decoder(modele)
        if not decode['ok']:
            lignes.append('  LE MODÈLE PROPOSÉ EST REFUSÉ PAR LE DÉCODEUR : %s'
                          % (decode['diagnostics'][0]['message']
                             if decode['diagnostics'] else 'raison inconnue'))
            return 2, lignes
        lignes.append('  le modèle décode en %d x %d codels, codel %d'
                      % (decode['largeur'], decode['hauteur'], decode['codel']))
        resultat = piet_texte.executer(modele)
        sortie = resultat.get('sortie') or resultat.get('output') or ''
        if '1' not in sortie:
            lignes.append('  LE MODÈLE NE PRODUIT PAS « 1 » (sortie %r) : il '
                          'apprendrait que l’éditeur est cassé.' % sortie)
            return 2, lignes
        lignes.append('  le modèle s’exécute et écrit « 1 »')
        lignes.append('  conforme (4.3.0 en place)')
        return 0, lignes
    if texte.count(ANCRE) == 1:
        lignes.append('  type .piett             applicable')
        return 1, lignes
    lignes.append('  ANCRE %d fois : rien n’est écrit.' % texte.count(ANCRE))
    return 2, lignes


def appliquer(chemin):
    code, rapport = verifier(chemin)
    for ligne in rapport:
        sys.stderr.write(ligne + '\n')
    if code == 0:
        return 0
    if code == 2:
        return 2
    texte = io.open(chemin, encoding='utf-8').read()
    depart = len(texte)
    assert texte.count(ANCRE) == 1, 'l’ancre n’est pas unique'
    texte = texte.replace(ANCRE, NOUVEAU, 1)
    assert SIGNATURE in texte, 'la signature manque après application'
    io.open(chemin, 'w', encoding='utf-8').write(texte)
    sys.stderr.write('%s : %d -> %d caractères, type « Programme Piet (texte) » '
                     'ajouté.\n' % (os.path.basename(chemin), depart, len(texte)))
    # Le contrôle du modèle est REJOUÉ sur le fichier écrit, pas sur celui qui a
    # été lu : c'est le seul moyen de voir une écriture qui aurait abîmé les
    # échappements.
    code, rapport = verifier(chemin)
    for ligne in rapport:
        sys.stderr.write(ligne + '\n')
    return code


def main(argv):
    seulement = '--verifier' in argv
    if seulement:
        code, rapport = verifier(CIBLE)
        for ligne in rapport:
            sys.stderr.write(ligne + '\n')
        return code
    return appliquer(CIBLE)


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
