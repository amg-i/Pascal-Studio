#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
asm_studio.py — engendre le tokenizer Monaco de l'assembleur (4.0.0).

    python3 asm_studio.py CHEMIN/asm-studio.js

Pourquoi engendrer au lieu d'écrire le tokenizer à la main : la coloration
syntaxique et l'analyse statique doivent connaître les MÊMES mnémoniques, les
mêmes registres et les mêmes directives. Écrites séparément, les deux listes
divergent, et l'éditeur colore en mot-clef une instruction que l'analyseur
signale comme inconnue — ou l'inverse. C'est le défaut que la 3.8.0 a évité pour
l'aide en engendrant aide-esoteriques.js depuis aide-esoteriques.py ; la même
raison s'applique ici, et assembleur.py est la source unique.

Le fichier produit est un module Monaco au format des autres *-studio.js :
`export const conf` et `export const language`. Il est copié tel quel dans
static/assets/ et chargé par le bundle via import("./asm-studio.js").

Les deux syntaxes sont colorées ensemble, et c'est voulu : un fichier peut
commencer en AT&T et être converti en Intel, et l'éditeur ne doit pas cesser de
colorer pendant la conversion. L'analyseur, lui, dit laquelle il a reconnue et
signale le mélange.
"""

import io
import os
import sys

MARQUEUR = 'ps-4.0.0-assembleur'

# Mnémoniques retenus pour la coloration. La table d'assembleur.py en compte
# plus de 400, dont beaucoup sont engendrés (jcc, setcc, cmovcc sur les 25 codes
# de condition, et les variantes SSE/AVX). Tout colorer alourdirait le fichier
# pour rien : les formes engendrées suivent des familles, et Monarch accepte des
# motifs réguliers. On liste donc explicitement ce qui ne se devine pas, et on
# laisse des motifs pour les familles régulières.
FAMILLES_REGULIERES = [
    # jz, jnz, jb, jae, jl, jge… sur les 25 codes de condition.
    r'j(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\b',
    # sete, setne, setb…
    r'set(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\b',
    # cmove, cmovne…
    r'cmov(?:o|no|b|nae|c|nb|ae|nbe|e|z|nz|na|a|ns|s|p|pe|np|po|l|nl|nge|ge|ng|g|nle)\b',
    # addss, vmulpd, vaddps…
    r'v?(?:add|sub|mul|div|sqrt|and|or|xor|cmp|min|max)(?:ss|sd|ps|pd)\b',
    # movaps, vmovdqu…
    r'v?mov(?:aps|ups|apd|upd|dqa|dqu|ss|sd|mskps|mskpd)\b',
    # opérations sur les chaînes avec leurs préfixes.
    r'(?:rep|repe|repz|repne|repnz)?\s*(?:movs|stos|lods|cmps|scas)[bwlqd]\b',
    # pxor, vpaddq, vpcmpeqd…
    r'v?p(?:xor|or|and|add|sub|mul|cmp|madd|shuf|unpck|sll|srl|sra)[bwdq]\b',
]


def listes(module):
    """Les trois listes de mots, triées et dédoublonnées."""
    # Les mnémoniques engendrés par famille sont retirés de la liste explicite :
    # les motifs réguliers les couvrent déjà, et les laisser produirait des
    # dizaines de milliers de mots dans le fichier.
    import re
    familles = [re.compile(expression, re.IGNORECASE)
                for expression in FAMILLES_REGULIERES]
    explicites = []
    for mnemonique in sorted(module.MNEMONIQUES):
        if any(famille.fullmatch(mnemonique) for famille in familles):
            continue
        explicites.append(mnemonique)

    registres = sorted(module.TOUS_REGISTRES)
    directives = sorted(
        {d.lstrip('.') for d in module.DIRECTIVES_GAS}
        | {d.lstrip('.') for d in module.DIRECTIVES_NASM if not d.startswith('%')})
    return explicites, registres, directives


def mot_js(mots):
    """Une liste JavaScript, en colonnes lisibles, SANS PERDRE D'ESPACE.

    Deux défauts ont été trouvés ici par le banc, et tous deux étaient
    invisibles à la lecture du fichier produit :

      1. deux littéraux juxtaposés ne sont pas du JavaScript valide
         (« 'a b'\\n 'c d' ») — il faut un « + » explicite ;
      2. « 'a b' + 'c d' » rend « a bc d » : la concaténation ne remet pas
         l'espace de séparation. Les listes produisaient donc des mots soudés
         comme « dr5dr6 » ou « movmovabs », qui n'étaient plus ni des registres
         ni des mnémoniques — et qui en faisaient disparaître deux à la fois.
         Chaque ligne de continuation commence donc par une espace.

    L'appelant parenthèse le résultat, parce que « 'a' + 'b'.split(' ') » se lit
    « 'a' + ['b'] » et rend une CHAÎNE : .split se lie plus fort que +.
    """
    lignes = []
    courante = ''
    for mot in mots:
        if courante and len(courante) + 1 + len(mot) > 96:
            lignes.append(courante)
            courante = mot
        else:
            courante = (courante + ' ' + mot).strip()
    if courante:
        lignes.append(courante)
    if len(lignes) == 1:
        return "'%s'" % lignes[0]
    # L'espace de séparation doit être À L'INTÉRIEUR des guillemets : écrite
    # avant l'apostrophe, elle ne sépare rien du tout et les mots se soudent.
    morceaux = ["'%s'" % lignes[0]] + ["' %s'" % l for l in lignes[1:]]
    return ' +\n    '.join(morceaux)


def generer(module):
    explicites, registres, directives = listes(module)
    motifs = '\n    '.join('[/%s/,' % f.replace('/', '\\/').replace('\\b', '\\\\b')
                           + "'keyword']," for f in FAMILLES_REGULIERES)
    return """\
/* Tokenizer de l'assembleur x86-64 pour Pascal Studio — ENGENDRÉ par
   asm_studio.py depuis les tables d'assembleur.py. Ne pas modifier à la main :
   la modification serait perdue au prochain engendrement, et c'est voulu, pour
   que la coloration ne diverge jamais de l'analyseur.
   marqueur : %(marqueur)s
   %(nb_mnemoniques)d mnémoniques explicites, %(nb_registres)d registres,
   %(nb_directives)d directives, et %(nb_familles)d familles régulières
   (jcc, setcc, cmovcc, SSE/AVX, opérations sur les chaînes, MMX). */
export const conf={
  comments:{lineComment:'#',blockComment:['/*','*/']},
  brackets:[['[',']'],['(',')']],
  autoClosingPairs:[
    {open:'"',close:'"'},
    {open:"'",close:"'"},
    {open:'[',close:']'},
    {open:'(',close:')'}
  ],
  surroundingPairs:[{open:'[',close:']'},{open:'(',close:')'},{open:'"',close:'"'}]
};

export const language={
  ignoreCase:true,
  /* Les mnémoniques hors familles régulières. */
  keywords:
    (%(mnemoniques)s).split(' '),
  /* Les registres, toutes largeurs : rax, eax, ax, ah, r15d, xmm0, rip… */
  registers:
    (%(registres)s).split(' '),
  /* Directives des deux assembleurs, sans leur point : le point est reconnu
     séparément pour que « .text » et « section » soient tous les deux colorés. */
  directives:
    (%(directives)s).split(' '),
  tokenizer:{
    root:[
      /* Commentaires : « # » en GAS, « ; » en NASM. Les deux sont acceptés
         partout, parce qu'un fichier en cours de conversion emploie les deux. */
      [/[#;].*$/,'comment'],
      [/\\/\\*/,'comment','@commentaire'],

      /* Étiquette en début de ligne, avec ou sans deux-points (NASM écrit
         « msg db 1 » sans deux-points). */
      [/^[ \\t]*[A-Za-z_.][\\w.$]*(?=\\s*:)/,'type.identifier'],
      [/^[ \\t]*[A-Za-z_.][\\w.$]*(?=\\s+(?:db|dw|dd|dq|dt|equ|resb|resw|resd|resq|times)\\b)/,
        'type.identifier'],

      /* Immédiat AT&T : « $1 », « $0x1f ». À reconnaître AVANT les registres,
         sinon le « $ » reste du texte et le nombre est colorié en identifiant. */
      [/\\$-?(?:0[xX][0-9a-fA-F]+|0[bB][01]+|\\d+)/,'number'],

      /* Registre AT&T préfixé par « %% ». */
      [/%%[A-Za-z][\\w]*/,{cases:{'@registers':'variable.predefined',
                                  '@default':'identifier'}}],

      /* Directives, avec ou sans point. */
      [/\\.[A-Za-z_][\\w.]*/,{cases:{'@directives':'keyword',
                                     '@default':'metatag'}}],
      [/^(?:section|segment|global|extern|bits|default|struc|endstruc|istruc|iend|times|equ|db|dw|dd|dq|dt|resb|resw|resd|resq)\\b/,'keyword'],

      /* Familles régulières : jcc, setcc, cmovcc, SSE/AVX, chaînes, MMX. */
    %(motifs)s

      /* Mnémonique explicite, ou registre nu en syntaxe Intel, ou identifiant. */
      [/[A-Za-z][\\w.]*/,{cases:{'@keywords':'keyword',
                                 '@registers':'variable.predefined',
                                 '@default':'identifier'}}],

      /* Nombres : hexadécimal, binaire, décimal, et la forme NASM « 0FFh ». */
      [/0[xX][0-9a-fA-F]+/,'number'],
      [/0[bB][01]+/,'number'],
      [/\\d+[hHbBoOdDqQ]?/,'number'],

      [/"(?:[^"\\\\]|\\\\.)*"/,'string'],
      [/'(?:[^'\\\\]|\\\\.)*'/,'string'],

      [/[[\\]()]/,'@brackets'],
      [/[,:+\\-*\\/<>&|^!~]/,'operator'],
      [/\\s+/,'white']
    ],
    commentaire:[
      [/[^/*]+/,'comment'],
      [/\\*\\//,'comment','@pop'],
      [/[/*]/,'comment']
    ]
  }
};
""" % {
        'marqueur': MARQUEUR,
        'nb_mnemoniques': len(explicites),
        'nb_registres': len(registres),
        'nb_directives': len(directives),
        'nb_familles': len(FAMILLES_REGULIERES),
        'mnemoniques': mot_js(explicites),
        'registres': mot_js(registres),
        'directives': mot_js(directives),
        'motifs': motifs,
    }


def main(argv):
    if len(argv) != 1:
        sys.stderr.write(__doc__)
        return 2
    ici = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, ici)
    try:
        import assembleur
    except ImportError as erreur:
        sys.stderr.write('assembleur.py est introuvable à côté de ce '
                         'générateur : %s\n' % erreur)
        return 1
    texte = generer(assembleur)
    cible = argv[0]
    io.open(cible, 'w', encoding='utf-8').write(texte)
    print('asm-studio.js engendré : %d octets, %s' % (len(texte), MARQUEUR))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
