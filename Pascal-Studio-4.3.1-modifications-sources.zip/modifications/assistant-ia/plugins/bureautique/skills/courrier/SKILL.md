---
name: courrier
description: Lettres officielles, CV, lettre de motivation, attestations, réclamations.
triggers: lettre de motivation, cv, curriculum, lettre de réclamation, lettre de résiliation, lettre officielle, attestation, candidature
---
# Courriers et CV
- Lettre officielle : expéditeur, destinataire, lieu et date, « Objet : », formule d'appel, corps (motif → faits datés → demande précise → délai), formule de politesse complète, signature.
- Réclamation / résiliation : cite le contrat ou la référence, la date, la base légale seulement si tu es sûr (sinon ne l'invente pas), demande un accusé de réception ; conseille l'envoi en recommandé.
- CV : 1 page, titre de poste, expériences en ordre antichronologique avec résultats chiffrés, compétences, formation. Lettre de motivation : 3 paragraphes (pourquoi eux, pourquoi moi, ce que j'apporte).
- Informations manquantes : [À COMPLÉTER]. Ne fabrique jamais de diplôme, d'employeur ni de date.
- Livre dans `<fichier nom="lettre.md">` (bouton Word / PDF dans la visionneuse).
