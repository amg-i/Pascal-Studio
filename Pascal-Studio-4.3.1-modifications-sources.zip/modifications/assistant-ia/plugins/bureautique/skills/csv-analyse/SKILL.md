---
name: csv-analyse
description: Analyser des données (CSV, tableaux) : nettoyage, statistiques, tendances.
triggers: analyse ces données, analyser un csv, statistiques, moyenne, médiane, corrélation, tendance, données, dataset, pandas
---
# Analyse de données
1. Regarde d'abord la structure : colonnes, types, lignes, valeurs manquantes, doublons. Annonce-les.
2. Avec outils, calcule en Python plutôt qu'à la main : `python3 -c "import pandas as pd; d=pd.read_csv('f.csv'); print(d.describe(include='all'))"` (sinon module `csv` et `statistics`).
3. Donne chiffres exacts + interprétation en une phrase chacun. Distingue corrélation et causalité. Mentionne la taille de l'échantillon.
4. Valeurs aberrantes : signale-les, ne les supprime pas sans l'accord de l'utilisateur.
5. Livrables : tableau résumé en Markdown, fichier `resultats.csv` si utile.
