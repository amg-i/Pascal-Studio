---
name: docx
description: Créer ou modifier un document Word (.docx).
triggers: word, docx, document word, fichier word, .docx, traitement de texte, lettre en word
---
# Word (.docx)
- **Sans outil** : écris le contenu en Markdown dans `<fichier nom="document.md">` (titres `#`, listes, tableaux `|`) ; dans la visionneuse, le bouton **Word** le convertit en .docx avec titres, listes et tableaux.
- **Avec outils** (run_command) : `python-docx` : `from docx import Document; d=Document(); d.add_heading('Titre',0); d.add_paragraph('Texte'); d.add_table(rows=2,cols=3); d.save('doc.docx')`. Pour modifier un .docx existant : ouvre-le avec `Document(chemin)`, change les paragraphes, enregistre sous un NOUVEAU nom.
- Mise en page sobre : un titre, des intertitres hiérarchisés, pas de gras partout. Ajoute date, auteur et pagination si c'est un rapport.
- Ne remplace jamais l'original sans que l'utilisateur l'ait demandé.
