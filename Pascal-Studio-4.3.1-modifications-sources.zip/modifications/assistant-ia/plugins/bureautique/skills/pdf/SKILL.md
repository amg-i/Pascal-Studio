---
name: pdf
description: Lire, extraire, résumer ou produire un document PDF.
triggers: pdf, fichier pdf, document pdf, extraire le texte, fusionner des pdf, convertis en pdf, exporter en pdf
---
# PDF
**Lire** (avec les outils) : `run_command` → `pdftotext -layout fichier.pdf -` (poppler) ; sinon `python3 -c "from pypdf import PdfReader;r=PdfReader('f.pdf');print('\n'.join(p.extract_text() or '' for p in r.pages))"`. Un PDF scanné n'a pas de texte : dis-le (OCR : `ocrmypdf` ou `tesseract` si installés).
Pièce jointe glissée dans le chat : le texte est déjà extrait, utilise-le directement.
**Produire** : le plus fiable est d'écrire un document HTML ou Markdown propre dans un `<fichier nom="rapport.html">` : la visionneuse propose le bouton **PDF** (impression → « Enregistrer au format PDF »).
Avec outils et si disponible : `python3 -c "from reportlab.pdfgen import canvas ..."` ou `libreoffice --headless --convert-to pdf fichier.docx`.
**Fusionner / découper** : `pdfunite a.pdf b.pdf out.pdf`, `pdfseparate`, ou `pypdf.PdfWriter`.
Toujours vérifier le résultat (nombre de pages, texte lisible) avant d'annoncer que c'est fait.
