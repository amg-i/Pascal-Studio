---
name: pptx
description: Préparer un diaporama / une présentation PowerPoint.
triggers: powerpoint, pptx, présentation, diaporama, slides, diapositives, deck
---
# Présentation
1. Plan d'abord : message principal, 5 à 12 diapositives, une idée par diapositive.
2. Chaque diapositive : titre-affirmation (« Les ventes ont doublé »), 3 puces maximum de 8 mots, une visualisation ou un chiffre clé. Notes de l'orateur pour le détail.
3. **Sans outil** : livre un `<fichier nom="presentation.html">` avec une section par diapositive (aperçu et PDF depuis la visionneuse), ou un plan en Markdown.
4. **Avec outils** : `python-pptx` si installé : `from pptx import Presentation; p=Presentation(); s=p.slides.add_slide(p.slide_layouts[1]); s.shapes.title.text='Titre'; p.save('p.pptx')`.
5. Sobriété : 2 couleurs, une police, contraste fort, pas de texte long.
