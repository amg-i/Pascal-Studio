---
name: xlsx
description: Créer, lire ou modifier un tableur Excel (.xlsx) ou CSV avec formules.
triggers: excel, xlsx, tableur, feuille de calcul, classeur, formule excel, tableau croisé, .xlsx, libreoffice calc
---
# Excel (.xlsx)
- **Sans outil** : écris un CSV dans `<fichier nom="tableau.csv">` (séparateur `;` ou `,`, première ligne = en-têtes) ; le bouton **Excel** de la visionneuse le convertit en .xlsx.
- **Avec outils** : `openpyxl` : `from openpyxl import Workbook; wb=Workbook(); ws=wb.active; ws.append(['Nom','Prix']); ws['C2']='=SUM(B2:B10)'; wb.save('t.xlsx')`. Lire : `load_workbook(f, data_only=True)`.
- Écris des FORMULES (`=SOMME` en français dans l'interface, `=SUM` dans le fichier) plutôt que des valeurs calculées à la main, pour que le tableur reste vivant.
- Une ligne d'en-têtes, un type de donnée par colonne, pas de cellules fusionnées dans les données, dates au format ISO.
- Vérifie les totaux par un calcul indépendant avant de livrer.
