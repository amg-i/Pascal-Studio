---
name: api-rest
description: Concevoir ou appeler une API REST (requêtes, JSON, authentification).
triggers: api rest, api, endpoint, requête http, curl, json, webhook, requests, fetch, openapi
---
# API REST
- Appels : `curl -sS -X POST URL -H 'Content-Type: application/json' -d '{"a":1}'` ; Python `requests` avec `timeout=` et `raise_for_status()`.
- Lis la documentation officielle (web_search) avant d'inventer un endpoint ; ne devine pas les champs.
- Authentification : clé dans une variable d'environnement, jamais dans le code ni dans une réponse.
- Conception : noms de ressources au pluriel, verbes HTTP corrects (GET lecture, POST création, PUT/PATCH modification, DELETE), codes 200/201/400/401/404/429/500, pagination, messages d'erreur JSON.
- Gère les limites de débit (429) avec une attente progressive.
