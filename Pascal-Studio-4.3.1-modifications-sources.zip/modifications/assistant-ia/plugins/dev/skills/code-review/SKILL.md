---
name: code-review
description: Relire du code : bugs, sécurité, lisibilité, performances.
triggers: revue de code, code review, relis ce code, relire mon code, vérifie ce code, audit du code, est-ce que ce code est bon
---
# Revue de code
Passe dans cet ordre et ne signale que du réel :
1. **Bugs** : cas limites (vide, None, 0, négatif), off-by-one, ressources non fermées, concurrence, erreurs ignorées.
2. **Sécurité** : entrées non validées, injection (SQL, shell, HTML), secrets en dur, chemins de fichiers, désérialisation.
3. **Clarté** : noms, fonctions trop longues, duplication, commentaires faux.
4. **Performance** : seulement si un problème est mesurable (boucle imbriquée sur grosses données, requêtes en boucle).
Format : liste classée (critique / important / mineur), chaque point avec la ligne, le problème, la correction proposée en code. Termine par ce qui est bien fait. Si tout va bien, dis-le simplement.
