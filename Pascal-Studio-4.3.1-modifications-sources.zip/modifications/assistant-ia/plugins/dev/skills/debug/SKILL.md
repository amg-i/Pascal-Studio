---
name: debug
description: Diagnostiquer et corriger une erreur, un plantage ou un comportement inattendu.
triggers: erreur, bug, traceback, exception, ça plante, ne marche pas, ne fonctionne pas, segfault, stack trace, debug, déboguer, message d'erreur
---
# Débogage
1. Lis le message d'erreur en entier : type, message, première ligne qui pointe vers le code de l'utilisateur.
2. Formule 1 à 3 causes possibles classées par probabilité, avec ce qui les confirmerait.
3. Si tu as les outils : reproduis (lance la commande), lis le fichier concerné, teste l'hypothèse — ne devine pas.
4. Corrige la cause, pas le symptôme. Montre le correctif minimal (avant/après), puis comment vérifier.
5. N'affirme « c'est corrigé » qu'après avoir relancé et obtenu le résultat attendu. Sinon écris ce qui reste à tester.
6. Il manque une info (version, système, code complet) ? Demande-la en une question précise.
