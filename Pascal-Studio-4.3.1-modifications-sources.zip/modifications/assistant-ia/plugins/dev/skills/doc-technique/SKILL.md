---
name: doc-technique
description: Écrire un README, une documentation technique ou des commentaires de code.
triggers: readme, documentation technique, documente ce code, docstring, commentaires de code, guide d'installation, doc de l'api
---
# Documentation technique
- README : titre + une phrase de but, prérequis, installation (commandes copiables), utilisation avec un exemple minimal, configuration, dépannage, licence.
- Teste mentalement chaque commande : un débutant doit pouvoir la suivre sans rien deviner. Versions et chemins précis.
- Docstrings : ce que fait la fonction, paramètres, valeur de retour, exceptions ; pas de paraphrase du code.
- Commentaires : expliquent le POURQUOI, pas le quoi.
- Livre dans `<fichier nom="README.md">`.
