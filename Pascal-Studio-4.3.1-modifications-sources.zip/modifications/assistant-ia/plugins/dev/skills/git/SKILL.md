---
name: git
description: Utiliser Git : commits, branches, fusions, annulations, résolution de conflits.
triggers: git, commit, branche, merge, rebase, pull request, github, gitlab, conflit de fusion, git stash, annuler un commit
---
# Git
- État : `git status`, `git log --oneline -10`, `git diff`. Regarde avant d'agir.
- Annuler sans perte : `git restore fichier` (travail non commité), `git revert <commit>` (commit publié), `git stash` (mettre de côté).
- Dangereux, à ne lancer qu'avec accord explicite et en prévenant : `git reset --hard`, `git push --force`, `git clean -fd`, `git rebase` sur une branche partagée.
- Messages de commit : impératif, ≤ 72 caractères, « Corrige le calcul de la TVA », corps = pourquoi.
- Conflit : ouvre le fichier, garde la bonne partie entre `<<<<<<<` `=======` `>>>>>>>`, supprime les marqueurs, `git add`, puis `git commit`.
- Ne commit jamais de secrets (.env, clés) ; ajoute-les à `.gitignore`.
