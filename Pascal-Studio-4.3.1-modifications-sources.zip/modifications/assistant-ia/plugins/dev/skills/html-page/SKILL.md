---
name: html-page
description: Créer une page web ou une petite application HTML/CSS/JavaScript autonome.
triggers: page web, site web, html, css, landing page, calculatrice en html, petite application web, mini jeu, formulaire html
---
# Page web autonome
- Un seul fichier `<fichier nom="index.html">` : HTML + `<style>` + `<script>`, sans bibliothèque externe (l'aperçu du chat n'a pas accès au réseau).
- `<!doctype html>`, `<meta charset="utf-8">`, `<meta name="viewport" ...>`, texte en français, `lang="fr"`.
- Mise en page responsive (flex/grid), contraste suffisant, boutons et champs avec libellés, aucune dépendance externe, pas de clé secrète dans le code.
- JavaScript : pas d'`eval`, échappe le texte inséré (`textContent` plutôt que `innerHTML`).
- Vérifie l'aperçu dans la visionneuse puis corrige si besoin.
