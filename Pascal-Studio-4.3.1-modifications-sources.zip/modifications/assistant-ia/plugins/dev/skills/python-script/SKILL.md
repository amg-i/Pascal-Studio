---
name: python-script
description: Écrire un script Python propre et exécutable.
triggers: script python, programme python, python, en python, fichier .py, automatise avec python
---
# Script Python
- Structure : imports, constantes, fonctions courtes avec type hints, `def main():`, `if __name__ == "__main__": main()`.
- Arguments avec `argparse`, fichiers avec `pathlib.Path`, ouverture avec `with` et `encoding="utf-8"`, journaux avec `logging`.
- Gère les erreurs attendues (fichier absent, réseau) avec un message clair ; pas de `except:` nu.
- Dépendances : liste-les avec la commande `pip install` ; préfère la bibliothèque standard.
- Livre un fichier complet `<fichier nom="script.py">`, puis (si tu as les outils) exécute-le sur un exemple et montre le vrai résultat.
