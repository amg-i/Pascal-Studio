---
name: refactor
description: Restructurer du code sans changer son comportement.
triggers: refactor, refactorer, refactorisation, nettoie ce code, simplifie ce code, restructure, factorise, code propre
---
# Refactorisation
1. Comprends et note le comportement actuel ; s'il n'y a pas de test, écris-en un minimal d'abord (ou vérifie à la main avec des entrées d'exemple).
2. Petites étapes, une à la fois : renommer → extraire une fonction → supprimer la duplication → simplifier les conditions (retours anticipés).
3. Ne change ni l'interface publique, ni le format des données, ni les messages d'erreur sans le dire.
4. Montre le résultat complet et ce qui a changé en 3-5 puces. Relance les tests / l'exemple pour confirmer l'équivalence.
5. Pas de réécriture complète « pour faire joli » : seulement ce qui améliore vraiment la lecture ou la fiabilité.
