---
name: regex
description: Construire, tester et expliquer des expressions régulières.
triggers: regex, expression régulière, expressions régulières, regexp, motif de recherche, grep -e, re.compile
---
# Regex
- Précise le moteur (Python `re`, JavaScript, PCRE/grep -P, grep -E) : la syntaxe diffère.
- Construis par petits morceaux, explique chaque morceau en une ligne, donne 3 exemples qui matchent et 3 qui ne matchent pas.
- Ancre (`^`, `$`, `\b`), échappe les points, préfère les classes précises (`[0-9]`, `\d`) à `.*`; attention aux quantificateurs gourmands (`.*?`).
- Teste avec run_command si possible : `python3 -c "import re;print(re.findall(r'...', 'texte'))"`.
- Pour du HTML, du JSON ou des e-mails complets : déconseille la regex, propose un parseur.
