---
name: shell-linux
description: Écrire des commandes et scripts shell (bash) sûrs.
triggers: script bash, script shell, bash, commande linux, one-liner, sed, awk, grep, find, xargs, cron, ligne de commande
---
# Shell / bash
- Scripts : `#!/usr/bin/env bash`, `set -euo pipefail`, variables entre guillemets `"$var"`, `[[ ]]` pour les tests, fonctions courtes, `trap` pour nettoyer.
- Teste en lecture seule d'abord (`echo`, `ls`, `--dry-run`, `-n`) ; pour `rm`/`mv` sur plusieurs fichiers, affiche la liste avant.
- Chemins avec espaces : `find ... -print0 | xargs -0 ...`. Jamais `rm -rf $var/` sans vérifier que `$var` n'est pas vide.
- Donne la commande ET une phrase qui explique chaque option non évidente.
- Planification : `crontab -e` (`*/15 * * * * commande`) ou timer systemd ; précise le chemin absolu des commandes.
