---
name: sql
description: Écrire, optimiser et expliquer des requêtes SQL.
triggers: sql, requête sql, select, jointure, join, group by, sqlite, postgresql, mysql, base de données, index
---
# SQL
- Demande ou déduis le schéma (tables, clés). Ne devine pas les noms de colonnes : liste-les (`.schema` en SQLite, `\d table` en PostgreSQL).
- Écris des requêtes lisibles : un mot-clé par ligne, alias courts, `JOIN ... ON` explicite, jamais `SELECT *` dans du code final.
- Paramètres : toujours des requêtes préparées (`?` / `%s`), jamais de concaténation de texte utilisateur.
- Avant `UPDATE`/`DELETE` : fais d'abord le `SELECT` avec le même `WHERE` et montre le nombre de lignes touchées ; propose une transaction (`BEGIN … ROLLBACK/COMMIT`).
- Lenteur : `EXPLAIN` / `EXPLAIN QUERY PLAN`, index sur les colonnes de `WHERE`/`JOIN`, évite les fonctions sur une colonne indexée.
