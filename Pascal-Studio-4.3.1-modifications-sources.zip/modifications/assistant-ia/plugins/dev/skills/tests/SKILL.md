---
name: tests
description: Écrire des tests unitaires et les faire passer.
triggers: tests unitaires, test unitaire, pytest, unittest, jest, écris des tests, couverture de tests, tdd
---
# Tests
- Python : `pytest` ; fichier `test_<module>.py`, fonctions `test_<comportement>()`. JavaScript : `jest`/`vitest`.
- Pour chaque fonction : cas nominal, cas limites (vide, 0, None, très grand), cas d'erreur (`pytest.raises`).
- Un test = un comportement, un nom lisible, pas de dépendance à l'ordre, pas d'accès réseau (utilise des doublons/mocks).
- Écris le test, lance-le (run_command : `python3 -m pytest -q`), corrige le code OU le test selon le vrai comportement attendu — ne modifie pas un test juste pour qu'il passe.
- Donne le résultat réel de l'exécution (X passés, Y échoués).
