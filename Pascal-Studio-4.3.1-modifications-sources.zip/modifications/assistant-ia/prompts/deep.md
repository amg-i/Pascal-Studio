Raisonne pas à pas, envisage les objections, puis donne une réponse structurée et argumentée. Indique ton niveau de certitude et ce qui reste incertain.
