"""Bac à sable jetable pour tester un exemple de l'aide.

Réponse au choix de l'utilisateur : chaque essai se déroule dans un dossier
temporaire SUPPRIMÉ ensuite, avec une limite de temps, une taille de sortie
bornée et des limites de ressources. Aucun privilège particulier n'est requis :
ni bubblewrap, ni espace de noms, ni montage.

Ce que cela garantit vraiment, et ce que cela ne garantit pas :

  garanti   le dossier de travail est isolé et détruit ; le processus est dans
            son propre groupe et tué par signal à l'échéance ; la mémoire, le
            temps processeur, la taille des fichiers écrits et le nombre de
            processus sont plafonnés par setrlimit ; la sortie est tronquée.

  limité    sans espace de noms, deux choses restent possibles pour le code
            exécuté, et il faut le dire plutôt que le laisser croire :

            • Réseau — un processus lancé avec les droits de l'utilisateur peut
              encore ouvrir un socket. On coupe donc le réseau de la manière la
              plus efficace disponible sans privilège : mandataires pointant vers
              un trou noir, résolution DNS rendue inutilisable par RES_OPTIONS,
              télémétries et index distants désactivés (PIP_NO_INDEX,
              CARGO_NET_OFFLINE, GOPROXY=off, npm_config_offline…). Les outils
              qui respectent ces variables — pip, npm, cargo, go, curl, wget, la
              plupart des gestionnaires de paquets — n'atteindront rien. Un
              programme qui ouvrirait un socket en dur n'est PAS arrêté.

            • Système de fichiers — le code peut écrire AILLEURS que dans le
              dossier temporaire, avec les droits de l'utilisateur. Seul
              RLIMIT_FSIZE borne la taille d'un fichier écrit. Vérifié :
              open('/tmp/x','w') réussit. Un cloisonnement réel exigerait des
              espaces de noms ou bubblewrap, explicitement écartés.

            Le bac à sable protège donc contre l'accident (boucle infinie,
            sortie énorme, fichier géant, projet pollué), pas contre un exemple
            volontairement malveillant. C'est le contrat du choix « temporaire ».

Le code de l'exemple n'est jamais écrit dans le projet : uniquement dans le
dossier temporaire.
"""

import os
import resource
import shutil
import signal
import subprocess
import tempfile
import time
from pathlib import Path

import langages

DELAI_INTERPRETE = 10
DELAI_COMPILATION = 60
DELAI_EXECUTION = 10
DELAI_CMAKE = 90
DELAI_LATEX = 60
LIMITE_CODE = 200_000
LIMITE_SORTIE = 200_000
LIMITE_ENTREE = 100_000
# Nombre d'instructions accordé au bouton « essayer » des fiches d'aide, pour les
# langages ésotériques dont le moteur tourne dans ce processus. La limite propre
# aux moteurs (deux millions de pas) est dimensionnée pour un programme réel ;
# ici il s'agit d'une démonstration interactive, et certains programmes publiés
# ne se terminent jamais — le « cat » de Malbolge émet indéfiniment le caractère
# 168 une fois l'entrée épuisée. Sans ce plafond, un clic pourrait immobiliser le
# serveur pendant des minutes. 200 000 pas s'exécutent en moins d'une seconde.
LIMITE_ESSAI = 200_000
MEMOIRE_OCTETS = 1_500_000_000
MEMOIRE_JVM = 3_000_000_000
TAILLE_FICHIER = 50_000_000
NOMBRE_PROCESSUS = 128

# Langages dont la machine virtuelle réserve beaucoup d'adresse : un plafond
# trop bas les ferait échouer avant même de démarrer.
MEMOIRE_LARGE = frozenset(('kotlin', 'cs', 'go', 'rust', 'swift', 'java'))

# Nom de fichier attendu par l'outil, quand ce n'est pas « prog.<extension> ».
# .f imposerait le format fixe à un exemple en format libre : on force .f90.
NOMS_IMPOSES = {'make': 'Makefile', 'cmake': 'CMakeLists.txt',
                'latex': 'document.tex', 'csproj': 'projet.csproj',
                'fortran': 'prog.f90'}

# Recettes de compilation : (construction, exécution). Les marqueurs {cc},
# {src} et {exe} sont remplacés. Une liste vide signifie « rien à construire ».
RECETTES = {
    'pascal': (['{cc}', '-o{exe}', '{src}'], ['{exe}']),
    'c': (['{cc}', '-o', '{exe}', '{src}', '-lm'], ['{exe}']),
    'cpp': (['{cc}', '-o', '{exe}', '{src}'], ['{exe}']),
    'fortran': (['{cc}', '-o', '{exe}', '{src}'], ['{exe}']),
    'rust': (['{cc}', '-o', '{exe}', '{src}'], ['{exe}']),
    'go': (['{cc}', 'build', '-o', '{exe}', '{src}'], ['{exe}']),
    'swift': (['{cc}', '-o', '{exe}', '{src}'], ['{exe}']),
    'kotlin': (['{cc}', '{src}', '-include-runtime', '-d', '{exe}.jar'],
               ['java', '-jar', '{exe}.jar']),
    'ocaml': (['ocamlc', '-o', '{exe}', '{src}'], ['{exe}']),
    'cs': (['{cc}', '{src}', '-out:{exe}.exe'], ['mono', '{exe}.exe']),
    'make': ([], ['make', '--no-print-directory']),
    'cmake': (['cmake', '-S', '.', '-B', 'construction'],
              ['cmake', '--build', 'construction']),
    'latex': ([], ['pdflatex', '-interaction=nonstopmode', '-halt-on-error',
                   'document.tex']),
}

# Binaire de remplacement quand le compilateur du registre n'est pas le bon nom.
BINAIRES = {'ocaml': 'ocamlc'}


def _trou_noir_reseau():
    """Variables d'environnement qui détournent le réseau vers un trou noir."""
    environ = dict(os.environ)
    trou = 'http://127.0.0.1:9'
    for cle in ('http_proxy', 'https_proxy', 'ftp_proxy', 'all_proxy',
                'HTTP_PROXY', 'HTTPS_PROXY', 'FTP_PROXY', 'ALL_PROXY'):
        environ[cle] = trou
    environ['no_proxy'] = ''
    environ['NO_PROXY'] = ''
    # Empêche les résolutions DNS de traîner en longueur.
    environ['RES_OPTIONS'] = 'timeout:1 attempts:1'
    # Télémétries et vérifications en ligne des outillages.
    environ.update({
        'PIP_NO_INDEX': '1', 'PIP_DISABLE_PIP_VERSION_CHECK': '1',
        'npm_config_offline': 'true', 'npm_config_audit': 'false',
        'npm_config_fund': 'false', 'CARGO_NET_OFFLINE': 'true',
        'GOPROXY': 'off', 'GOFLAGS': '-mod=mod',
        'DOTNET_CLI_TELEMETRY_OPTOUT': '1', 'DOTNET_SKIP_FIRST_TIME_EXPERIENCE': '1',
        'NUGET_OFFLINE': '1', 'HOMEBREW_NO_AUTO_UPDATE': '1',
        'CMAKE_DISABLE_FIND_PACKAGE_GIT': 'TRUE',
        'LC_ALL': 'C.UTF-8', 'LANG': 'C.UTF-8',
    })
    return environ


def _limites(memoire, cpu):
    """Fonction exécutée dans l'enfant, avant le programme.

    RLIMIT_CPU est une borne dure : même si le délai mur de communicate()
    manquait, le noyau enverrait SIGXCPU puis SIGKILL.
    """
    def appliquer():
        try:
            os.setsid()
        except OSError:
            pass
        secondes = max(1, int(cpu))
        limites = (
            (resource.RLIMIT_CORE, (0, 0)),
            (resource.RLIMIT_FSIZE, (TAILLE_FICHIER, TAILLE_FICHIER)),
            (resource.RLIMIT_NPROC, (NOMBRE_PROCESSUS, NOMBRE_PROCESSUS)),
            (resource.RLIMIT_AS, (memoire, memoire)),
            (resource.RLIMIT_CPU, (secondes, secondes + 1)),
        )
        for ressource, valeur in limites:
            try:
                resource.setrlimit(ressource, valeur)
            except (ValueError, OSError):
                pass
    return appliquer


def _tuer(proc):
    """Tue tout le groupe : un exemple peut lancer des enfants."""
    if not proc or proc.poll() is not None:
        return
    for signal_ in (signal.SIGTERM, signal.SIGKILL):
        try:
            os.killpg(os.getpgid(proc.pid), signal_)
        except (OSError, ProcessLookupError):
            try:
                proc.send_signal(signal_)
            except (OSError, ProcessLookupError):
                return
        try:
            proc.wait(timeout=3)
            return
        except subprocess.TimeoutExpired:
            continue


def _borne(sortie):
    if sortie is None:
        return '', False
    if isinstance(sortie, bytes):
        sortie = sortie.decode('utf8', 'replace')
    tronquee = len(sortie) > LIMITE_SORTIE
    if tronquee:
        sortie = sortie[:LIMITE_SORTIE] + '\n… sortie tronquée …\n'
    return sortie, tronquee


def _executer(commande, dossier, entree, delai, memoire, cpu):
    """Lance une commande bornée. Renvoie (code, sortie, erreur, depasse)."""
    if isinstance(entree, str) and len(entree) > LIMITE_ENTREE:
        entree = entree[:LIMITE_ENTREE]
    try:
        proc = subprocess.Popen(
            commande, cwd=str(dossier), stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            errors='replace', env=_trou_noir_reseau(),
            preexec_fn=_limites(memoire, cpu), start_new_session=False)
    except OSError as erreur:
        return None, '', 'Impossible de lancer %s : %s' % (commande[0], erreur), False
    try:
        sortie, erreur_sortie = proc.communicate(entree, timeout=delai)
        return proc.returncode, sortie or '', erreur_sortie or '', False
    except subprocess.TimeoutExpired:
        _tuer(proc)
        try:
            sortie, erreur_sortie = proc.communicate(timeout=3)
        except Exception:
            sortie, erreur_sortie = '', ''
        return None, sortie or '', erreur_sortie or '', True
    finally:
        _tuer(proc)


def nom_de_fichier(kind):
    """Le nom de fichier que l'outil attend pour ce langage."""
    if kind in NOMS_IMPOSES:
        return NOMS_IMPOSES[kind]
    extensions = langages.extensions(kind)
    return 'prog' + (extensions[0] if extensions else '.txt')


def _binaire(kind):
    langage_ = langages.langage(kind)
    if not langage_:
        return None
    if langage_.compilateur in BINAIRES:
        return BINAIRES[langage_.compilateur]
    return langage_.compilateur or (
        langage_.commande_essai[0] if langage_.commande_essai else None)


def _esoterique(identifiant):
    """Le module des moteurs ésotériques, si ce langage en fait partie."""
    try:
        import langages_esoteriques
    except ImportError:
        return None
    return langages_esoteriques if langages_esoteriques.est_esoterique(identifiant) \
        else None


class _MoteurPietTexte:
    """Adaptateur qui donne à la source .piett la forme attendue par
    _essayer_esoterique() : moteur.executer(code, identifiant, entree, limite=…).

    L'exécution est réelle : piet_texte.executer() compile le texte en PNG puis
    lance langages_esoteriques.Piet, le moteur déjà validé. Aucun second
    interpréteur n'est écrit ici, et le compte rendu a les mêmes clés que celui
    des dix langages ésotériques — donc aucune branche d'affichage en plus.
    """

    @staticmethod
    def executer(code, identifiant, entree='', limite=None):
        import piet_texte
        return piet_texte.executer(code, entree or '', limite=limite)


def disponible(kind):
    """L'outil nécessaire est-il installé ? (binaire, message)"""
    identifiant = langages.resoudre(kind) or kind
    langage_ = langages.langage(identifiant)
    if not langage_:
        return False, 'Langage inconnu.'
    if identifiant == 'piet_texte':
        # Rien à installer : le texte est compilé en PNG puis exécuté par le
        # moteur Piet intégré. Annoncer « ce langage produit un rendu » ici
        # refuserait un programme qui s'exécute très bien.
        return True, ''
    if _esoterique(identifiant):
        # Aucun de ces langages n'est empaqueté pour Debian 13 : le moteur est
        # écrit dans Pascal Studio, donc il n'y a jamais rien à installer.
        return True, ''
    mode = langage_.essai
    if mode == 'non':
        return False, 'Ce langage ne s’exécute pas.'
    if mode == 'graphique' and identifiant != 'latex':
        return False, ('Ce langage produit un rendu : utilisez l’aperçu et '
                       'l’inspecteur visuel.')
    binaire = _binaire(identifiant)
    if not binaire:
        return False, 'Aucun outil connu pour ce langage.'
    if not shutil.which(binaire):
        return False, '%s est introuvable sur cette machine.' % binaire
    if identifiant == 'kotlin' and not shutil.which('java'):
        return False, 'java est introuvable : Kotlin compile mais ne peut pas s’exécuter.'
    if identifiant == 'cs' and not shutil.which('mono'):
        return False, 'mono est introuvable : l’exécutable C# ne peut pas être lancé.'
    return True, ''


def _essayer_esoterique(moteur, identifiant, code, entree, resultat):
    """Exécute un exemple ésotérique avec le moteur intégré, en processus.

    Rien n'est écrit sur le disque et aucun processus n'est créé : les bornes
    viennent du moteur lui-même (nombre d'instructions, taille de sortie et
    d'entrée), ce qui est plus strict qu'un dossier temporaire.
    """
    debut = time.monotonic()
    try:
        compte = moteur.executer(code, identifiant,
                                 entree if isinstance(entree, str) else '',
                                 limite=LIMITE_ESSAI)
    except Exception as exc:                      # jamais d'exception remontée
        resultat['etat'] = 'echec'
        resultat['message'] = 'Le moteur a échoué : %s' % exc
        resultat['duree_ms'] = int((time.monotonic() - debut) * 1000)
        return resultat
    resultat['duree_ms'] = int((time.monotonic() - debut) * 1000)
    sortie, tronquee = _borne(compte.get('sortie', ''))
    erreur, tronquee_erreur = _borne(compte.get('erreur', ''))
    resultat['sortie'] = sortie
    resultat['erreur'] = erreur
    resultat['tronquee'] = tronquee or tronquee_erreur
    resultat['commande'] = 'moteur local intégré'
    message = compte.get('message', '') or ''
    pas = compte.get('pas', 0)
    if message.startswith('Limite de'):
        # Le moteur a atteint sa borne d'instructions : c'est un délai, pas un
        # échec du programme. Malbolge, par exemple, ne s'arrête jamais.
        resultat['etat'] = 'delai'
        resultat['message'] = '%s (%d instruction(s) exécutée(s).)' % (message, pas)
    elif compte.get('ok'):
        resultat['etat'] = 'succes'
        resultat['ok'] = True
        resultat['code_retour'] = 0
        resultat['message'] = 'Exécuté par le moteur local en %d instruction(s).' % pas
    else:
        resultat['etat'] = 'echec'
        resultat['code_retour'] = 1
        resultat['message'] = message or 'Le programme a échoué.'
    return resultat


def essayer(kind, code, entree='', modele=None):
    """Exécute un exemple dans un dossier temporaire, puis le détruit.

    Renvoie un dictionnaire toujours complet, sans jamais lever : un outil
    absent ou un code qui plante donnent un état, pas une exception.
    """
    identifiant = langages.resoudre(kind) or kind
    langage_ = langages.langage(identifiant)
    resultat = {
        'ok': False, 'etat': 'refuse', 'langage': identifiant,
        'libelle': langage_.libelle if langage_ else '',
        'sortie': '', 'erreur': '', 'code_retour': None, 'duree_ms': 0,
        'tronquee': False, 'message': '', 'dossier': None, 'commande': None,
    }
    if not langage_:
        resultat['message'] = 'Langage inconnu.'
        return resultat
    if not isinstance(code, str):
        resultat['message'] = 'Aucun code à tester.'
        return resultat
    moteur = _esoterique(identifiant)
    # Le programme Whitespace est fait EXCLUSIVEMENT d'espaces, de tabulations et
    # de fins de ligne : le garde habituel « code.strip() est vide » refuserait
    # donc un programme valide. Pour ce langage, seul un contenu vraiment vide
    # est refusé.
    if not code.strip() and not (moteur and identifiant == 'whitespace'):
        resultat['message'] = 'Aucun code à tester.'
        return resultat
    if not code:
        resultat['message'] = 'Aucun code à tester.'
        return resultat
    if len(code) > LIMITE_CODE:
        resultat['message'] = 'Exemple trop volumineux pour être testé.'
        return resultat
    if identifiant == 'piet_texte':
        return _essayer_esoterique(_MoteurPietTexte(), identifiant, code, entree,
                                   resultat)
    if moteur:
        return _essayer_esoterique(moteur, identifiant, code, entree, resultat)
    mode = langage_.essai
    if mode == 'non':
        resultat['message'] = 'Ce langage ne s’exécute pas : rien à tester.'
        return resultat
    pret, pourquoi = disponible(identifiant)
    if not pret:
        resultat['etat'] = 'graphique' if mode == 'graphique' else 'indisponible'
        resultat['message'] = pourquoi
        return resultat

    binaire = _binaire(identifiant)
    memoire = MEMOIRE_JVM if identifiant in MEMOIRE_LARGE else MEMOIRE_OCTETS
    dossier = Path(tempfile.mkdtemp(prefix='ps-exemple-'))
    resultat['dossier'] = str(dossier)
    debut = time.monotonic()
    try:
        source = dossier / nom_de_fichier(identifiant)
        source.write_text(code, encoding='utf8')
        if modele:
            for nom, contenu in dict(modele).items():
                cible = (dossier / Path(nom).name)
                cible.write_text(str(contenu), encoding='utf8')
        executable = dossier / 'programme'
        recette = RECETTES.get(identifiant)
        if mode == 'interprete':
            etapes = [([binaire, str(source)], DELAI_INTERPRETE, DELAI_INTERPRETE)]
        elif recette is None:
            resultat['message'] = 'Aucune recette d’exécution pour ce langage.'
            return resultat
        else:
            construction, execution = recette
            etapes = []
            if construction:
                commande = [part.format(cc=binaire, src=str(source), exe=str(executable))
                            for part in construction]
                etapes.append((commande, DELAI_COMPILATION, DELAI_COMPILATION))
            if execution:
                commande = [part.format(cc=binaire, src=str(source), exe=str(executable))
                            for part in execution]
                delai = DELAI_CMAKE if identifiant == 'cmake' else (
                    DELAI_LATEX if identifiant == 'latex' else DELAI_EXECUTION)
                etapes.append((commande, delai, delai))
        sortie_finale = ''
        erreur_finale = ''
        for commande, delai, cpu in etapes:
            if not shutil.which(commande[0]) and not commande[0].startswith(str(dossier)):
                resultat['etat'] = 'indisponible'
                resultat['message'] = '%s est introuvable sur cette machine.' % commande[0]
                return resultat
            resultat['commande'] = ' '.join(commande)
            code_retour, sortie, erreur, depasse = _executer(
                commande, dossier, entree, delai, memoire, cpu)
            sortie_finale += sortie
            if erreur:
                erreur_finale += erreur
            if depasse:
                resultat['etat'] = 'delai'
                resultat['message'] = ('L’exécution a dépassé la limite de %d s '
                                       'et a été interrompue.' % delai)
                break
            if code_retour != 0:
                resultat['etat'] = 'echec'
                resultat['code_retour'] = code_retour
                resultat['message'] = ('Le programme a échoué (code %s).' % code_retour
                                       if code_retour is not None else 'Échec.')
                break
            resultat['code_retour'] = code_retour
        else:
            resultat['ok'] = True
            resultat['etat'] = 'succes'
            resultat['message'] = 'Exemple exécuté dans un dossier temporaire, puis détruit.'
        resultat['erreur'] = erreur_finale
        sortie_finale, tronquee = _borne(sortie_finale)
        erreur_finale, tronquee_erreur = _borne(resultat['erreur'])
        resultat['sortie'] = sortie_finale
        resultat['erreur'] = erreur_finale
        resultat['tronquee'] = tronquee or tronquee_erreur
        if resultat['etat'] == 'succes' and erreur_finale.strip():
            resultat['message'] = 'Exemple exécuté, avec des avertissements.'
        if identifiant == 'latex':
            produit = dossier / 'document.pdf'
            resultat['pdf'] = produit.is_file()
            if produit.is_file():
                resultat['message'] = 'PDF produit (%d octets).' % produit.stat().st_size
    except Exception as erreur:
        resultat['etat'] = 'echec'
        resultat['message'] = 'Essai impossible : %s' % erreur
    finally:
        resultat['duree_ms'] = int((time.monotonic() - debut) * 1000)
        shutil.rmtree(dossier, ignore_errors=True)
        resultat['dossier'] = None
    return resultat


def etat(kind):
    """Ce que l'interface doit afficher avant même de lancer un essai."""
    identifiant = langages.resoudre(kind) or kind
    pret, pourquoi = disponible(identifiant)
    langage_ = langages.langage(identifiant)
    return {'langage': identifiant,
            'libelle': langage_.libelle if langage_ else '',
            'mode': langage_.essai if langage_ else 'non',
            'disponible': pret,
            'binaire': _binaire(identifiant),
            'message': pourquoi if not pret else (
                'L’exemple sera exécuté par le moteur local intégré, en '
                'processus : aucun fichier n’est écrit, aucun réseau, avec une '
                'borne sur le nombre d’instructions et sur la taille de sortie.'
                if (_esoterique(identifiant) or identifiant == 'piet_texte') else
                'L’exemple sera exécuté dans un dossier temporaire jetable, '
                'sans réseau et avec une limite de temps.'),
            'delai_s': DELAI_COMPILATION if (langage_ and langage_.essai == 'compile')
            else DELAI_INTERPRETE}
