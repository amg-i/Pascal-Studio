"""Bibliothèques de complétion : mots-clefs, types, extraits et motifs.

Une bibliothèque par langage, désignée par la clef « bibliotheque » du
registre (langages.py). Elle contient tout ce dont le moteur local a besoin
quand aucun serveur de langage n'est installé :

  mots_clefs   les mots réservés et courants du langage ;
  types        les types et classes fournis par le langage ;
  extraits     des modèles avec tabulations ($1, ${2:nom}, $0) ;
  motifs       des expressions régulières qui extraient les symboles déclarés
               dans un fichier, pour l'index du projet ;
  valeurs      pour HTML et CSS, les valeurs autorisées d'une propriété ou
               d'un attribut donné.

Les tables CSS, CMake, C# et HTML déjà éprouvées par verificateurs_statiques
sont réutilisées telles quelles : une seule source de vérité, donc aucun risque
de voir la complétion proposer une propriété que l'analyseur rejette.
"""

import re
from dataclasses import dataclass, field

from verificateurs_statiques import (AT_RULES, COMMANDES_CMAKE, MOTS_CLEFS_CS,
                                     PROPRIETES_CSS)

# LSP CompletionItemKind, de 1 à 25 dans l'ordre de la spécification.
(TEXTE, METHODE, FONCTION, CONSTRUCTEUR, CHAMP, VARIABLE, CLASSE, INTERFACE,
 MODULE, PROPRIETE, UNITE, VALEUR, ENUMERATION, MOT_CLEF, EXTRAIT, COULEUR,
 FICHIER, REFERENCE, DOSSIER, MEMBRE_ENUM, CONSTANT, STRUCTURE, EVENEMENT,
 OPERATEUR, PARAMETRE) = range(1, 26)

BALISES_HTML = (
    'a abbr address area article aside audio b base bdi bdo blockquote body br '
    'button canvas caption cite code col colgroup data datalist dd del details '
    'dfn dialog div dl dt em embed fieldset figcaption figure footer form h1 h2 '
    'h3 h4 h5 h6 head header hgroup hr html i iframe img input ins kbd label '
    'legend li link main map mark menu meta meter nav noscript object ol '
    'optgroup option output p param picture pre progress q rp rt ruby s samp '
    'script search section select slot small source span strong style sub '
    'summary sup table tbody td template textarea tfoot th thead time title tr '
    'track u ul var video wbr'
)

ATTRIBUTS_HTML = (
    'accept accept-charset accesskey action align alt async autocapitalize '
    'autocomplete autofocus autoplay charset checked cite class color cols '
    'colspan content contenteditable controls coords crossorigin datetime '
    'decoding default defer dir dirname disabled download draggable dropzone '
    'enctype enterkeyhint for form formaction formenctype formmethod '
    'formnovalidate formtarget headers height hidden high href hreflang '
    'http-equiv id inert inputmode integrity is itemid itemprop itemref '
    'itemscope itemtype kind label lang list loading loop low max maxlength '
    'media method min minlength multiple muted name novalidate open optimum '
    'pattern ping placeholder playsinline poster preload readonly referrerpolicy '
    'rel required reversed role rows rowspan sandbox scope selected shape size '
    'sizes slot span spellcheck src srcdoc srclang srcset start step style '
    'tabindex target title translate type usemap value width wrap'
)


@dataclass(frozen=True)
class Extrait:
    """Un modèle de code insérable, avec ses tabulations."""
    libelle: str
    insertion: str
    detail: str = ''
    genre: int = EXTRAIT


@dataclass(frozen=True)
class Motif:
    """Une expression régulière qui capture un nom de symbole déclaré."""
    expression: object
    genre: int
    detail: str = ''
    groupe: int = 1


@dataclass(frozen=True)
class Bibliotheque:
    nom: str
    mots_clefs: tuple = ()
    types: tuple = ()
    extraits: tuple = ()
    motifs: tuple = ()
    valeurs: dict = field(default_factory=dict)
    prefixe: str = ''          # préfixe des extraits (ex. « @ » pour CSS)


def _m(texte):
    return tuple(texte.split())


def _e(libelle, insertion, detail=''):
    return Extrait(libelle, insertion, detail)


def _x(expression, genre, detail='', groupe=1):
    return Motif(re.compile(expression, re.MULTILINE), genre, detail, groupe)


def _b(nom, mots='', types='', extraits=(), motifs=(), valeurs=None, prefixe=''):
    return Bibliotheque(nom=nom, mots_clefs=_m(mots) if isinstance(mots, str) else tuple(mots),
                        types=_m(types) if isinstance(types, str) else tuple(types),
                        extraits=tuple(extraits), motifs=tuple(motifs),
                        valeurs=dict(valeurs or {}), prefixe=prefixe)


# Les motifs d'extraction partagés par les langages à syntaxe « C ».
MOTIF_FONCTION_C = _x(
    r'^[ \t]*(?:static[ \t]+|inline[ \t]+|extern[ \t]+|const[ \t]+)*'
    r'[A-Za-z_][\w \t:*&<>,]*?[ \t*&]([A-Za-z_]\w*)[ \t]*\([^;{)]*\)[ \t]*'
    r'(?:const[ \t]*)?(?:=[ \t]*0[ \t]*)?(?=\{|$)', FONCTION, 'définition')
MOTIF_TYPE_C = _x(r'^[ \t]*(?:typedef[ \t]+)?(?:struct|union|enum)\s+([A-Za-z_]\w*)',
                  STRUCTURE, 'type')
MOTIF_MACRO_C = _x(r'^\s*#\s*define\s+([A-Za-z_]\w*)', CONSTANT, 'macro')


def _tables_assembleur():
    """Mots et registres de l'assembleur, LUS dans assembleur.py.

    Les recopier ici créerait un second tableau qui finirait par diverger du
    module d'analyse : la complétion proposerait alors des mnémoniques que
    l'analyseur ne connaît pas, ou refuserait des registres valides. C'est la
    raison pour laquelle le registre des langages et le résolveur d'extensions
    lisent déjà une source unique. Si assembleur.py est absent, on rend des
    tables vides : la complétion propose moins, mais rien ne casse.
    """
    try:
        import assembleur
    except ImportError:
        return (), ()
    mots = tuple(sorted(set(assembleur.MNEMONIQUES))) + tuple(sorted(
        set(assembleur.DIRECTIVES_GAS) | set(assembleur.DIRECTIVES_NASM)))
    return mots, tuple(sorted(assembleur.TOUS_REGISTRES))


_ASM_MOTS, _ASM_REGISTRES = _tables_assembleur()


BIBLIOTHEQUES = {

    'pascal': _b(
        'pascal',
        mots='and array as asm begin case class const constructor destructor div '
             'do downto else end except exports file finalization finally for '
             'function goto if implementation in inherited initialization inline '
             'interface is label library mod nil not object of or out packed '
             'procedure program property public private protected published '
             'record repeat set shl shr then threadvar to try type unit until '
             'uses var while with xor True False',
        types='Integer Cardinal Byte Word LongInt LongWord Int64 QWord Real '
              'Single Double Extended Comp Boolean Char AnsiChar WideChar '
              'String AnsiString WideString ShortString Pointer Variant '
              'TextFile TDateTime SizeInt SizeUInt PtrInt NativeInt',
        extraits=(
            _e('program', 'program ${1:nom};\n\nbegin\n\t$0\nend.', 'squelette de programme'),
            _e('procedure', 'procedure ${1:Nom};\nbegin\n\t$0\nend;', 'procédure'),
            _e('function', 'function ${1:Nom}(${2:arguments}): ${3:Integer};\nbegin\n\t$0\nend;', 'fonction'),
            _e('for', 'for ${1:i} := ${2:0} to ${3:10} do\nbegin\n\t$0\nend;', 'boucle for'),
            _e('while', 'while ${1:condition} do\nbegin\n\t$0\nend;', 'boucle while'),
            _e('repeat', 'repeat\n\t$0\nuntil ${1:condition};', 'boucle repeat'),
            _e('if', 'if ${1:condition} then\nbegin\n\t$0\nend;', 'condition'),
            _e('ifelse', 'if ${1:condition} then\nbegin\n\t$0\nend\nelse\nbegin\n\t\nend;', 'condition avec sinon'),
            _e('case', 'case ${1:valeur} of\n\t${2:1}: $0;\nelse\n\t;\nend;', 'aiguillage'),
            _e('try', 'try\n\t$0\nexcept\n\ton E: Exception do\n\t\tWriteLn(E.Message);\nend;', 'bloc protégé'),
            _e('record', '${1:Nom} = record\n\t${2:champ}: ${3:Integer};\nend;', 'enregistrement'),
            _e('unit', 'unit ${1:Nom};\n\ninterface\n\n$0\n\nimplementation\n\nend.', 'unité'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:function|procedure)\s+([A-Za-z_]\w*)', FONCTION, 'sous-programme'),
            _x(r'^[ \t]*type\s*\n?[ \t]*([A-Za-z_]\w*)\s*=', CLASSE, 'type'),
            _x(r'^[ \t]*([A-Za-z_]\w*)\s*=\s*(?:class|record|interface)\b', CLASSE, 'classe'),
            _x(r'^[ \t]*const\s+([A-Za-z_]\w*)\s*=', CONSTANT, 'constante'),
            _x(r'^[ \t]*var\s+([A-Za-z_]\w*)\s*:', VARIABLE, 'variable'),
            _x(r'^[ \t]*unit\s+([A-Za-z_]\w*)', MODULE, 'unité'),
        ),
    ),

    'c': _b(
        'c',
        mots='auto break case char const continue default do double else enum '
             'extern float for goto if inline int long register restrict return '
             'short signed sizeof static struct switch typedef union unsigned '
             'void volatile while _Bool _Complex _Imaginary NULL true false',
        types='int char float double void long short unsigned signed size_t '
              'ssize_t FILE int8_t int16_t int32_t int64_t uint8_t uint16_t '
              'uint32_t uint64_t ptrdiff_t intptr_t uintptr_t bool time_t '
              'div_t ldiv_t va_list',
        extraits=(
            _e('main', 'int main(int argc, char **argv)\n{\n\t$0\n\treturn 0;\n}', 'point d’entrée'),
            _e('include', '#include <${1:stdio.h}>', 'inclusion système'),
            _e('define', '#define ${1:NOM} ${2:valeur}', 'macro'),
            _e('for', 'for (${1:int i = 0}; ${2:i < n}; ${3:++i})\n{\n\t$0\n}', 'boucle for'),
            _e('if', 'if (${1:condition})\n{\n\t$0\n}', 'condition'),
            _e('ifelse', 'if (${1:condition})\n{\n\t$0\n}\nelse\n{\n\t\n}', 'condition avec sinon'),
            _e('while', 'while (${1:condition})\n{\n\t$0\n}', 'boucle while'),
            _e('switch', 'switch (${1:valeur})\n{\ncase ${2:0}:\n\t$0\n\tbreak;\ndefault:\n\tbreak;\n}', 'aiguillage'),
            _e('struct', 'struct ${1:Nom}\n{\n\t${2:int champ};\n};', 'structure'),
            _e('printf', 'printf("${1:%s}\\n"${2:, });', 'affichage'),
            _e('malloc', '${1:int} *${2:p} = malloc(${3:n} * sizeof(*$2));\nif ($2 == NULL)\n{\n\t$0\n}', 'allocation'),
        ),
        motifs=(MOTIF_FONCTION_C, MOTIF_TYPE_C, MOTIF_MACRO_C,
                _x(r'^[ \t]*(?:typedef[ \t]+)[\w \t:*]+\b([A-Za-z_]\w*)[ \t]*;', CLASSE, 'typedef')),
    ),

    'cpp': _b(
        'cpp',
        mots='alignas alignof and asm auto bool break case catch class '
             'concept const consteval constexpr constinit const_cast continue '
             'co_await co_return co_yield decltype default delete do dynamic_cast '
             'else enum explicit export extern false final for friend goto if '
             'inline int long mutable namespace new noexcept not nullptr operator '
             'or override private protected public reinterpret_cast requires '
             'return short signed sizeof static static_assert static_cast struct '
             'switch template this thread_local throw true try typedef typeid '
             'typename union unsigned using virtual void volatile while xor',
        types='std::string std::string_view std::vector std::array std::list '
              'std::deque std::map std::unordered_map std::set std::unordered_set '
              'std::pair std::tuple std::optional std::variant std::any '
              'std::unique_ptr std::shared_ptr std::weak_ptr std::function '
              'std::thread std::mutex std::atomic std::span std::istream '
              'std::ostream std::ifstream std::ofstream std::stringstream '
              'size_t int8_t int16_t int32_t int64_t uint8_t uint16_t uint32_t '
              'uint64_t char32_t',
        extraits=(
            _e('main', 'int main(int argc, char **argv)\n{\n\t$0\n\treturn 0;\n}', 'point d’entrée'),
            _e('class', 'class ${1:Nom}\n{\npublic:\n\t$1(${2:});\n\t~$1();\n\nprivate:\n\t$0\n};', 'classe'),
            _e('struct', 'struct ${1:Nom}\n{\n\t${2:int champ};\n};', 'structure'),
            _e('namespace', 'namespace ${1:nom}\n{\n$0\n} // namespace $1', 'espace de noms'),
            _e('template', 'template <typename ${1:T}>\n${2:void} ${3:fonction}($1 ${4:valeur})\n{\n\t$0\n}', 'modèle'),
            _e('for', 'for (${1:int i = 0}; ${2:i < n}; ${3:++i})\n{\n\t$0\n}', 'boucle for'),
            _e('forrange', 'for (const auto &${1:element} : ${2:conteneur})\n{\n\t$0\n}', 'parcours de conteneur'),
            _e('cout', 'std::cout << ${1:"texte"} << std::endl;', 'affichage'),
            _e('include', '#include <${1:iostream}>', 'inclusion'),
            _e('if', 'if (${1:condition})\n{\n\t$0\n}', 'condition'),
            _e('try', 'try\n{\n\t$0\n}\ncatch (const std::exception &e)\n{\n\tstd::cerr << e.what() << std::endl;\n}', 'bloc protégé'),
        ),
        motifs=(MOTIF_FONCTION_C, MOTIF_TYPE_C, MOTIF_MACRO_C,
                _x(r'^[ \t]*class\s+([A-Za-z_]\w*)', CLASSE, 'classe'),
                _x(r'^[ \t]*namespace\s+([A-Za-z_]\w*)', MODULE, 'espace de noms'),
                _x(r'^[ \t]*(?:template[^\n]*\n)?[ \t]*using\s+([A-Za-z_]\w*)\s*=', CLASSE, 'alias'),
                _x(r'^[ \t]*(?:constexpr|const)\s+[\w:<>,\s]+\b([A-Za-z_]\w*)\s*=', CONSTANT, 'constante')),
    ),

    'csharp': _b(
        'csharp', mots=tuple(MOTS_CLEFS_CS),
        types='string int bool double float decimal char byte sbyte short ushort '
              'long ulong object dynamic void var Task ValueTask List Dictionary '
              'HashSet Queue Stack IEnumerable ICollection IEnumerator Nullable '
              'Tuple StringBuilder Exception ArgumentException',
        extraits=(
            _e('namespace', 'namespace ${1:Nom}\n{\n\t$0\n}', 'espace de noms'),
            _e('class', 'public class ${1:Nom}\n{\n\t$0\n}', 'classe'),
            _e('Main', 'static void Main(string[] args)\n{\n\t$0\n}', 'point d’entrée'),
            _e('method', 'public ${1:void} ${2:Nom}(${3:})\n{\n\t$0\n}', 'méthode'),
            _e('foreach', 'foreach (var ${1:element} in ${2:collection})\n{\n\t$0\n}', 'parcours'),
            _e('for', 'for (int ${1:i} = 0; $1 < ${2:n}; $1++)\n{\n\t$0\n}', 'boucle for'),
            _e('if', 'if (${1:condition})\n{\n\t$0\n}', 'condition'),
            _e('try', 'try\n{\n\t$0\n}\ncatch (Exception e)\n{\n\tConsole.WriteLine(e.Message);\n}', 'bloc protégé'),
            _e('using', 'using ${1:System};', 'directive'),
            _e('prop', 'public ${1:string} ${2:Nom} { get; set; }', 'propriété'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:public|private|protected|internal|static|sealed|abstract|partial|async|virtual|override)[\w \t]*\b(?:class|record|struct|interface|enum)\s+([A-Za-z_]\w*)', CLASSE, 'type'),
            _x(r'^[ \t]*(?:public|private|protected|internal|static|async|virtual|override|sealed)[\w \t<>\[\],]*\s+([A-Za-z_]\w*)[ \t]*\([^)]*\)[ \t]*(?:\{|=>|$)', METHODE, 'méthode'),
            _x(r'^[ \t]*namespace\s+([A-Za-z_.]\w*)', MODULE, 'espace de noms'),
            _x(r'^[ \t]*(?:public|private|protected|internal|static|const|readonly)[\w \t]*\b([A-Za-z_]\w*)\s*(?:=|;)', VARIABLE, 'champ'),
        ),
    ),

    'makefile': _b(
        'makefile',
        mots='ifeq ifneq ifdef ifndef else endif define endef include -include '
             'override export unexport vpath .PHONY .DEFAULT .SUFFIXES '
             '.PRECIOUS .INTERMEDIATE .SECONDARY .DELETE_ON_ERROR .NOTPARALLEL '
             'subst patsubst strip findstring filter filter-out sort word '
             'wordlist words firstword lastdir notdir suffix basename addsuffix '
             'addprefix join wildcard realpath abspath error warning info shell '
             'foreach call if or and value eval file',
        extraits=(
            _e('cible', '${1:cible}: ${2:dépendances}\n\t${0:commande}', 'règle'),
            _e('phony', '.PHONY: ${1:clean}\n\n$1:\n\t$0', 'cible sans fichier'),
            _e('ifeq', 'ifeq (${1:$(CC)},gcc)\n\t$0\nendif', 'condition'),
            _e('foreach', '$(foreach ${1:v},$(shell seq 1 5),${2:echo $$v})', 'itération'),
            _e('clean', 'clean:\n\t$(RM) ${1:*.o $(CIBLE)}\n', 'nettoyage'),
        ),
        motifs=(
            _x(r'^([A-Za-z_][\w./-]*)\s*:(?!=)', VARIABLE, 'cible'),
            _x(r'^([A-Za-z_]\w*)\s*[:+?!]?=', CONSTANT, 'variable'),
            _x(r'^define\s+([A-Za-z_]\w*)', CONSTANT, 'macro'),
        ),
    ),

    'cmake': _b(
        'cmake', mots=tuple(COMMANDES_CMAKE) + _m(
            'if elseif else endif foreach endforeach while endwhile function '
            'endfunction macro endmacro return break continue block endblock '
            'CMAKE_CURRENT_SOURCE_DIR CMAKE_CURRENT_BINARY_DIR CMAKE_SOURCE_DIR '
            'CMAKE_BINARY_DIR PROJECT_NAME PROJECT_SOURCE_DIR CMAKE_INSTALL_PREFIX '
            'CMAKE_BUILD_TYPE CMAKE_CXX_STANDARD CMAKE_C_STANDARD BUILD_SHARED_LIBS '
            'CMAKE_EXPORT_COMPILE_COMMANDS TRUE FALSE ON OFF AND OR NOT'),
        extraits=(
            _e('project', 'cmake_minimum_required(VERSION ${1:3.16})\nproject(${2:Nom} VERSION ${3:1.0.0} LANGUAGES ${4:CXX})\n\n$0', 'squelette'),
            _e('add_executable', 'add_executable(${1:cible}\n\t${2:main.cpp})\n', 'exécutable'),
            _e('add_library', 'add_library(${1:cible} ${2:STATIC}\n\t${3:source.cpp})\n', 'bibliothèque'),
            _e('target_link_libraries', 'target_link_libraries(${1:cible} PRIVATE ${2:bibliotheque})\n', 'édition de liens'),
            _e('if', 'if(${1:condition})\n\t$0\nendif()\n', 'condition'),
            _e('foreach', 'foreach(${1:element} IN LISTS ${2:liste})\n\t$0\nendforeach()\n', 'itération'),
            _e('function', 'function(${1:nom} ${2:args})\n\t$0\nendfunction()\n', 'fonction'),
            _e('find_package', 'find_package(${1:Threads} REQUIRED)\n', 'recherche de paquet'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:function|macro)\s*\(\s*(\w+)', FONCTION, 'fonction CMake'),
            _x(r'^[ \t]*set\s*\(\s*(\w+)', VARIABLE, 'variable'),
            _x(r'^[ \t]*(?:add_executable|add_library)\s*\(\s*([\w.-]+)', MODULE, 'cible'),
        ),
    ),

    'latex': _b(
        'latex',
        mots='documentclass usepackage begin end section subsection subsubsection '
             'chapter part paragraph subparagraph label ref pageref cite textbf '
             'textit texttt underline emph item itemize enumerate description '
             'includegraphics caption newcommand renewcommand newenvironment '
             'input include bibliography bibliographystyle title author date '
             'maketitle tableofcontents footnote hspace vspace newline linebreak '
             'newpage clearpage pagebreak centering raggedright small large Large '
             'huge tiny normalsize footnotesize mathbb mathbf mathcal mathrm frac '
             'sqrt sum int prod lim alpha beta gamma delta theta lambda mu pi '
             'sigma omega Delta Omega quad qquad cdots ldots dots leq geq neq '
             'approx times cdot infty rightarrow leftrightarrow forall exists',
        types='document article report book letter beamer standalone revtex '
              'itemize enumerate description figure table tabular equation '
              'align gather multline center flushleft flushright quote quotation '
              'verbatim lstlisting minipage abstract appendix theorem proof '
              'definition lemma corollary example remark note tikzpicture frame '
              'columns block array matrix pmatrix bmatrix cases',
        extraits=(
            _e('document', '\\documentclass{${1:article}}\n\\usepackage[utf8]{inputenc}\n\\usepackage[T1]{fontenc}\n\\usepackage[french]{babel}\n\n\\title{${2:Titre}}\n\\author{${3:Auteur}}\n\\date{\\today}\n\n\\begin{document}\n\\maketitle\n\n$0\n\n\\end{document}\n', 'squelette complet'),
            _e('section', '\\section{${1:Titre}}\n$0', 'section'),
            _e('begin', '\\begin{${1:environnement}}\n\t$0\n\\end{$1}', 'environnement'),
            _e('itemize', '\\begin{itemize}\n\t\\item $0\n\\end{itemize}', 'liste à puces'),
            _e('enumerate', '\\begin{enumerate}\n\t\\item $0\n\\end{enumerate}', 'liste numérotée'),
            _e('figure', '\\begin{figure}[${1:h}]\n\t\\centering\n\t\\includegraphics[width=${2:0.8}\\textwidth]{${3:image.png}}\n\t\\caption{${4:Légende}}\n\t\\label{fig:${5:cle}}\n\\end{figure}', 'figure'),
            _e('table', '\\begin{table}[${1:h}]\n\t\\centering\n\t\\begin{tabular}{${2:lc}}\n\t\t\\hline\n\t\t$0 \\\\\n\t\t\\hline\n\t\\end{tabular}\n\t\\caption{${3:Légende}}\n\\end{table}', 'tableau'),
            _e('equation', '\\begin{equation}\n\t$0\n\\end{equation}', 'équation numérotée'),
            _e('newcommand', '\\newcommand{\\${1:nom}}[${2:1}]{${3:#1}}', 'nouvelle commande'),
            _e('cite', '\\cite{${1:cle}}', 'citation'),
            _e('ref', '\\ref{${1:cle}}', 'renvoi'),
        ),
        motifs=(
            _x(r'\\newcommand\s*\{\s*\\([A-Za-z]+)', FONCTION, 'commande définie'),
            _x(r'\\(?:re)?newenvironment\s*\{\s*([A-Za-z]+)', MODULE, 'environnement défini'),
            _x(r'\\label\s*\{\s*([^}\s]+)', REFERENCE, 'étiquette'),
            _x(r'\\bibitem\s*\{\s*([^}\s]+)', REFERENCE, 'référence bibliographique'),
        ),
    ),

    'rust': _b(
        'rust',
        mots='as async await break const continue crate dyn else enum extern '
             'false fn for if impl in let loop match mod move mut pub ref return '
             'self Self static struct super trait true type unsafe use where '
             'while union macro_rules derive Some None Ok Err Box Vec String str '
             'println print eprintln eprint format vec assert assert_eq debug_assert '
             'todo unimplemented unreachable cfg test target feature',
        types='i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool '
              'char String str Vec HashMap HashSet BTreeMap BTreeSet Option '
              'Result Box Rc Arc Cell RefCell Mutex RwLock PathBuf Path '
              'std::io::Error',
        extraits=(
            _e('fn', 'fn ${1:nom}(${2:}) -> ${3:()} {\n\t$0\n}', 'fonction'),
            _e('main', 'fn main() {\n\t$0\n}', 'point d’entrée'),
            _e('struct', 'struct ${1:Nom} {\n\t${2:champ}: ${3:u32},\n}', 'structure'),
            _e('impl', 'impl ${1:Nom} {\n\t$0\n}', 'implémentation'),
            _e('enum', 'enum ${1:Nom} {\n\t${2:Variante},\n}', 'énumération'),
            _e('match', 'match ${1:valeur} {\n\t${2:motif} => $0,\n\t_ => {}\n}', 'aiguillage'),
            _e('iflet', 'if let Some(${1:v}) = ${2:option} {\n\t$0\n}', 'si Some'),
            _e('for', 'for ${1:element} in ${2:iterable} {\n\t$0\n}', 'boucle'),
            _e('closure', 'let ${1:f} = |${2:x}| {\n\t$0\n};', 'fermeture'),
            _e('test', '#[test]\nfn ${1:test_nom}() {\n\t$0\n}', 'test'),
            _e('derive', '#[derive(${1:Debug, Clone})]\n$0', 'attribut derive'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:pub(?:\([^)]*\))?[ \t]+)?(?:async[ \t]+)?(?:unsafe[ \t]+)?fn\s+([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:pub[ \t]+)?struct\s+([A-Za-z_]\w*)', STRUCTURE, 'structure'),
            _x(r'^[ \t]*(?:pub[ \t]+)?enum\s+([A-Za-z_]\w*)', ENUMERATION, 'énumération'),
            _x(r'^[ \t]*(?:pub[ \t]+)?trait\s+([A-Za-z_]\w*)', INTERFACE, 'trait'),
            _x(r'^[ \t]*(?:pub[ \t]+)?mod\s+([A-Za-z_]\w*)', MODULE, 'module'),
            _x(r'^[ \t]*(?:pub[ \t]+)?const\s+([A-Za-z_]\w*)', CONSTANT, 'constante'),
            _x(r'^[ \t]*(?:pub[ \t]+)?static\s+([A-Za-z_]\w*)', CONSTANT, 'statique'),
            _x(r'^[ \t]*(?:pub[ \t]+)?type\s+([A-Za-z_]\w*)', CLASSE, 'alias de type'),
        ),
    ),

    'go': _b(
        'go',
        mots='break case chan const continue default defer else fallthrough for '
             'func go goto if import interface map package range return select '
             'struct switch type var nil true false iota len cap make new append '
             'copy delete panic recover print println close complex real imag '
             'any comparable',
        types='bool byte complex64 complex128 error float32 float64 int int8 '
              'int16 int32 int64 rune string uint uint8 uint16 uint32 uint64 '
              'uintptr fmt context sync time os io strings strconv errors',
        extraits=(
            _e('func', 'func ${1:Nom}(${2:}) ${3:error} {\n\t$0\n}', 'fonction'),
            _e('main', 'func main() {\n\t$0\n}', 'point d’entrée'),
            _e('iferr', 'if err != nil {\n\treturn ${1:fmt.Errorf("${2:contexte}: %w", err)}\n}', 'contrôle d’erreur'),
            _e('forrange', 'for ${1:i}, ${2:v} := range ${3:collection} {\n\t$0\n}', 'parcours'),
            _e('struct', 'type ${1:Nom} struct {\n\t${2:Champ} ${3:string}\n}', 'structure'),
            _e('interface', 'type ${1:Nom} interface {\n\t${2:Methode}() ${3:error}\n}', 'interface'),
            _e('goroutine', 'go func() {\n\t$0\n}()', 'goroutine'),
            _e('defer', 'defer ${1:f.Close}()', 'exécution différée'),
            _e('switch', 'switch ${1:valeur} {\ncase ${2:x}:\n\t$0\ndefault:\n}', 'aiguillage'),
            _e('method', 'func (${1:r} *${2:Nom}) ${3:Methode}(${4:}) ${5:error} {\n\t$0\n}', 'méthode'),
        ),
        motifs=(
            _x(r'^[ \t]*func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*type\s+([A-Za-z_]\w*)\s+(?:struct|interface)', CLASSE, 'type'),
            _x(r'^[ \t]*(?:const|var)\s+([A-Za-z_]\w*)', CONSTANT, 'constante'),
            _x(r'^[ \t]*package\s+([A-Za-z_]\w*)', MODULE, 'paquet'),
        ),
    ),

    'ruby': _b(
        'ruby',
        mots='alias and begin break case class def defined? do else elsif end '
             'ensure false for if in module next nil not or redo rescue retry '
             'return self super then true undef unless until when while yield '
             'require require_relative include extend prepend attr_accessor '
             'attr_reader attr_writer private protected public lambda proc raise '
             'puts print p format loop each map select reject reduce sort_by '
             'freeze frozen? nil? is_a? kind_of? respond_to? send method',
        types='String Symbol Integer Float Rational Complex Array Hash Range '
             'Regexp Proc Method Struct Class Module Object NilClass TrueClass '
             'FalseClass IOError Errno StandardError ArgumentError TypeError',
        extraits=(
            _e('class', 'class ${1:Nom}\n\tdef initialize(${2:})\n\t\t$0\n\tend\nend', 'classe'),
            _e('module', 'module ${1:Nom}\n\t$0\nend', 'module'),
            _e('def', 'def ${1:nom}(${2:})\n\t$0\nend', 'méthode'),
            _e('if', 'if ${1:condition}\n\t$0\nend', 'condition'),
            _e('unless', 'unless ${1:condition}\n\t$0\nend', 'condition inverse'),
            _e('each', '${1:collection}.each do |${2:element}|\n\t$0\nend', 'itération'),
            _e('map', '${1:collection}.map { |${2:x}| $0 }', 'transformation'),
            _e('begin', 'begin\n\t$0\nrescue ${1:StandardError} => e\n\twarn e.message\nend', 'bloc protégé'),
            _e('times', '${1:n}.times do |${2:i}|\n\t$0\nend', 'répétition'),
            _e('shebang', '#!/usr/bin/env ruby\n# frozen_string_literal: true\n\n$0', 'en-tête'),
        ),
        motifs=(
            _x(r'^[ \t]*def\s+(?:self\.)?([A-Za-z_]\w*[?!=]?)', METHODE, 'méthode'),
            _x(r'^[ \t]*class\s+([A-Z]\w*)', CLASSE, 'classe'),
            _x(r'^[ \t]*module\s+([A-Z]\w*)', MODULE, 'module'),
            _x(r'^[ \t]*([A-Z][A-Z0-9_]*)\s*=', CONSTANT, 'constante'),
        ),
    ),

    'python': _b(
        'python',
        mots='False None True and as assert async await break class continue '
             'def del elif else except finally for from global if import in is '
             'lambda nonlocal not or pass raise return try while with yield '
             'match case self cls print len range enumerate zip sorted reversed '
             'sum min max abs round isinstance issubclass hasattr getattr setattr '
             'super type vars dir id repr str int float bool list dict set tuple '
             'open input format map filter any all next iter slice staticmethod '
             'classmethod property',
        types='int float complex bool str bytes bytearray list tuple dict set '
              'frozenset object type Exception ValueError TypeError KeyError '
              'IndexError AttributeError RuntimeError StopIteration '
              'FileNotFoundError OSError ImportError ArithmeticError '
              'ZeroDivisionError NotImplementedError GeneratorType',
        extraits=(
            _e('main', 'if __name__ == "__main__":\n\t$0', 'point d’entrée'),
            _e('def', 'def ${1:nom}(${2:}) -> ${3:None}:\n\t"""${4:Description.}"""\n\t$0', 'fonction'),
            _e('class', 'class ${1:Nom}:\n\tdef __init__(self${2:, }) -> None:\n\t\t$0', 'classe'),
            _e('for', 'for ${1:element} in ${2:iterable}:\n\t$0', 'boucle'),
            _e('if', 'if ${1:condition}:\n\t$0', 'condition'),
            _e('try', 'try:\n\t$0\nexcept ${1:Exception} as erreur:\n\traise', 'bloc protégé'),
            _e('with', 'with open(${1:chemin}, ${2:"r"}, encoding="utf-8") as f:\n\t$0', 'gestionnaire de contexte'),
            _e('listcomp', '[${1:expression} for ${2:x} in ${3:iterable} if ${4:condition}]', 'compréhension de liste'),
            _e('dictcomp', '{${1:cle}: ${2:valeur} for ${3:x} in ${4:iterable}}', 'compréhension de dictionnaire'),
            _e('import', 'from ${1:module} import ${2:nom}', 'importation'),
            _e('docstring', '"""${1:Description.}\n\n${2:Details.}\n"""', 'docstring'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:async[ \t]+)?def\s+([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*class\s+([A-Za-z_]\w*)', CLASSE, 'classe'),
            _x(r'^([A-Za-z_]\w*)\s*(?::\s*[\w\[\], |\'"\.]+)?\s*=', VARIABLE, 'variable de module'),
            _x(r'^([A-Z][A-Z0-9_]*)\s*=', CONSTANT, 'constante'),
        ),
    ),

    'javascript': _b(
        'javascript',
        mots='async await break case catch class const continue debugger default '
             'delete do else export extends finally for from function get if '
             'import in instanceof let new of return set static super switch '
             'this throw try typeof var void while with yield null undefined '
             'true false NaN Infinity console document window process globalThis '
             'require module exports Promise Array Object String Number Boolean '
             'Map Set WeakMap WeakSet JSON Math Date RegExp Symbol Error '
             'setTimeout setInterval clearTimeout clearInterval fetch',
        types='Array Object String Number Boolean BigInt Symbol Map Set WeakMap '
              'WeakSet Date RegExp Promise Error TypeError RangeError '
              'SyntaxError Function Proxy Reflect ArrayBuffer DataView '
              'Int8Array Uint8Array Float64Array URL URLSearchParams FormData '
              'AbortController TextEncoder TextDecoder',
        extraits=(
            _e('function', 'function ${1:nom}(${2:}) {\n\t$0\n}', 'fonction'),
            _e('arrow', 'const ${1:nom} = (${2:}) => {\n\t$0\n};', 'fonction fléchée'),
            _e('class', 'class ${1:Nom} {\n\tconstructor(${2:}) {\n\t\t$0\n\t}\n}', 'classe'),
            _e('for', 'for (let ${1:i} = 0; $1 < ${2:n}; $1++) {\n\t$0\n}', 'boucle for'),
            _e('forof', 'for (const ${1:element} of ${2:iterable}) {\n\t$0\n}', 'parcours'),
            _e('if', 'if (${1:condition}) {\n\t$0\n}', 'condition'),
            _e('try', 'try {\n\t$0\n} catch (erreur) {\n\tconsole.error(erreur);\n}', 'bloc protégé'),
            _e('import', 'import ${1:nom} from "${2:module}";', 'importation'),
            _e('export', 'export ${1:function} ${2:nom}(${3:}) {\n\t$0\n}', 'exportation'),
            _e('promise', 'const ${1:donnee} = await new Promise((resoudre, rejeter) => {\n\t$0\n});', 'promesse'),
            _e('addEventListener', '${1:element}.addEventListener("${2:click}", (${3:evenement}) => {\n\t$0\n});', 'écouteur'),
            _e('log', 'console.log(${1:"message"}${2:, });', 'journal'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:export[ \t]+)?(?:async[ \t]+)?function\s*\*?\s*([A-Za-z_$]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:export[ \t]+)?(?:default[ \t]+)?class\s+([A-Za-z_$]\w*)', CLASSE, 'classe'),
            _x(r'^[ \t]*(?:export[ \t]+)?(?:const|let|var)\s+([A-Za-z_$]\w*)', VARIABLE, 'variable'),
            _x(r'^[ \t]*(?:const|let|var)\s+([A-Za-z_$]\w*)\s*=\s*(?:async\s*)?\(', FONCTION, 'fonction fléchée'),
            _x(r'^[ \t]*([A-Za-z_$]\w*)\s*:\s*(?:async\s*)?function', METHODE, 'méthode'),
        ),
    ),

    'php': _b(
        'php',
        mots='abstract and array as break callable case catch class clone const '
             'continue declare default do echo else elseif empty enddeclare '
             'endfor endforeach endif endswitch endwhile enum extends final '
             'finally fn for foreach function global goto if implements include '
             'include_once instanceof insteadof interface isset list match '
             'namespace new or print private protected public readonly require '
             'require_once return static switch throw trait try unset use var '
             'while xor yield true false null parent self',
        types='int float string bool array object mixed iterable void never '
              'callable null self static parent DateTime DateTimeImmutable '
              'Exception Error TypeError ValueError PDO mysqli ArrayObject '
              'Generator Closure stdClass Throwable',
        extraits=(
            _e('class', 'class ${1:Nom}\n{\n\tpublic function __construct(${2:})\n\t{\n\t\t$0\n\t}\n}', 'classe'),
            _e('function', 'function ${1:nom}(${2:}): ${3:void}\n{\n\t$0\n}', 'fonction'),
            _e('if', 'if (${1:condition}) {\n\t$0\n}', 'condition'),
            _e('foreach', 'foreach (${1:tableau} as ${2:cle} => ${3:valeur}) {\n\t$0\n}', 'parcours'),
            _e('try', 'try {\n\t$0\n} catch (${1:Throwable} $e) {\n\terror_log($e->getMessage());\n}', 'bloc protégé'),
            _e('namespace', 'namespace ${1:Espace\\Nom};\n\n$0', 'espace de noms'),
            _e('use', 'use ${1:Espace\\Nom\\Classe};', 'importation'),
            _e('echo', 'echo "${1:texte}";', 'affichage'),
            _e('interface', 'interface ${1:Nom}\n{\n\tpublic function ${2:methode}();\n}', 'interface'),
            _e('trait', 'trait ${1:Nom}\n{\n\t$0\n}', 'trait'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:public|private|protected|static|abstract|final|readonly)[\w \t]*function\s+([A-Za-z_]\w*)', METHODE, 'méthode'),
            _x(r'^[ \t]*function\s+([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:abstract[ \t]+|final[ \t]+|readonly[ \t]+)*(?:class|interface|trait|enum)\s+([A-Za-z_]\w*)', CLASSE, 'type'),
            _x(r'^[ \t]*(?:const|define\s*\()\s*[\'"]?([A-Za-z_]\w*)', CONSTANT, 'constante'),
            _x(r'^[ \t]*namespace\s+([A-Za-z_\\\w]+)', MODULE, 'espace de noms'),
        ),
    ),

    'html': _b(
        'html', mots=BALISES_HTML, types=ATTRIBUTS_HTML,
        valeurs={
            'type': 'text password email number tel url search date time '
                    'datetime-local month week color range file submit reset '
                    'button checkbox radio hidden image',
            'inputmode': 'none text decimal numeric tel search email url',
            'target': '_self _blank _parent _top',
            'rel': 'stylesheet noopener noreferrer nofollow alternate icon '
                   'author bookmark canonical license prefetch preload manifest',
            'method': 'get post dialog',
            'enctype': 'application/x-www-form-urlencoded multipart/form-data '
                       'text/plain',
            'autocomplete': 'on off name email username current-password '
                            'new-password tel address postal-code country '
                            'cc-number organization street-address',
            'crossorigin': 'anonymous use-credentials',
            'loading': 'lazy eager',
            'decoding': 'sync async auto',
            'dir': 'ltr rtl auto',
            'scope': 'row col rowgroup colgroup',
            'wrap': 'soft hard',
            'role': 'button link navigation main banner contentinfo '
                    'complementary form search list listitem alert dialog '
                    'tab tablisttabpanel tooltip status progressbar',
            'align': 'left right center justify',
            'referrerpolicy': 'no-referrer no-referrer-when-downgrade origin '
                               'origin-when-crossorigin unsafe-url',
            'sandbox': 'allow-forms allow-modals allow-popups '
                       'allow-same-origin allow-scripts allow-top-navigation',
            'media': 'screen print all speech',
        },
        extraits=(
            _e('html5', '<!DOCTYPE html>\n<html lang="fr">\n<head>\n\t<meta charset="utf-8">\n\t<meta name="viewport" content="width=device-width, initial-scale=1">\n\t<title>${1:Titre}</title>\n\t<link rel="stylesheet" href="${2:style.css}">\n</head>\n<body>\n\t$0\n\t<script src="${3:script.js}"></script>\n</body>\n</html>', 'squelette complet'),
            _e('div', '<div class="${1:nom}">\n\t$0\n</div>', 'conteneur'),
            _e('a', '<a href="${1:https://}">${2:texte}</a>', 'lien'),
            _e('img', '<img src="${1:image.png}" alt="${2:description}" width="${3:}" height="${4:}">', 'image'),
            _e('form', '<form action="${1:}" method="${2:post}">\n\t$0\n\t<button type="submit">Envoyer</button>\n</form>', 'formulaire'),
            _e('input', '<input type="${1:text}" name="${2:nom}" id="$2" placeholder="${3:}">', 'champ de saisie'),
            _e('table', '<table>\n\t<thead>\n\t\t<tr><th>$1</th></tr>\n\t</thead>\n\t<tbody>\n\t\t<tr><td>$0</td></tr>\n\t</tbody>\n</table>', 'tableau'),
            _e('ul', '<ul>\n\t<li>$0</li>\n</ul>', 'liste'),
            _e('script', '<script src="${1:script.js}" defer></script>', 'script'),
            _e('style', '<style>\n\t$0\n</style>', 'style'),
            _e('meta', '<meta name="${1:description}" content="${2:}">', 'métadonnée'),
            _e('section', '<section id="${1:nom}">\n\t<h2>${2:Titre}</h2>\n\t$0\n</section>', 'section'),
        ),
        motifs=(
            _x(r'\bid\s*=\s*["\']([^"\']+)["\']', CONSTANT, 'identifiant'),
            _x(r'\bclass\s*=\s*["\']([^"\']+)["\']', CLASSE, 'classe'),
            _x(r'<\s*(?:h1|h2|h3|h4|h5|h6)[^>]*>\s*([^<]{1,80})', REFERENCE, 'titre'),
        ),
    ),

    'css': _b(
        'css', mots=tuple(PROPRIETES_CSS),
        types=tuple('@' + r for r in sorted(AT_RULES)) + _m(
            'important inherit initial unset revert auto none normal center '
            'transparent currentColor'),
        valeurs={
            'display': 'block inline inline-block flex inline-flex grid '
                       'inline-grid table inline-table table-row table-cell '
                       'table-column none contents flow-root list-item',
            'position': 'static relative absolute fixed sticky',
            'overflow': 'visible hidden scroll auto clip',
            'overflow-x': 'visible hidden scroll auto clip',
            'overflow-y': 'visible hidden scroll auto clip',
            'float': 'left right none inline-start inline-end',
            'clear': 'left right both none inline-start inline-end',
            'text-align': 'left right center justify start end match-parent',
            'text-align-last': 'auto start end left right center justify',
            'vertical-align': 'baseline top middle bottom sub super text-top '
                              'text-bottom',
            'font-weight': 'normal bold bolder lighter 100 200 300 400 500 600 '
                           '700 800 900',
            'font-style': 'normal italic oblique',
            'font-variant': 'normal small-caps',
            'font-stretch': 'normal condensed expanded ultra-condensed '
                            'semi-condensed semi-expanded',
            'flex-direction': 'row row-reverse column column-reverse',
            'flex-wrap': 'nowrap wrap wrap-reverse',
            'justify-content': 'flex-start flex-end center space-between '
                               'space-around space-evenly start end',
            'align-items': 'stretch flex-start flex-end center baseline start end',
            'align-content': 'stretch flex-start flex-end center space-between '
                             'space-around space-evenly',
            'align-self': 'auto stretch flex-start flex-end center baseline',
            'justify-items': 'stretch start end center legacy left right',
            'justify-self': 'auto stretch start end center left right',
            'box-sizing': 'content-box border-box',
            'visibility': 'visible hidden collapse',
            'cursor': 'pointer default move text wait help not-allowed grab '
                      'grabbing crosshair progress cell alias copy zoom-in '
                      'zoom-out none',
            'white-space': 'normal nowrap pre pre-wrap pre-line break-spaces',
            'word-break': 'normal break-all keep-all break-word',
            'text-overflow': 'clip ellipsis',
            'text-transform': 'none capitalize uppercase lowercase full-width',
            'text-decoration': 'none underline overline line-through',
            'text-decoration-style': 'solid double dotted dashed wavy',
            'list-style-type': 'disc circle square decimal lower-alpha '
                               'upper-alpha lower-roman upper-roman none',
            'list-style-position': 'inside outside',
            'background-repeat': 'repeat repeat-x repeat-y no-repeat space round',
            'background-position': 'top bottom left right center',
            'background-size': 'auto cover contain',
            'background-attachment': 'scroll fixed local',
            'border-style': 'none solid dashed dotted double groove ridge '
                            'inset outset hidden',
            'border-collapse': 'collapse separate',
            'outline-style': 'none solid dashed dotted double groove ridge '
                             'inset outset',
            'pointer-events': 'none auto',
            'object-fit': 'fill contain cover none scale-down',
            'object-position': 'top bottom left right center',
            'flex-grow': '0 1',
            'flex-shrink': '0 1',
            'resize': 'none both horizontal vertical',
            'user-select': 'none auto text all',
            'scroll-behavior': 'auto smooth',
            'isolation': 'auto isolate',
            'mix-blend-mode': 'normal multiply screen overlay darken lighten '
                              'color-dodge color-burn difference exclusion',
            'writing-mode': 'horizontal-tb vertical-rl vertical-lr',
            'direction': 'ltr rtl',
            'table-layout': 'auto fixed',
            'caption-side': 'top bottom',
            'empty-cells': 'show hide',
            'grid-auto-flow': 'row column dense',
        },
        prefixe='',
        extraits=(
            _e('regle', '${1:.selecteur} {\n\t${2:propriete}: ${3:valeur};\n\t$0\n}', 'règle'),
            _e('media', '@media (${1:min-width}: ${2:768px}) {\n\t$0\n}', 'requête média'),
            _e('keyframes', '@keyframes ${1:nom} {\n\tfrom { $0 }\n\tto { }\n}', 'animation'),
            _e('flex', 'display: flex;\nflex-direction: ${1:row};\njustify-content: ${2:center};\nalign-items: ${3:center};\ngap: ${4:1rem};', 'conteneur flexible'),
            _e('grid', 'display: grid;\ngrid-template-columns: ${1:repeat(auto-fit, minmax(200px, 1fr))};\ngap: ${2:1rem};', 'grille'),
            _e('font-face', '@font-face {\n\tfont-family: "${1:Nom}";\n\tsrc: url("${2:police.woff2}") format("woff2");\n\tfont-display: swap;\n}', 'police'),
            _e('import', '@import url("${1:style.css}");', 'importation'),
            _e('var', '--${1:nom}: ${2:valeur};', 'variable personnalisée'),
            _e('supports', '@supports (${1:display}: ${2:grid}) {\n\t$0\n}', 'détection de support'),
        ),
        motifs=(
            _x(r'^[ \t]*\.([A-Za-z_][\w-]*)', CLASSE, 'classe'),
            _x(r'^[ \t]*#([A-Za-z_][\w-]*)', CONSTANT, 'identifiant'),
            _x(r'(--[\w-]+)\s*:', VARIABLE, 'variable personnalisée'),
            _x(r'@keyframes\s+([\w-]+)', EXTRAIT, 'animation'),
        ),
    ),

    'xml': _b(
        'xml',
        mots='xml xmlns xsi version encoding standalone schemaLocation',
        extraits=(
            _e('declaration', '<?xml version="1.0" encoding="UTF-8"?>\n$0', 'déclaration'),
            _e('cdata', '<![CDATA[$0]]>', 'section CDATA'),
            _e('comment', '<!-- $0 -->', 'commentaire'),
            _e('element', '<${1:nom}>$0</$1>', 'élément'),
            _e('doctype', '<!DOCTYPE ${1:racine}>\n$0', 'déclaration de type'),
        ),
        motifs=(
            _x(r'<\s*([A-Za-z_][\w:.-]*)', MODULE, 'élément'),
            _x(r'\b([A-Za-z_:][\w:.-]*)\s*=', PROPRIETE, 'attribut'),
        ),
    ),

    'markdown': _b(
        'markdown',
        mots='TODO FIXME NOTE IMPORTANT WARNING',
        extraits=(
            _e('titre', '# ${1:Titre}\n\n$0', 'titre de niveau 1'),
            _e('sous-titre', '## ${1:Titre}\n\n$0', 'titre de niveau 2'),
            _e('lien', '[${1:texte}](${2:https://})', 'lien'),
            _e('image', '![${1:description}](${2:image.png})', 'image'),
            _e('code', '```${1:python}\n$0\n```', 'bloc de code'),
            _e('inline', '`${1:code}`', 'code en ligne'),
            _e('tableau', '| ${1:Colonne} | ${2:Colonne} |\n| --- | --- |\n| $0 |  |', 'tableau'),
            _e('liste', '- ${1:élément}\n- $0', 'liste à puces'),
            _e('taches', '- [ ] ${1:tâche}\n- [x] ${2:tâche faite}', 'liste de tâches'),
            _e('citation', '> ${1:citation}\n', 'bloc de citation'),
            _e('gras', '**${1:texte}**', 'gras'),
            _e('italique', '*${1:texte}*', 'italique'),
            _e('separation', '\n---\n\n$0', 'séparateur'),
        ),
        motifs=(
            _x(r'^(?:#{1,6})\s+(.+?)\s*$', REFERENCE, 'ancre'),
        ),
    ),

    'bash': _b(
        'bash',
        mots='if then else elif fi for while until do done case esac function in '
             'select time coproc return exit break continue local export readonly '
             'declare typeset set shift trap eval exec source alias unalias unset '
             'echo printf read test true false let getopts cd pwd command builtin '
             'mapfile readarray pipefail noclobber errexit nounset',
        types='BASH_VERSION HOME PATH PWD USER SHELL IFS RANDOM SECONDS LINENO '
              'FUNCNAME EUID UID HOSTNAME OSTYPE MACHTYPE PS1 PS2 COLUMNS LINES '
              'OPTARG OPTIND REPLY',
        extraits=(
            _e('shebang', '#!/usr/bin/env bash\nset -euo pipefail\nIFS=$\'\\n\\t\'\n\n$0', 'en-tête robuste'),
            _e('function', '${1:nom}() {\n\tlocal ${2:argument}="${3:$1}"\n\t$0\n}', 'fonction'),
            _e('if', 'if [[ ${1:condition} ]]; then\n\t$0\nfi', 'condition'),
            _e('ifelse', 'if [[ ${1:condition} ]]; then\n\t$0\nelse\n\t\nfi', 'condition avec sinon'),
            _e('for', 'for ${1:element} in ${2:liste}; do\n\t$0\ndone', 'boucle for'),
            _e('forfiles', 'for ${1:fichier} in *.${2:txt}; do\n\t[[ -e "$$1" ]] || continue\n\t$0\ndone', 'parcours de fichiers'),
            _e('while', 'while [[ ${1:condition} ]]; do\n\t$0\ndone', 'boucle while'),
            _e('case', 'case "${1:valeur}" in\n\t${2:motif})\n\t\t$0\n\t\t;;\n\t*)\n\t\t;;\nesac', 'aiguillage'),
            _e('usage', 'usage() {\n\tcat <<USAGE\nUsage: $$(basename "$$0") [options]\n\n$0\nUSAGE\n}', 'aide'),
            _e('read', 'read -r -p "${1:Question : }" ${2:reponse}', 'lecture interactive'),
            _e('trap', 'trap \'${1:nettoyage}\' EXIT', 'piège de sortie'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:function[ \t]+)?([A-Za-z_]\w*)[ \t]*\(\s*\)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:local[ \t]+|export[ \t]+|readonly[ \t]+|declare[ \t+-]\w*[ \t]+)*([A-Za-z_]\w*)=', VARIABLE, 'variable'),
        ),
    ),

    'swift': _b(
        'swift',
        mots='associatedtype class deinit enum extension fileprivate func import '
             'init inout internal let open operator private protocol public '
             'rethrows static struct subscript typealias var break case continue '
             'default defer do else fallthrough for guard if in repeat return '
             'switch where while as Any AnyObject catch false is nil super self '
             'Self true throw throws try await async actor some any each '
             'mutating override final lazy required convenience optional '
             'indirect nonmutating dynamic weak unowned',
        types='Int Int8 Int16 Int32 Int64 UInt UInt8 UInt16 UInt32 UInt64 '
              'Float Double Bool String Character Array Dictionary Set Optional '
              'Result Error Codable Encodable Decodable Equatable Hashable '
              'Comparable CustomStringConvertible Void Never AnyHashable URL '
              'Data Date UUID',
        extraits=(
            _e('func', 'func ${1:nom}(${2:}) -> ${3:Void} {\n\t$0\n}', 'fonction'),
            _e('struct', 'struct ${1:Nom} {\n\t${2:var champ}: ${3:String}\n}', 'structure'),
            _e('class', 'class ${1:Nom} {\n\tinit(${2:}) {\n\t\t$0\n\t}\n}', 'classe'),
            _e('iflet', 'if let ${1:valeur} = ${2:option} {\n\t$0\n}', 'déballage optionnel'),
            _e('guard', 'guard ${1:condition} else {\n\t$0\n\treturn\n}', 'garde'),
            _e('switch', 'switch ${1:valeur} {\ncase ${2:motif}:\n\t$0\ndefault:\n\tbreak\n}', 'aiguillage'),
            _e('for', 'for ${1:element} in ${2:sequence} {\n\t$0\n}', 'boucle'),
            _e('protocol', 'protocol ${1:Nom} {\n\t${2:func methode}()\n}', 'protocole'),
            _e('extension', 'extension ${1:Nom} {\n\t$0\n}', 'extension'),
            _e('enum', 'enum ${1:Nom} {\n\tcase ${2:variante}\n}', 'énumération'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:@[\w( \t)]+\s*)*(?:public[ \t]+|private[ \t]+|fileprivate[ \t]+|internal[ \t]+|open[ \t]+)?(?:static[ \t]+)?(?:override[ \t]+)?func\s+([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:public[ \t]+|private[ \t]+|final[ \t]+)*class\s+([A-Za-z_]\w*)', CLASSE, 'classe'),
            _x(r'^[ \t]*(?:public[ \t]+|private[ \t]+)*struct\s+([A-Za-z_]\w*)', STRUCTURE, 'structure'),
            _x(r'^[ \t]*(?:public[ \t]+|private[ \t]+)*enum\s+([A-Za-z_]\w*)', ENUMERATION, 'énumération'),
            _x(r'^[ \t]*(?:public[ \t]+)*protocol\s+([A-Za-z_]\w*)', INTERFACE, 'protocole'),
            _x(r'^[ \t]*(?:public[ \t]+|private[ \t]+)*(?:let|var)\s+([A-Za-z_]\w*)', VARIABLE, 'propriété'),
        ),
    ),

    'kotlin': _b(
        'kotlin',
        mots='abstract actual annotation as break by catch class companion const '
             'constructor continue crossinline data do dynamic else enum expect '
             'external field file final finally for fun get if import in infer '
             'init inline interface internal is it lateinit noinline null object '
             'open operator out override package private property protected '
             'public receiver reified return sealed set super suspend tailrec '
             'this throw try typealias val var vararg when where while '
             'lateinit',
        types='Int Long Short Byte Float Double Boolean Char String Any Unit '
              'Nothing List MutableList Map MutableMap Set MutableSet Array '
              'IntArray ArrayList HashMap LinkedHashMap StringBuilder Pair '
              'Triple Result Lazy Throwable Exception',
        extraits=(
            _e('fun', 'fun ${1:nom}(${2:}): ${3:Unit} {\n\t$0\n}', 'fonction'),
            _e('main', 'fun main() {\n\t$0\n}', 'point d’entrée'),
            _e('class', 'class ${1:Nom}(${2:val champ: String}) {\n\t$0\n}', 'classe'),
            _e('dataclass', 'data class ${1:Nom}(\n\tval ${2:champ}: ${3:String},\n)', 'classe de données'),
            _e('object', 'object ${1:Nom} {\n\t$0\n}', 'singleton'),
            _e('when', 'when (${1:valeur}) {\n\t${2:motif} -> $0\n\telse -> {}\n}', 'aiguillage'),
            _e('if', 'if (${1:condition}) {\n\t$0\n}', 'condition'),
            _e('for', 'for (${1:element} in ${2:sequence}) {\n\t$0\n}', 'boucle'),
            _e('extension', 'fun ${1:String}.${2:nom}(): ${3:String} {\n\t$0\n}', 'fonction d’extension'),
            _e('lambda', 'val ${1:nom} = { ${2:x}: ${3:Int} ->\n\t$0\n}', 'lambda'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:override[ \t]+|suspend[ \t]+|inline[ \t]+|private[ \t]+|public[ \t]+|internal[ \t]+|protected[ \t]+)*fun\s+(?:[\w.]+\.)?([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*(?:data[ \t]+|sealed[ \t]+|open[ \t]+|abstract[ \t]+|inner[ \t]+)*class\s+([A-Za-z_]\w*)', CLASSE, 'classe'),
            _x(r'^[ \t]*interface\s+([A-Za-z_]\w*)', INTERFACE, 'interface'),
            _x(r'^[ \t]*object\s+([A-Za-z_]\w*)', MODULE, 'objet'),
            _x(r'^[ \t]*(?:const[ \t]+)?val\s+([A-Za-z_]\w*)', VARIABLE, 'valeur'),
            _x(r'^[ \t]*var\s+([A-Za-z_]\w*)', VARIABLE, 'variable'),
        ),
    ),

    'perl': _b(
        'perl',
        mots='my our local sub package use require no if elsif else unless while '
             'until for foreach given when do eval die warn print printf say '
             'chomp chop split join push pop shift unshift splice sort grep map '
             'keys values each exists delete defined ref bless return last next '
             'redo and or not xor eq ne lt gt le ge strict warnings utf8 '
             'wantarray caller',
        types='SCALAR ARRAY HASH CODE REF GLOB LVALUE FORMAT IO VSTRING Regexp',
        extraits=(
            _e('shebang', '#!/usr/bin/env perl\nuse strict;\nuse warnings;\nuse utf8;\n\n$0', 'en-tête'),
            _e('sub', 'sub ${1:nom} {\n\tmy (${$2:argument}) = @_;\n\t$0\n}', 'sous-routine'),
            _e('if', 'if (${1:condition}) {\n\t$0\n}', 'condition'),
            _e('foreach', 'foreach my $${1:element} (@${2:liste}) {\n\t$0\n}', 'parcours'),
            _e('while', 'while (${1:condition}) {\n\t$0\n}', 'boucle'),
            _e('open', 'open(my $fh, "<:encoding(UTF-8)", ${1:chemin})\n\tor die "Impossible d’ouvrir $1: $!";\n$0', 'ouverture de fichier'),
            _e('package', 'package ${1:Nom};\nuse strict;\nuse warnings;\n\n$0\n\n1;', 'module'),
        ),
        motifs=(
            _x(r'^[ \t]*sub\s+([A-Za-z_]\w*)', FONCTION, 'sous-routine'),
            _x(r'^[ \t]*package\s+([A-Za-z_:][\w:]*)', MODULE, 'module'),
            _x(r'^[ \t]*my\s+\$([A-Za-z_]\w*)', VARIABLE, 'variable'),
            _x(r'^[ \t]*(?:my[ \t]+)?([A-Z][A-Z0-9_]*)\s*=', CONSTANT, 'constante'),
        ),
    ),

    'basic': _b(
        'basic',
        mots='sub end function return if then else elseif endif while wend '
             'repeat until for to step next do loop goto gosub on print input '
             'open close read data restore dim local static global public and '
             'or not xor mod using let select case default exit continue '
             'label rem option base',
        types='INTEGER FLOAT STRING DOUBLE LONG SHORT BYTE ARRAY',
        extraits=(
            _e('sub', 'sub ${1:Nom}\n\t$0\nend sub', 'sous-programme'),
            _e('function', 'function ${1:Nom}()\n\t$0\n\treturn 0\nend function', 'fonction'),
            _e('if', 'if ${1:condition} then\n\t$0\nendif', 'condition'),
            _e('for', 'for ${1:i} = ${2:0} to ${3:10}\n\t$0\nnext ${1:i}', 'boucle'),
            _e('while', 'while ${1:condition}\n\t$0\nwend', 'boucle while'),
            _e('print', 'print "${1:texte}"', 'affichage'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:sub|function)\s+([A-Za-z_]\w*)', FONCTION, 'sous-programme'),
            _x(r'^([A-Za-z_]\w*)\s*:', CONSTANT, 'étiquette'),
        ),
    ),

    'fortran': _b(
        'fortran',
        mots='program end subroutine function module use implicit none integer '
             'real double precision character logical complex intent in out '
             'inout parameter allocatable allocate deallocate if then else '
             'elseif endif do while enddo select case default where forall '
             'return stop call write read print format open close contains '
             'interface type class procedure public private abstract extends '
             'recursive result associate block continue cycle exit go to '
             'namelist save sequence pointer optional pure elemental '
             'bind import only intrinsic',
        types='integer real doubleprecision complex logical character kind len '
             'iso_c_binding iso_fortran_env int8 int16 int32 int64 real32 '
             'real64 real128',
        extraits=(
            _e('program', 'program ${1:nom}\n\timplicit none\n\t$0\nend program $1', 'squelette'),
            _e('subroutine', 'subroutine ${1:Nom}(${2:})\n\timplicit none\n\t$0\nend subroutine $1', 'sous-routine'),
            _e('function', 'function ${1:Nom}(${2:}) result(${3:res})\n\timplicit none\n\treal :: $3\n\t$0\nend function $1', 'fonction'),
            _e('do', 'do ${1:i} = ${2:1}, ${3:10}\n\t$0\nend do', 'boucle'),
            _e('if', 'if (${1:condition}) then\n\t$0\nend if', 'condition'),
            _e('module', 'module ${1:Nom}\n\timplicit none\ncontains\n\t$0\nend module $1', 'module'),
            _e('type', 'type :: ${1:Nom}\n\tinteger :: ${2:champ}\nend type $1', 'type dérivé'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:recursive[ \t]+|pure[ \t]+|elemental[ \t]+)*(?:subroutine|function)\s+([A-Za-z_]\w*)', FONCTION, 'sous-programme'),
            _x(r'^[ \t]*program\s+([A-Za-z_]\w*)', MODULE, 'programme'),
            _x(r'^[ \t]*module\s+([A-Za-z_]\w*)', MODULE, 'module'),
            _x(r'^[ \t]*type\s*(?:::)?\s*([A-Za-z_]\w*)', CLASSE, 'type dérivé'),
        ),
    ),

    'lua': _b(
        'lua',
        mots='and break do else elseif end false for function goto if in local '
             'nil not or repeat return then true while self print pairs ipairs '
             'type tonumber tostring error assert pcall xpcall require setmetatable '
             'getmetatable rawget rawset select unpack table string math os io '
             'coroutine collectgarbage dofile loadfile load next',
        types='string table number boolean function userdata thread nil '
             'integer float',
        extraits=(
            _e('function', 'function ${1:nom}(${2:})\n\t$0\nend', 'fonction'),
            _e('localfunction', 'local function ${1:nom}(${2:})\n\t$0\nend', 'fonction locale'),
            _e('for', 'for ${1:i} = ${2:1}, ${3:10} do\n\t$0\nend', 'boucle numérique'),
            _e('forin', 'for ${1:cle}, ${2:valeur} in pairs(${3:table}) do\n\t$0\nend', 'parcours'),
            _e('if', 'if ${1:condition} then\n\t$0\nend', 'condition'),
            _e('while', 'while ${1:condition} do\n\t$0\nend', 'boucle while'),
            _e('local', 'local ${1:nom} = ${2:valeur}', 'variable locale'),
            _e('module', 'local ${1:M} = {}\n\n$0\n\nreturn $1', 'module'),
        ),
        motifs=(
            _x(r'^[ \t]*(?:local[ \t]+)?function\s+([A-Za-z_][\w.:]*)', FONCTION, 'fonction'),
            _x(r'^[ \t]*local\s+([A-Za-z_]\w*)\s*=', VARIABLE, 'variable locale'),
            _x(r'^([A-Za-z_]\w*)\s*=', VARIABLE, 'variable globale'),
        ),
    ),

    'ocaml': _b(
        'ocaml',
        mots='and as assert begin class constraint do done downto else end '
             'exception external false for fun function functor if in include '
             'inherit initializer lazy let match method module mutable new '
             'nonrec object of open or private rec sig struct then to true try '
             'type val virtual when while with land lor lsl lsr asr mod ref '
             'ignore print_endline print_int print_string string_of_int '
             'int_of_string Printf List Array String Option Result Map Set '
             'Hashtbl Buffer Seq',
        types='int float bool char string unit list array option result exn '
             'bytes ref format lazy_t in_channel out_channel',
        extraits=(
            _e('let', 'let ${1:nom} = ${2:valeur}', 'définition'),
            _e('letfun', 'let ${1:nom} ${2:argument} =\n\t$0', 'fonction'),
            _e('match', 'match ${1:valeur} with\n| ${2:motif} -> $0\n| _ -> ()', 'filtrage'),
            _e('if', 'if ${1:condition} then\n\t$0\nelse\n\t()', 'condition'),
            _e('for', 'for ${1:i} = ${2:0} to ${3:10} do\n\t$0\ndone', 'boucle'),
            _e('module', 'module ${1:Nom} = struct\n\t$0\nend', 'module'),
            _e('type', 'type ${1:nom} = ${2:definition}', 'type'),
            _e('try', 'try\n\t$0\nwith ${1:exn} -> ()', 'bloc protégé'),
        ),
        motifs=(
            _x(r'^[ \t]*let\s+(?:rec\s+)?([a-z_]\w*)', FONCTION, 'définition'),
            _x(r'^[ \t]*type\s+[\w\' ]*\s*([a-z_]\w*)\s*=', CLASSE, 'type'),
            _x(r'^[ \t]*module\s+([A-Z]\w*)', MODULE, 'module'),
            _x(r'^[ \t]*exception\s+([A-Z]\w*)', CLASSE, 'exception'),
            _x(r'^[ \t]*val\s+([a-z_]\w*)', METHODE, 'signature'),
        ),
    ),

    'json': _b(
        'json', mots='true false null',
        extraits=(
            _e('objet', '{\n\t"${1:cle}": ${2:"valeur"}\n}', 'objet'),
            _e('tableau', '[\n\t${1:element}\n]', 'tableau'),
            _e('paire', '"${1:cle}": ${2:"valeur"},', 'paire clef-valeur'),
        ),
        motifs=(
            _x(r'"([A-Za-z_][\w .-]{0,40})"\s*:', PROPRIETE, 'clef'),
        ),
    ),


    # ------------------------------------------------------------------
    # Les dix langages ésotériques (3.8.0). Les mots-clefs et les extraits
    # proviennent des spécifications vérifiées par exécution ; les motifs
    # extraient ce que chaque langage déclare vraiment (variables,
    # personnages, étiquettes, ingrédients).
    # ------------------------------------------------------------------
    'brainfuck': _b(
        'brainfuck',
        mots='',
        extraits=(
            _e('hello', '++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]'
                        '>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++.',
               'Hello World! canonique, 906 pas'),
            _e('cat', ',[.,]', 'recopie l’entrée jusqu’à la fin de fichier'),
            _e('boucle', '[${1:>+<-}]$0', 'boucle : décrémente la cellule courante'),
            _e('addition', '[<+>-]', 'ajoute la cellule courante à la précédente'),
            _e('copie', '[>+<-]', 'déplace la valeur vers la cellule suivante'),
            _e('duplication', '[>+<-]>[-]>', 'duplique la cellule courante'),
            _e('effacer', '[-]', 'met la cellule courante à zéro'),
        ),
    ),
    'whitespace': _b(
        'whitespace',
        mots='',
        extraits=(
            # Le code source est invisible : les extraits insèrent de vrais
            # espaces, tabulations et fins de ligne.
            _e('push 0', ' \n', 'empile 0 (espace espace espace + fin de ligne)'),
            _e('push nombre', '  ${1: }', 'espace espace signe binaire fin de ligne'),
            _e('dupliquer', ' \n \n', 'duplique le sommet de la pile'),
            _e('échanger', ' \n \t\n', 'échange les deux derniers'),
            _e('jeter', ' \n\n\n', 'dépile le sommet'),
            _e('addition', '\t  ', 'additionne les deux derniers'),
            _e('soustraction', '\t \t', 'soustrait le sommet de l’avant-dernier'),
            _e('multiplication', '\t \n', 'multiplie les deux derniers'),
            _e('sortie caractère', '\t\n  ', 'imprime le sommet comme caractère'),
            _e('sortie nombre', '\t\n \t', 'imprime le sommet comme nombre'),
            _e('entrée caractère', '\t\n\t ', 'lit un caractère dans le tas'),
            _e('fin', '\n\n\n', 'termine l’exécution'),
        ),
    ),
    'piet': _b(
        'piet',
        # Le programme EST une image : aucun mot-clef à compléter dans un
        # éditeur texte. On expose les noms des 20 couleurs et des 17 commandes,
        # utiles pour écrire un générateur de PNG ou annoter une peinture.
        mots=('light red red dark red light yellow yellow dark yellow '
              'light green green dark green light cyan cyan dark cyan '
              'light blue blue dark blue light magenta magenta dark magenta '
              'white black push pop add subtract multiply divide mod not '
              'greater pointer switch duplicate roll input output'),
        extraits=(
            _e('couleurs', '#FFC0C0 #FF0000 #C00000 #FFFFC0 #FFFF00 #C0C000 '
                           '#C0FFC0 #00FF00 #00C000 #C0FFFF #00FFFF #00C0C0 '
                           '#C0C0FF #0000FF #0000C0 #FFC0FF #FF00FF #C000C0 '
                           '#FFFFFF #000000',
               'les 20 couleurs de Piet, dans l’ordre teinte puis luminosité'),
            _e('commandes', '# push pop add subtract multiply divide mod not '
                            'greater pointer switch duplicate roll in(num) '
                            'in(char) out(num) out(char)',
               'les 17 commandes, indexées par (teinte, luminosité)'),
        ),
    ),
    'lolcode': _b(
        'lolcode',
        mots=('HAI KTHXBYE CAN HAS STDIO IZ I IZ MKAY VISIBLE GIMMEH I HAS A '
              'ITZ A AN IS NOW MAEK SMOOSH BOTH SAEM DIFFRINT BOTH EITHER '
              'WON OF ALL OF ANY GRAND SMALLER BIGGR SMALLR SUM DIFF PRODUKT '
              'QUOSHUNT MOD BIG SRS YARN NUMBR NUMBAR TROOF NOOB BUKKIT WIN '
              'FAIL O RLY YA RLY NO WAI OIC WTF OMG OMGWTF GTFO IM IN YR '
              'OUTTA YR UPPIN NERFIN TIL WILE HOW YR AN FOUND IF U SAY SO '
              'BTW OBTW TLDR R'),
        extraits=(
            _e('programme', 'HAI 1.2\n  ${1:VISIBLE "Hello, world!"}\nKTHXBYE\n',
               'squelette complet'),
            _e('visible', 'VISIBLE "${1:texte}"', 'affiche une ligne'),
            _e('variable', 'I HAS A ${1:nom} ITZ ${2:valeur}', 'déclare une variable'),
            _e('typee', 'I HAS A ${1:nom} ITZ A ${2|YARN,NUMBR,NUMBAR,TROOF|}',
               'déclare avec un type explicite'),
            _e('si', 'BOTH SAEM ${1:a} AN ${2:b}\nO RLY?\n  YA RLY\n    $0\n'
                     '  NO WAI\n    \nOIC', 'condition avec ses deux branches'),
            _e('boucle', 'IM IN YR ${1:boucle} UPPIN YR ${2:i} TIL BOTH SAEM '
                         '${2:i} AN ${3:10}\n  $0\nIM OUTTA YR ${1:boucle}',
               'boucle avec compteur'),
            _e('switch', '${1:valeur}, WTF?\n  OMG ${2:1}\n    $0\n    GTFO\n'
                         '  OMGWTF\n    \nOIC', 'aiguillage ; sans GTFO ça traverse'),
            _e('fonction', 'HOW IZ I ${1:nom} YR ${2:a}\n  FOUND YR ${3:a}\n'
                           'IF U SAY SO', 'fonction à valeur de retour'),
            _e('appel', 'I IZ ${1:nom} YR ${2:a} MKAY', 'appel de fonction'),
            _e('lire', 'GIMMEH ${1:nom}', 'lit une ligne depuis l’entrée'),
            _e('commentaire', 'BTW ${1:commentaire}', 'commentaire sur une ligne'),
            _e('bloc', 'OBTW\n  ${1:commentaire}\nTLDR', 'commentaire multiligne'),
        ),
        motifs=(
            _x(r'^\s*I HAS A\s+([A-Za-z_]\w*)', VARIABLE, 'variable'),
            _x(r'^\s*HOW IZ I\s+([A-Za-z_]\w*)', FONCTION, 'fonction'),
            _x(r'^\s*IM IN YR\s+([A-Za-z_]\w*)', REFERENCE, 'étiquette de boucle'),
        ),
    ),
    'arnoldc': _b(
        'arnoldc',
        mots=("IT'S SHOWTIME YOU HAVE BEEN TERMINATED HEY CHRISTMAS TREE "
              "YOU SET US UP GET TO THE CHOPPER HERE IS MY INVITATION "
              "ENOUGH TALK GET UP GET DOWN YOU'RE FIRED HE HAD TO SPLIT "
              "I LET HIM GO YOU ARE NOT YOU YOU ARE ME LET OFF SOME STEAM "
              "BENNET CONSIDER THAT A DIVORCE KNOCK KNOCK TALK TO THE HAND "
              "STICK AROUND CHILL BECAUSE I'M GOING TO SAY PLEASE BULLSHIT "
              "YOU HAVE NO RESPECT FOR LOGIC LISTEN TO ME VERY CAREFULLY "
              "GIVE THESE PEOPLE AIR I NEED YOUR CLOTHES YOUR BOOTS AND YOUR "
              "MOTORCYCLE I'LL BE BACK HASTA LA VISTA BABY DO IT NOW "
              "GET YOUR ASS TO MARS"),
        valeurs={'@NO PROBLEMO': '1', '@I LIED': '0'},
        extraits=(
            _e('programme', "IT'S SHOWTIME\n  ${1:TALK TO THE HAND \"Hello, world!\"}\n"
                            'YOU HAVE BEEN TERMINATED', 'squelette complet'),
            _e('afficher', 'TALK TO THE HAND ${1:"texte"}', 'affiche une ligne'),
            _e('variable', 'HEY CHRISTMAS TREE ${1:nom}\nYOU SET US UP ${2:@I LIED}',
               'déclare une variable, 0 par défaut'),
            _e('affecter', 'GET TO THE CHOPPER ${1:nom}\nHERE IS MY INVITATION '
                           '${2:0}\nENOUGH TALK', 'affecte une valeur'),
            _e('ajouter', 'GET TO THE CHOPPER ${1:nom}\nHERE IS MY INVITATION '
                          '${1:nom}\nGET UP ${2:1}\nENOUGH TALK', 'nom += 1'),
            _e('si', "BECAUSE I'M GOING TO SAY PLEASE ${1:condition}\n  $0\n"
                     'BULLSHIT\n  \nYOU HAVE NO RESPECT FOR LOGIC',
               'condition avec son sinon'),
            _e('boucle', 'STICK AROUND ${1:condition}\n  $0\nCHILL',
               'boucle tant que'),
            _e('methode', 'LISTEN TO ME VERY CAREFULLY ${1:nom}\n$0\n'
                          'HASTA LA VISTA, BABY', 'méthode sans valeur de retour'),
            _e('methode-valeur', 'GIVE THESE PEOPLE AIR ${1:nom}\n'
                                 'I NEED YOUR CLOTHES YOUR BOOTS AND YOUR '
                                 'MOTORCYCLE ${2:argument}\n'
                                 "I'LL BE BACK ${3:0}\nHASTA LA VISTA, BABY",
               'méthode avec valeur de retour'),
            _e('appel', 'DO IT NOW ${1:nom} ${2:arguments}', 'appel sans retour'),
            _e('appel-valeur', 'GET YOUR ASS TO MARS ${1:var} ${2:nom} '
                               '${3:arguments}', 'appel avec valeur de retour'),
        ),
        motifs=(
            _x(r'^\s*HEY CHRISTMAS TREE\s+([a-z_]\w*)', VARIABLE, 'variable'),
            _x(r'^\s*(?:LISTEN TO ME VERY CAREFULLY|GIVE THESE PEOPLE AIR)\s+'
               r'([a-z_]\w*)', FONCTION, 'méthode'),
        ),
    ),
    'chef': _b(
        'chef',
        mots=('Ingredients Method Serves Cooking time Pre-heat oven degrees '
              'Celsius gas mark Put Fold Add Remove Combine Divide Liquefy '
              'Stir Mix Clean Pour Set aside Serve with Refrigerate Take '
              'from refrigerator into the mixing bowl baking dish dry '
              'ingredients contents until'),
        extraits=(
            _e('recette', '${1:Titre}.\n\nIngredients.\n${2:72 ml h}\n\n'
                          'Method.\n${3:Put h into the mixing bowl.}\n\n'
                          'Serves 1.\n', 'squelette complet'),
            _e('ingredient', '${1:100} ${2|g,kg,ml,l,pinch,dash,cup,teaspoon,'
                             'tablespoon|} ${3:nom}',
               'ml/l/dash = liquide (imprimé en caractère), g/kg/pinch = sec'),
            _e('put', 'Put ${1:ingredient} into the ${2:}mixing bowl.',
               'empile dans un bol'),
            _e('fold', 'Fold ${1:ingredient} into the mixing bowl.',
               'dépile dans l’ingrédient'),
            _e('add', 'Add ${1:ingredient} to the mixing bowl.',
               'ajoute au sommet du bol'),
            _e('remove', 'Remove ${1:ingredient} from the mixing bowl.',
               'soustrait du sommet'),
            _e('combine', 'Combine ${1:ingredient} into the mixing bowl.',
               'multiplie le sommet'),
            _e('divide', 'Divide ${1:ingredient} into the mixing bowl.',
               'divise le sommet'),
            _e('liquefy', 'Liquefy the contents of the mixing bowl.',
               'tout le bol devient liquide (imprimé en caractères)'),
            _e('stir', 'Stir the mixing bowl for ${1:2} minutes.',
               'fait descendre le sommet de N places'),
            _e('pour', 'Pour contents of the mixing bowl into the baking dish.',
               'copie le bol dans le plat, en conservant l’ordre'),
            _e('boucle', '${1:Melt} the ${2:ingredient}.\n$0\n'
                         '${3:Mix} the ${2:ingredient} until ${1:melted}.',
               'boucle ; l’ingrédient est décrémenté à chaque tour'),
            _e('set-aside', 'Set aside.', 'sort de la boucle la plus interne'),
            _e('serve-with', 'Serve with ${1:recette auxiliaire}.',
               'appelle un sous-chef, qui rend son premier bol'),
            _e('refrigerate', 'Refrigerate for ${1:1} hour.',
               'termine la recette en imprimant N plats'),
            _e('take', 'Take ${1:ingredient} from refrigerator.',
               'lit un nombre depuis l’entrée'),
            _e('serves', 'Serves ${1:1}.',
               'sans cette ligne la recette n’imprime RIEN'),
        ),
        motifs=(
            # Ligne d'ingrédient : « [valeur] [[heaped|level] mesure] nom ».
            # La valeur et la mesure sont TOUTES DEUX facultatives, donc
            # « 101 eggs » (sans mesure) doit aussi capturer « eggs ».
            _x(r'^\s*-?[\d.]+\s*(?:(?:heaped|level)\s+)?'
               r'(?:g|kg|ml|l|pinch(?:es)?|dash(?:es)?|cups?|teaspoons?|'
               r'tablespoons?)?\s+(.+?)\s*$',
               VARIABLE, 'ingrédient'),
            # Titre de recette auxiliaire (« chocolate sauce. »). Il faut
            # exclure les lignes structurelles et les phrases de méthode, sinon
            # toute ligne finissant par un point devient un symbole proposé.
            _x(r'^\s*(?!(?:Ingredients|Method|Serves|Cooking time|Pre-heat oven|'
               r'Put|Fold|Add|Remove|Combine|Divide|Liquefy|Liquify|Stir|Mix|'
               r'Clean|Pour|Set aside|Serve with|Refrigerate|Take|Act|Scene)\b)'
               r'([A-Za-z][A-Za-z0-9 ,\'\-!?]{1,58})\.\s*$',
               REFERENCE, 'recette auxiliaire'),
        ),
    ),
    'shakespeare': _b(
        'shakespeare',
        mots=('Act Scene Enter Exit Exeunt Speak your mind Open your heart '
              'Open your mind Listen to your heart Remember Recall '
              'Am I better than you Am I worse than you Am I as good as you '
              'If so let us proceed to scene let us return to scene '
              'Thou art You are as as the sum of the difference between '
              'the product of the quotient between the square of the cube of '
              'yourself thyself myself'),
        extraits=(
            _e('piece', '${1:Titre}.\n\nRomeo, a young man with a remarkable '
                        'patience.\nJuliet, a likewise young woman of '
                        'remarkable grace.\n\nAct I: The first act.\n\n'
                        'Scene I: The first scene.\n\n[Enter Romeo and Juliet]\n\n'
                        'Romeo:\n ${2:Thou art a brave tree!}\n\n[Exeunt]\n',
               'squelette complet'),
            _e('entrer', '[Enter ${1:Romeo} and ${2:Juliet}]',
               'deux personnages au maximum sur scène'),
            _e('sortir', '[Exit ${1:Romeo}]', 'retire un personnage de la scène'),
            _e('exeunt', '[Exeunt]', 'vide la scène'),
            _e('constante', 'Thou art a ${1:brave} ${2:tree}!',
               'le nom donne le signe, chaque adjectif double la valeur'),
            _e('somme', 'Thou art as good as the sum of ${1:a} and ${2:b}!',
               'affecte une somme à l’INTERLOCUTEUR'),
            _e('difference', 'Thou art as good as the difference between '
                             '${1:a} and ${2:b}!', 'a - b'),
            _e('produit', 'Thou art as good as the product of ${1:a} and ${2:b}!',
               'a * b'),
            _e('carre', 'Thou art as good as the square of ${1:a}!', 'a au carré'),
            _e('imprimer-caractere', 'Speak thy mind!',
               'imprime l’interlocuteur comme caractère'),
            _e('imprimer-nombre', 'Open thy heart!',
               'imprime la valeur numérique de l’interlocuteur'),
            _e('lire-caractere', 'Open thy mind!', 'lit un caractère'),
            _e('lire-nombre', 'Listen to thy heart!', 'lit un nombre'),
            _e('condition', 'Am I better than you?\n${1:Romeo}:\n '
                            'If so, let us return to scene ${2:I}.',
               'saute si la comparaison est vraie'),
            _e('saut', 'Let us proceed to scene ${1:I}.', 'saut inconditionnel'),
            _e('pile', 'Remember!\n$0\nRecall!', 'empile puis restaure'),
        ),
        motifs=(
            _x(r'^([A-Z][A-Za-z\']*)\s*,', VARIABLE, 'personnage'),
            _x(r'^\s*(Act|Scene)\s+([IVXLCDM]+)', REFERENCE, 'acte ou scène'),
        ),
    ),
    'intercal': _b(
        'intercal',
        mots=('DO PLEASE PLEASE DO DON\'T DO NOT PLEASE DON\'T PLEASEN\'T '
              'STASH RETRIEVE NEXT RESUME FORGET ABSTAIN FROM REINSTATE '
              'IGNORE REMEMBER WRITE IN READ OUT COME FROM GIVE UP '
              'CALCULATING STASHING RETRIEVING NEXTING RESUMING FORGETTING '
              'ABSTAINING REINSTATING IGNORING REMEMBERING '
              'PLEASE NOTE SUB'),
        extraits=(
            _e('affecter', 'DO .1 <- ${1:#42}', 'affecte une constante 16 bits'),
            _e('imprimer', 'PLEASE READ OUT ${1:.1}',
               'écrit en chiffres romains abîmés'),
            _e('lire', 'DO WRITE IN ${1:.1}', 'lit des chiffres épelés (ONE TWO)'),
            _e('terminer', 'DO GIVE UP', 'termine le programme'),
            _e('etiquette', '(${1:1}) DO ${2:.1 <- #0}', 'ligne étiquetée'),
            _e('next', 'DO (${1:1}) NEXT', 'saute à l’étiquette, pile de 80'),
            _e('resume', 'DO RESUME ${1:#1}', 'revient de NEXT'),
            _e('abstain', 'DO ABSTAIN FROM ${1:READING OUT}',
               'désactive une commande, par étiquette ou par nom'),
            _e('reinstate', 'DO REINSTATE ${1:READING OUT}', 'annule un ABSTAIN'),
            _e('stash', 'DO STASH ${1:.1}', 'empile la valeur de la variable'),
            _e('retrieve', 'DO RETRIEVE ${1:.1}', 'dépile dans la variable'),
            _e('come-from', 'DO COME FROM (${1:1})', 'GOTO à l’envers'),
            _e('chance', 'DO %${1:50} ${2:.1 <- #1}',
               'exécute la ligne avec une chance sur 100'),
            _e('mingle', 'DO :1 <- \'${1:#1} $ ${2:#2}\'',
               'entrelace les bits, résultat sur 32 bits'),
            _e('select', 'DO .1 <- \'${1:#12} ~ ${2:#5}\'',
               'sélectionne les bits de gauche selon ceux de droite'),
            _e('commentaire', 'PLEASE NOTE ${1:texte}',
               'commentaire impossible à REINSTATE'),
        ),
        motifs=(
            _x(r'^\s*\(\s*(\d+)\s*\)', REFERENCE, 'étiquette'),
        ),
    ),
    'fractran': _b(
        'fractran',
        mots='',
        extraits=(
            _e('etat', 'n = ${1:2}', 'état initial du registre'),
            _e('fraction', '${1:17}/${2:91}',
               'une fraction par ligne, la première applicable gagne'),
            _e('commentaire', '# ${1:commentaire}', 'ligne de commentaire'),
            _e('doubleur', 'n = 1\n2/1', 'double indéfiniment : 1, 2, 4, 8…'),
            _e('termine', 'n = 2\n3/2\n1/3',
               '2 → 3 → 1 puis plus aucune fraction ne s’applique'),
            _e('primegame', 'n = 2\n17/91\n78/85\n19/51\n23/38\n29/33\n77/29\n'
                            '95/23\n77/19\n1/17\n11/13\n13/11\n15/14\n15/2\n55/1',
               'PRIMEGAME de Conway : ne s’arrête jamais'),
        ),
    ),
    'malbolge': _b(
        'malbolge',
        mots='',
        extraits=(
            _e('hello', "('&%:9]!~}|z2Vxwv-,POqponl$Hjig%eB@@>}=<M:9wv6WsU2T|"
                        'nm-,jcL(I&%$#"`CB]V?Tx<uVtT`Rpo3NlF.Jh++FdbCBA@?]'
                        '!~|4XzyTT43Qsqq(Lnmkj"Fhg${z@>',
               'le seul Hello World connu, trouvé par recherche : 75 pas'),
            _e('cat', 'jpoo*pjoooop*ojoopoo*ojoooooppjoivvvo/i<ivivi<'
                      'vvvvvvvvvvvvvoji',
               'forme normalisée du « cat » de la spécification, 62 opérations'),
        ),
    ),
    # L'assembleur (4.0.0). Les mots et les registres viennent d'assembleur.py ;
    # les extraits sont deux programmes complets qui s'assemblent et s'exécutent
    # réellement — vérifiés avec « as » et « ld » avant d'être livrés, parce
    # qu'un extrait faux apprend une faute à l'utilisateur. Les étiquettes du
    # projet sont extraites par motif, pour que la complétion propose les cibles
    # de saut qui existent vraiment dans le fichier.
    'asm': _b(
        'asm',
        mots=_ASM_MOTS,
        types=_ASM_REGISTRES,
        extraits=(
            # Échappement des extraits Monaco, vérifié par rendu dans le banc :
            #   « \\$ » dans ce fichier donne « \$ » dans la valeur, que Monaco
            #     rend comme un « $ » littéral — indispensable en AT&T, où « $1 »
            #     serait sinon lu comme la tabulation numéro 1 ;
            #   « $${1:x} » donne « $ » littéral PUIS l’emplacement réservé, donc
            #     « $x » une fois complété ;
            #   « $$1 » est FAUX : il rend « $ » suivi d’une tabulation vide.
            _e('hello AT&T', '''\
\t.globl _start
\t.text
_start:
\tmov \\$1, %eax\t\t# appel système : write
\tmov \\$1, %edi\t\t# descripteur : sortie standard
\tlea message(%rip), %rsi
\tmov \\$8, %edx\t\t# longueur en octets
\tsyscall
\tmov \\$60, %eax\t\t# appel système : exit
\txor %edi, %edi\t# code de retour 0
\tsyscall
\t.data
message:
\t.ascii "Bonjour\\n"''',
               'programme complet AT&T, à assembler par « as » puis « ld »'),
            _e('hello NASM', '''\
section .text
global _start
_start:
\tmov rax, 1\t\t; appel système : write
\tmov rdi, 1\t\t; descripteur : sortie standard
\tmov rsi, message
\tmov rdx, 8\t\t; longueur en octets
\tsyscall
\tmov rax, 60\t\t; appel système : exit
\txor rdi, rdi\t; code de retour 0
\tsyscall
section .data
message db "Bonjour", 10''',
               'programme complet Intel, à assembler par « nasm -f elf64 »'),
            _e('entête Intel pour as', '.intel_syntax noprefix\n',
               'indispensable pour écrire en Intel dans un .s assemblé par « as »'),
            _e('écrire sur stdout', '''\
\tmov \\$1, %eax
\tmov \\$1, %edi
\tlea ${1:message}(%rip), %rsi
\tmov $${2:8}, %edx
\tsyscall''',
               'appel système write(1, …) en AT&T'),
            _e('quitter', '''\
\tmov \\$60, %eax
\tmov $${1:0}, %edi
\tsyscall''',
               'appel système exit(60) : rend la main sans code de retour aléatoire'),
            _e('prologue', '''\
\tpush %rbp
\tmov %rsp, %rbp
\tsub $${1:32}, %rsp''',
               'ouverture d’une fonction : cadre et place pour les locales'),
            _e('épilogue', '''\
\tmov %rbp, %rsp
\tpop %rbp
\tret''',
               'fermeture d’une fonction ; « leave » fait les deux premières lignes'),
            _e('boucle décomptée', '''\
\tmov $${1:10}, %rcx
${2:boucle}:
\t${3:nop}
\tloop $2''',
               '« loop » décrémente rcx et saute tant qu’il n’est pas nul'),
            _e('comparaison et saut', '''\
\tcmp ${1:%rax}, ${2:%rbx}
\t${3:je} ${4:cible}''',
               'cmp pose les indicateurs, le saut conditionnel les lit'),
            _e('données', '''\
\t.data
${1:message}:
\t.ascii "${2:Bonjour\\n}"
\t.align 8
${3:tableau}:
\t.quad 0, 0, 0, 0''',
               'section de données : chaîne alignée et tableau de quadlets'),
            _e('appel conforme à System V', '''\
\tmov $${1:1}, %edi\t# 1er argument entier
\tmov $${2:2}, %esi\t# 2e
\tmov $${3:3}, %edx\t# 3e
\tmov $${4:4}, %ecx\t# 4e
\tmov $${5:5}, %r8d\t# 5e
\tmov $${6:6}, %r9d\t# 6e
\tcall ${7:fonction}''',
               'les six premiers arguments entiers passent par edi, esi, edx, '
               'ecx, r8d, r9d ; la valeur renvoyée est dans rax'),
            _e('accès à une variable locale', '''\
\tmov ${1:-8}(%rbp), %rax''',
               'les locales sont à des décalages négatifs depuis rbp'),
        ),
        motifs=(
            _x(r'^[ \t]*([A-Za-z_.][\w.$]*)[ \t]*:', FONCTION, 'étiquette'),
            _x(r'^[ \t]*\.set[ \t]+([A-Za-z_]\w*)', CONSTANT, 'constante'),
            _x(r'^[ \t]*\.equ[ \t]+([A-Za-z_]\w*)', CONSTANT, 'constante'),
            _x(r'^[ \t]*([A-Za-z_]\w*)[ \t]+equ[ \t]+', CONSTANT, 'constante NASM'),
            _x(r'^[ \t]*\.globl[ \t]+([A-Za-z_]\w*)', FONCTION, 'symbole exporté'),
        ),
    ),
    'plaintext': _b('plaintext'),
}


def bibliotheque(nom):
    """La bibliothèque d'un langage, ou une bibliothèque vide par sécurité."""
    if not nom:
        return BIBLIOTHEQUES['plaintext']
    return BIBLIOTHEQUES.get(nom, BIBLIOTHEQUES['plaintext'])


def existe(nom):
    return nom in BIBLIOTHEQUES


def noms():
    return sorted(BIBLIOTHEQUES)


def mots_clefs(nom):
    return bibliotheque(nom).mots_clefs


def types(nom):
    return bibliotheque(nom).types


def extraits(nom):
    return bibliotheque(nom).extraits


def motifs(nom):
    return bibliotheque(nom).motifs


def valeurs(nom):
    return bibliotheque(nom).valeurs
