# -*- coding: utf-8 -*-
"""Ce que chaque langage sait vraiment faire, pour l'index de l'aide.

L'aide des langages permet de chercher une page par langage et par mot. Il
manquait la recherche par FONCTIONNALITÉ : « lesquels puis-je déboguer pas à
pas ? », « où la complétion est-elle disponible ? », « quoi donne un aperçu ? ».

Ces réponses ne doivent pas être écrites à la main dans l'aide. Elles existent
déjà, éparpillées dans quatre modules qui font autorité chacun sur leur domaine :

    langages.py              le registre : libellé, extensions, vérificateur,
                             bibliothèque de complétion, rendu graphique
    debogueur_universel.py   ce que le débogage offre réellement
    bac_a_sable.py           ce que l'exécution d'essai offre réellement
    langages_esoteriques.py  l'appartenance aux dix langages ésotériques

Ce module les réunit en un catalogue unique, servi par /api/aide/capacites. Une
fonctionnalité n'y est annoncée que si le module compétent la déclare : quand un
moteur ou un outil manque, la facette disparaît au lieu de mentir, et le champ
« explication » dit pourquoi.

Le catalogue ne contient AUCUN compte de fiches d'aide : le nombre de pages
appartient aux fichiers d'aide, qui sont chargés côté interface. C'est
aide-index.js qui les compte, à partir des mêmes objets globaux que le bundle
consomme.
"""

import langages

# Les facettes, dans l'ordre d'affichage. L'identifiant est stable : c'est ce que
# l'interface envoie et reçoit, le libellé peut évoluer sans rien casser.
FONCTIONNALITES = (
    ('debogage', 'Débogage pas à pas'),
    ('points', 'Points d’arrêt'),
    ('variables', 'Variables en direct'),
    ('evaluation', 'Évaluation d’expressions'),
    ('execution', 'Exécution'),
    ('completions', 'Complétion'),
    ('analyse', 'Analyse en direct'),
    ('apercu', 'Aperçu et inspecteur visuel'),
)

# Les modes internes ne doivent jamais arriver jusqu'à l'utilisateur : « reel »
# et « instrumente » ne veulent rien dire hors du code.
LIBELLES_MODES = {
    'reel': 'débogueur intégré',
    'instrumente': 'exécution instrumentée',
    'visuel': 'inspecteur visuel',
    'trace': 'suivi de construction',
    'aucun': 'aucun débogage',
}

LIBELLES_EXECUTION = {
    'compile': 'compilation',
    'interprete': 'interpréteur',
    'graphique': 'rendu graphique',
    'non': 'ne s’exécute pas',
}

CATEGORIES = (('esoterique', 'Ésotériques'), ('classique', 'Classiques'))


def _esoteriques():
    """Les identifiants ésotériques, ou un ensemble vide si le module manque."""
    try:
        import langages_esoteriques
    except Exception:
        return frozenset()
    return frozenset(langages_esoteriques.ORDRE_ESOTERIQUES)


def _essai(identifiant):
    """Ce que l'exécution d'essai offre, sans jamais lever.

    bac_a_sable importe les moteurs à la demande et consulte les binaires
    présents : un outil absent doit produire une explication, pas une exception.
    """
    try:
        import bac_a_sable
        etat = bac_a_sable.etat(identifiant)
    except Exception:
        return {'mode': '', 'libelle': '', 'disponible': False,
                'message': 'État d’exécution indisponible.'}
    mode = str(etat.get('mode', '') or '')
    # bac_a_sable.etat() nomme ce champ « message » ; le reprendre tel quel évite
    # deux vocabulaires pour la même chose côté interface.
    return {'mode': mode,
            'libelle': LIBELLES_EXECUTION.get(mode, mode),
            'disponible': bool(etat.get('disponible')),
            'message': str(etat.get('message', '') or '')}


def capacites(identifiant):
    """Les capacités d'un langage, avec les facettes qui en découlent."""
    identifiant = langages.resoudre(identifiant) or identifiant
    langage = langages.langage(identifiant)
    if not langage:
        return None
    try:
        import debogueur_universel
        debogage = debogueur_universel.capacites(identifiant)
    except Exception:
        debogage = {}
    mode_debogage = str(debogage.get('mode', '') or '')
    essai = _essai(identifiant)
    graphique = bool(langages.est_graphique(identifiant))
    # Une bibliothèque de complétion peut exister sans que le langage soit
    # reconnu par l'éditeur ; c'est le registre qui fait foi.
    completions = bool(langages.bibliotheque(identifiant))
    analyse = bool(langages.verificateur(identifiant))

    facettes = []
    if debogage.get('pas_a_pas'):
        facettes.append('debogage')
    if debogage.get('points_arret'):
        facettes.append('points')
    if debogage.get('variables'):
        facettes.append('variables')
    if debogage.get('evaluation'):
        facettes.append('evaluation')
    if essai['disponible'] or graphique:
        facettes.append('execution')
    if completions:
        facettes.append('completions')
    if analyse:
        facettes.append('analyse')
    if graphique or debogage.get('visuel'):
        facettes.append('apercu')

    return {
        'langage': identifiant,
        'libelle': langage.libelle,
        'extensions': list(langages.extensions(identifiant)),
        'categorie': 'esoterique' if identifiant in _esoteriques() else 'classique',
        'graphique': graphique,
        'debogage': {
            'mode': mode_debogage,
            'libelle': LIBELLES_MODES.get(mode_debogage, mode_debogage),
            'pas_a_pas': bool(debogage.get('pas_a_pas')),
            'points_arret': bool(debogage.get('points_arret')),
            'variables': bool(debogage.get('variables')),
            'pile': bool(debogage.get('pile')),
            'evaluation': bool(debogage.get('evaluation')),
            'visuel': bool(debogage.get('visuel')),
            'disponible': bool(debogage.get('disponible')),
            'installation': str(debogage.get('installation', '') or ''),
            'explication': str(debogage.get('explication', '') or ''),
        },
        'execution': essai,
        'completions': completions,
        'analyse': analyse,
        'facettes': facettes,
    }


def catalogue():
    """Le catalogue complet : un langage du registre par entrée.

    L'ordre est celui du registre, donc les langages ésotériques arrivent en
    dernier — l'interface les regroupe de toute façon par catégorie.
    """
    entrees = []
    for identifiant in langages.tous():
        fiche = capacites(identifiant)
        if fiche:
            entrees.append(fiche)
    return {'langages': entrees,
            'fonctionnalites': [{'id': i, 'libelle': l} for i, l in FONCTIONNALITES],
            'categories': [{'id': i, 'libelle': l} for i, l in CATEGORIES],
            'total': len(entrees)}


def par_facette(facette):
    """Les libellés des langages qui offrent cette fonctionnalité."""
    if facette not in dict(FONCTIONNALITES):
        return []
    return [fiche['libelle'] for fiche in catalogue()['langages']
            if facette in fiche['facettes']]
