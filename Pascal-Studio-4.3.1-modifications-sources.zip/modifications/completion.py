"""Optional local clangd completion for unsaved C/C++ buffers (LSP over stdio)."""
import json, os, select, shutil, subprocess, threading, time
from pathlib import Path

class ClangCompletion:
    def __init__(self,root):
        self.root=Path(root).resolve(); self.lock=threading.Lock(); self.proc=None; self.buffer=b''; self.serial=0; self.documents={}
    def close(self):
        p=self.proc; self.proc=None; self.documents={};self.buffer=b''
        if p:
            try:p.terminate();p.wait(timeout=2)
            except Exception:
                try:p.kill();p.wait(timeout=2)
                except Exception:pass
            for stream in (p.stdin,p.stdout):
                try:stream.close()
                except Exception:pass
    def _send(self,msg):
        body=json.dumps(msg,ensure_ascii=False).encode();self.proc.stdin.write(('Content-Length: %d\r\n\r\n'%len(body)).encode()+body);self.proc.stdin.flush()
    def _notify(self,method,params):self._send({'jsonrpc':'2.0','method':method,'params':params})
    def _request(self,method,params,timeout=8):
        self.serial+=1;ident=self.serial;self._send({'jsonrpc':'2.0','id':ident,'method':method,'params':params});deadline=time.monotonic()+timeout
        while time.monotonic()<deadline:
            msg=self._read(deadline)
            if msg.get('id')==ident and ('result' in msg or 'error' in msg):
                if 'error' in msg:raise ValueError(str(msg['error']))
                return msg.get('result')
            # Reply to server-initiated requests; do not wait forever for clangd.
            if 'id' in msg and 'method' in msg:self._send({'jsonrpc':'2.0','id':msg['id'],'result':None})
        raise TimeoutError('clangd ne répond pas.')
    def _read(self,deadline):
        while True:
            split=self.buffer.find(b'\r\n\r\n')
            if split>=0:
                headers=self.buffer[:split].decode('ascii','replace');length=next((int(x.split(':',1)[1]) for x in headers.split('\r\n') if x.lower().startswith('content-length:')),None)
                if length is None or length>8_000_000:raise ValueError('Réponse clangd invalide.')
                end=split+4+length
                if len(self.buffer)>=end:
                    body=self.buffer[split+4:end];self.buffer=self.buffer[end:];return json.loads(body)
            left=deadline-time.monotonic()
            if left<=0 or not select.select([self.proc.stdout],[],[],left)[0]:raise TimeoutError('clangd ne répond pas.')
            chunk=os.read(self.proc.stdout.fileno(),65536)
            if not chunk:raise ValueError('clangd s’est arrêté.')
            self.buffer+=chunk
    def _start(self):
        exe=shutil.which('clangd')
        if not exe:return False
        self.proc=subprocess.Popen([exe,'--background-index=false','--header-insertion=never','--log=error'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,bufsize=0,cwd=self.root)
        self._request('initialize',{'processId':os.getpid(),'rootUri':self.root.as_uri(),'capabilities':{'general':{'positionEncodings':['utf-16']},'textDocument':{'completion':{'completionItem':{'snippetSupport':True,'insertReplaceSupport':True}}}}},timeout=12)
        self._notify('initialized',{});return True
    def complete(self,path,content,line,column):
        path=Path(path).resolve()
        if not path.is_file() or path.suffix.lower() not in ('.c','.cc','.cpp','.cxx','.c++','.h','.hh','.hpp','.hxx'):return []
        if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
        if not isinstance(line,int) or not isinstance(column,int) or line<1 or column<1:raise ValueError('Position invalide.')
        with self.lock:
            try:
                if not self.proc or self.proc.poll() is not None:
                    self.close()
                    if not self._start():return []
                uri=path.as_uri();lang='c' if path.suffix.lower() in ('.c','.h') and path.suffix!='.C' else 'cpp'
                ver=self.documents.get(uri,0)+1
                if ver==1:self._notify('textDocument/didOpen',{'textDocument':{'uri':uri,'languageId':lang,'version':ver,'text':content}})
                else:self._notify('textDocument/didChange',{'textDocument':{'uri':uri,'version':ver},'contentChanges':[{'text':content}]})
                self.documents[uri]=ver
                result=self._request('textDocument/completion',{'textDocument':{'uri':uri},'position':{'line':line-1,'character':column-1},'context':{'triggerKind':1}},timeout=6)
                return (result if isinstance(result,list) else (result or {}).get('items',[]))[:200]
            except Exception:
                self.close();return []
