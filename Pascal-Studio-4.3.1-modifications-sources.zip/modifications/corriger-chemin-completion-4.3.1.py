#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Corriger la résolution du chemin de /api/completion (4.3.1).

LE DÉFAUT
  La route faisait :

      p=Path(d.get('path','')).resolve()
      if not p.is_relative_to(ROOT) and p not in external_files.values():
          raise ValueError('Fichier non autorisé.')

  `Path('main.pas').resolve()` résout un chemin RELATIF par rapport au
  répertoire de lancement du PROCESSUS, pas par rapport au projet. Dans
  l'AppImage, le serveur Python n'est pas lancé dans l'espace de travail : le
  chemin relatif envoyé par l'interface se retrouvait donc hors de ROOT, la
  garde le refusait, et la console affichait

      POST http://127.0.0.1:44381/api/completion  400 (Bad Request)

  à chaque complétion. Autrement dit la complétion de code ne fonctionnait
  jamais, et rien ne le disait : l'interface avalait l'erreur.

  Toutes les autres routes locales passent par `resolve(name)`, qui fait
  `(ROOT / name).resolve()` — le comportement attendu. Deux routes seulement
  résolvent elles-mêmes un chemin, `/api/data/open-external` et
  `/api/external/open`, et toutes deux EXIGENT un chemin absolu avant de le
  résoudre : elles ne sont pas concernées. `/api/completion` était la seule à
  résoudre un chemin possiblement relatif sans le rattacher au projet.

LE CORRECTIF
  Rattacher un chemin relatif à ROOT avant de le résoudre, puis garder la garde
  existante telle quelle : un chemin hors du projet doit toujours être refusé,
  et un fichier externe déjà ouvert doit toujours être accepté.

  Le 400 que la console affiche sur `GET /api/file?path=main.pas` est une AUTRE
  histoire, et il est normal : la route lit le fichier, et quand `main.pas`
  n'existe pas dans le projet le serveur répond
  `[Errno 2] No such file or directory`. C'est le comportement de l'interface
  qui ouvre un document par défaut avant qu'il existe. Le banc
  tests/smoke_routes_completion.py fixe les deux lectures pour qu'on ne les
  confonde plus.

Usage : python3 corriger-chemin-completion-4.3.1.py [--verifier]
Trois états en --verifier : 0 conforme, 1 à corriger, 2 problème.
"""

import ast
import io
import os
import shutil
import subprocess
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
SAUVEGARDES = os.path.join(os.path.dirname(ICI), 'sauvegardes')
CIBLE = 'server.py'

ANCIEN = """            elif action == '/api/completion':
                p=Path(d.get('path','')).resolve()
                if not p.is_relative_to(ROOT) and p not in external_files.values(): raise ValueError('Fichier non autorisé.')"""

NOUVEAU = """            elif action == '/api/completion':
                # Un chemin RELATIF est relatif au PROJET, pas au répertoire de
                # lancement du serveur. Dans l'AppImage le processus Python ne
                # démarre pas dans l'espace de travail : 'main.pas' se résolvait
                # hors de ROOT, la garde le refusait, et chaque complétion
                # répondait 400 « Fichier non autorisé. » (4.3.1). Les routes
                # locales passent toutes par resolve(), qui fait (ROOT / name) ;
                # celles qui résolvent elles-mêmes exigent un chemin absolu.
                brut=d.get('path','')
                if not isinstance(brut,str) or '\\x00' in brut: raise ValueError('Chemin invalide')
                p=Path(brut).expanduser()
                if not p.is_absolute(): p=ROOT/p
                p=p.resolve()
                if not p.is_relative_to(ROOT) and p not in external_files.values(): raise ValueError('Fichier non autorisé.')"""


def lire():
    with io.open(os.path.join(ICI, CIBLE), encoding='utf8') as fichier:
        return fichier.read()


def verifier(texte):
    apres = texte.count(NOUVEAU)
    avant = texte.count(ANCIEN)
    if apres and avant:
        return 2, ['ancre et remplacement tous deux présents']
    if apres:
        return 0, []
    if avant:
        return 1, []
    return 2, ['ancre introuvable (ni avant ni après) : la route a changé de '
               'forme, ce correcteur ne doit pas écrire à l’aveugle']


def main():
    texte = lire()

    if '--verifier' in sys.argv:
        code, problemes = verifier(texte)
        if code == 0:
            print('chemin de /api/completion 4.3.1 : conforme — un chemin '
                  'relatif est rattaché au projet avant la garde')
        elif code == 1:
            print('chemin de /api/completion 4.3.1 : à corriger')
        else:
            print('chemin de /api/completion 4.3.1 : PROBLÈME')
            for p in problemes:
                print('  - ' + p)
        return code

    code, problemes = verifier(texte)
    if code == 0:
        print('ECHEC : la correction 4.3.1 est déjà appliquée ; ce correcteur a '
              'déjà été joué.')
        return 1
    if code == 2:
        print("ECHEC, rien n'est écrit :")
        for p in problemes:
            print('  - ' + p)
        return 1

    nouveau = texte.replace(ANCIEN, NOUVEAU, 1)

    # Un fichier écrit n'est pas un fichier valide : server.py fait 87 000
    # caractères, une parenthèse mangée ne se voit qu'à l'import.
    try:
        ast.parse(nouveau)
    except SyntaxError as erreur:
        print('ECHEC, rien n\'est écrit : le fichier corrigé ne se parse plus '
              '(%s, ligne %s)' % (erreur.msg, erreur.lineno))
        return 1

    if not os.path.isdir(SAUVEGARDES):
        os.makedirs(SAUVEGARDES)
    sauvegarde = os.path.join(SAUVEGARDES, CIBLE + '.avant-completion-4.3.1')
    if not os.path.exists(sauvegarde):
        shutil.copy2(os.path.join(ICI, CIBLE), sauvegarde)

    with io.open(os.path.join(ICI, CIBLE), 'w', encoding='utf8') as fichier:
        fichier.write(nouveau)

    # pyflakes sur la zone modifiée : un nom inventé dans le bloc est invisible à
    # ast.parse.
    controle = subprocess.run([sys.executable, '-m', 'pyflakes',
                               os.path.join(ICI, CIBLE)],
                              capture_output=True, text=True)
    lignes = [l for l in controle.stdout.splitlines()
              if 'unable to detect undefined names' not in l
              and 'imported but unused' not in l
              and 'redefinition' not in l]
    print('chemin de /api/completion 4.3.1 : 1 substitution appliquée')
    print('   %-14s %d -> %d caractères, ast.parse conforme'
          % (CIBLE, len(texte), len(nouveau)))
    print('   pyflakes : %s'
          % ('aucune alerte nouvelle' if not lignes
             else '%d alerte(s) — %s' % (len(lignes), lignes[0][:120])))
    print('   sauvegarde : %s' % os.path.basename(sauvegarde))
    return 0


if __name__ == '__main__':
    sys.exit(main())
