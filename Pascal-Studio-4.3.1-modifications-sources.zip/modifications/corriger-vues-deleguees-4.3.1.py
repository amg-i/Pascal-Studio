#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Corriger les panneaux délégués à la zone des vues (4.3.1).

Quatre défauts de la 4.3.0, tous nés du passage des panneaux flottants à des
onglets. Les trois premiers étaient invisibles aux bancs existants ; le banc
tests/smoke_boucle_vues.js les rejoue tous les quatre.

D. UNE BOUCLE DE RENDU À 60 IMAGES PAR SECONDE — le défaut dominant.
   ps-hotes.js observe document.body en { subtree:true, childList:true } et
   regroupe ses rappels sur requestAnimationFrame. Son contrat est écrit dans
   son propre en-tête : « Chaque rappel reste idempotent et doit revenir
   immédiatement s'il n'y a rien à faire — c'est ce qui empêche la boucle (un
   rendu produit des mutations, qui réveillent l'observateur, qui rappelle le
   rendu…) ». Or rendreColonnes() commençait par vider(conteneur) puis RECRÉAIT
   chaque colonne, chaque entête et chaque séparateur, et rendreOnglets()
   vidait puis reconstruisait la barre de vignettes — à chaque passage, sans
   rien comparer. Dès qu'une vue était ouverte, chaque passage produisait donc
   des mutations childList qui réveillaient l'observateur qui rappelait le
   rendu. Mesure : 24 éléments créés par passage, indéfiniment (600 pour 25
   passages à état strictement inchangé).
   Conséquences : le <webview> du navigateur était détaché puis rattaché à
   chaque image — Electron recharge un <webview> déplacé dans le DOM, donc le
   navigateur ne chargeait rien et ne répondait plus ; le curseur était
   recalculé en permanence sur des noeuds qui venaient d'être remplacés, d'où
   la flèche, la main et le redimensionnement qui alternaient ; et un clic
   tombait sur un noeud déjà remplacé, d'où « quand un panneau est ouvert,
   l'autre ne peut plus s'ouvrir, et une fois fermé on ne peut plus le
   rouvrir ». Le rendu est maintenant RÉCONCILIÉ : les éléments en place sont
   réutilisés, et rien n'est écrit quand rien n'a changé.

B. LA ZONE SE MASQUAIT DÈS L'OUVERTURE.
   synchroniser() se terminait par « si mode plein, une vue active et un onglet
   de fichier actif : display:none ». Comme ouvrir() et activer() appellent
   synchroniser(), et que la barre garde presque toujours un onglet de fichier
   actif, ouvrir un panneau le masquait aussitôt — et cliquer sa vignette
   aussi. C'est « les panneaux dev web et rétro n'arrivent plus à se charger ».
   L'affichage suit maintenant l'INTENTION : ouvrir, activer, scinder ou
   recoller une vue sont des demandes explicites et affichent la zone ; aller
   sur un onglet de FICHIER rend la main à l'éditeur.

A. LE NOEUD DÉLÉGUÉ RESTAIT UNE FENÊTRE FLOTTANTE.
   .psnav-panel est position:fixed; right:18px; bottom:18px;
   width:min(1180px,92vw); height:min(820px,88vh); z-index:8000, et
   navigateur-studio.css est injectée APRÈS vues-studio.css : à spécificité
   égale, c'est elle qui gagne. Le noeud sortait du flux de la colonne, se
   plaçait par rapport à la fenêtre et couvrait l'application — sa barre de
   titre (cursor:grab) et ses cinq poignées (ew/ns/nwse-resize) promenaient le
   curseur partout, et la colonne restait vide.

C. LES POIGNÉES DE LA FENÊTRE RESTAIENT ARMÉES.
   Leurs gestionnaires pointerdown écrivaient left/top/width/height EN LIGNE sur
   un noeud dont la colonne possède la géométrie.

Usage : python3 corriger-vues-deleguees-4.3.1.py [--verifier]
Trois états en --verifier : 0 conforme, 1 à corriger, 2 problème.
"""

import io
import os
import shutil
import subprocess
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
SAUVEGARDES = os.path.join(os.path.dirname(ICI), 'sauvegardes')

FICHIERS = ('vues-studio.css', 'vues-studio.js', 'navigateur-studio.js',
            'devweb-studio.js', 're-studio.js')

# ---------------------------------------------------------------- substitutions
# (fichier, ancien, nouveau, occurrences attendues)
SUBSTITUTIONS = (

    # ------------------------------------------------------------------ A. CSS --
    ('vues-studio.css',
     """.ps-vues-corps>*{width:100%;height:100%}""",
     """/* Le noeud qu'un panneau confie à la colonne : sa géométrie appartient à la
 * zone, pas à lui. Trois panneaux sont nés fenêtres flottantes — position:fixed,
 * ancrage à la fenêtre, z-index 8000 — et leurs feuilles sont injectées APRÈS
 * celle-ci. À spécificité égale la dernière posée gagne, donc sans ces
 * !important la fenêtre l'emporte : le noeud sort du flux de la colonne, se
 * place par rapport à la fenêtre, couvre l'application, et la colonne s'affiche
 * vide (4.3.1). */
.ps-vues-corps>*{position:relative!important;left:auto!important;top:auto!important;
  right:auto!important;bottom:auto!important;
  width:100%!important;height:100%!important;max-width:none!important;
  max-height:none!important;min-height:0!important;margin:0!important;
  z-index:auto!important;border-radius:0!important}

/* Les poignées de la fenêtre flottante n'ont plus d'objet dans un onglet : elles
 * ne redimensionnent rien, mais elles gardent leurs curseurs (ew/ns/nwse-resize)
 * et leurs écoutes pointerdown. */
.ps-vues-corps .psnav-resize,.ps-vues-corps .psdw-poignee,
.ps-vues-corps .ps-re-redim{display:none!important}

/* Même raison pour le curseur « main fermée » des barres de titre : dans un
 * onglet, la barre ne déplace plus rien. Les boutons gardent le leur — la règle
 * vise les barres, pas leurs enfants. */
.ps-vues-corps .psnav-titlebar,.ps-vues-corps .psdw-barre,
.ps-vues-corps .ps-re-fenetre-barre{cursor:default!important;
  user-select:auto!important}
.ps-vues-corps .psnav-titlebar:active,.ps-vues-corps .psdw-barre:active,
.ps-vues-corps .ps-re-fenetre-barre:active{cursor:default!important}""",
     1),

    # ------------------------------------------------------------------ B. état --
    ('vues-studio.js',
     """let entrainDeGlisser = false;
let partageLargeur = 55;   /* % pris par la zone en mode 'partage' */""",
     """let entrainDeGlisser = false;
let partageLargeur = 55;   /* % pris par la zone en mode 'partage' */
/* 4.3.1 : l'affichage suit l'INTENTION de l'utilisateur, pas l'état brut de la
 * barre d'onglets. `masqueeSurFichier` est le verrou posé par un changement
 * d'onglet de FICHIER ; `cleFichierVue` est la clé du dernier onglet de fichier
 * vu au premier plan, pour ne pas confondre un vrai changement de fichier avec
 * un simple rafraîchissement de la barre par React. */
let masqueeSurFichier = false;
let cleFichierVue = null;""",
     1),

    ('vues-studio.js',
     """  if (trouve && trouve !== hote) {
    hote = trouve;
    if (!hote.__psVuesEcoute) {""",
     """  if (trouve && trouve !== hote) {
    hote = trouve;
    /* Un hôte neuf est vide : la signature des vignettes doit être rejouée. */
    signatureOnglets = '';
    if (!hote.__psVuesEcoute) {""",
     1),

    ('vues-studio.js',
     """  barre = $(BARRE);
  const conteneur = assurerZone();""",
     """  barre = $(BARRE);
  if (barre && !barre.__psVuesEcouteBarre) {
    /* Un clic sur un onglet de FICHIER rend la main à l'éditeur. Sans cette
     * écoute, un second clic sur le même onglet ne changeait aucune clé et la
     * zone restait par-dessus le fichier. */
    barre.addEventListener('click', surClicBarreFichiers);
    barre.__psVuesEcouteBarre = true;
  }
  /* Un AUTRE fichier passé au premier plan (clic, clavier, explorateur) : la
   * zone s'efface devant lui. Le même fichier qui reste actif ne change rien,
   * et l'absence d'onglet de fichier rend la main aux panneaux. */
  const cle = cleOngletFichier(ongletFichierActifNoeud());
  if (cle !== cleFichierVue) {
    cleFichierVue = cle;
    masqueeSurFichier = cle !== null;
  }
  const conteneur = assurerZone();""",
     1),

    ('vues-studio.js',
     """  if (mode === 'plein' && active && ongletFichierActif()) {
    /* L'utilisateur a cliqué sur un onglet de fichier : on masque sans fermer. */""",
     """  if (mode === 'plein' && active && masqueeSurFichier) {
    /* L'utilisateur est allé sur un onglet de fichier : on masque sans fermer. */""",
     1),

    # Les quatre demandes explicites d'affichage.
    ('vues-studio.js',
     """    active = v.id;
    if (opts.mode) api.mode(opts.mode, opts.largeur);
    synchroniser();
    return true;""",
     """    active = v.id;
    if (opts.mode) api.mode(opts.mode, opts.largeur);
    intentionVoir();
    synchroniser();
    return true;""",
     1),

    ('vues-studio.js',
     """    active = v.id;
    synchroniser();
    return true;
  },

  /* Scinder : mettre une vue dans une NOUVELLE colonne""",
     """    active = v.id;
    intentionVoir();
    synchroniser();
    return true;
  },

  /* Scinder : mettre une vue dans une NOUVELLE colonne""",
     1),

    ('vues-studio.js',
     """    active = v.id;
    synchroniser();
    return true;
  },

  /* Recoller une colonne""",
     """    active = v.id;
    intentionVoir();
    synchroniser();
    return true;
  },

  /* Recoller une colonne""",
     1),

    ('vues-studio.js',
     """    const id = at('data-vue');
    if (id) {
      evt.preventDefault && evt.preventDefault();
      api.activer(id);
      return;
    }""",
     """    const id = at('data-vue');
    if (id) {
      evt.preventDefault && evt.preventDefault();
      intentionVoir();
      api.activer(id);
      return;
    }""",
     1),

    # -------------------------------------------------------------------- C. JS --
    ('navigateur-studio.js',
     """function rendreDeplacable() {
  const poignee = $('.psnav-titlebar', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psnav-plein')) return;""",
     """/* 4.3.1 : délégué à un onglet, le panneau n'est plus une fenêtre — c'est la zone
 * des vues qui possède sa géométrie. Écrire left/top/width/height en ligne sur un
 * noeud en colonne l'arrachait à sa colonne. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function rendreDeplacable() {
  const poignee = $('.psnav-titlebar', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(panneau)) return;
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psnav-plein')) return;""",
     1),

    ('navigateur-studio.js',
     """    const poignee = el('div', { class: 'psnav-resize psnav-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (panneau.classList.contains('psnav-plein')) return;""",
     """    const poignee = el('div', { class: 'psnav-resize psnav-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (dansUneColonne(panneau)) return;
      if (panneau.classList.contains('psnav-plein')) return;""",
     1),

    ('devweb-studio.js',
     """function rendreDeplacable(panneau) {
  const poignee = $('.psdw-barre', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psdw-plein')) return;""",
     """/* 4.3.1 : une fenêtre déléguée à un onglet ne se déplace plus — la zone des vues
 * possède la géométrie du noeud qu'on lui confie. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function rendreDeplacable(panneau) {
  const poignee = $('.psdw-barre', panneau);
  if (!poignee) return;
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(panneau)) return;
    if (ev.target.closest('button')) return;
    if (panneau.classList.contains('psdw-plein')) return;""",
     1),

    ('devweb-studio.js',
     """    const poignee = el('div', { class: 'psdw-poignee psdw-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (panneau.classList.contains('psdw-plein')) return;""",
     """    const poignee = el('div', { class: 'psdw-poignee psdw-r-' + cote, 'data-cote': cote });
    poignee.addEventListener('pointerdown', ev => {
      if (dansUneColonne(panneau)) return;
      if (panneau.classList.contains('psdw-plein')) return;""",
     1),

    ('re-studio.js',
     """function deplacable(noeud, poignee) {
  poignee.addEventListener('pointerdown', ev => {
    ev.preventDefault();""",
     """/* 4.3.1 : une fenêtre déléguée à un onglet ne se déplace plus — la zone des vues
 * possède la géométrie du noeud qu'on lui confie. Les fenêtres de dialogue du
 * panneau restent dans document.body et gardent leur glisser. */
function dansUneColonne(noeud) {
  const pere = noeud && noeud.parentNode;
  return !!(pere && pere.classList && pere.classList.contains('ps-vues-corps'));
}

function deplacable(noeud, poignee) {
  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(noeud)) return;
    ev.preventDefault();""",
     1),

    ('re-studio.js',
     """  poignee.addEventListener('pointerdown', ev => {
    ev.preventDefault(); ev.stopPropagation();
    const departX = ev.clientX, departY = ev.clientY;
    const largeur = noeud.offsetWidth, hauteur = noeud.offsetHeight;""",
     """  poignee.addEventListener('pointerdown', ev => {
    if (dansUneColonne(noeud)) return;
    ev.preventDefault(); ev.stopPropagation();
    const departX = ev.clientX, departY = ev.clientY;
    const largeur = noeud.offsetWidth, hauteur = noeud.offsetHeight;""",
     1),
)

# ------------------------------------------------- fonctions remplacées en bloc
# (fichier, marqueur de début, marqueur de fin conservé, nouveau texte)
FONCTIONS = (

    # D. Le rendu des colonnes : réconcilié au lieu d'être reconstruit.
    ('vues-studio.js', 'function rendreColonnes() {', 'function appliquerRacine() {',
     '''/* ps-hotes.js observe document.body en childList+subtree et regroupe ses rappels
 * sur une image. Son contrat est écrit dans son en-tête : un rappel doit être
 * idempotent et revenir immédiatement s'il n'y a rien à faire, sinon le rendu
 * produit des mutations qui réveillent l'observateur qui rappelle le rendu. La
 * 4.3.0 vidait la zone et recréait chaque colonne à chaque passage — 24 éléments
 * par passage, indéfiniment, dès qu'une vue était ouverte. Le <webview> du
 * navigateur était détaché puis rattaché à chaque image, ce qu'Electron traduit
 * par un rechargement permanent, et le curseur était recalculé sur des noeuds
 * déjà remplacés. Le rendu est donc RÉCONCILIÉ : ce qui est en place est
 * réutilisé, et rien n'est écrit quand rien n'a changé (4.3.1). */
let compteurNoeuds = 0;
let signatureRendu = '';
let signatureOnglets = '';
let rendu = null;

function identite(noeud) {
  if (!noeud) return '-';
  if (!noeud.__psVuesId) {
    compteurNoeuds += 1;
    noeud.__psVuesId = compteurNoeuds;
  }
  return String(noeud.__psVuesId);
}

function enfantsDe(noeud) {
  if (!noeud || !noeud.children) return [];
  return Array.prototype.slice.call(noeud.children);
}

/* Déplacer un noeud seulement s'il n'est pas déjà à sa place : un noeud déplacé
 * dans le DOM est un <webview> rechargé par Electron. */
function placer(noeud, parent) {
  if (!noeud || !parent) return;
  if (noeud.parentNode === parent) return;
  if (noeud.parentNode) detacher(noeud);
  parent.appendChild(noeud);
}

/* Tout ce qui joue sur le rendu des colonnes, y compris l'identité du noeud
 * confié par le panneau : un panneau reconstruit par son propre script doit
 * être repris même si l'identifiant de la vue n'a pas changé. */
function signatureColonnes() {
  const parts = ['a=' + (active || ''), 'n=' + colonnes.length];
  colonnes.forEach(function (c) {
    const v = vue(c.id);
    parts.push('c=' + c.id + ':' + nombre(c.largeur, LARGEUR_MIN, 100, 50)
      + ':' + (active === c.id ? 1 : 0)
      + ':' + (v ? v.titre : c.id) + ':' + (v ? v.icone : '◆')
      + ':' + (v && v.fermable === false ? 0 : 1)
      + ':' + identite(v && v.noeud));
  });
  vues.forEach(function (v) {
    if (v.noeud && !colonne(v.id)) {
      parts.push('h=' + v.id + ':' + identite(v.noeud));
    }
  });
  return parts.join('#');
}

/* La signature peut être juste et le DOM ne plus l'être : React remonte des
 * sous-arbres entiers, et la zone peut avoir été vidée sans qu'aucun état ait
 * changé. On revérifie donc ce qui est réellement attaché. */
function renduIntacte(conteneur) {
  if (!rendu) return false;
  const enfants = enfantsDe(conteneur);
  if (enfants.length !== rendu.enfants.length) return false;
  for (let i = 0; i < enfants.length; i += 1) {
    if (enfants[i] !== rendu.enfants[i]) return false;
  }
  const ids = Object.keys(rendu.colonnes);
  for (let i = 0; i < ids.length; i += 1) {
    const colonneEl = rendu.colonnes[ids[i]];
    const corps = colonneEl && colonneEl.__psCorps;
    const attendu = rendu.corps[ids[i]];
    if (attendu && (!corps || corps.firstChild !== attendu)) return false;
    if (!attendu && corps && corps.firstChild) return false;
  }
  return true;
}

function majEntete(entete, c, v) {
  const signature = [v ? v.titre : c.id, v ? v.icone : '◆',
    colonnes.length > 1 ? 1 : 0,
    v && v.fermable === false ? 0 : 1].join('|');
  if (entete.__psSignature === signature) return;
  entete.__psSignature = signature;
  const enfants = [
    el('span', { class: 'ps-vues-entete-icone', texte: v ? v.icone : '◆' }),
    el('b', { class: 'ps-vues-entete-titre', texte: v ? v.titre : c.id }),
    colonnes.length > 1 ? el('button', { class: 'ps-vues-mini', type: 'button',
      'data-fusion': c.id,
      title: 'Refermer cette colonne et garder sa vue en vignette',
      texte: '⤡' }) : null,
    el('button', { class: 'ps-vues-mini', type: 'button', 'data-scinder': c.id,
      title: 'Ouvrir une colonne à droite de celle-ci', texte: '⧉' }),
    v && v.fermable === false ? null : el('button', {
      class: 'ps-vues-mini ps-vues-x', type: 'button', 'data-fermer': c.id,
      title: 'Fermer ' + (v ? v.titre : c.id),
      'aria-label': 'Fermer ' + (v ? v.titre : c.id), texte: '×' }),
  ].filter(function (n) { return !!n; });
  /* replaceChildren sur L'ENTÊTE seulement. Le corps de la colonne, qui porte le
   * noeud du panneau, n'est jamais retiré : dans un vrai navigateur, retirer
   * puis réinsérer un élément recharge le <webview> qu'il contient. Et les
   * valeurs nulles sont filtrées : replaceChildren(null) insérerait le texte
   * « null ». */
  entete.replaceChildren.apply(entete, enfants);
}

function construireColonne(c, v) {
  const entete = el('div', { class: 'ps-vues-entete' });
  const corps = el('div', { class: 'ps-vues-corps' });
  const colonneEl = el('div', { class: 'ps-vues-colonne', 'data-colonne': c.id },
    entete, corps);
  colonneEl.__psCorps = corps;
  majEntete(entete, c, v);
  return colonneEl;
}

function majColonne(colonneEl, c, v) {
  const avant = active === c.id ? 'true' : 'false';
  if (colonneEl.getAttribute('data-avant') !== avant) {
    colonneEl.setAttribute('data-avant', avant);
  }
  const base = 'calc(' + nombre(c.largeur, LARGEUR_MIN, 100, 50) + '% - 4px)';
  if (colonneEl.style.flexBasis !== base) colonneEl.style.flexBasis = base;
  const entete = colonneEl.querySelector('.ps-vues-entete');
  if (entete) majEntete(entete, c, v);
  const corps = colonneEl.__psCorps;
  if (!corps) return;
  const noeud = v && v.noeud ? v.noeud : null;
  if (corps.firstChild !== noeud) {
    if (corps.firstChild) vider(corps);
    if (noeud) placer(noeud, corps);
  }
  if (!noeud) return;
  /* Le noeud peut revenir d'une période masquée (vue refermée puis rouverte) :
   * son display:none en ligne survivrait à l'attachement et la colonne
   * s'afficherait vide. Le remettre à '' rend la main à la feuille de style. */
  if (noeud.style.display !== '') noeud.style.display = '';
  if (noeud.classList && noeud.classList.contains('ps-vues-contenu')) {
    noeud.classList.remove('ps-vues-contenu');
  }
}

/* Remettre les enfants directs de la zone dans l'ordre voulu, sans toucher à ce
 * qui y est déjà. */
function aligner(conteneur, voulus) {
  const actuels = enfantsDe(conteneur);
  let identique = actuels.length === voulus.length;
  if (identique) {
    for (let i = 0; i < voulus.length; i += 1) {
      if (actuels[i] !== voulus[i]) { identique = false; break; }
    }
  }
  if (identique) return;
  actuels.forEach(function (n) { if (voulus.indexOf(n) < 0) detacher(n); });
  if (typeof conteneur.replaceChildren === 'function') {
    conteneur.replaceChildren.apply(conteneur, voulus);
  } else {
    vider(conteneur);
    voulus.forEach(function (n) { placer(n, conteneur); });
  }
}

function rendreColonnes() {
  const conteneur = assurerZone();
  if (!conteneur) return;
  const attendue = signatureColonnes();
  if (attendue === signatureRendu && renduIntacte(conteneur)) return;

  const existants = {};
  const seps = [];
  enfantsDe(conteneur).forEach(function (n) {
    if (!n.getAttribute) return;
    const id = n.getAttribute('data-colonne');
    if (id) existants[id] = n;
    if (n.getAttribute('data-sep') !== null) seps.push(n);
  });

  const voulus = [];
  const colonnesRendues = {};
  const corpsRendus = {};
  colonnes.forEach(function (c, index) {
    if (index > 0) {
      /* Le séparateur appartient à la colonne de DROITE : glisser vers la gauche
       * agrandit la colonne précédente. Il est réutilisé d'un passage à l'autre,
       * et son écoute de pointerdown reste posée à la création : un écouteur
       * posé sur un noeud remplacé ne serait jamais joué. */
      let sep = seps[index - 1] || null;
      if (!sep) {
        sep = el('div', { class: 'ps-vues-sep', role: 'separator',
          title: 'Glisser pour répartir la largeur' });
        sep.addEventListener('pointerdown', surSeparateur);
      }
      if (sep.getAttribute('data-sep') !== String(index)) {
        sep.setAttribute('data-sep', String(index));
      }
      voulus.push(sep);
    }
    const v = vue(c.id);
    let colonneEl = existants[c.id] || null;
    if (colonneEl && !colonneEl.__psCorps) colonneEl = null;
    if (!colonneEl) colonneEl = construireColonne(c, v);
    majColonne(colonneEl, c, v);
    colonnesRendues[c.id] = colonneEl;
    corpsRendus[c.id] = v && v.noeud ? v.noeud : null;
    voulus.push(colonneEl);
  });
  /* Les noeuds des vues qui ne sont dans AUCUNE colonne restent attachés à la
   * zone, masqués : les détacher détruirait un <webview> en cours de navigation. */
  vues.forEach(function (v) {
    if (!v.noeud || colonne(v.id)) return;
    placer(v.noeud, conteneur);
    if (v.noeud.classList && !v.noeud.classList.contains('ps-vues-contenu')) {
      v.noeud.classList.add('ps-vues-contenu');
    }
    if (v.noeud.style.display !== 'none') v.noeud.style.display = 'none';
    voulus.push(v.noeud);
  });
  aligner(conteneur, voulus);
  signatureRendu = attendue;
  rendu = { signature: attendue, enfants: voulus.slice(),
    colonnes: colonnesRendues, corps: corpsRendus };
}

'''),

    # B. L'intention d'affichage, et D pour les vignettes.
    ('vues-studio.js', 'function ongletFichierActif() {', 'function synchroniser() {',
     '''function ongletFichierActifNoeud() {
  if (!barre || !barre.querySelectorAll) return null;
  const onglets = barre.querySelectorAll('.tab');
  for (let i = 0; i < onglets.length; i += 1) {
    const classe = String(onglets[i].className || '');
    if (classe.indexOf('ps-vue-onglet') >= 0) continue;
    if (classe.indexOf('active') >= 0) return onglets[i];
  }
  return null;
}

function ongletFichierActif() { return !!ongletFichierActifNoeud(); }

/* La clé d'un onglet de fichier, pour distinguer un vrai changement de fichier
 * d'un rafraîchissement de la barre par React. Le chemin affiché est plus stable
 * que l'identité du noeud, que React remplace librement. Les puces de fichier
 * modifié sont retirées pour la même raison. */
function cleOngletFichier(noeud) {
  if (!noeud) return null;
  const at = function (nom) {
    return (noeud.getAttribute && noeud.getAttribute(nom)) || '';
  };
  const brut = at('title') || at('data-path') || at('aria-label') || at('id')
    || noeud.textContent || '';
  const cle = String(brut).replace(/[\\s\\u2022\\u00b7*]/g, '');
  return cle;
}

/* Vouloir montrer une vue : ouvrir un panneau, cliquer sa vignette, la scinder
 * ou la recoller sont des demandes explicites, donc la zone s'affiche même si un
 * onglet de fichier est actif. Sans cela, ouvrir un panneau pendant qu'un
 * fichier était ouvert le masquait aussitôt — ouvrir() et activer() rappellent
 * synchroniser(), et la barre garde un onglet actif en permanence : c'était
 * « les panneaux ne se chargent plus, et une fois fermés on ne peut plus les
 * rouvrir ». */
function intentionVoir() {
  barre = $(BARRE);
  masqueeSurFichier = false;
  cleFichierVue = cleOngletFichier(ongletFichierActifNoeud());
}

/* Un clic sur un onglet de FICHIER rend la main à l'éditeur. Les vignettes de
 * vues portent elles aussi la classe `tab` du bundle : elles sont écartées
 * d'abord, sinon cliquer une vignette masquerait le panneau qu'elle ouvre. */
function surClicBarreFichiers(evt) {
  if (!barre) return;
  let noeud = evt && evt.target;
  while (noeud && noeud !== barre) {
    const classes = String(noeud.className || '').split(/\\s+/);
    if (classes.indexOf('ps-vue-onglet') >= 0) return;
    if (classes.indexOf('tab') >= 0) {
      masqueeSurFichier = true;
      cleFichierVue = cleOngletFichier(noeud);
      synchroniser();
      return;
    }
    noeud = noeud.parentNode;
  }
}

function signatureVignettes() {
  return vues.map(function (v) {
    const affichee = !!colonne(v.id);
    return [v.id, v.titre, v.icone || '◆',
      active === v.id && affichee ? 1 : 0, affichee ? 1 : 0,
      v.fermable === false ? 0 : 1].join('|');
  }).join('#');
}

'''),

    # D. Les vignettes : même discipline que les colonnes.
    ('vues-studio.js', 'function rendreOnglets() {', 'function surClicOnglet(evt) {',
     '''function rendreOnglets() {
  if (!hote || !contient(document.documentElement, hote)) return;
  /* La barre de vignettes n'est reconstruite que si une vignette a vraiment
   * changé. La reconstruire à chaque passage faisait disparaître le noeud sous
   * le curseur au moment du clic : c'est « une fois fermé, on ne peut plus le
   * rouvrir ». */
  const attendue = signatureVignettes();
  if (attendue === signatureOnglets && enfantsDe(hote).length === vues.length) {
    return;
  }
  signatureOnglets = attendue;
  vider(hote);
  vues.forEach(function (v) {
    const dansUneColonne = !!colonne(v.id);
    const onglet = el('div', {
      class: 'tab ps-vue-onglet'
        + (active === v.id && dansUneColonne ? ' active' : ''),
      'data-vue': v.id, role: 'tab',
      'aria-selected': String(active === v.id && dansUneColonne),
      title: v.titre + (dansUneColonne ? '' : ' (masqué — cliquer pour l’afficher)')
    },
    el('span', { class: 'ps-vue-icone', texte: v.icone || '◆' }),
    el('span', { class: 'ps-vue-titre', texte: v.titre }),
    el('button', { class: 'ps-vue-scinder', type: 'button',
      'data-scinder-vue': v.id,
      title: 'Afficher dans une nouvelle colonne, à droite', texte: '⧉' }),
    v.fermable === false ? null : el('button', {
      class: 'ps-vue-x', type: 'button', 'data-fermer': v.id,
      'aria-label': 'Fermer ' + v.titre, texte: '×'
    }));
    if (!dansUneColonne) onglet.className += ' ps-vue-masquee';
    hote.appendChild(onglet);
  });
}

'''),
)


def lire(nom):
    with io.open(os.path.join(ICI, nom), encoding='utf8') as fichier:
        return fichier.read()


def ecrire(nom, texte):
    with io.open(os.path.join(ICI, nom), 'w', encoding='utf8') as fichier:
        fichier.write(texte)


def decouper(texte, debut, fin, nom):
    """Tranche un bloc entre `debut` inclus et `fin` exclu, de façon unique."""
    if texte.count(debut) != 1:
        raise AssertionError('%s : début %r trouvé %d fois'
                             % (nom, debut[:48], texte.count(debut)))
    if texte.count(fin) != 1:
        raise AssertionError('%s : fin %r trouvée %d fois'
                             % (nom, fin[:48], texte.count(fin)))
    i = texte.index(debut)
    j = texte.index(fin)
    if j <= i:
        raise AssertionError('%s : la fin précède le début' % nom)
    return i, j


def appliquer(textes, journal):
    """Applique tout sur des copies en mémoire. Lève si une ancre manque."""
    for nom, ancien, nouveau, compte in SUBSTITUTIONS:
        trouve = textes[nom].count(ancien)
        if trouve != compte:
            raise AssertionError('ancrage trouvé %d fois au lieu de %d dans '
                                 '%s : %r' % (trouve, compte, nom, ancien[:70]))
        textes[nom] = textes[nom].replace(ancien, nouveau, compte)
        journal.append('%s : substitution %r' % (nom, ancien.splitlines()[0][:52]))
    for nom, debut, fin, nouveau in FONCTIONS:
        i, j = decouper(textes[nom], debut, fin, nom)
        textes[nom] = textes[nom][:i] + nouveau + textes[nom][j:]
        journal.append('%s : fonction %s réécrite (%d -> %d caractères)'
                       % (nom, debut.split('(')[0].replace('function ', ''),
                          j - i, len(nouveau)))
    return textes


def verifier(textes):
    """Trois états : 0 conforme, 1 à corriger, 2 problème."""
    problemes = []
    deja = True
    for nom, ancien, nouveau, _compte in SUBSTITUTIONS:
        avant, apres = textes[nom].count(ancien), textes[nom].count(nouveau)
        if apres:
            # Un remplacement qui CONTIENT son ancre (ajout de lignes après une
            # déclaration) laisse les deux présents : ce n'est un problème que
            # si l'ancre n'est pas un morceau du remplacement.
            if avant and ancien not in nouveau:
                problemes.append('%s : ancre et remplacement tous deux présents'
                                 % nom)
                deja = False
            continue
        if avant:
            deja = False
        else:
            problemes.append('%s : ancre introuvable (ni avant ni après)' % nom)
            deja = False
    for nom, debut, fin, nouveau in FONCTIONS:
        texte = textes[nom]
        if nouveau in texte:
            continue
        if texte.count(debut) == 1 and texte.count(fin) == 1:
            deja = False
            continue
        problemes.append('%s : bornes de %r introuvables' % (nom, debut[:40]))
        deja = False
    if problemes:
        return 2, problemes
    return (0 if deja else 1), []


def main():
    textes = {nom: lire(nom) for nom in FICHIERS}

    if '--verifier' in sys.argv:
        code, problemes = verifier(textes)
        if code == 0:
            print('vues déléguées 4.3.1 : conforme — rendu réconcilié '
                  '(idempotent), affichage sur intention, géométrie rendue à la '
                  'zone, poignées désarmées en colonne')
        elif code == 1:
            print('vues déléguées 4.3.1 : à corriger')
        else:
            print('vues déléguées 4.3.1 : PROBLÈME')
            for p in problemes:
                print('  - ' + p)
        return code

    code, problemes = verifier(textes)
    if code == 0:
        print("ECHEC : la correction 4.3.1 est déjà appliquée ; ce correcteur a "
              "déjà été joué.")
        return 1
    if code == 2:
        print("ECHEC, rien n'est écrit :")
        for p in problemes:
            print('  - ' + p)
        return 1

    journal = []
    try:
        appliquer(textes, journal)
    except AssertionError as erreur:
        print("ECHEC, rien n'est écrit : %s" % erreur)
        return 1

    if not os.path.isdir(SAUVEGARDES):
        os.makedirs(SAUVEGARDES)
    for nom in FICHIERS:
        destination = os.path.join(SAUVEGARDES, nom + '.avant-4.3.1')
        if not os.path.exists(destination):
            shutil.copy2(os.path.join(ICI, nom), destination)

    for nom in FICHIERS:
        ecrire(nom, textes[nom])
        if nom.endswith('.js'):
            # Un fichier écrit n'est pas un fichier valide : node --check en lit
            # la syntaxe sans rien exécuter, donc sans toucher au DOM.
            controle = subprocess.run(['node', '--check', os.path.join(ICI, nom)],
                                      capture_output=True, text=True)
            if controle.returncode != 0:
                print('ECHEC : %s ne se parse plus' % nom)
                print(controle.stderr[-900:])
                return 1

    print('vues déléguées 4.3.1 : %d substitutions et %d fonctions réécrites '
          'sur %d fichiers' % (len(SUBSTITUTIONS), len(FONCTIONS), len(FICHIERS)))
    for ligne in journal:
        print('   - ' + ligne)
    for nom in FICHIERS:
        suffixe = ', node --check conforme' if nom.endswith('.js') else ''
        print('   %-24s %6d caractères%s' % (nom, len(textes[nom]), suffixe))
    print('   sauvegardes : %s'
          % ', '.join(n + '.avant-4.3.1' for n in FICHIERS))
    return 0


if __name__ == '__main__':
    sys.exit(main())
