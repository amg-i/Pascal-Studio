#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Faire passer les trois panneaux devant les fichiers ouverts (4.3.0).

CE QUE L'UTILISATEUR A DEMANDÉ
  « Que l'onglet rétro-ingénierie ne soit pas juste un bandeau mais quelque
  chose qui passe devant les fichiers ouverts, idem pour dev web. » Et, pour le
  navigateur : un onglet comme les fichiers, plus de fenêtre flottante.

CE QUE CE CORRECTIF FAIT
  Les trois panneaux rendent leur contenu dans une VUE de `vues-studio.js`
  (`window.PSVues`) au lieu de l'écrire dans leur hôte de la barre latérale.
  L'hôte de la barre latérale devient un QUAI : il dit où est le panneau, quel
  est son état, et propose de le replier ou de le mettre côte à côte avec
  l'éditeur. Rien n'est recopié d'un panneau à l'autre : le mécanisme est commun
  et chaque panneau ne fournit que son noeud.

POURQUOI UN QUAI PLUTÔT RIEN
  Le bundle crée l'hôte latéral tant que le bouton de la barre d'activité est
  actif. Le laisser vide ferait une colonne de 238 pixels muette — exactement le
  « bandeau » reproché, en pire. Le quai rend cette place utile et, surtout, il
  garde visible le moyen de tout replier.

POURQUOI LE REPLI
  Si `window.PSVues` est absent (base non patchée, patch refusé), chaque panneau
  reprend son comportement antérieur : contenu dans l'hôte latéral, fenêtre
  flottante pour le navigateur. Une fonctionnalité ne doit pas disparaître parce
  qu'un autre morceau manque.

LE PIÈGE ÉVITÉ, à ne pas redécouvrir
  `re-studio.js:attach()` se protégeait de la reconstruction par
  `if (cible === hote && racine && contient(cible, racine)) return;`. Avec une
  vue, la racine n'est PLUS dans l'hôte latéral : ce garde ne se déclenche
  jamais, `attach()` reconstruit le panneau à chaque passage de l'observateur, et
  l'utilisateur perd son état toutes les deux secondes. Le garde accepte donc
  aussi une racine attachée AILLEURS. Même raisonnement pour dev web.

Idempotence : chaque substitution est signée par le texte ajouté.
Usage :
    python3 corriger-vues-plein-ecran.py [--verifier]
"""

import io
import os
import sys

RACINE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# rétro-ingénierie
# ---------------------------------------------------------------------------
RE_ANCRE_CONST = "const HOTE = '.ps-re-host';\n"
RE_NOUVELLE_CONST = """const HOTE = '.ps-re-host';
/* 4.3.0 : le panneau passe devant les fichiers ouverts. Ces trois constantes
 * sont la seule identité de la vue — le contenu, lui, reste construit par
 * `construire()` et n'est jamais recopié. */
const ID_VUE = 'retro';
const TITRE_VUE = 'Rétro-ingénierie';
const ICONE_VUE = '0x';
"""

RE_ANCRE_GARDE = """  if (cible === hote && racine && contient(cible, racine)) return;
  hote = cible;
  vider(hote);
  racine = construire();
  hote.appendChild(racine);
"""
RE_NOUVELLE_GARDE = """  /* Avec une vue, la racine n'est plus dans l'hôte latéral : sans le second
   * membre, ce garde ne se déclencherait jamais et le panneau serait reconstruit
   * à chaque passage de l'observateur, en perdant son état. */
  if (cible === hote && racine && (contient(cible, racine) || racineAttachee())) {
    /* L'hôte latéral a pu être recréé par React : le quai, lui, doit suivre. */
    rendreQuai(cible);
    return;
  }
  hote = cible;
  vider(hote);
  racine = construire();
  if (ouvrirVue(racine)) rendreQuai(hote);
  else hote.appendChild(racine);
"""

RE_ANCRE_ABSENT = "    if (hote && !encoreAttache(hote)) { hote = null; racine = null; }"
RE_NOUVELLE_ABSENT = """    if (hote && !encoreAttache(hote)) {
      hote = null; racine = null;
      /* Le bouton de la barre d'activité a été désactivé : la vue suit. Sans
       * cet appel, le panneau resterait affiché devant les fichiers alors que
       * l'utilisateur vient de le refermer. */
      fermerVue();
    }"""

RE_ANCRE_FIN = "function encoreAttache(noeud) {"
RE_NOUVELLE_FIN = """/* ------------------------------------------------------- vue plein écran --
 * Trois fonctions, et une seule règle : si window.PSVues manque, on rend
 * `false` et le panneau reprend sa place dans la barre latérale. */
function racineAttachee() {
  if (!racine) return false;
  if (typeof racine.isConnected === 'boolean') return racine.isConnected;
  return !!racine.parentNode;
}

function ouvrirVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    return window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud,
      surFermeture: function () { racine = null; }
    }) === true;
  } catch (exc) {
    return false;
  }
}

function fermerVue() {
  if (!window.PSVues || typeof window.PSVues.fermer !== 'function') return;
  try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
}

/* Le quai : la barre latérale ne reste jamais vide ni muette. */
function rendreQuai(cible) {
  if (!cible) return;
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return;
  vider(cible);
  const disposition = (typeof window.PSVues.disposition === 'function')
    ? window.PSVues.disposition() : { mode: 'plein', colonnes: [] };
  const partage = disposition.mode === 'partage';
  const quai = el('div', { class: 'ps-vues-quai' },
    el('p', { class: 'ps-vues-quai-titre', text: 'Rétro-ingénierie' }),
    el('p', { class: 'ps-vues-quai-texte',
      text: 'Le panneau est affiché devant les fichiers ouverts.' }),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'mode' }),
      el('b', { text: partage ? 'côte à côte' : 'plein écran' })),
    boutonQuai('Replier le panneau', 'replier', function () { fermerVue(); }),
    boutonQuai(partage ? 'Passer en plein écran' : 'Garder l’éditeur à gauche',
      'basculer', function () {
        if (typeof window.PSVues.mode === 'function') {
          window.PSVues.mode(partage ? 'plein' : 'partage');
        }
        rendreQuai($(HOTE));
      }));
  cible.appendChild(quai);
}

function boutonQuai(texte, acte, rappel) {
  const b = el('button', { type: 'button', 'data-acte': acte, title: texte });
  b.textContent = texte;
  b.addEventListener('click', function (evt) {
    if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
    try { rappel(); } catch (exc) { statut && statut(String(exc), 'erreur'); }
  });
  return b;
}

function encoreAttache(noeud) {"""

# ---------------------------------------------------------------------------
# dev web
# ---------------------------------------------------------------------------
DW_ANCRE_CONST = "const HOTE = '.ps-devweb-host';\n"
DW_NOUVELLE_CONST = """const HOTE = '.ps-devweb-host';
/* 4.3.0 : le panneau passe devant les fichiers ouverts, comme la
 * rétro-ingénierie. Même mécanisme, mêmes garanties. */
const ID_VUE = 'devweb';
const TITRE_VUE = 'Dev web';
const ICONE_VUE = '</>';
"""

DW_ANCRE_APPEND = """  panneau.append(el('div', { class: 'psdw-statut', text: statutTexte || 'Prêt.' }));
  hote.append(panneau);
"""
DW_NOUVELLE_APPEND = """  panneau.append(el('div', { class: 'psdw-statut', text: statutTexte || 'Prêt.' }));
  /* 4.3.0 : le panneau passe devant les fichiers ouverts. S'il n'y a pas de
   * mécanisme de vues, il reste dans la barre latérale comme avant. */
  if (!ouvrirVue(panneau)) hote.append(panneau);
  else rendreQuai(hote);
"""

DW_ANCRE_ABSENT = "  if (!cible && hote) { hote = null; arretSonde(); }"
DW_NOUVELLE_ABSENT = """  if (!cible && hote) { hote = null; arretSonde(); fermerVue(); }"""

DW_ANCRE_FIN = "let observateurHote = null;"
DW_NOUVELLE_FIN = """/* ------------------------------------------------------- vue plein écran -- */
let vueOuverte = false;

function ouvrirVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    vueOuverte = window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud
    }) === true;
    return vueOuverte;
  } catch (exc) {
    vueOuverte = false;
    return false;
  }
}

function fermerVue() {
  vueOuverte = false;
  if (!window.PSVues || typeof window.PSVues.fermer !== 'function') return;
  try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
}

/* Le quai : la barre latérale ne reste jamais vide ni muette. */
function rendreQuai(cible) {
  if (!cible || !vueOuverte) return;
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return;
  vider(cible);
  const disposition = (typeof window.PSVues.disposition === 'function')
    ? window.PSVues.disposition() : { mode: 'plein' };
  const partage = disposition.mode === 'partage';
  const quai = el('div', { class: 'ps-vues-quai' },
    el('p', { class: 'ps-vues-quai-titre', text: 'Dev web' }),
    el('p', { class: 'ps-vues-quai-texte',
      text: 'Le panneau est affiché devant les fichiers ouverts.' }),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'mode' }),
      el('b', { text: partage ? 'côte à côte' : 'plein écran' })),
    el('div', { class: 'ps-vues-quai-etat' },
      el('span', { text: 'statut' }),
      el('b', { text: (statutTexte || 'Prêt.').slice(0, 42) })),
    boutonQuai('Replier le panneau', 'replier', function () {
      fermerVue();
      if (typeof arretSonde === 'function') arretSonde();
    }),
    boutonQuai(partage ? 'Passer en plein écran' : 'Garder l’éditeur à gauche',
      'basculer', function () {
        if (typeof window.PSVues.mode === 'function') {
          window.PSVues.mode(partage ? 'plein' : 'partage');
        }
        rendreQuai($(HOTE));
      }));
  cible.append(quai);
}

function boutonQuai(texte, acte, rappel) {
  const b = el('button', { type: 'button', 'data-acte': acte, title: texte });
  b.textContent = texte;
  b.addEventListener('click', function (evt) {
    if (evt && typeof evt.stopPropagation === 'function') evt.stopPropagation();
    try { rappel(); } catch (exc) { statut(String(exc), 'erreur'); }
  });
  return b;
}

let observateurHote = null;"""

# ---------------------------------------------------------------------------
# navigateur
# ---------------------------------------------------------------------------
NA_ANCRE_PROJET = """  const projet = el('button', { class: 'psnav-btn psnav-projet', type: 'button',
    title: 'Aperçu du projet en cours, servi par Pascal Studio' });
  projet.innerHTML = I.maison;
  projet.addEventListener('click', () => {
    const origine = window.location.origin;
    naviguer(origine);
    statut('Aperçu du projet servi par Pascal Studio : ' + origine, 'info');
  });
"""
# Le bouton « accueil local » est SUPPRIMÉ, comme demandé : deux boutons maison
# côte à côte, dont un qui mène au localhost, ne se distinguent pas. L'aperçu du
# projet garde son propre chemin d'accès (panneau dev web), donc rien n'est perdu.
NA_NOUVELLE_PROJET = """  /* 4.3.0 : le second bouton « maison » est supprimé, comme demandé. Il menait
   * à l'origine de l'application — donc à http://localhost:PORT — et deux
   * boutons maison identiques côte à côte ne se distinguaient pas. L'aperçu du
   * projet servi par Pascal Studio reste accessible par le panneau dev web, qui
   * est son vrai point d'entrée : rien n'est perdu, seulement dédoublonné. */
"""

NA_ANCRE_APPEND = "  barre.append(back, forward, reload, home, projet, champ, favori, chercher,"
NA_NOUVELLE_APPEND = "  barre.append(back, forward, reload, home, champ, favori, chercher,"

NA_ANCRE_MONTER = """  rendreDeplacable();
  rendreRedimensionnable();
  document.body.append(panneau);
  return panneau;
"""
NA_NOUVELLE_MONTER = """  /* 4.3.0 : le navigateur est un ONGLET, plus une fenêtre flottante. La fenêtre
   * flottante recouvrait l'éditeur, devait être déplacée à la main, et sa
   * géométrie était persistée pour rien. En vue déléguée, elle a sa vignette
   * dans la barre d'onglets, se ferme par la croix, et peut être mise côte à
   * côte avec l'éditeur ou avec un autre panneau. */
  if (monterVue(panneau)) return panneau;
  rendreDeplacable();
  rendreRedimensionnable();
  document.body.append(panneau);
  return panneau;
"""

NA_ANCRE_CONST = "let panneau = null;"
NA_NOUVELLE_CONST = """let panneau = null;
/* 4.3.0 : identité de la vue déléguée. Le navigateur s'ouvre comme un onglet. */
const ID_VUE = 'navigateur';
const TITRE_VUE = 'Navigateur';
const ICONE_VUE = '⌾';
let enVue = false;
let fermetureEnCours = false;

function monterVue(noeud) {
  if (!window.PSVues || typeof window.PSVues.ouvrir !== 'function') return false;
  try {
    enVue = window.PSVues.ouvrir({
      id: ID_VUE, titre: TITRE_VUE, icone: ICONE_VUE, noeud: noeud,
      /* La croix de la vignette doit faire ce que faisait la croix de la fenêtre
       * flottante : persister les onglets et la géométrie, couper le relais. */
      surFermeture: function () { enVue = false; fermerPanneau(true); }
    }) === true;
    return enVue;
  } catch (exc) {
    enVue = false;
    return false;
  }
}

function activerVue() {
  if (!enVue || !window.PSVues || typeof window.PSVues.activer !== 'function') {
    return false;
  }
  try { return window.PSVues.activer(ID_VUE) === true; } catch (exc) { return false; }
}
"""

NA_ANCRE_OUVRIR = """async function ouvrirPanneau() {
  if (panneau && panneau.isConnected) { panneau.classList.remove('psnav-reduit'); panneau.focus(); return; }
  construire();"""
NA_NOUVELLE_OUVRIR = """async function ouvrirPanneau() {
  /* En onglet, « ouvrir » une seconde fois veut dire « remettre au premier
   * plan », pas « reconstruire » : reconstruire perdrait la page en cours. */
  if (panneau && panneau.isConnected && activerVue()) return;
  if (panneau && panneau.isConnected) { panneau.classList.remove('psnav-reduit'); panneau.focus(); return; }
  construire();"""

NA_ANCRE_FERMER = """function fermerPanneau() {
  if (!panneau) return;
  persisterOnglets();"""
NA_NOUVELLE_FERMER = """function fermerPanneau(depuisVue) {
  if (!panneau) return;
  /* Garde anti-récursion : fermerPanneau() retire la vue, dont la fermeture
   * rappelle surFermeture, qui rappelle fermerPanneau(). Sans cette garde, la
   * boucle ne s'arrête que par chance. */
  if (fermetureEnCours) return;
  fermetureEnCours = true;
  try {
    persisterOnglets();"""

NA_ANCRE_FERMER_FIN = """  minuteurs = {};
  panneau.remove();
  panneau = null;
}
"""
NA_NOUVELLE_FERMER_FIN = """    minuteurs = {};
    if (enVue && !depuisVue && window.PSVues &&
        typeof window.PSVues.fermer === 'function') {
      enVue = false;
      try { window.PSVues.fermer(ID_VUE); } catch (exc) { /* déjà fermée */ }
    }
    if (panneau && typeof panneau.remove === 'function') panneau.remove();
    panneau = null;
    enVue = false;
  } finally {
    fermetureEnCours = false;
  }
}
"""

SUBSTITUTIONS = (
    ('re-studio.js', (
        ('constantes de la vue', RE_ANCRE_CONST, RE_NOUVELLE_CONST),
        ('garde de reconstruction', RE_ANCRE_GARDE, RE_NOUVELLE_GARDE),
        ('fermeture quand l’hôte disparaît', RE_ANCRE_ABSENT, RE_NOUVELLE_ABSENT),
        ('fonctions de vue et quai', RE_ANCRE_FIN, RE_NOUVELLE_FIN),
    )),
    ('devweb-studio.js', (
        ('constantes de la vue', DW_ANCRE_CONST, DW_NOUVELLE_CONST),
        ('panneau rendu dans la vue', DW_ANCRE_APPEND, DW_NOUVELLE_APPEND),
        ('fermeture quand l’hôte disparaît', DW_ANCRE_ABSENT, DW_NOUVELLE_ABSENT),
        ('fonctions de vue et quai', DW_ANCRE_FIN, DW_NOUVELLE_FIN),
    )),
    ('navigateur-studio.js', (
        ('identité de la vue', NA_ANCRE_CONST, NA_NOUVELLE_CONST),
        ('second bouton maison supprimé', NA_ANCRE_PROJET, NA_NOUVELLE_PROJET),
        ('barre sans le bouton local', NA_ANCRE_APPEND, NA_NOUVELLE_APPEND),
        ('panneau monté en vue', NA_ANCRE_MONTER, NA_NOUVELLE_MONTER),
        ('ouverture = premier plan', NA_ANCRE_OUVRIR, NA_NOUVELLE_OUVRIR),
        ('fermeture anti-récursion', NA_ANCRE_FERMER, NA_NOUVELLE_FERMER),
        ('fin de fermeture', NA_ANCRE_FERMER_FIN, NA_NOUVELLE_FERMER_FIN),
    )),
)

# Ce qui prouve l'application, et qui doit rester VRAI ensuite : un correctif
# qui casse une garantie doit être visible au contrôle, pas à l'usage.
TRACES = (
    ('re-studio.js', ('ID_VUE', 'ouvrirVue(racine)', 'racineAttachee()',
                      'ps-vues-quai')),
    ('devweb-studio.js', ('ID_VUE', 'ouvrirVue(panneau)', 'ps-vues-quai',
                          'fermerVue()')),
    ('navigateur-studio.js', ('ID_VUE', 'monterVue(panneau)', 'activerVue()',
                              'fermetureEnCours')),
)
INTERDITS = (
    # Le bouton « maison locale » ne doit plus exister, nulle part.
    ('navigateur-studio.js', ('psnav-projet',)),
)


def verifier(chemin):
    texte = io.open(chemin, encoding='utf-8').read()
    nom = os.path.basename(chemin)
    lignes = []
    code = 0
    for titre, ancre, nouveau in _substitutions(nom):
        # La signature est le TEXTE AJOUTÉ, jamais l'ancre : une ancre absente
        # peut aussi vouloir dire « le fichier n'est pas celui qu'on croit ».
        if nouveau.strip() in texte:
            lignes.append('  %-38s appliquée' % titre)
            continue
        compte = texte.count(ancre)
        if compte == 1:
            lignes.append('  %-38s applicable' % titre)
            code = max(code, 1)
        else:
            lignes.append('  %-38s ANCRE %d fois : rien n’est écrit.'
                          % (titre, compte))
            code = 2
    # Les traces et les interdits ne sont contrôlés que SI TOUT est appliqué :
    # avant l'application, « ID_VUE absent » n'est pas un problème, c'est l'état
    # normal du fichier. Les contrôler trop tôt rendait le correctif
    # inapplicable -- il se refusait lui-même.
    if code == 0:
        for trace in _traces(nom):
            if trace not in texte:
                lignes.append('  TRACE MANQUANTE : %s' % trace)
                code = 2
        for interdit in _interdits(nom):
            if interdit in texte:
                lignes.append('  RESTE INTERDIT : %s' % interdit)
                code = 2
        if code == 0:
            lignes.append('  conforme (4.3.0 en place)')
    return code, lignes


def _substitutions(nom):
    for fichier, liste in SUBSTITUTIONS:
        if fichier == nom:
            return liste
    return ()


def _traces(nom):
    for fichier, liste in TRACES:
        if fichier == nom:
            return liste
    return ()


def _interdits(nom):
    for fichier, liste in INTERDITS:
        if fichier == nom:
            return liste
    return ()


def appliquer(chemin):
    texte = io.open(chemin, encoding='utf-8').read()
    nom = os.path.basename(chemin)
    depart = len(texte)
    for titre, ancre, nouveau in _substitutions(nom):
        if nouveau.strip() and nouveau.strip() in texte:
            continue
        assert texte.count(ancre) == 1, \
            '%s : l’ancre de « %s » apparaît %d fois' % (
                nom, titre, texte.count(ancre))
        texte = texte.replace(ancre, nouveau, 1)
    for trace in _traces(nom):
        assert trace in texte, '%s : trace %r absente après application' % (nom, trace)
    for interdit in _interdits(nom):
        assert interdit not in texte, \
            '%s : %r est encore présent après application' % (nom, interdit)
    io.open(chemin, 'w', encoding='utf-8').write(texte)
    sys.stderr.write('%s : %d -> %d caractères.\n' % (nom, depart, len(texte)))
    return 0


def main(argv):
    seulement_verifier = '--verifier' in argv
    cibles = [a for a in argv if a != '--verifier']
    if not cibles:
        cibles = [f for f, _ in SUBSTITUTIONS]
    rc = 0
    for cible in cibles:
        chemin = cible if os.path.isabs(cible) else os.path.join(RACINE, cible)
        if not os.path.isfile(chemin):
            sys.stderr.write('%s : introuvable.\n' % cible)
            rc = 2
            continue
        code, lignes = verifier(chemin)
        sys.stderr.write('%s :\n' % cible)
        for ligne in lignes:
            sys.stderr.write(ligne + '\n')
        if seulement_verifier:
            rc = max(rc, code)
            continue
        if code == 0:
            sys.stderr.write('  déjà conforme.\n')
            continue
        if code == 2:
            rc = 2
            continue
        rc = max(rc, appliquer(chemin))
    return rc


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
