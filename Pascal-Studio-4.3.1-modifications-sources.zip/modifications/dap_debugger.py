"""Local DAP bridge for Go (Delve) and Ruby (rdbg).

A private Unix socket separates protocol traffic from the inferior PTY. Code
runs with the user's permissions. No shell is used to execute the target.
"""
import json, os, pty, queue, shutil, signal, socket, subprocess, tempfile, termios, threading, time
from pathlib import Path

class DapDebugger:
 def __init__(self,root,external_files=None):
  self.root=Path(root).resolve();self.external_files=external_files if external_files is not None else {};self.lock=threading.RLock();self.sendlock=threading.Lock();self.stoplock=threading.Lock()
  self.proc=None;self.conn=None;self.master=None;self.pending={};self.seq=0;self.bpmap={};self.frame_id=None;self.thread_id=None;self.folder=None;self.mode=None;self.pause_generation=0;self.first_pause=False
  self.data={'active':False,'state':'idle','reason':'','frame':None,'frames':[],'variables':[],'output':'','message':'','breakpoints':[]}
 def snapshot(self):
  with self.lock:return dict(self.data)
 def file(self,key):
  if not isinstance(key,str):raise ValueError('Fichier invalide.')
  p=self.external_files.get(key) if key.startswith('@external:') else (self.root/key).resolve()
  if p is None or (not key.startswith('@external:') and not p.is_relative_to(self.root)) or not p.is_file():raise ValueError('Fichier de point d’arrêt invalide.')
  return Path(p).resolve()
 def key(self,path):
  try:
   p=Path(path).resolve()
   try:return p.relative_to(self.root).as_posix()
   except ValueError:return next((k for k,v in self.external_files.items() if Path(v).resolve()==p),'')
  except (ValueError,OSError):return ''
 def request(self,command,args=None,timeout=12):
  with self.lock:
   if not self.conn:raise ValueError('Session de débogage inactive.')
   self.seq+=1;seq=self.seq;waiter=queue.Queue(1);self.pending[seq]=waiter;conn=self.conn
  obj={'seq':seq,'type':'request','command':command,'arguments':args or {}};data=json.dumps(obj,ensure_ascii=True).encode();packet=b'Content-Length: '+str(len(data)).encode()+b'\r\n\r\n'+data
  try:
   with self.sendlock:conn.sendall(packet)
   try:response=waiter.get(timeout=timeout)
   except queue.Empty:raise ValueError('Le débogueur ne répond pas à '+command+'.')
   if not response.get('success',False):
    error=response.get('body',{}).get('error',{});raise ValueError(error.get('format') or response.get('message') or 'Erreur du débogueur.')
   return response.get('body') or {}
  finally:
   with self.lock:self.pending.pop(seq,None)
 def listen(self,conn,proc):
  try:
   stream=conn.makefile('rb')
   with stream:
    while True:
     n=None
     while True:
      line=stream.readline(8192)
      if not line:return
      if line in (b'\r\n',b'\n'):break
      if line.lower().startswith(b'content-length:'):n=int(line.split(b':',1)[1])
     if n is None or n<0 or n>8_000_000:raise ValueError('Trame DAP invalide.')
     raw=stream.read(n)
     if len(raw)!=n:break
     self.event(json.loads(raw),proc)
  except (OSError,ValueError,json.JSONDecodeError):pass
  finally:
   with self.lock:
    if self.proc is proc:
     for waiter in list(self.pending.values()):
      try:waiter.put_nowait({'success':False,'message':'Session de débogage terminée.'})
      except queue.Full:pass
 def event(self,obj,proc):
  with self.lock:
   if self.proc is not proc:return
  if obj.get('type')=='response':
   with self.lock:q=self.pending.get(obj.get('request_seq'))
   if q:
    try:q.put_nowait(obj)
    except queue.Full:pass
   return
  if obj.get('type')!='event':return
  event=obj.get('event');body=obj.get('body') or {}
  if event=='stopped':
   if self.mode=='ruby' and self.first_pause:
    self.first_pause=False;threading.Thread(target=self.initial_ruby,args=(proc,body),daemon=True).start();return
   with self.lock:
    self.pause_generation+=1;generation=self.pause_generation;self.thread_id=body.get('threadId',1);self.data.update(state='paused',reason=body.get('reason','paused'),frame=None,frames=[],variables=[])
   threading.Thread(target=self.inspect,args=(proc,generation,self.thread_id),daemon=True).start()
  elif event=='continued':
   with self.lock:self.pause_generation+=1;self.data.update(state='running',frame=None,frames=[],variables=[])
  elif event in ('terminated','exited'):
   threading.Thread(target=self._finish,args=(proc,),daemon=True).start()
  elif event=='output' and body.get('category') not in ('telemetry','console'):
   self.output(body.get('output',''))
 def initial_ruby(self,proc,body):
  try:
   tid=body.get('threadId',1);stack=self.request('stackTrace',{'threadId':tid,'startFrame':0,'levels':1}).get('stackFrames',[])
   top=stack[0] if stack else {};key=self.key((top.get('source') or {}).get('path',''));line=top.get('line',0)
   if (key,line) not in self.bpmap:
    self.request('continue',{'threadId':tid});return
   with self.lock:
    self.pause_generation+=1;generation=self.pause_generation;self.thread_id=tid;self.data.update(state='paused',reason=body.get('reason','paused'),frame=None,frames=[],variables=[])
   self.inspect(proc,generation,tid)
  except Exception as e:
   with self.lock:
    if self.proc is proc:self.data.update(state='paused',message=str(e))
 def inspect(self,proc,generation,thread_id):
  try:
   result=self.request('stackTrace',{'threadId':thread_id,'startFrame':0,'levels':30});raw=result.get('stackFrames',[]);frames=[]
   for i,f in enumerate(raw):frames.append({'file':self.key((f.get('source') or {}).get('path','')),'line':f.get('line',0),'function':f.get('name','?'),'level':str(i)})
   frame_id=raw[0]['id'] if raw else None;variables=[]
   if frame_id is not None:
    scopes=self.request('scopes',{'frameId':frame_id}).get('scopes',[])
    for scope in scopes:
     if scope.get('expensive'):continue
     ref=scope.get('variablesReference',0)
     if not ref:continue
     values=self.request('variables',{'variablesReference':ref}).get('variables',[])
     variables.extend({'name':v.get('name','?'),'value':str(v.get('value',''))[:500]} for v in values[:150])
     if variables:break
   with self.lock:
    if self.proc is proc and self.pause_generation==generation and self.data['state']=='paused':
     self.frame_id=frame_id;self.data.update(frames=frames,frame=frames[0] if frames else None,variables=variables)
  except Exception as e:
   with self.lock:
    if self.proc is proc:self.data['message']=str(e)
 def output(self,s):
  with self.lock:self.data['output']=(self.data['output']+str(s))[-2_000_000:]
 def _finish(self,proc):time.sleep(.3);self.stop(finished=True,expected=proc)
 def start(self,mode,target,breakpoints,cwd=None):
  if self.snapshot()['active']:raise ValueError('Arrêtez la session de débogage en cours.')
  if mode not in ('go','ruby'):raise ValueError('Langage DAP inconnu.')
  exe=shutil.which('dlv' if mode=='go' else 'rdbg');setsid=shutil.which('setsid')
  if not exe:raise ValueError('Installez '+('Delve : sudo apt install delve' if mode=='go' else 'le débogueur Ruby : sudo apt install ruby-debug')+'.')
  if not setsid:raise ValueError('La commande setsid (util-linux) est nécessaire au débogage.')
  if not breakpoints or len(breakpoints)>1000:raise ValueError('Ajoutez au moins un point d’arrêt valide.')
  if mode=='go':target=Path(target).resolve();cwd=Path(cwd).resolve() if cwd else self.root
  else:target=self.file(target);cwd=target.parent
  checked=[(b['path'],int(b['line'])) for b in breakpoints]
  for path,line in checked:
   self.file(path)
   if line<1:raise ValueError('Ligne invalide.')
  self.mode=mode;self.bpmap={};self.first_pause=mode=='ruby';self.folder=tempfile.mkdtemp(prefix='ps-dap-');path=str(Path(self.folder)/'socket');self.master,slave=pty.openpty();attrs=termios.tcgetattr(slave);attrs[3]&=~termios.ECHO;termios.tcsetattr(slave,termios.TCSANOW,attrs)
  args=[exe,'dap','--listen=unix:'+path] if mode=='go' else [exe,'--no-rc','--open','--sock-path',path,str(target)]
  try:
   proc=subprocess.Popen([setsid,'--ctty']+args,cwd=cwd,stdin=slave,stdout=slave,stderr=slave);self.proc=proc
   with self.lock:self.data.update(active=True,state='starting',reason='',frame=None,frames=[],variables=[],output='',message='',breakpoints=[])
   master=self.master
   def console():
    try:
     while True:
      try:chunk=os.read(master,4096)
      except OSError:break
      if not chunk:break
      with self.lock:
       if self.proc is not proc:break
      self.output(chunk.decode('utf8','replace').replace('\r\n','\n'))
    finally:
     try:os.close(master)
     except OSError:pass
   threading.Thread(target=console,daemon=True).start()
   deadline=time.monotonic()+12;last=None
   while time.monotonic()<deadline:
    if proc.poll() is not None:raise ValueError('Le débogueur s’est arrêté avant la connexion : '+self.snapshot()['output'][-500:])
    conn=socket.socket(socket.AF_UNIX)
    try:conn.connect(path);self.conn=conn;break
    except OSError as e:last=e;conn.close();time.sleep(.05)
   else:raise ValueError('Connexion au débogueur impossible : '+str(last))
   threading.Thread(target=self.listen,args=(self.conn,proc),daemon=True).start()
   self.request('initialize',{'clientID':'pascal-studio','adapterID':mode,'pathFormat':'path','linesStartAt1':True,'columnsStartAt1':True,'supportsVariableType':True})
   if mode=='go':self.request('launch',{'mode':'exec','program':str(target),'cwd':str(cwd),'stopOnEntry':False},timeout=30)
   else:self.request('attach',{'localfs':True})
   for key,line in checked:self.bpmap[(key,line)]=line
   for key in set(x[0] for x in checked):self.sync_breakpoints(key)
   self.request('configurationDone')
   with self.lock:
    if self.data['state']=='starting':self.data['state']='running'
   def reap():
    proc.wait()
    if self.proc is proc:threading.Thread(target=self._finish,args=(proc,),daemon=True).start()
   threading.Thread(target=reap,daemon=True).start()
  except Exception:
   self.stop();raise
  finally:os.close(slave)
 def sync_breakpoints(self,key):
  lines=sorted(line for path,line in self.bpmap if path==key);res=self.request('setBreakpoints',{'source':{'path':str(self.file(key))},'breakpoints':[{'line':n} for n in lines],'sourceModified':False});returned=res.get('breakpoints',[])
  for n,b in zip(lines,returned):
   if not b.get('verified',True):
    with self.lock:self.data['message']=b.get('message','Point d’arrêt non vérifié.')
   self.bpmap[(key,n)]=b.get('line',n)
  with self.lock:self.data['breakpoints']=[{'path':p,'line':n,'resolvedLine':r} for (p,n),r in self.bpmap.items()]
 def add_breakpoint(self,key,line):
  self.file(key);line=int(line)
  if line<1:raise ValueError('Ligne invalide.')
  self.bpmap[(key,line)]=line;self.sync_breakpoints(key)
 def remove_breakpoint(self,key,line):
  self.bpmap.pop((key,int(line)),None);self.sync_breakpoints(key)
 def action(self,action):
  if action=='pause':
   if self.mode=='ruby':raise ValueError('La pause à distance n’est pas prise en charge par ce débogueur Ruby ; utilisez un point d’arrêt.')
   self.request('pause',{'threadId':self.thread_id or 1});return
  commands={'continue':'continue','next':'next','stepIn':'stepIn','stepOut':'stepOut','step':'stepIn','out':'stepOut','finish':'stepOut'}
  if action not in commands:raise ValueError('Action de débogage inconnue.')
  with self.lock:
   if self.data['state']!='paused':raise ValueError('Le programme n’est pas arrêté.')
   thread=self.thread_id or 1;self.pause_generation+=1;self.data.update(state='running',frame=None,frames=[],variables=[])
  try:self.request(commands[action],{'threadId':thread})
  except Exception:
   with self.lock:self.data['state']='paused'
   raise
 def evaluate(self,expression):
  if not isinstance(expression,str) or not expression.strip() or '\n' in expression or len(expression)>4000:raise ValueError('Expression invalide.')
  with self.lock:
   if self.data['state']!='paused' or self.frame_id is None:raise ValueError('Le programme n’est pas arrêté sur une ligne.')
   frame=self.frame_id
  return str(self.request('evaluate',{'expression':expression,'frameId':frame,'context':'watch'}).get('result',''))
 def input(self,text):
  if not isinstance(text,str) or len(text)>100000:raise ValueError('Entrée invalide.')
  with self.lock:
   if not self.data['active'] or self.master is None:raise ValueError('Aucune session active.')
   os.write(self.master,(text+'\n').encode());self.data['output']=(self.data['output']+text+'\n')[-2_000_000:]
 def stop(self,finished=False,expected=None):
  with self.stoplock:
   proc=self.proc
   if expected is not None and proc is not expected:return
   if proc and proc.poll() is None:
    try:self.request('disconnect',{'terminateDebuggee':True},timeout=2)
    except Exception:pass
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
     try:os.killpg(proc.pid,signal.SIGTERM)
     except ProcessLookupError:pass
     try:proc.wait(timeout=2)
     except subprocess.TimeoutExpired:
      try:os.killpg(proc.pid,signal.SIGKILL)
      except ProcessLookupError:pass
      proc.wait()
   conn=self.conn;self.conn=None
   if conn:
    try:conn.shutdown(socket.SHUT_RDWR)
    except OSError:pass
    conn.close()
   if self.folder:shutil.rmtree(self.folder,ignore_errors=True);self.folder=None
   with self.lock:
    if self.proc is proc:self.pause_generation+=1;self.data.update(active=False,state='finished' if finished else 'idle',frame=None,frames=[],variables=[])
