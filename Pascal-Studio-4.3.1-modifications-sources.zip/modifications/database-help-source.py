"""Référence hors ligne des données pour Pascal Studio PC.
Génère database-help.js ; chaque fiche contient une explication et un exemple.
"""
import json
from pathlib import Path
articles=[]
languages=['Données · Studio','SQL','SQLite','PostgreSQL','MySQL / MariaDB','CSV / TSV','JSON']

def intro(lang,title,text):
 articles.append(dict(id='db-'+str(len(articles)),lang=lang,group='Introduction',title=title,summary='',intro=True,blocks=[dict(title='',text=text,code='')]))
def add(lang,group,entries):
 for title,text,code in entries:
  articles.append(dict(id='db-'+str(len(articles)),lang=lang,group=group,title=title,summary=text,intro=False,blocks=[dict(title='Explication',text=text,code=''),dict(title='Exemple',text='Exemple à adapter et à vérifier sur une copie de vos données.',code=code)]))

intro('Données · Studio','Utilité et présentation',"L’explorateur de données de Pascal Studio permet de lire et modifier des fichiers SQLite, CSV, TSV et JSON, d’éditer des scripts SQL et de travailler avec des serveurs PostgreSQL et MySQL ou MariaDB. Il est utile pour inspecter une petite base, corriger une donnée ou apprendre le SQL depuis le même environnement que vos programmes.\n\nLes systèmes de gestion de bases de données se sont développés à partir des années 1960 ; le modèle relationnel proposé par Edgar F. Codd en 1970 a ouvert la voie à SQL. Un fichier SQLite est une base locale, tandis que PostgreSQL et MySQL/MariaDB sont habituellement des services distincts. CSV et JSON sont des formats d’échange, pas des serveurs de bases de données.\n\nCette référence fonctionne hors ligne. Les fiches de SQL général sont complétées par celles propres à chaque moteur et à chaque format. Le comportement dépend des versions et des réglages : consultez aussi les documentations officielles. L’outil ne remplace pas les sauvegardes ni une formation à l’administration de bases.")
add('Données · Studio','Prise en main',[
('Ouvrir le panneau','Cliquez sur le bouton Données et bases SQL dans la barre verticale. Une source du projet ou choisie ailleurs sur l’ordinateur peut ensuite être ouverte.','Barre verticale → Données et bases SQL → Ouvrir un fichier…'),
('Créer une base SQLite','Créez un fichier .sqlite, .sqlite3, .db ou .db3 dans le projet ; un fichier existant ne sera pas écrasé. Une base vide ne contient pas encore de tables.','Créer une base SQLite… → donnees.sqlite → Créer'),
('Créer une première table','Après création ou ouverture de la base, ouvrez Requête SQL. Une table exige une clé primaire pour être modifiée dans la grille.','CREATE TABLE clients (id INTEGER PRIMARY KEY, nom TEXT NOT NULL);'),
('Actualiser les tables','Après une création, modification ou suppression de table par SQL ou par un autre outil, actualisez la liste des tables de la source.','Base ouverte → Actualiser les tables'),
('Lire une table','Sélectionnez une table dans la liste pour afficher jusqu’à 100 lignes par page. Les vues sont présentées en lecture seule.','TABLES ET VUES → clients → ›'),
('Modifier une cellule','Cliquez sur une valeur modifiable et choisissez son type. Appliquer prépare le changement ; Enregistrer et confirmer le transmettent à la base.','clients → cellule nom → Texte : Alice → Appliquer → Enregistrer'),
('Ajouter une ligne','Dans une table modifiable, choisissez Ligne. Pour chaque colonne, Défaut omet la valeur, NULL fournit une valeur nulle et les autres types envoient la valeur choisie.','＋ Ligne → nom : Texte / Alice → Ajouter → Enregistrer'),
('Supprimer une ligne','La croix marque une ligne pour suppression ; la flèche permet de l’annuler avant enregistrement. La suppression peut activer des déclencheurs et cascades.','× sur la ligne → Enregistrer → confirmer'),
('Lecture seule et clé primaire','Une table sans clé primaire ou une vue ne peut pas être modifiée dans cette grille. Certaines valeurs ou clés non représentables sans risque sont également en lecture seule.','CREATE TABLE articles (id INTEGER PRIMARY KEY, titre TEXT);'),
('Conflits sur les lignes','La grille compare les valeurs lues aux valeurs courantes lors de l’enregistrement. Si une ligne a changé, l’opération est annulée ; relisez avant de recommencer.','Modifier une ligne → modification externe → Enregistrer → conflit'),
('Fichiers : changement externe','Avant de remplacer un CSV, JSON ou SQL, le contenu actuel est comparé à la révision ouverte. La comparaison puis le remplacement ne forment pas une opération atomique interprocessus.','Sauvegarder une copie → actualiser le fichier → refaire la modification'),
('Scripts SQL','Un fichier .sql est édité et sauvegardé comme texte UTF-8. Charger dans une connexion copie le texte vers l’éditeur de requête sans exécution.','Ouvrir requete.sql → Charger dans une connexion… → sélectionner la base'),
('Une instruction à la fois','Les moteurs et pilotes ne traitent pas tous les scripts multi-instructions de la même façon. Pour ces exemples, exécutez séparément chaque instruction SQL.','CREATE TABLE notes (id INTEGER PRIMARY KEY, texte TEXT);'),
('Exécuter puis annuler','Ce bouton tente un rollback. Il n’annule pas nécessairement les effets externes, certains déclencheurs ou les DDL MySQL/MariaDB qui peuvent valider implicitement.','Requête SQL → SELECT * FROM clients → Exécuter puis annuler si possible'),
('Exécuter et valider','Ce bouton confirme la requête et valide sa transaction si le moteur le permet. Vérifiez WHERE et sauvegardez avant une écriture ; les actions ne sont pas isolées.','UPDATE clients SET nom = \'Alice\' WHERE id = 1;'),
('Limite des résultats','La grille de requête affiche au plus 100 lignes. PostgreSQL limite les SELECT et WITH usuels côté serveur, mais des calculs et valeurs très volumineuses peuvent toujours consommer beaucoup de ressources.','SELECT id, nom FROM clients ORDER BY id LIMIT 20;'),
('PostgreSQL et RETURNING','Dans cet éditeur, les modifications PostgreSQL avec RETURNING sont refusées pour limiter la mémoire ; les WITH modifiant des données peuvent aussi être refusés. Consultez ensuite avec SELECT.','UPDATE clients SET nom = \'Alice\' WHERE id = 1;'),
('Sauvegarder explicitement','La sauvegarde des données de ce panneau n’est pas celle de l’éditeur de code : elle ne se déclenche pas à la perte du focus. Enregistrez avant de fermer ou de changer de page.','Modifier → Enregistrer → confirmer'),
('Connexion serveur','Choisissez PostgreSQL ou MySQL/MariaDB, puis hôte, port, base, utilisateur et mot de passe. Ces identifiants restent en mémoire pendant la session, pas dans un fichier créé par cet outil.','Connexion serveur… → localhost : 5432 → base → utilisateur → connecter'),
('TLS et certificat CA','TLS avec vérification du certificat est activé par défaut. Pour un serveur distant, le certificat doit être reconnu et le nom de l’hôte doit correspondre ; une CA PEM peut être fournie.','Hôte : db.exemple.fr → TLS coché → certificat CA : /chemin/ca.pem'),
('Sans TLS sur localhost','L’application n’autorise une connexion sans TLS que vers localhost, 127.0.0.1 ou ::1. Sur un serveur distant utilisez TLS vérifié ou un tunnel local sûr correctement configuré.','Hôte : 127.0.0.1 → décocher TLS → confirmer le risque'),
('Privilèges minimaux','Utilisez un compte limité à la base et aux opérations nécessaires. L’interface, les requêtes, fonctions et déclencheurs agissent avec les droits du compte connecté.','Compte en lecture seule pour l’exploration ; compte distinct pour l’écriture.'),
('Fermeture et sessions','Fermer une source arrête sa connexion. Des modifications en attente donnent lieu à une confirmation. Les sessions inactives expirent après environ 30 minutes.','Fermer la source → confirmer si nécessaire'),
('Formats pris en charge','CSV, TSV, JSON et SQL sont lus en UTF-8 et limités à 5 Mo à l’ouverture. Les tableurs .xlsx et autres formats binaires ne sont pas pris en charge.','clients.csv   produits.tsv   donnees.json   requete.sql'),
('Référence et limites','Les sources React complètes de l’interface principale ne sont pas disponibles ; ce panneau a été ajouté à l’interface compilée. Cette aide n’est pas la documentation exhaustive des moteurs.','SQLite : https://www.sqlite.org/docs.html\nPostgreSQL : https://www.postgresql.org/docs/\nMySQL : https://dev.mysql.com/doc/\nMariaDB : https://mariadb.com/kb/'),
])

intro('SQL','Utilité, histoire et spécificités',"SQL sert à définir, interroger et modifier des données relationnelles. Il est utilisé par les applications, les outils d’analyse et l’administration de bases : SELECT lit, INSERT ajoute, UPDATE modifie et DELETE supprime. SQL décrit surtout le résultat recherché ; le moteur choisit généralement comment l’obtenir.\n\nAu début des années 1970, IBM a conçu SEQUEL pour System R, devenu SQL. Le langage a été normalisé par l’ANSI puis l’ISO à partir des années 1980. SQLite, PostgreSQL et MySQL/MariaDB utilisent des variantes : types, fonctions, guillemets, transactions et commandes d’administration diffèrent.\n\nLes exemples suivants supposent souvent une table clients(id, nom, ville, age) ou commandes(id, client_id, montant). Exécutez chaque instruction séparément, adaptez les noms, et évitez toute écriture sur une base de production sans sauvegarde. Les paramètres utilisés par un programme protègent les valeurs, pas les noms de table ou de colonne.")
add('SQL','Lecture · SELECT et filtres',[
('SELECT','Sélectionne les expressions ou colonnes à retourner ; l’ordre des lignes est indéfini sans ORDER BY.','SELECT nom, ville FROM clients;'),
('FROM','Indique la table ou la source des lignes. Un alias court permet de distinguer plusieurs tables.','SELECT c.nom FROM clients AS c;'),
('DISTINCT','Supprime les doublons du résultat portant sur toutes les expressions sélectionnées.','SELECT DISTINCT ville FROM clients;'),
('WHERE','Filtre les lignes avant les regroupements. Sans WHERE, une modification ou suppression vise potentiellement toutes les lignes.','SELECT nom FROM clients WHERE ville = \'Paris\';'),
('Comparaisons','Les opérateurs =, <>, <, <=, > et >= comparent des valeurs ; la comparaison avec NULL ne produit pas vrai ou faux ordinaire.','SELECT nom FROM clients WHERE age >= 18;'),
('AND, OR, NOT','Combinent ou inversent des conditions ; AND est évalué avant OR. Les parenthèses rendent l’intention explicite.','SELECT nom FROM clients WHERE (ville = \'Paris\' OR ville = \'Lyon\') AND age >= 18;'),
('BETWEEN','Teste une plage inclusive ; les bornes sont incluses et l’ordre des valeurs est important.','SELECT nom FROM clients WHERE age BETWEEN 18 AND 30;'),
('IN','Teste l’appartenance à une liste ou à un résultat de sous-requête. Attention à NULL dans NOT IN ; NOT EXISTS est souvent plus sûr.','SELECT nom FROM clients WHERE ville IN (\'Paris\', \'Lyon\');'),
('LIKE','Effectue une recherche par motif : % correspond à zéro ou plusieurs caractères et _ à un caractère. La casse dépend du moteur et de la collation.','SELECT nom FROM clients WHERE nom LIKE \'Al%\';'),
('NULL, IS NULL, IS NOT NULL','NULL représente une valeur inconnue ou absente. Utilisez IS NULL plutôt que = NULL ; NULL et chaîne vide sont différents.','SELECT nom FROM clients WHERE ville IS NULL;'),
('ORDER BY','Trie le résultat selon une ou plusieurs expressions ; ASC est ascendant, DESC descendant. Les règles de tri de NULL dépendent du moteur.','SELECT nom, age FROM clients ORDER BY age DESC, nom ASC;'),
('LIMIT et OFFSET','SQLite, PostgreSQL et MySQL/MariaDB acceptent LIMIT et OFFSET pour paginer. Ajoutez un tri stable, idéalement par une clé unique.','SELECT id, nom FROM clients ORDER BY id LIMIT 10 OFFSET 10;'),
('Alias de colonne','AS attribue un nom au résultat. Les règles de visibilité des alias dans WHERE et GROUP BY varient selon les moteurs.','SELECT nom AS client, age + 1 AS age_prochain FROM clients;'),
('Commentaires','-- commente jusqu’à la fin de ligne ; /* ... */ délimite un commentaire de bloc. Ne construisez pas des requêtes avec du texte non fiable.','SELECT nom -- nom public\nFROM clients;'),
('Chaînes littérales','Une chaîne est entourée d’apostrophes ; une apostrophe interne se double. Le comportement des antislashs dépend du moteur et du mode SQL.','SELECT \'L\'\'été\' AS saison;'),
('Identifiants','Les identifiants désignent tables et colonnes. Préférez des noms simples ; PostgreSQL et SQLite utilisent les guillemets doubles, MySQL normalement les accents graves.','SELECT nom FROM clients;'),
('CASE','Calcule une valeur conditionnelle. ELSE est facultatif ; en son absence, aucun cas correspondant donne NULL.','SELECT nom, CASE WHEN age >= 18 THEN \'adulte\' ELSE \'mineur\' END AS categorie FROM clients;'),
('COALESCE','Retourne la première expression non NULL ; utile pour afficher une valeur de remplacement sans modifier la donnée.','SELECT nom, COALESCE(ville, \'Non renseignée\') AS ville FROM clients;'),
('NULLIF','Retourne NULL si les deux valeurs sont égales, sinon la première. Utile notamment pour éviter une division par zéro.','SELECT 100.0 / NULLIF(0, 0) AS resultat;'),
('CAST','Convertit explicitement une expression. La validité et les types disponibles dépendent du moteur ; certaines conversions peuvent arrondir ou échouer.','SELECT CAST(\'42\' AS INTEGER) AS nombre;'),
('Sous-requête','Une requête imbriquée peut fournir un ensemble de valeurs à une requête extérieure. Les colonnes doivent être compatibles avec l’opérateur.','SELECT nom FROM clients WHERE id IN (SELECT client_id FROM commandes);'),
('EXISTS','Teste si la sous-requête retourne au moins une ligne. Une sous-requête corrélée peut faire référence à la ligne extérieure.','SELECT c.nom FROM clients c WHERE EXISTS (SELECT 1 FROM commandes o WHERE o.client_id = c.id);'),
('UNION et UNION ALL','UNION fusionne des résultats compatibles en supprimant les doublons ; UNION ALL conserve les doublons et évite cette déduplication.','SELECT ville FROM clients WHERE age < 18 UNION ALL SELECT ville FROM clients WHERE age >= 18;'),
('WITH et CTE','WITH nomme une expression de table temporaire pour une requête, ce qui améliore souvent sa lisibilité. Le support des CTE récursives dépend des versions.','WITH adultes AS (SELECT nom, age FROM clients WHERE age >= 18) SELECT nom FROM adultes;'),
])
add('SQL','Relations · jointures et agrégats',[
('INNER JOIN','Associe les lignes ayant une correspondance selon ON. Une relation un-à-plusieurs peut produire plusieurs lignes pour un même client.','SELECT c.nom, o.montant FROM clients c INNER JOIN commandes o ON o.client_id = c.id;'),
('LEFT JOIN','Conserve chaque ligne de gauche, même sans correspondance ; les colonnes de droite sont alors NULL.','SELECT c.nom, o.montant FROM clients c LEFT JOIN commandes o ON o.client_id = c.id;'),
('CROSS JOIN','Produit le produit cartésien : chaque ligne de gauche est associée à chaque ligne de droite. Le résultat peut devenir très volumineux.','SELECT c.nom, o.id FROM clients c CROSS JOIN commandes o;'),
('COUNT(*)','Compte toutes les lignes du groupe, y compris celles contenant NULL.','SELECT COUNT(*) AS nombre_clients FROM clients;'),
('COUNT(colonne)','Compte les valeurs non NULL de la colonne ; COUNT(DISTINCT colonne) compte ses valeurs distinctes non NULL.','SELECT COUNT(ville) AS villes_renseignees FROM clients;'),
('SUM','Calcule la somme des valeurs non NULL ; sur un ensemble vide, le résultat est généralement NULL.','SELECT SUM(montant) AS total FROM commandes;'),
('AVG','Calcule la moyenne des valeurs non NULL. Le type et la précision du résultat varient selon les types et le moteur.','SELECT AVG(montant) AS moyenne FROM commandes;'),
('MIN et MAX','Retournent respectivement la plus petite et la plus grande valeur non NULL selon le type et la collation.','SELECT MIN(age) AS minimum, MAX(age) AS maximum FROM clients;'),
('GROUP BY','Regroupe les lignes avant les agrégats. Pour une requête portable, sélectionnez uniquement les clés de groupe et les agrégats.','SELECT ville, COUNT(*) AS nombre FROM clients GROUP BY ville;'),
('HAVING','Filtre les groupes après GROUP BY, contrairement à WHERE qui filtre les lignes avant agrégation.','SELECT ville, COUNT(*) AS nombre FROM clients GROUP BY ville HAVING COUNT(*) >= 2;'),
('ROW_NUMBER','Fonction de fenêtre numérotant les lignes dans une fenêtre ordonnée. Nécessite une version du moteur prenant en charge les fenêtres.','SELECT nom, ROW_NUMBER() OVER (ORDER BY id) AS numero FROM clients;'),
('PARTITION BY','Divise la fenêtre en groupes sans fusionner les lignes, contrairement à GROUP BY.','SELECT nom, ville, COUNT(*) OVER (PARTITION BY ville) AS clients_ville FROM clients;'),
])
add('SQL','Écriture · tables et transactions',[
('CREATE TABLE','Crée une table et ses colonnes. Les types et les options comme la génération automatique de clé varient selon le moteur.','CREATE TABLE clients (id INTEGER PRIMARY KEY, nom VARCHAR(100) NOT NULL, ville VARCHAR(100), age INTEGER);'),
('PRIMARY KEY','Identifie une ligne de manière unique ; une clé peut être composée de plusieurs colonnes. Dans la grille Studio, la clé est requise pour l’édition.','CREATE TABLE categories (id INTEGER PRIMARY KEY, nom VARCHAR(100));'),
('NOT NULL','Interdit une valeur NULL dans une colonne ; vérifiez également les valeurs par défaut et les contraintes de l’application.','CREATE TABLE pays (id INTEGER PRIMARY KEY, nom VARCHAR(80) NOT NULL);'),
('UNIQUE','Interdit les doublons selon les règles du moteur ; la façon de traiter plusieurs NULL dépend du moteur.','CREATE TABLE utilisateurs (id INTEGER PRIMARY KEY, email VARCHAR(200) UNIQUE);'),
('CHECK','Définit une condition que doivent respecter les lignes. La prise en charge dépend notamment des versions de MySQL.','CREATE TABLE produits (id INTEGER PRIMARY KEY, prix DECIMAL(10,2) CHECK (prix >= 0));'),
('DEFAULT','Fournit une valeur quand la colonne est omise ; fournir explicitement NULL ne signifie pas nécessairement utiliser la valeur par défaut.','CREATE TABLE articles (id INTEGER PRIMARY KEY, statut VARCHAR(20) DEFAULT \'nouveau\');'),
('FOREIGN KEY','Relie une ou plusieurs colonnes à une clé d’une autre table. Dans SQLite, l’application doit activer la vérification par connexion.','CREATE TABLE commandes (id INTEGER PRIMARY KEY, client_id INTEGER REFERENCES clients(id), montant DECIMAL(10,2));'),
('INSERT','Ajoute une ligne. Nommez les colonnes afin de ne pas dépendre de l’ordre physique de la table.','INSERT INTO clients (id, nom, ville, age) VALUES (1, \'Alice\', \'Paris\', 30);'),
('INSERT … SELECT','Ajoute des lignes produites par une requête ; les colonnes sources et cibles doivent être compatibles.','INSERT INTO archives_clients (id, nom) SELECT id, nom FROM clients WHERE age >= 65;'),
('UPDATE','Modifie les colonnes des lignes correspondant à WHERE. Sans WHERE, toutes les lignes sont concernées.','UPDATE clients SET ville = \'Lyon\' WHERE id = 1;'),
('DELETE','Supprime les lignes correspondant à WHERE. Sans WHERE, toutes les lignes de la table sont supprimées.','DELETE FROM clients WHERE id = 1;'),
('ALTER TABLE','Modifie la définition d’une table existante. Les opérations disponibles et leur coût diffèrent fortement selon les moteurs.','ALTER TABLE clients ADD COLUMN telephone VARCHAR(30);'),
('DROP TABLE','Supprime la table et ses données ; il peut échouer si d’autres objets en dépendent. Faites une sauvegarde avant de l’utiliser.','DROP TABLE clients;'),
('CREATE INDEX','Crée un index pouvant accélérer certaines recherches et tris, au prix d’espace disque et d’un coût sur les écritures.','CREATE INDEX idx_clients_ville ON clients (ville);'),
('CREATE VIEW','Enregistre une requête sous forme de vue. Une vue ordinaire n’est pas nécessairement une copie des données et la grille Studio la laisse en lecture seule.','CREATE VIEW clients_majeurs AS SELECT id, nom FROM clients WHERE age >= 18;'),
('Transactions','Une transaction regroupe des opérations : COMMIT valide et ROLLBACK demande l’annulation. Les DDL MySQL/MariaDB et les effets externes ont des exceptions.','BEGIN;  -- puis des écritures, puis COMMIT ou ROLLBACK selon le client'),
('Valeurs paramétrées','Dans un programme, liez les valeurs avec l’API du pilote au lieu de concaténer du texte utilisateur. La syntaxe du marqueur dépend du pilote.','cursor.execute("SELECT nom FROM clients WHERE id = ?", (identifiant,))  # sqlite3 Python'),
])
add('SQL','Fonctions courantes',[
('ABS','Retourne la valeur absolue d’un nombre ; les cas extrêmes dépendent de la représentation numérique.','SELECT ABS(-12) AS valeur;'),
('ROUND','Arrondit un nombre avec éventuellement un nombre de décimales ; les règles d’arrondi et types pris en charge varient.','SELECT ROUND(12.345, 2) AS valeur;'),
('LOWER','Convertit une chaîne en minuscules selon les capacités Unicode et la collation du moteur.','SELECT LOWER(\'BONJOUR\') AS texte;'),
('UPPER','Convertit une chaîne en majuscules ; le comportement Unicode et linguistique varie selon les moteurs et leur configuration.','SELECT UPPER(\'bonjour\') AS texte;'),
('LENGTH','Retourne une longueur mais l’unité diffère : SQLite et PostgreSQL comptent généralement les caractères ; MySQL LENGTH compte les octets.','SELECT LENGTH(\'abc\') AS longueur;'),
('SUBSTR','Extrait une partie d’une chaîne ; la position est généralement indexée à partir de 1. Les positions négatives et les variantes dépendent du moteur.','SELECT SUBSTR(\'bonjour\', 1, 3) AS debut;'),
('TRIM','Retire par défaut les espaces au début et à la fin d’une chaîne ; les variantes dépendent du moteur.','SELECT TRIM(\'  texte  \') AS texte;'),
('REPLACE','Remplace les occurrences d’une sous-chaîne ; casse, collation et conversions peuvent différer selon le moteur.','SELECT REPLACE(\'a-b-c\', \'-\', \':\') AS texte;'),
])

intro('SQLite','Utilité, histoire et spécificités',"SQLite est une base relationnelle embarquée : elle stocke normalement une base dans un fichier et n’exige pas de serveur séparé. Elle convient aux applications locales, prototypes, tests et petits services, mais il faut tenir compte des accès concurrents et des sauvegardes cohérentes.\n\nCréé par D. Richard Hipp en 2000, SQLite est largement intégré aux systèmes et applications. Sa bibliothèque est dans le domaine public. Son typage est dynamique avec des affinités de colonnes ; les tables STRICT, disponibles dans les versions récentes, offrent des contrôles supplémentaires.\n\nL’explorateur ouvre une base existante ou en crée une dans le projet. SQLite peut utiliser des fichiers auxiliaires de journal ou WAL ; ne copiez pas uniquement le fichier principal d’une base active comme si cela garantissait une sauvegarde cohérente. Documentation : https://www.sqlite.org/docs.html")
add('SQLite','Types et valeurs',[
('NULL','NULL représente une valeur absente. Une colonne peut le refuser par NOT NULL ; la comparaison se fait avec IS NULL.','SELECT typeof(NULL);'),
('INTEGER','Classe de stockage pour les entiers signés jusqu’à 64 bits. Les grands entiers sont affichés en lecture seule dans la grille si JavaScript ne peut les représenter exactement.','SELECT typeof(42), 42;'),
('REAL','Nombre approximatif en virgule flottante. N’utilisez pas REAL comme garantie de précision décimale exacte pour des montants financiers.','SELECT typeof(12.5), 12.5;'),
('TEXT','Texte stocké en Unicode. Les noms VARCHAR ou CHAR déclarent en pratique une affinité TEXT ; leur taille annoncée n’est pas automatiquement appliquée.','SELECT typeof(\'Bonjour\'), \'Bonjour\';'),
('BLOB','Données binaires arbitraires ; dans Studio les valeurs binaires sont affichées en lecture seule dans la grille.','SELECT typeof(X\'CAFE\'), X\'CAFE\';'),
('Affinités','Les types déclarés déterminent une affinité plutôt qu’un type strict ordinaire. SQLite peut convertir les valeurs au stockage selon les règles d’affinité.','CREATE TABLE exemples (id INTEGER PRIMARY KEY, valeur NUMERIC);'),
('BOOLEAN','SQLite n’a pas de classe de stockage booléenne distincte : TRUE et FALSE correspondent normalement à 1 et 0.','SELECT TRUE, FALSE, typeof(TRUE);'),
('Dates et heures','SQLite n’a pas de classe de stockage date distincte. Les dates peuvent être stockées en texte ISO 8601, nombre de jours juliens ou secondes Unix selon la convention choisie.','SELECT date(\'2025-01-31\'), time(\'12:30:00\');'),
('STRICT','Une table STRICT vérifie davantage les types et exige une version de SQLite compatible. Les types déclarés autorisés sont limités.','CREATE TABLE strict_exemple (id INTEGER PRIMARY KEY, nom TEXT NOT NULL) STRICT;'),
('INTEGER PRIMARY KEY','Dans une table ordinaire, INTEGER PRIMARY KEY correspond généralement à l’alias du rowid ; les détails diffèrent pour les tables WITHOUT ROWID.','CREATE TABLE notes (id INTEGER PRIMARY KEY, texte TEXT);'),
('AUTOINCREMENT','Empêche la réutilisation automatique de certains rowid déjà attribués au prix d’un surcoût. Il n’est pas nécessaire pour la plupart des clés générées.','CREATE TABLE messages (id INTEGER PRIMARY KEY AUTOINCREMENT, texte TEXT);'),
])
add('SQLite','Fonctions intégrées',[
('typeof','Indique la classe de stockage effective d’une valeur : null, integer, real, text ou blob.','SELECT typeof(12), typeof(\'12\');'),
('ifnull','Retourne le second argument si le premier est NULL ; équivalent à COALESCE avec deux arguments.','SELECT ifnull(NULL, \'inconnu\');'),
('coalesce','Retourne le premier argument non NULL parmi deux ou plus.','SELECT coalesce(NULL, NULL, \'secours\');'),
('length','Compte les caractères d’un texte avant un caractère NUL ou les octets d’un BLOB.','SELECT length(\'bonjour\'), length(X\'CAFE\');'),
('substr','Extrait une portion de texte ou de BLOB ; positions et longueurs négatives suivent les règles propres à SQLite.','SELECT substr(\'bonjour\', 2, 3);'),
('instr','Donne la position, à partir de 1, de la première occurrence ; retourne 0 si elle est absente.','SELECT instr(\'banane\', \'na\');'),
('replace','Remplace toutes les occurrences d’un texte par un autre.','SELECT replace(\'a-b-c\', \'-\', \':\');'),
('trim, ltrim, rtrim','Retirent les caractères indiqués ou, par défaut, les espaces respectivement des deux côtés, à gauche ou à droite.','SELECT trim(\'  salut  \'), ltrim(\'  salut  \');'),
('printf','Formate une chaîne selon les formats pris en charge par SQLite ; ne l’utilisez pas pour construire du SQL avec des valeurs non fiables.','SELECT printf(\'article %d : %s\', 7, \'stylo\');'),
('hex et unhex','hex représente des octets en hexadécimal ; unhex est disponible dans les versions récentes et sa disponibilité doit être vérifiée.','SELECT hex(X\'CAFE\');'),
('random','Produit un entier pseudo-aléatoire ; ce n’est pas une interface de génération de secrets pour vos applications.','SELECT random();'),
('date','Produit une date au format texte AAAA-MM-JJ à partir d’une valeur temporelle et de modificateurs.','SELECT date(\'2025-01-31\', \'+1 day\');'),
('time','Produit une heure au format texte, avec modificateurs optionnels.','SELECT time(\'12:30:00\', \'+15 minutes\');'),
('datetime','Produit une date et une heure au format texte ; UTC et heure locale doivent être traités explicitement.','SELECT datetime(\'2025-01-01 10:00:00\', \'+1 hour\');'),
('strftime','Formate une date à l’aide de codes spécifiques à SQLite. Certains codes dépendent de la version.','SELECT strftime(\'%Y-%m\', \'2025-03-12\');'),
('julianday','Convertit une valeur temporelle en nombre de jours juliens approximatif.','SELECT julianday(\'2025-01-01\');'),
('unixepoch','Retourne un nombre de secondes Unix pour une date ; disponible dans les versions récentes de SQLite.','SELECT unixepoch(\'2025-01-01\');'),
('group_concat','Concatène des valeurs non NULL d’un groupe, avec un séparateur facultatif. L’ordre n’est pas garanti sans le spécifier explicitement avec une syntaxe compatible.','SELECT group_concat(nom, \', \') FROM clients;'),
('json_valid','Vérifie si un texte constitue un JSON accepté par la version et les options de SQLite ; l’extension JSON doit être disponible.','SELECT json_valid(\'{"nom":"Alice"}\');'),
('json_extract','Extrait une valeur selon un chemin JSON SQLite ; la disponibilité et les types de retour dépendent de la version.','SELECT json_extract(\'{"nom":"Alice"}\', \'$.nom\');'),
('json_array','Construit un tableau JSON à partir d’arguments SQL lorsque les fonctions JSON sont disponibles.','SELECT json_array(1, \'deux\', NULL);'),
])
add('SQLite','Commandes et maintenance',[
('sqlite_master / sqlite_schema','Décrit les objets du schéma. Les noms internes et détails peuvent varier avec la version de SQLite.','SELECT name, type FROM sqlite_schema WHERE type IN (\'table\', \'view\');'),
('PRAGMA table_info','Retourne les informations de base sur les colonnes d’une table ; table_xinfo inclut aussi les colonnes cachées ou générées.','PRAGMA table_info(clients);'),
('PRAGMA foreign_keys','Active ou désactive le contrôle des clés étrangères pour une connexion ; l’activation ne doit pas être supposée et ne change pas au milieu d’une transaction.','PRAGMA foreign_keys;'),
('PRAGMA integrity_check','Vérifie la cohérence de la base et des index ; la commande peut être coûteuse sur une base volumineuse.','PRAGMA integrity_check;'),
('PRAGMA journal_mode','Consulte ou modifie le mode de journal ; WAL utilise des fichiers auxiliaires et modifie les contraintes de copie et concurrence.','PRAGMA journal_mode;'),
('Index','Un index améliore certaines recherches mais ralentit les écritures et occupe de la place ; examinez son intérêt selon les requêtes.','CREATE INDEX idx_clients_ville ON clients(ville);'),
('EXPLAIN QUERY PLAN','Montre comment SQLite envisage de lire une requête. Son format de sortie est destiné au diagnostic et peut changer.','EXPLAIN QUERY PLAN SELECT nom FROM clients WHERE ville = \'Paris\';'),
('Sauvegarde cohérente','Utilisez l’API de sauvegarde SQLite ou un outil qui la met en œuvre. Une copie brute d’un fichier actif, notamment en WAL, peut être incomplète.','sqlite3 source.db ".backup sauvegarde.db"  # commande dans un terminal, pas dans l’éditeur SQL'),
('VACUUM','Reconstruit la base et peut récupérer de l’espace, mais demande du temps et de l’espace libre. Dans Studio, l’exécution peut échouer car une transaction est ouverte.','VACUUM;  -- à utiliser dans un client SQLite adapté, après sauvegarde'),
('Paramètres Python sqlite3','Les marqueurs ? lient séparément les valeurs SQL et évitent l’injection de valeurs. Les identifiants doivent être validés séparément.','cursor.execute("SELECT nom FROM clients WHERE id = ?", (1,))'),
])

intro('PostgreSQL','Utilité, histoire et spécificités',"PostgreSQL est un système relationnel serveur libre, utilisé pour les applications web, la géomatique, l’analyse et les données nécessitant des contraintes riches. Il propose notamment transactions, types avancés, index variés, extensions et concurrence multiversion.\n\nLe projet descend de POSTGRES, commencé à Berkeley en 1986. Le support SQL a conduit au nom PostgreSQL en 1996. Les versions évoluent régulièrement ; les commandes et extensions décrites ici ne sont pas toutes disponibles sur toutes les versions ou tous les hébergements.\n\nPascal Studio se connecte à une base PostgreSQL choisie par l’utilisateur. Le serveur, ses comptes, ses droits et ses sauvegardes restent administrés séparément. TLS est vérifié pour une connexion distante. Documentation officielle : https://www.postgresql.org/docs/")
add('PostgreSQL','Types · nombres et texte',[
('smallint','Entier signé sur 2 octets, de -32768 à 32767. Un dépassement provoque une erreur.','SELECT 12::smallint;'),
('integer','Entier signé sur 4 octets, couramment utilisé pour les compteurs et valeurs entières modérées.','SELECT 42::integer;'),
('bigint','Entier signé sur 8 octets. Les valeurs supérieures à la précision sûre de JavaScript ne sont pas éditables dans la grille Studio.','SELECT 9007199254740993::bigint;'),
('numeric et decimal','Nombre décimal exact avec précision et échelle optionnelles ; adapté aux montants, mais les calculs et arrondis doivent être conçus explicitement.','SELECT 12.34::numeric(10,2);'),
('real','Nombre approximatif en virgule flottante simple précision ; les décimales ne sont pas toujours représentées exactement.','SELECT 1.5::real;'),
('double precision','Nombre approximatif en virgule flottante double précision. Évitez une comparaison d’égalité stricte pour des calculs sensibles à l’arrondi.','SELECT 1.5::double precision;'),
('boolean','Type logique true, false ou NULL. Les booléens ne sont pas des entiers dans PostgreSQL.','SELECT TRUE::boolean, FALSE::boolean;'),
('text','Chaîne de longueur variable ; PostgreSQL ne nécessite pas de longueur maximale pour ce type.','SELECT \'bonjour\'::text;'),
('varchar(n)','Chaîne dont la longueur en caractères est limitée à n ; la conversion explicite vers ce type peut tronquer selon le contexte.','SELECT \'bonjour\'::varchar(20);'),
('char(n)','Chaîne de longueur fixe complétée par des espaces ; ses règles de comparaison diffèrent du type text.','SELECT \'A\'::char(3);'),
('bytea','Données binaires. Studio les affiche mais ne les rend pas modifiables dans la grille.','SELECT decode(\'cafe\', \'hex\')::bytea;'),
('uuid','Identifiant universel de 128 bits. Les fonctions de génération disponibles dépendent de la version et des extensions installées.','SELECT \'550e8400-e29b-41d4-a716-446655440000\'::uuid;'),
('serial et identity','serial est une notation historique basée sur une séquence ; GENERATED AS IDENTITY est la méthode standard moderne.','CREATE TABLE notes (id bigint GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY, texte text);'),
])
add('PostgreSQL','Types · dates, JSON et collections',[
('date','Date civile sans heure. Une date n’est pas un instant et ne transporte pas de fuseau horaire.','SELECT DATE \'2025-03-12\';'),
('time','Heure sans date ; time with time zone existe mais son usage est rarement adapté aux horaires civils avec changements de fuseau.','SELECT TIME \'14:30:00\';'),
('timestamp sans fuseau','Date et heure civiles sans information de fuseau ; il faut connaître la convention utilisée par l’application.','SELECT TIMESTAMP \'2025-03-12 14:30:00\';'),
('timestamp with time zone','Un timestamptz représente un instant ; PostgreSQL l’affiche dans le fuseau de la session et ne conserve pas le nom original du fuseau.','SELECT TIMESTAMPTZ \'2025-03-12 14:30:00+01\';'),
('interval','Durée ou intervalle pouvant contenir mois, jours et temps ; un mois n’a pas toujours la même durée.','SELECT INTERVAL \'2 days 3 hours\';'),
('json','Stocke le texte JSON et conserve notamment sa présentation d’entrée ; les opérations doivent être choisies selon ce type.','SELECT \'{"nom":"Alice"}\'::json;'),
('jsonb','Stocke une représentation binaire décomposée ; l’ordre des clés et les clés dupliquées ne sont pas conservés comme dans le texte d’origine.','SELECT \'{"nom":"Alice"}\'::jsonb;'),
('Tableaux ARRAY','Un tableau PostgreSQL contient plusieurs éléments d’un type ; les dimensions et indices ont leurs propres règles.','SELECT ARRAY[10, 20, 30]::integer[];'),
('Types énumérés','Un enum définit un ensemble ordonné de valeurs. Sa modification et sa suppression nécessitent de tenir compte des dépendances.','CREATE TYPE etat AS ENUM (\'nouveau\', \'termine\');'),
('Types réseau','inet et cidr représentent des adresses ou réseaux IP avec des opérateurs spécialisés ; vérifiez les droits et besoins avant leur usage.','SELECT \'192.0.2.10/24\'::inet;'),
('Plages range','Les types de plage représentent des intervalles avec bornes ouvertes ou fermées et opérateurs adaptés.','SELECT int4range(1, 5, \'[)\');'),
])
add('PostgreSQL','Fonctions et opérateurs',[
(':: et CAST',':: est l’opérateur PostgreSQL de conversion ; CAST est plus portable. Une conversion invalide déclenche normalement une erreur.','SELECT \'42\'::integer;'),
('|| concaténation','Concatène deux chaînes ; NULL peut rendre le résultat NULL. Utilisez concat pour un comportement différent avec NULL.','SELECT \'Bonjour\' || \' \' || \'Alice\';'),
('concat','Concatène ses arguments textuels et ignore les arguments NULL ; son comportement diffère de ||.','SELECT concat(\'A\', NULL, \'B\');'),
('string_agg','Concatène les valeurs non NULL d’un groupe avec un séparateur ; ORDER BY dans l’agrégat permet de fixer l’ordre.','SELECT string_agg(nom, \', \' ORDER BY nom) FROM clients;'),
('length et char_length','Comptent les caractères d’une chaîne, pas nécessairement les octets ; octet_length compte les octets.','SELECT char_length(\'été\'), octet_length(\'été\');'),
('substring','Extrait une partie de texte ; les positions commencent à 1.','SELECT substring(\'bonjour\' FROM 1 FOR 3);'),
('position','Cherche une sous-chaîne et retourne sa position à partir de 1, ou 0 si elle est absente.','SELECT position(\'na\' IN \'banane\');'),
('split_part','Extrait le champ d’une chaîne séparée par un délimiteur ; les numéros de champ commencent à 1.','SELECT split_part(\'un,deux,trois\', \',\', 2);'),
('regexp_replace','Remplace une correspondance d’expression régulière ; le drapeau g demande le remplacement global.','SELECT regexp_replace(\'a1b2\', \'[0-9]\', \'X\', \'g\');'),
('ILIKE','Compare à un motif sans tenir compte de la casse selon la collation ; ILIKE est spécifique à PostgreSQL.','SELECT nom FROM clients WHERE nom ILIKE \'al%\';'),
('IS DISTINCT FROM','Compare deux valeurs en traitant NULL comme comparable ; utile pour détecter un changement incluant les valeurs absentes.','SELECT NULL IS DISTINCT FROM 1;'),
('now et current_timestamp','Retournent l’heure du début de la transaction courante ; ce n’est pas nécessairement l’heure exacte à chaque ligne.','SELECT now(), current_timestamp;'),
('clock_timestamp','Retourne l’heure réelle au moment de l’appel, qui peut évoluer au cours d’une même requête.','SELECT clock_timestamp();'),
('date_trunc','Tronque une date ou un timestamp à une précision donnée ; le fuseau peut influencer le résultat.','SELECT date_trunc(\'month\', TIMESTAMP \'2025-03-12 14:30:00\');'),
('extract','Extrait une composante d’une date, heure ou intervalle ; les champs disponibles dépendent du type.','SELECT EXTRACT(YEAR FROM DATE \'2025-03-12\');'),
('to_char','Formate une date ou un nombre suivant un motif PostgreSQL ; ne confondez pas le texte affiché et la valeur typée.','SELECT to_char(DATE \'2025-03-12\', \'YYYY-MM-DD\');'),
('generate_series','Produit une série de nombres ou dates. Une plage trop grande peut consommer beaucoup de ressources.','SELECT generate_series(1, 5);'),
('array_length','Retourne la longueur d’une dimension d’un tableau, ou NULL pour une dimension absente.','SELECT array_length(ARRAY[10,20,30], 1);'),
('unnest','Déplie les éléments d’un tableau en lignes.','SELECT unnest(ARRAY[10,20,30]);'),
('Opérateur JSON ->','Extrait un élément ou une clé JSON en conservant le type JSON ou JSONB.','SELECT \'{"nom":"Alice"}\'::jsonb -> \'nom\';'),
('Opérateur JSON ->>','Extrait une clé ou un élément JSON sous forme de texte SQL.','SELECT \'{"nom":"Alice"}\'::jsonb ->> \'nom\';'),
('jsonb_build_object','Construit un objet JSONB à partir de paires clé-valeur.','SELECT jsonb_build_object(\'nom\', \'Alice\', \'age\', 30);'),
('jsonb_array_elements','Déplie les éléments d’un tableau JSONB en lignes ; l’argument doit être un tableau JSON.','SELECT jsonb_array_elements(\'[1,2,3]\'::jsonb);'),
('ON CONFLICT','Permet de gérer une violation de contrainte unique à l’insertion. Choisissez explicitement la cible et les colonnes à modifier.','INSERT INTO clients (id, nom) VALUES (1, \'Alice\') ON CONFLICT (id) DO UPDATE SET nom = EXCLUDED.nom;'),
])
add('PostgreSQL','Administration et sécurité',[
('Schéma public','Un schéma regroupe des objets d’une base. Une référence qualifiée évite l’ambiguïté du search_path.','SELECT * FROM public.clients LIMIT 10;'),
('information_schema','Expose des vues standardisées de métadonnées accessibles selon les droits de l’utilisateur.','SELECT table_schema, table_name FROM information_schema.tables WHERE table_schema = \'public\';'),
('current_database et current_user','Indiquent la base et l’utilisateur effectif de la session.','SELECT current_database(), current_user;'),
('EXPLAIN','Affiche le plan prévu pour une requête sans exécuter sa partie principale ; des fonctions utilisées pendant la planification peuvent néanmoins avoir des effets.','EXPLAIN SELECT * FROM clients WHERE id = 1;'),
('EXPLAIN ANALYZE','Exécute réellement la requête pour mesurer son plan ; une instruction de modification modifie donc réellement les données, sous réserve de transaction.','EXPLAIN ANALYZE SELECT * FROM clients WHERE id = 1;'),
('GRANT et REVOKE','Attribuent ou retirent des privilèges. Utilisez un rôle dédié et limitez les droits à ce qui est nécessaire.','GRANT SELECT ON TABLE public.clients TO lecteur;'),
('Sauvegarde pg_dump','pg_dump crée une sauvegarde logique cohérente d’une base accessible ; la restauration et les rôles doivent être planifiés et testés.','pg_dump --format=custom --file=sauvegarde.dump nom_base  # terminal, pas éditeur SQL'),
('Restaurer avec pg_restore','pg_restore restaure une archive créée au format approprié ; la cible et les options peuvent entraîner des modifications destructrices.','pg_restore --dbname=base_test sauvegarde.dump  # terminal, sur une base de test'),
('Paramètres du pilote','La liaison des valeurs dépend du pilote. Avec pg8000 DB-API, le marqueur %s lie une valeur ; ne concaténez pas d’entrée non fiable.','cursor.execute("SELECT nom FROM clients WHERE id = %s", (1,))'),
('Extensions','Les extensions ajoutent des fonctions et types, mais ne sont pas nécessairement installées ni autorisées sur un hébergement.','SELECT name, installed_version FROM pg_available_extensions WHERE name = \'pgcrypto\';'),
])

intro('MySQL / MariaDB','Utilité, histoire et spécificités',"MySQL et MariaDB sont des systèmes relationnels serveur largement utilisés pour les sites web, applications métier et services. Ils prennent en charge les transactions avec des moteurs de stockage adaptés, les index et les connexions à distance, mais leurs capacités exactes dépendent de la version et de la configuration.\n\nMySQL apparaît en 1995 ; MariaDB est issu du code de MySQL à partir de 2009. Ces projets ont depuis divergé : syntaxe, JSON, privilèges, fonctions et modes de réplication ne sont pas toujours interchangeables. Vérifiez la documentation propre au serveur utilisé.\n\nPascal Studio utilise un pilote compatible MySQL/MariaDB. Il ne crée pas automatiquement un serveur ou un compte. Les connexions distantes exigent TLS vérifié. Les DDL peuvent valider implicitement une transaction même lorsque Studio tente un rollback. Documentation : https://dev.mysql.com/doc/ et https://mariadb.com/kb/")
add('MySQL / MariaDB','Types · nombres et texte',[
('TINYINT','Petit entier sur un octet, signé ou UNSIGNED ; les bornes diffèrent selon la présence de UNSIGNED.','SELECT CAST(12 AS SIGNED);'),
('SMALLINT, MEDIUMINT, INT','Entiers de tailles différentes. Le choix de l’intervalle signé ou non signé influence les valeurs autorisées.','CREATE TABLE exemples (id INT PRIMARY KEY, quantite SMALLINT UNSIGNED);'),
('BIGINT','Entier sur 8 octets, signé ou non signé ; les valeurs hors précision sûre JavaScript sont en lecture seule dans la grille.','SELECT CAST(9007199254740993 AS UNSIGNED);'),
('DECIMAL(p,s)','Décimal exact adapté notamment aux montants. p est la précision totale et s le nombre de chiffres après la virgule.','SELECT CAST(12.34 AS DECIMAL(10,2));'),
('FLOAT et DOUBLE','Nombres approximatifs en virgule flottante ; leur représentation n’est pas décimale exacte.','SELECT CAST(1.5 AS DOUBLE);'),
('BOOLEAN et BOOL','Synonymes de TINYINT(1) dans MySQL/MariaDB ; selon le pilote, une valeur peut être présentée comme entier plutôt que booléen.','CREATE TABLE drapeaux (id INT PRIMARY KEY, actif BOOLEAN NOT NULL);'),
('CHAR(n)','Chaîne de longueur fixe ; l’utilisation des espaces et comparaisons dépend de la configuration et du type.','CREATE TABLE codes (id INT PRIMARY KEY, code CHAR(2));'),
('VARCHAR(n)','Chaîne de longueur variable, avec limite de caractères et limites globales de ligne dépendant du jeu de caractères et du moteur.','CREATE TABLE villes (id INT PRIMARY KEY, nom VARCHAR(100));'),
('TEXT','Famille de types texte de différentes capacités. Vérifiez les limites de taille, d’index et de valeur par défaut selon la version.','CREATE TABLE notes (id INT PRIMARY KEY, texte TEXT);'),
('BINARY et VARBINARY','Données binaires de longueur fixe ou variable, distinctes des chaînes interprétées avec un jeu de caractères.','SELECT CAST(\'abc\' AS BINARY);'),
('BLOB','Famille de types pour données binaires ; Studio les affiche en lecture seule dans la grille.','CREATE TABLE fichiers (id INT PRIMARY KEY, contenu BLOB);'),
('ENUM','Valeur choisie dans une liste déclarée, avec des règles propres de stockage et de tri ; portabilité limitée.','CREATE TABLE taches (id INT PRIMARY KEY, etat ENUM(\'nouveau\',\'termine\'));'),
('AUTO_INCREMENT','Génère généralement une valeur entière pour une colonne indexée lorsque celle-ci est omise ; les valeurs peuvent présenter des trous.','CREATE TABLE messages (id BIGINT AUTO_INCREMENT PRIMARY KEY, texte TEXT);'),
])
add('MySQL / MariaDB','Types · dates et JSON',[
('DATE','Date civile au format AAAA-MM-JJ. Le traitement des dates invalides ou nulles dépend du mode SQL et de la version.','SELECT CAST(\'2025-03-12\' AS DATE);'),
('TIME','Heure ou durée selon le contexte MySQL/MariaDB ; la plage de TIME peut dépasser celle d’une heure du jour.','SELECT CAST(\'14:30:00\' AS TIME);'),
('DATETIME','Date et heure sans conversion automatique de fuseau comparable à TIMESTAMP. Définissez une convention explicite dans l’application.','SELECT CAST(\'2025-03-12 14:30:00\' AS DATETIME);'),
('TIMESTAMP','Type temporel dont les conversions impliquent le fuseau de la session ; la plage dépend de la version.','SELECT CURRENT_TIMESTAMP;'),
('YEAR','Stocke une année dans la plage acceptée par la version du serveur ; ne remplace pas toujours une date complète.','CREATE TABLE annees (id INT PRIMARY KEY, annee YEAR);'),
('JSON','MySQL possède un type JSON natif ; MariaDB utilise une approche différente, notamment un alias de texte validé selon les versions. Les performances et fonctions peuvent différer.','SELECT JSON_VALID(\'{"nom":"Alice"}\');'),
])
add('MySQL / MariaDB','Fonctions et opérateurs',[
('CONCAT','Concatène les arguments convertis en texte. Dans MySQL, un argument NULL rend le résultat NULL ; vérifiez les modes MariaDB.','SELECT CONCAT(\'Bonjour\', \' \', \'Alice\');'),
('CONCAT_WS','Concatène avec un séparateur et ignore les arguments NULL après celui-ci ; un séparateur NULL donne NULL.','SELECT CONCAT_WS(\', \', \'Paris\', NULL, \'Lyon\');'),
('CHAR_LENGTH','Compte les caractères, contrairement à LENGTH qui compte les octets.','SELECT CHAR_LENGTH(\'été\'), LENGTH(\'été\');'),
('SUBSTRING','Extrait une partie de chaîne ; la position commence à 1 et une position négative a une signification propre au moteur.','SELECT SUBSTRING(\'bonjour\', 1, 3);'),
('LOCATE','Cherche une sous-chaîne et retourne sa position à partir de 1, ou 0 si elle est absente.','SELECT LOCATE(\'na\', \'banane\');'),
('REPLACE','Remplace les occurrences d’une sous-chaîne ; les détails de comparaison dépendent du moteur.','SELECT REPLACE(\'a-b-c\', \'-\', \':\');'),
('IFNULL','Retourne la deuxième valeur si la première est NULL ; COALESCE accepte plusieurs arguments.','SELECT IFNULL(NULL, \'inconnu\');'),
('IF','Choisit une des deux valeurs selon une condition ; CASE est plus portable entre moteurs SQL.','SELECT IF(3 > 2, \'oui\', \'non\');'),
('GROUP_CONCAT','Concatène les valeurs d’un groupe ; la longueur maximale et les options dépendent du serveur et de ses réglages.','SELECT GROUP_CONCAT(nom ORDER BY nom SEPARATOR \', \') FROM clients;'),
('NOW','Retourne la date et l’heure courantes selon le fuseau et les règles de la session.','SELECT NOW();'),
('CURDATE et CURTIME','Retournent respectivement la date et l’heure courantes dans le contexte de la session.','SELECT CURDATE(), CURTIME();'),
('DATE_FORMAT','Formate une date ou heure avec les codes propres à MySQL/MariaDB.','SELECT DATE_FORMAT(\'2025-03-12\', \'%Y-%m\');'),
('DATE_ADD','Ajoute un intervalle à une date ; les règles des mois et les types de résultat doivent être vérifiés.','SELECT DATE_ADD(\'2025-03-12\', INTERVAL 7 DAY);'),
('DATEDIFF','Retourne la différence en jours entre deux dates ; les composantes horaires ne sont pas prises en compte.','SELECT DATEDIFF(\'2025-03-15\', \'2025-03-12\');'),
('JSON_VALID','Teste si un texte est un JSON valide selon le serveur ; les détails diffèrent de PostgreSQL et SQLite.','SELECT JSON_VALID(\'{"nom":"Alice"}\');'),
('JSON_EXTRACT','Extrait une valeur à partir d’un chemin JSON ; le résultat est de type ou représentation JSON selon le serveur.','SELECT JSON_EXTRACT(\'{"nom":"Alice"}\', \'$.nom\');'),
('JSON_UNQUOTE','Retire les guillemets d’une chaîne JSON extraite, selon les règles du serveur.','SELECT JSON_UNQUOTE(JSON_EXTRACT(\'{"nom":"Alice"}\', \'$.nom\'));'),
('JSON_OBJECT','Construit un objet JSON à partir de paires clé-valeur.','SELECT JSON_OBJECT(\'nom\', \'Alice\', \'age\', 30);'),
('ON DUPLICATE KEY UPDATE','En cas de conflit sur une clé unique, met à jour la ligne existante. La syntaxe recommandée et les détails évoluent entre versions MySQL et MariaDB.','INSERT INTO clients (id, nom) VALUES (1, \'Alice\') ON DUPLICATE KEY UPDATE nom = \'Alice\';'),
])
add('MySQL / MariaDB','Administration et sécurité',[
('Base courante','DATABASE() indique la base courante ; un schéma MySQL est généralement synonyme de base de données.','SELECT DATABASE(), CURRENT_USER();'),
('SHOW TABLES','Liste les tables et vues visibles de la base courante selon les droits de l’utilisateur.','SHOW TABLES;'),
('DESCRIBE','Décrit les colonnes et certaines propriétés d’une table. SHOW CREATE TABLE expose la définition générée par le serveur.','DESCRIBE clients;'),
('information_schema','Contient des vues de métadonnées de bases, tables et colonnes accessibles selon les droits.','SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE();'),
('Moteur InnoDB','InnoDB prend en charge les transactions et clés étrangères. Le comportement transactionnel dépend du moteur de stockage réellement utilisé.','SHOW TABLE STATUS;'),
('EXPLAIN','Affiche le plan prévu d’une requête et aide à repérer parcours et index utilisés ; les formats varient selon les versions.','EXPLAIN SELECT * FROM clients WHERE id = 1;'),
('sql_mode','Le mode SQL influence notamment les conversions, le regroupement et les erreurs ; vérifiez-le avant de comparer des comportements.','SELECT @@sql_mode;'),
('Jeu de caractères et collation','utf8mb4 couvre les caractères Unicode sur MySQL/MariaDB ; la collation contrôle comparaisons et tri. Les noms de collations diffèrent selon versions.','SELECT @@character_set_connection, @@collation_connection;'),
('GRANT et REVOKE','Gèrent les privilèges. Accordez le minimum nécessaire à un compte spécifique et ne publiez pas le serveur sans protection.','GRANT SELECT ON ma_base.* TO \'lecteur\'@\'localhost\';'),
('DDL et validation implicite','De nombreuses commandes DDL MySQL/MariaDB valident implicitement la transaction. Le bouton de test avec rollback ne garantit donc pas leur annulation.','CREATE TABLE exemple_ddl (id INT PRIMARY KEY);'),
('Sauvegarde logique','mysqldump ou mariadb-dump peut créer une sauvegarde logique ; choisissez des options adaptées au moteur et testez la restauration.','mariadb-dump --single-transaction -u utilisateur -p ma_base > sauvegarde.sql  # terminal'),
('Restauration logique','Une restauration SQL peut écraser ou modifier des données. Testez d’abord sur une base séparée et ne mettez pas le mot de passe dans la ligne de commande.','mariadb -u utilisateur -p base_test < sauvegarde.sql  # terminal'),
('Paramètres PyMySQL','Le marqueur %s est remplacé par une valeur liée par le pilote ; ne composez pas les valeurs avec des concaténations SQL.','cursor.execute("SELECT nom FROM clients WHERE id = %s", (1,))'),
])

intro('CSV / TSV','Utilité, histoire et spécificités',"CSV et TSV servent à échanger des données tabulaires entre programmes, tableurs et bases. Une ligne représente généralement un enregistrement et chaque champ correspond à une colonne. CSV utilise souvent une virgule ou un point-virgule ; TSV utilise une tabulation. Ces formats ne décrivent pas de façon universelle les types, contraintes ou relations.\n\nLes fichiers à valeurs séparées existent sous de nombreuses variantes historiques ; la RFC 4180 a décrit une forme courante de CSV en 2005, sans supprimer toutes les différences entre logiciels. Le séparateur, les guillemets, l’encodage et les fins de ligne doivent être convenus avec le destinataire.\n\nDans Pascal Studio, ouvrez un CSV ou TSV UTF-8 de 5 Mo maximum. L’enregistrement réécrit le contenu : présentation, BOM ou fins de ligne peuvent changer. Faites une copie avant conversion et méfiez-vous des formules exécutées par des tableurs.")
add('CSV / TSV','Structure et syntaxe',[
('Lignes et colonnes','Chaque ligne contient des champs séparés. Les fichiers réels peuvent avoir des lignes de longueur différente ; vérifiez l’import et les colonnes attendues.','nom,ville\nAlice,Paris\nBob,Lyon'),
('En-tête','La première ligne peut nommer les colonnes mais ce n’est pas obligatoire. Dans Studio, l’option d’en-tête change la présentation de la grille.','nom;ville\nAlice;Paris'),
('Séparateur virgule','La virgule est fréquente dans les exports CSV. Des guillemets entourent un champ contenant lui-même une virgule.','nom,adresse\nAlice,"12 rue A, Paris"'),
('Séparateur point-virgule','Le point-virgule est courant dans certains environnements francophones. Il peut être choisi et relu dans l’interface si la détection est incorrecte.','nom;ville\nAlice;Paris'),
('Tabulation TSV','Un TSV utilise une tabulation entre champs. Dans l’exemple, la flèche représente une vraie tabulation et ne doit pas être écrite littéralement.','nom\tville\nAlice\tParis'),
('Guillemets','Un champ peut être entouré de guillemets doubles pour contenir un séparateur ou une fin de ligne ; les règles exactes dépendent du dialecte.','nom,commentaire\nAlice,"Bonjour, tout le monde"'),
('Guillemet dans un champ','Dans le CSV de style RFC 4180, un guillemet double interne est doublé.','nom,commentaire\nAlice,"Elle dit ""bonjour"""'),
('Champ multiligne','Un champ entre guillemets peut contenir un saut de ligne ; tous les outils ne le traitent pas de façon identique.','nom,commentaire\nAlice,"Première ligne\nDeuxième ligne"'),
('Champ vide et NULL','Un champ vide est du texte vide dans la grille ; CSV ne définit pas universellement NULL. Convenez d’une convention avant import en base.','nom,ville\nAlice,\nBob,Lyon'),
('Encodage UTF-8 et BOM','Studio lit les fichiers texte en UTF-8 et peut accepter un BOM UTF-8 ; la réécriture ne garantit pas de conserver ce marqueur.','nom,ville\nÉlodie,Orléans'),
('Nombres et dates','CSV ne porte pas intrinsèquement les types : 0012, 1,25 et 2025-03-12 sont des textes tant qu’un importeur ne les convertit pas.','code;prix;date\n0012;1,25;2025-03-12'),
('Fins de ligne','LF et CRLF sont deux fins de ligne fréquentes. La réécriture par un éditeur ou un importeur peut modifier cette présentation.','nom,ville\r\nAlice,Paris\r\n'),
])
add('CSV / TSV','Manipulation et sécurité',[
('Modifier le séparateur','Choisissez parmi les séparateurs proposés, puis relisez le fichier. Relire remplace la grille courante ; sauvegardez d’abord vos modifications.','Séparateur → point-virgule → Relire'),
('Ajouter une ligne','Le bouton Ligne ajoute un enregistrement. Pensez à renseigner toutes les colonnes attendues puis à enregistrer.','＋ Ligne → saisir les cellules → Enregistrer'),
('Ajouter une colonne','Le bouton Colonne ajoute une colonne dans la grille et dans les lignes existantes ; précisez l’en-tête si la première ligne sert de titre.','＋ Colonne → nommer la colonne → Enregistrer'),
('Supprimer une ligne','La croix retire une ligne de la grille ; tant que le fichier n’est pas enregistré, cette modification reste en attente.','× à gauche de la ligne → Enregistrer → confirmer'),
('Formules de tableur','Un tableur peut interpréter une cellule débutant par =, +, - ou @ comme une formule. Vérifiez les données non fiables et les règles d’import de votre tableur.','nom,commentaire\nAlice,"=1+1"  # à traiter comme texte dans le tableur'),
('Fichiers volumineux','Studio limite l’ouverture des fichiers CSV à 5 Mo et affiche les lignes par pages. Un outil spécialisé convient mieux aux gros volumes.','Données → fichier CSV → page suivante ›'),
('Python : lecture csv','Le module csv de Python gère correctement guillemets et séparateurs si le dialecte est configuré ; newline vide évite certaines conversions parasites.','import csv\nwith open("clients.csv", encoding="utf-8", newline="") as f:\n    for ligne in csv.DictReader(f, delimiter=";"):\n        print(ligne["nom"])'),
('Python : écriture csv','csv.writer applique les règles de citation du dialecte choisi. L’écriture en mode w remplace le fichier : sauvegardez si nécessaire.','import csv\nwith open("sortie.csv", "w", encoding="utf-8", newline="") as f:\n    w = csv.writer(f, delimiter=";")\n    w.writerow(["nom", "ville"])\n    w.writerow(["Alice", "Paris"])'),
('Import en base','Un import doit préciser séparateur, encodage, en-tête et types. Préférez une table de travail et validez avant de remplacer les données réelles.','CSV UTF-8 → table de travail → vérifier les colonnes → transaction d’import'),
])

intro('JSON','Utilité, histoire et spécificités',"JSON est un format texte d’échange utilisé par les API, les fichiers de configuration et certaines colonnes de bases de données. Il représente des objets, tableaux, chaînes, nombres, booléens et null ; il ne définit ni schéma obligatoire ni référence entre objets.\n\nPopularisé au début des années 2000 par Douglas Crockford, JSON découle de la notation des objets JavaScript tout en étant indépendant des langages. La RFC 8259 décrit le format moderne. Les implémentations peuvent toutefois différer sur la précision des nombres et le traitement des noms de propriétés dupliqués.\n\nStudio accepte le JSON UTF-8 jusqu’à 5 Mo. La vue texte conserve les grands nombres sous forme de texte ; la vue tableau nécessite une liste d’objets et refuse les nombres dont la précision serait perdue. Une transformation peut reformater le document et supprimer des clés dupliquées.")
add('JSON','Types et syntaxe',[
('Objet','Un objet contient des paires nom-valeur ; les noms sont des chaînes entourées de guillemets doubles. Les clés dupliquées posent des problèmes d’interopérabilité.','{"nom": "Alice", "age": 30}'),
('Tableau','Un tableau ordonné contient zéro ou plusieurs valeurs JSON de types éventuellement différents.','["Paris", "Lyon", "Nantes"]'),
('Chaîne','Une chaîne est délimitée par des guillemets doubles ; les caractères de contrôle et guillemets internes doivent être échappés.','{"message": "Elle dit \\"bonjour\\""}'),
('Échappements','JSON définit notamment \\n, \\t, \\r, \\\\, \\" et \\u suivi de quatre chiffres hexadécimaux. Un antislash littéral doit être échappé.','{"texte": "ligne 1\\nligne 2", "symbole": "\\u00e9"}'),
('Nombre','Un nombre JSON peut comporter signe, fraction et exposant mais pas de zéro initial superflu, NaN ou Infinity. Les limites numériques dépendent du lecteur.','{"entier": 42, "decimal": 12.5, "scientifique": 1.2e3}'),
('Booléens','true et false sont écrits en minuscules et ne doivent pas être mis entre guillemets pour être des booléens.','{"actif": true, "archive": false}'),
('null','null indique une valeur nulle ; ce n’est ni une chaîne vide ni une propriété absente.','{"telephone": null}'),
('Objets imbriqués','Une valeur d’objet peut elle-même être un objet ou tableau, ce qui permet de structurer des données hiérarchiques.','{"nom": "Alice", "adresse": {"ville": "Paris"}}'),
('Tableau d’objets','Cette forme convient à la vue tableau de Studio si les valeurs numériques sont représentables sans perte.','[{"nom": "Alice", "age": 30}, {"nom": "Bob", "age": 28}]'),
('Propriété absente','Une propriété absente n’est pas équivalente à une propriété présente avec null. Dans la grille, une cellule vide signifie propriété absente.','[{"nom": "Alice"}, {"nom": "Bob", "ville": null}]'),
('Commentaires interdits','JSON standard n’accepte pas de commentaires // ou /* */ ni de virgule finale. Certains formats apparentés comme JSONC ont d’autres règles.','{"nom": "Alice", "age": 30}'),
('Clés dupliquées','Deux propriétés de même nom dans un objet ne sont pas interprétées de manière uniforme. Une transformation en objet JavaScript peut n’en garder qu’une.','{"nom": "premier", "nom": "second"}'),
('Précision numérique','Un entier trop grand ou une décimale non représentable peut être arrondi en JavaScript. Studio refuse alors le passage en vue tableau ; conservez la vue texte.','{"identifiant": 9007199254740993}'),
])
add('JSON','Manipulation et bibliothèques',[
('Vue texte','La vue texte convient à tout document JSON valide et à la préservation des grands nombres. Vérifiez la syntaxe avant enregistrement.','{"config": {"volume": 12}, "actif": true}'),
('Formater','Formater réécrit l’indentation et peut supprimer des clés dupliquées ; Studio vérifie aussi les nombres avant transformation.','Texte JSON → Formater le JSON → confirmer'),
('Vue tableau','La vue tableau accepte une liste d’objets ; chaque colonne correspond à une propriété. Elle est limitée à 5 000 objets et 200 colonnes.','[{"nom": "Alice", "score": 12}, {"nom": "Bob", "score": 7}]'),
('Modifier une cellule','Une cellule non vide contient une valeur JSON complète, par exemple une chaîne avec guillemets ou un nombre sans guillemets. Une valeur invalide bloque l’enregistrement.','"Alice"\n12\ntrue\nnull\n[1, 2]'),
('Ajouter un objet','Ajoutez un objet dans la vue tableau, renseignez ses valeurs puis enregistrez. Une cellule vide laisse la propriété absente.','＋ Objet → saisir les valeurs → Enregistrer'),
('Ajouter une propriété','Ajoutez une colonne nommée puis saisissez une valeur JSON pour les objets concernés. Une cellule non renseignée ne crée pas la propriété.','＋ Propriété → ville → "Paris"'),
('JSON.parse JavaScript','Convertit du texte JSON valide en valeur JavaScript ; les nombres sont convertis en Number et peuvent perdre de la précision.','const objet = JSON.parse(\'{"nom":"Alice"}\');\nconsole.log(objet.nom);'),
('JSON.stringify JavaScript','Sérialise une valeur JavaScript en JSON. Certaines valeurs JavaScript ne sont pas représentables ; les grands entiers BigInt demandent un traitement particulier.','const texte = JSON.stringify({nom: "Alice"}, null, 2);\nconsole.log(texte);'),
('json.loads Python','Analyse un texte JSON en objet Python. Python conserve les entiers arbitrairement grands, mais les décimales sont normalement des flottants.','import json\nobjet = json.loads(\'{"nom":"Alice"}\')\nprint(objet["nom"])'),
('json.dumps Python','Convertit un objet Python en texte JSON. ensure_ascii=False conserve les caractères lisibles ; allow_nan=False refuse les nombres non standard.','import json\ntexte = json.dumps({"nom": "Élodie"}, ensure_ascii=False, allow_nan=False)\nprint(texte)'),
('Décimales exactes en Python','parse_float=Decimal permet de lire les décimales sans conversion initiale en flottant binaire. Une sérialisation adaptée est nécessaire ensuite.','import json\nfrom decimal import Decimal\nobjet = json.loads(\'{"prix": 0.1}\', parse_float=Decimal)'),
('JSON et bases SQL','PostgreSQL, MySQL/MariaDB et SQLite proposent des fonctions JSON différentes ; le type de stockage et les index doivent être choisis selon le moteur.','SELECT json_extract(\'{"nom":"Alice"}\', \'$.nom\');  -- SQLite'),
('Données non fiables','Validez la structure, la taille et les valeurs des données reçues ; analyser du JSON ne garantit pas qu’elles sont autorisées ou sans risque.','Vérifier le type → vérifier les champs → valider les limites → utiliser les données'),
('RFC 8259','La spécification JSON décrit la grammaire et les recommandations d’interopérabilité ; chaque logiciel peut imposer des limites supplémentaires.','https://www.rfc-editor.org/rfc/rfc8259'),
])

assert len({x['id'] for x in articles})==len(articles)
for a in articles:
 assert a['lang'] in languages and a['title'] and a['blocks']
 if not a['intro']:assert len(a['blocks'])==2 and a['blocks'][1]['code'],a
out=Path(__file__).with_name('database-help.js')
out.write_text('/* Référence données hors ligne ; source : database-help-source.py. */\nwindow.PS_DB_HELP='+json.dumps(dict(languages=languages,articles=articles),ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf8')
from collections import Counter
print('Fiches :',len(articles),Counter(a['lang'] for a in articles));print('Fichier :',out)
