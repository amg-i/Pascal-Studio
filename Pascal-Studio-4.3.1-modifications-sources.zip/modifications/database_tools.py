"""Local data files and DB-API connections for Pascal Studio's data panel.

Explicit writes, optimistic conflict checking and per-connection locking. Not a
sandbox: opening an untrusted database or running SQL may execute DB triggers
or server functions. Remote credentials remain only in the process memory.
"""
import base64, csv, datetime, decimal, hashlib, io, json, math, os, re, secrets, sqlite3, ssl, sys, tempfile, threading, time
from pathlib import Path
from urllib.parse import quote
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor-db'))
MAX_FILE=5_000_000
MAX_ROWS=5000
MAX_COLS=200
PAGE=100
# Un type de colonne est le seul morceau d'une instruction de structure qui ne
# puisse pas passer par q() : il est donc validé sur ce motif, et rien d'autre
# n'est recopié tel quel dans l'instruction.
TYPE_SQL=re.compile(r'^[A-Za-z][A-Za-z_ ]{0,24}(\(\s*\d{1,4}\s*(,\s*\d{1,4}\s*)?\))?$')
csv.field_size_limit(MAX_FILE)

class DataError(ValueError):pass

def scalar(v):
 return v is None or isinstance(v,(str,int,float,bool)) and (not isinstance(v,float) or math.isfinite(v))
def safe(v):
 if isinstance(v,int) and not isinstance(v,bool) and abs(v)>9_007_199_254_740_991:return {'$kind':'entier-long','texte':str(v)}
 if isinstance(v,str) and len(v)>10000:return {'$kind':'texte-long','taille':len(v),'apercu':v[:200],'sha256':hashlib.sha256(v.encode()).hexdigest()}
 if scalar(v):return v
 if isinstance(v,(bytes,bytearray,memoryview)):
  raw=bytes(v);return {'$kind':'binaire','taille':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
 if isinstance(v,decimal.Decimal):return {'$kind':'decimal','texte':str(v)}
 if isinstance(v,(datetime.date,datetime.time,datetime.datetime)):return {'$kind':type(v).__name__,'texte':v.isoformat()}
 if isinstance(v,(dict,list)):
  try:return {'$kind':'objet','texte':json.dumps(v,sort_keys=True,ensure_ascii=False,default=str)}
  except (ValueError,TypeError):pass
 return {'$kind':type(v).__name__,'texte':str(v)[:10000]}
def input_value(v):
 if not scalar(v):raise DataError('Seules les valeurs simples (texte, nombre, booléen ou NULL) peuvent être modifiées.')
 if isinstance(v,str) and len(v)>100_000:raise DataError('Valeur trop longue.')
 return v

def reject_constant(x):raise DataError('Valeur JSON non standard : '+x)

def digest(data):return hashlib.sha256(data).hexdigest()
def file_bytes(path):
 try:
  with path.open('rb') as f:data=f.read(MAX_FILE+1)
 except OSError as e:raise DataError('Lecture impossible : '+str(e))
 if len(data)>MAX_FILE:raise DataError('Fichier trop volumineux pour cet éditeur (limite 5 Mo).')
 return data

def write_checked(path,data,revision):
 """Atomic replacement with optimistic check; not a cross-process CAS."""
 old=file_bytes(path)
 if digest(old)!=revision:raise DataError('Le fichier a changé sur le disque. Rechargez-le avant de sauvegarder.')
 if len(data)>MAX_FILE:raise DataError('Fichier trop volumineux (limite 5 Mo).')
 mode=path.stat().st_mode & 0o777;name=None
 try:
  with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.pascal-data-',delete=False) as f:
   name=f.name;os.fchmod(f.fileno(),mode);f.write(data);f.flush();os.fsync(f.fileno())
  if digest(file_bytes(path))!=revision:raise DataError('Le fichier a changé sur le disque. Sauvegarde annulée.')
  os.replace(name,path);name=None
 finally:
  if name:
   try:os.unlink(name)
   except FileNotFoundError:pass
 return digest(data)

def detect_csv(text,ext):
 default='\t' if ext=='.tsv' else ','
 try:
  sniff=csv.Sniffer().sniff(text[:8192],delimiters=',;\t|')
  delimiter=sniff.delimiter;quoting=sniff.quoting;quotechar=sniff.quotechar or '"';doublequote=sniff.doublequote;escapechar=sniff.escapechar
 except csv.Error:delimiter=default;quoting=csv.QUOTE_MINIMAL;quotechar='"';doublequote=True;escapechar=None
 return dict(delimiter=delimiter,quoting=quoting,quotechar=quotechar,doublequote=doublequote,escapechar=escapechar,lineterminator='\r\n' if '\r\n' in text else '\n')

class Manager:
 def __init__(self):self.sessions={};self.lock=threading.RLock()
 def _add(self,s):
  self.reap()
  with self.lock:
   if len(self.sessions)>=12:raise DataError('Trop de sources ouvertes. Fermez-en une avant de continuer.')
   sid=secrets.token_urlsafe(24);s.update(id=sid,touched=time.monotonic(),lock=threading.RLock());self.sessions[sid]=s;return sid
 def _get(self,sid):
  if not isinstance(sid,str):raise DataError('Session invalide.')
  self.reap()
  with self.lock:
   s=self.sessions.get(sid)
   if not s:raise DataError('Session fermée ou expirée. Rouvrez la source.')
   s['touched']=time.monotonic();return s
 def reap(self):
  now=time.monotonic()
  with self.lock:ids=[k for k,v in self.sessions.items() if now-v['touched']>1800]
  for k in ids:self.close(k)
 def close(self,sid):
  with self.lock:s=self.sessions.pop(sid,None)
  if s:
   with s['lock']:
    conn=s.get('conn')
    if conn:
     try:conn.close()
     except Exception:pass
 def close_all(self):
  with self.lock:ids=list(self.sessions)
  for sid in ids:self.close(sid)
 def open_file(self,path):
  path=Path(path).resolve();ext=path.suffix.lower()
  if not path.is_file():raise DataError('Fichier introuvable.')
  # 4.0.0 : la SIGNATURE tranche, pas la seule extension. Une base SQLite nommée
  # « export.dat » est une base SQLite ; un « notes.sqlite » qui contient du
  # texte n'en est pas une, et l'ouvrir comme base remplirait l'onglet de binaire
  # illisible au lieu de dire ce qu'il en est.
  try:
   import donnees_etendues
   detection=donnees_etendues.famille(path)
  except ImportError:
   detection={'famille':'inconnu','raison':'module donnees_etendues absent'}
  famille=detection.get('famille')
  if famille in ('xlsx','ods','xml'):return self._ouvrir_tables(path,famille,detection)
  if famille=='texte' and ext in ('.sqlite','.sqlite3','.db','.db3','.xlsx','.xlsm','.ods'):
   raison=str(detection.get('raison') or 'Ce fichier n’est pas une base.')
   # La raison produite par donnees_etendues dit déjà que le fichier s’ouvre
   # comme texte ; la répéter donnait « …ouvert comme texte Ouvrez-le comme
   # texte. ». On ne complète que si l’information manque.
   if 'comme texte' not in raison:raison=raison+' Ouvrez-le comme texte.'
   raise DataError(raison)
  if famille=='zip-autre':
   # La raison renvoyée par la détection répétait mot pour mot le début du
   # message (« archive ZIP qui n’est ni un classeur XLSX ni un ODS ») : elle
   # n’apportait rien et alourdissait la phrase.
   raise DataError('Cette archive ZIP n’est ni un classeur XLSX ni un classeur ODS. Ouvrez-la avec un gestionnaire d’archives.')
  if ext in ('.sqlite','.sqlite3','.db','.db3') or famille=='sqlite':
   try:
    # mode=rw guarantees the chooser cannot create a new DB by accident.
    conn=sqlite3.connect(path.as_uri()+'?mode=rw',uri=True,check_same_thread=False,timeout=5)
    conn.execute('PRAGMA foreign_keys=ON');conn.execute('SELECT name FROM sqlite_master LIMIT 1').fetchone()
   except Exception as e:
    try:conn.close()
    except Exception:pass
    raise DataError('Base SQLite non valide ou inaccessible : '+str(e))
   try:sid=self._add({'kind':'sqlite','path':str(path),'conn':conn})
   except Exception:conn.close();raise
   return {'id':sid,'kind':'sqlite','label':path.name,'location':str(path)}
  if ext not in ('.csv','.tsv','.json','.sql'):raise DataError('Formats acceptés : SQLite, CSV, TSV, JSON, SQL, XLSX, ODS et XML.')
  data=file_bytes(path)
  try:text=data.decode('utf-8-sig')
  except UnicodeError:raise DataError('Le fichier doit être encodé en UTF-8.')
  session={'kind':'csv' if ext in ('.csv','.tsv') else ext[1:],'path':str(path),'revision':digest(data),'bom':data.startswith(b'\xef\xbb\xbf')}
  if session['kind']=='csv':
   dialect=detect_csv(text,ext);session['dialect']=dialect
   try:rows=list(csv.reader(io.StringIO(text,newline=''),delimiter=dialect['delimiter'],quotechar=dialect['quotechar'],doublequote=dialect['doublequote'],escapechar=dialect['escapechar'],strict=True))
   except csv.Error as e:raise DataError('CSV invalide : '+str(e))
   if len(rows)>MAX_ROWS+1 or any(len(r)>MAX_COLS for r in rows):raise DataError('CSV trop grand : 5 000 lignes et 200 colonnes maximum.')
   payload={'rows':rows,'delimiter':dialect['delimiter']}
  elif session['kind']=='json':
   try:json.loads(text,parse_constant=reject_constant)
   except (ValueError,RecursionError) as e:raise DataError('JSON invalide : '+str(e))
   payload={'text':text}
  else:payload={'text':text}
  sid=self._add(session);return {'id':sid,'kind':session['kind'],'label':path.name,'location':str(path),'revision':session['revision'],**payload}
 def _ouvrir_tables(self,path,famille,detection):
  """Un classeur XLSX ou ODS, ou un document XML, comme source de tables.

  Ces formats n'ont aucun moteur de requête : les tables sont donc chargées d'un
  coup et gardées en session, et le champ de requête s'appuie sur un miroir
  SQLite en mémoire reconstruit à chaque interrogation. C'est assumé, annoncé
  par « miroir » dans la réponse, et une requête qui modifierait est refusée
  parce qu'elle n'écrirait rien dans le fichier.
  """
  try:
   import donnees_etendues
  except ImportError:
   raise DataError('Module donnees_etendues introuvable : les classeurs et l’XML ne peuvent pas être ouverts.')
  try:
   tables,_=donnees_etendues.lire(path)
  except donnees_etendues.DonneesRefusees as e:
   raise DataError(str(e))
  if not tables:
   # `detection['raison']` explique la FAMILLE du fichier, pas l’absence de
   # table : pour un XML elle disait « déclaration XML en tête », ce qui est
   # vrai mais n’explique rien. On donne la règle réellement appliquée.
   if famille=='xml':
    manque='aucun élément n’y est répété au moins deux fois, donc aucune table ne peut en être dégagée'
   else:
    manque='le classeur ne contient aucune feuille exploitable'
   raise DataError('Aucune table exploitable dans '+path.name+' : '+manque+'. Ce fichier s’ouvre comme texte.')
  data=file_bytes(path);rev=digest(data)
  # Ce qui interdirait l'écriture est vérifié À L'OUVERTURE et non au premier
  # clic sur Enregistrer : une grille qui se dit modifiable puis refuse fait
  # perdre le travail saisi. La raison est une phrase qui dit quoi faire à la
  # place — des formules dans le classeur, openpyxl absent, un document XML dont
  # la racine ne peut pas être replacée.
  ecriture,raison=donnees_etendues.ecriture_possible(path)
  sid=self._add({'kind':famille,'path':str(path),'tables':tables,'revision':rev,
                 'ecriture':ecriture,'ecriture_raison':raison})
  return {'id':sid,'kind':famille,'label':path.name,'location':str(path),'revision':rev,'miroir':True,
   'editable':ecriture,'raison_lecture_seule':raison,
   'tables':[{'schema':'','name':t['nom'],'type':'table','titre':t.get('titre') or t['nom'],
              'colonnes':t.get('colonnes') or [],'entete':bool(t.get('entete')),
              'lignes':len(t.get('lignes') or [])} for t in tables]}
 def _table_locale(self,s,name):
  for t in s.get('tables') or []:
   if t['nom']==name or t.get('titre')==name:return t
  raise DataError('Table « '+str(name)+' » absente de ce fichier.')
 def _table_autorisee(self,s,schema,name):
  """Une table qui existe vraiment dans cette source, et rien d'autre.

  Passer par la liste réelle empêche d'écrire dans une table qui n'existe pas :
  l'erreur remonterait de la base, moins claire que celle-ci, et une vue serait
  traitée comme une table.
  """
  schema=schema or ''
  tables=self.list_tables(s['id'])['tables']
  table=next((x for x in tables if x['schema']==schema and x['name']==name),None)
  if not table:raise DataError('Table « '+str(name)+' » introuvable ou non autorisée.')
  return table
 def _colonnes_brutes(self,payload,quoi):
  """La liste de colonnes d'une demande de création, présente et de taille valable."""
  colonnes=payload.get('columns')
  if not isinstance(colonnes,list) or not colonnes or len(colonnes)>MAX_COLS:raise DataError(quoi+' demande de 1 à '+str(MAX_COLS)+' colonnes.')
  return colonnes
 def _noms_colonnes(self,payload,quoi):
  """Les noms de colonnes d'une demande de création, validés et sans doublon."""
  noms=[]
  for colonne in self._colonnes_brutes(payload,quoi):
   if isinstance(colonne,dict):colonne=colonne.get('name')
   if not isinstance(colonne,str) or not colonne.strip():raise DataError('Nom de colonne invalide : '+repr(colonne)[:120])
   noms.append(colonne.strip())
  if len({n.lower() for n in noms})!=len(noms):raise DataError('Deux colonnes portent le même nom.')
  return noms
 def _colonne_sql(self,s,colonne):
  """Valide une colonne demandée et rend (nom, type).

  Le type est validé sur un motif et non recopié tel quel : c'est le seul
  morceau de l'instruction qui ne puisse pas passer par `self.q()`, et un texte
  libre y permettrait de glisser n'importe quelle suite d'instructions.
  """
  if isinstance(colonne,str):colonne={'name':colonne}
  if not isinstance(colonne,dict):raise DataError('Colonne invalide : '+repr(colonne)[:120])
  nom=colonne.get('name');type_=str(colonne.get('type') or 'TEXT').strip()
  if not isinstance(nom,str) or not nom.strip() or '\x00' in nom or len(nom)>200:raise DataError('Nom de colonne invalide.')
  if not TYPE_SQL.match(type_):raise DataError('Type de colonne non reconnu : « '+type_+' ». Employez un type simple — TEXT, INTEGER, REAL, NUMERIC(10,2), VARCHAR(255), TIMESTAMP.')
  return nom.strip(),type_.upper()
 def _valeur_texte(self,v):
  """Une valeur de case de miroir : du texte, comme tout ce que ces formats portent.

  Un booléen devient « true »/« false » et non « True » : c'est ce que le lecteur
  rendra, et une casse différente ferait croire à deux valeurs distinctes.
  """
  input_value(v)
  if v is None:return ''
  if isinstance(v,bool):return 'true' if v else 'false'
  return str(v)
 # ------------------------------------------------------------------ miroirs
 # Un classeur ou un document XML n'a pas de moteur : les modifications sont
 # appliquées sur la copie en session, puis le FICHIER est réécrit d'un coup.
 # Tout est vérifié avant d'écrire, pour qu'un refus laisse le fichier intact.
 def _ecrire_miroir(self,s,tables,supprimees=()):
  """Écrit le fichier d'un miroir, puis recharge la session sur ce qui a été écrit.

  L'empreinte du fichier est revérifiée avant d'écrire : sans ce contrôle, un
  enregistrement écraserait sans le dire ce qu'un autre onglet — ou un autre
  programme — a écrit entre-temps. C'est la même garantie que `write_checked()`
  pour les fichiers texte.

  La session est rechargée depuis le FICHIER et non depuis la copie en mémoire :
  ce qui compte est ce que la prochaine lecture rendra. Un nom de feuille nettoyé
  ou désambiguïsé par le lecteur ne doit pas surprendre l'interface, et une
  écriture refusée doit laisser la session exactement comme elle était.
  """
  try:import donnees_etendues
  except ImportError:raise DataError('Module donnees_etendues introuvable : ce format ne peut pas être écrit.')
  chemin=Path(s['path'])
  if digest(file_bytes(chemin))!=s['revision']:raise DataError('Le fichier a changé sur le disque. Rechargez-le avant de sauvegarder.')
  if supprimees and len(s.get('tables') or [])<=len(supprimees):
   raise DataError('Ce fichier n’a que '+str(len(s.get('tables') or []))+' table(s) : tout supprimer le laisserait sans aucune table exploitable, et il ne s’ouvrirait plus que comme texte. Supprimez le fichier lui-même depuis le gestionnaire de fichiers.')
  ecrivain={'xlsx':donnees_etendues.ecrire_xlsx,'ods':donnees_etendues.ecrire_ods,'xml':donnees_etendues.ecrire_xml}[s['kind']]
  try:ecrivain(chemin,tables,supprimees=tuple(supprimees))
  except donnees_etendues.DonneesRefusees as e:raise DataError(str(e))
  except OSError as e:raise DataError('Écriture impossible : '+str(e))
  try:relues,_=donnees_etendues.lire(chemin)
  except donnees_etendues.DonneesRefusees as e:raise DataError('Le fichier a été écrit, mais il ne peut plus être relu ('+str(e)+'). Rechargez-le.')
  s['tables']=relues;s['revision']=digest(file_bytes(chemin))
  return s['revision']
 def _indice_ligne(self,lignes,original):
  """Le rang de la ligne identique à `original`, ou -1.

  Un miroir n'a pas de clé primaire : une ligne est donc reconnue par son
  contenu entier, comme la branche SQL reconnaît la sienne par sa clé puis la
  revérifie avant d'écrire. Deux lignes strictement identiques sont
  interchangeables — en modifier ou en supprimer une donne exactement le même
  fichier — donc prendre la première n'est pas une ambiguïté.
  """
  for i,ligne in enumerate(lignes):
   if [safe(v) for v in ligne]==list(original):return i
  return -1
 def _normaliser(self,t):
  """Colonnes et lignes d'une table de miroir, calées l'une sur l'autre.

  Une ligne plus courte que les colonnes est complétée, une ligne plus longue
  est coupée : sans cela l'indice d'une colonne ne désignerait pas la même case
  d'une ligne à l'autre, et une modification écrirait à côté.
  """
  colonnes=list(t.get('colonnes') or [])
  n=len(colonnes)
  return colonnes,[(list(l)+['']*n)[:n] for l in (t.get('lignes') or [])]
 def _appliquer_miroir(self,s,name,edits):
  t=self._table_locale(s,name)
  if s.get('ecriture') is False:raise DataError(s.get('ecriture_raison') or 'Ce format ne peut pas être écrit.')
  colonnes,lignes=self._normaliser(t)
  changed=0
  for edit in edits:
   if not isinstance(edit,dict):raise DataError('Modification invalide.')
   if 'insert' in edit:
    values=edit['insert']
    if not isinstance(values,dict):raise DataError('Colonnes d’insertion invalides.')
    inconnues=[k for k in values if k not in colonnes]
    if inconnues:raise DataError('Colonne inconnue dans « '+str(name)+' » : '+', '.join('« '+str(k)+' »' for k in inconnues)+'. Ajoutez d’abord la colonne.')
    nouvelle=['']*len(colonnes)
    for k,v in values.items():nouvelle[colonnes.index(k)]=self._valeur_texte(v)
    lignes.append(nouvelle);changed+=1;continue
   original=edit.get('original');diff=edit.get('changes',{});delete=edit.get('delete') is True
   if not isinstance(original,list) or len(original)!=len(colonnes) or not isinstance(diff,dict):raise DataError('Ligne originale invalide.')
   i=self._indice_ligne(lignes,original)
   if i<0:raise DataError('Conflit : une ligne a changé ou a été supprimée. Aucune modification n’a été enregistrée ; rechargez la table.')
   if delete:del lignes[i];changed+=1;continue
   if not diff:continue
   inconnues=[k for k in diff if k not in colonnes]
   if inconnues:raise DataError('Colonne inconnue dans « '+str(name)+' » : '+', '.join('« '+str(k)+' »' for k in inconnues)+'.')
   for k,v in diff.items():lignes[i][colonnes.index(k)]=self._valeur_texte(v)
   changed+=1
  copie=dict(t);copie['colonnes']=colonnes;copie['lignes']=lignes
  return {'changed':changed,'revision':self._ecrire_miroir(s,[copie]),'miroir':True}
 def _structure_miroir(self,s,action,payload):
  nom=str(payload.get('name') or payload.get('table') or '').strip()
  if action=='create_table':
   if s['kind']=='xml':
    raise DataError('Ajouter une table à un document XML n’est pas pris en charge : une table y est une famille d’éléments répétés, et rien ne dit où placer les nouveaux éléments ni sous quel nom. Ouvrez le fichier comme texte pour le faire.')
   if not nom:raise DataError('Nom de feuille invalide.')
   if len(nom)>31:raise DataError('Un nom de feuille est limité à 31 caractères.')
   noms=self._noms_colonnes(payload,'Une feuille')
   self._ecrire_miroir(s,[{'nom':nom,'titre':nom,'colonnes':noms,'lignes':[],'entete':True,'formules':False}])
   return {'ok':True,'instruction':'feuille « '+nom+' » créée avec '+str(len(noms))+' colonne(s)','miroir':True}
  if action=='drop_table':
   t=self._table_locale(s,nom)
   self._ecrire_miroir(s,[],[t['nom']])
   return {'ok':True,'instruction':'table « '+t['nom']+' » supprimée du fichier','miroir':True}
  if action in ('add_column','drop_column'):
   t=self._table_locale(s,nom)
   colonne=str(payload.get('column') or payload.get('name') or '').strip()
   if not colonne:raise DataError('Nom de colonne invalide.')
   if len(colonne)>200:raise DataError('Nom de colonne trop long (200 caractères maximum).')
   colonnes,lignes=self._normaliser(t)
   if action=='add_column':
    if colonne in colonnes:raise DataError('La colonne « '+colonne+' » existe déjà dans « '+nom+' ».')
    if len(colonnes)>=MAX_COLS:raise DataError('Limite de '+str(MAX_COLS)+' colonnes atteinte dans « '+nom+' ».')
    defaut=payload.get('default')
    if defaut is not None and not scalar(defaut):raise DataError('Valeur par défaut invalide : texte, nombre, booléen ou rien.')
    valeur='' if defaut is None else self._valeur_texte(defaut)
    if s['kind']=='xml' and payload.get('attribut') is True and not colonne.startswith('@'):
     # En XML une colonne est soit un attribut soit un élément enfant. Le
     # préfixe « @ » est la notation que le lecteur emploie déjà : c'est la seule
     # façon de dire où ranger une colonne ajoutée.
     colonne='@'+colonne
    copie=dict(t);copie['colonnes']=colonnes+[colonne]
    copie['lignes']=[l+[valeur] for l in lignes]
   else:
    if colonne not in colonnes:raise DataError('La colonne « '+colonne+' » n’existe pas dans « '+nom+' ».')
    if len(colonnes)<=1:raise DataError('« '+colonne+' » est la dernière colonne de « '+nom+' » : la supprimer viderait la table. Supprimez la table entière.')
    i=colonnes.index(colonne)
    copie=dict(t);copie['colonnes']=[c for j,c in enumerate(colonnes) if j!=i]
    copie['lignes']=[[v for j,v in enumerate(l) if j!=i] for l in lignes]
   self._ecrire_miroir(s,[copie])
   return {'ok':True,'instruction':'colonne « '+colonne+' » '+('ajoutée à' if action=='add_column' else 'supprimée de')+' « '+nom+' »','miroir':True}
  raise DataError('Action de structure inconnue : '+repr(action)[:60])
 def _structure_sql(self,s,action,payload):
  if 'conn' not in s:raise DataError('Ouvrez une connexion SQL.')
  schema=str(payload.get('schema') or '')
  nom=str(payload.get('name') or payload.get('table') or '').strip()
  c=s['conn'].cursor()
  try:
   if action=='create_table':
    if not nom:raise DataError('Nom de table invalide.')
    paires=[self._colonne_sql(s,x) for x in self._colonnes_brutes(payload,'Une table')]
    if len({n.lower() for n,_t in paires})!=len(paires):raise DataError('Deux colonnes portent le même nom.')
    instruction='CREATE TABLE '+self.table_name(s,schema,nom)+' ('+', '.join(self.q(s,n)+' '+t for n,t in paires)+')'
   elif action=='drop_table':
    table=self._table_autorisee(s,schema,nom)
    if table['type']!='table':raise DataError('« '+nom+' » est une vue, pas une table : supprimez-la avec DROP VIEW dans le champ de requête.')
    instruction='DROP TABLE '+self.table_name(s,schema,nom)
   elif action in ('add_column','drop_column'):
    _table,cols=self.table_meta(s,schema,nom)
    colonne=str(payload.get('column') or '').strip()
    if not colonne:raise DataError('Nom de colonne invalide.')
    existantes=[x['name'] for x in cols]
    if action=='add_column':
     if colonne in existantes:raise DataError('La colonne « '+colonne+' » existe déjà dans « '+nom+' ».')
     if len(cols)>=MAX_COLS:raise DataError('Limite de '+str(MAX_COLS)+' colonnes atteinte dans « '+nom+' ».')
     _n,type_=self._colonne_sql(s,{'name':colonne,'type':payload.get('type') or 'TEXT'})
     instruction='ALTER TABLE '+self.table_name(s,schema,nom)+' ADD COLUMN '+self.q(s,colonne)+' '+type_
    else:
     cible=next((x for x in cols if x['name']==colonne),None)
     if not cible:raise DataError('La colonne « '+colonne+' » n’existe pas dans « '+nom+' ».')
     if cible['pk']:raise DataError('« '+colonne+' » fait partie de la clé primaire de « '+nom+' » : la base refuserait de la supprimer, et la retirer casserait l’identification des lignes.')
     if cible['generated']:raise DataError('« '+colonne+' » est une colonne générée : elle dépend d’une autre colonne, et se supprime avec elle ou dans la définition de la table.')
     if len(cols)<=1:raise DataError('« '+colonne+' » est la dernière colonne de « '+nom+' » : supprimez la table entière.')
     instruction='ALTER TABLE '+self.table_name(s,schema,nom)+' DROP COLUMN '+self.q(s,colonne)
   else:raise DataError('Action de structure inconnue : '+repr(action)[:60])
   c.execute(instruction);s['conn'].commit()
  except DataError:
   try:s['conn'].rollback()
   except Exception:pass
   raise
  except Exception as e:
   try:s['conn'].rollback()
   except Exception:pass
   raise DataError('Instruction refusée par la base : '+str(e)[:400])
  finally:c.close()
  return {'ok':True,'instruction':instruction,'tables':self.list_tables(s['id'])['tables'],'miroir':False}
 def structure(self,sid,action,payload=None):
  """Créer et supprimer des tables et des colonnes, quel que soit le format.

  Une seule entrée pour tous les formats, et c'est délibéré : l'interface propose
  les mêmes boutons partout, et c'est ici que chaque format dit ce qu'il sait
  faire. Un refus NOMME le format, l'action et la voie de recours — un bouton qui
  échoue avec « 'conn' » ou « Source non SQL » ne dit rien d'utilisable.

  Les commandes tournent en arrière-plan, donc l'instruction réellement exécutée
  est rendue dans « instruction » : l'utilisateur doit pouvoir lire ce qui a été
  fait à sa place.
  """
  s=self._get(sid)
  if not isinstance(action,str) or not action.strip():raise DataError('Action invalide.')
  action=action.strip()
  if action not in ('create_table','drop_table','add_column','drop_column'):
   raise DataError('Action de structure inconnue : « '+action+' ». Les actions prises en charge sont create_table, drop_table, add_column et drop_column.')
  if not isinstance(payload,dict):payload={}
  with s['lock']:
   if s['kind'] in ('xlsx','ods','xml'):
    if s.get('ecriture') is False:raise DataError(s.get('ecriture_raison') or 'Ce format ne peut pas être écrit.')
    resultat=self._structure_miroir(s,action,payload)
    resultat['tables']=[{'schema':'','name':t['nom'],'type':'table','titre':t.get('titre') or t['nom']} for t in s.get('tables') or []]
   elif s['kind'] in ('sqlite','postgres','mysql'):
    resultat=self._structure_sql(s,action,payload)
   elif s['kind']=='csv':
    raise DataError('Un fichier CSV ne contient qu’une seule table et s’édite comme texte : les boutons « ＋ Ligne » et « ＋ Colonne » de sa grille ajoutent lignes et colonnes, puis Enregistrer réécrit le fichier.')
   elif s['kind']=='json':
    raise DataError('Un fichier JSON s’édite dans sa vue tableau : « ＋ Objet » et « ＋ Propriété » y ajoutent lignes et colonnes, puis Enregistrer réécrit le fichier.')
   else:
    raise DataError('Un script SQL est du texte : les instructions CREATE TABLE, ALTER TABLE et DROP TABLE s’y écrivent directement. Le bouton « Insérer une instruction » les rédige pour vous, et « Charger dans une connexion » les exécute sur une base.')
   resultat['revision']=s.get('revision')
   return resultat
 def reparse_csv(self,sid,delimiter):
  s=self._get(sid)
  if s['kind']!='csv' or delimiter not in (',',';','\t','|'):raise DataError('Séparateur CSV invalide.')
  with s['lock']:
   data=file_bytes(Path(s['path']))
   try:text=data.decode('utf-8-sig')
   except UnicodeError:raise DataError('Le fichier doit être encodé en UTF-8.')
   dialect=detect_csv(text,Path(s['path']).suffix.lower());dialect['delimiter']=delimiter
   try:rows=list(csv.reader(io.StringIO(text,newline=''),delimiter=delimiter,quotechar=dialect['quotechar'],doublequote=dialect['doublequote'],escapechar=dialect['escapechar'],strict=True))
   except csv.Error as e:raise DataError('CSV invalide : '+str(e))
   if len(rows)>MAX_ROWS+1 or any(len(r)>MAX_COLS for r in rows):raise DataError('CSV trop grand : 5 000 lignes et 200 colonnes maximum.')
   s.update(dialect=dialect,revision=digest(data),bom=data.startswith(b'\xef\xbb\xbf'))
   return {'rows':rows,'revision':s['revision'],'delimiter':delimiter}
 def save_file(self,sid,revision,payload):
  s=self._get(sid)
  if s['kind'] not in ('csv','json','sql'):
   if s['kind'] in ('xlsx','ods','xml'):raise DataError('Un classeur ou un document XML ne s’enregistre pas comme texte : les modifications de la grille sont écrites dans le fichier par le bouton Enregistrer de la table.')
   raise DataError('Cette source n’est pas un fichier texte : une base ou une connexion s’enregistre par les boutons de sa grille et par le champ de requête.')
  with s['lock']:
   if revision!=s['revision']:raise DataError('Version du fichier périmée : rechargez la source.')
   if s['kind']=='csv':
    rows=payload.get('rows')
    if not isinstance(rows,list) or len(rows)>MAX_ROWS+1:raise DataError('Nombre de lignes invalide.')
    out=io.StringIO(newline='');w=csv.writer(out,**s['dialect'])
    for row in rows:
     if not isinstance(row,list) or len(row)>MAX_COLS or any(not isinstance(c,str) or len(c)>100_000 for c in row):raise DataError('Ligne CSV invalide.')
     w.writerow(row)
    text=out.getvalue()
   else:
    text=payload.get('text')
    if not isinstance(text,str):raise DataError('Texte invalide.')
    if s['kind']=='json':
     try:json.loads(text,parse_constant=reject_constant)
     except (ValueError,RecursionError) as e:raise DataError('JSON invalide : '+str(e))
   raw=(b'\xef\xbb\xbf' if s['bom'] else b'')+text.encode('utf-8');s['revision']=write_checked(Path(s['path']),raw,revision);return {'revision':s['revision']}
 def create_sqlite(self,path):
  path=Path(path).resolve()
  if path.suffix.lower() not in ('.sqlite','.sqlite3','.db','.db3'):raise DataError('Utilisez une extension .sqlite, .sqlite3, .db ou .db3.')
  if not path.parent.is_dir():raise DataError('Le dossier parent n’existe pas.')
  try:fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  except FileExistsError:raise DataError('Un fichier existe déjà à cet emplacement.')
  os.close(fd)
  try:
   conn=sqlite3.connect(path);conn.execute('PRAGMA user_version = 0');conn.commit();conn.close()
  except Exception as e:raise DataError('Création incomplète ; vérifiez le fichier créé : '+str(e))
  return self.open_file(path)
 def connect(self,d):
  kind=d.get('kind');host=str(d.get('host','')).strip();database=str(d.get('database','')).strip();user=str(d.get('user','')).strip();password=d.get('password','');tls=bool(d.get('tls',True))
  if kind not in ('postgres','mysql') or not host or not database or not user or not isinstance(password,str):raise DataError('Renseignez hôte, base, utilisateur et mot de passe.')
  if any(len(x)>500 or '\x00' in x for x in (host,database,user,password)):raise DataError('Paramètre de connexion invalide.')
  try:port=int(d.get('port') or (5432 if kind=='postgres' else 3306))
  except (TypeError,ValueError):raise DataError('Port invalide.')
  if port<1 or port>65535:raise DataError('Port invalide.')
  if not tls and host not in ('localhost','127.0.0.1','::1'):raise DataError('Sans TLS, seules les connexions locales sont autorisées.')
  ca=str(d.get('ca_file') or '').strip()
  if ca and not tls:raise DataError('Le certificat CA ne peut être utilisé que si TLS est activé.')
  try:
   if ca:
    ca_path=Path(ca).expanduser().resolve()
    if not ca_path.is_file() or ca_path.stat().st_size>5_000_000:raise DataError('Fichier de certificat CA introuvable ou trop volumineux.')
    context=ssl.create_default_context(cafile=str(ca_path))
   else:context=ssl.create_default_context() if tls else False
  except (OSError,ssl.SSLError) as e:raise DataError('Certificat CA invalide : '+str(e))
  try:
   if kind=='postgres':
    import pg8000.dbapi
    conn=pg8000.dbapi.connect(user=user,password=password,host=host,port=port,database=database,timeout=10,ssl_context=context)
   else:
    import pymysql
    options={'ssl':context} if tls else {}
    conn=pymysql.connect(user=user,password=password,host=host,port=port,database=database,connect_timeout=10,read_timeout=30,write_timeout=30,autocommit=False,**options)
  except Exception as e:
   msg=str(e)
   if password:msg=msg.replace(password,'••••')
   raise DataError('Connexion impossible : '+msg[:700])
  try:sid=self._add({'kind':kind,'conn':conn,'label':database,'host':host,'tls':tls})
  except Exception:conn.close();raise
  return {'id':sid,'kind':kind,'label':database,'location':host+':'+str(port),'tls':tls}
 def q(self,s,name):
  if not isinstance(name,str) or not name or '\x00' in name or len(name)>500:raise DataError('Identifiant SQL invalide.')
  ch='`' if s['kind']=='mysql' else '"';return ch+name.replace(ch,ch+ch)+ch
 def placeholder(self,s):return '?' if s['kind']=='sqlite' else '%s'
 def list_tables(self,sid):
  s=self._get(sid)
  # 4.0.0 : un classeur ou un XML n'a pas de connexion, mais il a bien des
  # tables. Sans cette branche, la réponse était « Source non SQL » — exactement
  # le refus que cette version doit supprimer.
  if s['kind'] in ('xlsx','ods','xml'):
   with s['lock']:
    tables=[{'schema':'','name':t['nom'],'type':'table'} for t in s.get('tables') or []]
    return {'tables':tables,'miroir':True}
  if 'conn' not in s:raise DataError('Source non SQL.')
  with s['lock']:
   c=s['conn'].cursor()
   try:
    if s['kind']=='sqlite':c.execute("SELECT '' AS schema,name,type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name")
    elif s['kind']=='postgres':c.execute("SELECT table_schema,table_name,CASE WHEN table_type='VIEW' THEN 'view' ELSE 'table' END FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema') AND table_type IN ('BASE TABLE','VIEW') ORDER BY table_schema,table_name")
    else:c.execute("SELECT table_schema,table_name,CASE WHEN table_type='VIEW' THEN 'view' ELSE 'table' END FROM information_schema.tables WHERE table_schema=DATABASE() ORDER BY table_name")
    tables=[{'schema':r[0] or '', 'name':r[1], 'type':r[2]} for r in c.fetchall()[:1000]];s['tables']=tables
    return {'tables':tables}
   finally:c.close();s['conn'].rollback()
 def table_meta(self,s,schema,name):
  # Sans cette garde, un classeur ou un XML arrivait ici et levait KeyError sur
  # « conn » : l'interface affichait alors le nom d'une variable Python, ce qui
  # n'explique rien. Les colonnes d'un miroir sont rendues par rows().
  if 'conn' not in s:raise DataError('Cette source n’a pas de connexion SQL : ses colonnes sont rendues par la lecture de la table.')
  table=self._table_autorisee(s,schema,name)
  c=s['conn'].cursor();ph=self.placeholder(s)
  try:
   if s['kind']=='sqlite':
    c.execute('PRAGMA table_xinfo('+self.q(s,name)+')');cols=[{'name':r[1],'type':r[2] or '', 'pk':bool(r[5]), 'generated':bool(r[6])} for r in c.fetchall() if r[6]!=1]
   elif s['kind']=='postgres':
    c.execute('''SELECT c.column_name,c.data_type,EXISTS(SELECT 1 FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage k ON tc.constraint_name=k.constraint_name AND tc.table_schema=k.table_schema WHERE tc.constraint_type='PRIMARY KEY' AND tc.table_schema=c.table_schema AND tc.table_name=c.table_name AND k.column_name=c.column_name), c.is_generated<>'NEVER' OR c.is_identity='YES' FROM information_schema.columns c WHERE c.table_schema=%s AND c.table_name=%s ORDER BY c.ordinal_position''',(schema,name))
    cols=[{'name':r[0],'type':r[1],'pk':bool(r[2]),'generated':bool(r[3])} for r in c.fetchall()]
   else:
    c.execute("SELECT column_name,column_type,column_key='PRI',extra FROM information_schema.columns WHERE table_schema=%s AND table_name=%s ORDER BY ordinal_position",(schema,name));cols=[{'name':r[0],'type':r[1],'pk':bool(r[2]),'generated':('generated' in (r[3] or '').lower() or 'auto_increment' in (r[3] or '').lower())} for r in c.fetchall()]
   if not cols or len(cols)>MAX_COLS:raise DataError('Table vide ou trop de colonnes (limite 200).')
   return table,cols
  finally:c.close();s['conn'].rollback()
 def table_name(self,s,schema,name):return (self.q(s,schema)+'.' if schema else '')+self.q(s,name)
 def rows(self,sid,schema,name,offset=0):
  s=self._get(sid)
  try:offset=int(offset)
  except (TypeError,ValueError):raise DataError('Page invalide.')
  if offset<0 or offset>1_000_000:raise DataError('Page invalide.')
  with s['lock']:
   if s['kind'] in ('xlsx','ods','xml'):
    t=self._table_locale(s,name);lignes=t.get('lignes') or [];colonnes=t.get('colonnes') or []
    cols=[{'name':c,'type':'TEXT','pk':False,'generated':False} for c in colonnes]
    page=lignes[offset:offset+PAGE]
    return {'columns':cols,'rows':[[safe(v) for v in (list(r)+['']*len(colonnes))[:len(colonnes)]] for r in page],'offset':offset,'more':len(lignes)>offset+PAGE,'editable':s.get('ecriture') is not False,'raison_lecture_seule':s.get('ecriture_raison') or '','type':'feuille','miroir':True,'entete':bool(t.get('entete')),'total':len(lignes)}
   table,cols=self.table_meta(s,schema,name);pk=[c['name'] for c in cols if c['pk']];names=','.join(self.q(s,c['name']) for c in cols);order=' ORDER BY '+','.join(self.q(s,p) for p in pk) if pk else '';c=s['conn'].cursor()
   try:
    c.execute('SELECT '+names+' FROM '+self.table_name(s,schema,name)+order+f' LIMIT {PAGE+1} OFFSET {offset}');raw=c.fetchmany(PAGE+1);more=len(raw)>PAGE
    return {'columns':cols,'rows':[[safe(v) for v in row] for row in raw[:PAGE]],'offset':offset,'more':more,'editable':bool(pk) and table['type']=='table','type':table['type']}
   finally:c.close();s['conn'].rollback()
 def apply(self,sid,schema,name,edits):
  s=self._get(sid)
  if not isinstance(edits,list) or not edits or len(edits)>100:raise DataError('Modifications invalides (100 lignes maximum).')
  with s['lock']:
   # 4.0.0 : un classeur ou un XML n'a ni connexion ni clé primaire. Sans cette
   # branche, la grille s'affichait « modifiable » puis l'enregistrement
   # renvoyait « 'conn' » — le nom d'une variable Python en guise d'explication.
   if s['kind'] in ('xlsx','ods','xml'):return self._appliquer_miroir(s,name,edits)
   table,cols=self.table_meta(s,schema,name);pk=[i for i,c in enumerate(cols) if c['pk']]
   if not pk or table['type']!='table':raise DataError('Cette table est en lecture seule : clé primaire requise.')
   names=[c['name'] for c in cols];ph=self.placeholder(s);tbl=self.table_name(s,schema,name);c=s['conn'].cursor();changed=0
   try:
    if s['kind']=='sqlite':c.execute('BEGIN IMMEDIATE')
    for edit in edits:
     if not isinstance(edit,dict):raise DataError('Modification invalide.')
     if 'insert' in edit:
      values=edit['insert']
      if not isinstance(values,dict) or any(k not in names or cols[names.index(k)]['generated'] for k in values):raise DataError('Colonnes d’insertion invalides.')
      if values:
       keys=list(values);vals=[input_value(values[k]) for k in keys];c.execute('INSERT INTO '+tbl+' ('+','.join(self.q(s,k) for k in keys)+') VALUES ('+','.join([ph]*len(keys))+')',vals)
      else:
       c.execute('INSERT INTO '+tbl+(' () VALUES ()' if s['kind']=='mysql' else ' DEFAULT VALUES'))
      changed+=1;continue
     original=edit.get('original');diff=edit.get('changes',{});delete=edit.get('delete') is True
     if not isinstance(original,list) or len(original)!=len(cols) or not isinstance(diff,dict):raise DataError('Ligne originale invalide.')
     if any(not scalar(original[i]) for i in pk):raise DataError('Clé primaire non prise en charge.')
     where=[];values=[]
     for i in pk:
      if original[i] is None:where.append(self.q(s,names[i])+' IS NULL')
      else:where.append(self.q(s,names[i])+'='+ph);values.append(input_value(original[i]))
     lock=' FOR UPDATE' if s['kind'] in ('mysql','postgres') else ''
     c.execute('SELECT '+','.join(self.q(s,k) for k in names)+' FROM '+tbl+' WHERE '+' AND '.join(where)+lock,values);current=c.fetchone()
     if current is None or [safe(x) for x in current]!=original:raise DataError('Conflit : une ligne a changé ou a été supprimée. Aucune modification n’a été enregistrée ; rechargez la table.')
     if delete:c.execute('DELETE FROM '+tbl+' WHERE '+' AND '.join(where),values)
     else:
      if not diff:continue
      if any(k not in names or cols[names.index(k)]['pk'] or cols[names.index(k)]['generated'] or not scalar(original[names.index(k)]) for k in diff):raise DataError('Colonne non modifiable ou clé primaire.')
      vals=[input_value(diff[k]) for k in diff];c.execute('UPDATE '+tbl+' SET '+','.join(self.q(s,k)+'='+ph for k in diff)+' WHERE '+' AND '.join(where),vals+values)
     if c.rowcount!=1:raise DataError('Conflit : une ligne n’a pas été modifiée.')
     changed+=1
    s['conn'].commit();return {'changed':changed}
   except Exception:
    s['conn'].rollback();raise
   finally:c.close()
 def query(self,sid,sql,commit=False):
  s=self._get(sid)
  # 4.0.0 : les classeurs et l'XML sont interrogés par SQL sur un miroir en
  # mémoire. Une requête qui modifierait est refusée, parce qu'elle n'écrirait
  # rien dans le fichier et laisserait croire à tort que le classeur a changé.
  if s['kind'] in ('xlsx','ods','xml'):
   if not isinstance(sql,str) or not sql.strip() or len(sql)>100_000:raise DataError('Requête vide ou trop longue.')
   try:
    import donnees_etendues
   except ImportError:
    raise DataError('Module donnees_etendues introuvable.')
   with s['lock']:
    try:
     r=donnees_etendues.interroger(s.get('tables') or [],sql,limite=PAGE)
    except donnees_etendues.DonneesRefusees as e:
     raise DataError(str(e))
   return {'columns':r['colonnes'],'rows':[[safe(v) for v in ligne] for ligne in r['lignes']],'more':r['tronque'],'count':None,'committed':False,'miroir':True,'tables':r['tables']}
  if 'conn' not in s:raise DataError('Ouvrez une connexion SQL.')
  if not isinstance(sql,str) or not sql.strip() or len(sql)>100_000:raise DataError('Requête vide ou trop longue.')
  with s['lock']:
   # pg8000 buffers results, so cap common SELECT/CTE queries server-side.
   # MySQL streams results instead of buffering the entire result in memory.
   command=sql.strip().rstrip(';').strip()
   if s['kind']=='postgres' and re.match(r'^(SELECT|WITH)\b',command,re.I):command='SELECT * FROM (\n'+command+'\n) AS "_pascal_result" LIMIT '+str(PAGE+1)
   if s['kind']=='postgres' and not re.match(r'^(SELECT|WITH)\b',sql.strip(),re.I) and re.search(r'\bRETURNING\b',sql,re.I):raise DataError('Pour limiter la mémoire, exécutez la modification sans RETURNING puis interrogez les résultats avec SELECT.')
   if s['kind']=='mysql':
    import pymysql.cursors
    c=s['conn'].cursor(pymysql.cursors.SSCursor)
   else:c=s['conn'].cursor()
   if s['kind']=='sqlite':
    deadline=time.monotonic()+15;s['conn'].set_progress_handler(lambda: int(time.monotonic()>deadline),10000)
   try:
    if s['kind']=='sqlite':c.execute('BEGIN')
    c.execute(command)
    if c.description:
     columns=[str(x[0]) for x in c.description];raw=c.fetchmany(PAGE+1);result={'columns':columns,'rows':[[safe(v) for v in r] for r in raw[:PAGE]],'more':len(raw)>PAGE,'count':None}
    else:result={'columns':[],'rows':[],'more':False,'count':c.rowcount}
    if commit:s['conn'].commit()
    else:s['conn'].rollback()
    result['committed']=bool(commit);return result
   except Exception:s['conn'].rollback();raise
   finally:
    c.close()
    if s['kind']=='sqlite':s['conn'].set_progress_handler(None,0)
