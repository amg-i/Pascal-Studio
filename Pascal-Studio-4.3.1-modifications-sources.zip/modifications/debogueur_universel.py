"""Débogage uniforme : un mode pour chaque langage de Pascal Studio.

L'interface ne doit plus afficher « Débogage indisponible pour ce langage ».
Chaque langage reçoit un mode, choisi selon ce qu'on peut réellement faire :

  reel          un vrai débogueur existe déjà (GDB, script, Xdebug, DAP) :
                points d'arrêt, pas à pas, variables, pile, évaluation.
  instrumente   aucun débogueur n'existe, mais l'interpréteur permet d'injecter
                une sonde : bash et perl sont pilotés ligne à ligne au moyen
                d'un canal de contrôle.
  visuel        le langage produit un rendu et non des commandes (HTML, CSS,
                SVG, LaTeX, Markdown, XML) : le débogage passe par
                l'inspecteur visuel de l'aperçu, pas par la console.
  trace         on peut exécuter et rapporter des diagnostics structurés, sans
                pas à pas fiable (lua, ocaml, basic, make, cmake, cs).
  aucun         rien d'exécutable ni de rendable (csproj, json, plaintext).

« capacites() » décrit ce que chaque mode offre, pour que l'interface affiche
les bons boutons au lieu de promettre un pas à pas impossible.

Le canal de contrôle est une paire de FIFO : l'enfant annonce ses arrêts sur
l'une, le parent envoie ses ordres sur l'autre. Les deux sont ouvertes en
lecture-écriture côté parent, ce qui supprime tout blocage à l'ouverture et
tout EOF prématuré.
"""

import base64
import errno
import os
import queue
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from pathlib import Path

import langages

MODE_REEL = 'reel'
MODE_INSTRUMENTE = 'instrumente'
MODE_VISUEL = 'visuel'
MODE_TRACE = 'trace'
MODE_AUCUN = 'aucun'

DELAI_ARRET = 10
DELAI_FIN = 5
LIMITE_SORTIE = 2_000_000
LIMITE_VARIABLES = 40
LIMITE_VALEUR = 500

# Débogueurs déjà implémentés par Pascal Studio.
MOTEURS_REELS = {
    # Les dix langages ésotériques : leurs moteurs sont écrits dans
    # langages_esoteriques.py et sont des machines à pas NATIVES, donc le
    # débogage est réel — pas de prélude injecté, pas de tube nommé, et aucun
    # interpréteur externe à installer (aucun n'existe pour Debian 13).
    'esoterique': ('brainfuck', 'whitespace', 'lolcode', 'arnoldc', 'chef',
                   'shakespeare', 'intercal', 'fractran', 'malbolge', 'piet'),
    'gdb': ('pascal', 'c', 'cpp', 'rust', 'fortran'),
    'script': ('python', 'javascript'),
    'php': ('php',),
    'dap': ('go', 'ruby', 'swift', 'kotlin'),
}

INSTALLATIONS = {
    'gdb': 'sudo apt install gdb',
    'php': 'sudo apt install php-cli php-xdebug',
    'dap': 'un adaptateur DAP doit être installé pour ce langage',
    'script': 'sudo apt install python3 nodejs',
    'perl': 'sudo apt install perl',
    'bash': 'sudo apt install bash',
    'lua': 'sudo apt install lua5.4',
    'ocaml': 'sudo apt install ocaml',
    'basic': 'sudo apt install yabasic',
    'make': 'sudo apt install make',
    'cmake': 'sudo apt install cmake',
    'cs': 'sudo apt install mono-mcs',
}


def mode(kind):
    """Le mode de débogage d'un langage."""
    identifiant = langages.resoudre(kind) or (kind if langages.langage(kind) else '')
    if not identifiant:
        return MODE_AUCUN
    langage = langages.langage(identifiant)
    if langage.graphique:
        return MODE_VISUEL
    moteur = langage.debogueur
    if moteur in MOTEURS_REELS:
        return MODE_REEL
    if moteur == 'instrumente':
        return MODE_INSTRUMENTE
    if moteur == 'visuel':
        return MODE_VISUEL
    if identifiant in ('cs', 'make', 'cmake'):
        return MODE_TRACE
    if not moteur:
        return MODE_AUCUN
    return MODE_TRACE


def capacites(kind):
    """Ce que le débogage offre réellement pour ce langage."""
    identifiant = langages.resoudre(kind) or (kind if langages.langage(kind) else '')
    m = mode(identifiant)
    langage = langages.langage(identifiant) if identifiant else None
    base = {
        'langage': identifiant,
        'libelle': langage.libelle if langage else '',
        'mode': m,
        'points_arret': m in (MODE_REEL, MODE_INSTRUMENTE, MODE_VISUEL, MODE_TRACE),
        'pas_a_pas': m in (MODE_REEL, MODE_INSTRUMENTE),
        'variables': m == MODE_REEL or identifiant in ('bash', 'perl'),
        'pile': m == MODE_REEL,
        'evaluation': m in (MODE_REEL, MODE_INSTRUMENTE),
        'visuel': m == MODE_VISUEL,
        'execution': m in (MODE_REEL, MODE_INSTRUMENTE, MODE_TRACE),
        'disponible': m != MODE_AUCUN,
        'installation': '',
        'explication': '',
    }
    if m == MODE_REEL:
        moteur = langage.debogueur
        base['moteur'] = moteur
        if moteur == 'gdb' and not shutil.which('gdb'):
            base['installation'] = INSTALLATIONS['gdb']
        elif moteur == 'php' and not shutil.which('php'):
            base['installation'] = INSTALLATIONS['php']
        elif moteur == 'script':
            manque = [b for b in ('python3', 'node')
                      if not shutil.which(b) and (
                          (b == 'python3' and identifiant == 'python')
                          or (b == 'node' and identifiant == 'javascript'))]
            if manque:
                base['installation'] = INSTALLATIONS['script']
        elif moteur == 'dap' and not langage.dap:
            base['installation'] = INSTALLATIONS['dap']
        base['explication'] = 'Débogueur complet : points d’arrêt, pas à pas, variables et pile.'
    elif m == MODE_INSTRUMENTE:
        base['moteur'] = identifiant
        if not shutil.which(identifiant == 'basic' and 'yabasic' or identifiant):
            base['installation'] = INSTALLATIONS.get(identifiant, '')
            base['explication'] = ('Interpréteur absent : le débogage instrumenté '
                                   'ne peut pas démarrer.')
        else:
            base['explication'] = ('Exécution instrumentée : le script est arrêté '
                                   'sur vos points d’arrêt, avec pas à pas et '
                                   'inspection des variables.')
            if identifiant == 'perl':
                base['explication'] += (' Perl n’expose que les variables de '
                                        'paquet (our) : les lexicales (my) ne '
                                        'sont pas visibles sans PadWalker.')
    elif m == MODE_VISUEL:
        base['explication'] = ('Ce langage produit un rendu, pas des commandes : '
                               'utilisez l’inspecteur visuel dans l’aperçu.')
        if identifiant == 'piet_texte':
            # La source texte Piet : même moteur que Piet, donc mêmes capacités,
            # mais l'aperçu est le PNG COMPILÉ et l'éditeur est celui de
            # piet-studio.js. Le dire évite de chercher la peinture dans le
            # fichier .piett lui-même.
            base['pas_a_pas'] = True
            base['variables'] = True
            base['pile'] = True
            base['explication'] = (
                'Le fichier .piett est la SOURCE : il est compilé en PNG, puis '
                'c’est le moteur Piet qui tourne — pas à pas, pile et sortie '
                'inclus. L’éditeur Piet affiche la grille à peindre et l’aperçu '
                'PNG ; l’inspecteur visuel surligne le bloc actif.')
        elif langage and langage.debogueur == 'esoterique':
            # Piet : le rendu EST le programme, mais son moteur sait stepper.
            # L’inspecteur visuel surligne le bloc de couleur actif et affiche
            # l’opération en cours ; le pas à pas, les variables et la pile
            # restent disponibles parce qu’ils viennent de notre propre moteur.
            base['pas_a_pas'] = True
            base['variables'] = True
            base['pile'] = True
            base['explication'] = (
                'Le programme est une image : l’aperçu affiche la peinture et '
                'l’inspecteur surligne le bloc de couleur actif avec son '
                'opération. Le pas à pas et la pile viennent du moteur local.')
    elif m == MODE_TRACE:
        base['explication'] = ('Pas de pas à pas fiable pour ce langage : '
                               'l’exécution est tracée et les erreurs sont '
                               'rapportées ligne par ligne.')
        binaire = {'cs': 'mcs', 'make': 'make', 'cmake': 'cmake'}.get(identifiant)
        if binaire and not shutil.which(binaire):
            base['installation'] = INSTALLATIONS.get(identifiant, '')
    else:
        base['explication'] = 'Aucun débogage possible pour ce langage.'
    return base


def tous_les_modes():
    """Le tableau complet, pour la documentation et les vérifications."""
    return {i: mode(i) for i in langages.tous()}


class CanalDeControle:
    """Deux FIFO : événements de l'enfant, ordres du parent."""

    def __init__(self, dossier):
        self.dossier = Path(dossier)
        self.chemin_evenements = self.dossier / 'evenements.fifo'
        self.chemin_commandes = self.dossier / 'commandes.fifo'
        self.evenements = -1
        self.commandes = -1
        self.verrou = threading.Lock()
        # Tampon persistant : un seul os.read() peut contenir plusieurs
        # événements. Le rendre local à lire() perdrait tout ce qui suit la
        # première ligne, et l'enfant resterait bloqué sur son prochain arrêt.
        self.reste = b''

    def ouvrir(self):
        os.mkfifo(self.chemin_evenements)
        os.mkfifo(self.chemin_commandes)
        # O_RDWR des deux côtés : l'ouverture ne bloque jamais et la lecture
        # ne reçoit pas de EOF quand l'enfant ferme son extrémité.
        self.evenements = os.open(self.chemin_evenements, os.O_RDWR | os.O_NONBLOCK)
        self.commandes = os.open(self.chemin_commandes, os.O_RDWR | os.O_NONBLOCK)
        os.set_blocking(self.evenements, False)

    def envoyer(self, ordre):
        with self.verrou:
            if self.commandes < 0:
                raise ValueError('Canal de contrôle fermé.')
            donnees = (ordre.rstrip('\n') + '\n').encode('utf8')
            for _ in range(50):
                try:
                    os.write(self.commandes, donnees)
                    return
                except BlockingIOError:
                    time.sleep(0.02)
            raise ValueError('Le programme ne lit plus les ordres.')

    def lire(self, delai=DELAI_ARRET):
        """Une ligne d'événement, ou None à l'échéance."""
        if self.evenements < 0:
            return None
        echeance = time.monotonic() + delai
        while True:
            if b'\n' in self.reste:
                ligne, self.reste = self.reste.split(b'\n', 1)
                return ligne.decode('utf8', 'replace')
            if time.monotonic() >= echeance:
                return None
            try:
                bloc = os.read(self.evenements, 65536)
            except BlockingIOError:
                bloc = b''
            except OSError as e:
                if e.errno == errno.EAGAIN:
                    bloc = b''
                else:
                    return None
            self.reste += bloc
            if not bloc:
                time.sleep(0.01)

    def fermer(self):
        for fd in (self.evenements, self.commandes):
            if fd >= 0:
                try:
                    os.close(fd)
                except OSError:
                    pass
        self.evenements = -1
        self.commandes = -1
        self.reste = b''


class DebogueurInstrumente:
    """Débogage par sonde injectée, pour les langages sans moteur dédié.

    Même interface que les autres débogueurs de Pascal Studio : snapshot(),
    start(), action(), add_breakpoint(), remove_breakpoint(), evaluate(),
    input(), stop(). L'interface n'a donc rien à changer.
    """

    def __init__(self, root, external_files=None):
        self.root = Path(root)
        self.external_files = external_files if external_files is not None else {}
        self.lock = threading.RLock()
        self.data = {'active': False, 'state': 'idle', 'reason': '', 'frame': None,
                     'frames': [], 'variables': [], 'output': '', 'message': '',
                     'breakpoints': []}
        self.kind = ''
        self.proc = None
        self.canal = None
        self.dossier = None
        self.breakpoints = set()
        self.pile = queue.Queue()
        self.lecteur = None
        self.lecteur_sortie = None
        self.arrete = threading.Event()

    # -- interface commune -------------------------------------------------

    def snapshot(self):
        with self.lock:
            return dict(self.data)

    def add_breakpoint(self, path, line):
        # Même exigence que les autres débogueurs : une clef de fichier, pas un
        # numéro. Sinon le point d'arrêt serait enregistré sur le chemin vide.
        if not isinstance(path, str) or not path:
            raise ValueError('Fichier invalide.')
        cle = self.key(path)
        try:
            ligne = int(line)
        except (TypeError, ValueError):
            raise ValueError('Numéro de ligne invalide.')
        if ligne < 1:
            raise ValueError('Numéro de ligne invalide.')
        with self.lock:
            self.breakpoints.add((cle, ligne))
            self._publier_points_arret()

    def remove_breakpoint(self, path, line):
        if not isinstance(path, str) or not path:
            raise ValueError('Fichier invalide.')
        cle = self.key(path)
        with self.lock:
            self.breakpoints.discard((cle, int(line)))
            self._publier_points_arret()

    def _publier_points_arret(self):
        self.data['breakpoints'] = [
            {'path': c, 'line': l, 'resolvedLine': l}
            for c, l in sorted(self.breakpoints, key=lambda x: (x[0], x[1]))]

    def key(self, path):
        if not isinstance(path, str):
            return ''
        if path.startswith('file://'):
            import urllib.parse
            path = urllib.parse.unquote(urllib.parse.urlparse(path).path)
        racine = self.root.resolve()
        candidats = []
        try:
            candidats.append(Path(path).resolve())
        except (OSError, ValueError):
            pass
        try:
            candidats.append((self.root / path).resolve())
        except (OSError, ValueError):
            pass
        for p in candidats:
            try:
                return p.relative_to(racine).as_posix()
            except ValueError:
                continue
        for p in candidats:
            cle = next((k for k, v in self.external_files.items()
                        if Path(v).resolve() == p), '')
            if cle:
                return cle
        return ''

    def file(self, key):
        if not isinstance(key, str):
            raise ValueError('Fichier invalide.')
        if key.startswith('@external:'):
            p = self.external_files.get(key)
        else:
            p = (self.root / key).resolve()
        if p is None or not p.is_file():
            raise ValueError('Fichier de point d’arrêt invalide.')
        if not key.startswith('@external:') and not p.is_relative_to(self.root.resolve()):
            raise ValueError('Fichier de point d’arrêt invalide.')
        return Path(p).resolve()

    # -- démarrage ---------------------------------------------------------

    def start(self, kind, path, breakpoints=None):
        if self.data['active']:
            raise ValueError('Arrêtez la session de débogage en cours.')
        identifiant = langages.resoudre(kind) or kind
        pilote = _PILOTES.get(identifiant)
        if pilote is None:
            raise ValueError('Débogage instrumenté indisponible pour ce langage.')
        if not pilote.disponible():
            raise ValueError('%s est introuvable. Installez-le avec : %s'
                             % (pilote.binaire, pilote.installation))
        with self.lock:
            self.kind = identifiant
            self.breakpoints = set()
            for bp in breakpoints or []:
                if isinstance(bp, dict):
                    self.breakpoints.add((self.key(bp.get('path', '')),
                                          int(bp.get('line', 0))))
                elif isinstance(bp, (list, tuple)) and len(bp) == 2:
                    self.breakpoints.add((self.key(bp[0]), int(bp[1])))
            if not self.breakpoints:
                raise ValueError('Ajoutez un point d’arrêt dans la marge avant de déboguer.')
            self._publier_points_arret()
            self.data.update({'active': True, 'state': 'starting', 'reason': '',
                              'frame': None, 'frames': [], 'variables': [],
                              'output': '', 'message': ''})
            self.dossier = Path(tempfile.mkdtemp(prefix='ps-debog-'))
            self.canal = CanalDeControle(self.dossier)
            self.canal.ouvrir()
            commande, environnement = pilote.lancer(self, path)
            try:
                self.proc = subprocess.Popen(
                    commande, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT, cwd=str(self.root),
                    env=environnement, start_new_session=True, text=True,
                    errors='replace', bufsize=1)
            except OSError as e:
                self._nettoyer()
                raise ValueError('Impossible de lancer %s : %s' % (pilote.binaire, e))
            self.arrete.clear()
            self.lecteur = threading.Thread(target=self._boucle, daemon=True)
            self.lecteur.start()
            self.lecteur_sortie = threading.Thread(target=self._boucle_sortie,
                                                   daemon=True)
            self.lecteur_sortie.start()
            self.data['state'] = 'running'
            self.data['message'] = 'Exécution instrumentée en cours.'

    def _boucle_sortie(self):
        """Vide la sortie de l'enfant au fur et à mesure.

        Ce fil est le seul à fermer proc.stdout : TextIOWrapper.close() attend
        le verrou interne du fichier, que la lecture bloquante détient. Le
        fermer depuis stop() pendant cette lecture gèlerait les deux fils.
        """
        proc = self.proc
        if not proc or not proc.stdout:
            return
        try:
            for ligne in proc.stdout:
                with self.lock:
                    self.data['output'] = (self.data['output'] + ligne)[-LIMITE_SORTIE:]
        except (OSError, ValueError):
            pass
        finally:
            try:
                proc.stdout.close()
            except (OSError, ValueError):
                pass

    def _boucle(self):
        """Lit les événements de l'enfant jusqu'à la fin de la session."""
        while not self.arrete.is_set():
            ligne = self.canal.lire(0.25) if self.canal else None
            if ligne is None:
                if self.proc and self.proc.poll() is not None:
                    self._terminer()
                    return
                continue
            self._traiter(ligne)
            if self.data['state'] == 'exited':
                return

    def _traiter(self, ligne):
        ordre, _, reste = ligne.partition(' ')
        with self.lock:
            if ordre == 'OUT':
                self.data['output'] = (self.data['output'] + reste + '\n')[-LIMITE_SORTIE:]
            elif ordre == 'VAR':
                if len(self.data['variables']) < LIMITE_VARIABLES and reste:
                    nom, _, valeur = reste.partition('=')
                    if nom:
                        self.data['variables'].append(
                            {'name': nom, 'value': valeur[:LIMITE_VALEUR]})
            elif ordre == 'STOP':
                numero_brut, _, fonction = reste.partition(' ')
                try:
                    numero = int(numero_brut)
                except ValueError:
                    return
                fonction = fonction or 'main'
                cadre = self.data['frame']
                if cadre and cadre.get('line') == numero:
                    return
                self.data['state'] = 'paused'
                self.data['reason'] = 'breakpoint'
                self.data['frame'] = {'file': self._cle_courante(), 'line': numero,
                                      'function': fonction, 'level': '0'}
                self.data['frames'] = [self.data['frame']]
                self.data['variables'] = []
                self.data['message'] = 'Arrêt ligne %d.' % numero
            elif ordre == 'EVAL':
                self.pile.put(reste)
            elif ordre == 'EXIT':
                self.data['state'] = 'exited'
                self.data['reason'] = 'exited'
                self.data['message'] = 'Programme terminé.'
                self.data['active'] = False
                self._nettoyer()

    def _cle_courante(self):
        for cle, _ in sorted(self.breakpoints):
            if cle:
                return cle
        return ''

    def _terminer(self):
        with self.lock:
            if self.proc:
                code = self.proc.poll()
                self.data['state'] = 'exited'
                self.data['reason'] = 'exited'
                self.data['active'] = False
                self.data['message'] = ('Programme terminé (code %s).' % code
                                        if code is not None else 'Programme terminé.')
            self.proc = None
            self._nettoyer()

    @staticmethod
    def _fermer_flux(proc):
        """Ferme les tubes du processus : sinon ils fuient à chaque session.

        À n'appeler qu'APRÈS l'arrêt de l'enfant et la fin du fil de sortie.
        """
        if not proc:
            return
        for flux in (proc.stdin, proc.stderr, proc.stdout):
            try:
                if flux:
                    flux.close()
            except (OSError, ValueError):
                pass

    def _nettoyer(self):
        if self.canal:
            self.canal.fermer()
            self.canal = None
        if self.dossier:
            shutil.rmtree(self.dossier, ignore_errors=True)
            self.dossier = None

    # -- commandes ---------------------------------------------------------

    def action(self, name):
        with self.lock:
            if not self.data['active']:
                raise ValueError('Session de débogage inactive.')
            if name not in ('continue', 'next', 'step', 'finish', 'pause'):
                raise ValueError('Action de débogage inconnue.')
            if self.canal:
                self.canal.envoyer('next' if name == 'step' else name)
            if name in ('continue', 'next', 'step', 'finish'):
                self.data['state'] = 'running'
                self.data['reason'] = ''
                self.data['frame'] = None
                self.data['frames'] = []
                self.data['variables'] = []

    def evaluate(self, expression):
        with self.lock:
            if not self.data['active']:
                raise ValueError('Session de débogage inactive.')
            if self.canal:
                self.canal.envoyer('eval ' + str(expression))
        try:
            return self.pile.get(timeout=DELAI_ARRET)
        except queue.Empty:
            raise ValueError('Le programme n’a pas répondu à l’évaluation.')

    def input(self, text):
        with self.lock:
            if self.proc and self.proc.stdin:
                try:
                    self.proc.stdin.write(str(text) + '\n')
                    self.proc.stdin.flush()
                except (OSError, ValueError):
                    raise ValueError('Le programme n’accepte plus d’entrée.')

    def stop(self):
        with self.lock:
            self.arrete.set()
            proc = self.proc
            self.proc = None
            # D'abord un ordre propre : l'enfant est peut-être bloqué sur la
            # lecture d'une commande, « quit » le fait sortir sans signal.
            if self.canal:
                try:
                    self.canal.envoyer('quit')
                except Exception:
                    pass
            if proc and proc.poll() is None:
                try:
                    os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                    proc.wait(timeout=2)
                except Exception:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                        proc.wait(timeout=2)
                    except Exception:
                        pass
            self.data.update({'active': False, 'state': 'idle', 'reason': '',
                              'frame': None, 'frames': [], 'variables': [],
                              'message': ''})
        # Hors du verrou, et seulement APRÈS l'arrêt de l'enfant : fermer un
        # tube pendant que le fil de sortie le lit gèlerait les deux fils.
        for fil in (self.lecteur_sortie, self.lecteur):
            if fil is not None and fil.is_alive():
                fil.join(timeout=2)
        self._fermer_flux(proc)
        self._nettoyer()


class Pilote:
    """Comment instrumenter un interpréteur donné."""

    binaire = ''
    installation = ''

    def disponible(self):
        return shutil.which(self.binaire) is not None

    def lancer(self, debogueur, path):
        raise NotImplementedError


class PiloteBash(Pilote):
    binaire = 'bash'
    installation = 'sudo apt install bash'

    PRELUDE = r'''# Prélude de débogage Pascal Studio — ne pas modifier.
__PS_EVENEMENTS='@EVENEMENTS@'
__PS_COMMANDES='@COMMANDES@'
__PS_BP=' @POINTS@ '
__PS_PAS=0
__PS_DECALAGE=@DECALAGE@
# Les variables héritées de l'environnement ne sont pas celles du script :
# on les exclut pour que l'inspecteur reste lisible.
__PS_ENV=" $(env | cut -d= -f1 | tr '\n' ' ') "
exec 7>>"$__PS_EVENEMENTS"
exec 6<"$__PS_COMMANDES"
set -T
__ps_trace() {
  # « set -T » propage le trap jusque dans cette fonction : la garde évite
  # qu'elle ne se relance elle-même. Elle n'est posée QU'AU MOMENT de s'arrêter
  # et toujours relâchée ensuite : un retour anticipé avant cela ne doit rien
  # laisser bloqué, sinon plus aucun arrêt ne serait possible.
  [ -n "$__PS_DANS" ] && return 0
  local __l=$(( $1 - __PS_DECALAGE ))
  local __arret=0
  case " $__PS_BP " in
    *" $__l "*) __arret=1 ;;
  esac
  [ "$__PS_PAS" = "1" ] && __arret=1
  [ "$__arret" = "1" ] || return 0
  __PS_DANS=1
  # STOP d'abord, variables ensuite : le gestionnaire d'arrêt vide la liste
  # avant de la remplir, il faut donc que l'ordre soit celui-ci.
  printf 'STOP %s %s\n' "$__l" "${FUNCNAME[1]:-main}" >&7
  local __v __n
  __n=0
  for __v in $(compgen -v 2>/dev/null); do
    case "$__v" in
      __*|BASH*|FUNCNAME|DIRSTACK|GROUPS|HOSTNAME|HOSTTYPE|IFS|LINENO|EUID|UID|SHELLOPTS|PIPESTATUS|PPID|PS[0-9]|RANDOM|SRANDOM|SECONDS|_|MACHTYPE|OSTYPE|OPTARG|OPTIND|OPTERR|REPLY|OLDPWD|PWD|SHLVL|COMP_WORDBREAKS|EPOCHREALTIME|EPOCHSECONDS|HISTCMD|HISTFILE|HISTFILESIZE|HISTSIZE|TERM|TERMCAP|COLUMNS|LINES|EMACS|INFONANOS|LASTCMD) continue ;;
    esac
    case " $__PS_ENV " in *" $__v "*) continue ;; esac
    [ "$__n" -ge @LIMITE@ ] && break
    __n=$(( __n + 1 ))
    printf 'VAR %s=%s\n' "$__v" "$(printf '%s' "${!__v}" 2>/dev/null | head -c 200)" >&7
  done
  local __c
  while IFS= read -r -u 6 __c; do
    case "$__c" in
      continue|finish) __PS_PAS=0; break ;;
      next|step) __PS_PAS=1; break ;;
      eval\ *) printf 'EVAL %s\n' "$(eval "${__c#eval }" 2>&1 | head -c 200)" >&7 ;;
      quit) printf 'EXIT 0\n' >&7; kill -9 $$ 2>/dev/null; exit 0 ;;
    esac
  done
  __PS_DANS=
}
trap '__ps_trace "$LINENO"' DEBUG
'''

    def lancer(self, debogueur, path):
        source = _fichier_source(debogueur, path)
        lignes = _lignes_ciblees(debogueur, path)
        prelude = self.PRELUDE \
            .replace('@EVENEMENTS@', str(debogueur.canal.chemin_evenements)) \
            .replace('@COMMANDES@', str(debogueur.canal.chemin_commandes)) \
            .replace('@POINTS@', ' '.join(str(l) for l in lignes) or '0') \
            .replace('@LIMITE@', str(LIMITE_VARIABLES))
        # Le prélude occupe la ligne 1 ; le script original commence en ligne 2.
        nombre = prelude.count('\n')
        prelude = prelude.replace('@DECALAGE@', str(nombre))
        enveloppe = debogueur.dossier / 'session.sh'
        enveloppe.write_text(prelude + source.read_text('utf8', 'replace'),
                             encoding='utf8')
        return [self.binaire, str(enveloppe)], None


class PilotePerl(Pilote):
    binaire = 'perl'
    installation = 'sudo apt install perl'

    MODULE = r'''package Devel::PS;
use strict;
use warnings;
our $EVENEMENTS = '@EVENEMENTS@';
our $COMMANDES  = '@COMMANDES@';
our %POINTS     = (@POINTS@);
our $PAS        = 0;
our $EV; our $CMD;
open($EV,  '>>', $EVENEMENTS) or die "evenements: $!";
open($CMD, '<',  $COMMANDES)  or die "commandes: $!";
$EV->autoflush(1);

sub DB::DB {
    my (undef, $fichier, $ligne) = caller;
    return unless $POINTS{$ligne} || $PAS;
    my $paquet = (caller(0))[0] || 'main';
    no strict 'refs';
    my @noms = grep { /^[A-Za-z_][A-Za-z0-9_]*$/
                      && !/^__/
                      && !/^(ARGV|ARGVOUT|BEGIN|CHECK|END|ENV|INC|INIT|SIG|STDERR|STDIN|STDOUT|stderr|stdin|stdout)$/ }
               keys %{"${paquet}::"};
    print $EV "STOP $ligne main\n";
    my $n = 0;
    for my $nom (sort @noms) {
        last if $n >= @LIMITE@;
        my $valeur = '';
        eval {
            # « defined @tableau » est fatal en Perl moderne et « local *g »
            # se heurte à « use strict » : on prend une RÉFÉRENCE de glob,
            # qui se déréférence dans les trois sigles sans rien déclarer.
            my $g = do { no strict 'refs'; *{"${paquet}::$nom"} };
            if (defined $$g) {
                $valeur = substr($$g, 0, 200);
            } elsif (@$g) {
                $valeur = '[' . join(', ', map { defined $_ ? $_ : 'undef' } @$g) . ']';
            } elsif (%$g) {
                my %h = %$g;
                $valeur = '{' . join(', ', map { "$_=>" . (defined $h{$_} ? $h{$_} : 'undef') }
                                     sort keys %h) . '}';
            }
        };
        $valeur = '' unless defined $valeur;
        $valeur =~ s/[\r\n]+/ /g;
        print $EV "VAR $nom=" . substr($valeur, 0, 200) . "\n";
        $n++;
    }
    while (defined(my $ordre = <$CMD>)) {
        chomp $ordre;
        if ($ordre eq 'continue' || $ordre eq 'finish') { $PAS = 0; last }
        elsif ($ordre eq 'next' || $ordre eq 'step')     { $PAS = 1; last }
        elsif ($ordre =~ /^eval\s+(.*)$/) {
            my $expression = $1;
            my $r = eval "package $paquet; no strict; no warnings; $expression";
            $r = 'undef' unless defined $r;
            $r = $@ ? "erreur: $@" : $r;
            $r =~ s/[\r\n]+/ /g;
            print $EV 'EVAL ' . substr($r, 0, 200) . "\n";
        }
        elsif ($ordre eq 'quit') { print $EV "EXIT 0\n"; exit 0 }
    }
}
sub import { }
1;
'''

    def lancer(self, debogueur, path):
        source = _fichier_source(debogueur, path)
        lignes = _lignes_ciblees(debogueur, path)
        points = ', '.join('%d => 1' % l for l in lignes) or '0 => 0'
        module = self.MODULE \
            .replace('@EVENEMENTS@', str(debogueur.canal.chemin_evenements)) \
            .replace('@COMMANDES@', str(debogueur.canal.chemin_commandes)) \
            .replace('@POINTS@', points) \
            .replace('@LIMITE@', str(LIMITE_VARIABLES))
        dossier = debogueur.dossier / 'lib' / 'Devel'
        dossier.mkdir(parents=True, exist_ok=True)
        (dossier / 'PS.pm').write_text(module, encoding='utf8')
        return ([self.binaire, '-I', str(debogueur.dossier / 'lib'), '-d:PS',
                 str(source)], None)


class PiloteTrace(Pilote):
    """Exécution simple, sans pas à pas : pour les langages non instrumentables."""

    def __init__(self, binaire, installation, arguments):
        self.binaire = binaire
        self.installation = installation
        self.arguments = arguments

    def lancer(self, debogueur, path):
        source = _fichier_source(debogueur, path)
        return [self.binaire, *self.arguments, str(source)], None


_PILOTES = {
    'bash': PiloteBash(),
    'shell': PiloteBash(),
    'perl': PilotePerl(),
    'lua': PiloteTrace('lua5.4', INSTALLATIONS['lua'], []),
    'basic': PiloteTrace('yabasic', INSTALLATIONS['basic'], []),
    'ocaml': PiloteTrace('ocaml', INSTALLATIONS['ocaml'], []),
}


def _fichier_source(debogueur, path):
    """Le fichier à déboguer, qu'on reçoive un chemin absolu ou une clef."""
    p = Path(path)
    if p.is_absolute():
        if not p.is_file():
            raise ValueError('Fichier de point d’arrêt invalide.')
        return p
    return debogueur.file(debogueur.key(str(path)))


def _lignes_ciblees(debogueur, path):
    """Les lignes de point d'arrêt qui portent bien sur ce fichier."""
    return [l for c, l in sorted(debogueur.breakpoints)
            if _memes_fichiers(c, path, debogueur)]


def _memes_fichiers(cle_point, chemin_lance, debogueur):
    """Le point d'arrêt porte-t-il sur le fichier en cours de débogage ?"""
    if not cle_point:
        return False
    try:
        cible = debogueur.file(cle_point)
    except ValueError:
        return False
    try:
        lance = Path(chemin_lance)
        if not lance.is_absolute():
            lance = debogueur.file(debogueur.key(chemin_lance))
        return lance.resolve() == cible
    except (OSError, ValueError):
        return False


def pilote(kind):
    return _PILOTES.get(langages.resoudre(kind) or kind)


def _moteur_piet_texte(code, chemin):
    """Le moteur Piet alimenté par la SOURCE texte .piett (4.3.0).

    piet_texte.pas_a_pas() compile le texte en PNG puis rend une instance de
    langages_esoteriques.Piet arrêtée avant la première commande : c'est le MÊME
    moteur, inchangé, donc le pas à pas, la pile et l'inspecteur visuel viennent
    avec. Aucun second interpréteur n'est introduit ici.

    Les diagnostics de décodage sont rendus en premier : un texte refusé ne doit
    surtout pas produire un PNG vide que le moteur croirait valide, ce qui
    donnerait « programme terminé sans erreur » à la place de la vraie raison.
    """
    try:
        import piet_texte
    except ImportError:
        raise ValueError('Module piet_texte introuvable : le débogage des '
                         'sources .piett est indisponible.')
    texte = code if isinstance(code, str) else ''
    decode = piet_texte.decoder(texte)
    diagnostics = list(decode.get('diagnostics', []))
    moteur = piet_texte.pas_a_pas(texte, chemin=str(chemin)) if decode.get('ok') else None
    return moteur, diagnostics


def _esoteriques():
    """Charge le module des moteurs ésotériques, ou rend None s'il manque.

    L'import est paresseux pour deux raisons : ce module fait plus de deux cent
    mille octets, et surtout le débogueur universel reste utilisable pour les
    vingt-neuf autres langages si jamais il est absent.
    """
    try:
        import langages_esoteriques
    except Exception:
        return None
    return langages_esoteriques


class DebogueurEsoterique(DebogueurInstrumente):
    """Pas à pas réel des dix langages ésotériques, sans processus enfant.

    Les moteurs de langages_esoteriques.py sont des machines à pas NATIVES :
    pas() exécute exactement une instruction et rend False quand le programme est
    terminé. Aucune sonde n'est injectée, aucun processus n'est créé, aucun
    interpréteur externe n'est requis — ce qui est décisif, puisqu'aucun de ces
    dix langages n'est paqueté pour Debian 13.

    L'héritage de DebogueurInstrumente ne sert qu'à réutiliser l'interface
    attendue par l'interface graphique, inchangée : key(), file(),
    add_breakpoint(), remove_breakpoint(), _publier_points_arret() et
    snapshot(). Tout ce qui suppose un processus enfant est remplacé.

    Deux choix assumés, qui diffèrent du débogage instrumenté :

    * Aucun point d'arrêt n'est exigé au démarrage. La session s'ouvre arrêtée
      AVANT la première instruction, ce qui montre l'état initial — pour
      FRACTRAN, dont le résultat est l'état et qui n'imprime rien, c'est la
      seule façon utile de commencer. Les points d'arrêt restent honorés.
    * « next » et « step » font la même chose. Ces moteurs rendent un seul cadre
      d'appel : il n'y a pas de pas-à-pas « par-dessus » à distinguer. « finish »
      va jusqu'à la fin du programme.
    """

    # Nombre d'instructions qu'une seule action peut exécuter. « continue » doit
    # pouvoir aller au bout d'un programme, mais pas immobiliser le serveur quand
    # le programme ne termine jamais — cas courant ici, le « cat » publié de
    # Malbolge émet indéfiniment le caractère 168 une fois l'entrée épuisée.
    PAS_PAR_ACTION = 200_000

    def __init__(self, root, external_files=None):
        super().__init__(root, external_files)
        self.moteur = None
        self.identifiant = ''
        self.cle = ''
        # Piet est une image : la surcouche surligne le bloc de couleur en cours,
        # il lui faut donc son rectangle en pixels à chaque pas. None ailleurs.
        self.data['visuel'] = None

    # -- chargement du programme ---------------------------------------------

    def _lire_programme(self, path):
        """Lit le programme à déboguer. Renvoie (code, cle, chemin).

        Piet est un cas à part : son programme EST un PNG binaire. Le lire en
        texte avec un remplacement d'octets invalides détruirait l'image, donc le
        fichier est lu en octets puis porté en data URI, la forme que le moteur
        sait décoder.
        """
        cle = self.key(path) if isinstance(path, str) else ''
        chemin = None
        if cle:
            try:
                chemin = self.file(cle)
            except ValueError:
                chemin = None
        if chemin is None:
            chemin = Path(path)
        if not chemin.is_file():
            raise ValueError('Fichier introuvable : %s' % path)
        donnees = chemin.read_bytes()
        if self.identifiant == 'piet':
            return ('data:image/png;base64,'
                    + base64.b64encode(donnees).decode('ascii')), cle, chemin
        return donnees.decode('utf8', 'replace'), cle, chemin

    # -- démarrage -----------------------------------------------------------

    def start(self, kind, path, breakpoints=None):
        if self.data['active']:
            raise ValueError('Arrêtez la session de débogage en cours.')
        esoteriques = _esoteriques()
        if esoteriques is None:
            raise ValueError('Module langages_esoteriques introuvable : le '
                             'débogage intégré de ce langage est indisponible.')
        identifiant = langages.resoudre(kind) or kind
        # « piet_texte » n'est pas dans MOTEURS : ce n'est pas un onzième
        # langage ésotérique, c'est la SOURCE du dixième. Son moteur est celui de
        # Piet, atteint par piet_texte.pas_a_pas() — voir _moteur_piet_texte().
        if not (esoteriques.est_esoterique(identifiant)
                or identifiant == 'piet_texte'):
            raise ValueError('Débogage intégré indisponible pour ce langage.')
        self.identifiant = identifiant
        code, cle, chemin = self._lire_programme(path)
        with self.lock:
            self.kind = identifiant
            self.cle = cle
            self.breakpoints = set()
            for bp in breakpoints or []:
                if isinstance(bp, dict):
                    self.breakpoints.add((self.key(bp.get('path', '') or cle),
                                          int(bp.get('line', 0))))
                elif isinstance(bp, (list, tuple)) and len(bp) == 2:
                    self.breakpoints.add((self.key(bp[0] or cle), int(bp[1])))
            self._publier_points_arret()

            if identifiant == 'piet_texte':
                moteur, diagnostics = _moteur_piet_texte(code, chemin)
                if moteur is not None:
                    moteur.diagnostiques.extend(diagnostics)
            else:
                classe = esoteriques.moteur(identifiant)
                if classe is None:
                    raise ValueError('Aucun moteur intégré pour « %s ».' % identifiant)
                # Le moteur est construit directement, sans passer par
                # pas_a_pas() : cette fonction appelle charger() et jette les
                # diagnostics, or charger() n'est pas idempotent (il alimente la
                # liste des fractions d'un programme FRACTRAN, qui serait donc
                # doublée au second appel). Pour « piet_texte », au contraire,
                # pas_a_pas() EST le bon chemin : il compile le texte en PNG et
                # ne rejoue rien.
                moteur = classe(code, chemin=str(chemin))
                diagnostics = moteur.charger()
                moteur.diagnostiques.extend(diagnostics)
            erreurs = [d for d in diagnostics
                       if d.get('severity') == 'error']
            if moteur is None or erreurs:
                raise ValueError('Programme refusé : %s' % '; '.join(
                    '%s (ligne %s)' % (d.get('message', ''), d.get('line', '?'))
                    for d in (erreurs or [{'message': 'aucune grille lisible '
                                          'dans cette source .piett'}])[:3]))
            self.moteur = moteur
            self.data.update({'active': True, 'state': 'paused', 'reason': 'step',
                              'frame': None, 'frames': [], 'variables': [],
                              'output': '', 'message': ''})
            self._publier('step', 'Session ouverte avant la première instruction.')

    # -- publication de l'état ------------------------------------------------

    def _cadre(self):
        ligne, _colonne = self.moteur.position
        return {'file': self.cle, 'line': int(ligne),
                'function': (getattr(self.moteur, 'libelle', None)
                             or self.identifiant),
                'level': '0'}

    def _publier(self, raison='step', message=''):
        """Écrit l'état du moteur dans l'instantané, sous verrou."""
        cadre = self._cadre()
        self.data['state'] = 'paused'
        self.data['reason'] = raison
        self.data['frame'] = cadre
        self.data['frames'] = [cadre]
        self.data['variables'] = [
            {'name': str(v.get('name', '')),
             'value': str(v.get('value', ''))[:LIMITE_VALEUR]}
            for v in self.moteur.variables()[:LIMITE_VARIABLES]]
        self.data['output'] = self.moteur.sortie[-LIMITE_SORTIE:]
        self.data['message'] = message or (
            'Arrêt ligne %d — %d instruction(s) exécutée(s).'
            % (cadre['line'], self.moteur.pas_fait))
        self.data['visuel'] = self._bloc_actif()

    def _fini(self, message=''):
        compte = self.moteur.compte_rendu()
        self.data['state'] = 'exited'
        self.data['reason'] = 'exited'
        self.data['active'] = False
        self.data['frame'] = None
        self.data['frames'] = []
        self.data['output'] = self.moteur.sortie[-LIMITE_SORTIE:]
        # Les variables finales sont CONSERVÉES : pour FRACTRAN le résultat est
        # l'état n, et pour Brainfuck c'est le contenu du ruban. Les effacer
        # comme le fait le débogueur instrumenté priverait l'utilisateur du seul
        # résultat qui compte.
        self.data['variables'] = [
            {'name': str(v.get('name', '')),
             'value': str(v.get('value', ''))[:LIMITE_VALEUR]}
            for v in self.moteur.variables()[:LIMITE_VARIABLES]]
        self.data['message'] = message or compte.get('message') or 'Programme terminé.'

    def _bloc_actif(self):
        """Le bloc de couleur en cours, pour surligner l\'image Piet.

        Seul le moteur Piet expose `bloc_actif()` ; les neuf autres n\'ont rien à
        montrer dans un aperçu. Un moteur en état incohérent ne doit pas faire
        tomber la publication : on rend None et la session continue.
        """
        bloc = getattr(self.moteur, 'bloc_actif', None)
        if not callable(bloc):
            return None
        try:
            return bloc()
        except Exception:
            return None

    def _sur_point_arret(self):
        if not self.breakpoints or not self.cle:
            return False
        ligne = int(self.moteur.position[0])
        return any(cle == self.cle and numero == ligne
                   for cle, numero in self.breakpoints)

    def _capacite(self, debordement):
        self.data.update({'state': 'exited', 'reason': 'exited', 'active': False,
                          'frame': None, 'frames': [],
                          'message': ('Capacité dépassée : %s. Exécution '
                                      'interrompue pour protéger la mémoire.'
                                      % debordement)})

    # -- actions --------------------------------------------------------------

    def _un_pas(self):
        if self.moteur.termine:
            return self._fini()
        if not self.moteur.pas():
            return self._fini()
        if self.moteur.termine:
            return self._fini()
        if self._sur_point_arret():
            return self._publier('breakpoint', 'Arrêt sur un point d’arrêt, ligne %d.'
                                 % int(self.moteur.position[0]))
        self._publier('step')

    def _avancer(self, jusquau_bout=False):
        """« continue » s'arrête au prochain point d'arrêt ; « finish » va au bout."""
        esoteriques = _esoteriques()
        budget = self.PAS_PAR_ACTION
        plafond = getattr(esoteriques, 'LIMITE_PAS', budget)
        while (not self.moteur.termine and budget > 0
               and self.moteur.pas_fait < plafond):
            if not self.moteur.pas():
                break
            budget -= 1
            if not jusquau_bout and self._sur_point_arret():
                return self._publier(
                    'breakpoint', 'Arrêt sur un point d’arrêt, ligne %d.'
                    % int(self.moteur.position[0]))
        if self.moteur.termine:
            return self._fini()
        if self.moteur.pas_fait >= plafond:
            return self._fini('Limite de %d instructions atteinte : exécution '
                              'interrompue.' % plafond)
        # Budget de l'action épuisé avant la fin du programme : on rend la main
        # en montrant où l'on est, plutôt que de laisser croire à un blocage.
        self._publier('step', 'Encore en cours après %d instructions — '
                              'relancez « continuer » pour poursuivre.'
                      % self.PAS_PAR_ACTION)

    def action(self, name):
        with self.lock:
            if not self.data['active'] or self.moteur is None:
                raise ValueError('Session de débogage inactive.')
            if name not in ('continue', 'next', 'step', 'finish', 'pause'):
                raise ValueError('Action de débogage inconnue.')
            if name == 'pause':
                self.data['message'] = ('Le moteur intégré s’arrête déjà après '
                                        'chaque instruction : il n’y a rien à '
                                        'suspendre.')
                return
            esoteriques = _esoteriques()
            try:
                if name in ('step', 'next'):
                    self._un_pas()
                elif name == 'finish':
                    self._avancer(jusquau_bout=True)
                else:
                    self._avancer()
            except Exception as exc:
                debordement = getattr(esoteriques, 'DebordementCapacite', None)
                if debordement is not None and isinstance(exc, debordement):
                    return self._capacite(exc)
                raise

    # -- évaluation et entrée -------------------------------------------------

    def evaluate(self, expression):
        """Rend la valeur d'une variable du moteur, par nom exact puis partiel.

        Ces langages n'ont pas d'expressions évaluables à la volée : il n'y a ni
        opérateur ni fonction dans la plupart d'entre eux. Ce qui a du sens, et
        qui est réellement utile, c'est de demander la valeur d'un élément que
        l'inspecteur affiche — « pile[0] », « n (état) », « A (accumulateur) ».
        """
        with self.lock:
            if not self.data['active'] or self.moteur is None:
                raise ValueError('Session de débogage inactive.')
            nom = str(expression).strip()
            if not nom:
                raise ValueError('Expression vide.')
            variables = self.moteur.variables()
            for variable in variables:
                if str(variable.get('name', '')) == nom:
                    return str(variable.get('value', ''))
            for variable in variables:
                if nom in str(variable.get('name', '')):
                    return str(variable.get('value', ''))
            raise ValueError('Aucune variable nommée « %s » dans ce moteur. '
                             'Disponibles : %s'
                             % (nom, ', '.join(str(v.get('name', ''))
                                               for v in variables[:8]) or 'aucune'))

    def input(self, text):
        """Fournit de l'entrée standard à un programme arrêté sur une lecture."""
        with self.lock:
            if self.moteur is None:
                raise ValueError('Session de débogage inactive.')
            texte = str(text)
            if not texte.endswith('\n'):
                texte += '\n'
            entree = getattr(self.moteur, 'entree', None)
            if entree is None or not entree.ajouter(texte):
                raise ValueError('L’entrée standard de ce programme est pleine '
                                 '(borne atteinte) : le texte n’a pas été ajouté.')

    # -- arrêt -----------------------------------------------------------------

    def stop(self):
        with self.lock:
            self.moteur = None
            self.identifiant = ''
            self.cle = ''
            self.arrete.set()
            self.data.update({'active': False, 'state': 'idle', 'reason': '',
                              'frame': None, 'frames': [], 'variables': [],
                              'output': '', 'message': '', 'visuel': None})
