"""Single IDE-facing session shared by GDB, Python, Node, Xdebug and DAP.

Le choix du moteur ne dépend plus d'une liste de langages codée en dur : il
suit le registre (langages.py) via debogueur_universel.mode(). La convention
d'appel de start() diffère d'un moteur à l'autre ; demarrer() la centralise,
pour que server.py n'ait plus à la connaître.
"""
from debugger import Debugger
from script_debugger import ScriptDebugger
from php_debugger import PhpDebugger
from dap_debugger import DapDebugger
import debogueur_universel
from debogueur_universel import DebogueurInstrumente, DebogueurEsoterique

def esoterique(kind):
 """Vrai pour les dix langages dont le moteur est écrit dans Pascal Studio.

 Le test passe par le registre des moteurs ésotériques et non par mode() : Piet
 est en mode visuel, les neuf autres en mode réel, donc aucun des deux modes ne
 les identifie tous. La fonction est publique parce que server.py en a besoin
 autant que le multiplexeur : sans elle, la route /api/debug/start enverrait un
 .bf se faire compiler, et refuserait Piet au titre de langage « visuel », alors
 même que capacites() y annonce le pas à pas, les variables et la pile.
 """
 try:
  import langages_esoteriques
 except Exception:
  return False
 ident=debogueur_universel.langages.resoudre(kind) or kind
 # 4.3.0 : « piet_texte » (.piett) n'est pas un onzième langage ésotérique,
 # c'est la SOURCE du dixième. Elle n'est donc pas dans MOTEURS, mais son pas à
 # pas passe par le moteur Piet existant (debogueur_universel._moteur_piet_texte
 # compile le texte en PNG). Sans cette ligne, le multiplexeur enverrait un
 # .piett se faire compiler par gdb alors que la route HTTP, elle, l'accepterait
 # — et c'est exactement la divergence que cette fonction publique empêche.
 return langages_esoteriques.est_esoterique(ident) or ident=='piet_texte'

class DebuggerMux:
 def __init__(self,root,external_files=None):
  self.root=root;self.external_files=external_files if external_files is not None else {}
  self.current=Debugger(root,self.external_files)
 def select(self,kind):
  if self.current.snapshot()['active']:raise ValueError('Arrêtez la session de débogage en cours.')
  if self._esoterique(kind):
   self.current=DebogueurEsoterique(self.root,self.external_files);return
  if debogueur_universel.mode(kind)==debogueur_universel.MODE_INSTRUMENTE:
   self.current=DebogueurInstrumente(self.root,self.external_files);return
  cls=ScriptDebugger if kind in ('python','javascript') else PhpDebugger if kind=='php' else DapDebugger if kind in ('go','ruby','swift','kotlin') else Debugger
  self.current=cls(self.root,self.external_files)
 def _esoterique(self,kind):
  """Voir la fonction publique esoterique() : le routage et la route HTTP
  doivent répondre la même chose, sinon l'un accepte ce que l'autre refuse."""
  return esoterique(kind)

 def demarrer(self,kind,path,breakpoints,binaire=None,dossier=None):
  """Démarre la session selon la convention propre au moteur retenu."""
  mode=debogueur_universel.mode(kind)
  if self._esoterique(kind):
   # Aucun processus, aucun binaire : le moteur est une machine à pas native.
   self.current.start(kind,path,breakpoints)
  elif mode==debogueur_universel.MODE_INSTRUMENTE:
   self.current.start(kind,path,breakpoints)
  elif kind in ('python','javascript'):
   self.current.start(kind,path,breakpoints)
  elif kind=='php':
   self.current.start(path,breakpoints)
  elif kind=='ruby':
   self.current.start('ruby',path,breakpoints)
  elif kind=='go':
   self.current.start('go',binaire,breakpoints,str(dossier))
  elif kind in ('swift','kotlin'):
   adaptateurs=debogueur_universel.langages.adaptateurs_dap(kind)
   if not adaptateurs:raise ValueError(debogueur_universel.capacites(kind)['explication'])
   self.current.start(kind,path,breakpoints)
  else:
   if not binaire:raise ValueError('Programme compilé introuvable.')
   if kind in ('rust','fortran'):self.current.start(binaire,breakpoints,str(dossier))
   else:self.current.start(binaire,breakpoints)
 def snapshot(self):return self.current.snapshot()
 def start(self,*args):return self.current.start(*args)
 def action(self,*args):return self.current.action(*args)
 def add_breakpoint(self,*args):return self.current.add_breakpoint(*args)
 def remove_breakpoint(self,*args):return self.current.remove_breakpoint(*args)
 def evaluate(self,*args):return self.current.evaluate(*args)
 def input(self,*args):return self.current.input(*args)
 def stop(self,*args,**kwargs):return self.current.stop(*args,**kwargs)
