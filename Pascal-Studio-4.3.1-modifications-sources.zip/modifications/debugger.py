"""One local GDB/MI session, with a separate PTY for the inferior's console."""
import ast, json, os, pty, queue, re, shutil, subprocess, termios, threading
from pathlib import Path


def parse_mi(text):
    """Parse the MI result grammar, retaining lists and nested tuples."""
    i=0
    def string():
        nonlocal i
        start=i; i+=1; escape=False
        while i<len(text):
            c=text[i]; i+=1
            if c=='"' and not escape: break
            if c=='\\' and not escape: escape=True
            else: escape=False
        try: return ast.literal_eval(text[start:i])
        except Exception: return text[start+1:i-1]
    def value():
        nonlocal i
        if i>=len(text): return ''
        if text[i]=='"': return string()
        if text[i] in '{[':
            end='}' if text[i]=='{' else ']'; isdict=text[i]=='{'; i+=1; items=[]
            while i<len(text) and text[i]!=end:
                start=i
                while i<len(text) and (text[i].isalnum() or text[i] in '_-'): i+=1
                if i<len(text) and text[i]=='=':
                    key=text[start:i]; i+=1; items.append((key,value()))
                else:
                    i=start; items.append(value())
                if i<len(text) and text[i]==',': i+=1
                else: break
            if i<len(text) and text[i]==end: i+=1
            if isdict: return dict(items)
            return items
        start=i
        while i<len(text) and text[i] not in ',}]': i+=1
        return text[start:i]
    return value()

def q(value): return json.dumps(str(value), ensure_ascii=True)

class Debugger:
    def __init__(self, root, external_files=None):
        self.root=Path(root).resolve(); self.external_files=external_files if external_files is not None else {}; self.lock=threading.RLock(); self.sendlock=threading.Lock(); self.stoplock=threading.Lock()
        self.proc=None; self.master=None; self.pending={}; self.counter=0; self.bpmap={}
        self.data={'active':False,'state':'idle','reason':'','frame':None,'frames':[], 'variables':[], 'output':'','message':'','breakpoints':[]}
    def snapshot(self):
        with self.lock: return dict(self.data)
    def command(self, command, timeout=8):
        with self.lock:
            if not self.proc or self.proc.poll() is not None: raise ValueError('Aucune session GDB active.')
            self.counter+=1; token=str(self.counter); response=queue.Queue(maxsize=1); self.pending[token]=response
        try:
            with self.sendlock:
                self.proc.stdin.write(token+command+'\n'); self.proc.stdin.flush()
            try: result=response.get(timeout=timeout)
            except queue.Empty: raise ValueError('GDB ne répond pas à la commande.')
            if result[0]=='error': raise ValueError(result[1].get('msg','Erreur GDB'))
            return result[1]
        finally:
            with self.lock: self.pending.pop(token,None)
    def read_gdb(self,p):
        for raw in p.stdout:
            with self.lock:
                if self.proc is not p: return
            line=raw.rstrip('\r\n')
            m=re.match(r'^(\d+)\^(\w+)(?:,(.*))?$',line)
            if m:
                try: payload=parse_mi('{'+(m.group(3) or '')+'}')
                except Exception: payload={}
                with self.lock: waiter=self.pending.get(m.group(1))
                if waiter: waiter.put((m.group(2),payload))
            elif line.startswith('*running'):
                with self.lock: self.data.update(state='running',frame=None,frames=[],variables=[])
            elif line.startswith('*stopped'):
                try: payload=parse_mi('{'+line.partition(',')[2]+'}')
                except Exception: payload={}
                reason=payload.get('reason','stopped'); frame=payload.get('frame')
                with self.lock:
                    if reason.startswith('exited'):
                        self.data.update(state='finished',reason=reason,frame=None,frames=[],variables=[])
                    else: self.data.update(state='paused',reason=reason,frame=self.clean_frame(frame),frames=[],variables=[])
                if reason.startswith('exited'): threading.Thread(target=self.stop,kwargs={'finished':True,'expected':p},daemon=True).start()
                else: threading.Thread(target=self.inspect,daemon=True).start()
            elif line.startswith('&'):
                try: message=ast.literal_eval(line[1:]).strip()
                except Exception: message=''
                if message:
                    with self.lock: self.data['message']=message
        with self.lock:
            if self.proc is p: self.data.update(active=False,state='finished' if self.data['state']=='finished' else 'idle')
    def clean_frame(self,f):
        if not isinstance(f,dict): return None
        path=f.get('fullname') or f.get('file','')
        try:
            absolute=Path(path).resolve()
            try: path=absolute.relative_to(self.root).as_posix()
            except ValueError: path=next((k for k,v in self.external_files.items() if v==absolute),'')
        except OSError: path=''
        return {'file':path,'line':int(f.get('line','0') or '0'),'function':f.get('func','?'),'level':f.get('level','0')}
    def inspect(self):
        try:
            variables=self.command('-stack-list-variables --all-values').get('variables',[])
            stack=self.command('-stack-list-frames').get('stack',[])
            frames=[self.clean_frame(item[1]) for item in stack if isinstance(item,tuple) and item[0]=='frame']
            with self.lock:
                if self.data['state']=='paused': self.data.update(variables=variables,frames=frames)
        except Exception as e:
            with self.lock: self.data['message']=str(e)
    def start(self,binary,breakpoints,cwd=None):
        if self.data['active']: raise ValueError('Arrêtez la session de débogage en cours.')
        gdb=shutil.which('gdb')
        if not gdb: raise ValueError('GDB est introuvable. Installez-le avec : sudo apt install gdb')
        self.master,slave=pty.openpty(); attrs=termios.tcgetattr(slave); attrs[3]&=~termios.ECHO; termios.tcsetattr(slave,termios.TCSANOW,attrs)
        tty=os.ttyname(slave)
        try:
            self.proc=subprocess.Popen([gdb,'--quiet','--nx','--interpreter=mi2'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,bufsize=1,text=True,errors='replace',cwd=Path(cwd).resolve() if cwd else self.root,start_new_session=True)
        except Exception:
            os.close(slave); os.close(self.master); raise
        p=self.proc; master=self.master
        with self.lock:
            self.bpmap={}; self.data.update(active=True,state='starting',reason='',frame=None,frames=[],variables=[],output='',message='',breakpoints=[])
        p.reader=threading.Thread(target=self.read_gdb,args=(p,),daemon=True); p.reader.start()
        def console():
            try:
                while True:
                    try: chunk=os.read(master,4096)
                    except OSError: break
                    if not chunk: break
                    with self.lock:
                        if self.proc is p: self.data['output']+=chunk.decode('utf-8','replace').replace('\r\n','\n')
            finally:
                try: os.close(master)
                except OSError: pass
        threading.Thread(target=console,daemon=True).start()
        try:
            self.command('-gdb-set pagination off'); self.command('-gdb-set confirm off'); self.command('-gdb-set mi-async on')
            self.command('-file-exec-and-symbols '+q(binary))
            self.command('-inferior-tty-set '+q(tty))
            for bp in breakpoints: self.add_breakpoint(bp['path'],bp['line'])
            if not breakpoints: raise ValueError("Ajoutez au moins un point d'arrêt dans la marge avant de déboguer.")
            self.command('-exec-run')
        except Exception:
            self.stop(); raise
        finally: os.close(slave)
    def add_breakpoint(self,path,line):
        p=self.external_files.get(path) if path.startswith('@external:') else (self.root/path).resolve()
        if p is None or (not path.startswith('@external:') and not p.is_relative_to(self.root)) or not p.is_file(): raise ValueError('Fichier de point d’arrêt invalide.')
        line=int(line)
        if line<1: raise ValueError('Ligne invalide.')
        key=(path,line)
        if key in self.bpmap: return
        result=self.command('-break-insert '+q(str(p)+':'+str(line)))
        bkpt=result.get('bkpt',{}); self.bpmap[key]={'number':bkpt.get('number'), 'resolvedLine':int(bkpt.get('line',line))}
        with self.lock: self.data['breakpoints']=[{'path':k[0],'line':k[1], 'resolvedLine':v['resolvedLine']} for k,v in self.bpmap.items()]
    def remove_breakpoint(self,path,line):
        key=(path,int(line)); bp=self.bpmap.get(key)
        if bp and bp['number']: self.command('-break-delete '+str(bp['number'])); self.bpmap.pop(key,None)
        with self.lock: self.data['breakpoints']=[{'path':k[0],'line':k[1], 'resolvedLine':v['resolvedLine']} for k,v in self.bpmap.items()]
    def action(self,action):
        mapping={'continue':'-exec-continue','next':'-exec-next','step':'-exec-step','finish':'-exec-finish','pause':'-exec-interrupt --all'}
        if action not in mapping: raise ValueError('Commande de débogage invalide.')
        self.command(mapping[action])
    def evaluate(self,expression):
        if self.data['state'] != 'paused': raise ValueError("Mettez le programme en pause avant d’évaluer une expression.")
        if not expression.strip() or '\n' in expression: raise ValueError('Expression invalide.')
        return self.command('-data-evaluate-expression '+q(expression)).get('value','')
    def input(self,text):
        if self.data['state']!='running': raise ValueError("Le programme n'est pas en cours d'exécution.")
        os.write(self.master,(text+'\n').encode())
        with self.lock: self.data['output']+=text+'\n'
    def stop(self, finished=False, expected=None):
        # Serialize automatic and explicit shutdown; an old session must never
        # close a newer GDB started just after the inferior exited.
        with self.stoplock:
            p=self.proc
            if expected is not None and p is not expected: return
            if p and p.poll() is None:
                try: self.command('-gdb-exit',timeout=2)
                except Exception: pass
                try: p.wait(timeout=2)
                except subprocess.TimeoutExpired: p.kill(); p.wait()
            if p:
                reader=getattr(p,'reader',None)
                if reader and reader is not threading.current_thread(): reader.join(timeout=1)
                for stream in (p.stdin,p.stdout):
                    try: stream.close()
                    except (OSError,ValueError): pass
            with self.lock:
                if self.proc is p:
                    self.data.update(active=False,state='finished' if finished else 'idle',frame=None,frames=[],variables=[])
