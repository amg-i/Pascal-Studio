const {app, BrowserWindow, dialog, shell, ipcMain, clipboard} = require('electron');
const {spawn} = require('child_process');
const fs = require('fs');
const path = require('path');
const net = require('net');
const http = require('http');
let server, window, allowWindowClose=false, pendingClose=0, closeSerial=0, closeTimer=null;
function requestSafeClose(){
 if(!window||allowWindowClose||pendingClose)return;const id=++closeSerial;pendingClose=id;window.webContents.send('documents:request-close',id);
 closeTimer=setTimeout(async()=>{if(!window||pendingClose!==id)return;const result=await dialog.showMessageBox(window,{type:'warning',title:'Fermeture en attente',message:'L’enregistrement ne répond pas. Fermer malgré le risque de perdre des modifications ?',buttons:['Annuler la fermeture','Fermer sans attendre'],defaultId:0,cancelId:0});if(pendingClose!==id)return;pendingClose=0;if(result.response===1){allowWindowClose=true;window.close()}},12000);
}
function freePort(){return new Promise((resolve,reject)=>{const s=net.createServer();s.on('error',reject);s.listen(0,'127.0.0.1',()=>{const p=s.address().port;s.close(()=>resolve(p))})})}
function waitUntilReady(port,child){return new Promise((resolve,reject)=>{const start=Date.now();function ping(){if(child.exitCode!==null)return reject(new Error('Le serveur Python s’est arrêté.'));http.get(`http://127.0.0.1:${port}/api/status`,r=>{r.resume();r.statusCode===200?resolve():retry()}).on('error',retry)}function retry(){if(Date.now()-start>15000)reject(new Error('Le serveur Python ne répond pas.'));else setTimeout(ping,180)}ping()})}
app.whenReady().then(async()=>{
 try{
  const resources=app.isPackaged?process.resourcesPath:path.resolve(__dirname,'..');
  const prefsPath=path.join(app.getPath('userData'),'project.json');
  let prefs={}; try{prefs=JSON.parse(fs.readFileSync(prefsPath,'utf8'))}catch{}
  let remembered=prefs.workspace;
  const project=process.env.PASCAL_WORKSPACE || (remembered&&fs.existsSync(remembered)?remembered:null) || path.join(app.getPath('documents'),'Pascal Studio');
  ipcMain.handle('project:choose-file',async()=>{const r=await dialog.showOpenDialog(window,{title:'Ouvrir un fichier',properties:['openFile'],filters:[{name:'Sources, projets et Markdown',extensions:['pas','pp','p','lpr','inc','c','h','cc','cpp','cxx','hpp','cs','csproj','cmake','mk','md','txt','tex','sty','pdf','psnote','py','rs','go','rb','js','mjs','cjs','html','htm','css','php','db','db3','sqlite','sqlite3','csv','tsv','json','sql','pem','crt','cer']},{name:'Tous les fichiers',extensions:['*']}]});return r.canceled?null:r.filePaths[0]});
  ipcMain.handle('accounts:browser-login',async(_event,provider)=>{
    if(!['github','gitlab'].includes(provider))throw new Error('Service inconnu.');
    const executable=provider==='github'?'gh':'glab';
    const {spawnSync}=require('child_process');
    if(spawnSync('which',[executable],{encoding:'utf8'}).status!==0)throw new Error('Installez '+executable+' avant la connexion navigateur.');
    if(provider==='gitlab'){
      const help=spawnSync('glab',['auth','login','--help'],{encoding:'utf8'});
      if(!((help.stdout||'').includes('--web')))throw new Error('Cette version de glab ne prend pas en charge la connexion navigateur. Mettez glab à jour ou utilisez un jeton personnel.');
    }
    const args=provider==='github'?['gh','auth','login','--hostname','github.com','--web','--git-protocol','https']:['glab','auth','login','--hostname','gitlab.com','--web','--git-protocol','https'];
    return await new Promise((resolve,reject)=>{const child=spawn('x-terminal-emulator',['-e',...args],{stdio:'ignore'});child.on('error',()=>reject(new Error('Impossible d’ouvrir un terminal.')));child.on('close',code=>code===0?resolve(true):reject(new Error('Connexion annulée ou non terminée.')))});
  });
  ipcMain.handle('clipboard:read',()=>clipboard.readText());
  ipcMain.handle('clipboard:write',(_event,text)=>clipboard.writeText(String(text)));
  ipcMain.handle('project:choose-directory',async(_event,kind)=>{const r=await dialog.showOpenDialog(window,{title:kind==='open'?'Ouvrir un dossier de projet':'Choisir le dossier parent du nouveau projet',properties:['openDirectory','createDirectory']});return r.canceled?null:r.filePaths[0]});
  ipcMain.handle('project:recent',()=>[...new Set([prefs.workspace,...(prefs.recent||[])].filter(p=>typeof p==='string'&&fs.existsSync(p)))].slice(0,8));
  ipcMain.handle('project:remember',async(_event,workspace)=>{if(typeof workspace!=='string'||!path.isAbsolute(workspace)||!fs.existsSync(workspace))throw new Error('Projet invalide');prefs={workspace,recent:[...new Set([workspace,prefs.workspace,...(prefs.recent||[])].filter(Boolean))].slice(0,8)};fs.mkdirSync(path.dirname(prefsPath),{recursive:true});fs.writeFileSync(prefsPath,JSON.stringify(prefs));return prefs.recent});
  const fresh=!fs.existsSync(project);fs.mkdirSync(project,{recursive:true});
  const sample=path.join(resources,app.isPackaged?'sample':'workspace');
  if(fresh && fs.existsSync(sample))for(const name of ['main.pas','README.md']){let src=path.join(sample,name),dest=path.join(project,name);if(fs.existsSync(src)&&!fs.existsSync(dest))fs.copyFileSync(src,dest)}
  const port=await freePort();
  server=spawn('python3',[path.join(resources,'server.py')],{env:{...process.env,PASCAL_HOST:'127.0.0.1',PASCAL_PORT:String(port),PASCAL_WORKSPACE:project,PASCAL_STATIC_DIR:path.join(resources,app.isPackaged?'static':'dist')},stdio:['ignore','pipe','pipe']});
  let err='';server.stderr.on('data',d=>err+=d);server.on('error',e=>{dialog.showErrorBox('Pascal Studio',`Impossible de démarrer Python : ${e.message}\nInstallez python3.`);app.quit()});
  await waitUntilReady(port,server);
  ipcMain.handle('latex:save-pdf',async(_event,id,name)=>{
    if(typeof id!=='string'||!/^[A-Za-z0-9_-]{20,40}$/.test(id))throw new Error('PDF invalide.');
    const safeName=(typeof name==='string'?path.basename(name):'document.pdf').replace(/[\x00-\x1f]/g,'')||'document.pdf';
    const choice=await dialog.showSaveDialog(window,{title:'Enregistrer le PDF',defaultPath:safeName,filters:[{name:'Document PDF',extensions:['pdf']}]});
    if(choice.canceled||!choice.filePath)return null;
    const dest=choice.filePath,tmpDir=fs.mkdtempSync(path.join(path.dirname(dest),'.pascal-studio-pdf-')),tmp=path.join(tmpDir,'document.pdf');
    try {
      await new Promise((resolve,reject)=>{http.get(`http://127.0.0.1:${port}/api/latex/pdf?id=${encodeURIComponent(id)}`,response=>{
        if(response.statusCode!==200){response.resume();return reject(new Error('PDF expiré ou inaccessible.'))}
        const output=fs.createWriteStream(tmp,{flags:'wx',mode:0o600});response.on('error',reject);output.on('error',reject);output.on('finish',resolve);response.pipe(output)
      }).on('error',reject)});
      fs.renameSync(tmp,dest);return dest;
    }finally{fs.rmSync(tmpDir,{recursive:true,force:true})}
  });
  ipcMain.handle('documents:save-copy',async(_event,kind,name,bytes)=>{
    if(!['pdf','psnote'].includes(kind)||!(bytes instanceof Uint8Array)||bytes.byteLength>85_000_000)throw new Error('Document invalide ou trop volumineux.');
    const safe=(typeof name==='string'?path.basename(name):'document.'+kind).replace(/[\x00-\x1f]/g,'')||('document.'+kind);
    const result=await dialog.showSaveDialog(window,{title:kind==='pdf'?'Exporter en PDF':'Enregistrer une copie du document',defaultPath:safe,filters:[{name:kind==='pdf'?'Document PDF':'Document manuscrit Pascal Studio',extensions:[kind]}]});
    if(result.canceled||!result.filePath)return null;
    const target=result.filePath,tmpDir=fs.mkdtempSync(path.join(path.dirname(target),'.ps-document-')),tmp=path.join(tmpDir,'copy');
    try{fs.writeFileSync(tmp,Buffer.from(bytes),{flag:'wx',mode:0o600});fs.renameSync(tmp,target);return target}finally{fs.rmSync(tmpDir,{recursive:true,force:true})}
  });
  ipcMain.handle('documents:close-result',(_event,id,allow)=>{
    if(!window||_event.sender!==window.webContents||id!==pendingClose)return false;
    clearTimeout(closeTimer);pendingClose=0;if(allow===true){allowWindowClose=true;window.close()}return true;
  });
  window=new BrowserWindow({width:1440,height:940,minWidth:820,minHeight:600,backgroundColor:'#2b2b2b',title:'Pascal Studio',autoHideMenuBar:true,webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true,preload:path.join(__dirname,'preload.cjs')}});
  window.on('close',e=>{if(!allowWindowClose){e.preventDefault();requestSafeClose()}});
  window.webContents.setWindowOpenHandler(({url})=>{if(url.startsWith('https://'))shell.openExternal(url);return {action:'deny'}});
  window.webContents.on('will-navigate',(e,url)=>{if(!url.startsWith(`http://127.0.0.1:${port}/`))e.preventDefault()});
  await window.loadURL(`http://127.0.0.1:${port}/`);
  window.on('closed',()=>{window=null});
 }catch(e){dialog.showErrorBox('Pascal Studio',`Impossible de démarrer : ${e.message}\nInstallez python3, fp-compiler et gdb.`);app.quit()}
});
app.on('window-all-closed',()=>app.quit());
app.on('before-quit',e=>{if(window&&!allowWindowClose){e.preventDefault();requestSafeClose();return}if(server&&!server.killed)server.kill('SIGTERM')});
