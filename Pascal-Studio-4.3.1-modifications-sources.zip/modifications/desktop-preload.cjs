const {contextBridge, ipcRenderer} = require('electron');
contextBridge.exposeInMainWorld('pascalDesktop',{
  recentProjects: () => ipcRenderer.invoke('project:recent'),
  chooseFile: () => ipcRenderer.invoke('project:choose-file'),
  chooseDirectory: kind => ipcRenderer.invoke('project:choose-directory',kind),
  rememberProject: path => ipcRenderer.invoke('project:remember',path),
  browserLogin: provider => ipcRenderer.invoke('accounts:browser-login',provider),
  onCloseRequest: callback => ipcRenderer.on('documents:request-close',(_event,id)=>callback(id)),
  closeResult: (id,allow) => ipcRenderer.invoke('documents:close-result',id,allow),
  saveDocumentCopy: (kind,name,bytes) => ipcRenderer.invoke('documents:save-copy',kind,name,bytes),
  saveLatexPdf: (id,name) => ipcRenderer.invoke('latex:save-pdf',id,name),
  clipboardRead: () => ipcRenderer.invoke('clipboard:read'),
  clipboardWrite: text => ipcRenderer.invoke('clipboard:write',String(text)),
  /* 4.0.0 — navigateur intégré. Les trois relais partent du processus
   * principal : un invité <webview> a ses propres webContents, donc un popup
   * ouvert depuis une page affichée dans le panneau n'atteint jamais le
   * panneau lui-même. Chaque relais rend une fonction de désinscription, pour
   * qu'un panneau fermé ne continue pas d'accumuler des écouteurs. */
  onNavigateurPopup: callback => {
    const ecoute = (_e,url) => callback(url);
    ipcRenderer.on('navigateur:popup',ecoute);
    return () => ipcRenderer.removeListener('navigateur:popup',ecoute);
  },
  onNavigateurDownload: callback => {
    const ecoute = (_e,info) => callback(info);
    ipcRenderer.on('navigateur:telechargement',ecoute);
    return () => ipcRenderer.removeListener('navigateur:telechargement',ecoute);
  },
  onNavigateurPermission: callback => {
    const ecoute = (_e,info) => callback(info);
    ipcRenderer.on('navigateur:permission',ecoute);
    return () => ipcRenderer.removeListener('navigateur:permission',ecoute);
  }
});
