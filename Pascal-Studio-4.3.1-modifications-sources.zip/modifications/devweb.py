"""Façade du panneau dev web.

Un seul point d'entrée pour le serveur et pour l'aperçu : `import devweb`. Les
modules qui font le travail (journal, analyse, références, audits, modèles,
client) restent séparés et testables seuls ; cette façade ne contient pas de
logique métier, seulement du routage, du confinement de chemins et des gardes.

Trois règles s'y appliquent, et elles valent pour tout ce qui suit :

  * AUCUNE fonction ne lève vers l'appelant. Le serveur HTTP n'a pas de quoi
    transformer une exception en réponse utile, et un panneau qui reçoit une
    trace de pile n'affiche rien. Chaque entrée rend un dictionnaire avec
    `ok` et, en cas d'échec, `erreur` en français.
  * Les chemins sont CONFINÉS à la racine du projet. C'est déjà fait dans
    server.py pour ses propres routes ; le refaire ici n'est pas de la
    méfiance envers l'appelant, c'est la seule façon de garantir que le panneau
    ne peut pas être utilisé pour lire un fichier hors du projet, quel que soit
    le chemin d'appel.
  * Un échec est dit avec sa cause. « introuvable » ne suffit pas : le panneau
    doit pouvoir afficher « lecture refusée : le fichier est hors du projet ».
"""

import json
import os
import re
from pathlib import Path

import devweb_analyse
import devweb_audits
import devweb_client
import devweb_journal
import devweb_modeles
import devweb_references as ref

VERSION = '4.0.0'

# L'encodage d'un document n'est pas devinable de façon fiable : on cherche la
# déclaration, et à défaut on décode en UTF-8 en le DISANT. Un document
# windows-1252 lu comme de l'UTF-8 affiche des accents cassés, et l'audit
# porterait alors sur un texte qui n'est pas celui que voit l'utilisateur.
_ENCODAGES = ('utf-8-sig', 'utf-8', 'cp1252', 'iso-8859-15', 'iso-8859-1')
_MAX_DOCUMENT = 8_000_000
_META_CHARSET = re.compile(
    rb'<meta[^>]+charset\s*=\s*["\']?\s*([a-zA-Z0-9_\-:.]+)', re.IGNORECASE)
_XML_ENCODING = re.compile(
    rb'<\?xml[^>]+encoding\s*=\s*["\']([a-zA-Z0-9_\-:.]+)', re.IGNORECASE)


# ================================================================== CAPACITÉS ==
def capacites():
    """Ce que le panneau peut afficher, en une seule réponse.

    L'interface construit ses listes depuis ce dictionnaire plutôt que de
    coder en dur des identifiants : ajouter un audit ou un générateur côté
    Python suffit alors à le faire apparaître.
    """
    return {
        'ok': True,
        'version': VERSION,
        'modules': {
            'journal': True, 'analyse': True, 'references': True,
            'audits': True, 'modeles': True, 'client': True,
        },
        # AUDITS est un tuple de dictionnaires {id, nom, resume} : le résumé est
        # transmis tel quel, c'est ce que l'interface affiche pour expliquer ce
        # que chaque audit regarde, sans avoir à le recopier en JavaScript.
        'audits': [{'id': a['id'], 'nom': a['nom'],
                    'resume': a.get('resume', '')}
                   for a in devweb_audits.AUDITS],
        'gravites': list(devweb_audits.GRAVITES),
        'generateurs': devweb_modeles.catalogue_generateurs(),
        'groupes_generateurs': sorted({g['groupe']
                                       for g in devweb_modeles.GENERATEURS}),
        'extraits': [
            {'id': e['id'], 'groupe': e['groupe'], 'titre': e['titre'],
             'langage': e['langage'], 'description': e['description'],
             'octets': len(e['code'].encode('utf8'))}
            for e in devweb_modeles.EXTRAITS],
        'groupes_extraits': list(devweb_modeles.GROUPES_EXTRAITS),
        # Les clefs sont celles des structures de devweb_references, pas des
        # clefs inventées ici : un dictionnaire reconstruit avec des noms
        # approximatifs lève une KeyError au premier appel, et c'est exactement
        # ce que ce contrôle interne existe pour attraper.
        'viewports': [
            {'id': v['id'], 'nom': v['nom'], 'categorie': v['categorie'],
             'largeur': v['largeur'], 'hauteur': v['hauteur'],
             'dpr': v.get('dpr', 1), 'note': v.get('note', '')}
            for v in ref.VIEWPORTS],
        'en_tetes_securite': [
            {'nom': e['nom'], 'gravite': e['gravite'], 'role': e['role'],
             'conseil': e['conseil'],
             'https_uniquement': bool(e.get('https_uniquement'))}
            for e in ref.EN_TETES_SECURITE],
        'en_tetes_bavards': list(ref.EN_TETES_BAVARDS),
        'motifs_dangereux': [
            {'code': m['code'], 'gravite': m['gravite'],
             'langage': m['langage'], 'raison': m['raison'],
             'conseil': m['conseil']}
            for m in ref.MOTIFS_DANGEREUX],
        'elements_obsoletes': len(ref.ELEMENTS_OBSOLETES),
        'roles_aria': len(ref.ROLES_ARIA),
        'proprietes_css': len(ref.PROPRIETES_CSS),
        'budgets': ref.BUDGETS,
        'journal': {'marqueur': devweb_journal.MARQUEUR,
                    'capacite': devweb_journal.MAX_ENTREES,
                    'types': list(devweb_journal.TYPES),
                    'statistiques': devweb_journal.statistiques()},
        'limites': {'document': _MAX_DOCUMENT,
                    'corps_requete': devweb_journal.MAX_CORPS,
                    'liens_distants': devweb_audits.MAX_LIENS_DISTANTS,
                    'ressources_poids': devweb_audits.MAX_RESSOURCES_POIDS},
    }


def etat():
    """État courant, séparé de capacites().

    capacites() est statique et peut être mise en cache côté interface ; etat()
    change à chaque appel (contenu du journal, compteurs). Les modules sont
    importés sans condition en tête de ce fichier : s'ils manquent, c'est
    l'import de devweb lui-même qui échoue, donc un test « module is None » ici
    ne détecterait jamais rien.
    """
    statistiques_journal = devweb_journal.statistiques()
    return {'ok': True, 'version': VERSION,
            'journal': statistiques_journal,
            'capture_active': bool(statistiques_journal.get('total')),
            'compteurs': {'audits': len(devweb_audits.AUDIT_IDS),
                          'generateurs': len(devweb_modeles.GENERATEURS),
                          'extraits': len(devweb_modeles.EXTRAITS)}}


# ==================================================================== CHEMINS ==
def _confine(chemin, racine):
    """(chemin absolu, raison du refus).

    La comparaison porte sur les chemins RÉSOLUS : un projet peut contenir des
    liens symboliques, et comparer des chaînes laisserait passer
    « projet/../../etc/passwd » dès que la racine elle-même en contient un.
    """
    if chemin is None:
        return None, 'Aucun chemin fourni.'
    try:
        cible = Path(os.path.expanduser(str(chemin))).absolute()
    except (OSError, ValueError) as exc:
        return None, 'Chemin illisible (%s).' % exc
    if racine is None:
        return cible, ''
    try:
        base = Path(os.path.expanduser(str(racine))).absolute()
    except (OSError, ValueError) as exc:
        return None, 'Racine illisible (%s).' % exc
    try:
        cible.relative_to(base)
    except ValueError:
        try:
            if cible.resolve().is_relative_to(base.resolve()):
                return cible.resolve(), ''
        except (OSError, ValueError, AttributeError):
            pass
        return None, ('Le fichier « %s » est hors du projet « %s » : l’audit '
                      'ne sort pas du projet ouvert.' % (cible, base))
    return cible, ''


def _decoder(donnees):
    """(texte, encodage, note). Ne lève jamais."""
    if isinstance(donnees, str):
        return donnees, 'utf-8', ''
    if not donnees:
        return '', 'utf-8', ''
    declares = []
    correspondance = _META_CHARSET.search(donnees[:4096])
    if correspondance:
        declares.append(correspondance.group(1).decode('ascii', 'replace'))
    correspondance = _XML_ENCODING.search(donnees[:512])
    if correspondance:
        declares.append(correspondance.group(1).decode('ascii', 'replace'))
    if donnees[:3] == b'\xef\xbb\xbf':
        declares.insert(0, 'utf-8-sig')
    candidats = declares + [e for e in _ENCODAGES if e not in declares]
    for candidat in candidats:
        try:
            return donnees.decode(candidat), candidat, ''
        except (UnicodeDecodeError, LookupError):
            continue
    # Aucun encodage candidat ne décode le document : on rend quand même un
    # texte, en disant qu'il est approché. Refuser de rendre priverait
    # l'utilisateur de tout diagnostic sur un fichier justement douteux.
    return (donnees.decode('utf-8', 'replace'), 'utf-8 (approché)',
            'Aucun encodage candidat n’a pu décoder ce document : il est lu en '
            'UTF-8 en remplaçant les octets invalides. Les caractères accentués '
            'peuvent être inexacts, et l’audit porte sur ce texte approché.')


def _lire_document(chemin):
    """(texte, encodage, note, taille, raison du refus)."""
    try:
        taille = chemin.stat().st_size
    except OSError as exc:
        return None, '', '', 0, 'Fichier illisible : %s' % (exc.strerror or exc)
    if taille > _MAX_DOCUMENT:
        return (None, '', '', taille,
                'Document trop volumineux (%d octets, limite %d) : l’audit '
                's’arrête là plutôt que de saturer la mémoire.'
                % (taille, _MAX_DOCUMENT))
    try:
        donnees = chemin.read_bytes()
    except OSError as exc:
        return None, '', '', taille, 'Lecture impossible : %s' % (
            exc.strerror or exc)
    texte, encodage, note = _decoder(donnees)
    return texte, encodage, note, taille, ''


# ====================================================================== AUDIT ==
def auditer(chemin=None, contenu=None, cible='', racine=None, url='',
            entetes=None, statut=200, options=None, seulement=None):
    """Audite un document : soit un fichier du projet, soit un contenu fourni.

    `contenu` a la priorité : c'est ce que l'aperçu passe, pour auditer
    EXACTEMENT ce qui est servi (après injection éventuelle), et non une
    relecture du disque qui pourrait différer.
    """
    options = dict(options or {})
    notes = []
    chemin_absolu = None
    encodage = 'utf-8'
    if contenu is None:
        chemin_absolu, refus = _confine(chemin, racine)
        if refus:
            return {'ok': False, 'erreur': refus}
        if not chemin_absolu.exists():
            return {'ok': False,
                    'erreur': 'Le fichier « %s » est introuvable.' % chemin_absolu}
        if chemin_absolu.is_dir():
            return {'ok': False,
                    'erreur': '« %s » est un dossier : l’audit porte sur un '
                              'document. Utilisez l’inventaire du projet pour '
                              'choisir une page.' % chemin_absolu}
        texte, encodage, note, taille, refus = _lire_document(chemin_absolu)
        if refus:
            return {'ok': False, 'erreur': refus}
        if note:
            notes.append(note)
        contenu = texte
        cible = cible or chemin_absolu.name
        if racine is None:
            racine = chemin_absolu.parent
    if not isinstance(contenu, str):
        contenu, encodage, note = _decoder(contenu)
        if note:
            notes.append(note)
    if not contenu.strip():
        return {'ok': False,
                'erreur': 'Le document est vide : il n’y a rien à auditer.'}

    base_racine, refus = _confine(racine, None) if racine else (None, '')
    if refus:
        notes.append(refus)
    try:
        rapport = devweb_audits.auditer_contenu(
            contenu, cible=cible or 'document', racine=base_racine,
            chemin=chemin_absolu, url=url, entetes=entetes, statut=statut,
            options=options, seulement=seulement)
    except Exception as exc:
        # auditer_tous() encadre déjà chaque audit ; ce qui peut encore lever
        # ici est l'analyse du document lui-même. Rendre un échec nommé vaut
        # mieux qu'une réponse vide que l'interface lirait comme « tout va
        # bien ».
        return {'ok': False,
                'erreur': 'L’audit n’a pas abouti (%s : %s).'
                          % (type(exc).__name__, exc)}
    rapport['ok'] = True
    rapport['encodage'] = encodage
    rapport['notes'] = notes
    rapport['chemin'] = str(chemin_absolu) if chemin_absolu else ''
    return rapport


def inventaire(chemin=None, racine=None):
    """Inventaire d'un projet web : ce qu'il contient, page par page.

    L'audit porte sur UN document. Pour choisir lequel, et pour voir d'un coup
    ce qui manque à l'échelle du projet, il faut cet inventaire. Il ne lit pas
    les fichiers (sauf leur taille) : un projet de quelques milliers de
    fichiers reste listable en une fraction de seconde.
    """
    # `racine or chemin` faisait taire le chemin demandé dès qu'une racine
    # était fournie — et le serveur en fournit toujours une : l'inventaire d'un
    # sous-dossier rendait celui du projet entier.
    base = chemin or racine
    base, refus = _confine(base, None)
    if refus:
        return {'ok': False, 'erreur': refus}
    if base is None:
        return {'ok': False, 'erreur': 'Aucun chemin de projet fourni.'}
    if not base.is_dir():
        return {'ok': False,
                'erreur': '« %s » n’est pas un dossier.' % base}
    pages = []
    categories = {}
    total_octets = 0
    nombre = 0
    ignores = []
    try:
        for entree in sorted(base.rglob('*'), key=lambda p: str(p).lower()):
            if not entree.is_file():
                continue
            relatif = str(entree.relative_to(base))
            # Les dossiers cachés (.git, .cache) et leurs contenus sont écartés,
            # mais pas les fichiers de configuration web qui commencent par un
            # point : .htaccess et .well-known font partie du projet, et ce sont
            # justement ceux que l'audit de sécurité consulte.
            if any(partie.startswith('.') for partie in entree.parts[:-1]):
                ignores.append(relatif)
                continue
            if (entree.name.startswith('.')
                    and entree.name not in _CONFIGURATIONS_WEB):
                ignores.append(relatif)
                continue
            if 'node_modules' in entree.parts:
                ignores.append(relatif)
                continue
            try:
                taille = entree.stat().st_size
            except OSError:
                taille = 0
            nombre += 1
            total_octets += taille
            extension = entree.suffix.lower().lstrip('.') or '(sans)'
            groupe = _groupe_de(entree.name, extension)
            categorie = categories.setdefault(
                groupe, {'groupe': groupe, 'nombre': 0, 'octets': 0,
                         'extensions': {}})
            categorie['nombre'] += 1
            categorie['octets'] += taille
            categorie['extensions'][extension] = (
                categorie['extensions'].get(extension, 0) + 1)
            if groupe == 'html':
                pages.append({'chemin': relatif, 'octets': taille,
                              'nom': entree.name})
            if nombre >= 5000:
                ignores.append('(inventaire arrêté à 5 000 fichiers)')
                break
    except OSError as exc:
        return {'ok': False,
                'erreur': 'Parcours impossible : %s' % (exc.strerror or exc)}
    for categorie in categories.values():
        categorie['extensions'] = dict(
            sorted(categorie['extensions'].items(),
                   key=lambda paire: -paire[1])[:12])
    index = [p for p in pages if p['nom'].lower() in
             ('index.html', 'index.htm', 'index.php')]
    return {'ok': True, 'racine': str(base), 'nombre_fichiers': nombre,
            'octets': total_octets, 'pages': pages[:400],
            'nombre_pages': len(pages),
            'page_accueil': (index[0]['chemin'] if index
                             else (pages[0]['chemin'] if pages else '')),
            'categories': sorted(categories.values(),
                                 key=lambda c: -c['octets']),
            'ignores': len(ignores)}


_CONFIGURATIONS_WEB = ('.htaccess', '.htpasswd', '.user.ini', '.well-known',
                       '.babelrc', '.eslintrc', '.editorconfig', '.gitignore',
                       '.browserslistrc', '.nojekyll')


def _groupe_fichier(extension):
    if extension in ('html', 'htm', 'xhtml', 'shtml'):
        return 'html'
    if extension in ('css', 'scss', 'sass', 'less'):
        return 'css'
    if extension in ('js', 'mjs', 'cjs', 'jsx', 'ts', 'tsx', 'vue', 'map'):
        return 'javascript'
    if extension in ('png', 'jpg', 'jpeg', 'gif', 'webp', 'avif', 'svg', 'ico',
                     'bmp'):
        return 'images'
    if extension in ('woff', 'woff2', 'ttf', 'otf', 'eot'):
        return 'polices'
    if extension in ('json', 'xml', 'yml', 'yaml', 'toml', 'webmanifest'):
        return 'donnees'
    if extension in ('php', 'py', 'rb', 'pl', 'asp', 'aspx', 'jsp'):
        return 'serveur'
    if extension in ('txt', 'md', 'rst'):
        return 'texte'
    return 'autres'


def _groupe_de(nom, extension):
    """Le groupe d'un fichier, en tenant aussi de son NOM.

    `.htaccess` n'a pas d'extension exploitable : le classer en « autres »
    cacherait le fichier le plus important d'un projet Apache.
    """
    if nom in ('.htaccess', '.htpasswd', '.user.ini'):
        return 'serveur'
    if nom in ('.gitignore', '.editorconfig', '.browserslistrc', '.nojekyll',
               '.babelrc', '.eslintrc'):
        return 'donnees'
    return _groupe_fichier(extension)


# =================================================================== GÉNÉRATION ==
def generer(identifiant, parametres=None):
    """Génère un fichier. Rend `ok=False` avec la raison plutôt que de lever."""
    resultat = devweb_modeles.generer(identifiant, parametres)
    resultat.setdefault('ok', False)
    return resultat


def extraits(groupe=None, recherche=None, identifiant=None):
    """Les extraits de code à copier."""
    if identifiant:
        extrait = devweb_modeles.EXTRAITS_PAR_ID.get(identifiant)
        if extrait is None:
            return {'ok': False,
                    'erreur': 'Extrait « %s » inconnu. Les extraits '
                              'disponibles sont : %s.'
                              % (identifiant,
                                 ', '.join(devweb_modeles.EXTRAITS_PAR_ID))}
        return {'ok': True, 'extrait': extrait}
    return {'ok': True,
            'extraits': devweb_modeles.extraits(groupe=groupe,
                                                recherche=recherche),
            'groupes': list(devweb_modeles.GROUPES_EXTRAITS)}


def viewports():
    """Les tailles d'écran proposées, celles du panneau et celles de l'aperçu."""
    return {'ok': True, 'viewports': [dict(v) for v in ref.VIEWPORTS],
            'points_rupture': list(ref.POINTS_RUPTURE)}


# ===================================================================== CLIENT ==
def requeter(url, **options):
    """Requête HTTP contrôlée par le panneau.

    Le client rend toujours un dictionnaire ; cette façade ajoute la seule
    garde qui relève du produit : une adresse locale n'est pas traitée comme
    une adresse distante, parce que contacter 127.0.0.1 peut atteindre un
    service de la machine qui n'a rien à voir avec le projet (le serveur de
    Pascal Studio lui-même écoute sur 127.0.0.1). Le panneau le signale plutôt
    que de l'interdire : c'est justement utile pour tester son propre serveur.
    """
    resultat = devweb_client.requeter(url, **options)
    resultat['ok'] = bool(resultat.get('ok'))
    resultat['locale'] = _est_locale(resultat.get('adresse_demandee') or '')
    if resultat['locale'] and not options.get('autoriser_local', True):
        return {'ok': False, 'url': resultat.get('url', ''),
                'erreur': 'Adresse locale refusée par les options demandées.'}
    resultat['apercu'] = devweb_client.apercu(resultat, lignes=40)
    return resultat


def _est_locale(url):
    try:
        import urllib.parse
        hote = (urllib.parse.urlsplit(url).hostname or '').lower()
    except ValueError:
        return False
    return hote in ('localhost', '127.0.0.1', '::1', '0.0.0.0', '[::1]') or \
        hote.startswith('127.') or hote.startswith('192.168.') or \
        hote.startswith('10.') or hote.endswith('.local')


# ===================================================================== JOURNAL ==
def journal(depuis=0, limite=500):
    return devweb_journal.journal(depuis=depuis, limite=limite)


def statistiques():
    return devweb_journal.statistiques()


def capturer(donnees):
    return devweb_journal.capturer(donnees)


def journal_vider(raison=''):
    return devweb_journal.journal_vider(raison)


def injecter_capture(document, base=''):
    """Place le script de capture dans le document servi par l'aperçu.

    `base` n'est pas utilisée pour construire l'adresse de collecte : le script
    poste sur son ORIGINE propre. C'est délibéré — l'aperçu peut être servi
    derrière un mandataire qui réécrit les adresses, et une adresse absolue
    construite ici pointerait alors ailleurs.
    """
    return devweb_journal.injecter_capture(document)


SCRIPT_CAPTURE = devweb_journal.SCRIPT_CAPTURE
MARQUEUR = devweb_journal.MARQUEUR


# ===================================================================== DIVERS ==
def analyser(contenu=None, chemin=None, racine=None):
    """Analyse structurelle seule, sans audit : pour un aperçu rapide.

    Utile quand l'utilisateur veut voir ce que Pascal Studio comprend d'un
    document (titres, images, liens, règles CSS) sans la couche de jugements.
    C'est aussi l'endroit où un désaccord entre l'analyseur et le rendu saute
    aux yeux : si cette vue est juste, l'audit qui s'appuie dessus l'est aussi.

    L'API de devweb_analyse est à connaître : `Element.get(nom, defaut)` rend la
    VALEUR d'un attribut, `Element.a(nom)` rend un BOOLÉEN de présence, et
    `Document.par_balise(*balises)` est une MÉTHODE — pas un dictionnaire.

    Un chemin peut être donné à la place du contenu : le document est alors lu
    en octets et son encodage est détecté, ce que `read_exact` côté serveur ne
    fait pas (il décode en UTF-8 sans regarder la déclaration du document).
    """
    notes = []
    encodage = ''
    lu_depuis_fichier = contenu is None
    if lu_depuis_fichier:
        if chemin is None:
            return {'ok': False,
                    'erreur': 'analyser() demande un contenu ou un chemin de '
                              'fichier : aucun des deux n’a été fourni.'}
        chemin_absolu, refus = _confine(chemin, racine)
        if refus:
            return {'ok': False, 'erreur': refus}
        if chemin_absolu is None or not chemin_absolu.is_file():
            return {'ok': False,
                    'erreur': 'Le fichier « %s » est introuvable.' % chemin_absolu}
        texte, encodage, note, _taille, refus = _lire_document(chemin_absolu)
        if refus:
            return {'ok': False, 'erreur': refus}
        if note:
            notes.append(note)
        contenu = texte
    if isinstance(contenu, (bytes, bytearray)):
        contenu, _, note = _decoder(contenu)
        if note:
            notes.append(note)
    document, blocs = devweb_analyse.analyser_html(contenu)
    html = document.premier('html')
    balises = {}
    for element in document.elements:
        balises[element.balise] = balises.get(element.balise, 0) + 1
    titres = [{'niveau': int(element.balise[1]),
               'texte': element.texte_complet()[:200], 'ligne': element.ligne}
              for element in document.par_balise('h1', 'h2', 'h3', 'h4', 'h5',
                                                 'h6')]
    meta = {}
    for nom in ('description', 'viewport', 'robots', 'theme-color', 'author',
                'generator', 'keywords'):
        valeur = document.meta(nom)
        if valeur:
            meta[nom] = valeur
    sociaux = {}
    for nom in ('og:title', 'og:description', 'og:image', 'og:url', 'og:type',
                'og:locale', 'twitter:card', 'twitter:title'):
        attribut = 'property' if nom.startswith('og:') else 'name'
        valeur = document.meta(nom, attribut)
        if valeur:
            sociaux[nom] = valeur
    regles = 0
    erreurs = []
    for bloc in blocs:
        trouvees, anomalies = devweb_analyse.analyser_css(
            bloc.get('texte', ''), 'le style en ligne %s'
            % (bloc.get('ligne') or 0), bloc.get('ligne') or 0)
        regles += len(trouvees)
        erreurs.extend({'code': a['code'], 'ligne': a.get('ligne'),
                        'message': a.get('message', '')} for a in anomalies)
    return {
        'ok': True,
        'notes': notes,
        'encodage': encodage if lu_depuis_fichier else '',
        'titre': document.titre(),
        'langue': html.get('lang', '') if html else '',
        'doctype': document.doctype,
        'encodage_declare': document.encodage_declare,
        'elements': len(document.elements),
        'ids': sorted(document.ids),
        'anomalies': [{'code': a['code'], 'ligne': a.get('ligne'),
                       'message': a.get('message', ''),
                       'extrait': a.get('extrait', '')}
                      for a in document.anomalies],
        'balises': dict(sorted(balises.items(),
                               key=lambda paire: -paire[1])[:40]),
        'titres': titres,
        'images': [{'src': element.get('src', ''),
                    'alt': element.get('alt'),
                    'largeur': element.get('width'),
                    'hauteur': element.get('height'),
                    'chargement': element.get('loading', ''),
                    'ligne': element.ligne}
                   for element in document.par_balise('img')],
        'liens': [{'href': element.get('href', ''),
                   'texte': element.texte_complet()[:200],
                   'nouvelle_fenetre': element.a('target'),
                   'ligne': element.ligne}
                  for element in document.par_balise('a')],
        'formulaires': [
            {'action': element.get('action', ''),
             'methode': element.get('method', 'get'),
             'champs': len([c for c in element.iterer()
                            if c.balise in ('input', 'select', 'textarea')]),
             'ligne': element.ligne}
            for element in document.par_balise('form')],
        'scripts': [{'src': element.get('src', ''),
                     'differe': element.a('defer') or element.a('async'),
                     'ligne': element.ligne}
                    for element in document.par_balise('script')],
        'feuilles': [{'href': element.get('href', ''),
                      'media': element.get('media', ''),
                      'ligne': element.ligne}
                     for element in document.par_balise('link')
                     if (element.get('rel', '').lower() == 'stylesheet')],
        'meta': meta,
        'sociaux': sociaux,
        'blocs_css': len(blocs),
        'regles_css': regles,
        'erreurs_css': erreurs,
        'commentaires': len(document.commentaires),
        'texte_octets': len(document.racine.texte_complet().encode(
            'utf8', 'replace')),
    }


def verifier():
    """Contrôle interne complet de la façade et des modules qu'elle expose.

    Exécuté par les bancs et par le script de reconditionnement : un module
    devweb dont l'import échoue dans l'image produite doit être détecté là,
    pas au premier clic de l'utilisateur.
    """
    problemes = []

    def verif(condition, message):
        if not condition:
            problemes.append(message)

    capacite = capacites()
    verif(capacite['ok'], 'capacites() ne répond pas ok')
    verif(len(capacite['audits']) == len(devweb_audits.AUDIT_IDS),
          'la liste des audits ne correspond pas aux audits réels')
    verif(len(capacite['generateurs']) == len(devweb_modeles.GENERATEURS),
          'le catalogue des générateurs est incomplet')
    verif(len(capacite['extraits']) == len(devweb_modeles.EXTRAITS),
          'la liste des extraits est incomplète')
    verif(all(a['id'] for a in capacite['audits']), 'un audit sans identifiant')
    verif(len(capacite['viewports']) == len(ref.VIEWPORTS),
          'la liste des viewports est incomplète')

    for souci in devweb_modeles.verifier_modeles():
        problemes.append('modeles : %s' % souci)
    for souci in ref.verifier_listes():
        problemes.append('references : %s' % souci)

    page = ('<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
            '<title>Page de contrôle</title>'
            '<meta name="description" content="'
            'Une description assez longue pour passer le contrôle de longueur '
            'minimale imposé par les moteurs de recherche.">'
            '</head>'
            '<body><h1>Titre</h1><img src="img.png" alt="Une image" '
            'width="10" height="10"><a href="#titre">Ancre</a></body></html>')
    rapport = auditer(contenu=page, cible='controle.html')
    verif(rapport.get('ok'), 'auditer(contenu=…) échoue : %s'
          % rapport.get('erreur'))
    verif(set(rapport.get('audits', {})) == set(devweb_audits.AUDIT_IDS),
          'tous les audits ne sont pas rendus')
    verif(0 <= rapport.get('note_globale', -1) <= 100,
          'la note globale est hors de 0 à 100')
    verif(rapport.get('encodage') == 'utf-8',
          'l’encodage d’un contenu texte n’est pas rendu')

    refus = auditer(chemin='/etc/passwd', racine='/tmp/projet-inexistant-xyz')
    verif(not refus.get('ok') and 'hors du projet' in (refus.get('erreur') or ''),
          'un chemin hors du projet n’est pas refusé : %r' % refus.get('erreur'))
    verif(not auditer(contenu='   ').get('ok'),
          'un document vide est accepté')
    dossier = auditer(chemin='/tmp')
    verif(not dossier.get('ok') and 'dossier' in (dossier.get('erreur') or ''),
          'un dossier est accepté comme document : %r' % dossier.get('erreur'))

    analyse = analyser(page)
    # Vérifier d'abord que le document de contrôle est bien analysé : sans cela,
    # une fixture cassée ferait échouer les contrôles suivants en accusant le
    # produit plutôt que le banc.
    verif(not analyse['anomalies'],
          'le document de contrôle présente des anomalies d\u2019analyse : %r'
          % [(a['code'], a.get('message')) for a in analyse['anomalies']])
    verif(analyse['ok'] and analyse['titre'] == 'Page de contrôle',
          'analyser() ne rend pas le titre : %r' % analyse.get('titre'))
    verif(len(analyse['images']) == 1 and analyse['images'][0]['alt'] ==
          'Une image' and analyse['images'][0]['largeur'] == '10',
          'analyser() ne rend pas les attributs des images : %r'
          % analyse.get('images'))
    verif(analyse['langue'] == 'fr', 'analyser() ne rend pas la langue du '
          'document : %r' % analyse.get('langue'))
    verif([t['niveau'] for t in analyse['titres']] == [1],
          'analyser() ne rend pas la hiérarchie des titres')
    verif(analyse['liens'][0]['texte'] == 'Ancre',
          'analyser() ne rend pas le texte des liens')
    verif(analyse['meta']['description'].startswith('Une description'),
          'analyser() ne rend pas les meta')
    verif(not analyse.get('notes'), 'analyser() signale un souci sur un '
          'document UTF-8 ordinaire : %r' % analyse.get('notes'))
    absent = analyser(chemin='/etc/passwd', racine='/tmp/projet-inexistant-xyz')
    verif(not absent.get('ok') and 'hors du projet' in (absent.get('erreur')
                                                        or ''),
          'analyser(chemin=…) ne confine pas : %r' % absent.get('erreur'))
    sans_rien = analyser()
    verif(not sans_rien.get('ok'),
          'analyser() sans contenu ni chemin répond ok : %r' % sans_rien)

    # Le nom local est distinct de la fonction du module : écrire
    # `inventaire = inventaire(…)` ferait de `inventaire` une variable locale
    # pour toute la fonction, et l'appel lèverait UnboundLocalError.
    absent = inventaire(chemin='/tmp/projet-inexistant-xyz')
    verif(not absent.get('ok'), 'un dossier inexistant est inventorié')

    texte, encodage, note = _decoder('hétéroclite'.encode('cp1252'))
    verif(encodage == 'cp1252' and texte == 'hétéroclite',
          'un document cp1252 n’est pas décodé (%s, %r)' % (encodage, texte))
    texte, encodage, note = _decoder(b'<meta charset="iso-8859-1">caf\xe9')
    verif(texte.endswith('café'), 'la déclaration de charset n’est pas suivie')
    # iso-8859-1 décode n'importe quelle suite d'octets : un document
    # « indécodable » n'existe donc pas, et _decoder rend toujours un texte. Le
    # contrôle porte sur ce qui compte : pas d'exception, et l'encodage
    # réellement utilisé est rendu (le panneau l'affiche).
    texte, encodage, note = _decoder(b'\xff\xfe\x00\x01')
    verif(texte and encodage and note == '',
          'un document binaire ne rend ni texte ni encodage (%r, %r)'
          % (texte[:8], encodage))
    verif(_decoder('<meta charset="utf-8">café'.encode('utf8'))[1] == 'utf-8',
          'un document UTF-8 déclaré n\u2019est pas décodé en UTF-8')
    verif(_decoder('')[0] == '', 'un document vide lève au lieu de rendre \'\'')

    resultat = requeter('ftp://exemple.fr/x')
    verif(not resultat['ok'] and resultat['erreur'],
          'un schéma non HTTP est accepté par requeter()')
    resultat = requeter('http://127.0.0.1:1/x')
    verif(resultat['locale'] and resultat['erreur'],
          'une adresse locale fermée n’est ni dite locale ni expliquée')

    capture = injecter_capture('<html><head></head><body>x</body></html>')
    verif(MARQUEUR in capture and 'body>x' in capture.replace(' ', ''),
          'injecter_capture() ne place pas le script')
    verif(injecter_capture(capture) == capture,
          'injecter_capture() n’est pas idempotent')
    verif(capturer(json.dumps({'entrees': [{'type': 'console', 'methode': 'log',
                                            'texte': ['x']}]}))['acceptees'] == 1,
          'capturer() n’accepte pas une entrée valide')
    journal_vider('contrôle interne de devweb')
    verif(statistiques()['total'] == 1,
          'journal_vider() ne remet pas le journal à zéro')
    verif(journal()['total'] == 1, 'journal() ne rend pas l’entrée système')

    return problemes


if __name__ == '__main__':
    import sys

    soucis = verifier()
    if soucis:
        for souci in soucis:
            print('ÉCHEC :', souci)
        sys.exit(1)
    capacite = capacites()
    print('devweb %s : %d audits, %d générateurs, %d extraits, %d viewports, '
          '%d en-têtes de sécurité, %d motifs dangereux — autocontrôle OK.'
          % (VERSION, len(capacite['audits']), len(capacite['generateurs']),
             len(capacite['extraits']), len(capacite['viewports']),
             len(capacite['en_tetes_securite']),
             len(capacite['motifs_dangereux'])))
