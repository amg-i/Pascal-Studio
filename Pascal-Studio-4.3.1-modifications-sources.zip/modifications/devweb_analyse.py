"""Modèle de document pour les audits dev web : HTML tolérant et CSS scanné.

Tous les audits (accessibilité, sécurité, liens, poids, métadonnées, validation)
travaillent sur le même objet : un arbre d'éléments avec sa ligne, ses
attributs, son texte, plus les règles CSS du document et de ses feuilles liées.
Analyser six fois six arbres différents donnerait six verdicts contradictoires
sur la même page.

Deux exigences guident l'analyseur, et elles viennent d'une leçon de ce projet :
le pire défaut d'un analyseur est d'accuser du code correct.

  * L'arbre est TOLÉRANT : une page cassée doit malgré tout produire quelque
    chose d'exploitable, parce que c'est précisément quand elle est cassée
    qu'on a besoin de l'audit. Aucune exception ne sort de l'analyse.
  * Les FERMETURES IMPLICITES du HTML sont connues : `li`, `p`, `td`, `option`
    et quelques autres n'ont pas besoin de balise fermante. Un validateur qui
    les signale comme « non fermées » noie l'utilisateur sous des faux positifs
    et lui apprend à ignorer le rapport — ce qui rend l'outil inutile même quand
    il trouve une vraie erreur. La liste est donc dans le code, et le banc la
    vérifie sur des pages qui omettent volontairement ces fermetures.

Aucune dépendance externe : html.parser et re suffisent, et lxml n'est pas
installé partout.
"""

import re
from html.parser import HTMLParser

LIMITE_ELEMENTS = 8_000
LIMITE_TEXTE = 4_000_000
LIMITE_ATTRIBUTS = 200

# Balises sans contenu ni balise fermante. `keygen` et `basefont` sont
# obsolètes mais les navigateurs les traitent encore comme vides.
VIDES = frozenset((
    'area', 'base', 'basefont', 'br', 'col', 'embed', 'frame', 'hr', 'img',
    'input', 'keygen', 'link', 'meta', 'param', 'source', 'track', 'wbr',
))

# Contenu brut : le parseur ne doit pas y chercher de balises.
BRUT = frozenset(('script', 'style', 'textarea', 'title'))

# Éléments dont la balise fermante PEUT être omise en fin de document sans que
# le document soit invalide (HTML Living Standard, « optional tags »).
FERMETURE_OMISSIBLE = frozenset((
    'html', 'head', 'body', 'p', 'li', 'td', 'th', 'tr', 'option', 'optgroup',
    'thead', 'tbody', 'tfoot', 'dt', 'dd', 'rt', 'rp', 'colgroup', 'caption',
))

# Fermetures IMPLICITES : l'ouverture de la clef ferme les balises encore
# ouvertes listées en valeur. Sans cette table, `<ul><li>a<li>b</ul>` produirait
# un avertissement par élément de liste.
IMPLICITES = {
    'li': ('li',),
    'dt': ('dt', 'dd'),
    'dd': ('dt', 'dd'),
    'option': ('option',),
    'optgroup': ('option', 'optgroup'),
    'tr': ('td', 'th', 'tr'),
    'td': ('td', 'th'),
    'th': ('td', 'th'),
    'thead': ('td', 'th', 'tr', 'thead', 'tbody', 'tfoot', 'caption'),
    'tbody': ('td', 'th', 'tr', 'thead', 'tbody', 'tfoot', 'caption'),
    'tfoot': ('td', 'th', 'tr', 'thead', 'tbody', 'tfoot'),
    'caption': ('td', 'th', 'tr', 'thead', 'tbody', 'tfoot', 'caption'),
    'colgroup': ('td', 'th', 'tr', 'thead', 'tbody', 'tfoot', 'caption'),
    'rt': ('rt', 'rp'),
    'rp': ('rt', 'rp'),
    'body': ('head',),
}

# Une balise <p> ouverte est fermée par l'ouverture de n'importe lequel de ces
# éléments de niveau bloc.
FERME_PARAGRAPHE = frozenset((
    'address', 'article', 'aside', 'blockquote', 'details', 'div', 'dl',
    'fieldset', 'figcaption', 'figure', 'footer', 'form', 'h1', 'h2', 'h3',
    'h4', 'h5', 'h6', 'header', 'hgroup', 'hr', 'main', 'menu', 'nav', 'ol',
    'p', 'pre', 'search', 'section', 'table', 'ul',
))


class Element:
    """Un élément du document, avec sa position dans le fichier source."""

    __slots__ = ('balise', 'attributs', 'ligne', 'colonne', 'parent',
                 'enfants', 'texte', 'ferme', 'autoferme', 'fin_ligne',
                 'brut_interne', 'ordre')

    def __init__(self, balise, attributs, ligne, colonne, ordre):
        self.balise = balise
        # Les attributs dupliqués sont conservés en liste : c'est justement ce
        # que la validation doit signaler, et un dictionnaire les aurait fait
        # disparaître silencieusement.
        self.attributs = list(attributs or ())
        self.ligne = ligne
        self.colonne = colonne
        self.parent = None
        self.enfants = []
        self.texte = []
        self.ferme = False
        self.autoferme = False
        self.fin_ligne = None
        self.brut_interne = ''
        self.ordre = ordre

    # ---------------------------------------------------------------- accès --
    def get(self, nom, defaut=None):
        """La PREMIÈRE valeur d'un attribut, casse indifférente.

        Un attribut sans valeur (`<input disabled>`) vaut la chaîne vide, comme
        dans un vrai DOM : `get('disabled')` doit alors renvoyer '' et non None,
        sinon un test de présence écrit `if el.get('disabled')` raterait un
        attribut booléen présent.
        """
        nom = nom.lower()
        for cle, valeur in self.attributs:
            if cle == nom:
                return '' if valeur is None else valeur
        return defaut

    def a(self, nom):
        nom = nom.lower()
        return any(cle == nom for cle, _ in self.attributs)

    def tous(self, nom):
        """Toutes les valeurs d'un attribut répété, dans l'ordre du source."""
        nom = nom.lower()
        return ['' if v is None else v for c, v in self.attributs if c == nom]

    def contenu(self):
        return ''.join(self.texte)

    def texte_complet(self):
        """Le texte de l'élément et de ses descendants, espaces normalisés."""
        morceaux = []
        _collecter_texte(self, morceaux)
        return re.sub(r'\s+', ' ', ''.join(morceaux)).strip()

    def iterer(self):
        yield self
        for enfant in self.enfants:
            for element in enfant.iterer():
                yield element

    def ancetres(self):
        courant = self.parent
        while courant is not None:
            yield courant
            courant = courant.parent

    def dans(self, *balises):
        """Vrai si l'un des ancêtres porte l'une de ces balises."""
        cibles = frozenset(b.lower() for b in balises)
        return any(a.balise in cibles for a in self.ancetres())

    def signature(self):
        """Une description courte et lisible, pour les rapports d'audit."""
        texte = '<' + self.balise
        for nom, valeur in self.attributs[:4]:
            if valeur is None:
                texte += ' ' + nom
            else:
                texte += ' %s="%s"' % (nom, valeur if len(valeur) <= 40
                                       else valeur[:37] + '…')
        return texte + '>'

    def __repr__(self):
        return '<Element %s l.%s>' % (self.balise, self.ligne)


def _collecter_texte(element, morceaux):
    morceaux.extend(element.texte)
    for enfant in element.enfants:
        _collecter_texte(enfant, morceaux)


class Document:
    """Le résultat de l'analyse : arbre, index et anomalies de structure."""

    def __init__(self):
        self.racine = Element('#document', (), 1, 0, 0)
        self.elements = []          # tous les éléments, dans l'ordre du source
        self.ids = {}               # id -> [Element] (les doublons comptent)
        self.doctype = ''
        self.doctype_ligne = None
        self.commentaires = []
        self.anomalies = []         # problèmes d'analyse, déjà mis en forme
        self.source = ''
        self.encodage_declare = ''
        self.taille = 0

    # ---------------------------------------------------------------- accès --
    def par_balise(self, *balises):
        cibles = frozenset(b.lower() for b in balises)
        return [e for e in self.elements if e.balise in cibles]

    def premier(self, balise):
        balise = balise.lower()
        for element in self.elements:
            if element.balise == balise:
                return element
        return None

    def meta(self, nom, attribut='name'):
        """La valeur d'un <meta name=…> ou <meta property=…>, casse ignorée."""
        nom = nom.lower()
        for element in self.par_balise('meta'):
            cle = (element.get(attribut) or '').strip().lower()
            if cle == nom:
                return (element.get('content') or '').strip()
        return ''

    def meta_element(self, nom, attribut='name'):
        nom = nom.lower()
        for element in self.par_balise('meta'):
            cle = (element.get(attribut) or '').strip().lower()
            if cle == nom:
                return element
        return None

    def titre(self):
        element = self.premier('title')
        return element.texte_complet() if element else ''

    def feuille(self, balise):
        return self.premier(balise) is not None


def analyser_html(source):
    """Analyse un document HTML sans jamais lever.

    Renvoie (Document, feuilles_css) où feuilles_css est la liste des blocs
    <style> trouvés, chacun avec sa position, prêts pour analyser_css().
    """
    if isinstance(source, (bytes, bytearray)):
        source = bytes(source).decode('utf8', 'replace')
    if not isinstance(source, str):
        source = str(source)
    if len(source) > LIMITE_TEXTE:
        source = source[:LIMITE_TEXTE]
    analyseur = _Analyseur(source)
    try:
        analyseur.feed(source)
        analyseur.close()
    except Exception as exc:                    # une page cassée reste auditable
        analyseur.document.anomalies.append(
            {'code': 'analyse-interrompue', 'gravite': 'avertissement',
             'message': 'L’analyse du document s’est arrêtée : %s. Les audits '
                        'portent sur la partie lisible.' % type(exc).__name__,
             'ligne': analyseur.ligne_courante()})
    document = analyseur.document
    document.source = source
    document.taille = len(source.encode('utf8', 'replace'))
    analyseur.clore_implicitement()
    return document, analyseur.blocs_css


class _Analyseur(HTMLParser):
    """Un HTMLParser qui construit un arbre et note les anomalies de structure.

    Les anomalies sont stockées brutes ici ; devweb_audits les transforme en
    constats d'audit. Séparer les deux évite que l'analyseur décide de la
    gravité, qui dépend de l'audit qui l'exploite.
    """

    def __init__(self, source=''):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.document = Document()
        self.pile = [self.document.racine]
        self.blocs_css = []
        self._ordre = 0
        self._source = source

    # ---------------------------------------------------------------- util ---
    def ligne_courante(self):
        try:
            return self.getpos()[0]
        except Exception:
            return None

    def _position(self):
        try:
            ligne, colonne = self.getpos()
        except Exception:
            return None, None
        return ligne, colonne + 1

    def _note(self, code, message, gravite='avertissement', element=None,
              ligne=None):
        if ligne is None:
            ligne = self.ligne_courante()
        self.document.anomalies.append({
            'code': code, 'gravite': gravite, 'message': message,
            'ligne': ligne,
            'element': element.signature() if element is not None else ''})

    def _nouvel(self, balise, attributs, autoferme=False):
        ligne, colonne = self._position()
        self._ordre += 1
        element = Element(balise, attributs, ligne, colonne, self._ordre)
        element.autoferme = autoferme
        element.parent = self.pile[-1]
        element.parent.enfants.append(element)
        if len(self.document.elements) < LIMITE_ELEMENTS:
            self.document.elements.append(element)
        ident = element.get('id')
        if ident:
            self.document.ids.setdefault(ident, []).append(element)
        return element

    def _normaliser(self, attributs):
        """Attributs en minuscules, valeurs en texte, doublons conservés."""
        propres = []
        for nom, valeur in (attributs or ()):
            if not isinstance(nom, str):
                continue
            if valeur is not None and not isinstance(valeur, str):
                valeur = str(valeur)
            propres.append((nom.lower(), valeur))
            if len(propres) >= LIMITE_ATTRIBUTS:
                self._note('attributs-trop-nombreux',
                           'Plus de %d attributs sur une balise : la suite est '
                           'ignorée par l’audit.' % LIMITE_ATTRIBUTS,
                           gravite='info')
                break
        return propres

    # -------------------------------------------------------------- évènements
    def handle_decl(self, decl):
        ligne, _ = self._position()
        if not self.document.doctype:
            self.document.doctype = decl.strip()
            self.document.doctype_ligne = ligne
        else:
            self._note('doctype-double',
                       'Plusieurs déclarations <!DOCTYPE> : seule la première '
                       'est prise en compte par le navigateur.', ligne=ligne)

    def handle_pi(self, donnees):
        self._note('instruction-traitement',
                   'Instruction de traitement <?%s…> ignorée en HTML.'
                   % donnees[:20].strip(), gravite='info')

    def handle_comment(self, donnees):
        ligne, colonne = self._position()
        self.document.commentaires.append(
            {'texte': donnees[:400], 'ligne': ligne, 'colonne': colonne})
        if '--' in donnees:
            self._note('commentaire-malforme',
                       'Un commentaire contient « -- », ce qui le termine plus '
                       'tôt que prévu pour certains navigateurs.',
                       gravite='info', ligne=ligne)

    def unknown_decl(self, donnees):
        self._note('declaration-inconnue',
                   'Déclaration <![%s…]> inconnue en HTML.' % donnees[:20],
                   gravite='info')

    def handle_starttag(self, balise, attributs):
        self._ouvrir(balise, self._normaliser(attributs), False)

    def handle_startendtag(self, balise, attributs):
        self._ouvrir(balise, self._normaliser(attributs), True)

    def _ouvrir(self, balise, attributs, autoferme):
        balise = (balise or '').lower()
        if not balise:
            return
        if len(self.document.elements) >= LIMITE_ELEMENTS:
            self._note('document-trop-grand',
                       'Le document dépasse %d éléments : l’analyse s’arrête '
                       'ici pour rester réactive.' % LIMITE_ELEMENTS,
                       gravite='info')
            return
        # Fermetures implicites : d'abord la règle propre à la balise, puis la
        # règle du paragraphe, qui s'applique à tout élément de bloc.
        fermes = IMPLICITES.get(balise, ())
        if balise in FERME_PARAGRAPHE:
            fermes = tuple(fermes) + ('p',)
        while len(self.pile) > 1 and self.pile[-1].balise in fermes:
            element = self.pile.pop()
            element.ferme = True
        element = self._nouvel(balise, attributs, autoferme)
        if balise in BRUT:
            # Le contenu brut est récupéré par handle_data ; on empile pour
            # pouvoir le rattacher, mais rien ne sera analysé dedans.
            self.pile.append(element)
            return
        if balise not in VIDES and not autoferme:
            self.pile.append(element)
        else:
            element.ferme = True
            if autoferme and balise not in VIDES:
                self._note('autofermeture',
                           '%s n’est pas une balise vide : l’écriture « /> » '
                           'est ignorée par les navigateurs HTML et la balise '
                           'reste ouverte.' % element.signature(),
                           element=element)

    def handle_endtag(self, balise):
        balise = (balise or '').lower()
        if not balise:
            return
        if balise in VIDES:
            self._note('fermeture-vide',
                       '</%s> : une balise vide n’a pas de balise fermante.'
                       % balise)
            return
        # Recherche dans la pile : si la balise y est, tout ce qui est au-dessus
        # n'a jamais été fermé (désordre) ; si elle n'y est pas, la fermeture
        # n'a rien à fermer.
        index = None
        for i in range(len(self.pile) - 1, 0, -1):
            if self.pile[i].balise == balise:
                index = i
                break
        if index is None:
            if balise in ('br', 'p'):
                return
            self._note('fermeture-orpheline',
                       '</%s> sans ouverture correspondante.' % balise)
            return
        element = self.pile[index]
        for oublie in self.pile[index + 1:]:
            oublie.ferme = True
            if oublie.balise in FERMETURE_OMISSIBLE:
                continue
            self._note('non-ferme',
                       '%s ouvert ligne %s n’est jamais fermé : %s l’a '
                       'refermé à sa place.'
                       % (oublie.signature(), oublie.ligne, element.signature()),
                       element=oublie, ligne=oublie.ligne)
        del self.pile[index:]
        element.ferme = True
        element.fin_ligne = self.ligne_courante()

    def handle_data(self, donnees):
        if not donnees:
            return
        courant = self.pile[-1]
        if courant.balise in ('script', 'style'):
            courant.brut_interne += donnees
            return
        courant.texte.append(donnees)

    def handle_entityref(self, nom):
        self.pile[-1].texte.append('&%s;' % nom)

    def handle_charref(self, nom):
        self.pile[-1].texte.append('&#%s;' % nom)

    def clore_implicitement(self):
        """Fin du document : ce qui reste ouvert est noté, sans excès.

        Les balises dont la fermeture est facultative (html, body, p, li, td…)
        ne produisent AUCUN constat : les omettre est conforme. Tout le reste
        est signalé comme avertissement, car un <div> jamais fermé décale la
        mise en page bien au-delà de l'endroit où il a été oublié.
        """
        for element in self.pile[1:]:
            if element.balise in ('script', 'style'):
                self._note('contenu-brut-non-ferme',
                           '%s n’est jamais fermé : tout le reste du document '
                           'est avalé comme son contenu.'
                           % element.signature(),
                           gravite='erreur', element=element,
                           ligne=element.ligne)
                continue
            element.ferme = True
            if element.balise in FERMETURE_OMISSIBLE:
                continue
            self._note('non-ferme',
                       '%s ouvert ligne %s n’est jamais fermé.'
                       % (element.signature(), element.ligne),
                       element=element, ligne=element.ligne)
        # Les blocs <style> sont extraits ici, une fois leur contenu complet.
        for element in self.document.par_balise('style'):
            if element.brut_interne.strip():
                self.blocs_css.append({
                    'texte': element.brut_interne,
                    'ligne': element.ligne,
                    'origine': 'style en ligne',
                    'media': element.get('media') or '',
                    'element': element,
                })


# --------------------------------------------------------------------- CSS ---
REGLE_MEDIA = re.compile(r'^@(media|supports|layer|container|scope)\b',
                         re.IGNORECASE)
REGLE_BLOC = re.compile(
    r'^@(font-face|page|counter-style|property|keyframes|'
    r'-webkit-keyframes|-moz-keyframes)\b', re.IGNORECASE)
REGLE_SIMPLE = re.compile(r'^@(import|charset|namespace|use)\b',
                          re.IGNORECASE)


class RegleCSS:
    __slots__ = ('selecteur', 'declarations', 'ligne', 'media', 'origine',
                 'brut', 'genre')

    def __init__(self, selecteur, declarations, ligne, media, origine, brut,
                 genre='regle'):
        self.selecteur = selecteur
        self.declarations = declarations    # [(propriete, valeur, importante, ligne)]
        self.ligne = ligne
        self.media = media
        self.origine = origine
        self.brut = brut
        self.genre = genre                  # regle | font-face | keyframes | import

    def valeur(self, propriete):
        propriete = propriete.lower()
        for nom, valeur, _importante, _ligne in self.declarations:
            if nom == propriete:
                return valeur
        return None

    def __repr__(self):
        return '<RegleCSS %s (%d declarations)>' % (self.selecteur,
                                                    len(self.declarations))


def analyser_css(texte, origine='feuille', ligne_decalage=0, media=''):
    """Découpe une feuille de style en règles, sans jamais lever.

    Renvoie (regles, erreurs). Les erreurs sont des constats bruts
    {'code','message','ligne'} ; devweb_audits leur donne une gravité.

    Le scan suit les accolades en ignorant celles qui apparaissent dans une
    chaîne, un commentaire ou un parenthésage : `content:"}"` ne ferme pas le
    bloc, et un bloc @media doit être refermé par SA propre accolade et non par
    la première rencontrée — sans ce compte, chaque @media produisait une fausse
    erreur « bloc jamais fermé » sur la règle qu'il contient.

    Les blocs imbriqués (@media, @supports, @keyframes) sont parcourus par un
    appel récursif qui reçoit le texte du bloc : chaque niveau a ses propres
    indices, et aucune variable de la fonction englobante n'est détournée.
    """
    regles = []
    erreurs = []
    if not isinstance(texte, str):
        return regles, erreurs
    if len(texte) > LIMITE_TEXTE:
        texte = texte[:LIMITE_TEXTE]
        erreurs.append({'code': 'css-tronque', 'ligne': None,
                        'message': 'Feuille trop volumineuse : analyse limitée '
                                   'aux %d premiers caractères.' % LIMITE_TEXTE})

    def parcourir(corps, decalage, media_courant):

        def ligne_de(index):
            return decalage + corps.count('\n', 0, index) + 1

        def sauter_blancs(i):
            while i < len(corps) and corps[i] in ' \t\r\n\f':
                i += 1
            return i

        def lire_commentaire(i):
            fin = corps.find('*/', i + 2)
            if fin < 0:
                erreurs.append({
                    'code': 'commentaire-ouvert', 'ligne': ligne_de(i),
                    'message': 'Commentaire /* jamais terminé : tout le reste '
                               'de la feuille est ignoré par le navigateur.'})
                return len(corps), True
            return fin + 2, False

        def sauter_chaine(i):
            guillemet = corps[i]
            j = i + 1
            while j < len(corps):
                if corps[j] == '\\':
                    j += 2
                    continue
                if corps[j] == guillemet:
                    return j + 1, False
                if corps[j] == '\n':
                    return j, True
                j += 1
            return j, True

        def chercher(i, cible):
            """Prochaine occurrence de `cible` au niveau d'imbrication courant.

            Hors commentaire, hors chaîne, et en tenant compte DES DEUX
            parenthésages : les parenthèses (url(), calc()) et les accolades.
            """
            parenthesage = 0
            accolades = 0
            while i < len(corps):
                caractere = corps[i]
                if caractere == '/' and corps.startswith('/*', i):
                    i, casse = lire_commentaire(i)
                    if casse:
                        return -1
                    continue
                if caractere in '"\'':
                    i, casse = sauter_chaine(i)
                    if casse:
                        erreurs.append({
                            'code': 'chaine-ouverte', 'ligne': ligne_de(i),
                            'message': 'Chaîne non terminée : la règle est '
                                       'ignorée par le navigateur.'})
                        return -1
                    continue
                # La cible est testée AVANT le compte des accolades : sinon la
                # recherche d'un « { » incrémentait le compteur au lieu de
                # renvoyer la position, et AUCUNE règle n'était trouvée.
                if parenthesage == 0 and accolades == 0 \
                        and corps.startswith(cible, i):
                    return i
                if caractere == '(':
                    parenthesage += 1
                elif caractere == ')':
                    parenthesage = max(0, parenthesage - 1)
                elif caractere == '{':
                    accolades += 1
                elif caractere == '}':
                    accolades = max(0, accolades - 1)
                i += 1
            return -1

        def lire_bloc(i):
            """i pointe l'accolade ouvrante ; renvoie (contenu, index_apres)."""
            fin = chercher(i + 1, '}')
            if fin < 0:
                erreurs.append({
                    'code': 'accolade-ouverte', 'ligne': ligne_de(i),
                    'message': 'Bloc { jamais fermé : les règles qui suivent '
                               'sont ignorées par le navigateur.'})
                return corps[i + 1:], len(corps)
            return corps[i + 1:fin], fin + 1

        def lire_declarations(contenu, ligne_base):
            declarations = []
            morceaux = []          # [(indice_de_départ, texte)]
            courant = []
            depart = 0
            parenthesage = 0
            i = 0
            while i < len(contenu):
                caractere = contenu[i]
                if caractere == '/' and contenu.startswith('/*', i):
                    fin = contenu.find('*/', i + 2)
                    if fin < 0:
                        erreurs.append({
                            'code': 'commentaire-ouvert',
                            'ligne': ligne_base + contenu.count('\n', 0, i),
                            'message': 'Commentaire /* jamais terminé dans une '
                                       'déclaration.'})
                        i = len(contenu)
                        break
                    i = fin + 2
                    continue
                if caractere in '"\'':
                    guillemet = caractere
                    j = i + 1
                    while j < len(contenu) and contenu[j] != guillemet:
                        j += 2 if contenu[j] == '\\' else 1
                    courant.append(contenu[i:j + 1])
                    i = j + 1
                    continue
                if caractere == '(':
                    parenthesage += 1
                elif caractere == ')':
                    parenthesage = max(0, parenthesage - 1)
                elif caractere == ';' and parenthesage == 0:
                    morceaux.append((depart, ''.join(courant)))
                    courant = []
                    i += 1
                    depart = i
                    continue
                courant.append(caractere)
                i += 1
            morceaux.append((depart, ''.join(courant)))
            for indice, morceau in morceaux:
                brut = morceau.strip()
                if not brut:
                    continue
                deux_points = None
                parenthesage = 0
                for k, caractere in enumerate(brut):
                    if caractere in '([':
                        parenthesage += 1
                    elif caractere in ')]':
                        parenthesage -= 1
                    elif caractere == ':' and parenthesage == 0:
                        deux_points = k
                        break
                ligne = ligne_base + contenu.count('\n', 0, indice)
                if deux_points is None:
                    erreurs.append({
                        'code': 'declaration-sans-deux-points', 'ligne': ligne,
                        'message': '« %s » n\'est pas une déclaration : il '
                                   'manque le deux-points.' % brut[:60]})
                    continue
                nom = brut[:deux_points].strip().lower()
                valeur = brut[deux_points + 1:].strip()
                importante = False
                if valeur.lower().endswith('!important'):
                    importante = True
                    valeur = valeur[:-len('!important')].strip()
                if not nom:
                    erreurs.append({'code': 'propriete-vide', 'ligne': ligne,
                                    'message': 'Déclaration sans nom de '
                                               'propriété.'})
                    continue
                declarations.append((nom, valeur, importante, ligne))
            return declarations

        i = sauter_blancs(0)
        while i < len(corps):
            caractere = corps[i]
            if caractere == '/' and corps.startswith('/*', i):
                i, casse = lire_commentaire(i)
                if casse:
                    return
                i = sauter_blancs(i)
                continue
            if caractere == '}':
                erreurs.append({
                    'code': 'accolade-fermante-seule', 'ligne': ligne_de(i),
                    'message': 'Une accolade fermante } n\'a pas de bloc '
                               'ouvrant correspondant.'})
                i += 1
                continue
            ouverture = chercher(i, '{')
            if ouverture < 0:
                reste = corps[i:].strip()
                if reste:
                    if REGLE_SIMPLE.match(reste):
                        regles.append(RegleCSS(reste.split(';')[0], [],
                                               ligne_de(i), media_courant,
                                               origine, reste[:120], 'import'))
                    elif reste.startswith('@'):
                        erreurs.append({
                            'code': 'at-regle-incomplete', 'ligne': ligne_de(i),
                            'message': 'Règle @ sans bloc ni point-virgule : '
                                       '« %s ».' % reste[:60]})
                    else:
                        erreurs.append({
                            'code': 'texte-hors-regle', 'ligne': ligne_de(i),
                            'message': 'Texte hors de toute règle : « %s ».'
                                       % reste[:60]})
                return
            entete = corps[i:ouverture].strip()
            ligne = ligne_de(i)
            contenu, suivant = lire_bloc(ouverture)
            if not entete:
                erreurs.append({'code': 'selecteur-vide', 'ligne': ligne,
                                'message': 'Un bloc { n\'a pas de sélecteur : '
                                           'il est ignoré.'})
                i = sauter_blancs(suivant)
                continue
            if REGLE_MEDIA.match(entete):
                regles.append(RegleCSS(entete, [], ligne, media_courant,
                                       origine, entete + '{…}', 'media'))
                parcourir(contenu, ligne, entete)
            elif REGLE_BLOC.match(entete) and 'keyframes' in entete.lower():
                regles.append(RegleCSS(entete, [], ligne, media_courant,
                                       origine, entete + '{…}', 'keyframes'))
                avant = len(regles)
                parcourir(contenu, ligne, media_courant)
                for regle in regles[avant:]:
                    regle.selecteur = '%s → %s' % (entete, regle.selecteur)
                    regle.genre = 'keyframes'
            elif REGLE_BLOC.match(entete):
                regles.append(RegleCSS(
                    entete, lire_declarations(contenu, ligne), ligne,
                    media_courant, origine,
                    entete + '{' + contenu.strip()[:80], 'font-face'))
            elif REGLE_SIMPLE.match(entete):
                regles.append(RegleCSS(entete, [], ligne, media_courant,
                                       origine,
                                       entete + contenu.strip()[:80], 'import'))
            else:
                regles.append(RegleCSS(
                    entete, lire_declarations(contenu, ligne), ligne,
                    media_courant, origine,
                    entete + '{' + contenu.strip()[:120]))
            i = sauter_blancs(suivant)

    try:
        parcourir(texte, ligne_decalage, media)
    except RecursionError:
        erreurs.append({'code': 'css-trop-imbrique', 'ligne': None,
                        'message': 'Feuille trop imbriquée : l\'analyse s\'est '
                                   'arrêtée pour rester réactive.'})
    except Exception as exc:
        erreurs.append({'code': 'analyse-css-interrompue', 'ligne': None,
                        'message': 'Analyse CSS interrompue (%s) : les règles '
                                   'lues avant sont conservées.'
                                   % type(exc).__name__})
    return regles, erreurs


def dimensions_image(donnees):
    """(largeur, hauteur) d'une image, depuis ses seuls octets d'en-tête.

    PNG, JPEG, GIF, WebP et BMP. Renvoie (None, None) si le format n'est pas
    reconnu : deviner une taille ferait dire à l'audit de poids qu'une image est
    surdimensionnée alors qu'elle ne l'est peut-être pas.
    """
    if not isinstance(donnees, (bytes, bytearray)) or len(donnees) < 24:
        return None, None
    donnees = bytes(donnees)
    try:
        if donnees[:8] == b'\x89PNG\r\n\x1a\n' and donnees[12:16] == b'IHDR':
            return (int.from_bytes(donnees[16:20], 'big'),
                    int.from_bytes(donnees[20:24], 'big'))
        if donnees[:6] in (b'GIF87a', b'GIF89a'):
            return (int.from_bytes(donnees[6:8], 'little'),
                    int.from_bytes(donnees[8:10], 'little'))
        if donnees[:2] == b'BM':
            return (int.from_bytes(donnees[18:22], 'little'),
                    abs(int.from_bytes(donnees[22:26], 'little', signed=True)))
        if donnees[:4] == b'RIFF' and donnees[8:12] == b'WEBP':
            format_interne = donnees[12:16]
            if format_interne == b'VP8X':
                largeur = 1 + int.from_bytes(donnees[24:27], 'little')
                hauteur = 1 + int.from_bytes(donnees[27:30], 'little')
                return largeur, hauteur
            if format_interne == b'VP8 ':
                return (int.from_bytes(donnees[26:28], 'little') & 0x3FFF,
                        int.from_bytes(donnees[28:30], 'little') & 0x3FFF)
            if format_interne == b'VP8L' and len(donnees) > 25:
                bloc = int.from_bytes(donnees[21:25], 'little')
                return (bloc & 0x3FFF) + 1, ((bloc >> 14) & 0x3FFF) + 1
            return None, None
        if donnees[:2] == b'\xff\xd8':
            index = 2
            while index + 9 < len(donnees):
                if donnees[index] != 0xFF:
                    index += 1
                    continue
                marqueur = donnees[index + 1]
                if marqueur in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                                0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    hauteur = int.from_bytes(donnees[index + 5:index + 7], 'big')
                    largeur = int.from_bytes(donnees[index + 7:index + 9], 'big')
                    return largeur, hauteur
                if marqueur in (0xD8, 0x01) or 0xD0 <= marqueur <= 0xD7:
                    index += 2
                    continue
                longueur = int.from_bytes(donnees[index + 2:index + 4], 'big')
                if longueur < 2:
                    break
                index += 2 + longueur
            return None, None
    except Exception:
        return None, None
    return None, None


def rapport_luminosite(couleur):
    """Luminosité relative WCAG d'une couleur CSS simple, ou None.

    Seuls les formats non ambigus sont acceptés (#rgb, #rrggbb, #rrggbbaa,
    rgb(), rgba(), et une courte liste de noms). Une couleur en hsl(), en
    color() ou en var() renvoie None : deviner une valeur ferait prononcer un
    contraste faux, et un faux constat de contraste est le genre d'erreur qui
    fait ignorer tout un rapport d'accessibilité.
    """
    if not isinstance(couleur, str):
        return None
    valeur = couleur.strip().lower()
    if not valeur or valeur.startswith('var(') or valeur == 'inherit' \
            or valeur in ('currentcolor', 'transparent', 'initial', 'unset'):
        return None
    noms = {
        'white': '#ffffff', 'black': '#000000', 'red': '#ff0000',
        'green': '#008000', 'lime': '#00ff00', 'blue': '#0000ff',
        'yellow': '#ffff00', 'gray': '#808080', 'grey': '#808080',
        'silver': '#c0c0c0', 'navy': '#000080', 'orange': '#ffa500',
        'purple': '#800080', 'teal': '#008080', 'maroon': '#800000',
        'olive': '#808000', 'fuchsia': '#ff00ff', 'aqua': '#00ffff',
    }
    if valeur in noms:
        valeur = noms[valeur]
    rouge = vert = bleu = None
    if valeur.startswith('#'):
        hexadecimal = valeur[1:]
        if len(hexadecimal) in (3, 4):
            hexadecimal = ''.join(c * 2 for c in hexadecimal)
        if len(hexadecimal) not in (6, 8):
            return None
        if not re.fullmatch(r'[0-9a-f]{6}([0-9a-f]{2})?', hexadecimal):
            return None
        rouge = int(hexadecimal[0:2], 16)
        vert = int(hexadecimal[2:4], 16)
        bleu = int(hexadecimal[4:6], 16)
        if len(hexadecimal) == 8:
            alpha = int(hexadecimal[6:8], 16) / 255.0
            if alpha < 0.99:
                # Une couleur partiellement transparente dépend du fond sur
                # lequel elle est posée : aucun contraste fiable n'est
                # calculable ici.
                return None
    else:
        correspondance = re.match(r'rgba?\(\s*([^)]*)\)\s*$', valeur)
        if not correspondance:
            return None
        parties = [p.strip() for p in correspondance.group(1).replace(',', ' ').split()]
        if any('%' in p for p in parties) or len(parties) < 3:
            return None
        try:
            rouge, vert, bleu = (int(float(p)) for p in parties[:3])
        except ValueError:
            return None
        if len(parties) == 4:
            try:
                if float(parties[3]) < 0.99:
                    return None
            except ValueError:
                return None
    if rouge is None:
        return None

    def canal(composante):
        composante = max(0, min(255, composante)) / 255.0
        return composante / 12.92 if composante <= 0.03928 \
            else ((composante + 0.055) / 1.055) ** 2.4

    return 0.2126 * canal(rouge) + 0.7152 * canal(vert) + 0.0722 * canal(bleu)


def contraste(premiere, seconde):
    """Rapport de contraste WCAG entre deux couleurs, ou None."""
    a = rapport_luminosite(premiere)
    b = rapport_luminosite(seconde)
    if a is None or b is None:
        return None
    claire, foncee = max(a, b), min(a, b)
    return round((claire + 0.05) / (foncee + 0.05), 2)


if __name__ == '__main__':
    # Autocontrôle : ce module sert de base aux six audits, il doit être
    # exécuté avant eux (leçon des défauts invisibles à la lecture).
    import sys

    echecs = []

    def verif(condition, message):
        if not condition:
            echecs.append(message)

    document, blocs = analyser_html(
        '<!DOCTYPE html>\n<html lang="fr"><head><meta charset="utf-8">'
        '<title>Essai</title><style>body{color:#111;background:#fff}</style>'
        '</head><body><ul><li>un<li>deux</ul><p>texte<p>autre'
        '<div id="x">ouvert<span>croisé</div></span></body>')
    verif(document.doctype.upper().startswith('DOCTYPE'), 'doctype lu')
    verif(document.meta('charset') == '' and document.premier('meta').get('charset') == 'utf-8',
          'attribut charset lu')
    verif(document.titre() == 'Essai', 'titre lu')
    items = document.par_balise('li')
    verif(len(items) == 2 and all(i.ferme for i in items),
          'les <li> sans fermeture ne sont pas signalés comme ouverts')
    paragraphes = document.par_balise('p')
    verif(len(paragraphes) == 2 and all(p.ferme for p in paragraphes),
          'les <p> sans fermeture ne sont pas signalés comme ouverts')
    verif(not any(a['code'] == 'non-ferme' and a['element'].startswith('<li')
                  for a in document.anomalies),
          'aucun constat « non fermé » pour un <li>')
    document2, _ = analyser_html('<!doctype html><html><body><div id="y">ouvert'
                                 '<p>texte</body></html>')
    verif(any(a['code'] == 'non-ferme' and '<div' in a['element']
              for a in document2.anomalies),
          'un <div> jamais fermé EST signalé')
    verif(not any(a['code'] == 'non-ferme' and a['element'].startswith('<p')
                  for a in document2.anomalies),
          'un <p> non fermé à la fin du document n’est PAS signalé : c’est conforme')
    document3, _ = analyser_html('<div>jamais fermé')
    verif(any(a['code'] == 'non-ferme' for a in document3.anomalies),
          'un document sans </body> signale quand même le <div> ouvert')
    verif(any(a['code'] == 'non-ferme' and '<span' in a['element']
              for a in document.anomalies),
          'le <span> refermé par </div> est signalé comme jamais fermé')
    verif(any(a['code'] == 'fermeture-orpheline' for a in document.anomalies),
          'le </span> qui ne ferme rien est signalé')
    verif(len(blocs) == 1 and 'color' in blocs[0]['texte'], 'bloc <style> extrait')

    regles, erreurs = analyser_css(
        'body{color:#111;background:#fff}\n'
        '@media (max-width:600px){.a{display:none}}\n'
        '.b{content:"}";padding:0}\n'
        '.c{margin:0}\n'
        '@font-face{font-family:"X";src:url(x.woff2)}\n')
    verif(len([r for r in regles if r.selecteur == 'body']) == 1, 'règle body lue')
    verif(any(r.genre == 'media' for r in regles), '@media reconnu comme groupe')
    verif(any(r.selecteur == '.a' and r.media for r in regles),
          'règle imbriquée dans @media lue avec son média')
    verif(not any(e['code'] == 'accolade-ouverte' for e in erreurs),
          'une accolade dans une chaîne ne ferme pas le bloc')
    verif(any(r.selecteur == '.c' for r in regles),
          'la règle après la chaîne est toujours lue')
    verif(any(r.genre == 'font-face' for r in regles), '@font-face reconnu')
    verif(regles[0].valeur('color') == '#111', 'valeur de propriété lue')

    casses, erreurs2 = analyser_css('.x{color:red')
    verif(any(e['code'] == 'accolade-ouverte' for e in erreurs2),
          'un bloc non fermé EST signalé')

    verif(dimensions_image(bytes.fromhex(
        '89504e470d0a1a0a0000000d494844520000001000000020')) == (16, 32),
        'dimensions PNG lues')
    verif(dimensions_image(b'GIF89a' + (10).to_bytes(2, 'little')
                           + (20).to_bytes(2, 'little') + b'\x00' * 20) == (10, 20),
        'dimensions GIF lues')
    verif(dimensions_image(b'pas une image' * 4) == (None, None),
        'format inconnu -> (None, None), pas de taille inventée')

    verif(contraste('#000000', '#ffffff') == 21.0, 'contraste noir/blanc = 21')
    verif(contraste('#777777', '#777777') == 1.0, 'contraste identique = 1')
    verif(contraste('var(--x)', '#fff') is None,
          'une couleur en var() ne donne PAS de contraste deviné')
    verif(contraste('rgba(0,0,0,.5)', '#fff') is None,
          'une couleur transparente ne donne pas de contraste deviné')
    verif(abs(rapport_luminosite('#fff') - 1.0) < 1e-9, 'blanc = luminosité 1')

    print('devweb_analyse : %s' % ('ÉCHECS : ' + ' ; '.join(echecs) if echecs
                                   else 'autocontrôle OK (%d contrôles)' % 28))
    sys.exit(1 if echecs else 0)
