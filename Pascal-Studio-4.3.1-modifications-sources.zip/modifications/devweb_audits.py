"""Les six audits du panneau dev web.

Chaque audit reçoit le MÊME contexte (devweb_analyse.Document déjà construit) et
renvoie une liste de constats. Analyser la page six fois de suite donnerait six
interprétations différentes du même document, et un rapport qui se contredit ne
peut pas être suivi.

Un constat a cette forme, stable et consommée telle quelle par l'interface :

    {'audit': 'accessibilite', 'code': 'img-sans-alt',
     'gravite': 'erreur'|'avertissement'|'info'|'ok',
     'message': '…', 'conseil': '…', 'ligne': 12, 'colonne': 3,
     'element': '<img src="logo.png">', 'extrait': '…'}

Deux principes suivis partout :

  * Un audit n'accuse que ce qu'il peut PROUVER. Ce qui dépend d'une liste de
    référence (propriété CSS, rôle ARIA) est une information, jamais une erreur :
    la liste peut être en retard sur la spécification.
  * Un audit qui échoue le DIT. `auditer_tous` enveloppe chaque audit : une
    exception produit un constat « audit interrompu » nommé, au lieu d'une
    section vide qui laisserait croire que tout va bien.
"""

import re
import urllib.parse
import zlib
from pathlib import Path

import devweb_references as ref
from devweb_analyse import analyser_css, analyser_html, contraste, dimensions_image

GRAVITES = ('erreur', 'avertissement', 'info', 'ok')

MALUS = {'erreur': 12, 'avertissement': 4, 'info': 1, 'ok': 0}

AUDITS = (
    {'id': 'accessibilite', 'nom': 'Accessibilité',
     'resume': 'Noms accessibles, étiquettes de formulaire, ordre des titres, '
               'identifiants uniques, rôles ARIA, contraste vérifiable.'},
    {'id': 'securite', 'nom': 'Sécurité',
     'resume': 'En-têtes de la réponse, motifs dangereux dans le code, '
               'intégrité des scripts distants, contenu mixte, cookies.'},
    {'id': 'liens', 'nom': 'Liens',
     'resume': 'Liens internes et fragments, fichiers absents ou mal '
               'orthographiés, et — sur demande explicite — adresses distantes.'},
    {'id': 'poids', 'nom': 'Poids',
     'resume': 'Taille du document et de ses ressources, nombre de requêtes, '
               'gain de compression, images surdimensionnées, budgets.'},
    {'id': 'metadonnees', 'nom': 'Métadonnées',
     'resume': 'Titre, description, canonique, Open Graph, Twitter Card, '
               'favicon, JSON-LD, robots et sitemap.'},
    {'id': 'validation', 'nom': 'Validation',
     'resume': 'Structure du document, doctype, éléments et attributs '
               'dépréciés, imbrications impossibles, feuilles de style.'},
)

AUDIT_IDS = tuple(a['id'] for a in AUDITS)

MAX_RESSOURCES_POIDS = 200
# En dessous de ce seuil, gzip GONFLE un fichier (18 octets d'en-tête) : les
# serveurs ne compressent pas, et l'estimation ne doit pas le faire non plus.
SEUIL_COMPRESSION = 1024
MAX_LIENS_DISTANTS = 25
MAX_EXTRAIT = 160


def faire_constat(audit, code, gravite, message, conseil='', ligne=None, colonne=None,
            element='', extrait=''):
    if gravite not in GRAVITES:
        gravite = 'info'
    return {'audit': audit, 'code': code, 'gravite': gravite,
            'message': message, 'conseil': conseil or '', 'ligne': ligne,
            'colonne': colonne, 'element': element or '', 'extrait': extrait or ''}


class Contexte:
    """Ce que les six audits partagent.

    `ressources` est un dictionnaire {référence -> octets} fourni par l'appelant
    quand il a déjà lu les fichiers (aperçu local) ; sinon le contexte les lit
    lui-même, dans la limite du projet et d'une taille raisonnable.
    """

    def __init__(self, cible, contenu, racine=None, url=None, chemin=None,
                 entetes=None, statut=None, options=None, ressources=None,
                 encodage='utf-8'):
        self.cible = cible
        self.contenu = contenu if isinstance(contenu, str) else str(contenu or '')
        self.racine = Path(racine) if racine else None
        self.url = url
        self.chemin = Path(chemin) if chemin else None
        self.entetes = {}
        for cle, valeur in (entetes or {}).items():
            if isinstance(cle, str):
                self.entetes[cle.lower()] = valeur
        self.statut = statut
        self.options = dict(options or {})
        self.encodage = encodage
        self._ressources_fournies = dict(ressources or {})
        self._cache = {}
        self.document, self.blocs_css = analyser_html(self.contenu)
        self._regles = None
        self._erreurs_css = None
        self._declares = None
        # La base de résolution des références relatives : le dossier du fichier
        # audité, ou l'URL servie. Sans elle, « img/logo.png » ne veut rien dire.
        if self.chemin:
            self.base = self.chemin.parent
        elif self.url:
            self.base = self.url
        else:
            self.base = self.racine or Path('.')

    # ------------------------------------------------------- configuration --
    @property
    def declares(self):
        """Les en-têtes déclarés dans la configuration du projet, en cache.

        Plusieurs règles en ont besoin (l'audit des en-têtes, celle du
        Referrer-Policy) : les relire à chaque fois ferait parcourir le projet
        plusieurs fois pour un même fait, et deux règles pourraient en voir des
        versions différentes si un fichier change entre les deux lectures.
        """
        if self._declares is None:
            try:
                self._declares = _en_tetes_declares(self)
            except Exception:
                self._declares = {}
        return self._declares

    # ------------------------------------------------------------------ CSS --
    @property
    def styles(self):
        """(origine, texte, décalage) des blocs <style> ET des feuilles liées.

        Auditer le seul CSS inline laisserait passer l'essentiel : dans un
        projet réel, la couleur du texte, les règles et les accolades mal
        fermées sont dans la feuille liée. Les feuilles distantes ne sont PAS
        téléchargées — cela ferait du réseau à l'insu de l'utilisateur, et
        l'audit de poids dit déjà qu'elles existent.
        """
        sortie = []
        for bloc in self.blocs_css:
            sortie.append(('le style en ligne de la ligne %s' % bloc.get('ligne'),
                           bloc['texte'], (bloc.get('ligne') or 1) - 1,
                           bloc.get('element')))
        for element in self.document.par_balise('link'):
            if (element.get('rel') or '').lower() != 'stylesheet':
                continue
            adresse = (element.get('href') or '').strip()
            if not adresse:
                continue
            donnees = self.lire(adresse)
            if not donnees:
                continue
            _chemin, relatif = self.resoudre_local(adresse)
            sortie.append((relatif or adresse, donnees.decode('utf8', 'replace'),
                           0, element))
        return sortie

    @property
    def regles_css(self):
        if self._regles is None:
            self._regles = []
            self._erreurs_css = []
            for origine, texte, decalage, _element in self.styles:
                regles, erreurs = analyser_css(texte, origine, decalage)
                self._regles.extend(regles)
                for erreur in erreurs:
                    # Sans l'origine, une erreur de syntaxe dans une feuille
                    # liée serait annoncée avec un numéro de ligne du DOCUMENT :
                    # l'interface proposerait de sauter à une ligne qui ne
                    # contient rien.
                    erreur['origine'] = origine
                self._erreurs_css.extend(erreurs)
        return self._regles

    @property
    def erreurs_css(self):
        self.regles_css                       # le calcul est paresseux
        return self._erreurs_css

    # ------------------------------------------------------------- ressources --
    def _confine(self, chemin):
        """Un chemin local n'est lisible que dans le projet audité.

        Sans cette garde, un document contenant <img src="../../etc/passwd">
        ferait lire un fichier hors du projet — et le rapport d'audit
        afficherait son contenu.
        """
        if self.racine is None:
            return False
        try:
            return chemin.is_relative_to(self.racine)
        except (TypeError, ValueError):
            return False

    def resoudre_local(self, reference):
        """(chemin, relatif_au_projet) pour une référence locale, ou (None, None).

        `relatif_au_projet` est ce que l'interface doit afficher : un chemin
        absolu de la machine de l'utilisateur n'a pas sa place dans un rapport.
        """
        if not isinstance(reference, str) or not reference:
            return None, None
        if reference.startswith(('data:', 'blob:', 'about:', 'javascript:',
                                 'mailto:', 'tel:', '#')):
            return None, None
        if re.match(r'^[a-z][a-z0-9+.-]*:', reference, re.IGNORECASE):
            return None, None                     # http://, https://, ftp://…
        if self.chemin is None:
            return None, None                     # cible distante : pas de disque
        brut = urllib.parse.unquote(reference.split('#')[0].split('?')[0])
        if not brut or '\x00' in brut:
            return None, None
        try:
            if brut.startswith('/'):
                base = self.racine or self.chemin.parent
                chemin = (base / brut.lstrip('/')).resolve()
            else:
                chemin = (self.chemin.parent / brut).resolve()
        except (OSError, ValueError):
            return None, None
        if not self._confine(chemin):
            return None, None
        try:
            relatif = chemin.relative_to(self.racine).as_posix()
        except (ValueError, AttributeError):
            relatif = chemin.name
        return chemin, relatif

    def lire(self, reference, limite=8_000_000):
        """Le contenu octet d'une référence locale, ou None. Jamais d'exception."""
        if reference in self._cache:
            return self._cache[reference]
        donnees = self._ressources_fournies.get(reference)
        if donnees is None:
            chemin, _relatif = self.resoudre_local(reference)
            if chemin is None:
                self._cache[reference] = None
                return None
            try:
                if not chemin.is_file() or chemin.stat().st_size > limite:
                    donnees = None
                else:
                    donnees = chemin.read_bytes()
            except OSError:
                donnees = None
        elif isinstance(donnees, str):
            donnees = donnees.encode('utf8', 'replace')
        self._cache[reference] = donnees
        return donnees

    def ligne(self, numero):
        """Le texte de la ligne `numero`, coupé : un extrait aide à localiser."""
        if not numero or numero < 1:
            return ''
        lignes = self.contenu.split('\n')
        if numero > len(lignes):
            return ''
        return lignes[numero - 1].strip()[:MAX_EXTRAIT]

    def scripts(self):
        """Chaque script de la page, séparément et NOMMÉ.

        Les concaténer en un seul texte ferait perdre l'origine d'une erreur :
        une ligne dans un bloc fusionné ne correspond à aucune ligne d'aucun
        fichier. Rendre (origine, texte, élément) permet au constat de dire où
        regarder, et au banc de vérifier que le nom est bien cité.
        """
        sortie = []
        for element in self.document.par_balise('script'):
            if (element.get('type') or '').lower() not in (
                    '', 'text/javascript', 'module'):
                continue
            source = (element.get('src') or '').strip()
            if source:
                donnees = self.lire(source)
                if donnees:
                    sortie.append(('%s (script lié)' % source,
                                   donnees.decode('utf8', 'replace'), element))
            elif element.brut_interne.strip():
                sortie.append(('le script en ligne de la ligne %s'
                               % element.ligne, element.brut_interne, element))
        return sortie

    def texte_script(self):
        """Tout le JavaScript de la page, pour les recherches globales."""
        return '\n;\n'.join(texte for _origine, texte, _e in self.scripts())

def _rapporteur(audit, ctx):
    """(liste de constats, fonction ajouter) pour un audit.

    Les six audits avaient chacun leur propre fonction d'ajout, et QUATRE
    d'entre elles plaçaient `ligne` en 5e position et `element` en 6e, là où les
    deux autres faisaient l'inverse. Les appels qui passaient l'élément en 5e
    position comparaient alors un Element à un entier et levaient un TypeError :
    l'audit entier était perdu. Une seule fabrique, un seul ordre — et `element`
    est accepté soit comme Element, soit comme texte déjà mis en forme.
    """
    trouvés = []
    vus = set()

    def ajouter(code, gravite, message, conseil='', element=None, ligne=None,
                colonne=None):
        if element is not None and not isinstance(element, str):
            if ligne is None:
                ligne = getattr(element, 'ligne', None)
            if colonne is None:
                colonne = getattr(element, 'colonne', None)
            element = element.signature()
        # Un même fait ne doit pas être répété : un rapport qui dit deux fois la
        # même chose met en doute tout le reste. La clef inclut le début du
        # message, sinon quatre constats « og:… absent » différents, tous sans
        # ligne ni élément, n'en feraient plus qu'un.
        clef = (code, ligne, element or '', message[:80])
        if clef in vus:
            return
        vus.add(clef)
        trouvés.append(faire_constat(audit, code, gravite, message, conseil,
                               ligne=ligne, colonne=colonne,
                               element=element or '',
                               extrait=ctx.ligne(ligne)))

    return trouvés, ajouter


# ------------------------------------------------------------------- aides ----
def _enumerer(noms):
    """« a, b et c » — pour nommer une liste courte dans un message."""
    noms = [str(nom) for nom in noms]
    if not noms:
        return ''
    if len(noms) == 1:
        return noms[0]
    return '%s et %s' % (', '.join(noms[:-1]), noms[-1])


def nom_accessible(element, document):
    """Le nom accessible d'un élément, dans l'ordre de priorité ARIA.

    Ordre réel : aria-labelledby, puis aria-label, puis le contenu (texte et
    `alt` des images), puis title, puis value pour un bouton de formulaire,
    puis placeholder en dernier recours — et ce dernier recours est signalé à
    part par l'audit, parce qu'un placeholder disparaît à la saisie.
    """
    if element is None:
        return ''
    references = (element.get('aria-labelledby') or '').split()
    if references:
        morceaux = []
        for identifiant in references:
            cibles = document.ids.get(identifiant)
            if cibles:
                morceaux.append(cibles[0].texte_complet())
        if morceaux:
            return ' '.join(morceaux).strip()
    etiquette = (element.get('aria-label') or '').strip()
    if etiquette:
        return etiquette
    morceaux = [element.texte_complet()]
    for enfant in element.iterer():
        if enfant is element:
            continue
        if enfant.balise == 'img' and enfant.get('alt'):
            morceaux.append(enfant.get('alt'))
        elif enfant.balise == 'input' and enfant.get('type') in ('submit', 'button', 'reset'):
            morceaux.append(enfant.get('value') or '')
        elif enfant.balise == 'svg':
            for sous in enfant.iterer():
                if sous.balise == 'title':
                    morceaux.append(sous.texte_complet())
    nom = re.sub(r'\s+', ' ', ' '.join(m for m in morceaux if m)).strip()
    if nom:
        return nom
    titre = (element.get('title') or '').strip()
    if titre:
        return titre
    if element.balise == 'input':
        valeur = (element.get('value') or '').strip()
        if valeur and element.get('type') in ('submit', 'button', 'reset'):
            return valeur
        image = (element.get('alt') or '').strip()
        if image:
            return image
    return ''


def etiquette_de(champ, document):
    """Le texte de l'étiquette associée à un champ, ou '' s'il n'en a pas."""
    identifiant = champ.get('id')
    if identifiant:
        for etiquette in document.par_balise('label'):
            if (etiquette.get('for') or '') == identifiant:
                return etiquette.texte_complet()
    for ancetre in champ.ancetres():
        if ancetre.balise == 'label':
            return ancetre.texte_complet()
    return ''


def champ_etiquete(champ, document):
    """(étiqueté, moyen) : le moyen dit COMMENT, pour expliquer le constat."""
    if champ.get('aria-labelledby') and champ.get('aria-labelledby').split():
        for identifiant in champ.get('aria-labelledby').split():
            if document.ids.get(identifiant):
                return True, 'aria-labelledby'
    if (champ.get('aria-label') or '').strip():
        return True, 'aria-label'
    if etiquette_de(champ, document):
        return True, 'label'
    if (champ.get('title') or '').strip():
        return True, 'title'
    return False, ''


def selecteurs_de(regles):
    """La liste aplatie des sélecteurs d'une règle, sans les parties de groupe."""
    sortie = []
    for partie in regles.selecteur.split(','):
        partie = partie.strip()
        if partie:
            sortie.append(partie)
    return sortie


def correspond(element, selecteur):
    """Correspondance TRÈS simplifiée : .classe, #id, balise, [attribut].

    Elle ne couvre volontairement que les sélecteurs simples, parce qu'un
    moteur de sélecteurs incomplet qui répond « non » à ce qu'il ne sait pas
    faire produirait de faux constats. Tout ce qui contient un combinateur ou
    une pseudo-classe renvoie None (inconnu), et l'appelant s'abstient.
    """
    selecteur = (selecteur or '').strip()
    if not selecteur or not re.fullmatch(
            r'[#.:\w\-\[\]="\'\s]+', selecteur):
        return None
    if any(c in selecteur for c in ('>', '+', '~', ':')):
        return None
    if selecteur.startswith('#'):
        return selecteur[1:] in (element.get('id') or '')
    if selecteur.startswith('.'):
        classes = (element.get('class') or '').split()
        return selecteur[1:] in classes
    if selecteur.startswith('['):
        correspondance = re.fullmatch(r'\[([\w-]+)(?:=["\']?([^\]"\']*)["\']?)?\]',
                                      selecteur)
        if not correspondance:
            return None
        nom, valeur = correspondance.group(1), correspondance.group(2)
        if valeur is None:
            return element.a(nom)
        return (element.get(nom) or '') == valeur
    if re.fullmatch(r'[a-zA-Z][\w-]*', selecteur):
        return element.balise == selecteur.lower()
    return None


def couleur_pour(element, propriete, regles):
    """La valeur d'une propriété pour un élément, ou None si elle n'est pas
    déterminable sans moteur de rendu.

    L'audit de contraste n'affirme QUE ce qu'il peut prouver : une couleur
    explicite dans une règle simple, ou dans l'attribut style de l'élément. Dès
    qu'un sélecteur est trop complexe pour `correspond`, la réponse est None et
    l'audit se tait — mieux vaut un contraste non vérifié qu'un contraste faux.
    """
    style = element.get('style') or ''
    correspondance = re.search(r'(?:^|;)\s*%s\s*:\s*([^;]+)'
                               % re.escape(propriete), style, re.IGNORECASE)
    if correspondance:
        return correspondance.group(1).strip()
    trouve = None
    for regle in regles:
        if regle.genre != 'regle' or regle.media:
            continue
        valeur = regle.valeur(propriete)
        if valeur is None:
            continue
        for selecteur in selecteurs_de(regle):
            verdict = correspond(element, selecteur)
            if verdict is None:
                return None
            if verdict:
                trouve = valeur
    return trouve


# =========================================================== 1. ACCESSIBILITÉ ==
def audit_accessibilite(ctx):
    audit = 'accessibilite'
    trouvés, ajouter = _rapporteur(audit, ctx)
    document = ctx.document

    # --- langue du document -------------------------------------------------
    html = document.premier('html')
    if html is None:
        ajouter('html-absent', 'avertissement',
                'Le document n’a pas d’élément <html> : la langue ne peut pas '
                'être déclarée, et les lecteurs d’écran prononceront le texte '
                'dans la mauvaise langue.')
    elif not (html.get('lang') or '').strip():
        ajouter('lang-manquante', 'erreur',
                '<html> n’a pas d’attribut lang : un lecteur d’écran ne sait '
                'pas dans quelle langue prononcer la page.',
                '<html lang="fr"> (ou la langue du contenu).', html)
    elif not re.fullmatch(r'[a-zA-Z]{2,3}(-[a-zA-Z0-9]{2,8})*',
                          (html.get('lang') or '').strip()):
        ajouter('lang-invalide', 'erreur',
                'lang="%s" n’est pas une étiquette de langue valide (BCP 47) : '
                'elle sera ignorée.' % html.get('lang'),
                'Exemples valides : fr, en, en-GB, pt-BR, zh-Hans.', html)

    # --- titres de section --------------------------------------------------
    titres = []
    for niveau in range(1, 7):
        for element in document.par_balise('h%d' % niveau):
            titres.append((niveau, element))
    titres.sort(key=lambda paire: paire[1].ordre)
    uns = [e for n, e in titres if n == 1]
    if not uns:
        ajouter('h1-absent', 'avertissement',
                'La page n’a aucun <h1> : c’est le titre que les lecteurs '
                'd’écran annoncent en premier et que les moteurs reprennent.',
                'Un seul <h1> par page, en début de contenu principal.')
    elif len(uns) > 1:
        for element in uns[1:]:
            ajouter('h1-multiple', 'info',
                    'Un second <h1> (« %s ») : ce n’est pas invalide, mais la '
                    'structure de la page devient ambiguë.'
                    % element.texte_complet()[:60],
                    'Gardez un seul <h1>, utilisez <h2> pour les sections.',
                    element)
    precedent = None
    for niveau, element in titres:
        if not element.texte_complet():
            ajouter('titre-vide', 'erreur',
                    'Un <h%d> est vide : il annonce une section qui n’existe '
                    'pas.' % niveau,
                    'Donnez-lui un texte, ou retirez-le.', element)
        if precedent is not None and niveau > precedent + 1:
            ajouter('saut-de-niveau', 'avertissement',
                    'Le titre passe de <h%d> à <h%d> : les niveaux sautés '
                    'cassent la navigation au clavier par titres.'
                    % (precedent, niveau),
                    'Descendez d’un seul niveau à la fois.', element)
        precedent = niveau

    # --- images -------------------------------------------------------------
    for element in document.par_balise('img'):
        if not element.a('alt'):
            if (element.get('role') or '') in ('presentation', 'none') \
                    or (element.get('aria-hidden') or '') == 'true':
                ajouter('alt-remplace', 'info',
                        'Une image décorative est marquée comme telle par %s : '
                        'c’est accepté, mais alt="" est la forme recommandée.'
                        % ('role="%s"' % element.get('role')
                           if element.a('role') else 'aria-hidden="true"'),
                        'alt="" reste plus fiable : aria-hidden n’est pas '
                        'interprété partout de la même façon.', element)
            else:
                ajouter('img-sans-alt', 'erreur',
                        'Une image n’a pas d’attribut alt : son contenu est '
                        'invisible aux lecteurs d’écran, qui annonceront le nom '
                        'du fichier.',
                        'alt="description courte" — ou alt="" si l’image est '
                        'purement décorative.', element)
        source = element.get('src') or ''
        if not source.strip():
            ajouter('img-sans-src', 'erreur',
                    'Un <img> sans src ne s’affiche pas et reste annoncé comme '
                    'une image vide.', 'Renseignez src, ou retirez l’élément.',
                    element)
        elif re.search(r'\.(png|jpe?g|gif|webp|svg)$/i', source.split('?')[0]) \
                and (element.get('alt') or '').strip().lower() in (
                    'image', 'logo', 'photo', 'image de', 'sans titre'):
            ajouter('alt-generique', 'avertissement',
                    'alt="%s" ne décrit rien : un lecteur d’écran annoncera ce '
                    'mot à la place de l’image.' % element.get('alt'),
                    'Décrivez ce que l’image apporte au contenu.', element)

    # --- svg ----------------------------------------------------------------
    for element in document.par_balise('svg'):
        if element.get('aria-hidden') == 'true' or element.get('focusable') == 'false':
            continue
        if not (element.get('aria-label') or element.get('role')
                or any(s.balise == 'title' for s in element.enfants)):
            ajouter('svg-sans-nom', 'info',
                    'Un <svg> n’a ni <title>, ni aria-label, ni role : son '
                    'contenu graphique n’est pas restitué.',
                    '<svg role="img" aria-label="…"> ou un <title> en premier '
                    'enfant.', element)

    # --- formulaires --------------------------------------------------------
    champs = []
    for balise in ('input', 'select', 'textarea'):
        champs.extend(document.par_balise(balise))
    champs.sort(key=lambda e: e.ordre)
    for element in champs:
        type_ = (element.get('type') or 'text').lower()
        if element.balise == 'input' and type_ in (
                'hidden', 'submit', 'button', 'reset', 'image'):
            if type_ == 'image' and not (element.get('alt') or '').strip():
                ajouter('image-sans-alt', 'erreur',
                        'Un <input type="image"> sans alt : le bouton n’a aucun '
                        'nom accessible.',
                        'alt="Rechercher" (le rôle du bouton).', element)
            continue
        etiquete, moyen = champ_etiquete(element, document)
        if not etiquete:
            if (element.get('placeholder') or '').strip():
                ajouter('placeholder-seul', 'avertissement',
                        'Un champ n’a pour étiquette que son placeholder : il '
                        'disparaît dès la première saisie, et son contraste est '
                        'trop faible pour servir de seul repère.',
                        'Un <label for="…"> en plus du placeholder.', element)
            else:
                ajouter('champ-sans-etiquette', 'erreur',
                        'Un champ de formulaire n’a aucune étiquette : il est '
                        'annoncé sans nom par les lecteurs d’écran.',
                        '<label for="id">Texte</label>, ou aria-label si '
                        'l’étiquette ne peut pas être affichée.', element)
        elif moyen == 'title':
            ajouter('etiquette-title', 'info',
                    'Un champ n’est étiqueté que par title : ce titre n’est ni '
                    'affiché de façon fiable, ni accessible au clavier.',
                    'Un vrai <label>.', element)
        if element.balise == 'input' and type_ in ('email', 'tel', 'url'):
            if not element.a('autocomplete'):
                ajouter('autocomplete-manquant', 'info',
                        'Un champ %s sans autocomplete : le navigateur et les '
                        'gestionnaires de mots de passe ne peuvent pas le '
                        'remplir.' % type_,
                        'autocomplete="email" / "tel" / "url".', element)
        if element.balise == 'input' and type_ == 'password' \
                and (element.get('autocomplete') or '').lower() == 'off':
            ajouter('password-autocomplete-off', 'avertissement',
                    'autocomplete="off" sur un mot de passe empêche le '
                    'gestionnaire de mots de passe, ce qui pousse aux mots de '
                    'passe faibles.',
                    'autocomplete="current-password" ou "new-password".', element)
        if not element.a('required') and not element.a('aria-required') \
                and '*' in (etiquette_de(element, document) or ''):
            ajouter('requis-non-declare', 'info',
                    'Une étoile dans l’étiquette annonce un champ obligatoire '
                    'qui n’est déclaré ni par required ni par aria-required.',
                    'Ajoutez required : l’astérisque seul n’est pas restitué.',
                    element)
    for element in document.par_balise('label'):
        cible = (element.get('for') or '').strip()
        if not cible and not any(e.balise in ('input', 'select', 'textarea')
                                 for e in element.iterer() if e is not element):
            ajouter('label-sans-cible', 'avertissement',
                    'Un <label> ne référence aucun champ (pas de for, aucun '
                    'champ imbriqué) : il n’est associé à rien.',
                    'for="identifiant-du-champ", ou englobez le champ.', element)
        elif cible and cible not in document.ids:
            ajouter('label-cible-introuvable', 'erreur',
                    'Un <label for="%s"> pointe vers un identifiant qui '
                    'n’existe pas dans la page.' % cible,
                    'Corrigez le for, ou donnez cet id au champ.', element)
    for element in document.par_balise('form'):
        if not any(e.balise in ('button', 'input') and
                   (e.get('type') or 'submit') == 'submit'
                   for e in element.iterer() if e is not element):
            ajouter('formulaire-sans-envoi', 'info',
                    'Un <form> n’a aucun bouton d’envoi : la touche Entrée ne '
                    'fera rien, et un utilisateur au clavier reste bloqué.',
                    '<button type="submit">.', element)

    # --- noms accessibles des actions ---------------------------------------
    for element in document.par_balise('button'):
        if not nom_accessible(element, document):
            ajouter('bouton-sans-nom', 'erreur',
                    'Un <button> n’a aucun nom accessible : il est annoncé '
                    '« bouton » sans dire ce qu’il fait.',
                    'Un texte, ou aria-label pour un bouton purement '
                    'iconographique.', element)
    for element in document.par_balise('a'):
        if not element.a('href'):
            ajouter('a-sans-href', 'info',
                    'Un <a> sans href n’est pas un lien : il n’est pas '
                    'atteignable au clavier et n’a pas de rôle.',
                    'Un href, ou un <button> si c’est une action.', element)
            continue
        nom = nom_accessible(element, document)
        if not nom:
            ajouter('lien-sans-nom', 'erreur',
                    'Un lien n’a aucun texte accessible : il est annoncé vide.',
                    'Un texte, ou aria-label pour une icône seule.', element)
        elif nom.strip().lower() in ('cliquez ici', 'ici', 'en savoir plus',
                                     'lire la suite', 'plus', 'link', 'here',
                                     'click here', 'more'):
            ajouter('lien-peu-explicite', 'avertissement',
                    'Le lien « %s » ne dit rien hors contexte : la navigation '
                    'de lien en lien devient incompréhensible.' % nom.strip(),
                    'Nommez la destination : « Tarifs 2026 ».', element)
        if (element.get('href') or '').strip() in ('', '#'):
            ajouter('lien-mort', 'avertissement',
                    'Un lien pointe vers « %s » : il ne mène nulle part mais '
                    'reste focusable.' % (element.get('href') or '(vide)'),
                    'Un href réel, ou un <button> pour une action en page.',
                    element)
        if element.get('tabindex') == '-1' and element.a('href'):
            ajouter('lien-retire-tabulation', 'info',
                    'tabindex="-1" retire ce lien de la navigation au clavier.',
                    'Ne retirez un lien de la tabulation que s’il est doublé.',
                    element)

    # --- identifiants -------------------------------------------------------
    for identifiant, elements in document.ids.items():
        if len(elements) > 1:
            for element in elements[1:]:
                ajouter('id-duplique', 'erreur',
                        'L’identifiant « %s » est utilisé %d fois : '
                        'document.getElementById, les ancres et les label for '
                        'ne viseront que le premier.'
                        % (identifiant, len(elements)),
                        'Un identifiant doit être unique dans la page.',
                        element)
        if re.match(r'^\d', identifiant):
            ajouter('id-commence-par-chiffre', 'info',
                    'L’identifiant « %s » commence par un chiffre : il est '
                    'invalide en sélecteur CSS sans échappement.' % identifiant,
                    'Préfixez-le d’une lettre.', elements[0])

    # --- iframes, tableaux, widgets -----------------------------------------
    for element in document.par_balise('iframe'):
        if not ((element.get('title') or '').strip()
                or (element.get('aria-label') or '').strip()):
            ajouter('iframe-sans-titre', 'avertissement',
                    'Une <iframe> n’a pas de title : elle est annoncée « cadre '
                    '» sans dire ce qu’elle contient.',
                    'title="Description du contenu intégré".', element)
    for element in document.par_balise('table'):
        if element.get('role') == 'presentation':
            continue
        lignes = [e for e in element.iterer() if e.balise == 'tr']
        entetes = [e for e in element.iterer() if e.balise == 'th']
        if lignes and not entetes:
            ajouter('tableau-sans-entete', 'avertissement',
                    'Un tableau de données n’a aucune cellule d’en-tête <th> : '
                    'les cellules sont annoncées sans leur colonne.',
                    '<th scope="col"> dans la première ligne.', element)
        elif entetes and not any(e.a('scope') or e.a('id') for e in entetes):
            ajouter('th-sans-scope', 'info',
                    'Des <th> sans scope : la portée (ligne ou colonne) est '
                    'devinée par le lecteur d’écran.',
                    'scope="col" ou scope="row".', entetes[0])
        if not [e for e in element.iterer() if e.balise == 'caption'] \
                and not (element.get('aria-label') or element.get('aria-labelledby')):
            ajouter('tableau-sans-legende', 'info',
                    'Un tableau n’a ni <caption> ni aria-label : son sujet '
                    'n’est pas annoncé.',
                    '<caption> en premier enfant du <table>.', element)
    for element in document.par_balise('video', 'audio'):
        if element.balise == 'video' and not any(
                e.balise == 'track' and (e.get('kind') or '') == 'captions'
                for e in element.iterer() if e is not element):
            ajouter('video-sans-sous-titres', 'avertissement',
                    'Une <video> n’a pas de piste de sous-titres : son contenu '
                    'est inaccessible aux personnes sourdes ou malentendantes.',
                    '<track kind="captions" src="…" srclang="fr" label="Français">.',
                    element)
    for element in document.par_balise('marquee', 'blink'):
        ajouter('animation-non-controlable', 'erreur',
                '<%s> produit un mouvement que l’utilisateur ne peut pas '
                'arrêter : c’est un critère d’accessibilité (2.2.2).'
                % element.balise,
                'Une animation CSS avec prefers-reduced-motion.', element)

    # --- navigation au clavier ----------------------------------------------
    for element in document.elements:
        tabindex = element.get('tabindex')
        if tabindex is None:
            continue
        try:
            valeur = int(tabindex)
        except ValueError:
            ajouter('tabindex-invalide', 'erreur',
                    'tabindex="%s" n’est pas un entier : il est ignoré.'
                    % tabindex, 'tabindex="0" ou "-1".', element)
            continue
        if valeur > 0:
            ajouter('tabindex-positif', 'avertissement',
                    'tabindex="%d" impose un ordre de tabulation artificiel, '
                    'différent de l’ordre de lecture.' % valeur,
                    'tabindex="0" pour rendre focusable, et un ordre de '
                    'document logique.', element)
    for element in document.elements:
        if element.get('aria-hidden') != 'true':
            continue
        interactif = element.balise in ('button', 'input', 'select', 'textarea') \
            or (element.balise == 'a' and element.a('href'))
        if interactif and element.get('tabindex') != '-1':
            ajouter('aria-hidden-focusable', 'erreur',
                    'Un élément masqué aux lecteurs d’écran (aria-hidden='
                    '"true") reste focusable au clavier : ce qui est lu ne '
                    'correspond plus à ce qui est atteint.',
                    'tabindex="-1" et pointer-events:none, ou retirez '
                    'l’élément.', element)
    for element in document.elements:
        if element.a('onclick') and element.balise not in ref.INTERACTIFS \
                and not element.a('role') and not element.a('tabindex'):
            ajouter('clic-sans-clavier', 'avertissement',
                    'Un onclick sur un <%s> : l’action est inaccessible au '
                    'clavier, qui n’émet pas de clic sur cet élément.'
                    % element.balise,
                    'Un <button>, ou tabindex="0" avec un gestionnaire keydown.',
                    element)

    # --- zoom et viewport ---------------------------------------------------
    viewport = document.meta('viewport')
    if viewport:
        normalise = viewport.replace(' ', '').lower()
        if 'user-scalable=no' in normalise:
            ajouter('zoom-interdit', 'erreur',
                    'meta viewport interdit le zoom (user-scalable=no) : un '
                    'utilisateur malvoyant ne peut pas agrandir la page.',
                    'Retirez user-scalable=no.', document.meta_element('viewport'))
        correspondance = re.search(r'maximum-scale=([0-9.]+)', normalise)
        if correspondance and float(correspondance.group(1)) < 2:
            ajouter('zoom-limite', 'avertissement',
                    'meta viewport limite le zoom à %s : en dessous de 2, '
                    'l’agrandissement reste insuffisant.'
                    % correspondance.group(1),
                    'maximum-scale=5 ou pas de maximum-scale du tout.',
                    document.meta_element('viewport'))
    # --- région principale et évitement --------------------------------------
    if not document.par_balise('main'):
        ajouter('main-absent', 'info',
                'La page n’a pas d’élément <main> : le raccourci « aller au '
                'contenu principal » des lecteurs d’écran ne trouve rien.',
                '<main> autour du contenu principal.', None,
                ligne=document.doctype_ligne)
    # Un lien d'évitement se reconnaît à son NOM, pas à sa position : traiter
    # n'importe quelle ancre de début de page comme un lien d'évitement faisait
    # dire « lien d'évitement sans cible » d'un simple lien cassé, déjà signalé
    # ailleurs sous son vrai nom.
    for element in document.elements[:40]:
        if element.balise != 'a' or not (element.get('href') or '').startswith('#'):
            continue
        nom = nom_accessible(element, document).lower()
        if not re.search(r'(aller|passer|sauter|évit|contenu principal|'
                         r'skip|main content)', nom):
            continue
        if (element.get('href') or '#')[1:] not in document.ids:
            ajouter('evitement-sans-cible', 'avertissement',
                    'Le lien d’évitement « %s » pointe vers %s, une ancre qui '
                    'n’existe pas : le raccourci ne mène nulle part.'
                    % (nom.strip(), element.get('href')),
                    'Donnez cet id au conteneur du contenu principal.', element)

    # --- contraste vérifiable ------------------------------------------------
    corps = document.premier('body') or html
    if corps is not None:
        avant = couleur_pour(corps, 'color', ctx.regles_css)
        fond = couleur_pour(corps, 'background-color', ctx.regles_css)
        if fond is None:
            fond = couleur_pour(corps, 'background', ctx.regles_css)
        if avant and fond:
            rapport = contraste(avant, fond)
            if rapport is None:
                trouvés.append(faire_constat(
                    audit, 'contrast-non-calculable', 'info',
                    'Les couleurs du texte (%s) et du fond (%s) ne sont pas '
                    'dans un format calculable : le contraste n’est pas vérifié.'
                    % (avant, fond),
                    'Une couleur en hexadécimal ou rgb() peut être vérifiée.'))
            elif rapport < 4.5:
                trouvés.append(faire_constat(
                    audit, 'contrast-insuffisant', 'erreur',
                    'Le contraste du texte courant est de %s:1 (%s sur %s) : '
                    'en dessous de 4,5:1, le texte n’est pas lisible pour une '
                    'personne malvoyante.' % (rapport, avant, fond),
                    'Assombrissez le texte ou éclaircissez le fond jusqu’à '
                    '4,5:1 (3:1 pour du texte de 24 px et plus).'))
            else:
                trouvés.append(faire_constat(
                    audit, 'contrast-ok', 'ok',
                    'Contraste du texte courant : %s:1 (%s sur %s), conforme au '
                    'niveau AA.' % (rapport, avant, fond)))
        else:
            trouvés.append(faire_constat(
                audit, 'contrast-non-verifie', 'info',
                'Le contraste n’a pas pu être vérifié : il faut pour cela que '
                'la couleur du texte et celle du fond soient déclarées '
                'explicitement pour <body> dans une règle simple.',
                'Déclarez color et background-color sur body, ou vérifiez le '
                'contraste dans l’aperçu.'))

    # --- ARIA ----------------------------------------------------------------
    for element in document.elements:
        role = element.get('role')
        if role is not None and role.strip() and role.strip().lower() not in ref.ROLES_ARIA:
            ajouter('role-inconnu', 'info',
                    'role="%s" n’est pas dans la liste de référence des rôles '
                    'ARIA de Pascal Studio : il est peut-être récent, ou '
                    'mal orthographié. Un rôle invalide est ignoré sans danger.'
                    % role.strip(),
                    'Vérifiez l’orthographe dans la spécification WAI-ARIA.',
                    element)
        for nom, _valeur in element.attributs:
            if nom.startswith('aria-') and nom not in ref.ATTRIBUTS_ARIA:
                ajouter('attribut-aria-inconnu', 'info',
                        '%s n’est pas un attribut ARIA reconnu par la liste de '
                        'référence : il sera ignoré.' % nom,
                        'Consultez la liste des états et propriétés ARIA.',
                        element)
        if element.a('aria-describedby'):
            for identifiant in (element.get('aria-describedby') or '').split():
                if identifiant not in document.ids:
                    ajouter('aria-cible-introuvable', 'erreur',
                            'aria-describedby="%s" vise un identifiant absent : '
                            'la description ne sera jamais lue.' % identifiant,
                            'Donnez cet id à l’élément de description.', element)
        if element.a('aria-controls'):
            for identifiant in (element.get('aria-controls') or '').split():
                if identifiant not in document.ids:
                    ajouter('aria-controls-introuvable', 'avertissement',
                            'aria-controls="%s" vise un identifiant absent.'
                            % identifiant,
                            'Corrigez l’id, ou retirez aria-controls.', element)
    if not trouvés:
        trouvés.append(faire_constat(audit, 'rien', 'ok',
                               'Aucun problème d’accessibilité détecté par cet '
                               'audit automatique. Un audit automatique ne '
                               'remplace pas un test au lecteur d’écran ni une '
                               'navigation au clavier.'))
    return trouvés


# ================================================================= 2. SÉCURITÉ ==
def audit_securite(ctx):
    audit = 'securite'
    trouvés, ajouter = _rapporteur(audit, ctx)
    document = ctx.document
    https = bool(ctx.url and ctx.url.lower().startswith('https://'))

    # --- en-têtes de la réponse ---------------------------------------------
    if ctx.entetes:
        for regle in ref.EN_TETES_SECURITE:
            valeur = ctx.entetes.get(regle['nom'])
            if valeur:
                if regle['nom'] == 'content-security-policy':
                    directives = [d.strip().lower()
                                  for d in re.split(r';', valeur)]
                    if 'default-src' not in directives \
                            and 'script-src' not in directives:
                        ajouter('csp-sans-default-src', 'avertissement',
                                'La Content-Security-Policy ne pose ni '
                                'default-src ni script-src : elle ne restreint '
                                'pas l’origine des scripts, ce qui est son '
                                'principal apport.',
                                "default-src 'self' au minimum.")
                    if "'unsafe-inline'" in valeur or "'unsafe-eval'" in valeur:
                        ajouter('csp-unsafe', 'avertissement',
                                'La CSP autorise %s : une injection de script '
                                'redevient possible même avec l’en-tête en '
                                'place.'
                                % (' et '.join(x for x in ("'unsafe-inline'",
                                                           "'unsafe-eval'")
                                               if x in valeur)),
                                'Retirez unsafe-inline en sortant le JavaScript '
                                'inline dans des fichiers, ou utilisez des '
                                'nonces.', ligne=1)
                    else:
                        ajouter('csp-presente', 'ok',
                                'Content-Security-Policy présente et sans '
                                'unsafe-inline/unsafe-eval.')
                elif regle.get('valeur_attendue') \
                        and valeur.strip().lower() != regle['valeur_attendue']:
                    ajouter('en-tete-valeur', 'avertissement',
                            '%s vaut « %s » au lieu de « %s » : il n’a pas '
                            'l’effet attendu.'
                            % (regle['nom'], valeur, regle['valeur_attendue']),
                            regle['conseil'], ligne=1)
                else:
                    ajouter('en-tete-present', 'ok',
                            '%s : %s' % (regle['nom'], valeur[:80]))
                continue
            if regle['https_uniquement'] and not https:
                ajouter('en-tete-manquant-https', 'info',
                        '%s est absent, mais la réponse est servie en HTTP : '
                        'cet en-tête ne s’applique qu’en HTTPS. Il deviendra '
                        'une erreur dès que la page sera servie en HTTPS.'
                        % regle['nom'], regle['conseil'], ligne=1)
            else:
                ajouter('en-tete-manquant', regle['gravite'],
                        'L’en-tête %s est absent. %s' % (regle['nom'].upper(),
                                                         regle['role']),
                        regle['conseil'], ligne=1)
        for bavard in ref.EN_TETES_BAVARDS:
            if bavard in ctx.entetes:
                ajouter('en-tete-bavard', 'info',
                        'L’en-tête %s révèle le logiciel serveur (%s) : il '
                        'facilite le ciblage d’une version vulnérable.'
                        % (bavard, str(ctx.entetes[bavard])[:60]),
                        'Désactivez la bannière du serveur.', ligne=1)
        for cle, valeur in ctx.entetes.items():
            if cle != 'set-cookie':
                continue
            for cookie in re.findall(r'[^,]+', valeur):
                manque = [drapeau for drapeau in ('HttpOnly', 'Secure', 'SameSite')
                          if drapeau.lower() not in cookie.lower()]
                if manque:
                    ajouter('cookie-sans-drapeau', 'erreur' if 'Secure' in manque
                            or 'HttpOnly' in manque else 'avertissement',
                            'Un cookie est posé sans %s.'
                            % ', '.join(manque),
                            'Set-Cookie: nom=valeur; HttpOnly; Secure; '
                            'SameSite=Strict', ligne=1)
            if 'samesite=none' in valeur.lower() and 'secure' not in valeur.lower():
                ajouter('samesite-none-sans-secure', 'erreur',
                        'SameSite=None exige Secure : sans lui le cookie est '
                        'refusé par les navigateurs récents.',
                        'Ajoutez Secure.', ligne=1)
        if ctx.statut and 300 <= int(ctx.statut) < 400:
            emplacement = ctx.entetes.get('location', '')
            if ctx.url and ctx.url.startswith('http://') \
                    and emplacement.startswith('https://'):
                ajouter('redirection-https', 'info',
                        'La requête HTTP est redirigée vers HTTPS : c’est bien, '
                        'mais chaque visite paie un aller-retour de plus.',
                        'HSTS permet au navigateur d’aller directement en HTTPS.',
                        ligne=1)
    elif ctx.url:
        ajouter('en-tetes-indisponibles', 'avertissement',
                'Aucun en-tête de réponse n’a pu être lu pour cette URL : '
                'l’audit des en-têtes de sécurité est incomplet.',
                'Relancez l’audit sur l’URL, pas sur le fichier.', ligne=1)
    else:
        ajouter('audit-fichier', 'info',
                'L’audit porte sur un fichier local : les en-têtes de sécurité '
                'ne sont pas ceux d’un fichier mais d’une réponse HTTP. Ils '
                'sont cherchés dans la configuration du projet, et le code de '
                'la page est analysé.',
                'Pour auditer les en-têtes réels, lancez l’aperçu puis auditez '
                'l’URL servie.', ligne=1)
        declares = ctx.declares
        if declares:
            for regle in ref.EN_TETES_SECURITE:
                if regle['nom'] in declares:
                    ajouter('en-tete-declare', 'ok',
                            '%s est déclaré dans %s.'
                            % (regle['nom'], declares[regle['nom']]), ligne=1)
                elif not regle['https_uniquement']:
                    ajouter('en-tete-non-declare', regle['gravite'],
                            '%s n’est déclaré dans aucune configuration du '
                            'projet (%s).'
                            % (regle['nom'].upper(),
                               ', '.join(c['fichier'] for c in
                                         ref.CONFIGURATIONS_EN_TETES)),
                            regle['conseil'], ligne=1)
        else:
            ajouter('aucune-config-en-tetes', 'info',
                    'Le projet ne contient aucune configuration d’en-têtes '
                    'reconnue (%s).'
                    % ', '.join(c['fichier'] for c in ref.CONFIGURATIONS_EN_TETES),
                    'Le générateur « En-têtes de sécurité » du panneau produit '
                    'ces fichiers.', ligne=1)

    # --- motifs dangereux dans le code --------------------------------------
    # Une seule liste, UNE SEULE FORME d'entrée (langage, texte, origine) : la
    # branche « style en ligne » ajoutait un couple à deux éléments, et le
    # dépaquetage en trois de la boucle levait un ValueError dès qu'une page
    # contenait un <style>. Les pages de contrôle précédentes n'en avaient pas —
    # leur CSS était dans une feuille liée — donc l'audit de sécurité entier
    # était perdu sans qu'aucun banc ne le voie.
    cibles = [('html', ctx.contenu, 'le document')]
    for origine, texte, _element in ctx.scripts():
        cibles.append(('javascript', texte, origine))
    javascript = ctx.texte_script()
    for element in document.par_balise('style'):
        if element.brut_interne:
            cibles.append(('css', element.brut_interne,
                           'le style en ligne de la ligne %s' % element.ligne))
    for regle in ref.MOTIFS_DANGEREUX:
        try:
            expression = re.compile(regle['motif'], re.IGNORECASE)
        except re.error:
            continue
        for langage, texte, origine in cibles:
            if regle['langage'] != langage:
                continue
            fragments_vus = set()
            for correspondance in expression.finditer(texte):
                debut = correspondance.start()
                ligne = texte.count('\n', 0, debut) + 1
                fragment = texte[max(0, debut - 30):debut + 60].replace('\n', ' ')
                if fragment in fragments_vus:
                    continue
                fragments_vus.add(fragment)
                if len(fragments_vus) > 12:
                    ajouter(regle['code'], 'info',
                            'Plus de 12 occurrences de « %s » dans %s : les '
                            'suivantes ne sont pas listées.'
                            % (regle['code'], origine))
                    break
                if langage == 'javascript':
                    # La ligne est celle du SCRIPT, pas celle du document : le
                    # dire évite d'envoyer l'utilisateur à une ligne du HTML qui
                    # ne contient rien.
                    ajouter(regle['code'], regle['gravite'],
                            '%s Trouvé dans %s, à la ligne %d de ce script.'
                            % (regle['raison'], origine, ligne), regle['conseil'])
                else:
                    ajouter(regle['code'], regle['gravite'], regle['raison'],
                            regle['conseil'], ligne=ligne)
                trouvés[-1]['extrait'] = fragment[:MAX_EXTRAIT]

    # --- intégrité des ressources distantes ---------------------------------
    for element in document.par_balise('script', 'link'):
        source = element.get('src') or element.get('href') or ''
        if not re.match(r'^(https?:)?//', source):
            continue
        if not element.a('integrity'):
            ajouter('sri-manquant', 'avertissement',
                    'Une ressource distante est chargée sans integrity (SRI) : '
                    'si le serveur tiers est compromis, le code servi change '
                    'sans que la page le remarque. %s' % source[:80],
                    'integrity="sha384-…" crossorigin="anonymous" — le générateur '
                    '« SRI » du panneau calcule l’empreinte.', element)
        elif not re.match(r'^sha(256|384|512)-', element.get('integrity') or ''):
            ajouter('sri-invalide', 'erreur',
                    'integrity="%s" n’est pas une empreinte sha256/384/512 : '
                    'la ressource sera BLOQUÉE par le navigateur.'
                    % element.get('integrity'),
                    'Recalculez l’empreinte.', element)

    # --- contenu mixte ------------------------------------------------------
    if https:
        for element in document.elements:
            for attribut in ('src', 'href', 'action', 'data', 'poster'):
                valeur = element.get(attribut)
                if isinstance(valeur, str) and valeur.startswith('http://'):
                    ajouter('contenu-mixte', 'erreur',
                            'Une page servie en HTTPS charge %s en HTTP clair : '
                            'le navigateur bloquera ou dégradera ce contenu, et '
                            'il est interceptable.' % valeur[:80],
                            'Passez cette ressource en https://.', element)

    # --- stockage et données sensibles --------------------------------------
    for element in document.par_balise('input'):
        if (element.get('type') or '').lower() == 'password' and not https \
                and ctx.url:
            ajouter('mot-de-passe-en-http', 'erreur',
                    'Un champ mot de passe est servi en HTTP clair : la saisie '
                    'part sans chiffrement.',
                    'Servez le formulaire en HTTPS.', element)
    if re.search(r'(api[_-]?key|secret|token|mot[_-]?de[_-]?passe|password)'
                 r'\s*[:=]\s*["\'][^"\']{8,}', ctx.contenu, re.IGNORECASE):
        ajouter('secret-en-clair', 'erreur',
                'Le document contient ce qui ressemble à un secret en clair '
                '(clef d’API, jeton ou mot de passe). Toute personne qui charge '
                'la page le lit.',
                'Retirez-le du code côté client : il doit rester côté serveur.',
                ligne=_ligne_du_motif(ctx.contenu,
                                     r'(api[_-]?key|secret|token|password)'))
    if 'localStorage' in javascript or 'sessionStorage' in javascript:
        if re.search(r'localStorage\.setItem\([^)]*(token|jwt|session|password)',
                     javascript, re.IGNORECASE):
            ajouter('token-dans-storage', 'erreur',
                    'Un jeton d’authentification est écrit dans le stockage '
                    'local : il est lisible par n’importe quel script de la '
                    'page, donc par toute injection.',
                    'Un cookie HttpOnly posé par le serveur, ou le stockage en '
                    'mémoire.', ligne=None)
    # Cette règle doit consulter les MÊMES sources que l'audit des en-têtes :
    # annoncée ici alors que le .htaccess du projet déclare Referrer-Policy,
    # elle contredisait le constat « referrer-policy est déclaré » rendu plus
    # haut dans le même audit.
    if (not document.meta('referrer')
            and 'referrer-policy' not in ctx.entetes
            and 'referrer-policy' not in ctx.declares):
        ajouter('referrer-non-defini', 'info',
                'Ni meta referrer ni en-tête Referrer-Policy : l’URL complète, '
                'paramètres compris, peut partir vers les sites liés.',
                '<meta name="referrer" content="strict-origin-when-cross-origin">.')

    # --- cadre et fenêtres ---------------------------------------------------
    for element in document.par_balise('a'):
        if (element.get('target') or '') == '_blank' \
                and 'noopener' not in (element.get('rel') or ''):
            ajouter('noopener-manquant', 'avertissement',
                    'target="_blank" sans rel="noopener" : la page ouverte '
                    'obtient window.opener et peut rediriger votre onglet.',
                    'rel="noopener noreferrer".', element)
    for element in document.par_balise('iframe'):
        if not element.a('sandbox'):
            ajouter('iframe-sans-sandbox', 'info',
                    'Une <iframe> sans sandbox exécute son contenu avec tous '
                    'ses droits. Pour du contenu tiers, c’est une surface '
                    'd’attaque.',
                    'sandbox="allow-scripts allow-same-origin" adapté au cas, '
                    'ou allow-* au strict nécessaire.', element)
        if element.get('src') and element.get('src').startswith('http') \
                and not element.a('referrerpolicy'):
            ajouter('iframe-sans-referrer', 'info',
                    'Une <iframe> distante sans referrerpolicy transmet '
                    'l’adresse de votre page au site intégré.',
                    'referrerpolicy="no-referrer" ou strict-origin.', element)
    if not trouvés:
        trouvés.append(faire_constat(audit, 'rien', 'ok',
                               'Aucun problème de sécurité détecté sur ce qui '
                               'est vérifiable ici.'))
    return trouvés


def _ligne_du_motif(texte, motif):
    try:
        correspondance = re.search(motif, texte, re.IGNORECASE)
    except re.error:
        return None
    if not correspondance:
        return None
    return texte.count('\n', 0, correspondance.start()) + 1


MAX_DOSSIERS_CONFIG = 12


def _dossiers_de_configuration(ctx):
    """Du dossier du document jusqu'à la racine du projet, du plus proche au
    plus éloigné.

    Apache applique un .htaccess à son dossier ET à ses sous-dossiers : une page
    dans site/ est régie par site/.htaccess. Ne regarder que la racine du projet
    faisait dire « aucun en-tête déclaré » pour un projet organisé en
    sous-dossier (public/, dist/, site/, www/) — c'est-à-dire la majorité des
    projets réels, et justement ceux où la configuration est soignée.
    """
    if ctx.racine is None:
        return []
    if ctx.chemin is not None:
        depart = Path(ctx.chemin).parent
    elif isinstance(ctx.base, Path):
        depart = ctx.base
    else:
        depart = Path(ctx.racine)
    try:
        racine = Path(ctx.racine).resolve()
    except OSError:
        racine = Path(ctx.racine)
    sortie = []
    courant = depart
    for _ in range(MAX_DOSSIERS_CONFIG):
        sortie.append(courant)
        try:
            resolu = courant.resolve()
        except OSError:
            break
        if resolu == racine:
            break
        try:
            if not resolu.is_relative_to(racine):
                break
        except (OSError, AttributeError):
            break
        parent = courant.parent
        if parent == courant:
            break
        courant = parent
    return sortie


def _en_tetes_declares(ctx):
    """Les en-têtes de sécurité déclarés dans la configuration du projet.

    Un audit qui ne regarde que la réponse HTTP rate le cas le plus courant en
    développement local : les en-têtes sont écrits dans .htaccess ou nginx.conf
    et le serveur n'est pas encore lancé.

    La valeur rendue est le chemin RELATIF du fichier qui déclare l'en-tête :
    dire « .htaccess » quand il y en a trois dans le projet ne permet pas de
    savoir lequel corriger.
    """
    declares = {}
    if ctx.racine is None:
        return declares
    try:
        racine = Path(ctx.racine)
    except (TypeError, ValueError):
        return declares
    for dossier in _dossiers_de_configuration(ctx):
        for configuration in ref.CONFIGURATIONS_EN_TETES:
            chemin = Path(dossier) / configuration['fichier']
            try:
                if not chemin.is_file():
                    continue
                texte = chemin.read_text('utf8', 'replace')
            except OSError:
                continue
            try:
                etiquette = str(chemin.relative_to(racine))
            except ValueError:
                etiquette = configuration['fichier']
            for regle in ref.EN_TETES_SECURITE:
                if regle['nom'] in declares:
                    continue        # le fichier le plus proche l'emporte
                try:
                    motif = configuration['motif'] % re.escape(regle['nom'])
                except TypeError:
                    continue
                if re.search(motif, texte, re.IGNORECASE | re.MULTILINE):
                    declares[regle['nom']] = etiquette
    return declares


# =================================================================== 3. LIENS ==
def _collecter_references(ctx):
    """Toutes les références d'un document, avec leur nature et leur position."""
    document = ctx.document
    references = []

    def ajouter(element, attribut, valeur, nature):
        if valeur is None:
            return
        valeur = valeur.strip()
        references.append({'element': element, 'attribut': attribut,
                           'valeur': valeur, 'nature': nature,
                           'ligne': element.ligne})

    for element in document.elements:
        if element.balise == 'a':
            ajouter(element, 'href', element.get('href'), 'lien')
        elif element.balise == 'area':
            ajouter(element, 'href', element.get('href'), 'lien')
        elif element.balise == 'link':
            ajouter(element, 'href', element.get('href'), 'ressource')
        elif element.balise == 'script':
            ajouter(element, 'src', element.get('src'), 'script')
        elif element.balise == 'img':
            ajouter(element, 'src', element.get('src'), 'image')
            ajouter(element, 'longdesc', element.get('longdesc'), 'ressource')
        elif element.balise == 'input' \
                and (element.get('type') or '').lower() == 'image':
            ajouter(element, 'src', element.get('src'), 'image')
        elif element.balise in ('video', 'audio', 'iframe', 'embed', 'track',
                                'source'):
            ajouter(element, 'src', element.get('src'), 'ressource')
            ajouter(element, 'poster', element.get('poster'), 'image')
        elif element.balise == 'object':
            ajouter(element, 'data', element.get('data'), 'ressource')
        elif element.balise == 'form':
            ajouter(element, 'action', element.get('action'), 'action')
        elif element.balise == 'use':
            ajouter(element, 'href', element.get('href') or element.get('xlink:href'),
                    'ressource')
        if element.balise in ('img', 'source'):
            srcset = element.get('srcset')
            if srcset:
                for candidat in srcset.split(','):
                    adresse = candidat.strip().split(' ')[0]
                    if adresse:
                        ajouter(element, 'srcset', adresse, 'image')
    # url() dans les styles en ligne et les blocs <style>
    for regle in ctx.regles_css:
        for _nom, valeur, _importante, ligne in regle.declarations:
            for adresse in re.findall(r'url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)',
                                      valeur):
                references.append({'element': None, 'attribut': 'url()',
                                   'valeur': adresse.strip(),
                                   'nature': 'css', 'ligne': ligne})
    for element in document.elements:
        style = element.get('style')
        if not style:
            continue
        for adresse in re.findall(r'url\(\s*[\'"]?([^\'")]+)[\'"]?\s*\)', style):
            references.append({'element': element, 'attribut': 'style',
                               'valeur': adresse.strip(), 'nature': 'css',
                               'ligne': element.ligne})
    return references


def audit_liens(ctx):
    audit = 'liens'
    trouvés = []
    references = _collecter_references(ctx)
    compte = {'fragments': 0, 'internes': 0, 'externes': 0, 'speciaux': 0,
              'verifies': 0, 'casses': 0}
    distants_a_verifier = []

    for reference in references:
        valeur = reference['valeur']
        element = reference['element']
        signature = element.signature() if element is not None else 'CSS'
        if not valeur:
            trouvés.append(faire_constat(audit, 'reference-vide', 'avertissement',
                                   'Un attribut %s est présent mais vide.'
                                   % reference['attribut'],
                                   'Renseignez-le ou retirez l’attribut.',
                                   ligne=reference['ligne'], element=signature,
                                   extrait=ctx.ligne(reference['ligne'])))
            continue
        if valeur.startswith('#'):
            compte['fragments'] += 1
            cible = valeur[1:]
            if not cible:
                continue
            if cible not in ctx.document.ids:
                trouvés.append(faire_constat(
                    audit, 'fragment-casse', 'erreur',
                    'L’ancre %s vise l’identifiant « %s », qui n’existe pas '
                    'dans la page.' % (valeur, cible),
                    'Donnez id="%s" à l’élément visé.' % cible,
                    ligne=reference['ligne'], element=signature,
                    extrait=ctx.ligne(reference['ligne'])))
                compte['casses'] += 1
            continue
        if valeur.lower().startswith(('mailto:', 'tel:', 'sms:', 'callto:')):
            compte['speciaux'] += 1
            if valeur.lower().startswith('mailto:'):
                adresse = valeur[7:].split('?')[0]
                if adresse and '@' not in adresse:
                    trouvés.append(faire_constat(
                        audit, 'mailto-invalide', 'avertissement',
                        'mailto:%s ne contient pas d’adresse valide.' % adresse,
                        'mailto:nom@exemple.fr', ligne=reference['ligne'],
                        element=signature))
            continue
        if valeur.lower().startswith(('data:', 'blob:', 'about:', 'javascript:')):
            compte['speciaux'] += 1
            continue
        if re.match(r'^[a-z][a-z0-9+.-]*:', valeur, re.IGNORECASE) \
                and not valeur.startswith('//'):
            compte['externes'] += 1
            if valeur.lower().startswith(('http://', 'https://')):
                distants_a_verifier.append(reference)
            else:
                trouvés.append(faire_constat(
                    audit, 'schema-inattendu', 'info',
                    'La référence « %s » emploie un schéma que l’audit ne sait '
                    'pas vérifier (%s).' % (valeur[:80], valeur.split(':')[0]),
                    'Vérifiez cette adresse à la main.',
                    ligne=reference['ligne'], element=signature))
            continue
        # Référence locale (relative, absolue ou //hôte)
        if valeur.startswith('//'):
            compte['externes'] += 1
            distants_a_verifier.append(reference)
            continue
        compte['internes'] += 1
        chemin, relatif = ctx.resoudre_local(valeur)
        if chemin is None:
            if ctx.chemin is None:
                raison = ('l’audit porte sur une URL distante, pas sur un '
                          'fichier du projet' if ctx.url else
                          'le document est audité sans chemin ni URL, donc sans '
                          'dossier de référence')
                trouvés.append(faire_constat(
                    audit, 'local-non-verifiable', 'info',
                    'La référence locale « %s » ne peut pas être vérifiée sur '
                    'le disque : %s.' % (valeur[:80], raison),
                    'Auditez le fichier du projet pour vérifier les chemins '
                    'locaux.', ligne=reference['ligne'], element=signature))
            else:
                trouvés.append(faire_constat(
                    audit, 'hors-projet', 'avertissement',
                    'La référence « %s » sort du projet : elle ne sera pas '
                    'publiée avec lui.' % valeur[:80],
                    'Placez la ressource dans le projet, ou utilisez une URL '
                    'complète.', ligne=reference['ligne'], element=signature))
            continue
        if chemin.is_file():
            continue
        if chemin.is_dir():
            index = chemin / 'index.html'
            if index.is_file():
                continue
            trouvés.append(faire_constat(
                audit, 'dossier-sans-index', 'erreur',
                'La référence « %s » désigne le dossier %s, qui ne contient '
                'pas d’index.html : le serveur répondra 403 ou 404.'
                % (valeur, relatif),
                'Ajoutez un index.html, ou référencez le fichier voulu.',
                ligne=reference['ligne'], element=signature,
                extrait=ctx.ligne(reference['ligne'])))
            compte['casses'] += 1
            continue
        # Absent : chercher un homonyme dont la casse diffère, faute classique
        # sous Linux où le système de fichiers distingue les casse.
        homonyme = _homonyme(chemin)
        if homonyme:
            trouvés.append(faire_constat(
                audit, 'casse-differente', 'erreur',
                '« %s » est introuvable, mais %s existe : la casse diffère. '
                'Cela fonctionne sous Windows et macOS, pas sous Linux ni sur '
                'la plupart des hébergements.' % (valeur, homonyme),
                'Écrivez exactement « %s ».' % homonyme,
                ligne=reference['ligne'], element=signature,
                extrait=ctx.ligne(reference['ligne'])))
        else:
            trouvés.append(faire_constat(
                audit, 'fichier-introuvable', 'erreur',
                'La référence « %s » ne correspond à aucun fichier du projet.'
                % valeur,
                'Vérifiez le chemin (il est résolu depuis %s).'
                % (ctx.chemin.parent.name + '/' if ctx.chemin else 'la racine'),
                ligne=reference['ligne'], element=signature,
                extrait=ctx.ligne(reference['ligne'])))
        compte['casses'] += 1

    if distants_a_verifier and ctx.options.get('verifier_distant'):
        import devweb_client
        for reference in distants_a_verifier[:MAX_LIENS_DISTANTS]:
            adresse = reference['valeur']
            if adresse.startswith('//'):
                adresse = 'https:' + adresse
            resultat = devweb_client.requeter(
                adresse, methode='HEAD', delai=ctx.options.get('delai_distant', 8),
                suivre=False, octets_max=0)
            compte['verifies'] += 1
            if resultat.get('erreur') and resultat.get('methode_refusee'):
                resultat = devweb_client.requeter(
                    adresse, methode='GET',
                    delai=ctx.options.get('delai_distant', 8), suivre=False,
                    octets_max=1024)
                compte['verifies'] += 1
            if resultat.get('erreur'):
                trouvés.append(faire_constat(
                    audit, 'distant-injoignable', 'erreur',
                    'L’adresse %s est injoignable : %s'
                    % (adresse[:80], resultat['erreur']),
                    'Retirez la référence ou corrigez l’adresse.',
                    ligne=reference['ligne'],
                    element=reference['element'].signature()
                    if reference['element'] is not None else ''))
                compte['casses'] += 1
            elif resultat.get('statut', 0) >= 400:
                trouvés.append(faire_constat(
                    audit, 'distant-erreur', 'erreur',
                    'L’adresse %s répond %s.' % (adresse[:80],
                                                 resultat.get('statut')),
                    'Vérifiez l’adresse, ou le droit d’accès.',
                    ligne=reference['ligne'],
                    element=reference['element'].signature()
                    if reference['element'] is not None else ''))
                compte['casses'] += 1
            else:
                trouvés.append(faire_constat(
                    audit, 'distant-ok', 'ok',
                    '%s répond %s.' % (adresse[:80], resultat.get('statut'))))
    elif distants_a_verifier:
        trouvés.append(faire_constat(
            audit, 'distants-non-verifies', 'info',
            '%d adresse(s) distante(s) n’ont PAS été contactées : la '
            'vérification à distance est désactivée par défaut, pour que '
            'l’audit ne produise aucun trafic réseau à votre insu.'
            % len(distants_a_verifier),
            'Cochez « Vérifier les adresses distantes » pour les contacter '
            '(%d au maximum).' % MAX_LIENS_DISTANTS))

    trouvés.append(faire_constat(
        audit, 'liens-comptes', 'ok',
        '%d référence(s) : %d interne(s), %d fragment(s), %d externe(s), '
        '%d spéciale(s)%s.'
        % (len(references), compte['internes'], compte['fragments'],
           compte['externes'], compte['speciaux'],
           ', %d cassée(s)' % compte['casses'] if compte['casses'] else ''),
        '', ligne=None))
    ctx.comptes_liens = compte
    return trouvés


def _homonyme(chemin):
    """Cherche, dans le dossier parent, un fichier qui ne diffère que par la casse."""
    try:
        parent = chemin.parent
        if not parent.is_dir():
            return None
        voulu = chemin.name.lower()
        for candidat in parent.iterdir():
            if candidat.name.lower() == voulu and candidat.name != chemin.name:
                return candidat.name
    except OSError:
        return None
    return None


# =================================================================== 4. POIDS ==
def audit_poids(ctx):
    audit = 'poids'
    trouvés, ajouter = _rapporteur(audit, ctx)
    document = ctx.document
    ressources = []
    total = len(ctx.contenu.encode('utf8', 'replace'))
    inline = 0

    for element in document.par_balise('script', 'style'):
        inline += len(element.brut_interne.encode('utf8', 'replace'))

    vus = set()
    for reference in _collecter_references(ctx):
        valeur = reference['valeur']
        if not valeur or valeur in vus:
            continue
        if valeur.startswith('#') or valeur.lower().startswith(
                ('data:', 'blob:', 'mailto:', 'tel:', 'javascript:', 'about:')):
            continue
        distant = bool(re.match(r'^(https?:)?//', valeur))
        if distant:
            ressources.append({'reference': valeur, 'distant': True,
                               'octets': None, 'mime': '', 'gzip': None,
                               'ligne': reference['ligne']})
            continue
        if valeur in ctx._ressources_fournies:
            donnees = ctx._ressources_fournies[valeur]
            if isinstance(donnees, str):
                donnees = donnees.encode('utf8', 'replace')
        else:
            donnees = ctx.lire(valeur)
        if donnees is None:
            continue                            # déjà signalé par l'audit liens
        vus.add(valeur)
        chemin, relatif = ctx.resoudre_local(valeur)
        suffixe = (Path(valeur.split('?')[0].split('#')[0]).suffix or '').lower()
        mime = _mime_depuis(suffixe)
        compresse = None
        if any(mime == prefixe or mime.startswith(prefixe)
               for prefixe in ref.COMPRESSIBLES):
            try:
                estime = len(zlib.compress(donnees, 6))
            except Exception:
                estime = None
            # gzip GONFLE un fichier de quelques dizaines d'octets (en-tête de
            # 18 octets). Compter cette taille comme « transférée » donnait un
            # total compressé SUPÉRIEUR au total brut, et un rapport qui
            # annonce une économie négative n'est pas pris au sérieux. Les
            # serveurs fixent d'ailleurs un seuil (1 Ko en général) pour cette
            # raison : l'estimation suit la même règle.
            if estime is not None and (estime < len(donnees)
                                       or len(donnees) >= SEUIL_COMPRESSION):
                compresse = estime
        entree = {'reference': valeur, 'relatif': relatif, 'distant': False,
                  'octets': len(donnees), 'mime': mime, 'gzip': compresse,
                  'ligne': reference['ligne'], 'nature': reference['nature'],
                  'largeur': None, 'hauteur': None,
                  'affichee': _taille_affichee(reference['element'])}
        if suffixe in ref.EXTENSIONS_IMAGES:
            largeur, hauteur = dimensions_image(donnees)
            entree['largeur'], entree['hauteur'] = largeur, hauteur
        ressources.append(entree)
        total += len(donnees)
        if len(ressources) >= MAX_RESSOURCES_POIDS:
            trouvés.append(faire_constat(
                audit, 'ressources-tronquees', 'info',
                'Plus de %d ressources : le détail du poids s’arrête là, le '
                'total affiché est donc minoré.' % MAX_RESSOURCES_POIDS))
            break

    # Le poids transféré se calcule élément par élément : le document compressé
    # plus chaque ressource locale compressée. Une première version compressait
    # le DOCUMENT et soustrayait le gain d'un total qui contenait aussi un PNG
    # non compressible — le « transféré » annoncé devenait inférieur au poids de
    # la seule image, ce qui est impossible et se voit.
    document_octets = len(ctx.contenu.encode('utf8', 'replace'))
    document_compresse = document_octets
    if document_octets >= SEUIL_COMPRESSION:
        try:
            document_compresse = min(
                document_octets,
                len(zlib.compress(ctx.contenu.encode('utf8', 'replace'), 6)))
        except Exception:
            document_compresse = document_octets
    transfere = document_compresse
    for entree in ressources:
        if entree['distant'] or entree.get('octets') is None:
            continue
        transfere += (entree['gzip'] if entree.get('gzip') is not None
                      else entree['octets'])
    seuils = ref.BUDGETS
    ok, alerte = seuils['page_octets']
    ajouter('poids-total', 'ok' if total <= ok else
            ('avertissement' if total <= alerte else 'erreur'),
            'Poids total de la page et de ses ressources locales : %s '
            '(document %s, CSS et JS inline %s, %d ressource(s)).'
            % (_octets(total), _octets(
                len(ctx.contenu.encode('utf8', 'replace'))), _octets(inline),
               len([r for r in ressources if not r['distant']])),
            'Budget conseillé : %s pour une page, %s au-delà duquel le '
            'chargement mobile devient pénible.' % (_octets(ok), _octets(alerte)))
    ajouter('poids-transfere', 'ok' if transfere <= ok else
            ('avertissement' if transfere <= alerte else 'erreur'),
            'Estimation avec compression gzip des ressources texte : %s '
            '(économie de %s).' % (_octets(transfere),
                                   _octets(max(0, total - transfere))),
            'La compression doit être activée sur le serveur : c’est le gain '
            'le plus simple de tout cet audit.')

    ok, alerte = seuils['requetes']
    nombre = len(ressources)
    ajouter('nombre-requetes', 'ok' if nombre <= ok else
            ('avertissement' if nombre <= alerte else 'erreur'),
            '%d requête(s) pour charger la page%s.'
            % (nombre, ', dont %d distante(s)' % len([r for r in ressources
                                                      if r['distant']])
               if any(r['distant'] for r in ressources) else ''),
            'En dessous de %d requêtes, la page reste rapide même sur un réseau '
            'mobile ; au-delà de %d, regroupez (sprites, CSS unique, '
            'différé).' % (ok, alerte))

    for entree in ressources:
        if entree['distant'] or entree.get('octets') is None:
            continue
        suffixe = (Path(entree['reference'].split('?')[0]).suffix or '').lower()
        if suffixe in ref.EXTENSIONS_IMAGES:
            cle = 'image_octets'
        elif suffixe in ref.EXTENSIONS_SCRIPTS:
            cle = 'script_octets'
        elif suffixe in ref.EXTENSIONS_STYLES:
            cle = 'feuille_octets'
        elif suffixe in ref.EXTENSIONS_POLICES:
            cle = 'police_octets'
        else:
            cle = None
        if cle:
            ok, alerte = seuils[cle]
            if entree['octets'] > alerte:
                ajouter('ressource-lourde', 'erreur',
                        '%s pèse %s : au-delà de %s pour ce type de ressource.'
                        % (entree['reference'], _octets(entree['octets']),
                           _octets(alerte)),
                        'Compressez, réduisez la définition, ou chargez en '
                        'différé (loading="lazy").', ligne=entree['ligne'])
            elif entree['octets'] > ok:
                ajouter('ressource-lourde', 'avertissement',
                        '%s pèse %s, au-dessus du budget conseillé de %s.'
                        % (entree['reference'], _octets(entree['octets']),
                           _octets(ok)),
                        'Compressez ou différez le chargement.',
                        ligne=entree['ligne'])
        if entree.get('largeur') and entree.get('affichee'):
            affichee = entree['affichee']
            if affichee[0] and entree['largeur'] > affichee[0] * 2.5 \
                    and entree['largeur'] > 400:
                ajouter('image-surdimensionnee', 'avertissement',
                        '%s fait %d px de large pour un affichage de %d px : '
                        'le navigateur télécharge et décode %.1f fois plus de '
                        'pixels que nécessaire.'
                        % (entree['reference'], entree['largeur'], affichee[0],
                           entree['largeur'] / max(1, affichee[0])),
                        'Exportez l’image à la taille affichée (×2 pour les '
                        'écrans denses), ou utilisez srcset.',
                        ligne=entree['ligne'])
        if entree.get('gzip') is not None and entree['octets'] > 100_000:
            gain = entree['octets'] - entree['gzip']
            if gain > entree['octets'] * 0.6:
                ajouter('compressible', 'info',
                        '%s (%s) gagnerait %s en gzip : vérifiez que le serveur '
                        'compresse bien les ressources texte.'
                        % (entree['reference'], _octets(entree['octets']),
                           _octets(gain)),
                        'Activez gzip/brotli sur le serveur.',
                        ligne=entree['ligne'])
        if suffixe == '.svg' and entree['octets'] > 50_000:
            ajouter('svg-lourd', 'info',
                    '%s est un SVG de %s : passez-le dans un optimiseur '
                    '(SVGO), les métadonnées d’éditeur y pèsent souvent la '
                    'moitié.' % (entree['reference'], _octets(entree['octets'])),
                    'svgo, ou « nettoyer le SVG » de votre éditeur vectoriel.',
                    ligne=entree['ligne'])

    polices = [e for e in ressources
               if (Path(e['reference'].split('?')[0]).suffix or '').lower()
               in ref.EXTENSIONS_POLICES]
    if len(polices) > 4:
        ajouter('trop-de-polices', 'avertissement',
                '%d fichiers de polices sont chargés (%s) : chaque police est '
                'un aller-retour bloquant le rendu du texte.'
                % (len(polices), _octets(sum(p['octets'] for p in polices))),
                'Limitez-vous à deux familles et deux graisses, en woff2, avec '
                'font-display:swap.')
    if polices and not re.search(r'font-display\s*:', ctx.contenu):
        ajouter('font-display-absent', 'info',
                'Des polices externes sont chargées sans font-display : le '
                'texte reste invisible pendant leur téléchargement.',
                'font-display: swap dans la règle @font-face.')

    sans_dimensions = [e for e in document.par_balise('img')
                       if not e.a('width') and not e.a('height')
                       and e.get('loading') != 'lazy']
    if sans_dimensions:
        premier = sans_dimensions[0]
        ajouter('img-sans-dimensions', 'info',
                '%d image(s) n’ont ni width ni height (la première ligne %s) : '
                'le navigateur ne peut pas réserver leur place, et la mise en '
                'page saute à leur arrivée (décalage cumulatif).'
                % (len(sans_dimensions), premier.ligne),
                'width et height en attributs, ou aspect-ratio en CSS.',
                ligne=premier.ligne, element=premier.signature())
    if inline > 50_000:
        ajouter('inline-lourd', 'avertissement',
                '%s de CSS et de JavaScript sont écrits en ligne dans le '
                'document : ils ne peuvent pas être mis en cache séparément et '
                'sont retéléchargés à chaque page.' % _octets(inline),
                'Sortez-les dans des fichiers liés.', ligne=1)

    ctx.poids = {'total': total, 'transfere': transfere, 'inline': inline,
                 'document_octets': document_octets,
                 'document_compresse': document_compresse,
                 'requetes': nombre, 'ressources': ressources}
    return trouvés


def _taille_affichee(element):
    if element is None:
        return None
    try:
        largeur = int(element.get('width')) if element.a('width') else None
    except (TypeError, ValueError):
        largeur = None
    try:
        hauteur = int(element.get('height')) if element.a('height') else None
    except (TypeError, ValueError):
        hauteur = None
    if largeur is None and hauteur is None:
        return None
    return (largeur, hauteur)


def _mime_depuis(suffixe):
    table = {
        '.css': 'text/css', '.js': 'application/javascript',
        '.mjs': 'application/javascript', '.cjs': 'application/javascript',
        '.json': 'application/json', '.html': 'text/html',
        '.htm': 'text/html', '.xml': 'application/xml',
        '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
        '.avif': 'image/avif', '.ico': 'image/x-icon', '.bmp': 'image/bmp',
        '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf',
        '.otf': 'font/otf', '.eot': 'application/vnd.ms-fontobject',
        '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg',
        '.pdf': 'application/pdf', '.txt': 'text/plain',
        '.map': 'application/json', '.wasm': 'application/wasm',
    }
    return table.get(suffixe.lower(), 'application/octet-stream')


def _octets(nombre):
    """Une taille lisible : 940 o, 12,4 Ko, 3,2 Mo."""
    if nombre is None:
        return 'inconnue'
    nombre = float(nombre)
    for unite, diviseur in (('o', 1), ('Ko', 1024), ('Mo', 1024 ** 2),
                            ('Go', 1024 ** 3)):
        if nombre < diviseur * 1024 or unite == 'Go':
            valeur = nombre / diviseur
            return ('%d %s' % (round(valeur), unite) if valeur >= 100 or unite == 'o'
                    else '%s %s' % (('%.1f' % valeur).replace('.', ','), unite))
    return '%d o' % nombre


# ============================================================ 5. MÉTADONNÉES ==
def audit_metadonnees(ctx):
    audit = 'metadonnees'
    trouvés, ajouter = _rapporteur(audit, ctx)
    document = ctx.document
    donnees = {}

    titre = document.titre()
    donnees['titre'] = titre
    titres = document.par_balise('title')
    if not titres:
        ajouter('titre-absent', 'erreur',
                'Le document n’a pas de <title> : l’onglet du navigateur, les '
                'résultats de recherche et les partages n’auront aucun nom.',
                '<title>Nom de la page — Nom du site</title> dans <head>.')
    else:
        if len(titres) > 1:
            ajouter('titre-multiple', 'erreur',
                    '%d éléments <title> : seul le premier est utilisé, les '
                    'autres sont du bruit.' % len(titres),
                    'Un seul <title>, dans <head>.', titres[1])
        longueur = len(titre)
        mini, maxi = ref.LONGUEUR_TITRE
        if not titre.strip():
            ajouter('titre-vide', 'erreur', 'Le <title> est vide.',
                    'Un titre de %d à %d caractères.' % (mini, maxi), titres[0])
        elif longueur < mini:
            ajouter('titre-court', 'avertissement',
                    'Le titre « %s » ne fait que %d caractères : trop court '
                    'pour être descriptif.' % (titre, longueur),
                    'Entre %d et %d caractères.' % (mini, maxi), titres[0])
        elif longueur > maxi:
            ajouter('titre-long', 'avertissement',
                    'Le titre fait %d caractères : il sera coupé dans les '
                    'résultats de recherche au-delà d’environ %d.'
                    % (longueur, maxi),
                    'Raccourcissez-le.', titres[0])
        else:
            ajouter('titre-ok', 'ok', 'Titre de %d caractères : « %s ».'
                    % (longueur, titre), '', titres[0])
        if titre.strip().lower() in ('sans titre', 'untitled', 'document',
                                     'index', 'page', 'test'):
            ajouter('titre-banal', 'avertissement',
                    'Le titre « %s » est celui d’un document non fini : il est '
                    'repris tel quel par les moteurs et les partages.' % titre,
                    'Un titre descriptif.', titres[0])

    description = document.meta('description')
    donnees['description'] = description
    element = document.meta_element('description')
    if not description:
        ajouter('description-absente', 'erreur',
                'Pas de meta description : les moteurs en fabriquent une en '
                'prenant du texte au hasard dans la page.',
                '<meta name="description" content="150 caractères qui disent '
                'ce que la page apporte.">', None)
    else:
        mini, maxi = ref.LONGUEUR_DESCRIPTION
        if len(description) < mini:
            ajouter('description-courte', 'avertissement',
                    'La meta description fait %d caractères : en dessous de '
                    '%d, elle n’apporte rien de plus que le titre.'
                    % (len(description), mini),
                    'Entre %d et %d caractères.' % (mini, maxi), element)
        elif len(description) > maxi:
            ajouter('description-longue', 'avertissement',
                    'La meta description fait %d caractères : elle sera coupée '
                    'au-delà d’environ %d.' % (len(description), maxi),
                    'Raccourcissez-la.', element)
        else:
            ajouter('description-ok', 'ok',
                    'Meta description de %d caractères.' % len(description),
                    '', element)
        if description == titre:
            ajouter('description-identique', 'avertissement',
                    'La meta description recopie le titre : c’est une '
                    'occasion perdue de dire autre chose.', 'Décrivez le '
                    'contenu.', element)

    encodage = document.premier('meta')
    charset = ''
    for meta in document.par_balise('meta'):
        if meta.a('charset'):
            charset = meta.get('charset')
            encodage = meta
            break
    donnees['charset'] = charset
    if not charset:
        ajouter('charset-absent', 'erreur',
                'Aucun <meta charset> : le navigateur devine l’encodage, et les '
                'accents se cassent d’un navigateur à l’autre.',
                '<meta charset="utf-8"> en TOUT DÉBUT de <head>.')
    elif charset.strip().lower().replace('-', '') != 'utf8':
        ajouter('charset-non-utf8', 'avertissement',
                'Le document déclare charset="%s" : UTF-8 est attendu partout '
                'ailleurs dans ce projet.' % charset,
                '<meta charset="utf-8">.', encodage)
    else:
        tete = document.premier('head')
        if tete is not None and encodage is not None:
            avant = [e for e in tete.enfants
                     if e.ordre < encodage.ordre and e.balise not in ('meta',)]
            position = ctx.contenu.lower().find('charset')
            if avant or (position > 1024 and position >= 0):
                ajouter('charset-tardif', 'avertissement',
                        'Le <meta charset> doit être le premier élément de '
                        '<head>, dans les 1024 premiers octets : au-delà, le '
                        'navigateur a déjà commencé à décoder et peut '
                        'réinterpréter la page.',
                        'Placez-le immédiatement après <head>.', encodage)

    viewport = document.meta('viewport')
    donnees['viewport'] = viewport
    if not viewport:
        ajouter('viewport-absent', 'erreur',
                'Pas de meta viewport : sur mobile la page est affichée à 980 '
                'px puis réduite, illisible sans zoom.',
                '<meta name="viewport" content="width=device-width, '
                'initial-scale=1">.')
    elif 'width=device-width' not in viewport.replace(' ', ''):
        ajouter('viewport-sans-width', 'avertissement',
                'meta viewport="%s" ne contient pas width=device-width : la '
                'mise en page responsive ne s’appliquera pas.' % viewport,
                'content="width=device-width, initial-scale=1".',
                document.meta_element('viewport'))

    canonique = ''
    for lien in document.par_balise('link'):
        if (lien.get('rel') or '').lower() == 'canonical':
            canonique = lien.get('href') or ''
            element = lien
            break
    donnees['canonical'] = canonique
    if not canonique:
        ajouter('canonical-absent', 'avertissement',
                'Pas de lien canonical : une même page atteinte par plusieurs '
                'adresses (paramètres, majuscules, http/https) est comptée '
                'plusieurs fois.',
                '<link rel="canonical" href="https://exemple.fr/page">.')
    elif not re.match(r'^https?://', canonique):
        ajouter('canonical-relatif', 'erreur',
                'Le canonical « %s » est relatif : la spécification exige une '
                'adresse absolue, et un canonical relatif est ignoré.'
                % canonique,
                'href="https://exemple.fr/page".', element)

    donnees['robots'] = document.meta('robots')
    robots = donnees['robots'].lower()
    if 'noindex' in robots:
        ajouter('noindex', 'avertissement',
                'meta robots contient noindex : cette page sera retirée de '
                'l’index. C’est voulu pour une page privée, catastrophique sur '
                'une page publique.',
                'Retirez noindex si la page doit être trouvée.',
                document.meta_element('robots'))

    # Une info par balise absente produisait sept constats pour une page qui
    # n'a simplement pas de partage social, et noyait les vrais problèmes sous
    # la note. Les balises sont regroupées : les trois qui changent le rendu du
    # partage d'un côté, les facultatives de l'autre.
    og_importants = []
    og_facultatifs = []
    for nom, gravite, role in ref.OPENGRAPH:
        valeur = document.meta(nom, 'property') or document.meta(nom, 'name')
        donnees[nom] = valeur
        if valeur:
            continue
        if nom in ('og:title', 'og:description', 'og:image'):
            og_importants.append(nom)
        else:
            og_facultatifs.append(nom)
    if og_importants:
        ajouter('og-incomplet', 'avertissement',
                'Open Graph incomplet : %s. Sans elles, le partage sur les '
                'réseaux sociaux reprend le titre et la description de la page '
                'et affiche un aperçu sans image — ce qui n’est pas faux, mais '
                'n’est pas contrôlé.' % _enumerer(og_importants),
                'Le générateur « Balises de partage » produit le bloc complet.',
                document.meta_element('og:title', 'property'))
    if og_facultatifs:
        langue = ''
        element_html = document.premier('html')
        if element_html is not None:
            langue = (element_html.get('lang') or '').strip()
        precision = ''
        if 'og:locale' in og_facultatifs and langue:
            precision = (' La page est en « %s » : sans og:locale, les partages '
                         'ne disent pas dans quelle langue est le contenu.'
                         % langue)
        ajouter('og-manquant', 'info',
                '%d balise(s) Open Graph facultative(s) absente(s) : %s. Elles '
                'affinent le partage, elles ne sont pas nécessaires.%s'
                % (len(og_facultatifs), _enumerer(og_facultatifs), precision),
                '<meta property="og:site_name" content="Nom du site">.')
    if donnees.get('og:image'):
        adresse = donnees['og:image']
        if not re.match(r'^https?://', adresse):
            ajouter('og-image-relative', 'erreur',
                    'og:image="%s" est relative : les réseaux sociaux exigent '
                    'une adresse absolue et l’ignoreront.' % adresse,
                    'https://exemple.fr/images/partage.png.')
        else:
            chemin, relatif = ctx.resoudre_local(adresse)
            if chemin is None and ctx.chemin is not None:
                pass                              # distante : rien à vérifier ici
    if donnees.get('og:url') and not re.match(r'^https?://',
                                              donnees['og:url']):
        ajouter('og-url-relative', 'erreur',
                'og:url="%s" doit être une adresse absolue.' % donnees['og:url'],
                'https://exemple.fr/page.')

    twitter_absents = []
    for nom, gravite, role in ref.TWITTER:
        valeur = document.meta(nom)
        donnees[nom] = valeur
        if valeur:
            continue
        if nom == 'twitter:card' and any(
                donnees.get(x) for x in ('twitter:title', 'twitter:image')):
            # Des balises twitter: sans twitter:card : aucune carte n'est
            # produite. C'est un fait distinct de l'absence du bloc entier, il
            # garde donc son propre constat.
            ajouter('twitter-card-absent', gravite,
                    'Des meta twitter: sont présentes sans twitter:card : sans '
                    'elle, aucune carte n’est produite.',
                    '<meta name="twitter:card" content="summary_large_image">.')
            continue
        twitter_absents.append(nom)
    if twitter_absents and len(twitter_absents) < len(ref.TWITTER):
        ajouter('twitter-manquant', 'info',
                '%d balise(s) Twitter Card absente(s) : %s.'
                % (len(twitter_absents), _enumerer(twitter_absents)),
                '<meta name="twitter:card" content="summary_large_image">.')

    favicon = False
    for lien in document.par_balise('link'):
        relation = (lien.get('rel') or '').lower()
        if 'icon' in relation:
            favicon = True
            if not (lien.get('href') or '').strip():
                ajouter('favicon-vide', 'erreur',
                        'Un lien d’icône a un href vide.',
                        'href="/favicon.ico".', lien)
    donnees['favicon'] = favicon
    if not favicon:
        ajouter('favicon-absent', 'avertissement',
                'Aucun lien d’icône (favicon) : l’onglet, les marque-pages et '
                'l’écran d’accueil mobile n’auront pas d’icône.',
                '<link rel="icon" href="/favicon.ico" sizes="any"> et une '
                'variante SVG.')

    theme = document.meta('theme-color')
    donnees['theme_color'] = theme
    if not theme:
        ajouter('theme-color-absent', 'info',
                'Pas de meta theme-color : la barre du navigateur mobile reste '
                'par défaut.',
                '<meta name="theme-color" content="#1e1e2e">.')

    manifeste = ''
    for lien in document.par_balise('link'):
        if (lien.get('rel') or '').lower() == 'manifest':
            manifeste = lien.get('href') or ''
    donnees['manifest'] = manifeste
    if manifeste:
        donnees_manifeste = ctx.lire(manifeste)
        if donnees_manifeste:
            try:
                import json
                contenu = json.loads(donnees_manifeste.decode('utf8', 'replace'))
                if not isinstance(contenu, dict):
                    raise ValueError('ce n’est pas un objet')
                for champ in ('name', 'short_name', 'start_url', 'display'):
                    if champ not in contenu:
                        ajouter('manifeste-incomplet', 'avertissement',
                                'Le manifeste %s ne déclare pas « %s » : '
                                'l’installation en application est dégradée.'
                                % (manifeste, champ),
                                'Complétez le manifeste — le générateur '
                                '« Manifeste web » du panneau le produit.')
                if 'icons' not in contenu or not contenu['icons']:
                    ajouter('manifeste-sans-icones', 'erreur',
                            'Le manifeste ne déclare aucune icône : sans icône '
                            '192 px et 512 px, l’installation est refusée.',
                            'icons: [{src, sizes:"192x192"}, {src, '
                            'sizes:"512x512"}].')
            except (ValueError, KeyError) as exc:
                ajouter('manifeste-invalide', 'erreur',
                        'Le manifeste %s n’est pas un JSON valide (%s) : il '
                        'sera ignoré.' % (manifeste, exc),
                        'Corrigez le JSON.')
        elif ctx.chemin is not None:
            ajouter('manifeste-introuvable', 'erreur',
                    'Le manifeste « %s » est introuvable dans le projet.'
                    % manifeste, 'Vérifiez le chemin.')

    blocs_jsonld = []
    for element in document.par_balise('script'):
        if (element.get('type') or '').lower() != 'application/ld+json':
            continue
        blocs_jsonld.append(element)
        try:
            import json
            contenu = json.loads(element.brut_interne)
        except ValueError as exc:
            ajouter('jsonld-invalide', 'erreur',
                    'Un bloc JSON-LD n’est pas un JSON valide (%s) : les '
                    'données structurées sont rejetées en bloc.' % exc,
                    'Validez le JSON — une virgule de trop suffit à tout '
                    'perdre.', element)
            continue
        entrees = contenu if isinstance(contenu, list) else [contenu]
        for entree in entrees:
            if not isinstance(entree, dict):
                ajouter('jsonld-non-objet', 'erreur',
                        'Une entrée JSON-LD n’est pas un objet.', '', element)
                continue
            contexte = entree.get('@context', '')
            if isinstance(contexte, str) and contexte.rstrip('/') not in \
                    [c.rstrip('/') for c in ref.CONTEXTES_JSONLD]:
                ajouter('jsonld-contexte', 'avertissement',
                        '@context="%s" n’est pas schema.org : les moteurs ne '
                        'reconnaîtront pas le type.' % contexte,
                        '"@context": "https://schema.org".', element)
            if not entree.get('@type'):
                ajouter('jsonld-sans-type', 'erreur',
                        'Une entrée JSON-LD n’a pas de @type : elle ne décrit '
                        'rien.', '"@type": "Article", "Product", "LocalBusiness"…',
                        element)
    donnees['jsonld'] = len(blocs_jsonld)
    if not blocs_jsonld:
        ajouter('jsonld-absent', 'info',
                'Aucune donnée structurée JSON-LD : ce n’est pas obligatoire, '
                'mais c’est ce qui produit les résultats enrichis (étoiles, '
                'prix, fil d’Ariane).',
                'Le générateur « JSON-LD » du panneau produit un bloc valide.')

    if ctx.racine is not None:
        for nom, conseil in (
                ('robots.txt', 'Le générateur « robots.txt » du panneau le '
                               'produit, avec la ligne Sitemap.'),
                ('sitemap.xml', 'Le générateur « sitemap.xml » du panneau le '
                                'produit à partir d’une liste d’adresses.')):
            chemin = ctx.racine / nom
            try:
                existe = chemin.is_file()
            except OSError:
                existe = False
            donnees[nom] = existe
            if not existe:
                ajouter('fichier-manquant', 'info',
                        'Le projet ne contient pas de %s.' % nom, conseil)
            elif nom == 'sitemap.xml' and existe:
                try:
                    contenu = chemin.read_text('utf8', 'replace')
                except OSError:
                    contenu = ''
                if contenu and '<urlset' not in contenu:
                    ajouter('sitemap-invalide', 'erreur',
                            'sitemap.xml ne contient pas d’élément <urlset> : '
                            'il sera rejeté.',
                            '<urlset xmlns="http://www.sitemaps.org/schemas/'
                            'sitemap/0.9">.')

    auteur = document.meta('author')
    donnees['author'] = auteur
    if not auteur:
        ajouter('author-absent', 'info',
                'Pas de meta author : utile pour un article signé.',
                '<meta name="author" content="Nom">.')
    # Le bloc qui suivait ici testait la présence de <html lang> puis ne faisait
    # rien (`pass`) : l'absence de langue est déjà un constat de l'audit
    # d'accessibilité, et un `if … : pass` se lit comme une règle oubliée.
    # Le conseil sur og:locale est désormais porté par le constat regroupé des
    # balises facultatives, qui nomme déjà og:locale quand elle manque : deux
    # constats pour un même fait, c'est un fait compté deux fois dans la note.
    ctx.metadonnees = donnees
    return trouvés


# ============================================================== 6. VALIDATION ==
def audit_validation(ctx):
    audit = 'validation'
    trouvés, ajouter = _rapporteur(audit, ctx)
    document = ctx.document

    # --- doctype ------------------------------------------------------------
    declaration = (document.doctype or '').strip().lower()
    if not declaration:
        ajouter('doctype-absent', 'erreur',
                'Le document n’a pas de <!DOCTYPE html> : le navigateur bascule '
                'en mode de compatibilité (« quirks »), où les tailles et les '
                'héritages CSS ne suivent plus les règles normales.',
                '<!DOCTYPE html> en toute première ligne.', ligne=1)
    elif declaration not in ('doctype html',) and not declaration.startswith(
            'doctype html '):
        ajouter('doctype-inattendu', 'avertissement',
                'La déclaration « <!%s> » n’est pas le doctype HTML5 : elle '
                'place le document en mode quasi standard.' % document.doctype,
                '<!DOCTYPE html>.', ligne=document.doctype_ligne)
    if document.doctype and ctx.contenu.lstrip()[:1] not in ('<',):
        ajouter('avant-doctype', 'avertissement',
                'Du contenu précède le <!DOCTYPE> (souvent une ligne vide avec '
                'un BOM) : le doctype est alors ignoré.',
                'Le doctype doit être le tout premier caractère.', ligne=1)

    # --- anomalies de l'analyseur -------------------------------------------
    for anomalie in document.anomalies:
        gravite = anomalie.get('gravite', 'avertissement')
        ajouter(anomalie['code'], gravite, anomalie['message'],
                _CONSEILS_STRUCTURE.get(anomalie['code'], ''),
                ligne=anomalie.get('ligne'), element=None)

    # --- attributs ----------------------------------------------------------
    for element in document.elements:
        vus = {}
        for nom, _valeur in element.attributs:
            vus[nom] = vus.get(nom, 0) + 1
        for nom, fois in vus.items():
            if fois > 1:
                ajouter('attribut-duplique', 'erreur',
                        '%s porte %d fois l’attribut %s : seul le premier est '
                        'conservé, le suivant est ignoré sans avertissement.'
                        % (element.signature(), fois, nom),
                        'Ne gardez qu’une occurrence.', element)
        if element.balise in ref.ELEMENTS_OBSOLETES:
            ajouter('element-obsolete', 'erreur',
                    '<%s> est retiré du HTML : %s'
                    % (element.balise, ref.ELEMENTS_OBSOLETES[element.balise]),
                    '', element)
        for (balise, attribut), conseil in ref.ATTRIBUTS_OBSOLETES.items():
            if balise not in ('*', element.balise):
                continue
            if element.a(attribut):
                ajouter('attribut-obsolete', 'avertissement',
                        'L’attribut %s sur <%s> est déprécié. Utilisez : %s'
                        % (attribut, element.balise, conseil), '', element)
        for nom, valeur in element.attributs:
            if nom == 'style' and valeur and not valeur.rstrip().endswith((';', '}')):
                pass                              # un style sans ; final est valide
            if nom.startswith('on') and nom not in _EVENEMENTS_CONNUS:
                ajouter('evenement-inconnu', 'info',
                        '%s n’est pas un gestionnaire d’événement reconnu : il '
                        'ne se déclenchera jamais.' % nom,
                        'Vérifiez l’orthographe (onclick, oninput, onchange…).',
                        element)

    # --- imbrications impossibles -------------------------------------------
    for element in document.elements:
        permis = ref.PARENTS_OBLIGATOIRES.get(element.balise)
        if not permis:
            continue
        parent = element.parent
        if parent is None or parent.balise == '#document':
            ajouter('parent-manquant', 'erreur',
                    '<%s> est directement dans le document : il doit être dans '
                    'un <%s>.' % (element.balise, '>, <'.join(permis)),
                    '', element)
        elif parent.balise not in permis:
            # <tbody> est inséré implicitement par le navigateur : un <tr> sous
            # un <table> n'est pas une erreur, l'analyseur ne crée pas de tbody
            # implicite, donc on l'accepte explicitement.
            if element.balise == 'tr' and parent.balise == 'table':
                continue
            if element.balise in ('dt', 'dd') and parent.balise == 'dl':
                continue
            ajouter('parent-inattendu', 'erreur',
                    '<%s> se trouve dans <%s> : il doit être dans <%s>. Le '
                    'navigateur le déplace, ce qui casse la mise en page et les '
                    'sélecteurs CSS descendants.'
                    % (element.balise, parent.balise, '>, <'.join(permis)),
                    '', element)
        if element.balise == 'table':
            for enfant in element.enfants:
                if enfant.balise in ref.ENFANTS_TABLE:
                    continue
                ajouter('enfant-de-table', 'erreur',
                        'Un <%s> est enfant direct de <table> : le navigateur '
                        'le déplace AVANT le tableau. C’est la cause classique '
                        'd’un texte ou d’un formulaire qui apparaît au mauvais '
                        'endroit.' % enfant.balise,
                        'Enveloppez les lignes dans <tbody>.', enfant)
        if element.balise in ('a', 'button'):
            for descendant in element.iterer():
                if descendant is element:
                    continue
                if descendant.balise in ref.INTERACTIFS:
                    ajouter('interactif-imbrique', 'erreur',
                            'Un <%s> contient un <%s> : le contenu interactif '
                            'ne peut pas être imbriqué, le comportement au clic '
                            'devient imprévisible et l’accessibilité casse.'
                            % (element.balise, descendant.balise),
                            'Sortez le second élément, ou remplacez le '
                            'conteneur par un <div> avec un gestionnaire.',
                            descendant)
                    break
        if element.balise == 'form':
            for descendant in element.iterer():
                if descendant is not element and descendant.balise == 'form':
                    ajouter('formulaire-imbrique', 'erreur',
                            'Un <form> contient un autre <form> : le second est '
                            'ignoré et ses champs partent avec le premier.',
                            'Deux formulaires distincts, côte à côte.',
                            descendant)
                    break
        if element.balise == 'p':
            for descendant in element.iterer():
                if descendant is element:
                    continue
                if descendant.balise in ('div', 'p', 'ul', 'ol', 'table',
                                         'section', 'article', 'form'):
                    ajouter('bloc-dans-paragraphe', 'erreur',
                            'Un <%s> dans un <p> : le paragraphe est fermé '
                            'automatiquement avant, et la structure du document '
                            'n’est plus celle écrite.' % descendant.balise,
                            'Utilisez <div> comme conteneur.', descendant)
                    break
        if element.balise == 'head':
            for enfant in element.enfants:
                if enfant.balise in ('div', 'p', 'span', 'section', 'article',
                                     'ul', 'table', 'img', 'button', 'a'):
                    ajouter('contenu-dans-head', 'erreur',
                            'Un <%s> dans <head> : il sera déplacé dans <body>, '
                            'et tout ce qui le suit dans <head> aussi.'
                            % enfant.balise, '', enfant)
        if element.balise == 'body':
            for enfant in element.enfants:
                if enfant.balise in ('title', 'meta', 'link', 'base') \
                        and not enfant.a('itemprop'):
                    ajouter('meta-dans-body', 'avertissement',
                            'Un <%s> dans <body> : il appartient à <head>. '
                            'meta/link y sont tolérés mais déplacés par les '
                            'outils d’indexation.' % enfant.balise,
                            'Déplacez-le dans <head>.', enfant)
        if element.balise == 'script' and element.brut_interne.strip():
            for etiquette in ('</script', '<!--', '-->'):
                if etiquette in element.brut_interne.lower():
                    ajouter('script-mal-echappe', 'erreur',
                            'Le contenu d’un <script> contient « %s » : le '
                            'navigateur ferme le script à cet endroit et le '
                            'reste devient du texte affiché.' % etiquette,
                            'Écrivez "<\\/script" dans une chaîne JavaScript, '
                            'ou déplacez le code dans un fichier .js.', element)
                    break
        if element.balise == 'input':
            type_ = (element.get('type') or 'text').lower()
            if type_ == 'checkbox' or type_ == 'radio':
                if not element.a('name'):
                    ajouter('case-sans-name', 'avertissement',
                            'Un <input type="%s"> sans name : sa valeur ne sera '
                            'pas envoyée avec le formulaire.' % type_,
                            'name="…" (identique pour les cases d’un même '
                            'groupe radio).', element)
            if type_ == 'submit' and not element.a('name'):
                pass                              # sans objet pour un bouton
            if type_ == 'text' and element.a('pattern') is False and \
                    element.get('inputmode') in ('numeric', 'decimal') \
                    and not element.a('pattern'):
                ajouter('inputmode-sans-pattern', 'info',
                        'inputmode="%s" affiche un clavier numérique sans '
                        'contrôler la saisie.' % element.get('inputmode'),
                        'pattern="[0-9]*" pour valider aussi.', element)
        if element.balise == 'option' and not element.a('value'):
            ajouter('option-sans-value', 'info',
                    'Une <option> sans value envoie son texte comme valeur : '
                    'le moindre changement de libellé change la donnée.',
                    'value="code" distinct du libellé.', element)
        if element.balise == 'meta' and element.get('http-equiv') == 'Content-Type':
            ajouter('meta-content-type', 'info',
                    'meta http-equiv="Content-Type" est remplacé par '
                    '<meta charset>.', '<meta charset="utf-8">.', element)

    # --- encodage déclaré contre encodage réel ------------------------------
    if '\ufffd' in ctx.contenu:
        ajouter('caracteres-remplaces', 'erreur',
                'Le document contient des caractères de remplacement (U+FFFD) : '
                'il a été lu dans un encodage qui n’est pas le sien, et des '
                'accents sont perdus.',
                'Enregistrez le fichier en UTF-8 et déclarez <meta '
                'charset="utf-8">.',
                ligne=_ligne_du_motif(ctx.contenu, '\ufffd'))

    # --- CSS ----------------------------------------------------------------
    for erreur in ctx.erreurs_css:
        origine = erreur.get('origine') or ''
        ligne = erreur.get('ligne')
        message = erreur['message']
        if origine and not origine.startswith('le style en ligne'):
            # Le numéro de ligne est celui de la FEUILLE : le garder comme
            # ligne du constat ferait sauter l'utilisateur à une ligne du
            # document qui n'a rien à voir. Il passe donc dans le message.
            message = '%s Dans %s, ligne %s.' % (message, origine, ligne)
            ligne = None
        ajouter('css-' + erreur['code'],
                'erreur' if erreur['code'] in (
                    'accolade-ouverte', 'commentaire-ouvert', 'chaine-ouvert',
                    'chaine-ouverte')
                else 'avertissement', message, '', ligne=ligne)
    importants = 0
    declarations = 0
    proprietes_vues = {}

    def positionner(regle, ligne):
        """(ligne du constat, complément de message) selon l'origine de la règle.

        Une règle vient soit d'un bloc <style> du document — la ligne est alors
        celle du document — soit d'une feuille liée, où la ligne ne signifie
        rien pour le document audité.
        """
        origine = regle.origine or ''
        if origine.startswith('le style en ligne'):
            return ligne, ''
        return None, ' Dans %s, ligne %s.' % (origine, ligne)

    for regle in ctx.regles_css:
        for nom, valeur, importante, ligne in regle.declarations:
            declarations += 1
            if importante:
                importants += 1
            proprietes_vues.setdefault(nom, []).append(ligne)
            if nom.startswith('--'):
                continue
            if nom.startswith(ref.PREFIXES_VENDEURS):
                continue
            if nom not in ref.PROPRIETES_CSS:
                ou, complement = positionner(regle, ligne)
                ajouter('css-propriete-inconnue', 'info',
                        'La propriété « %s » n’est pas dans la liste de '
                        'référence de Pascal Studio : elle est peut-être '
                        'récente, expérimentale ou spécifique à un moteur, ou '
                        'bien il s’agit d’une faute de frappe — dans ce dernier '
                        'cas elle est simplement ignorée.%s' % (nom, complement),
                        'Vérifiez l’orthographe sur MDN.', ligne=ou)
            if re.fullmatch(r'0(px|em|rem|%|pt|cm|mm|in|pc|vh|vw|vmin|vmax|ch|ex)',
                            valeur.replace(' ', '')):
                ou, complement = positionner(regle, ligne)
                ajouter('css-zero-avec-unite', 'info',
                        '« %s: %s » : l’unité est superflue sur un zéro.%s'
                        % (nom, valeur, complement), 'Écrivez 0.', ligne=ou)
            if nom == 'z-index':
                try:
                    if abs(int(valeur)) > 10000:
                        ou, complement = positionner(regle, ligne)
                        ajouter('css-z-index-demesure', 'info',
                                'z-index: %s — les grandes valeurs ne règlent '
                                'rien, elles rendent seulement la suite '
                                'impossible à corriger.%s' % (valeur, complement),
                                'Une échelle courte (10, 20, 30) et des '
                                'contextes d’empilement.', ligne=ou)
                except ValueError:
                    pass
        for selecteur in selecteurs_de(regle):
            if re.search(r'(^|[\s>+~])\*($|[\s.:#\[])', selecteur) \
                    and regle.genre == 'regle':
                ou, complement = positionner(regle, regle.ligne)
                ajouter('css-selecteur-universel', 'info',
                        'Le sélecteur « %s » applique la règle à tous les '
                        'éléments : c’est coûteux et souvent involontaire.%s'
                        % (selecteur, complement),
                        'Ciblez les éléments concernés.', ligne=ou)
    if declarations and importants * 100 // max(1, declarations) > 20:
        ajouter('css-important-abusif', 'avertissement',
                '%d déclarations sur %d utilisent !important (%d %%) : à ce '
                'niveau, ce n’est plus un dépannage mais une cascade cassée.'
                % (importants, declarations,
                   importants * 100 // max(1, declarations)),
                'Corrigez la spécificité des sélecteurs plutôt que de forcer.')
    for nom, lignes in proprietes_vues.items():
        if len(lignes) > 40:
            ajouter('css-propriete-repetee', 'info',
                    'La propriété « %s » est déclarée %d fois : un fichier '
                    'utilitaire ou une variable CSS réduirait la feuille.'
                    % (nom, len(lignes)), '', ligne=lignes[0])
    if not ctx.regles_css and ctx.blocs_css:
        ajouter('css-vide', 'avertissement',
                'Un bloc <style> ne contient aucune règle exploitable.',
                'Vérifiez la syntaxe de la feuille.')

    # --- JSON des fichiers liés ---------------------------------------------
    for element in document.par_balise('script'):
        type_ = (element.get('type') or '').lower()
        if type_ in ('application/json', 'application/manifest+json',
                     'importmap'):
            try:
                import json
                json.loads(element.brut_interne)
            except ValueError as exc:
                ajouter('json-inline-invalide', 'erreur',
                        'Un <script type="%s"> n’est pas un JSON valide (%s).'
                        % (type_, exc),
                        'Validez le JSON.', element)
    ctx.validation = {'elements': len(document.elements),
                      'declarations_css': declarations,
                      'regles_css': len(ctx.regles_css),
                      'anomalies': len(document.anomalies)}
    if not trouvés:
        trouvés.append(faire_constat(audit, 'rien', 'ok',
                               'Le document est structurellement valide selon '
                               'cet audit (%d éléments, %d règles CSS).'
                               % (len(document.elements), len(ctx.regles_css))))
    return trouvés


_EVENEMENTS_CONNUS = frozenset((
    'onabort', 'onanimationend', 'onanimationiteration', 'onanimationstart',
    'onauxclick', 'onbeforeinput', 'onbeforematch', 'onbeforetoggle',
    'onblur', 'oncancel', 'oncanplay', 'oncanplaythrough', 'onchange',
    'onclick', 'onclose', 'oncontentvisibilityautostatechange', 'oncontextlost',
    'oncontextmenu', 'oncontextrestored', 'oncopy', 'oncuechange', 'oncut',
    'ondblclick', 'ondrag', 'ondragend', 'ondragenter', 'ondragleave',
    'ondragover', 'ondragstart', 'ondrop', 'ondurationchange', 'onemptied',
    'onended', 'onerror', 'onfocus', 'onfocusin', 'onfocusout', 'onformdata',
    'ongotpointercapture', 'oninput', 'oninvalid', 'onkeydown', 'onkeypress',
    'onkeyup', 'onload', 'onloadeddata', 'onloadedmetadata', 'onloadstart',
    'onlostpointercapture', 'onmousedown', 'onmouseenter', 'onmouseleave',
    'onmousemove', 'onmouseout', 'onmouseover', 'onmouseup', 'onmousewheel',
    'onpaste', 'onpause', 'onplay', 'onplaying', 'onpointercancel',
    'onpointerdown', 'onpointerenter', 'onpointerleave', 'onpointermove',
    'onpointerout', 'onpointerover', 'onpointerrawupdate', 'onpointerup',
    'onprogress', 'onratechange', 'onreset', 'onresize', 'onscroll',
    'onscrollend', 'onsecuritypolicyviolation', 'onseeked', 'onseeking',
    'onselect', 'onselectionchange', 'onselectstart', 'onslotchange',
    'onstalled', 'onsubmit', 'onsuspend', 'ontimeupdate', 'ontoggle',
    'ontouchcancel', 'ontouchend', 'ontouchmove', 'ontouchstart',
    'ontransitioncancel', 'ontransitionend', 'ontransitionrun',
    'ontransitionstart', 'onvolumechange', 'onwaiting', 'onwebkitanimationend',
    'onwheel',
))

_CONSEILS_STRUCTURE = {
    'non-ferme': 'Fermez la balise, ou corrigez la fermeture qui la suit.',
    'imbrication': 'Vérifiez l’ordre des fermetures.',
    'fermeture-orpheline': 'Retirez cette balise fermante, ou ouvrez '
                           'l’élément correspondant.',
    'autofermeture': 'En HTML, « /> » sur une balise non vide est ignoré : '
                     'ouvrez et fermez normalement.',
    'doctype-double': 'Une seule déclaration <!DOCTYPE html>, en première ligne.',
    'contenu-brut-non-ferme': 'Fermez le bloc : tout ce qui suit est avalé.',
    'commentaire-malforme': 'Retirez les « -- » à l’intérieur du commentaire.',
}


# ------------------------------------------------------------------- rapport --
def resume(constats):
    compte = {g: 0 for g in GRAVITES}
    for element in constats:
        compte[element['gravite']] = compte.get(element['gravite'], 0) + 1
    note = 100
    for gravite, malus in MALUS.items():
        note -= malus * compte.get(gravite, 0)
    compte['note'] = max(0, note)
    return compte


def auditer_tous(ctx, seulement=None):
    """Exécute les audits demandés sur un contexte déjà construit.

    Chaque audit est enveloppé : s'il lève, un constat nommé le remplace. Une
    section absente du rapport se lit comme « rien à signaler », ce qui est le
    contraire de la vérité quand l'audit a planté.
    """
    fonctions = {
        'accessibilite': audit_accessibilite,
        'securite': audit_securite,
        'liens': audit_liens,
        'poids': audit_poids,
        'metadonnees': audit_metadonnees,
        'validation': audit_validation,
    }
    cibles = seulement or AUDIT_IDS
    rapport = {'cible': ctx.cible, 'genre': 'url' if ctx.url else 'fichier',
               'entetes': dict(ctx.entetes), 'statut': ctx.statut,
               'audits': {}, 'resume': {}, 'donnees': {}}
    for identifiant in cibles:
        fonction = fonctions.get(identifiant)
        if fonction is None:
            rapport['audits'][identifiant] = [faire_constat(
                identifiant, 'audit-inconnu', 'erreur',
                'L’audit « %s » n’existe pas. Les audits disponibles sont : %s.'
                % (identifiant, ', '.join(AUDIT_IDS)))]
            rapport['resume'][identifiant] = resume(
                rapport['audits'][identifiant])
            continue
        try:
            constats = fonction(ctx)
        except Exception as exc:
            constats = [faire_constat(
                identifiant, 'audit-interrompu', 'erreur',
                'L’audit « %s » s’est interrompu (%s : %s). Les autres audits '
                'ont été exécutés ; celui-ci n’a PAS été fait, et son absence '
                'de résultat ne veut pas dire que tout va bien.'
                % (identifiant, type(exc).__name__, exc))]
        if not isinstance(constats, list):
            constats = [faire_constat(identifiant, 'audit-invalide', 'erreur',
                                'L’audit « %s » n’a pas rendu de liste.'
                                % identifiant)]
        for element in constats:
            element.setdefault('audit', identifiant)
        rapport['audits'][identifiant] = constats
        rapport['resume'][identifiant] = resume(constats)
    for cle, attribut in (('poids', 'poids'), ('liens', 'comptes_liens'),
                          ('metadonnees', 'metadonnees'),
                          ('validation', 'validation')):
        valeur = getattr(ctx, attribut, None)
        if valeur is not None:
            rapport['donnees'][cle] = valeur
    total = {'erreur': 0, 'avertissement': 0, 'info': 0, 'ok': 0}
    for compte in rapport['resume'].values():
        for gravite in total:
            total[gravite] += compte.get(gravite, 0)
    rapport['resume']['_global'] = total
    rapport['note_globale'] = max(
        0, 100 - sum(MALUS[g] * total[g] for g in GRAVITES) // max(
            1, len(rapport['resume']) - 1))
    return rapport


def auditer_contenu(contenu, cible='(document)', racine=None, chemin=None,
                    url=None, entetes=None, statut=None, options=None,
                    ressources=None, seulement=None):
    """Point d'entrée pratique : construit le contexte puis audite."""
    ctx = Contexte(cible, contenu, racine=racine, chemin=chemin, url=url,
                   entetes=entetes, statut=statut, options=options,
                   ressources=ressources)
    return auditer_tous(ctx, seulement)


# ============================================================== AUTOCONTRÔLE ==
if __name__ == '__main__':
    import shutil
    import struct
    import sys
    import tempfile

    # Ce contrôle porte sur des DÉFAUTS PLANTÉS : un audit qui rend « rien à
    # signaler » sur une page saine ne prouve pas qu'il fonctionne, il prouve
    # seulement qu'il ne trouve rien. Chaque code attendu correspond à un défaut
    # écrit exprès dans la fixture, et deux contrôles négatifs vérifient que ce
    # qui est correct n'est PAS signalé.
    echecs = []
    controles = [0]

    def verif(condition, titre):
        # Le compteur existe pour que le message final dise combien de contrôles
        # ont réellement été exécutés : un total codé en dur ne suit pas quand on
        # ajoute un contrôle, et annonce alors un chiffre faux.
        controles[0] += 1
        if not condition:
            echecs.append(titre)

    def _png(largeur=8, hauteur=8):
        def morceau(type_, donnees):
            return (struct.pack('>I', len(donnees)) + type_ + donnees
                    + struct.pack('>I', zlib.crc32(type_ + donnees)
                                  & 0xffffffff))
        ihdr = struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0)
        brut = b''.join(b'\x00' + b'\x20\x40\x80' * largeur
                        for _ in range(hauteur))
        return (b'\x89PNG\r\n\x1a\n' + morceau(b'IHDR', ihdr)
                + morceau(b'IDAT', zlib.compress(brut))
                + morceau(b'IEND', b''))

    PAGE_CASSEE = (
        '<html><head><title></title>'
        '<meta name="viewport" content="width=device-width, user-scalable=no">'
        '<style>body { color: #fff; background: #fff }</style>'
        '</head><body>'
        '<div id="a">x</div><div id="a">y</div>'
        '<h1>Un</h1><h3>Trois</h3>'
        '<img src="x.png">'
        '<form><input type="text" placeholder="Nom"></form>'
        '<a href="https://e.fr/" target="_blank">e</a>'
        '<script src="http://insecur.example/a.js"></script>'
        '<script>eval("1"); document.write("<b>")</script>'
        '<button></button>'
        '</body></html>')

    rapport = auditer_contenu(PAGE_CASSEE, cible='cassee.html')
    tous = set()
    for constats in rapport['audits'].values():
        for constat in constats:
            tous.add(constat['code'])
    verif('audit-interrompu' not in tous,
          'un audit s’est interrompu sur la page cassée : %r'
          % [c['message'] for c in sum(rapport['audits'].values(), [])
             if c['code'] == 'audit-interrompu'])
    # Les codes attendus sont ceux que le produit produit pour CES défauts, pas
    # ceux qu'on imaginerait : un <title> présent mais vide donne titre-vide et
    # non titre-absent ; un champ avec placeholder donne placeholder-seul, le
    # diagnostic le plus précis ; un script http:// dans un document sans URL
    # donne script-http, car « contenu mixte » suppose une page servie en HTTPS.
    for attendu in ('doctype-absent', 'charset-absent', 'titre-vide',
                    'description-absente', 'zoom-interdit', 'lang-manquante',
                    'id-duplique', 'saut-de-niveau', 'img-sans-alt',
                    'placeholder-seul', 'bouton-sans-nom', 'formulaire-sans-envoi',
                    'contrast-insuffisant', 'favicon-absent',
                    'noopener-manquant', 'script-http',
                    'sri-manquant', 'eval', 'document-write',
                    'aucune-config-en-tetes', 'referrer-non-defini'):
        verif(attendu in tous, 'le défaut planté « %s » n’est pas trouvé'
              % attendu)
    # Ce qui N'EST pas planté ne doit pas apparaître : un viewport est présent
    # (il interdit seulement le zoom) et la page n'a pas d'URL, donc le contenu
    # mixte n'est pas affirmable ici.
    for interdit in ('viewport-absent', 'contenu-mixte', 'titre-absent',
                     'titre-court', 'champ-sans-etiquette', 'contrast-ok'):
        verif(interdit not in tous,
              'la page cassée est accusée à tort de « %s »' % interdit)

    # Les mêmes défauts, mais sur une page servie en HTTPS : le contenu mixte
    # devient alors affirmable, et c'est la seule façon d'exercer cette branche.
    https = auditer_contenu(PAGE_CASSEE, cible='cassee.html',
                            url='https://exemple.fr/cassee.html',
                            entetes={'content-type': 'text/html; charset=utf-8'})
    codes_https = set()
    for constats in https['audits'].values():
        for trouve in constats:
            codes_https.add(trouve['code'])
    verif('contenu-mixte' in codes_https,
          'un script http:// sur une page https n’est pas signalé comme '
          'contenu mixte')
    verif('charset-absent' not in codes_https
          or 'charset-absent' in tous,
          'le charset annoncé par l’en-tête de réponse n’est pas pris en compte')

    # Un champ sans étiquette ET sans placeholder : c'est l'autre branche.
    sans_rien = auditer_contenu(
        '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
        '<title>Champ</title></head><body><form>'
        '<input type="text" name="x"></form></body></html>',
        cible='champ.html')
    codes_champ = set()
    for constats in sans_rien['audits'].values():
        for trouve in constats:
            codes_champ.add(trouve['code'])
    verif('champ-sans-etiquette' in codes_champ,
          'un champ sans étiquette et sans placeholder n’est pas signalé')
    verif('placeholder-seul' not in codes_champ,
          'placeholder-seul est annoncé alors qu’il n’y a pas de placeholder')
    verif('contrast-insuffisant' in tous or 'contrast-non-verifie' in tous,
          'un texte blanc sur fond blanc n’est pas signalé')
    verif(0 <= rapport['note_globale'] <= 100,
          'la note globale sort de 0 à 100 (%r)' % rapport['note_globale'])
    verif(set(rapport['audits']) == set(AUDIT_IDS),
          'tous les audits ne sont pas rendus')
    verif(rapport['resume']['_global']['erreur'] > 0,
          'une page cassée ne compte aucune erreur')

    # Deux contrôles négatifs : ce qui est correct ne doit PAS être signalé.
    PAGE_SAINES = (
        '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>Une page correctement écrite</title>'
        '<meta name="description" content="'
        'Une description de la page, assez longue pour passer le contrôle de '
        'longueur minimale des moteurs de recherche et assez claire.">'
        '<style>body { color: #111; background: #fff }</style>'
        '</head><body><a href="#c">Aller au contenu</a>'
        '<main id="c"><h1>Titre</h1><h2>Sous-titre</h2>'
        '<img src="i.png" alt="Une image" width="8" height="8">'
        '<form><label for="n">Nom</label>'
        '<input id="n" type="text" name="n"></form></main></body></html>')
    rapport = auditer_contenu(PAGE_SAINES, cible='saine.html')
    tous = set()
    for constats in rapport['audits'].values():
        for constat in constats:
            tous.add(constat['code'])
    for interdit in ('doctype-absent', 'charset-absent', 'titre-absent',
                     'viewport-absent', 'description-absente', 'id-duplique',
                     'saut-de-niveau', 'img-sans-alt', 'champ-sans-etiquette',
                     'bouton-sans-nom', 'eval', 'document-write',
                     'evitement-sans-cible', 'img-sans-dimensions',
                     'contrast-insuffisant'):
        verif(interdit not in tous,
              'une page saine est accusée à tort de « %s »' % interdit)
    verif('contrast-ok' in tous, 'un contraste conforme n’est pas confirmé')
    verif(rapport['note_globale'] >= 85,
          'une page saine obtient une note basse (%s)' % rapport['note_globale'])

    # ---------------------------------------------------------------- projet --
    dossier = tempfile.mkdtemp(prefix='ps-devweb-audit-')
    try:
        racine = Path(dossier) / 'site'
        (racine / 'css').mkdir(parents=True)
        (racine / 'img').mkdir(parents=True)
        (racine / 'css' / 'style.css').write_text(
            'body { color: #111; background: #fff }\n'
            '.titre { font-size: 2rem\n'
            '.pied { margin-top: 2rem; }\n', 'utf8')
        (racine / 'app.js').write_text(
            "document.write('<b>x</b>');\neval('1');\n", 'utf8')
        # Le .htaccess est dans le SOUS-DOSSIER du document : c'est là qu'Apache
        # le cherche d'abord. Un audit qui ne regarde que la racine du projet
        # conclurait à tort qu'aucun en-tête n'est déclaré.
        (racine / '.htaccess').write_text(
            '<IfModule mod_headers.c>\n'
            '  Header always set X-Content-Type-Options "nosniff"\n'
            '  Header always set Referrer-Policy "strict-origin-when-cross-origin"\n'
            '</IfModule>\n', 'utf8')
        (racine / 'img' / 'hero.png').write_bytes(_png(8, 8))
        index = racine / 'index.html'
        index.write_text(
            '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width, initial-scale=1">'
            '<title>Projet de contrôle</title>'
            '<link rel="stylesheet" href="css/style.css">'
            '</head><body><h1>Titre</h1>'
            '<img src="img/Hero.png" alt="Casse différente">'
            '<img src="manquant.png" alt="Absent">'
            '<img src="img/hero.png" alt="Présent" width="8" height="8">'
            '<a href="#inconnu">Ancre</a><a href="page2.html">Autre</a>'
            '<script src="app.js" defer></script>'
            '</body></html>', 'utf8')
        rapport = auditer_contenu(index.read_text('utf8'), cible='index.html',
                                  racine=Path(dossier), chemin=index)
        tous = {}
        for nom, constats in rapport['audits'].items():
            for constat in constats:
                tous.setdefault(constat['code'], []).append(constat)
        verif('audit-interrompu' not in tous,
              'un audit s’est interrompu sur le projet : %r'
              % [c['message'] for c in tous.get('audit-interrompu', [])])
        for attendu in ('casse-differente', 'fichier-introuvable',
                        'fragment-casse', 'css-accolade-ouverte', 'eval',
                        'document-write'):
            verif(attendu in tous, 'le projet ne révèle pas « %s »' % attendu)
        # L'erreur de la FEUILLE LIÉE doit la nommer et ne pas porter une ligne
        # du document : ce numéro pointerait dans le mauvais fichier.
        verif(tous['css-accolade-ouverte']
              and 'css/style.css' in tous['css-accolade-ouverte'][0]['message']
              and tous['css-accolade-ouverte'][0]['ligne'] is None,
              'l’erreur CSS ne nomme pas la feuille liée (%r)'
              % tous['css-accolade-ouverte'][0]['message'][:120])
        verif(tous['eval'] and 'app.js' in tous['eval'][0]['message'],
              'un motif trouvé dans un script externe ne cite pas ce script')
        verif('en-tete-declare' in tous
              and any('referrer-policy' in c['message'].lower()
                      for c in tous['en-tete-declare']),
              'le .htaccess du sous-dossier n’est pas lu')
        verif('referrer-non-defini' not in tous,
              'une règle contredit le .htaccess trouvé')
        poids = rapport['donnees']['poids']
        verif(poids['transfere'] <= poids['total'],
              'le poids transféré (%s) dépasse le total (%s) : gzip gonfle les '
              'petits fichiers, il ne faut pas le compter en dessous du seuil'
              % (poids['transfere'], poids['total']))
        verif(poids['total'] > len(index.read_bytes()),
              'le poids total ignore les ressources locales')
        verif(len(tous.get('img-sans-dimensions', [])) == 1,
              'les images sans dimensions produisent %s constats au lieu d’un '
              'seul regroupé' % len(tous.get('img-sans-dimensions', [])))
        verif(tous.get('img-sans-dimensions')
              and '2 image(s)' in tous['img-sans-dimensions'][0]['message'],
              'le constat regroupé ne dit pas combien d’images sont concernées')
        # Un audit partiel ne rend que ce qui est demandé.
        partiel = auditer_contenu(index.read_text('utf8'), cible='index.html',
                                  racine=Path(dossier), chemin=index,
                                  seulement=['liens'])
        verif(set(partiel['audits']) == {'liens'},
              'seulement=[…] ne limite pas les audits (%r)'
              % sorted(partiel['audits']))

        # La garde « audit-interrompu » : une panne dans un audit doit être
        # NOMMÉE, pas produire une section absente qui se lirait comme
        # « rien à signaler ».
        def _panne(ctx):
            raise RuntimeError('panne provoquée pour le contrôle')

        original = audit_poids
        globals()['audit_poids'] = _panne
        try:
            defaillant = auditer_contenu(PAGE_SAINES, cible='saine.html')
        finally:
            globals()['audit_poids'] = original

        def _codes(rapport):
            sortie = set()
            for constats in rapport['audits'].values():
                for constat in constats:
                    sortie.add(constat['code'])
            return sortie

        verif('audit-interrompu' in _codes(defaillant),
              'une panne d’audit ne produit aucun constat d’interruption')
        verif(any('panne provoquée' in c['message']
                  for c in defaillant['audits']['poids']),
              'le constat d’interruption ne nomme pas la cause')
        verif(set(defaillant['audits']) == set(AUDIT_IDS),
              'l’audit en panne disparaît du rapport au lieu d’être nommé')
    finally:
        shutil.rmtree(dossier, ignore_errors=True)

    if echecs:
        for echec in echecs:
            print('ÉCHEC :', echec)
        sys.exit(1)
    print('devweb_audits : autocontrôle OK (%d contrôles sur deux fixtures, '
          'dont une panne d’audit provoquée)' % controles[0])
