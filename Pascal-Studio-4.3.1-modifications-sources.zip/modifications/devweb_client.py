"""Client HTTP du panneau dev web.

Un client HTTP de développement n'a pas les mêmes exigences qu'un client de
production. Trois arbitraires sont donc assumés et dits, pas cachés :

  * la chaîne de redirections est CONSERVÉE. Suivre silencieusement un 301 fait
    perdre l'information la plus utile d'un diagnostic : c'est souvent la
    redirection elle-même qui est le problème (http vers https, slash final,
    domaine puni). Chaque étape est donc rendue dans `chaine`.
  * les erreurs ne lèvent JAMAIS. `requeter` rend un dictionnaire avec un champ
    `erreur` en français. Un client qui lève oblige l'appelant à connaître les
    douze exceptions d'urllib ; un client qui rend une raison lisible permet au
    panneau d'afficher autre chose qu'une trace de pile.
  * un identifiant dans l'URL est MASQUÉ dans le résultat. `http://user:mot2passe@hôte`
    est accepté (c'est pratique contre une API locale), mais le mot de passe ne
    doit pas se retrouver copié dans le journal du panneau, ni dans un rapport
    d'audit, ni dans un presse-papiers.

Le trafic sortant n'est jamais déclenché à l'insu de l'utilisateur : c'est
l'appelant qui décide. L'audit des liens, par exemple, ne contacte une adresse
distante que si l'option explicite est cochée.
"""

import base64
import gzip
import http.client
import json
import re
import socket
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

METHODES = ('GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS')
SCHEMAS = ('http://', 'https://')

DEFAUT_DELAI = 15.0
DEFAUT_OCTETS = 2_000_000
DEFAUT_REDIRECTIONS = 5
MAX_CORPS_TEXTE = 400_000          # ce que le panneau reçoit en clair
MAX_ENTETES = 200

ENTETES_PAR_DEFAUT = {
    'User-Agent': 'Pascal-Studio/4.0 (client HTTP de développement)',
    'Accept': '*/*',
    'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.6',
    'Connection': 'close',
}


def _masquer(url):
    """Retire l'identifiant et le mot de passe d'une URL, sans rien changer d'autre."""
    try:
        parties = urllib.parse.urlsplit(url)
    except ValueError:
        return url
    if not parties.username and not parties.password:
        return url
    hote = parties.hostname or ''
    if parties.port:
        hote = '%s:%d' % (hote, parties.port)
    return urllib.parse.urlunsplit(
        (parties.scheme, hote, parties.path, parties.query, parties.fragment))


def _verifier_url(url):
    """(adresse propre, raison du refus). Un refus est une raison, pas une exception."""
    if not isinstance(url, str) or not url.strip():
        return None, 'Aucune adresse fournie.'
    adresse = url.strip()
    if len(adresse) > 4000:
        return None, ('Adresse trop longue (%d caractères) : elle est refusée '
                      'telle quelle plutôt que tronquée, car une adresse '
                      'tronquée pointe ailleurs.' % len(adresse))
    if any(c in adresse for c in '\r\n\t'):
        return None, 'L’adresse contient un caractère de contrôle (CR, LF ou tabulation).'
    if ' ' in adresse:
        adresse = urllib.parse.quote(adresse, safe=':/?#[]@!$&\'()*+,;=%')
    if not adresse.lower().startswith(SCHEMAS):
        if '://' in adresse:
            return None, ('Le schéma « %s » n’est pas accepté : le client ne '
                          'parle que HTTP et HTTPS. file:, ftp:, data: et les '
                          'autres sont refusés.' % adresse.split('://')[0])
        return None, ('Adresse sans schéma : écrivez http:// ou https:// '
                      'devant. Une adresse nue n’est pas devinée, pour ne pas '
                      'ouvrir autre chose que ce que vous voulez.')
    try:
        parties = urllib.parse.urlsplit(adresse)
    except ValueError as exc:
        return None, 'Adresse impossible à analyser : %s' % exc
    if not parties.hostname:
        return None, 'Adresse sans nom d’hôte.'
    if re.search(r'[\x00-\x20\x7f]', parties.hostname):
        return None, 'Nom d’hôte contenant un caractère interdit.'
    return adresse, ''


def _verifier_entetes(entetes):
    """(en-têtes propres, raison du refus).

    Un en-tête contenant un retour à la ligne permet d'ajouter des en-têtes que
    l'utilisateur n'a pas demandés (injection d'en-tête HTTP) : c'est refusé
    net, pas nettoyé en silence.
    """
    propres = {}
    for cle, valeur in (entetes or {}).items():
        if not isinstance(cle, str) or not isinstance(valeur, str):
            return None, 'Les en-têtes doivent être des paires de textes.'
        if not cle.strip():
            return None, 'Un nom d’en-tête est vide.'
        if not re.fullmatch(r'[!#$%&\'*+\-.^_`|~0-9A-Za-z]+', cle.strip()):
            return None, ('Le nom d’en-tête « %s » contient un caractère '
                          'interdit par la RFC 7230.' % cle)
        if any(c in valeur for c in '\r\n\x00'):
            return None, ('L’en-tête %s contient un retour à la ligne : ce '
                          'serait une injection d’en-tête.' % cle)
        propres[cle.strip()] = valeur
        if len(propres) > MAX_ENTETES:
            return None, 'Trop d’en-têtes (maximum %d).' % MAX_ENTETES
    return propres, ''


class _SansRedirection(urllib.request.HTTPRedirectHandler):
    """Ne suit rien : chaque étape est rendue à l'appelant."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def requeter(url, methode='GET', entetes=None, corps=None, delai=DEFAUT_DELAI,
             suivre=True, redirections_max=DEFAUT_REDIRECTIONS,
             octets_max=DEFAUT_OCTETS, verifier_tls=True, cookies=None):
    """Effectue une requête et rend TOUJOURS un dictionnaire.

    `suivre=False` s'arrête à la première réponse, y compris un 3xx : c'est ce
    que l'audit des liens demande pour voir la redirection elle-même.
    """
    methode = (methode or 'GET').upper()
    resultat = {
        'ok': False, 'url': _masquer(url) if isinstance(url, str) else '',
        'adresse_demandee': _masquer(url) if isinstance(url, str) else '',
        'methode': methode, 'statut': None, 'raison': '', 'entetes': {},
        'corps': '', 'base64': None, 'binaire': False, 'encodage': '',
        'octets': 0, 'tronque': False, 'duree_ms': 0.0, 'chaine': [],
        'erreur': None, 'tls_verifie': bool(verifier_tls),
        'methode_refusee': False, 'redirections': 0,
    }
    if methode not in METHODES:
        resultat['erreur'] = ('Méthode « %s » inconnue. Les méthodes acceptées '
                              'sont : %s.' % (methode, ', '.join(METHODES)))
        return resultat
    adresse, refus = _verifier_url(url)
    if refus:
        resultat['erreur'] = refus
        return resultat
    propres, refus = _verifier_entetes(entetes)
    if refus:
        resultat['erreur'] = refus
        return resultat
    try:
        delai = float(delai)
    except (TypeError, ValueError):
        delai = DEFAUT_DELAI
    delai = max(0.5, min(delai, 120.0))
    try:
        octets_max = int(octets_max)
    except (TypeError, ValueError):
        octets_max = DEFAUT_OCTETS
    octets_max = max(0, min(octets_max, 50_000_000))
    resultat['url'] = _masquer(adresse)

    donnees = None
    if corps is not None and methode not in ('GET', 'HEAD'):
        if isinstance(corps, (bytes, bytearray)):
            donnees = bytes(corps)
        elif isinstance(corps, (dict, list)):
            donnees = json.dumps(corps, ensure_ascii=False).encode('utf8')
            propres.setdefault('Content-Type', 'application/json; charset=utf-8')
        else:
            donnees = str(corps).encode('utf8')

    # Un seul gestionnaire HTTPS, avec le contexte choisi : en avoir deux
    # ferait gagner le dernier sans qu'on sache lequel, et l'option
    # « ne pas vérifier le certificat » deviendrait silencieusement inopérante.
    contexte = ssl.create_default_context()
    if not verifier_tls:
        contexte = ssl._create_unverified_context()
        resultat['tls_verifie'] = False
    ouvreboite = urllib.request.build_opener(
        _SansRedirection(),
        urllib.request.HTTPSHandler(context=contexte))

    courant = adresse
    debut = time.monotonic()
    while True:
        requete = urllib.request.Request(courant, data=donnees, method=methode)
        # Le nom de la variable de boucle et celui passé à add_header DOIVENT
        # être identiques : un « clef » pour un « cle » est un NameError qui
        # n'apparaît qu'à la première requête réelle, jamais à l'import ni à la
        # lecture. C'est la famille de défauts la plus coûteuse de ce projet.
        for clef, valeur in ENTETES_PAR_DEFAUT.items():
            requete.add_header(clef, valeur)
        for clef, valeur in propres.items():
            requete.add_header(clef, valeur)
        if cookies:
            requete.add_header('Cookie', cookies)
        try:
            reponse = ouvreboite.open(requete, timeout=delai)
            statut = getattr(reponse, 'status', None) or reponse.getcode()
            # Les en-têtes sont normalisés DÈS la réception, à partir de la
            # liste des paires : passer par un dictionnaire ici écraserait les
            # homonymes, et deux Set-Cookie n'en laisseraient voir qu'un.
            # L'audit de sécurité déclarerait alors conforme une réponse qui
            # pose un second cookie sans HttpOnly.
            entetes_recus = _normaliser(list(reponse.headers.items()))
            brut, coupe = _lire(reponse, octets_max)
            resultat['tronque'] = coupe
            reponse.close()
        except urllib.error.HTTPError as exc:
            # Une réponse 4xx/5xx EST une réponse : c'est même souvent ce qu'on
            # vient chercher. Elle n'est donc pas traitée comme une erreur.
            statut = exc.code
            entetes_recus = _normaliser(list(exc.headers.items())) \
                if exc.headers else {}
            try:
                brut, coupe = _lire(exc, octets_max)
                resultat['tronque'] = coupe
            except Exception:
                brut = b''
            exc.close()
        except Exception as exc:
            resultat['duree_ms'] = round((time.monotonic() - debut) * 1000, 1)
            resultat['erreur'] = _expliquer(exc, courant, verifier_tls)
            resultat['chaine'].append({'url': _masquer(courant), 'statut': None,
                                       'raison': resultat['erreur']})
            return resultat

        resultat['chaine'].append({'url': _masquer(courant), 'statut': statut,
                                   'raison': _raison(statut, entetes_recus)})
        emplacement = entetes_recus.get('location')
        if suivre and emplacement and 300 <= int(statut) < 400:
            if len(resultat['chaine']) - 1 >= redirections_max:
                resultat['erreur'] = (
                    'Plus de %d redirections successives : la chaîne est '
                    'interrompue pour éviter une boucle. Dernière étape : %s'
                    % (redirections_max, _masquer(courant)))
                resultat['statut'] = statut
                resultat['raison'] = _raison(statut, entetes_recus)
                resultat['entetes'] = entetes_recus
                resultat['duree_ms'] = round((time.monotonic() - debut) * 1000, 1)
                return resultat
            courant = urllib.parse.urljoin(courant, emplacement)
            resultat['redirections'] += 1
            # Un 303 transforme la requête en GET ; les navigateurs font de
            # même après un 302 sur un POST. Le dire plutôt que de renvoyer le
            # corps d'un POST à une autre adresse.
            if int(statut) == 303 or (int(statut) == 302 and methode == 'POST'):
                methode = 'GET'
                donnees = None
                resultat['methode'] = 'GET'
            continue
        resultat['ok'] = 200 <= int(statut) < 400
        resultat['statut'] = int(statut)
        resultat['raison'] = _raison(statut, entetes_recus)
        resultat['entetes'] = entetes_recus
        resultat['url'] = _masquer(courant)
        _remplir_corps(resultat, brut, entetes_recus)
        if methode == 'HEAD' and int(statut) in (405, 501):
            resultat['methode_refusee'] = True
        break

    resultat['duree_ms'] = round((time.monotonic() - debut) * 1000, 1)
    return resultat


def _lire(reponse, octets_max):
    """(octets lus, lecture coupée). Lit AU PLUS `octets_max` octets.

    Un octet de plus est lu exprès : c'est la seule façon de savoir si la
    réponse était plus longue que la limite, et une réponse tronquée annoncée
    comme complète ferait auditer la moitié d'un document.
    """
    if octets_max == 0:
        return b'', True
    morceaux = []
    lus = 0
    while lus <= octets_max:
        try:
            paquet = reponse.read(min(65536, octets_max - lus + 1))
        except Exception:
            break
        if not paquet:
            break
        morceaux.append(paquet)
        lus += len(paquet)
    brut = b''.join(morceaux)
    if len(brut) > octets_max:
        return brut[:octets_max], True
    return brut, False


def _decompresser(brut, entetes):
    """Décompresse gzip/deflate quand le serveur l'annonce.

    Sans cela, un corps compressé s'affiche en octets illisibles et l'utilisateur
    conclut à un bug du client alors que la réponse est parfaitement normale.
    """
    encodage = (entetes.get('Content-Encoding')
                or entetes.get('content-encoding') or '').lower().strip()
    if not encodage or not brut:
        return brut, ''
    try:
        if 'gzip' in encodage:
            return gzip.decompress(brut), encodage
        if 'deflate' in encodage:
            try:
                return zlib.decompress(brut), encodage
            except zlib.error:
                return zlib.decompress(brut, -zlib.MAX_WBITS), encodage
        if 'br' in encodage:
            try:
                import brotli                                  # type: ignore
                return brotli.decompress(brut), encodage
            except Exception:
                return brut, ''
    except Exception:
        return brut, ''
    return brut, ''


def _remplir_corps(resultat, brut, entetes):
    brut, encodage_contenu = _decompresser(brut, entetes)
    if encodage_contenu:
        resultat['content_encoding'] = encodage_contenu
    resultat['octets'] = len(brut)
    type_contenu = (entetes.get('Content-Type')
                    or entetes.get('content-type') or '')
    encodage = ''
    correspondance = re.search(r'charset\s*=\s*"?([\w\-]+)', type_contenu,
                               re.IGNORECASE)
    if correspondance:
        encodage = correspondance.group(1)
    elif brut[:3] == b'\xef\xbb\xbf':
        encodage = 'utf-8-sig'
    texte = None
    # Un corps est binaire s'il contient un octet nul ou trop d'octets non
    # imprimables : essayer de le décoder en texte produirait du bruit illisible.
    echantillon = brut[:4096]
    non_texte = sum(1 for o in echantillon if o < 9 or (13 < o < 32 and o != 27))
    binaire = bool(echantillon) and (b'\x00' in echantillon
                                     or non_texte * 100 > len(echantillon) * 12)
    if not binaire:
        for candidat in ([encodage] if encodage else []) + ['utf-8', 'latin-1']:
            try:
                texte = brut.decode(candidat)
                encodage = encodage or candidat
                break
            except (UnicodeDecodeError, LookupError):
                continue
    if texte is None:
        binaire = True
    # Une troncature peut venir de DEUX limites distinctes : celle de la lecture
    # (octets_max, déjà notée par _lire) et celle de l'affichage. Les deux sont
    # dites, sinon un corps coupé se lit comme un corps complet.
    resultat['binaire'] = bool(binaire)
    if binaire:
        resultat['base64'] = base64.b64encode(brut[:MAX_CORPS_TEXTE]).decode('ascii')
        resultat['corps'] = ''
        if len(brut) > MAX_CORPS_TEXTE:
            resultat['tronque'] = True
    else:
        if len(texte) > MAX_CORPS_TEXTE:
            resultat['tronque'] = True
        resultat['corps'] = texte[:MAX_CORPS_TEXTE]
        resultat['base64'] = None
    resultat['encodage'] = encodage


def _normaliser(entetes):
    """Noms d'en-tête en minuscules, valeurs multiples conservées en liste.

    Accepte une liste de paires (ce que rend une réponse HTTP) ou un
    dictionnaire. Avec un dictionnaire, deux cookies posés par la même réponse
    n'en laisseraient voir qu'un, et l'audit déclarerait conforme une réponse
    qui ne l'est pas.
    """
    propres = {}
    paires = (entetes.items() if hasattr(entetes, 'items')
              else list(entetes or ()))
    for cle, valeur in paires:
        if not isinstance(cle, str):
            continue
        nom = cle.lower()
        if nom in propres:
            precedent = propres[nom]
            propres[nom] = ([precedent] if isinstance(precedent, str)
                            else list(precedent)) + [str(valeur)]
        else:
            propres[nom] = str(valeur)
    return propres


def _raison(statut, entetes):
    try:
        return http.client.responses.get(int(statut), '')
    except (TypeError, ValueError):
        return ''


def _expliquer(exc, url, verifier_tls):
    """Une raison lisible en français, et ce qu'il faut essayer ensuite."""
    if isinstance(exc, urllib.error.URLError):
        return _expliquer(exc.reason, url, verifier_tls)
    if isinstance(exc, ssl.SSLCertVerificationError):
        return ('Certificat TLS refusé : %s. Pour un serveur local en '
                'certificat auto-signé, relancez avec la vérification '
                'désactivée — en sachant que la connexion n’est alors plus '
                'authentifiée.' % getattr(exc, 'verify_message', exc))
    if isinstance(exc, ssl.SSLError):
        return 'Erreur TLS : %s' % exc
    if isinstance(exc, socket.timeout) or (
            isinstance(exc, TimeoutError)):
        return ('Délai dépassé : le serveur n’a pas répondu dans le temps '
                'imparti. Augmentez le délai, ou vérifiez que le serveur '
                'tourne.')
    if isinstance(exc, ConnectionRefusedError):
        return ('Connexion refusée : rien n’écoute sur ce port. Le serveur '
                'cible n’est pas démarré, ou l’adresse est fausse.')
    if isinstance(exc, socket.gaierror):
        return ('Nom d’hôte introuvable : la résolution DNS a échoué (%s). '
                'Vérifiez l’orthographe du domaine.' % exc.strerror)
    if isinstance(exc, ConnectionResetError):
        return 'Connexion réinitialisée par le serveur en cours de réponse.'
    if isinstance(exc, OSError):
        return 'Erreur réseau : %s' % (exc.strerror or exc)
    if isinstance(exc, http.client.BadStatusLine):
        return 'Réponse illisible : la ligne de statut n’est pas du HTTP.'
    if isinstance(exc, ValueError):
        return 'Adresse ou en-tête invalide : %s' % exc
    return '%s : %s' % (type(exc).__name__, exc)


def apercu(resultat, lignes=20):
    """Un résumé texte de la réponse, pour un affichage ou un journal."""
    if resultat.get('erreur'):
        return '%s %s — ÉCHEC : %s' % (resultat.get('methode'),
                                       resultat.get('url'), resultat['erreur'])
    entetes = resultat.get('entetes') or {}
    sortie = ['%s %s → %s %s (%s, %d ms)'
              % (resultat.get('methode'), resultat.get('url'),
                 resultat.get('statut'), resultat.get('raison'),
                 _taille(resultat.get('octets')), resultat.get('duree_ms', 0))]
    for etape in resultat.get('chaine', [])[:-1]:
        sortie.insert(1, '  ↳ %s %s' % (etape.get('statut'), etape.get('url')))
    for nom in sorted(entetes):
        sortie.append('  %s: %s' % (nom, entetes[nom]))
    corps = resultat.get('corps') or ''
    if corps:
        sortie.append('')
        sortie.extend('  | ' + ligne for ligne in
                      corps.split('\n')[:lignes])
        if len(corps.split('\n')) > lignes:
            sortie.append('  | … (%d lignes au total)'
                          % len(corps.split('\n')))
    elif resultat.get('binaire'):
        sortie.append('  (corps binaire, %s)' % _taille(resultat.get('octets')))
    return '\n'.join(sortie)


def _taille(nombre):
    if not nombre:
        return '0 o'
    for unite, diviseur in (('o', 1), ('Ko', 1024), ('Mo', 1024 ** 2)):
        if nombre < diviseur * 1024 or unite == 'Mo':
            valeur = nombre / diviseur
            return ('%d %s' % (round(valeur), unite) if valeur >= 100
                    else '%s %s' % (('%.1f' % valeur).replace('.', ','), unite))
    return '%d o' % nombre


if __name__ == '__main__':
    # Autocontrôle : il porte sur ce qui peut être vérifié SANS réseau. Tester
    # une requête réelle ici rendrait le banc dépendant de l'état du réseau de
    # la machine, donc intermittent — et un banc intermittent finit par ne plus
    # être lancé.
    import sys

    echecs = []

    def verif(condition, message):
        if not condition:
            echecs.append(message)

    for adresse, attendu in (
            ('ftp://exemple.fr/x', 'schéma'),
            ('file:///etc/passwd', 'schéma'),
            ('data:text/html,x', 'schéma'),
            ('javascript:alert(1)', 'schéma'),
            ('exemple.fr/page', 'schéma'),
            ('', 'Aucune adresse'),
            ('http://' + 'a' * 5000, 'trop longue'),
            ('http://hôte\nX-Injecte: oui', 'contrôle'),
    ):
        reponse = requeter(adresse)
        verif(reponse['erreur'] and attendu.lower() in reponse['erreur'].lower(),
              'refus de %r : %r' % (adresse[:40], reponse['erreur']))
        verif(reponse['statut'] is None, 'aucun statut pour une adresse refusée')

    # Le comportement attendu est « refusé, et aucune requête tentée », pas une
    # formulation particulière : vérifier le mot « injection » ferait échouer le
    # banc dès que le message est amélioré, et c'est le message qui doit pouvoir
    # changer, pas l'exigence.
    reponse = requeter('http://127.0.0.1:1/x', entetes={'X-Mauvais\nNom': 'v'})
    verif(reponse['erreur'] and reponse['statut'] is None
          and not reponse['chaine'],
          'un NOM d’en-tête avec retour à la ligne est refusé sans requête')
    reponse = requeter('http://127.0.0.1:1/x', entetes={'X-Ok': 'a\r\nb: c'})
    verif(reponse['erreur'] and 'injection' in reponse['erreur'].lower()
          and not reponse['chaine'],
          'une VALEUR d’en-tête avec retour à la ligne est refusée comme injection')
    # Un en-tête ordinaire doit être ACCEPTÉ : la requête est tentée (la chaîne
    # contient une étape) et l'erreur éventuelle vient du réseau, pas du refus de
    # l'en-tête. Le port 1 est fermé exprès : ce test porte sur la validation des
    # en-têtes, pas sur la réponse.
    reponse = requeter('http://127.0.0.1:1/x', entetes={'Content-Type': 'text/plain'})
    verif(len(reponse['chaine']) == 1 and 'interdit' not in (reponse['erreur'] or '')
          and 'injection' not in (reponse['erreur'] or ''),
          'un en-tête ordinaire est accepté et la requête est tentée')
    reponse = requeter('http://127.0.0.1:1/x', methode='TRACE')
    verif('TRACE' in (reponse['erreur'] or ''), 'une méthode hors liste est refusée')

    verif(_masquer('https://user:secret@hote.fr/x?a=1')
          == 'https://hote.fr/x?a=1', 'le mot de passe est masqué')
    verif(_masquer('https://hote.fr:8080/x') == 'https://hote.fr:8080/x',
          'une adresse sans identifiant n’est pas modifiée')

    verif(_normaliser({'Set-Cookie': 'a=1', 'set-cookie': 'b=2'})
          == {'set-cookie': ['a=1', 'b=2']},
          'deux en-têtes homonymes sont conservés en liste')

    brut = gzip.compress(b'bonjour ' * 100)
    resultat = {}
    _remplir_corps(resultat, brut, {'Content-Encoding': 'gzip',
                                    'Content-Type': 'text/plain; charset=utf-8'})
    verif(resultat['corps'].startswith('bonjour'), 'un corps gzip est décompressé')
    verif(resultat['binaire'] is False, 'un corps texte n’est pas dit binaire')

    resultat = {}
    _remplir_corps(resultat, b'\x89PNG\r\n\x1a\n' + b'\x00' * 200,
                   {'Content-Type': 'image/png'})
    verif(resultat['binaire'] and resultat['base64'],
          'un corps binaire est rendu en base64, pas en texte illisible')

    resultat = {}
    _remplir_corps(resultat, ('x' * (MAX_CORPS_TEXTE + 5000)).encode(),
                   {'Content-Type': 'text/plain'})
    verif(resultat['tronque'] and len(resultat['corps']) == MAX_CORPS_TEXTE,
          'un corps trop long est tronqué ET le dit')

    verif('rien n’écoute' in _expliquer(ConnectionRefusedError(), 'u', True),
          'une connexion refusée est expliquée')
    verif('DNS' in _expliquer(socket.gaierror(-2, 'Name or service not known'),
                              'u', True),
          'un échec DNS est expliqué')
    verif('auto-signé' in _expliquer(
        ssl.SSLCertVerificationError('certificate verify failed'), 'u', True),
        'un certificat refusé explique la sortie de secours')
    verif('Délai' in _expliquer(TimeoutError(), 'u', True),
          'un dépassement de délai est expliqué')

    depart = time.monotonic()
    reponse = requeter('http://127.0.0.1:1/', delai=1)
    verif(reponse['erreur'] and not reponse['ok'],
          'un port fermé rend une erreur, pas une exception')
    verif(time.monotonic() - depart < 10, 'un port fermé ne fait pas attendre')

    if echecs:
        for echec in echecs:
            print('ÉCHEC :', echec)
        sys.exit(1)
    print('devweb_client : autocontrôle OK (sans réseau)')
