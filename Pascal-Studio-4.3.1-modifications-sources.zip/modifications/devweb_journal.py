"""Journal de la page aperçue : console, erreurs, réseau, navigation.

Le panneau dev web n'a PAS accès à la page qu'il montre. L'aperçu est servi par
web_preview sur une AUTRE origine que l'application (127.0.0.1 et un port tiré
au sort à chaque démarrage) : ni son DOM, ni sa console, ni ses requêtes ne
sont lisibles depuis l'interface, et c'est voulu — cette séparation d'origine
est justement ce qui empêche la page aperçue d'atteindre l'application.

Le journal ne peut donc fonctionner que dans un sens : un script injecté DANS
la page (comme la surcouche de l'inspecteur visuel) capture console.*, les
erreurs non interceptées, les promesses rejetées et les entrées de performance,
puis les envoie à SON propre serveur d'aperçu. Même origine, aucun CORS, aucun
droit nouveau accordé à la page. Le serveur range le tout dans un tampon borné
que l'interface interroge par /api/devweb.

Trois règles découlent de ce montage ; chacune est vérifiée par un banc :

  1. La capture ne doit JAMAIS casser la page. Tout est enveloppé, un échec
     d'envoi est silencieux, et les méthodes de console conservent leur
     comportement d'origine (arguments, this, valeur de retour). Un outil de
     diagnostic qui fait planter la page qu'il diagnostique est pire qu'aucun
     outil.
  2. Le tampon est borné, côté page ET côté serveur. Une page qui boucle en
     console ne doit pas manger la mémoire de l'application, et une page hostile
     ne doit pas pouvoir écrire 100 Mo dans le journal : la taille du corps est
     plafonnée, le nombre d'entrées par lot aussi, et chaque chaîne est
     recoupée côté serveur. Quand le tampon déborde, les entrées les plus
     anciennes tombent et le compteur `perdues` le dit — un journal qui se
     prétend complet alors qu'il a été amputé ferait chercher une erreur là où
     elle a déjà disparu.
  3. La capture commence AVANT le reste de la page. Un script `defer` chargé en
     fin de <body> manquerait précisément ce qu'on cherche le plus souvent :
     les erreurs des scripts d'en-tête et les messages émis pendant
     l'analyse. Le script est donc INLINE et placé en tête de <head>.

Aucune ressource externe : pas de police, pas de CDN, pas d'appel sortant autre
que vers l'origine de l'aperçu.
"""

import collections
import json
import re
import threading
import time

# ------------------------------------------------------------------ bornes ---
MAX_ENTREES = 3000          # tampon circulaire côté serveur
MAX_LOT = 200               # entrées acceptées par envoi de la page
MAX_MESSAGE = 4_000         # longueur d'un message conservé
MAX_PILE = 3_000            # longueur d'une pile d'appel conservée
MAX_CHAMP = 1_000           # longueur d'un champ court (url, ressource…)
MAX_CORPS = 200_000         # octets acceptés pour un envoi (contrôlé aussi
                            # par web_preview avant même de lire le corps)

TYPES = ('console', 'erreur', 'reseau', 'navigation', 'systeme')
NIVEAUX = ('log', 'info', 'warn', 'error', 'debug', 'trace', '')

_verrou = threading.RLock()
_entrees = collections.deque(maxlen=MAX_ENTREES)
_sequence = 0
_perdues = 0


# ------------------------------------------------------------------ tampon ---
def journal_vider(raison=''):
    """Remet le journal à zéro.

    Appelé par web_preview au démarrage d'un aperçu : sans cela, les messages
    de la page précédente resteraient mélangés à ceux de la nouvelle, et un
    utilisateur qui relit son journal après avoir changé de fichier attribuerait
    à la mauvaise page une erreur qui n'est plus d'actualité.
    """
    global _sequence, _perdues
    with _verrou:
        _entrees.clear()
        _sequence = 0
        _perdues = 0
        if raison:
            _ajouter({'type': 'systeme', 'niveau': 'info', 'message': raison})
    return statistiques()


def _ajouter(champs):
    """Ajoute une entrée déjà nettoyée ; compte ce que le tampon laisse tomber.

    Doit être appelé avec le verrou tenu.
    """
    global _sequence, _perdues
    _sequence += 1
    champs['id'] = _sequence
    champs.setdefault('horodatage', time.time() * 1000.0)
    champs.setdefault('page', '')
    if len(_entrees) == MAX_ENTREES:
        _perdues += 1
    _entrees.append(champs)
    return champs


def _nettoyer(brut):
    """Ramène une entrée venue de la page à un schéma connu et borné.

    Rien de ce que produit la page n'est recopié tel quel : une page peut
    envoyer n'importe quel type, n'importe quelle taille, et un champ qui
    n'existe pas dans le schéma. Tout ce qui n'est pas reconnu est jeté, tout
    ce qui est reconnu est recoupé.
    """
    if not isinstance(brut, dict):
        return None
    type_ = brut.get('type')
    if type_ not in TYPES:
        return None
    niveau = brut.get('niveau')
    if niveau not in NIVEAUX:
        niveau = ''
    propre = {'type': type_, 'niveau': niveau}
    for cle in ('message', 'arguments', 'pile', 'url', 'page', 'ressource',
                'initiateur', 'methode'):
        valeur = brut.get(cle)
        if isinstance(valeur, str) and valeur:
            limite = MAX_PILE if cle == 'pile' else (
                MAX_MESSAGE if cle in ('message', 'arguments') else MAX_CHAMP)
            propre[cle] = valeur[:limite]
    for cle in ('ligne', 'colonne', 'statut', 'octets_transferes',
                'octets_bruts', 'octets_decodes'):
        valeur = brut.get(cle)
        if isinstance(valeur, bool) or not isinstance(valeur, (int, float)):
            continue
        propre[cle] = int(valeur)
    for cle in ('duree', 'horodatage', 'ttfb', 'dom_complet', 'charge'):
        valeur = brut.get(cle)
        if isinstance(valeur, bool) or not isinstance(valeur, (int, float)):
            continue
        if valeur != valeur or valeur in (float('inf'), float('-inf')):
            continue
        propre[cle] = float(valeur)
    return propre


def capturer(donnees):
    """Traite un envoi de la page aperçue. Renvoie ce qui a été accepté.

    `donnees` est le corps brut du POST (octets ou texte). Un corps illisible
    n'est pas une exception : la page n'y peut rien et l'aperçu ne doit pas en
    être affecté, donc on répond par un refus expliqué.
    """
    if isinstance(donnees, (bytes, bytearray)):
        if len(donnees) > MAX_CORPS:
            return {'acceptees': 0, 'refusees': 0,
                    'erreur': 'Envoi trop volumineux (%d octets, maximum %d).'
                              % (len(donnees), MAX_CORPS)}
        try:
            donnees = bytes(donnees).decode('utf8')
        except UnicodeDecodeError:
            return {'acceptees': 0, 'refusees': 0,
                    'erreur': 'Envoi illisible : ce n’est pas du texte UTF-8.'}
    if not isinstance(donnees, str):
        return {'acceptees': 0, 'refusees': 0, 'erreur': 'Envoi vide.'}
    if len(donnees) > MAX_CORPS:
        return {'acceptees': 0, 'refusees': 0,
                'erreur': 'Envoi trop volumineux (maximum %d octets).' % MAX_CORPS}
    try:
        charge = json.loads(donnees)
    except (ValueError, RecursionError):
        return {'acceptees': 0, 'refusees': 0, 'erreur': 'JSON invalide.'}
    if not isinstance(charge, dict):
        return {'acceptees': 0, 'refusees': 0, 'erreur': 'Objet JSON attendu.'}
    brut = charge.get('entrees')
    if not isinstance(brut, list):
        return {'acceptees': 0, 'refusees': 0,
                'erreur': 'Le lot doit contenir une liste « entrees ».'}
    acceptees = 0
    refusees = 0
    with _verrou:
        for element in brut[:MAX_LOT]:
            propre = _nettoyer(element)
            if propre is None:
                refusees += 1
                continue
            _ajouter(propre)
            acceptees += 1
        refusees += max(0, len(brut) - MAX_LOT)
    reponse = {'acceptees': acceptees, 'refusees': refusees,
               'total': len(_entrees)}
    if len(brut) > MAX_LOT:
        reponse['erreur'] = ('Lot tronqué à %d entrées : la page en produisait '
                             '%d. Réduisez la fréquence des messages.'
                             % (MAX_LOT, len(brut)))
    return reponse


def journal(depuis=0, limite=500):
    """Les entrées dont l'identifiant dépasse `depuis`, dans l'ordre.

    `suivant` est l'identifiant à rappeler pour la prochaine interrogation :
    le panneau sonde sans jamais redemander ce qu'il a déjà, et sans jamais
    rater une entrée arrivée entre deux sondes.
    """
    try:
        depuis = int(depuis or 0)
    except (TypeError, ValueError):
        depuis = 0
    try:
        limite = int(limite or 500)
    except (TypeError, ValueError):
        limite = 500
    limite = max(1, min(limite, MAX_ENTREES))
    with _verrou:
        selection = [dict(e) for e in _entrees if e['id'] > depuis][-limite:]
        suivant = _entrees[-1]['id'] if _entrees else depuis
        perdues, total, sequence = _perdues, len(_entrees), _sequence
    return {'entrees': selection, 'suivant': suivant, 'perdues': perdues,
            'total': total, 'sequence': sequence,
            'capacite': MAX_ENTREES}


def statistiques():
    with _verrou:
        compte = {t: 0 for t in TYPES}
        for entree in _entrees:
            compte[entree['type']] = compte.get(entree['type'], 0) + 1
        return {'total': len(_entrees), 'perdues': _perdues,
                'capacite': MAX_ENTREES, **compte}


def noter(message, niveau='info'):
    """Une entrée produite par l'application elle-même, pas par la page.

    Sert à dire dans le journal ce que le panneau fait : « aperçu démarré »,
    « journal vidé ». Sans cela, un journal vide ne se distingue pas d'un
    journal qui n'a jamais été branché.
    """
    with _verrou:
        return _ajouter({'type': 'systeme', 'niveau': niveau,
                         'message': str(message)[:MAX_MESSAGE]})


# ------------------------------------------------------- script de capture ---
# Le script est écrit en une seule pièce, sans dépendance, et doit rester
# autonome : il est injecté tel quel dans la page aperçue.
SCRIPT_CAPTURE = r"""(function(){
  'use strict';
  if (window.__psDevwebCapture) return;
  window.__psDevwebCapture = true;
  var DESTINATION = '/__ps_devweb_capture';
  var MAX_LOT = 60;
  var DELAI = 700;
  var MAX_MESSAGE = 4000;
  var MAX_PILE = 3000;
  var MAX_VUS = 4000;
  var file = [];
  var minuteur = null;
  var envoi = false;
  var page = '';
  try { page = location.href; } catch (e) { page = ''; }

  function couper(t, n) {
    if (typeof t !== 'string') return '';
    return t.length > n ? t.slice(0, n) + '… [coupé]' : t;
  }

  /* Une valeur de console peut être n'importe quoi : un objet circulaire, un
   * nœud du DOM, une fonction, un symbole. JSON.stringify lève sur les
   * cycles ; sans cette sérialisation, un console.log(objetCirculaire) ferait
   * échouer l'envoi et perdre le message — exactement celui qu'on voulait
   * lire. */
  function serialiser(v, profondeur, vus) {
    if (profondeur === undefined) profondeur = 0;
    if (vus === undefined) vus = [];
    try {
      if (v === null) return 'null';
      if (v === undefined) return 'undefined';
      var t = typeof v;
      if (t === 'string') return profondeur === 0 ? v : JSON.stringify(v);
      if (t === 'number' || t === 'boolean') return String(v);
      if (t === 'bigint') return String(v) + 'n';
      if (t === 'symbol') return v.toString();
      if (t === 'function') return '[function ' + (v.name || 'anonyme') + ']';
      if (v instanceof Error) {
        return (v.name || 'Error') + ': ' + (v.message || '') +
               (v.stack ? '\n' + v.stack : '');
      }
      if (typeof Node !== 'undefined' && v instanceof Node) {
        if (v.nodeType === 1) {
          return '<' + v.tagName.toLowerCase() +
                 (v.id ? ' id="' + v.id + '"' : '') +
                 (v.className && typeof v.className === 'string'
                   ? ' class="' + v.className + '"' : '') + '>';
        }
        if (v.nodeType === 3) return '#text ' + couper(v.nodeValue || '', 80);
        return '#node ' + v.nodeType;
      }
      if (profondeur > 3) return Array.isArray(v) ? '[…]' : '{…}';
      if (vus.indexOf(v) !== -1) return '[circulaire]';
      vus.push(v);
      if (Array.isArray(v)) {
        return '[' + v.slice(0, 20).map(function (x) {
          return serialiser(x, profondeur + 1, vus);
        }).join(', ') + (v.length > 20 ? ', …' + (v.length - 20) : '') + ']';
      }
      var nom = Object.prototype.toString.call(v);
      if (nom !== '[object Object]') {
        try { return JSON.stringify(v) || nom; } catch (e) { return nom; }
      }
      var clefs = Object.keys(v).slice(0, 40);
      return '{' + clefs.map(function (k) {
        var val;
        try { val = serialiser(v[k], profondeur + 1, vus); }
        catch (e) { val = '[illisible]'; }
        return k + ': ' + couper(val, 200);
      }).join(', ') + (Object.keys(v).length > 40 ? ', …' : '') + '}';
    } catch (e) {
      return '[insérialisable]';
    }
  }

  function pousser(champs) {
    try {
      champs.page = page;
      champs.horodatage = Date.now();
      file.push(champs);
      if (file.length > MAX_LOT * 4) file.splice(0, file.length - MAX_LOT * 4);
      programmer();
    } catch (e) { /* jamais d'effet sur la page */ }
  }

  function programmer() {
    if (minuteur !== null) return;
    minuteur = setTimeout(function () {
      minuteur = null;
      vider();
    }, DELAI);
  }

  function moissonner() {
    var lot = file.splice(0, MAX_LOT);
    return lot.length ? lot : null;
  }

  function vider() {
    if (envoi) { programmer(); return; }
    var lot = moissonner();
    if (!lot) return;
    envoi = true;
    try {
      fetch(DESTINATION, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entrees: lot }),
        keepalive: true,
        credentials: 'same-origin'
      }).then(function () {
        envoi = false;
        if (file.length) programmer();
      }, function () {
        /* Un échec d'envoi n'est pas remonté à la page : ce serait l'outil de
         * diagnostic qui pollue la console qu'il observe. */
        envoi = false;
        file.length = 0;
      });
    } catch (e) {
      envoi = false;
      file.length = 0;
    }
  }

  /* --- console -------------------------------------------------------- */
  var NIVEAUX = ['log', 'info', 'warn', 'error', 'debug', 'trace'];
  NIVEAUX.forEach(function (niveau) {
    var origine;
    try { origine = console[niveau]; } catch (e) { return; }
    if (typeof origine !== 'function') return;
    var enveloppe = function () {
      try {
        var args = Array.prototype.slice.call(arguments);
        var premier = args.length ? serialiser(args[0], 0, []) : '';
        var reste = args.slice(1).map(function (a) {
          return serialiser(a, 0, []);
        });
        pousser({
          type: 'console', niveau: niveau,
          message: couper(premier, MAX_MESSAGE),
          arguments: couper(reste.join(' '), MAX_MESSAGE)
        });
      } catch (e) { /* la page passe avant le journal */ }
      return origine.apply(console, arguments);
    };
    try {
      /* Les propriétés natives sont non configurables sur certains moteurs :
       * un échec ici ne doit pas empêcher le reste de la capture. */
      Object.defineProperty(console, niveau, {
        value: enveloppe, writable: true, configurable: true
      });
    } catch (e) {
      try { console[niveau] = enveloppe; } catch (e2) { /* abandon */ }
    }
  });

  /* --- erreurs -------------------------------------------------------- */
  window.addEventListener('error', function (evt) {
    try {
      var cible = evt && evt.target && evt.target !== window ? evt.target : null;
      if (cible) {
        var url = cible.src || cible.href || '';
        if (url && url.indexOf('__ps_devweb') === -1 &&
            url.indexOf('__ps_inspecteur') === -1) {
          pousser({
            type: 'erreur', niveau: 'error',
            message: 'Ressource impossible à charger : ' + cible.tagName,
            url: couper(String(url), 1000),
            ressource: couper(String(url), 1000),
            initiateur: String(cible.tagName).toLowerCase()
          });
        }
        return;
      }
      pousser({
        type: 'erreur', niveau: 'error',
        message: couper(String(evt.message || 'Erreur inconnue'), MAX_MESSAGE),
        url: couper(String(evt.filename || ''), 1000),
        ligne: evt.lineno | 0, colonne: evt.colno | 0,
        pile: couper(evt.error && evt.error.stack
          ? String(evt.error.stack) : '', MAX_PILE)
      });
    } catch (e) { /* rien */ }
  }, true);

  window.addEventListener('unhandledrejection', function (evt) {
    try {
      var raison = evt && evt.reason;
      var texte = raison instanceof Error
        ? (raison.name + ': ' + raison.message)
        : serialiser(raison, 0, []);
      pousser({
        type: 'erreur', niveau: 'error',
        message: couper('Promesse rejetée et non interceptée — ' + texte,
                        MAX_MESSAGE),
        pile: couper(raison && raison.stack ? String(raison.stack) : '', MAX_PILE)
      });
    } catch (e) { /* rien */ }
  });

  /* --- réseau et navigation ------------------------------------------- */
  var vus = {};
  var nbVus = 0;
  function ignorée(url) {
    return !url || url.indexOf('__ps_devweb') !== -1 ||
           url.indexOf('__ps_inspecteur') !== -1;
  }
  function recolter() {
    try {
      if (!window.performance || !performance.getEntriesByType) return;
      var ressources = performance.getEntriesByType('resource');
      for (var i = 0; i < ressources.length; i++) {
        var r = ressources[i];
        var clef = r.name + '|' + Math.round(r.startTime);
        if (vus[clef] || ignorée(r.name)) continue;
        vus[clef] = 1;
        if (++nbVus > MAX_VUS) { vus = {}; nbVus = 0; }
        pousser({
          type: 'reseau', niveau: '',
          ressource: couper(String(r.name), 1000),
          message: couper(String(r.name), 1000),
          initiateur: couper(String(r.initiatorType || ''), 100),
          duree: r.duration || 0,
          statut: (typeof r.responseStatus === 'number' && r.responseStatus)
            ? r.responseStatus : undefined,
          octets_transferes: (typeof r.transferSize === 'number'
            && r.transferSize >= 0) ? r.transferSize : undefined,
          octets_bruts: (typeof r.encodedBodySize === 'number')
            ? r.encodedBodySize : undefined,
          octets_decodes: (typeof r.decodedBodySize === 'number')
            ? r.decodedBodySize : undefined
        });
      }
      var navigations = performance.getEntriesByType('navigation');
      if (navigations && navigations.length && !window.__psDevwebNav) {
        window.__psDevwebNav = true;
        var n = navigations[0];
        pousser({
          type: 'navigation', niveau: 'info',
          message: 'Document chargé en ' + Math.round(n.duration || 0) + ' ms',
          duree: n.duration || 0,
          ttfb: (n.responseStart || 0) - (n.requestStart || 0),
          dom_complet: n.domComplete || 0,
          charge: n.loadEventEnd || 0,
          octets_transferes: (typeof n.transferSize === 'number')
            ? n.transferSize : undefined,
          octets_decodes: (typeof n.decodedBodySize === 'number')
            ? n.decodedBodySize : undefined
        });
      }
    } catch (e) { /* rien */ }
  }
  setInterval(function () { recolter(); if (file.length) vider(); }, DELAI);
  document.addEventListener('DOMContentLoaded', recolter);
  window.addEventListener('load', function () { recolter(); vider(); });
  window.addEventListener('pagehide', function () { recolter(); vider(); });
  recolter();
})();"""

MARQUEUR = '__ps_devweb_capture'

_TETE = re.compile(r'<head(\s[^>]*)?>', re.IGNORECASE)
_HTML = re.compile(r'<html(\s[^>]*)?>', re.IGNORECASE)


def injecter_capture(document):
    """Place le script de capture AU DÉBUT de la page servie.

    L'emplacement n'est pas un détail : en `defer` ou en fin de document, le
    script manquerait les erreurs des scripts d'en-tête, c'est-à-dire celles
    qu'on vient chercher. Il est donc inline, en premier enfant de <head>, ou à
    défaut juste après <html>, ou à défaut en fin de document (une page cassée
    doit malgré tout être journalisée).

    Idempotent : la présence du marqueur suffit à reconnaître une page déjà
    équipée, y compris quand l'aperçu recharge la même page plusieurs fois.
    """
    if isinstance(document, (bytes, bytearray)):
        texte = bytes(document).decode('utf8', 'replace')
        encoder = True
    else:
        texte = document
        encoder = False
    if MARQUEUR in texte:
        return document
    bloc = '<script>%s</script>' % SCRIPT_CAPTURE
    correspondance = _TETE.search(texte)
    if correspondance:
        texte = (texte[:correspondance.end()] + bloc
                 + texte[correspondance.end():])
    else:
        correspondance = _HTML.search(texte)
        if correspondance:
            texte = (texte[:correspondance.end()] + bloc
                     + texte[correspondance.end():])
        else:
            texte = texte + bloc
    return texte.encode('utf8') if encoder else texte


if __name__ == '__main__':
    # Autocontrôle rapide : ce module doit pouvoir être exécuté seul, sans
    # serveur, pour vérifier que le tampon et l'injection se comportent.
    import sys

    def verif(condition, message):
        if not condition:
            print('ÉCHEC :', message)
            return 1
        return 0

    echecs = 0
    journal_vider()
    echecs += verif(statistiques()['total'] == 0,
                    'un vidage sans raison laisse le journal vide')
    journal_vider('Aperçu démarré.')
    echecs += verif(statistiques()['total'] == 1 and statistiques()['systeme'] == 1,
                    'un vidage avec raison la note dans le journal')
    journal_vider()
    lot = json.dumps({'entrees': [
        {'type': 'console', 'niveau': 'log', 'message': 'bonjour'},
        {'type': 'erreur', 'niveau': 'error', 'message': 'boom', 'ligne': 3},
        {'type': 'reseau', 'ressource': 'http://x/a.css', 'duree': 12.5,
         'statut': 200, 'octets_transferes': 900},
        {'type': 'inconnu', 'message': 'rejeté'},
        'pas un objet',
    ]}).encode('utf8')
    reponse = capturer(lot)
    echecs += verif(reponse['acceptees'] == 3, '3 entrées acceptées, pas %d' % reponse['acceptees'])
    echecs += verif(reponse['refusees'] == 2, '2 entrées refusées')
    j = journal()
    echecs += verif(len(j['entrees']) == 3, 'les 3 entrées valides sont journalisées')
    echecs += verif(j['entrees'][1]['ligne'] == 3, 'ligne conservée')
    echecs += verif(j['entrees'][2]['duree'] == 12.5, 'durée conservée')
    echecs += verif(j['entrees'][2]['statut'] == 200, 'statut réseau conservé')
    echecs += verif('message' not in j['entrees'][2] or j['entrees'][2]['type'] == 'reseau',
                    'type réseau conservé')
    echecs += verif(journal(depuis=j['suivant'])['entrees'] == [], 'rien de nouveau après `suivant`')
    document = '<!doctype html><html><head><title>x</title></head><body></body></html>'
    une = injecter_capture(document)
    echecs += verif(une.index(MARQUEUR) < une.index('<title>'), 'script placé avant le titre')
    echecs += verif(injecter_capture(une) == une, 'injection idempotente')
    echecs += verif('</script' not in SCRIPT_CAPTURE.lower(),
                    'le script ne contient pas de </script qui fermerait l’injection')
    echecs += verif(capturer(b'{' )['erreur'], 'JSON invalide refusé sans exception')
    echecs += verif(capturer('x' * (MAX_CORPS + 1))['erreur'], 'corps trop grand refusé')
    echecs += verif(capturer(json.dumps({'entrees': [{'type': 'console', 'message': 'm' * (MAX_MESSAGE + 500)}]}))
                    ['acceptees'] == 1, 'message long accepté')
    echecs += verif(len(journal()['entrees'][-1]['message']) == MAX_MESSAGE,
                    'message recoupé à la borne serveur')
    journal_vider()
    for i in range(MAX_ENTREES + 10):
        _ajouter({'type': 'console', 'niveau': 'log', 'message': str(i)})
    stats = statistiques()
    echecs += verif(stats['total'] == MAX_ENTREES, 'tampon borné')
    echecs += verif(stats['perdues'] == 10, 'entrées perdues comptées')
    echecs += verif(journal(limite=MAX_ENTREES)['entrees'][0]['message'] == '10',
                    'les plus anciennes tombent, les récentes restent')
    echecs += verif(len(journal()['entrees']) == 500,
                    'une interrogation ordinaire est bornée à 500 entrées')
    print('devweb_journal : %s' % ('ÉCHECS %d' % echecs if echecs else 'autocontrôle OK'))
    sys.exit(1 if echecs else 0)
