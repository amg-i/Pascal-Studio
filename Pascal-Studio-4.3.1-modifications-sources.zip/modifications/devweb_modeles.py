"""Générateurs et extraits du panneau dev web.

Deux familles, et la différence est utile à garder en tête :

  * un GÉNÉRATEUR produit un FICHIER à partir de quelques paramètres, avec des
    valeurs par défaut sensées et la liste de ce qui a été laissé par défaut —
    parce qu'un fichier généré dont on ne sait pas quelles parties sont à
    personnaliser finit publié tel quel ;
  * un EXTRAIT est un morceau de code à copier, sans paramètre : c'est la
    réponse courte à « comment on centre une div », « comment on fait un fetch
    propre », « comment on déclare un skip link ».

Les modèles sont remplis par substitution de `{{cle}}`, JAMAIS par str.format :
une feuille de style ou un script contient des accolades littérales partout, et
.format() y lève une KeyError sur le premier bloc CSS. C'est une erreur déjà
rencontrée dans ce projet ; le doublement d'accolades n'est pas une convention
de formatage ici, c'est la marque du remplacement.

Aucun générateur n'écrit sur le disque : ils rendent du texte. C'est
l'utilisateur qui décide d'enregistrer, et l'interface le propose.
"""

import base64
import hashlib
import json
import re
import urllib.parse

VERSION = '4.0.0'


def remplir(modele, **champs):
    """Remplace {{cle}} par la valeur, sans toucher aux autres accolades."""
    sortie = modele
    for cle, valeur in champs.items():
        sortie = sortie.replace('{{%s}}' % cle, '' if valeur is None else str(valeur))
    restes = re.findall(r'\{\{(\w+)\}\}', sortie)
    if restes:
        # Une clef non fournie laisserait « {{titre}} » littéral dans le fichier
        # généré. Mieux vaut le dire que de livrer un modèle à moitié rempli.
        raise KeyError('Paramètres manquants pour ce modèle : %s'
                       % ', '.join(sorted(set(restes))))
    return sortie


def _oui(valeur):
    if isinstance(valeur, bool):
        return valeur
    return str(valeur or '').strip().lower() in ('1', 'oui', 'true', 'vrai', 'on')


def _liste(valeur, separateurs=(',\n;')):
    if isinstance(valeur, (list, tuple)):
        return [str(x).strip() for x in valeur if str(x).strip()]
    texte = str(valeur or '')
    motif = '[' + re.escape(separateurs) + ']'
    return [x.strip() for x in re.split(motif, texte) if x.strip()]


def _url(valeur, defaut=''):
    valeur = (valeur or '').strip()
    if not valeur:
        return defaut
    if not re.match(r'^https?://', valeur):
        return 'https://' + valeur
    return valeur


def _slug(valeur):
    sortie = re.sub(r'[^a-z0-9]+', '-', (valeur or '').lower()).strip('-')
    return sortie or 'page'


def _absolue(cible, base=''):
    """Rend une adresse absolue à partir d'une base, sans deviner un domaine.

    Un générateur qui complète une adresse relative en y collant « https:// »
    produit « https:///boutique » : une adresse qui ne pointe nulle part et qui
    est reprise telle quelle par les moteurs. Trois cas seulement : l'adresse a
    déjà un schéma, une base permet de la joindre, ou elle est rendue inchangée
    et l'appelant doit le dire.
    """
    cible = (cible or '').strip()
    if not cible:
        return ''
    if re.match(r'^[a-z][a-z0-9+.-]*:', cible, re.IGNORECASE):
        return cible
    base = (base or '').strip()
    if base:
        return urllib.parse.urljoin(base, cible)
    return cible


def _echapper_html(texte):
    return (str(texte or '').replace('&', '&amp;').replace('<', '&lt;')
            .replace('>', '&gt;').replace('"', '&quot;'))


def _echapper_json_ligne(texte):
    """Échappe pour un JSON qui sera collé dans du HTML (</script> y est mortel)."""
    return json.dumps(str(texte or ''), ensure_ascii=False)[1:-1].replace(
        '</', '<\\/')


# ============================================================ GÉNÉRATEURS ======
PAGE_HTML5 = """<!DOCTYPE html>
<html lang="{{langue}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{titre}}</title>
<meta name="description" content="{{description}}">
<link rel="canonical" href="{{canonique}}">
<meta name="theme-color" content="{{couleur}}">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="/icon-180.png">
<meta property="og:type" content="website">
<meta property="og:title" content="{{titre}}">
<meta property="og:description" content="{{description}}">
<meta property="og:url" content="{{canonique}}">
<meta property="og:image" content="{{image}}">
<meta property="og:locale" content="{{locale}}">
<meta name="twitter:card" content="summary_large_image">
<link rel="stylesheet" href="{{feuille}}">
</head>
<body>
<a class="evitement" href="#contenu">Aller au contenu principal</a>

<header class="entete">
  <div class="conteneur entete-interieur">
    <a class="marque" href="/">{{site}}</a>
    <button class="menu-bouton" type="button" aria-expanded="false" aria-controls="navigation">
      <span class="visually-hidden">Menu</span>
      <span aria-hidden="true">☰</span>
    </button>
    <nav id="navigation" class="navigation" aria-label="Navigation principale">
      <ul>
{{navigation}}
      </ul>
    </nav>
  </div>
</header>

<main id="contenu" class="conteneur">
  <h1>{{titre}}</h1>
  <p class="chapo">{{description}}</p>

  <section aria-labelledby="s1">
    <h2 id="s1">{{section}}</h2>
    <p>Remplacez ce paragraphe. La page est construite pour rester lisible du
    mobile ({{largeur_mobile}} px) à l'écran large, sans feuille de style
    externe autre que celle déclarée ci-dessus.</p>
  </section>
</main>

<footer class="pied">
  <div class="conteneur">
    <p>© {{annee}} {{site}} — <a href="/mentions-legales.html">Mentions légales</a></p>
  </div>
</footer>

<script src="{{script}}" defer></script>
</body>
</html>
"""

FEUILLE_BASE = """/* Feuille de base générée par Pascal Studio {{version}}.
   Elle pose trois choses : une remise à zéro minimale, des variables, et la
   grille de la page. Rien d'autre : c'est un point de départ, pas un thème. */

/* --- remise à zéro minimale ------------------------------------------------ */
*, *::before, *::after { box-sizing: border-box; }
* { margin: 0; }
html { -webkit-text-size-adjust: 100%; }
body {
  min-height: 100vh;
  line-height: 1.6;
  font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color: var(--texte);
  background: var(--fond);
  text-rendering: optimizeLegibility;
}
img, picture, video, canvas, svg { display: block; max-width: 100%; height: auto; }
input, button, textarea, select { font: inherit; color: inherit; }
button { cursor: pointer; }
p, h1, h2, h3, h4 { overflow-wrap: anywhere; }
ul[class], ol[class] { list-style: none; padding: 0; }
a { color: var(--lien); }

/* --- variables ------------------------------------------------------------- */
:root {
  --fond: #ffffff;
  --surface: #f6f6f8;
  --texte: #16161d;
  --texte-doux: #4a4a57;
  --lien: #1f5fd0;
  --bordure: #dcdce4;
  --accent: {{couleur}};
  --rayon: 8px;
  --largeur: {{largeur}}px;
  --espace: clamp(1rem, 2.5vw, 2rem);
}

@media (prefers-color-scheme: dark) {
  :root {
    --fond: #16161d;
    --surface: #1e1e28;
    --texte: #ececf4;
    --texte-doux: #b3b3c2;
    --lien: #8ab4ff;
    --bordure: #33333f;
  }
}

/* --- mise en page ---------------------------------------------------------- */
.conteneur {
  width: min(var(--largeur), 100% - 2 * var(--espace));
  margin-inline: auto;
}
.evitement {
  position: absolute;
  left: -9999px;
  top: 0;
  z-index: 100;
  padding: .6rem 1rem;
  background: var(--accent);
  color: #fff;
}
.evitement:focus { left: 0; }
.visually-hidden {
  position: absolute;
  width: 1px; height: 1px;
  margin: -1px; padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
  border: 0;
}
.entete {
  position: sticky;
  top: 0;
  z-index: 10;
  background: color-mix(in srgb, var(--fond) 88%, transparent);
  backdrop-filter: blur(6px);
  border-bottom: 1px solid var(--bordure);
}
.entete-interieur {
  display: flex;
  align-items: center;
  gap: 1rem;
  min-height: 56px;
}
.marque { font-weight: 700; text-decoration: none; color: var(--texte); }
.navigation { margin-left: auto; }
.navigation ul { display: flex; gap: 1rem; flex-wrap: wrap; }
.navigation a { text-decoration: none; padding: .35rem .1rem; }
.navigation a:hover, .navigation a:focus-visible { text-decoration: underline; }
.menu-bouton {
  display: none;
  margin-left: auto;
  background: none;
  border: 1px solid var(--bordure);
  border-radius: var(--rayon);
  padding: .3rem .55rem;
}
main { padding-block: calc(2 * var(--espace)); }
.chapo { color: var(--texte-doux); font-size: 1.1rem; max-width: 62ch; }
h1 { font-size: clamp(1.8rem, 1.2rem + 2.4vw, 3rem); line-height: 1.15; }
h2 { font-size: clamp(1.3rem, 1.1rem + 1vw, 1.8rem); margin-block: 1.6em .5em; }
section + section { margin-top: calc(2 * var(--espace)); }
.pied {
  margin-top: auto;
  border-top: 1px solid var(--bordure);
  padding-block: var(--espace);
  color: var(--texte-doux);
  font-size: .9rem;
}
:focus-visible { outline: 3px solid var(--accent); outline-offset: 2px; }

/* --- responsive : les points de rupture correspondent aux viewports du
       panneau, pas à des valeurs rondes arbitraires ------------------------ */
@media (max-width: 768px) {
  .menu-bouton { display: block; }
  .navigation[hidden] { display: none; }
  .navigation {
    position: absolute;
    left: 0; right: 0; top: 100%;
    background: var(--fond);
    border-bottom: 1px solid var(--bordure);
    padding: var(--espace);
  }
  .navigation ul { flex-direction: column; gap: .5rem; }
}

@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: .01ms !important;
    scroll-behavior: auto !important;
  }
}
"""

HTACCESS = """# En-têtes de sécurité, compression et cache — Apache (mod_headers, mod_deflate).
# Généré par Pascal Studio {{version}}.
# Ce fichier ne fait rien si mod_headers n'est pas activé :
#   sudo a2enmod headers deflate && sudo systemctl reload apache2

<IfModule mod_headers.c>
{{en_tetes}}
  # Retire la bannière du serveur quand c'est possible.
  Header unset X-Powered-By
</IfModule>

<IfModule mod_deflate.c>
  AddOutputFilterByType DEFLATE text/html text/plain text/css text/xml \\
    application/javascript application/json image/svg+xml application/xml
</IfModule>

<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType text/css "access plus 1 year"
  ExpiresByType application/javascript "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/webp "access plus 1 year"
  ExpiresByType font/woff2 "access plus 1 year"
  # Le HTML ne doit JAMAIS être mis en cache longtemps : c'est lui qui porte
  # les références aux ressources versionnées.
  ExpiresByType text/html "access plus 0 seconds"
</IfModule>

# Force HTTPS si le site est servi en HTTPS.
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{HTTPS} !=on
  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]
</IfModule>

# N'expose pas les fichiers sensibles.
<FilesMatch "(^\\.|\\.(env|ini|log|sql|sqlite|db|bak|old|swp)$)">
  Require all denied
</FilesMatch>

Options -Indexes
"""

NGINX = """# En-têtes de sécurité, compression et cache — nginx.
# Généré par Pascal Studio {{version}}. À placer dans le bloc server{}.

server {
    listen 80;
    server_name {{domaine}};
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name {{domaine}};
    root /var/www/{{racine}};
    index index.html;

    ssl_certificate     /etc/letsencrypt/live/{{domaine}}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/{{domaine}}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

{{en_tetes}}

    # Cache navigateur : les ressources versionnées, pas le HTML.
    location ~* \\.(?:css|js|mjs|woff2?|png|jpe?g|gif|svg|webp|avif|ico)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
        access_log off;
        try_files $uri =404;
    }
    location / {
        add_header Cache-Control "no-cache";
        try_files $uri $uri/ =404;
    }

    gzip on;
    gzip_comp_level 6;
    gzip_min_length 1024;
    gzip_vary on;
    gzip_types text/css application/javascript application/json image/svg+xml
               application/xml text/plain;

    # Fichiers sensibles jamais servis.
    location ~ /\\. { deny all; }
    location ~* \\.(env|ini|log|sql|sqlite|db|bak|old|swp)$ { deny all; }

    error_page 404 /404.html;
}
"""

NETLIFY_HEADERS = """# Fichier _headers (Netlify, Cloudflare Pages accepte le même format).
# Généré par Pascal Studio {{version}}.
# La première ligne est le motif d'URL ; les suivantes sont indentées.

/*
{{en_tetes}}

/assets/*
  Cache-Control: public, max-age=31536000, immutable
"""

ROBOTS = """# robots.txt — généré par Pascal Studio {{version}}
# Un robots.txt n'empêche RIEN : c'est une convention que suivent les robots
# honnêtes. Il ne protège pas un contenu sensible — pour cela, il faut
# l'authentification.

User-agent: *
{{interdictions}}
{{autorisations}}
{{sitemap}}
"""

SITEMAP = """<?xml version="1.0" encoding="UTF-8"?>
<!-- sitemap.xml — généré par Pascal Studio {{version}} -->
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
{{urlset}}
</urlset>
"""

MANIFESTE = """{
  "name": "{{nom}}",
  "short_name": "{{court}}",
  "description": "{{description}}",
  "lang": "{{langue}}",
  "dir": "ltr",
  "start_url": "{{accueil}}",
  "scope": "/",
  "display": "{{affichage}}",
  "orientation": "any",
  "background_color": "{{fond}}",
  "theme_color": "{{couleur}}",
  "icons": [
    { "src": "{{icone}}-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
    { "src": "{{icone}}-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" },
    { "src": "{{icone}}-512-maskable.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ],
  "shortcuts": [
{{raccourcis}}
  ]
}
"""

SERVICE_WORKER = """/* Service worker — généré par Pascal Studio {{version}}.
 *
 * Deux stratégies, et c'est le point important :
 *   - les RESSOURCES (CSS, JS, images, polices) sont mises en cache d'abord :
 *     elles sont versionnées par leur nom, donc immuables ;
 *   - les PAGES passent par le réseau d'abord, avec repli sur le cache : une
 *     page servie depuis un cache périmé affiche du contenu ancien sans que
 *     rien ne le signale, ce qui est pire qu'une page lente.
 *
 * Enregistrer ce fichier ne suffit pas : il faut l'enregistrer depuis la page
 * (voir le bas de ce fichier) et le servir depuis la racine du site pour que sa
 * portée couvre tout.
 */
const VERSION = '{{version_cache}}';
const CACHE_STATIQUE = VERSION + '-statique';
const CACHE_PAGES = VERSION + '-pages';

const PRECACHE = [
{{precache}}
];

self.addEventListener('install', (evenement) => {
  evenement.waitUntil(
    caches.open(CACHE_STATIQUE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (evenement) => {
  evenement.waitUntil(
    caches.keys()
      .then((clefs) => Promise.all(
        clefs.filter((clef) => clef.startsWith('{{version_cache}}') === false)
             .map((clef) => caches.delete(clef))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (evenement) => {
  const requete = evenement.request;
  if (requete.method !== 'GET') return;
  const url = new URL(requete.url);
  if (url.origin !== self.location.origin) return;

  if (requete.mode === 'navigate') {
    evenement.respondWith(
      fetch(requete)
        .then((reponse) => {
          const copie = reponse.clone();
          caches.open(CACHE_PAGES).then((cache) => cache.put(requete, copie));
          return reponse;
        })
        .catch(() => caches.match(requete).then((en_cache) =>
          en_cache || caches.match('{{repli}}')))
    );
    return;
  }

  evenement.respondWith(
    caches.match(requete).then((en_cache) => en_cache || fetch(requete).then(
      (reponse) => {
        if (reponse.ok && (url.pathname.startsWith('/assets/') ||
            /\\.(css|js|mjs|woff2?|png|jpe?g|gif|svg|webp|ico)$/.test(url.pathname))) {
          const copie = reponse.clone();
          caches.open(CACHE_STATIQUE).then((cache) => cache.put(requete, copie));
        }
        return reponse;
      }))
  );
});

/* Enregistrement, à placer dans la page :
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').then(
      (enregistrement) => console.log('SW prêt, portée', enregistrement.scope),
      (erreur) => console.error('SW refusé', erreur));
  });
}
*/
"""

FORMULAIRE = """<!-- Formulaire accessible — généré par Pascal Studio {{version}}.
     Chaque champ a un <label for>, une erreur annoncée par aria-describedby et
     aria-live, et autocomplete renseigné : c'est ce qui permet au navigateur et
     aux gestionnaires de mots de passe de remplir correctement. -->
<form action="{{action}}" method="{{methode}}" novalidate>
  <h2>{{titre}}</h2>

  <div class="champ">
    <label for="nom">Nom et prénom <span aria-hidden="true">*</span></label>
    <input id="nom" name="nom" type="text" required autocomplete="name"
           aria-describedby="nom-aide nom-erreur" maxlength="120">
    <p class="aide" id="nom-aide">Tel qu'il doit apparaître dans la réponse.</p>
    <p class="erreur" id="nom-erreur" hidden></p>
  </div>

  <div class="champ">
    <label for="courriel">Adresse électronique <span aria-hidden="true">*</span></label>
    <input id="courriel" name="courriel" type="email" required autocomplete="email"
           inputmode="email" aria-describedby="courriel-erreur">
    <p class="erreur" id="courriel-erreur" hidden></p>
  </div>

  <div class="champ">
    <label for="telephone">Téléphone</label>
    <input id="telephone" name="telephone" type="tel" autocomplete="tel"
           inputmode="tel" pattern="[0-9+().\\s-]{6,20}"
           aria-describedby="telephone-aide">
    <p class="aide" id="telephone-aide">Facultatif. Indicatif compris.</p>
  </div>

  <fieldset>
    <legend>Motif <span aria-hidden="true">*</span></legend>
    <label><input type="radio" name="motif" value="devis" required> Demande de devis</label>
    <label><input type="radio" name="motif" value="support"> Support technique</label>
    <label><input type="radio" name="motif" value="autre"> Autre</label>
  </fieldset>

  <div class="champ">
    <label for="sujet">Sujet</label>
    <select id="sujet" name="sujet">
      <option value="">— Choisissez —</option>
{{options}}
    </select>
  </div>

  <div class="champ">
    <label for="message">Message <span aria-hidden="true">*</span></label>
    <textarea id="message" name="message" rows="6" required minlength="20"
              maxlength="4000" aria-describedby="message-aide message-erreur"></textarea>
    <p class="aide" id="message-aide">20 caractères minimum, 4000 au plus.</p>
    <p class="erreur" id="message-erreur" hidden></p>
  </div>

  <div class="champ">
    <label>
      <input type="checkbox" name="consentement" required value="oui">
      J'accepte que ces informations soient utilisées pour me répondre.
    </label>
  </div>

  <!-- Un jeton anti-CSRF doit être produit côté serveur ; celui-ci n'est qu'un
       emplacement. -->
  <input type="hidden" name="csrf" value="{{jeton}}">

  <button type="submit">{{bouton}}</button>
  <p role="status" aria-live="polite" class="statut"></p>
</form>

<script>
/* Validation côté client : elle améliore l'expérience, elle ne remplace JAMAIS
   la validation côté serveur. Un formulaire validé seulement ici est un
   formulaire non validé. */
(() => {
  'use strict';
  const formulaire = document.currentScript.closest('form')
    || document.querySelector('form');
  const dire = (champ, texte) => {
    const sortie = document.getElementById(champ.id + '-erreur');
    if (!sortie) return;
    sortie.textContent = texte || '';
    sortie.hidden = !texte;
    champ.setAttribute('aria-invalid', texte ? 'true' : 'false');
  };
  formulaire.addEventListener('submit', (evenement) => {
    let premier = null;
    for (const champ of formulaire.elements) {
      if (!champ.checkValidity || !champ.id) continue;
      if (!champ.checkValidity()) {
        dire(champ, champ.validationMessage);
        premier = premier || champ;
      } else {
        dire(champ, '');
      }
    }
    if (premier) {
      evenement.preventDefault();
      premier.focus();
      premier.scrollIntoView({ block: 'center', behavior: 'smooth' });
    }
  });
  for (const champ of formulaire.elements) {
    if (champ.id) champ.addEventListener('input', () => dire(champ, ''), { once: false });
  }
})();
</script>
"""

GRILLE = """/* Grille responsive — générée par Pascal Studio {{version}}.
   auto-fit + minmax : le nombre de colonnes s'adapte à la largeur disponible
   SANS media query. C'est la façon la plus courte d'obtenir une grille qui ne
   casse à aucune largeur intermédiaire, y compris celles qu'on n'a pas prévues. */

.grille {
  display: grid;
  gap: var(--espace, 1.5rem);
  grid-template-columns: repeat(auto-fit, minmax(min({{{min}}}, 100%), 1fr));
}

/* Variante à nombre de colonnes imposé, qui retombe proprement en mobile. */
.grille-{{colonnes}} {
  display: grid;
  gap: var(--espace, 1.5rem);
  grid-template-columns: repeat({{colonnes}}, minmax(0, 1fr));
}
@media (max-width: 1024px) {
  .grille-{{colonnes}} { grid-template-columns: repeat({{moitie}}, minmax(0, 1fr)); }
}
@media (max-width: 640px) {
  .grille-{{colonnes}} { grid-template-columns: 1fr; }
}

/* Mise en page de page complète : en-tête collant, contenu, pied en bas même
   sur une page courte. */
.page {
  display: grid;
  grid-template-rows: auto 1fr auto;
  min-height: 100vh;
}

/* Deux colonnes qui passent l'une sous l'autre sans media query : min() fait
   tomber la colonne à 100 % dès qu'elle ne tient plus. */
.deux-colonnes {
  display: grid;
  gap: var(--espace, 1.5rem);
  grid-template-columns: min({{colonne}}, 100%) 1fr;
}
@media (max-width: 900px) {
  .deux-colonnes { grid-template-columns: 1fr; }
}

/* Carte : image au ratio imposé, pied de carte poussé en bas. */
.carte {
  display: flex;
  flex-direction: column;
  gap: .6rem;
  border: 1px solid var(--bordure, #ddd);
  border-radius: var(--rayon, 8px);
  overflow: hidden;
  background: var(--surface, #fff);
}
.carte img { aspect-ratio: {{ratio}}; object-fit: cover; width: 100%; }
.carte > :last-child { margin-top: auto; }
"""

IMPRESSION = """/* Feuille d'impression — générée par Pascal Studio {{version}}.
   À lier avec <link rel="stylesheet" href="impression.css" media="print">, ou
   à inclure en fin de feuille principale. */

@page {
  size: A4 portrait;
  margin: 18mm 16mm;
  /* Le numéro de page et le titre dans la marge : c'est ce qui manque le plus
     sur une impression de page web. */
  @bottom-center { content: counter(page) " / " counter(pages); }
}

@media print {
  :root { --texte: #000; --fond: #fff; --lien: #000; }

  body { font-size: 11pt; line-height: 1.45; color: #000; background: #fff; }

  /* Ce qui n'a pas de sens sur papier. */
  .entete, .pied, .navigation, .menu-bouton, .evitement,
  form, .pub, .cookie, video, audio, iframe { display: none !important; }

  main { width: auto; margin: 0; padding: 0; }
  .conteneur { width: auto; max-width: none; }

  a { color: #000; text-decoration: underline; }
  /* L'adresse des liens externes, imprimée après le texte : c'est la seule
     façon de les suivre sur papier. Les ancres internes sont exclues, sinon
     chaque lien de sommaire imprime « #section ». */
  a[href^="http"]::after { content: " (" attr(href) ")"; font-size: 9pt; color: #444; }
  a[href^="#"]::after, a[href^="javascript"]::after { content: ""; }

  img { max-width: 100% !important; }

  /* Éviter les coupures qui rendent un document illisible. */
  h1, h2, h3, h4, caption, figcaption { break-after: avoid-page; }
  p, li, blockquote { orphans: 3; widows: 3; }
  tr, img { break-inside: avoid; }
  thead { display: table-header-group; }   /* l'en-tête se répète à chaque page */

  table { border-collapse: collapse; width: 100%; }
  th, td { border: 1px solid #999; padding: 4pt 6pt; text-align: left; }

  /* Les ombres et les fonds coûtent de l'encre pour rien. */
  * { box-shadow: none !important; text-shadow: none !important; }
}
"""

PAGE_404 = """<!DOCTYPE html>
<html lang="{{langue}}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page introuvable — {{site}}</title>
<meta name="robots" content="noindex">
<style>
  :root { color-scheme: light dark; }
  body { margin:0; min-height:100vh; display:grid; place-items:center;
         font:16px/1.6 system-ui,sans-serif; background:#16161d; color:#ececf4;
         padding:2rem; text-align:center; }
  main { max-width:34rem; }
  h1 { font-size:clamp(2rem,1rem+6vw,4rem); margin:0 0 .4em; line-height:1.1; }
  code { background:#24242f; padding:.1em .4em; border-radius:4px; }
  a { color:#8ab4ff; }
  ul { text-align:left; display:inline-block; padding-left:1.2em; }
  .code { font-size:.9rem; opacity:.7; letter-spacing:.15em; }
</style>
</head>
<body>
<main>
  <p class="code">ERREUR 404</p>
  <h1>Cette page n'existe pas</h1>
  <p>L'adresse <code>{{adresse}}</code> ne correspond à aucune page de
  {{site}}. Elle a peut-être été déplacée ou supprimée.</p>
  <p>Vous pouvez :</p>
  <ul>
    <li><a href="/">revenir à l'accueil</a> ;</li>
    <li><a href="/plan-du-site.html">consulter le plan du site</a> ;</li>
    <li>vérifier l'adresse dans la barre de votre navigateur.</li>
  </ul>
</main>
</body>
</html>
"""

META_SOCIAUX = """<!-- Partage social — généré par Pascal Studio {{version}}.
     og:image doit être une adresse ABSOLUE et faire 1200×630 px pour être
     reprise partout ; en dessous, certains réseaux la refusent. -->
<meta property="og:type" content="{{type}}">
<meta property="og:site_name" content="{{site}}">
<meta property="og:title" content="{{titre}}">
<meta property="og:description" content="{{description}}">
<meta property="og:url" content="{{url}}">
<meta property="og:image" content="{{image}}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{{legende}}">
<meta property="og:locale" content="{{locale}}">

<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{titre}}">
<meta name="twitter:description" content="{{description}}">
<meta name="twitter:image" content="{{image}}">
<meta name="twitter:image:alt" content="{{legende}}">
{{twitter_site}}
"""

FAVICONS = """<!-- Icônes — généré par Pascal Studio {{version}}.
     Un SVG suffit pour les onglets modernes ; le PNG 180 px couvre iOS, le
     192/512 couvre Android et l'installation en application. -->
<link rel="icon" href="{{base}}/favicon.svg" type="image/svg+xml">
<link rel="icon" href="{{base}}/favicon.ico" sizes="32x32">
<link rel="apple-touch-icon" href="{{base}}/icon-180.png">
<link rel="manifest" href="{{base}}/manifest.webmanifest">
<meta name="theme-color" content="{{couleur}}" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="{{couleur_sombre}}" media="(prefers-color-scheme: dark)">
"""

JSONLD_MODELES = {
    'Article': {
        '@context': 'https://schema.org',
        '@type': 'Article',
        'headline': '{{titre}}',
        'description': '{{description}}',
        'image': '{{image}}',
        'datePublished': '{{date}}',
        'dateModified': '{{date}}',
        'author': {'@type': 'Person', 'name': '{{auteur}}'},
        'publisher': {'@type': 'Organization', 'name': '{{site}}',
                      'logo': {'@type': 'ImageObject', 'url': '{{logo}}'}},
        'mainEntityOfPage': '{{url}}',
        'inLanguage': '{{langue}}',
    },
    'LocalBusiness': {
        '@context': 'https://schema.org',
        '@type': '{{sous_type}}',
        'name': '{{site}}',
        'description': '{{description}}',
        'image': '{{image}}',
        'url': '{{url}}',
        'telephone': '{{telephone}}',
        'priceRange': '{{prix}}',
        'address': {
            '@type': 'PostalAddress',
            'streetAddress': '{{rue}}',
            'postalCode': '{{code_postal}}',
            'addressLocality': '{{ville}}',
            'addressCountry': '{{pays}}',
        },
        'geo': {'@type': 'GeoCoordinates', 'latitude': '{{latitude}}',
                'longitude': '{{longitude}}'},
        'openingHoursSpecification': [{
            '@type': 'OpeningHoursSpecification',
            'dayOfWeek': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
            'opens': '{{ouverture}}', 'closes': '{{fermeture}}',
        }],
    },
    'Product': {
        '@context': 'https://schema.org',
        '@type': 'Product',
        'name': '{{titre}}',
        'description': '{{description}}',
        'image': ['{{image}}'],
        'sku': '{{sku}}',
        'brand': {'@type': 'Brand', 'name': '{{site}}'},
        'offers': {
            '@type': 'Offer',
            'url': '{{url}}',
            'priceCurrency': '{{devise}}',
            'price': '{{prix}}',
            'availability': 'https://schema.org/{{disponibilite}}',
            'itemCondition': 'https://schema.org/NewCondition',
        },
    },
    'WebSite': {
        '@context': 'https://schema.org',
        '@type': 'WebSite',
        'name': '{{site}}',
        'url': '{{url}}',
        'inLanguage': '{{langue}}',
        'potentialAction': {
            '@type': 'SearchAction',
            'target': {'@type': 'EntryPoint',
                       'urlTemplate': '{{url}}/recherche?q={search_term_string}'},
            'query-input': 'required name=search_term_string',
        },
    },
    # Ces deux champs sont des LISTES d'objets : les écrire comme des
    # {{placeholders}} texte produirait une chaîne JSON contenant « {{etapes}} »,
    # et _remplir_json lèverait une KeyError sur une clef jamais fournie. La
    # liste est donc posée vide ici et remplie après analyse.
    'BreadcrumbList': {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        'itemListElement': [],
    },
    'FAQPage': {
        '@context': 'https://schema.org',
        '@type': 'FAQPage',
        'mainEntity': [],
    },
}


# ------------------------------------------------------------------ rendus ----
def _rendre_page(parametres):
    titre = (parametres.get('titre') or '').strip() or 'Page sans titre'
    site = (parametres.get('site') or '').strip() or 'Mon site'
    description = (parametres.get('description') or '').strip() or (
        'Description de la page, entre 70 et 160 caractères, qui dit ce '
        'qu\'elle apporte à qui la lit.')
    navigation = _liste(parametres.get('navigation')) or [
        'Accueil|/', 'À propos|/a-propos.html', 'Contact|/contact.html']
    lignes = []
    for entree in navigation:
        libelle, _, cible = entree.partition('|')
        lignes.append('        <li><a href="%s">%s</a></li>'
                      % (_echapper_html(cible.strip() or '/'),
                         _echapper_html(libelle.strip())))
    langue = (parametres.get('langue') or 'fr').strip()
    locale = {'fr': 'fr_FR', 'en': 'en_US', 'es': 'es_ES', 'de': 'de_DE',
              'it': 'it_IT', 'pt': 'pt_BR'}.get(langue.split('-')[0], 'fr_FR')
    import datetime
    notes = []
    if not parametres.get('titre'):
        notes.append('Le titre par défaut est « Page sans titre » : remplacez-le, '
                     'c\'est lui qui apparaît dans l\'onglet et dans les '
                     'résultats de recherche.')
    if not parametres.get('description'):
        notes.append('La description est un texte d\'exemple : remplacez-le.')
    if not parametres.get('canonique'):
        notes.append('L\'adresse canonique doit être l\'adresse ABSOLUE de la '
                     'page ; laissez-la vide pour retirer la balise plutôt que '
                     'de publier une adresse fausse.')
    contenu = remplir(
        PAGE_HTML5,
        langue=langue, titre=_echapper_html(titre),
        description=_echapper_html(description),
        canonique=_url(parametres.get('canonique'), ''),
        couleur=(parametres.get('couleur') or '#1f5fd0').strip(),
        locale=locale,
        image=_url(parametres.get('image'), ''),
        feuille=(parametres.get('feuille') or 'style.css').strip(),
        script=(parametres.get('script') or 'script.js').strip(),
        site=_echapper_html(site),
        navigation='\n'.join(lignes),
        section=_echapper_html((parametres.get('section') or 'Première section').strip()),
        largeur_mobile=320,
        annee=datetime.date.today().year,
    )
    if not parametres.get('canonique'):
        contenu = contenu.replace('<link rel="canonical" href="">\n', '')
        contenu = contenu.replace('<meta property="og:url" content="">\n', '')
    if not parametres.get('image'):
        contenu = contenu.replace('<meta property="og:image" content="">\n', '')
    return contenu, notes


def _csp(parametres):
    """Construit une Content-Security-Policy directive par directive.

    Les directives vides sont omises plutôt que laissées à '*' : une directive
    présente et permissive se lit comme une décision, alors qu'une directive
    absente retombe sur default-src.
    """
    directives = []
    defaut = (parametres.get('default_src') or "'self'").strip()
    directives.append(('default-src', defaut))
    for cle, nom in (('script_src', 'script-src'), ('style_src', 'style-src'),
                     ('img_src', 'img-src'), ('font_src', 'font-src'),
                     ('connect_src', 'connect-src'), ('media_src', 'media-src'),
                     ('object_src', 'object-src'), ('frame_src', 'frame-src'),
                     ('worker_src', 'worker-src'), ('form_action', 'form-action'),
                     ('base_uri', 'base-uri'),
                     ('frame_ancestors', 'frame-ancestors')):
        valeur = (parametres.get(cle) or '').strip()
        if valeur:
            directives.append((nom, valeur))
    if _oui(parametres.get('upgrade')):
        directives.append(('upgrade-insecure-requests', ''))
    rapport = (parametres.get('rapport') or '').strip()
    if rapport:
        directives.append(('report-uri', rapport))
    return '; '.join(('%s %s' % (nom, valeur)).strip() for nom, valeur in directives)


def _rendre_csp(parametres):
    politique = _csp(parametres)
    notes = []
    if "'unsafe-inline'" in politique:
        notes.append("La politique contient 'unsafe-inline' : elle autorise le "
                     "JavaScript et le CSS en ligne, ce qui annule l'essentiel "
                     "de la protection contre une injection. Sortez le code "
                     "dans des fichiers, ou utilisez des nonces.")
    if "'unsafe-eval'" in politique:
        notes.append("La politique contient 'unsafe-eval' : eval() redevient "
                     "possible, et avec lui l'exécution de toute chaîne reçue.")
    if '*' in politique.split():
        notes.append("La politique autorise '*' : toute origine est acceptée, "
                     "ce qui revient à ne rien restreindre.")
    if 'frame-ancestors' not in politique:
        notes.append("frame-ancestors est absent : la page peut être encadrée "
                     "par n'importe quel site. Ajoutez frame-ancestors 'none' "
                     "si elle ne doit jamais l'être.")
    meta = '<meta http-equiv="Content-Security-Policy" content="%s">' % (
        politique.replace('"', '&quot;'))
    contenu = (
        '# Content-Security-Policy générée par Pascal Studio %s\n'
        '#\n'
        '# Testez d\'abord en Content-Security-Policy-Report-Only : la page\n'
        '# continue de fonctionner, et les violations sont signalées sans être\n'
        '# bloquées. Passer directement en mode bloquant casse des sites entiers\n'
        '# le jour de la mise en production.\n'
        '\n'
        '# --- en-tête (Apache, .htaccess) ---------------------------------\n'
        '<IfModule mod_headers.c>\n'
        '  Header always set Content-Security-Policy "%s"\n'
        '</IfModule>\n'
        '\n'
        '# --- en-tête (nginx) ---------------------------------------------\n'
        '#   add_header Content-Security-Policy "%s" always;\n'
        '\n'
        '# --- en-tête (Netlify, fichier _headers) --------------------------\n'
        '#   /*\n'
        '#     Content-Security-Policy: %s\n'
        '\n'
        '# --- balise meta (dépannage seulement) ----------------------------\n'
        '# Une CSP en meta ignore frame-ancestors, report-uri et sandbox :\n'
        '# elle est moins puissante que l\'en-tête.\n'
        '%s\n'
        '\n'
        '# --- politique ---\n'
        '%s\n'
        % (VERSION, _echapper_html(politique), _echapper_html(politique),
           politique, meta, politique))
    return contenu, notes


def _rendre_htaccess(parametres):
    lignes = []
    politique = _csp(parametres) if parametres.get('csp') else ''
    if politique:
        lignes.append('  Header always set Content-Security-Policy "%s"'
                      % politique.replace('"', '\\"'))
    for nom, valeur in (
            ('X-Content-Type-Options', 'nosniff'),
            ('X-Frame-Options', parametres.get('encadrement') or 'DENY'),
            ('Referrer-Policy', parametres.get('referrer')
             or 'strict-origin-when-cross-origin'),
            ('Permissions-Policy', parametres.get('permissions')
             or 'camera=(), microphone=(), geolocation=(), interest-cohort=()')):
        lignes.append('  Header always set %s "%s"' % (nom, valeur))
    if _oui(parametres.get('hsts')):
        lignes.append('  Header always set Strict-Transport-Security '
                      '"max-age=%d; includeSubDomains"'
                      % int(parametres.get('hsts_duree') or 31536000))
    notes = []
    if not politique:
        notes.append('Aucune Content-Security-Policy : le champ « csp » était '
                     'vide. Le générateur « Politique CSP » la construit '
                     'directive par directive.')
    if not _oui(parametres.get('hsts')):
        notes.append('HSTS n\'est pas activé : sans lui, la première visite en '
                     'HTTP reste interceptable. Ne l\'activez que si le site '
                     'est servi en HTTPS partout, y compris les sous-domaines.')
    return remplir(HTACCESS, en_tetes='\n'.join(lignes), version=VERSION), notes


def _rendre_nginx(parametres):
    lignes = []
    politique = _csp(parametres) if parametres.get('csp') else ''
    if politique:
        lignes.append('    add_header Content-Security-Policy "%s" always;'
                      % politique.replace('"', '\\"'))
    for nom, valeur in (
            ('X-Content-Type-Options', 'nosniff'),
            ('X-Frame-Options', parametres.get('encadrement') or 'DENY'),
            ('Referrer-Policy', parametres.get('referrer')
             or 'strict-origin-when-cross-origin'),
            ('Permissions-Policy', parametres.get('permissions')
             or 'camera=(), microphone=(), geolocation=()')):
        lignes.append('    add_header %s "%s" always;' % (nom, valeur))
    if _oui(parametres.get('hsts')):
        lignes.append('    add_header Strict-Transport-Security '
                      '"max-age=%d; includeSubDomains" always;'
                      % int(parametres.get('hsts_duree') or 31536000))
    notes = []
    if not politique:
        notes.append('Aucune Content-Security-Policy : le champ « csp » était vide.')
    notes.append('nginx : un add_header posé dans un bloc location REMPLACE '
                 'ceux du bloc server. Si vous ajoutez des en-têtes dans un '
                 'location, recopiez-y ceux-ci.')
    return remplir(NGINX, en_tetes='\n'.join(lignes), version=VERSION,
                   domaine=(parametres.get('domaine') or 'exemple.fr').strip(),
                   racine=_slug(parametres.get('racine') or 'site')), notes


def _rendre_netlify(parametres):
    lignes = []
    politique = _csp(parametres) if parametres.get('csp') else ''
    if politique:
        lignes.append('  Content-Security-Policy: %s' % politique)
    for nom, valeur in (
            ('X-Content-Type-Options', 'nosniff'),
            ('X-Frame-Options', parametres.get('encadrement') or 'DENY'),
            ('Referrer-Policy', parametres.get('referrer')
             or 'strict-origin-when-cross-origin'),
            ('Permissions-Policy', parametres.get('permissions')
             or 'camera=(), microphone=(), geolocation=()')):
        lignes.append('  %s: %s' % (nom, valeur))
    if _oui(parametres.get('hsts')):
        lignes.append('  Strict-Transport-Security: max-age=%d; includeSubDomains'
                      % int(parametres.get('hsts_duree') or 31536000))
    notes = []
    if not politique:
        notes.append('Aucune Content-Security-Policy : le champ « csp » était vide.')
    return remplir(NETLIFY_HEADERS, en_tetes='\n'.join(lignes),
                   version=VERSION), notes


def _rendre_robots(parametres):
    interdits = _liste(parametres.get('interdire')) or ['/admin/', '/tmp/']
    autorises = _liste(parametres.get('autoriser'))
    site = _url(parametres.get('site'), '')
    lignes = ['Disallow: %s' % x for x in interdits]
    if autorises:
        lignes += ['Allow: %s' % x for x in autorises]
    sitemap = 'Sitemap: %s/sitemap.xml' % site.rstrip('/') if site else \
        '# Sitemap: https://exemple.fr/sitemap.xml   (adresse absolue obligatoire)'
    notes = []
    if not site:
        notes.append('L\'adresse du site n\'est pas renseignée : la ligne '
                     'Sitemap est laissée en commentaire, car elle exige une '
                     'adresse absolue.')
    if any(x.strip() in ('/', '/*') for x in interdits):
        notes.append('Un Disallow: / interdit TOUT le site aux robots qui '
                     'suivent cette convention. Si c\'est voulu, gardez-le ; '
                     'sinon, retirez-le.')
    return remplir(ROBOTS, version=VERSION,
                   interdictions='\n'.join(l for l in lignes
                                           if l.startswith('Disallow')),
                   autorisations='\n'.join(l for l in lignes
                                           if l.startswith('Allow')),
                   sitemap=sitemap), notes


def _rendre_sitemap(parametres):
    adresses = _liste(parametres.get('urls'))
    site = _url(parametres.get('site'), '')
    if not adresses and site:
        adresses = [site.rstrip('/') + '/']
    lignes = []
    import datetime
    date = (parametres.get('date') or '').strip() or datetime.date.today().isoformat()
    frequence = (parametres.get('frequence') or 'weekly').strip()
    priorite = (parametres.get('priorite') or '0.7').strip()
    for adresse in adresses:
        absolue = adresse if re.match(r'^https?://', adresse) else (
            site.rstrip('/') + '/' + adresse.lstrip('/') if site else '')
        if not absolue:
            continue
        lignes.append(
            '  <url>\n    <loc>%s</loc>\n    <lastmod>%s</lastmod>\n'
            '    <changefreq>%s</changefreq>\n    <priority>%s</priority>\n  </url>'
            % (_echapper_html(absolue), _echapper_html(date),
               _echapper_html(frequence), _echapper_html(priorite)))
    notes = []
    if not lignes:
        notes.append('Aucune adresse exploitable : il faut soit une liste '
                     'd\'URL, soit l\'adresse du site pour les rendre absolues.')
    else:
        notes.append('%d adresse(s). Un sitemap ne contient QUE des adresses '
                     'absolues, qui répondent 200, et qui ne sont pas bloquées '
                     'par robots.txt.' % len(lignes))
    return remplir(SITEMAP, version=VERSION, urlset='\n'.join(lignes)), notes


def _rendre_manifeste(parametres):
    raccourcis = _liste(parametres.get('raccourcis'))
    lignes = []
    for entree in raccourcis[:4]:
        nom, _, cible = entree.partition('|')
        lignes.append('    { "name": "%s", "url": "%s", "description": "%s" }%s'
                      % (_echapper_json_ligne(nom.strip()),
                         _echapper_json_ligne((cible.strip() or '/')),
                         _echapper_json_ligne(nom.strip()),
                         ',' if entree != raccourcis[-1] else ''))
    contenu = remplir(
        MANIFESTE,
        nom=_echapper_json_ligne(parametres.get('nom') or 'Mon application'),
        court=_echapper_json_ligne((parametres.get('court')
                                    or (parametres.get('nom') or 'Mon appli'))[:12]),
        description=_echapper_json_ligne(parametres.get('description') or ''),
        langue=(parametres.get('langue') or 'fr').strip(),
        accueil=(parametres.get('accueil') or '/').strip(),
        affichage=(parametres.get('affichage') or 'standalone').strip(),
        fond=(parametres.get('fond') or '#ffffff').strip(),
        couleur=(parametres.get('couleur') or '#1f5fd0').strip(),
        icone=(parametres.get('icone') or '/icones/icon').strip(),
        raccourcis='\n'.join(lignes),
        version=VERSION)
    notes = ['Les icônes 192 px et 512 px doivent EXISTER aux chemins '
             'indiqués : sans elles, l\'installation est refusée.',
             'Le manifeste doit être servi avec le type '
             'application/manifest+json.']
    if not str(parametres.get('nom') or '').strip():
        notes.append('Le nom « Mon application » est une valeur d\'exemple : '
                     'c\'est lui qui s\'affiche sous l\'icône une fois '
                     'l\'application installée.')
    try:
        json.loads(contenu)
    except ValueError as exc:
        notes.append('AVERTISSEMENT : le manifeste produit n\'est pas un JSON '
                     'valide (%s). Corrigez les paramètres contenant des '
                     'guillemets.' % exc)
    return contenu, notes


def _rendre_service_worker(parametres):
    precache = _liste(parametres.get('precache')) or ['/', '/style.css', '/script.js']
    lignes = ['  %s,' % json.dumps(x) for x in precache]
    import datetime
    version = (parametres.get('version') or '').strip() or \
        'v%s' % datetime.date.today().strftime('%Y%m%d')
    notes = ['Chaque changement du fichier DOIT changer la constante VERSION : '
             'c\'est elle qui déclenche la purge des anciens caches.',
             'Le fichier doit être servi depuis la racine du site : sa portée '
             'est limitée au dossier qui le contient.']
    if len(precache) > 30:
        notes.append('%d ressources en précache : l\'installation télécharge '
                     'tout d\'un coup. Ne précachez que ce qui est indispensable '
                     'au premier affichage.' % len(precache))
    # Le modèle porte DEUX clefs : {{version}} (l'en-tête du fichier) et
    # {{version_cache}} (la constante qui déclenche la purge). N'en fournir
    # qu'une laissait « {{version}} » littéral dans le fichier généré — et
    # remplir() lève plutôt que de livrer un modèle à moitié rempli, ce qui est
    # bien le comportement voulu : un fichier généré à moitié rempli se publie.
    return remplir(SERVICE_WORKER, version=VERSION, version_cache=version,
                   precache='\n'.join(lignes),
                   repli=(parametres.get('repli') or '/').strip()), notes


def _rendre_formulaire(parametres):
    options = _liste(parametres.get('options')) or ['Demande générale', 'Devis',
                                                    'Réclamation']
    lignes = ['      <option value="%s">%s</option>' % (_slug(o), _echapper_html(o))
              for o in options]
    notes = ['Le jeton anti-CSRF est un emplacement : il DOIT être produit et '
             'vérifié côté serveur. Un jeton constant écrit dans le HTML ne '
             'protège de rien.',
             'La validation JavaScript n\'est qu\'un confort : le serveur doit '
             'revérifier chaque champ.']
    if (parametres.get('methode') or 'post').lower() == 'get':
        notes.append('method="get" place toutes les saisies dans l\'URL : elles '
                     'se retrouvent dans l\'historique et les journaux du '
                     'serveur. N\'utilisez GET que pour une recherche.')
    return remplir(FORMULAIRE, version=VERSION,
                   action=(parametres.get('action') or '/envoyer').strip(),
                   methode=(parametres.get('methode') or 'post').lower(),
                   titre=_echapper_html(parametres.get('titre') or 'Contactez-nous'),
                   bouton=_echapper_html(parametres.get('bouton') or 'Envoyer'),
                   jeton=_echapper_html(parametres.get('jeton') or 'JETON_A_REMPLACER'),
                   options='\n'.join(lignes)), notes


def _rendre_grille(parametres):
    colonnes = max(1, min(12, int(parametres.get('colonnes') or 3)))
    notes = []
    if colonnes % 2:
        notes.append('%d colonnes : le palier intermédiaire utilise %d '
                     'colonne(s), ce qui laisse une colonne vide sur la '
                     'dernière ligne.' % (colonnes, max(1, colonnes // 2)))
    return remplir(GRILLE, version=VERSION,
                   min=(parametres.get('min') or '280px').strip(),
                   colonnes=colonnes,
                   moitie=max(1, colonnes // 2),
                   colonne=(parametres.get('colonne') or '320px').strip(),
                   ratio=(parametres.get('ratio') or '16 / 9').strip()), notes


def _rendre_jsonld(parametres):
    genre = (parametres.get('genre') or 'Article').strip()
    modele = JSONLD_MODELES.get(genre)
    notes = []
    if modele is None:
        notes.append('Le type « %s » n\'est pas proposé : %s ont été générés à '
                     'la place.' % (genre, 'Article'))
        modele = JSONLD_MODELES['Article']
        genre = 'Article'
    champs = {
        'titre': parametres.get('titre') or 'Titre de la page',
        'description': parametres.get('description') or 'Description courte.',
        'image': _url(parametres.get('image'), 'https://exemple.fr/image.jpg'),
        'date': (parametres.get('date') or '').strip() or _aujourdhui(),
        'auteur': parametres.get('auteur') or 'Nom de l’auteur',
        'site': parametres.get('site') or 'Nom du site',
        'logo': _url(parametres.get('logo'), 'https://exemple.fr/logo.png'),
        'url': _url(parametres.get('url'), 'https://exemple.fr/'),
        'langue': parametres.get('langue') or 'fr',
        'telephone': parametres.get('telephone') or '+33 1 23 45 67 89',
        'rue': parametres.get('rue') or '1 rue de l’Exemple',
        'code_postal': parametres.get('code_postal') or '75001',
        'ville': parametres.get('ville') or 'Paris',
        'pays': parametres.get('pays') or 'FR',
        'latitude': parametres.get('latitude') or '48.8566',
        'longitude': parametres.get('longitude') or '2.3522',
        'ouverture': parametres.get('ouverture') or '09:00',
        'fermeture': parametres.get('fermeture') or '18:00',
        'sku': parametres.get('sku') or 'REF-001',
        'devise': parametres.get('devise') or 'EUR',
        'prix': parametres.get('prix') or '0.00',
        'sous_type': parametres.get('sous_type') or 'LocalBusiness',
    }
    if genre == 'Product':
        champs['prix'] = re.sub(r'[^0-9.,]', '', str(champs['prix'])) or '0.00'
        disponibilite = (parametres.get('disponibilite') or 'InStock').strip()
        if not disponibilite.startswith('http'):
            disponibilite = disponibilite.replace('https://schema.org/', '')
        champs['disponibilite'] = disponibilite
    donnees = json.loads(_remplir_json(modele, champs))
    if genre == 'BreadcrumbList':
        etapes = _liste(parametres.get('etapes')) or ['Accueil|/', 'Section|/section']
        elements = []
        base = champs['url']
        relatives = []
        for position, entree in enumerate(etapes, start=1):
            nom, _, cible = entree.partition('|')
            absolue = _absolue(cible.strip(), base)
            if absolue and not re.match(r'^https?://', absolue):
                relatives.append(absolue)
            elements.append({'@type': 'ListItem', 'position': position,
                             'name': nom.strip(), 'item': absolue})
        if relatives:
            notes.append('Les adresses %s restent relatives : un fil d’Ariane en '
                         'données structurées exige des adresses absolues. '
                         'Renseignez l’adresse du site.'
                         % ', '.join(relatives))
        donnees['itemListElement'] = elements
    if genre == 'FAQPage':
        questions = _liste(parametres.get('questions'))
        if questions:
            donnees['mainEntity'] = [{
                '@type': 'Question',
                'name': q.partition('|')[0].strip(),
                'acceptedAnswer': {'@type': 'Answer',
                                   'text': q.partition('|')[2].strip()
                                           or 'Réponse à compléter.'}}
                for q in questions]
        else:
            donnees['mainEntity'] = [{
                '@type': 'Question', 'name': 'Question à compléter ?',
                'acceptedAnswer': {'@type': 'Answer',
                                   'text': 'Réponse à compléter.'}}]
            notes.append('Aucune question fournie : un exemple a été placé. Le '
                         'format attendu est « Question | Réponse » par ligne.')
    if genre == 'Article' and not parametres.get('url'):
        notes.append('mainEntityOfPage doit être l\'adresse absolue de '
                     'l\'article : c\'est elle que les moteurs vérifient.')
    if genre == 'LocalBusiness':
        notes.append('Les horaires et l\'adresse doivent correspondre à la '
                     'réalité : une donnée structurée fausse est pire '
                     'qu\'absente, elle est reprise telle quelle.')
    # Les champs laissés à leur valeur d\'exemple sont NOMMÉS. Sans cela, un
    # bloc JSON-LD généré contient « exemple.fr », un téléphone et des
    # coordonnées inventées — et il est parfaitement valide : rien ne signale
    # qu\'il faut le compléter, alors qu\'une donnée structurée fausse est
    # reprise telle quelle par les moteurs.
    # La liste est restreinte aux champs QUE CE TYPE utilise : signaler le
    # téléphone et les coordonnées géographiques manquantes sur un Article
    # noierait l'information utile sous quatre avertissements hors sujet.
    exemples = [libelle for champ, libelle in _CHAMPS_EXEMPLES.get(genre, ())
                if not str(parametres.get(champ) or '').strip()]
    if exemples:
        notes.append('Valeurs d\'exemple laissées telles quelles : %s. Elles '
                     'sont valides syntaxiquement, donc rien ne signalera '
                     'qu\'elles sont fausses — remplacez-les avant publication.'
                     % ', '.join(exemples))
    texte = json.dumps(donnees, ensure_ascii=False, indent=2).replace('</', '<\\/')
    contenu = ('<script type="application/ld+json">\n%s\n</script>\n' % texte)
    notes.append('Le bloc est collé dans <head>. Vérifiez-le avec l\'outil de '
                 'test des résultats enrichis avant publication.')
    return contenu, notes


_CHAMPS_EXEMPLES = {
    'Article': (('titre', 'le titre'), ('description', 'la description'),
                ('url', 'l\'adresse de l\'article'), ('image', 'l\'image'),
                ('auteur', 'l\'auteur'), ('logo', 'le logo de l\'éditeur')),
    'LocalBusiness': (('site', 'le nom'), ('description', 'la description'),
                      ('url', 'l\'adresse du site'), ('image', 'l\'image'),
                      ('telephone', 'le téléphone'),
                      ('rue', 'l\'adresse postale'), ('ville', 'la ville'),
                      ('latitude', 'les coordonnées géographiques')),
    'Product': (('titre', 'le nom'), ('description', 'la description'),
                ('url', 'l\'adresse du produit'), ('image', 'l\'image'),
                ('sku', 'la référence'), ('prix', 'le prix')),
    'WebSite': (('site', 'le nom'), ('url', 'l\'adresse du site')),
    'BreadcrumbList': (('url', 'l\'adresse du site, qui sert de base'),),
    'FAQPage': (('questions', 'les questions et réponses'),),
}


def _remplir_json(structure, champs):
    """Remplace {{cle}} dans une structure JSON, puis la rend en texte.

    Passer par le texte puis par json.loads vérifie au passage que le résultat
    est un JSON valide : un générateur qui produit du JSON cassé est pire
    qu'absent, car le bloc entier est rejeté par les moteurs sans message.
    """
    brut = json.dumps(structure, ensure_ascii=False, indent=2)
    for cle, valeur in champs.items():
        brut = brut.replace('{{%s}}' % cle, _echapper_json_ligne(valeur))
    restes = re.findall(r'\{\{(\w+)\}\}', brut)
    if restes:
        raise KeyError('Champs manquants pour ce modèle JSON : %s'
                       % ', '.join(sorted(set(restes))))
    return brut


def _aujourdhui():
    import datetime
    return datetime.date.today().isoformat()


def _rendre_meta_sociaux(parametres):
    titre = _echapper_html(parametres.get('titre') or 'Titre de la page')
    description = _echapper_html(parametres.get('description')
                                 or 'Description de 150 caractères environ.')
    contenu = remplir(
        META_SOCIAUX, version=VERSION,
        type=(parametres.get('type') or 'website').strip(),
        site=_echapper_html(parametres.get('site') or 'Nom du site'),
        titre=titre, description=description,
        url=_url(parametres.get('url'), ''),
        image=_url(parametres.get('image'), ''),
        legende=_echapper_html(parametres.get('legende') or titre),
        locale=(parametres.get('locale') or 'fr_FR').strip(),
        twitter_site=('<meta name="twitter:site" content="@%s">'
                      % _echapper_html(parametres.get('twitter'))
                      if parametres.get('twitter') else
                      '<!-- twitter:site est facultatif : c\'est le compte du '
                      'site, pas celui de l\'auteur. -->'))
    notes = []
    if not parametres.get('url'):
        notes.append('og:url est vide : retirez la balise plutôt que de publier '
                     'une adresse vide, elle serait reprise telle quelle.')
    if not parametres.get('image'):
        notes.append('og:image est vide : sans image, la plupart des réseaux '
                     'affichent un aperçu sans vignette.')
    else:
        notes.append('og:image doit être absolue et faire 1200×630 px.')
    return contenu, notes


def _rendre_favicons(parametres):
    return remplir(FAVICONS, version=VERSION,
                   base=(parametres.get('base') or '').strip(),
                   couleur=(parametres.get('couleur') or '#ffffff').strip(),
                   couleur_sombre=(parametres.get('couleur_sombre')
                                   or '#16161d').strip()), [
        'Le SVG n\'est pas lu par les vieux navigateurs : gardez un favicon.ico '
        'à la racine, il est demandé même s\'il n\'est pas référencé.',
        'theme-color accepte une valeur par schéma de couleur depuis Chrome 93.']


def _rendre_impression(parametres):
    notes = ['Cette feuille ne s\'applique qu\'à l\'impression. Pour la voir, '
             'ouvrez l\'aperçu et choisissez « Imprimer » ou le média print '
             'dans les outils de développement.']
    if parametres.get('masquer'):
        for selecteur in _liste(parametres.get('masquer')):
            notes.append('Le sélecteur %s a été ajouté à la liste masquée.'
                         % selecteur)
    contenu = IMPRESSION.replace('{{version}}', VERSION)
    if parametres.get('masquer'):
        supplement = ', '.join(_liste(parametres.get('masquer')))
        contenu = contenu.replace(
            '.pub, .cookie, video, audio, iframe { display: none !important; }',
            '.pub, .cookie, video, audio, iframe, %s { display: none !important; }'
            % supplement)
    return contenu, notes


def _rendre_404(parametres):
    return remplir(PAGE_404, langue=(parametres.get('langue') or 'fr').strip(),
                   site=_echapper_html(parametres.get('site') or 'ce site'),
                   adresse=_echapper_html(parametres.get('adresse')
                                          or '/page-introuvable')), [
        'Le serveur doit réellement répondre 404 sur cette page : un 200 avec '
        'un message d\'erreur fait indexer une page vide.',
        'nginx : error_page 404 /404.html;  —  Apache : ErrorDocument 404 '
        '/404.html']


def _rendre_sri(parametres):
    """Calcule l'empreinte d'intégrité d'une ressource.

    L'empreinte peut venir d'un fichier local (chemin) ou d'une URL — dans ce
    second cas, le fichier est téléchargé, et l'utilisateur en est prévenu dans
    les notes : un générateur qui va chercher une ressource sur Internet sans le
    dire fait du trafic à l'insu de l'utilisateur.
    """
    import devweb_client
    notes = []
    adresse = (parametres.get('url') or '').strip()
    chemin = (parametres.get('chemin') or '').strip()
    donnees = None
    if chemin:
        try:
            from pathlib import Path
            cible = Path(chemin)
            if cible.is_file():
                donnees = cible.read_bytes()
            else:
                notes.append('Le fichier « %s » est introuvable : aucune '
                             'empreinte n\'a pu être calculée.' % chemin)
        except OSError as exc:
            notes.append('Lecture impossible (%s).' % exc)
    elif adresse:
        if not re.match(r'^https?://', adresse):
            notes.append('Adresse sans schéma : écrivez https:// devant.')
        else:
            notes.append('La ressource a été TÉLÉCHARGÉE pour calculer son '
                         'empreinte : du trafic sortant a eu lieu.')
            resultat = devweb_client.requeter(
                adresse, delai=float(parametres.get('delai') or 15))
            if resultat.get('erreur'):
                notes.append('Téléchargement impossible : %s' % resultat['erreur'])
            else:
                # L'empreinte doit porter sur le corps TEL QUE SERVI, donc avant
                # toute décompression : c'est ce que le navigateur compare.
                notes.append('Réponse %s, %d octets.' % (resultat.get('statut'),
                                                         resultat.get('octets', 0)))
                if resultat.get('content_encoding'):
                    notes.append(
                        'ATTENTION : la réponse était compressée en %s. '
                        'L\'empreinte doit être calculée sur le corps compressé ; '
                        'fournissez plutôt le fichier local.'
                        % resultat['content_encoding'])
                    donnees = None
                elif resultat.get('binaire') or resultat.get('tronque'):
                    notes.append('Le corps n\'a pas pu être lu intégralement en '
                                 'texte : fournissez le fichier local pour une '
                                 'empreinte fiable.')
                else:
                    donnees = resultat['corps'].encode(resultat.get('encodage')
                                                       or 'utf-8', 'replace')
    if donnees is None:
        # Rendre une balise SANS integrity alors que c'est l'empreinte qui était
        # demandée serait une demi-livraison : le fichier collé ressemblerait à
        # un SRI posé. generer() attrape cette exception et rend ok=False avec
        # la raison exacte, notes comprises.
        raison = ' '.join(notes) or (
            'Renseignez un fichier local ou une URL.')
        raise ValueError('Aucune empreinte n’a pu être calculée. %s' % raison)
    algo = (parametres.get('algorithme') or 'sha384').strip().lower()
    if algo not in ('sha256', 'sha384', 'sha512'):
        notes.append('Algorithme « %s » inconnu : sha384 utilisé.' % algo)
        algo = 'sha384'
    empreinte = base64.b64encode(
        hashlib.new(algo, donnees).digest()).decode('ascii')
    integrity = '%s-%s' % (algo, empreinte)
    lignes = ['<!-- Intégrité de sous-ressource calculée par Pascal Studio %s -->'
              % VERSION,
              '<script src="%s"' % _echapper_html(adresse or 'ressource.js'),
              '        integrity="%s"' % integrity,
              '        crossorigin="anonymous"',
              '        defer></script>',
              '',
              '# La même valeur pour un en-tête (utile pour les feuilles) :',
              '#   require-sri-for script;   ou   Link: <%s>; rel=preload; '
              'integrity="%s"' % (adresse or 'ressource.js', integrity)]
    notes.append('crossorigin="anonymous" est OBLIGOIRE avec integrity sur une '
                 'ressource d\'une autre origine : sans lui, le navigateur '
                 'n\'envoie pas la requête en mode CORS et la ressource est '
                 'bloquée.')
    notes.append('Si la ressource change d\'un octet, elle est BLOQUÉE. Pour un '
                 'script mis à jour automatiquement par un CDN, l\'empreinte '
                 'doit être changée à chaque version.')
    return '\n'.join(lignes), notes


def _rendre_feuille_base(parametres):
    return remplir(FEUILLE_BASE, version=VERSION,
                   couleur=(parametres.get('couleur') or '#1f5fd0').strip(),
                   largeur=int(parametres.get('largeur') or 1200)), [
        'color-mix() est pris en charge depuis Chrome 111, Safari 16.2 et '
        'Firefox 113 : prévoyez un repli si vous visez plus ancien.',
        'Les variables sont dans :root — changez-les là, pas règle par règle.']


GENERATEURS = (
    {'id': 'page-html5', 'nom': 'Page HTML5 complète', 'groupe': 'Pages',
     'langage': 'html', 'fichier': 'index.html',
     'description': 'Une page responsive avec en-tête collant, navigation '
                    'accessible, lien d\'évitement, pied de page et toutes les '
                    'balises meta utiles.',
     'parametres': (
         {'nom': 'titre', 'libelle': 'Titre de la page', 'type': 'texte',
          'defaut': '', 'aide': '10 à 60 caractères.'},
         {'nom': 'site', 'libelle': 'Nom du site', 'type': 'texte', 'defaut': ''},
         {'nom': 'description', 'libelle': 'Description', 'type': 'zone',
          'defaut': '', 'aide': '70 à 160 caractères.'},
         {'nom': 'langue', 'libelle': 'Langue', 'type': 'texte', 'defaut': 'fr'},
         {'nom': 'canonique', 'libelle': 'Adresse canonique', 'type': 'url',
          'defaut': '', 'aide': 'Absolue. Vide = balise retirée.'},
         {'nom': 'image', 'libelle': 'Image de partage (og:image)', 'type': 'url',
          'defaut': ''},
         {'nom': 'couleur', 'libelle': 'Couleur d\'accent', 'type': 'couleur',
          'defaut': '#1f5fd0'},
         {'nom': 'navigation', 'libelle': 'Entrées de menu', 'type': 'liste',
          'defaut': 'Accueil|/,À propos|/a-propos.html,Contact|/contact.html',
          'aide': 'Une par ligne : Libellé|adresse'},
         {'nom': 'section', 'libelle': 'Titre de la première section',
          'type': 'texte', 'defaut': 'Première section'},
         {'nom': 'feuille', 'libelle': 'Feuille de style', 'type': 'texte',
          'defaut': 'style.css'},
         {'nom': 'script', 'libelle': 'Script', 'type': 'texte',
          'defaut': 'script.js'},
     ), 'rendre': _rendre_page},

    {'id': 'feuille-base', 'nom': 'Feuille de style de base', 'groupe': 'Pages',
     'langage': 'css', 'fichier': 'style.css',
     'description': 'Remise à zéro minimale, variables de couleur avec mode '
                    'sombre automatique, conteneur fluide, en-tête collant, '
                    'lien d\'évitement, focus visible et respect de '
                    'prefers-reduced-motion.',
     'parametres': (
         {'nom': 'couleur', 'libelle': 'Couleur d\'accent', 'type': 'couleur',
          'defaut': '#1f5fd0'},
         {'nom': 'largeur', 'libelle': 'Largeur maximale (px)', 'type': 'nombre',
          'defaut': '1200'},
     ), 'rendre': _rendre_feuille_base},

    {'id': 'formulaire', 'nom': 'Formulaire accessible', 'groupe': 'Pages',
     'langage': 'html', 'fichier': 'formulaire.html',
     'description': 'Chaque champ a une étiquette, une aide, une erreur annoncée '
                    'aux lecteurs d\'écran, autocomplete et la validation '
                    'JavaScript qui replace le focus sur le premier champ fautif.',
     'parametres': (
         {'nom': 'titre', 'libelle': 'Titre', 'type': 'texte',
          'defaut': 'Contactez-nous'},
         {'nom': 'action', 'libelle': 'Adresse d\'envoi', 'type': 'texte',
          'defaut': '/envoyer'},
         {'nom': 'methode', 'libelle': 'Méthode', 'type': 'choix',
          'defaut': 'post', 'options': ('post', 'get')},
         {'nom': 'options', 'libelle': 'Options du menu déroulant',
          'type': 'liste', 'defaut': 'Demande générale,Devis,Réclamation'},
         {'nom': 'bouton', 'libelle': 'Texte du bouton', 'type': 'texte',
          'defaut': 'Envoyer'},
         {'nom': 'jeton', 'libelle': 'Jeton CSRF (produit par le serveur)',
          'type': 'texte', 'defaut': ''},
     ), 'rendre': _rendre_formulaire},

    {'id': 'grille', 'nom': 'Grille responsive', 'groupe': 'Mise en page',
     'langage': 'css', 'fichier': 'grille.css',
     'description': 'auto-fit + minmax pour une grille qui s\'adapte sans media '
                    'query, plus une grille à nombre de colonnes imposé, une '
                    'page en trois bandes et une carte à ratio fixe.',
     'parametres': (
         {'nom': 'min', 'libelle': 'Largeur minimale d\'une colonne',
          'type': 'texte', 'defaut': '280px'},
         {'nom': 'colonnes', 'libelle': 'Colonnes (variante fixe)',
          'type': 'nombre', 'defaut': '3'},
         {'nom': 'colonne', 'libelle': 'Largeur de la première colonne',
          'type': 'texte', 'defaut': '320px'},
         {'nom': 'ratio', 'libelle': 'Ratio des images de carte', 'type': 'texte',
          'defaut': '16 / 9'},
     ), 'rendre': _rendre_grille},

    {'id': 'impression', 'nom': 'Feuille d\'impression', 'groupe': 'Mise en page',
     'langage': 'css', 'fichier': 'impression.css',
     'description': '@page avec marges et numéros, suppression des éléments de '
                    'navigation, adresse des liens externes imprimée, en-têtes '
                    'de tableau répétés, et coupures de page évitées.',
     'parametres': (
         {'nom': 'masquer', 'libelle': 'Sélecteurs à masquer en plus',
          'type': 'liste', 'defaut': ''},
     ), 'rendre': _rendre_impression},

    {'id': 'page-404', 'nom': 'Page 404', 'groupe': 'Pages', 'langage': 'html',
     'fichier': '404.html',
     'description': 'Une page d\'erreur autonome (style inclus), qui dit ce qui '
                    's\'est passé et propose trois sorties.',
     'parametres': (
         {'nom': 'site', 'libelle': 'Nom du site', 'type': 'texte', 'defaut': ''},
         {'nom': 'langue', 'libelle': 'Langue', 'type': 'texte', 'defaut': 'fr'},
         {'nom': 'adresse', 'libelle': 'Adresse exemple affichée', 'type': 'texte',
          'defaut': '/page-introuvable'},
     ), 'rendre': _rendre_404},

    {'id': 'csp', 'nom': 'Politique CSP', 'groupe': 'Sécurité', 'langage': 'apache',
     'fichier': 'csp.txt',
     'description': 'Construit une Content-Security-Policy directive par '
                    'directive et la donne sous quatre formes : Apache, nginx, '
                    'Netlify et balise meta.',
     'parametres': (
         {'nom': 'default_src', 'libelle': 'default-src', 'type': 'texte',
          'defaut': "'self'"},
         {'nom': 'script_src', 'libelle': 'script-src', 'type': 'texte',
          'defaut': "'self'"},
         {'nom': 'style_src', 'libelle': 'style-src', 'type': 'texte',
          'defaut': "'self'"},
         {'nom': 'img_src', 'libelle': 'img-src', 'type': 'texte',
          'defaut': "'self' data:"},
         {'nom': 'font_src', 'libelle': 'font-src', 'type': 'texte', 'defaut': ''},
         {'nom': 'connect_src', 'libelle': 'connect-src', 'type': 'texte',
          'defaut': ''},
         {'nom': 'frame_ancestors', 'libelle': 'frame-ancestors', 'type': 'texte',
          'defaut': "'none'"},
         {'nom': 'form_action', 'libelle': 'form-action', 'type': 'texte',
          'defaut': "'self'"},
         {'nom': 'base_uri', 'libelle': 'base-uri', 'type': 'texte',
          'defaut': "'self'"},
         {'nom': 'object_src', 'libelle': 'object-src', 'type': 'texte',
          'defaut': "'none'"},
         {'nom': 'upgrade', 'libelle': 'upgrade-insecure-requests',
          'type': 'case', 'defaut': False},
         {'nom': 'rapport', 'libelle': 'report-uri', 'type': 'texte',
          'defaut': ''},
     ), 'rendre': _rendre_csp},

    {'id': 'entetes-htaccess', 'nom': 'En-têtes de sécurité (Apache)',
     'groupe': 'Sécurité', 'langage': 'apache', 'fichier': '.htaccess',
     'description': 'En-têtes de sécurité, compression, cache par type, '
                    'redirection HTTPS et blocage des fichiers sensibles.',
     'parametres': (
         {'nom': 'csp', 'libelle': 'Content-Security-Policy (vide = omise)',
          'type': 'texte', 'defaut': ''},
         {'nom': 'encadrement', 'libelle': 'X-Frame-Options', 'type': 'choix',
          'defaut': 'DENY', 'options': ('DENY', 'SAMEORIGIN')},
         {'nom': 'referrer', 'libelle': 'Referrer-Policy', 'type': 'choix',
          'defaut': 'strict-origin-when-cross-origin',
          'options': ('no-referrer', 'strict-origin-when-cross-origin',
                      'same-origin', 'unsafe-url')},
         {'nom': 'permissions', 'libelle': 'Permissions-Policy', 'type': 'texte',
          'defaut': 'camera=(), microphone=(), geolocation=()'},
         {'nom': 'hsts', 'libelle': 'Activer HSTS', 'type': 'case',
          'defaut': True},
         {'nom': 'hsts_duree', 'libelle': 'Durée HSTS (secondes)',
          'type': 'nombre', 'defaut': '31536000'},
     ), 'rendre': _rendre_htaccess},

    {'id': 'entetes-nginx', 'nom': 'En-têtes de sécurité (nginx)',
     'groupe': 'Sécurité', 'langage': 'nginx', 'fichier': 'site.conf',
     'description': 'Bloc server complet : redirection HTTP vers HTTPS, '
                    'en-têtes, cache différencié HTML/ressources, compression, '
                    'fichiers sensibles bloqués.',
     'parametres': (
         {'nom': 'domaine', 'libelle': 'Nom de domaine', 'type': 'texte',
          'defaut': 'exemple.fr'},
         {'nom': 'racine', 'libelle': 'Dossier web', 'type': 'texte',
          'defaut': 'site'},
         {'nom': 'csp', 'libelle': 'Content-Security-Policy (vide = omise)',
          'type': 'texte', 'defaut': ''},
         {'nom': 'encadrement', 'libelle': 'X-Frame-Options', 'type': 'choix',
          'defaut': 'DENY', 'options': ('DENY', 'SAMEORIGIN')},
         {'nom': 'hsts', 'libelle': 'Activer HSTS', 'type': 'case',
          'defaut': True},
         {'nom': 'hsts_duree', 'libelle': 'Durée HSTS (secondes)',
          'type': 'nombre', 'defaut': '31536000'},
     ), 'rendre': _rendre_nginx},

    {'id': 'entetes-netlify', 'nom': 'En-têtes de sécurité (Netlify)',
     'groupe': 'Sécurité', 'langage': 'text', 'fichier': '_headers',
     'description': 'Le fichier _headers au format Netlify, avec le cache '
                    'immutable pour /assets/.',
     'parametres': (
         {'nom': 'csp', 'libelle': 'Content-Security-Policy (vide = omise)',
          'type': 'texte', 'defaut': ''},
         {'nom': 'encadrement', 'libelle': 'X-Frame-Options', 'type': 'choix',
          'defaut': 'DENY', 'options': ('DENY', 'SAMEORIGIN')},
         {'nom': 'hsts', 'libelle': 'Activer HSTS', 'type': 'case',
          'defaut': True},
     ), 'rendre': _rendre_netlify},

    {'id': 'sri', 'nom': 'Empreinte d\'intégrité (SRI)', 'groupe': 'Sécurité',
     'langage': 'html', 'fichier': 'sri.txt', 'exige_une_entree': True,
     'description': 'Calcule sha256/sha384/sha512 d\'un fichier local ou d\'une '
                    'URL et produit la balise script avec integrity et '
                    'crossorigin.',
     'parametres': (
         {'nom': 'chemin', 'libelle': 'Fichier local', 'type': 'texte',
          'defaut': '', 'aide': 'Chemin absolu ou relatif au projet.'},
         {'nom': 'url', 'libelle': 'ou URL à télécharger', 'type': 'url',
          'defaut': ''},
         {'nom': 'algorithme', 'libelle': 'Algorithme', 'type': 'choix',
          'defaut': 'sha384', 'options': ('sha256', 'sha384', 'sha512')},
         {'nom': 'delai', 'libelle': 'Délai (s)', 'type': 'nombre',
          'defaut': '15'},
     ), 'rendre': _rendre_sri},

    {'id': 'robots', 'nom': 'robots.txt', 'groupe': 'Référencement',
     'langage': 'text', 'fichier': 'robots.txt',
     'description': 'Interdictions, autorisations et ligne Sitemap absolue.',
     'parametres': (
         {'nom': 'site', 'libelle': 'Adresse du site', 'type': 'url',
          'defaut': ''},
         {'nom': 'interdire', 'libelle': 'Chemins interdits', 'type': 'liste',
          'defaut': '/admin/,/tmp/'},
         {'nom': 'autoriser', 'libelle': 'Chemins explicitement autorisés',
          'type': 'liste', 'defaut': ''},
     ), 'rendre': _rendre_robots},

    {'id': 'sitemap', 'nom': 'sitemap.xml', 'groupe': 'Référencement',
     'langage': 'xml', 'fichier': 'sitemap.xml',
     'description': 'Une entrée <url> par adresse, avec lastmod, changefreq et '
                    'priority ; les adresses relatives sont rendues absolues.',
     'parametres': (
         {'nom': 'site', 'libelle': 'Adresse du site', 'type': 'url',
          'defaut': ''},
         {'nom': 'urls', 'libelle': 'Adresses', 'type': 'liste', 'defaut': '',
          'aide': 'Absolues, ou relatives à l\'adresse du site.'},
         {'nom': 'frequence', 'libelle': 'Fréquence', 'type': 'choix',
          'defaut': 'weekly',
          'options': ('always', 'hourly', 'daily', 'weekly', 'monthly',
                      'yearly', 'never')},
         {'nom': 'priorite', 'libelle': 'Priorité', 'type': 'texte',
          'defaut': '0.7'},
         {'nom': 'date', 'libelle': 'Date de modification (AAAA-MM-JJ)',
          'type': 'texte', 'defaut': ''},
     ), 'rendre': _rendre_sitemap},

    {'id': 'meta-sociaux', 'nom': 'Balises de partage', 'groupe': 'Référencement',
     'langage': 'html', 'fichier': 'meta-sociaux.html',
     'description': 'Open Graph complet plus Twitter Card, avec dimensions et '
                    'texte alternatif de l\'image.',
     'parametres': (
         {'nom': 'titre', 'libelle': 'Titre', 'type': 'texte', 'defaut': ''},
         {'nom': 'description', 'libelle': 'Description', 'type': 'zone',
          'defaut': ''},
         {'nom': 'url', 'libelle': 'Adresse absolue', 'type': 'url', 'defaut': ''},
         {'nom': 'image', 'libelle': 'Image (1200×630)', 'type': 'url',
          'defaut': ''},
         {'nom': 'legende', 'libelle': 'Texte alternatif de l\'image',
          'type': 'texte', 'defaut': ''},
         {'nom': 'site', 'libelle': 'Nom du site', 'type': 'texte', 'defaut': ''},
         {'nom': 'type', 'libelle': 'Type', 'type': 'choix', 'defaut': 'website',
          'options': ('website', 'article', 'product', 'profile')},
         {'nom': 'locale', 'libelle': 'Locale', 'type': 'texte',
          'defaut': 'fr_FR'},
         {'nom': 'twitter', 'libelle': 'Compte Twitter (sans @)', 'type': 'texte',
          'defaut': ''},
     ), 'rendre': _rendre_meta_sociaux},

    {'id': 'jsonld', 'nom': 'Données structurées JSON-LD',
     'groupe': 'Référencement', 'langage': 'html', 'fichier': 'jsonld.html',
     'description': 'Article, LocalBusiness, Product, WebSite, BreadcrumbList ou '
                    'FAQPage — validé comme JSON avant d\'être rendu.',
     'parametres': (
         {'nom': 'genre', 'libelle': 'Type', 'type': 'choix', 'defaut': 'Article',
          'options': tuple(JSONLD_MODELES)},
         {'nom': 'titre', 'libelle': 'Titre', 'type': 'texte', 'defaut': ''},
         {'nom': 'description', 'libelle': 'Description', 'type': 'zone',
          'defaut': ''},
         {'nom': 'url', 'libelle': 'Adresse absolue', 'type': 'url', 'defaut': ''},
         {'nom': 'image', 'libelle': 'Image', 'type': 'url', 'defaut': ''},
         {'nom': 'auteur', 'libelle': 'Auteur', 'type': 'texte', 'defaut': ''},
         {'nom': 'site', 'libelle': 'Nom du site', 'type': 'texte', 'defaut': ''},
         {'nom': 'date', 'libelle': 'Date (AAAA-MM-JJ)', 'type': 'texte',
          'defaut': ''},
         {'nom': 'langue', 'libelle': 'Langue', 'type': 'texte', 'defaut': 'fr'},
         {'nom': 'prix', 'libelle': 'Prix (Product)', 'type': 'texte',
          'defaut': ''},
         {'nom': 'devise', 'libelle': 'Devise', 'type': 'texte', 'defaut': 'EUR'},
         {'nom': 'disponibilite', 'libelle': 'Disponibilité', 'type': 'choix',
          'defaut': 'InStock',
          'options': ('InStock', 'OutOfStock', 'PreOrder', 'Discontinued')},
         {'nom': 'ville', 'libelle': 'Ville (LocalBusiness)', 'type': 'texte',
          'defaut': ''},
         {'nom': 'etapes', 'libelle': 'Fil d\'Ariane (Nom|adresse)',
          'type': 'liste', 'defaut': ''},
         {'nom': 'questions', 'libelle': 'Questions (Question|Réponse)',
          'type': 'liste', 'defaut': ''},
     ), 'rendre': _rendre_jsonld},

    {'id': 'favicons', 'nom': 'Liens d\'icônes', 'groupe': 'Référencement',
     'langage': 'html', 'fichier': 'favicons.html',
     'description': 'SVG, ICO, pomme, manifeste et theme-color par schéma de '
                    'couleur.',
     'parametres': (
         {'nom': 'base', 'libelle': 'Préfixe des chemins', 'type': 'texte',
          'defaut': ''},
         {'nom': 'couleur', 'libelle': 'theme-color clair', 'type': 'couleur',
          'defaut': '#ffffff'},
         {'nom': 'couleur_sombre', 'libelle': 'theme-color sombre',
          'type': 'couleur', 'defaut': '#16161d'},
     ), 'rendre': _rendre_favicons},

    {'id': 'manifeste', 'nom': 'Manifeste web', 'groupe': 'Application',
     'langage': 'json', 'fichier': 'manifest.webmanifest',
     'description': 'Nom, icônes (dont une maskable), couleurs, affichage et '
                    'raccourcis — validé comme JSON avant d\'être rendu.',
     'parametres': (
         {'nom': 'nom', 'libelle': 'Nom complet', 'type': 'texte', 'defaut': ''},
         {'nom': 'court', 'libelle': 'Nom court (12 caractères)', 'type': 'texte',
          'defaut': ''},
         {'nom': 'description', 'libelle': 'Description', 'type': 'zone',
          'defaut': ''},
         {'nom': 'accueil', 'libelle': 'URL de départ', 'type': 'texte',
          'defaut': '/'},
         {'nom': 'affichage', 'libelle': 'Affichage', 'type': 'choix',
          'defaut': 'standalone',
          'options': ('standalone', 'fullscreen', 'minimal-ui', 'browser')},
         {'nom': 'couleur', 'libelle': 'Couleur du thème', 'type': 'couleur',
          'defaut': '#1f5fd0'},
         {'nom': 'fond', 'libelle': 'Couleur de fond', 'type': 'couleur',
          'defaut': '#ffffff'},
         {'nom': 'icone', 'libelle': 'Préfixe des icônes', 'type': 'texte',
          'defaut': '/icones/icon'},
         {'nom': 'langue', 'libelle': 'Langue', 'type': 'texte', 'defaut': 'fr'},
         {'nom': 'raccourcis', 'libelle': 'Raccourcis (Nom|adresse)',
          'type': 'liste', 'defaut': ''},
     ), 'rendre': _rendre_manifeste},

    {'id': 'service-worker', 'nom': 'Service worker', 'groupe': 'Application',
     'langage': 'javascript', 'fichier': 'sw.js',
     'description': 'Cache d\'abord pour les ressources versionnées, réseau '
                    'd\'abord pour les pages avec repli, et purge des anciennes '
                    'versions à l\'activation.',
     'parametres': (
         {'nom': 'version', 'libelle': 'Version du cache', 'type': 'texte',
          'defaut': '', 'aide': 'Vide = date du jour. À changer à chaque mise '
                                'en production.'},
         {'nom': 'precache', 'libelle': 'Ressources à précharger', 'type': 'liste',
          'defaut': '/,/style.css,/script.js'},
         {'nom': 'repli', 'libelle': 'Page de repli hors ligne', 'type': 'texte',
          'defaut': '/'},
     ), 'rendre': _rendre_service_worker},
)

GENERATEURS_PAR_ID = {g['id']: g for g in GENERATEURS}


def generer(identifiant, parametres=None):
    """Rend un fichier généré. Renvoie un dictionnaire, jamais d'exception.

    Les `notes` ne sont pas une décoration : elles disent ce qui a été laissé
    par défaut et ce qui doit être vérifié avant publication. Un fichier généré
    dont on ne sait pas quelles parties sont des exemples finit publié tel quel.
    """
    generateur = GENERATEURS_PAR_ID.get(identifiant)
    if generateur is None:
        return {'ok': False,
                'erreur': 'Générateur « %s » inconnu. Les générateurs '
                          'disponibles sont : %s.'
                          % (identifiant, ', '.join(GENERATEURS_PAR_ID))}
    parametres = dict(parametres or {})
    appliques = {}
    for parametre in generateur['parametres']:
        nom = parametre['nom']
        valeur = parametres.get(nom, parametre.get('defaut'))
        if valeur is None:
            valeur = parametre.get('defaut')
        if parametre['type'] == 'nombre':
            try:
                valeur = str(int(float(valeur)))
            except (TypeError, ValueError):
                valeur = str(parametre.get('defaut'))
        elif parametre['type'] == 'case':
            valeur = _oui(valeur)
        elif parametre['type'] == 'choix':
            if valeur not in parametre['options']:
                valeur = parametre.get('defaut') or parametre['options'][0]
        appliques[nom] = valeur
    try:
        resultat = generateur['rendre'](appliques)
    except Exception as exc:
        return {'ok': False, 'id': identifiant,
                'erreur': 'Le générateur « %s » a échoué (%s : %s).'
                          % (generateur['nom'], type(exc).__name__, exc)}
    if isinstance(resultat, tuple):
        contenu, notes = resultat
    else:
        contenu, notes = resultat, []
    if not isinstance(notes, list):
        notes = [str(notes)]
    return {'ok': True, 'id': identifiant, 'nom': generateur['nom'],
            'groupe': generateur['groupe'], 'langage': generateur['langage'],
            'fichier': generateur['fichier'], 'contenu': contenu,
            'notes': notes, 'parametres': appliques,
            'octets': len(contenu.encode('utf8', 'replace'))}


def catalogue_generateurs():
    """Le catalogue, sans les fonctions : c'est ce que l'interface affiche."""
    return [{'id': g['id'], 'nom': g['nom'], 'groupe': g['groupe'],
             'langage': g['langage'], 'fichier': g['fichier'],
             'description': g['description'],
             'parametres': g['parametres']} for g in GENERATEURS]


# =================================================================== EXTRAITS ==
EXTRAITS = (
    # --- Mise en page ---------------------------------------------------------
    {'id': 'centrer-flex', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Centrer un élément, en hauteur et en largeur',
     'description': 'La forme la plus courte et la plus fiable. place-items est '
                    'le raccourci de align-items + justify-items en grille.',
     'code': """.parent {
  display: grid;
  place-items: center;
  min-height: 100vh;      /* sans hauteur, il n'y a rien à centrer */
}

/* Variante flex, quand le parent a déjà d'autres enfants en ligne : */
.parent-flex {
  display: flex;
  align-items: center;
  justify-content: center;
}"""},
    {'id': 'conteneur-fluide', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Conteneur fluide avec marge garantie',
     'description': 'Une seule ligne, pas de media query, et la marge ne '
                    'disparaît jamais à aucune largeur.',
     'code': """.conteneur {
  width: min(1200px, 100% - 2rem);
  margin-inline: auto;
}

/* Même idée avec une largeur de texte confortable (65 caractères environ) : */
.prose { max-width: 65ch; }"""},
    {'id': 'pied-en-bas', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Pied de page en bas même sur une page courte',
     'description': 'La ligne du milieu prend tout l\'espace disponible et pousse '
                    'le pied. Pas de calc(), pas de hauteur fixe.',
     'code': """body {
  display: grid;
  grid-template-rows: auto 1fr auto;
  min-height: 100vh;
  margin: 0;
}"""},
    {'id': 'typographie-fluide', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Typographie fluide avec clamp()',
     'description': 'Une taille qui suit la largeur de l\'écran sans jamais '
                    'descendre sous un minimum ni dépasser un maximum.',
     'code': """:root {
  /* min, préféré, max : le préféré est en vw pour suivre l'écran */
  --texte: clamp(1rem, 0.95rem + 0.3vw, 1.15rem);
  --titre: clamp(1.9rem, 1.2rem + 3vw, 3.4rem);
}
body { font-size: var(--texte); }
h1 { font-size: var(--titre); line-height: 1.1; }"""},
    {'id': 'debordement-horizontal', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Supprimer le défilement horizontal involontaire',
     'description': 'Les trois causes habituelles : une largeur fixe trop '
                    'grande, un mot long non coupable, et une marge négative.',
     'code': """img, video, table, pre { max-width: 100%; }
* { min-width: 0; }              /* un enfant de flex refuse de rétrécir sinon */
p, h1, h2, h3 { overflow-wrap: anywhere; }
pre { overflow-x: auto; }

/* Pour trouver le coupable : surligner tout ce qui dépasse */
[data-debug] * { outline: 1px solid rgba(255,0,0,.35); }"""},
    {'id': 'zones-grille', 'groupe': 'Mise en page', 'langage': 'css',
     'titre': 'Mise en page nommée avec grid-template-areas',
     'description': 'La mise en page se lit comme un dessin. Changer '
                    'l\'ordonnancement en mobile tient en trois lignes.',
     'code': """.page {
  display: grid;
  gap: 1rem;
  grid-template-columns: 220px 1fr;
  grid-template-areas:
    "entete  entete"
    "menu    contenu"
    "pied    pied";
}
.entete  { grid-area: entete; }
.menu    { grid-area: menu; }
.contenu { grid-area: contenu; }
.pied    { grid-area: pied; }

@media (max-width: 768px) {
  .page {
    grid-template-columns: 1fr;
    grid-template-areas: "entete" "menu" "contenu" "pied";
  }
}"""},

    # --- Responsive -----------------------------------------------------------
    {'id': 'media-queries-mobile-first', 'groupe': 'Responsive', 'langage': 'css',
     'titre': 'Media queries en mobile d\'abord',
     'description': 'Écrire la version mobile comme base et n\'ajouter des '
                    'règles qu\'au-delà de seuils. Moins de règles, moins de '
                    'surcharge, et les petits écrans ne paient pas pour les grands.',
     'code': """.grille { display: grid; grid-template-columns: 1fr; gap: 1rem; }

@media (min-width: 640px)  { .grille { grid-template-columns: repeat(2, 1fr); } }
@media (min-width: 1024px) { .grille { grid-template-columns: repeat(3, 1fr); } }
@media (min-width: 1600px) { .grille { grid-template-columns: repeat(4, 1fr); } }"""},
    {'id': 'conteneur-queries', 'groupe': 'Responsive', 'langage': 'css',
     'titre': 'Requêtes de conteneur (pas de media query)',
     'description': 'Le composant s\'adapte à la largeur de SON conteneur, pas à '
                    'celle de l\'écran : la même carte fonctionne dans une '
                    'colonne étroite et en pleine largeur.',
     'code': """.carte-conteneur { container-type: inline-size; container-name: carte; }

.carte { display: grid; gap: 1rem; }

@container carte (min-width: 480px) {
  .carte { grid-template-columns: 200px 1fr; align-items: start; }
}"""},
    {'id': 'images-responsives', 'groupe': 'Responsive', 'langage': 'html',
     'titre': 'Image responsive : srcset, sizes et picture',
     'description': 'srcset laisse le navigateur choisir selon la largeur et la '
                    'densité ; picture impose le choix quand le cadrage doit '
                    'changer.',
     'code': """<!-- Même image, plusieurs largeurs : le navigateur choisit -->
<img src="photo-800.jpg"
     srcset="photo-400.jpg 400w,
             photo-800.jpg 800w,
             photo-1600.jpg 1600w"
     sizes="(max-width: 640px) 100vw,
            (max-width: 1200px) 50vw,
            600px"
     alt="Description de la photo"
     width="800" height="600" loading="lazy" decoding="async">

<!-- Cadrage ou format différent selon l'écran -->
<picture>
  <source media="(max-width: 640px)" srcset="photo-carre-400.webp" type="image/webp">
  <source media="(max-width: 640px)" srcset="photo-carre-400.jpg">
  <source srcset="photo-large.webp" type="image/webp">
  <img src="photo-large.jpg" alt="Description" width="1600" height="900">
</picture>"""},
    {'id': 'menu-mobile', 'groupe': 'Responsive', 'langage': 'javascript',
     'titre': 'Menu mobile accessible (aria-expanded, Échap, clic dehors)',
     'description': 'Un bouton qui ouvre un panneau : l\'état est annoncé, '
                    'Échap le ferme, et le focus reste utilisable.',
     'code': """const bouton = document.querySelector('.menu-bouton');
const panneau = document.querySelector('#navigation');

const definir = (ouvert) => {
  bouton.setAttribute('aria-expanded', String(ouvert));
  panneau.hidden = !ouvert;
};
bouton.addEventListener('click', () =>
  definir(bouton.getAttribute('aria-expanded') !== 'true'));

document.addEventListener('keydown', (evenement) => {
  if (evenement.key === 'Escape' && !panneau.hidden) {
    definir(false);
    bouton.focus();
  }
});
document.addEventListener('click', (evenement) => {
  if (!panneau.hidden && !panneau.contains(evenement.target)
      && evenement.target !== bouton) definir(false);
});
definir(false);"""},

    # --- Accessibilité --------------------------------------------------------
    {'id': 'evitement', 'groupe': 'Accessibilité', 'langage': 'html',
     'titre': 'Lien d\'évitement',
     'description': 'Premier élément focusable de la page : il permet de sauter '
                    'la navigation au clavier. Invisible tant qu\'il n\'a pas le '
                    'focus, jamais display:none (qui le rendrait inatteignable).',
     'code': """<a class="evitement" href="#contenu">Aller au contenu principal</a>
<main id="contenu">…</main>

<style>
.evitement {
  position: absolute; left: -9999px; top: 0; z-index: 100;
  padding: .6rem 1rem; background: #1f5fd0; color: #fff;
}
.evitement:focus { left: 0; }
</style>"""},
    {'id': 'focus-visible', 'groupe': 'Accessibilité', 'langage': 'css',
     'titre': 'Focus visible et net (sans le retirer)',
     'description': 'outline:none sans remplacement est la faute '
                    'd\'accessibilité la plus répandue : le clavier devient '
                    'aveugle. Voici le remplacement correct.',
     'code': """:focus-visible {
  outline: 3px solid currentColor;
  outline-offset: 2px;
  border-radius: 2px;
}

/* Retirer l'anneau seulement là où un autre signal existe */
.carte:focus-visible { outline: none; box-shadow: 0 0 0 3px #1f5fd0; }

/* Ne JAMAIS écrire ceci sans remplacement : */
/* a:focus { outline: none; } */"""},
    {'id': 'aria-live', 'groupe': 'Accessibilité', 'langage': 'html',
     'titre': 'Annoncer un changement dynamique',
     'description': 'Un message ajouté par JavaScript n\'est pas lu sans '
                    'aria-live. polite attend la fin de la lecture en cours, '
                    'assertive interrompt.',
     'code': """<p id="statut" role="status" aria-live="polite" aria-atomic="true"></p>

<script>
const statut = document.getElementById('statut');
const annoncer = (texte) => {
  statut.textContent = '';                 // vider d'abord : un texte identique
  setTimeout(() => { statut.textContent = texte; }, 50);   // n'est pas relu
};
annoncer('3 résultats trouvés.');
</script>

<!-- role="alert" équivaut à aria-live="assertive" : à réserver aux erreurs -->"""},
    {'id': 'dialogue-accessible', 'groupe': 'Accessibilité', 'langage': 'javascript',
     'titre': 'Dialogue natif <dialog> avec focus piégé',
     'description': 'showModal() gère déjà le piège à focus, l\'empilement et la '
                    'fermeture par Échap. C\'est la raison de l\'utiliser plutôt '
                    'qu\'une div.',
     'code': """<dialog id="boite" aria-labelledby="boite-titre">
  <h2 id="boite-titre">Confirmer l'envoi</h2>
  <p>Le message partira immédiatement.</p>
  <form method="dialog">
    <button value="annuler" type="submit">Annuler</button>
    <button value="confirmer" type="submit" autofocus>Confirmer</button>
  </form>
</dialog>

<script>
const boite = document.getElementById('boite');
document.querySelector('.ouvrir').addEventListener('click', () => {
  boite.showModal();                       // pas show() : showModal piège le focus
});
boite.addEventListener('close', () => {
  console.log('valeur rendue :', boite.returnValue);
});
// Fermer en cliquant sur le fond, pas sur le contenu
boite.addEventListener('click', (evenement) => {
  if (evenement.target === boite) boite.close('fond');
});
</script>"""},

    # --- JavaScript -----------------------------------------------------------
    {'id': 'fetch-propre', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'fetch() avec gestion complète des erreurs',
     'description': 'fetch ne rejette PAS sur un 404 ou un 500 : sans le test '
                    'sur response.ok, une erreur serveur passe pour un succès. '
                    'C\'est la faute la plus fréquente de ce code.',
     'code': """async function charger(url, options = {}) {
  const controleur = new AbortController();
  const minuteur = setTimeout(() => controleur.abort(), options.delai || 15000);
  try {
    const reponse = await fetch(url, {
      ...options,
      signal: controleur.signal,
      headers: { 'Accept': 'application/json', ...(options.headers || {}) },
    });
    if (!reponse.ok) {
      // Un 404 ou un 500 N'EST PAS une exception pour fetch : il faut le dire.
      const detail = await reponse.text().catch(() => '');
      throw new Error(`HTTP ${reponse.status} sur ${url} — ${detail.slice(0, 200)}`);
    }
    const type = reponse.headers.get('content-type') || '';
    return type.includes('application/json') ? await reponse.json()
                                             : await reponse.text();
  } catch (erreur) {
    if (erreur.name === 'AbortError') throw new Error(`Délai dépassé sur ${url}`);
    throw erreur;
  } finally {
    clearTimeout(minuteur);
  }
}"""},
    {'id': 'anti-rebond', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'Anti-rebond et throttle',
     'description': 'L\'anti-rebond attend la fin de la saisie (recherche) ; le '
                    'throttle limite la fréquence (défilement, redimensionnement).',
     'code': """const antiRebond = (fonction, delai = 300) => {
  let minuteur;
  return (...args) => {
    clearTimeout(minuteur);
    minuteur = setTimeout(() => fonction(...args), delai);
  };
};

const throttle = (fonction, delai = 200) => {
  let dernier = 0, minuteur = null;
  return (...args) => {
    const maintenant = Date.now();
    const reste = delai - (maintenant - dernier);
    if (reste <= 0) {
      dernier = maintenant;
      fonction(...args);
    } else if (!minuteur) {
      minuteur = setTimeout(() => {
        minuteur = null; dernier = Date.now(); fonction(...args);
      }, reste);
    }
  };
};

champ.addEventListener('input', antiRebond((e) => chercher(e.target.value), 250));
addEventListener('scroll', throttle(mesurer, 150), { passive: true });"""},
    {'id': 'intersection-observer', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'IntersectionObserver (apparition, lazy, scroll-spy)',
     'description': 'Remplace l\'écoute de scroll + getBoundingClientRect, qui '
                    'recalcule la mise en page à chaque événement.',
     'code': """const observateur = new IntersectionObserver((entrees) => {
  for (const entree of entrees) {
    if (!entree.isIntersecting) continue;
    entree.target.classList.add('visible');
    observateur.unobserve(entree.target);   // une seule fois
  }
}, { rootMargin: '0px 0px -10% 0px', threshold: 0.15 });

document.querySelectorAll('.a-animer').forEach((el) => observateur.observe(el));

/* Scroll-spy : quel titre de section est à l'écran */
const espion = new IntersectionObserver((entrees) => {
  for (const entree of entrees) {
    const lien = document.querySelector(`nav a[href="#${entree.target.id}"]`);
    if (lien) lien.setAttribute('aria-current', entree.isIntersecting ? 'true' : 'false');
  }
}, { rootMargin: '-40% 0px -55% 0px' });
document.querySelectorAll('main section[id]').forEach((s) => espion.observe(s));"""},
    {'id': 'stockage-sur', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'localStorage sans exception',
     'description': 'localStorage LÈVE en navigation privée saturée, quand les '
                    'données de site sont bloquées, ou au-delà du quota. Sans '
                    'ces protections, toute la page plante pour une donnée '
                    'accessoire.',
     'code': """const memoire = (() => {
  let disponible = false;
  try {
    const clef = '__test__';
    localStorage.setItem(clef, '1');
    localStorage.removeItem(clef);
    disponible = true;
  } catch (erreur) { disponible = false; }
  const repli = new Map();                    // en mémoire si le stockage est refusé

  return {
    disponible,
    lire(clef, defaut = null) {
      try {
        const brut = disponible ? localStorage.getItem(clef) : repli.get(clef);
        return brut === null || brut === undefined ? defaut : JSON.parse(brut);
      } catch (erreur) { return defaut; }     // une donnée corrompue ne plante pas
    },
    ecrire(clef, valeur) {
      const brut = JSON.stringify(valeur);
      try {
        if (disponible) localStorage.setItem(clef, brut); else repli.set(clef, brut);
        return true;
      } catch (erreur) {
        repli.set(clef, brut);                // quota atteint : on bascule
        return false;
      }
    },
  };
})();"""},
    {'id': 'copier-presse-papier', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'Copier dans le presse-papiers, avec repli',
     'description': 'navigator.clipboard n\'existe qu\'en contexte sécurisé '
                    '(HTTPS ou localhost) ; sans repli, le bouton ne fait rien '
                    'en HTTP.',
     'code': """async function copier(texte, bouton) {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(texte);
    } else {
      const zone = document.createElement('textarea');
      zone.value = texte;
      zone.setAttribute('readonly', '');
      zone.style.cssText = 'position:fixed;top:-1000px;opacity:0';
      document.body.append(zone);
      zone.select();
      const reussi = document.execCommand('copy');
      zone.remove();
      if (!reussi) throw new Error('execCommand a échoué');
    }
    if (bouton) {
      const avant = bouton.textContent;
      bouton.textContent = 'Copié ✓';
      bouton.setAttribute('aria-live', 'polite');
      setTimeout(() => { bouton.textContent = avant; }, 1600);
    }
    return true;
  } catch (erreur) {
    if (bouton) bouton.textContent = 'Copie refusée';
    return false;
  }
}"""},
    {'id': 'delegation', 'groupe': 'JavaScript', 'langage': 'javascript',
     'titre': 'Délégation d\'événements (liste dynamique)',
     'description': 'Un seul écouteur sur le conteneur fonctionne pour les '
                    'éléments ajoutés plus tard, sans réattacher quoi que ce soit.',
     'code': """liste.addEventListener('click', (evenement) => {
  const cible = evenement.target.closest('[data-action]');
  if (!cible || !liste.contains(cible)) return;   // clic hors d'un élément utile

  const action = cible.dataset.action;
  const ligne = cible.closest('[data-id]');
  if (action === 'supprimer' && ligne) {
    ligne.remove();
  } else if (action === 'modifier' && ligne) {
    ouvrirEditeur(ligne.dataset.id);
  }
});"""},

    # --- Performance ----------------------------------------------------------
    {'id': 'chargement-differe', 'groupe': 'Performance', 'langage': 'html',
     'titre': 'Différer ce qui ne bloque pas le premier affichage',
     'description': 'defer, preload, preconnect et lazy : les quatre leviers qui '
                    'donnent le plus de gain pour le moins de risque.',
     'code': """<!-- defer : téléchargé en parallèle, exécuté après l'analyse du document -->
<script src="app.js" defer></script>

<!-- preload : une ressource critique découverte tard (police, image above-the-fold) -->
<link rel="preload" href="/polices/texte.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="/hero.webp" as="image" fetchpriority="high">

<!-- preconnect : préparer une origine tierce avant d'en avoir besoin -->
<link rel="preconnect" href="https://api.exemple.fr" crossorigin>
<link rel="dns-prefetch" href="https://cdn.exemple.fr">

<!-- lazy : jamais sur l'image visible au chargement, toujours sur les suivantes -->
<img src="a.jpg" alt="…" width="800" height="600" loading="lazy" decoding="async">"""},
    {'id': 'css-critique', 'groupe': 'Performance', 'langage': 'html',
     'titre': 'CSS critique en ligne, reste différé',
     'description': 'Une feuille de style est bloquante : le premier affichage '
                    'attend son téléchargement. En ligne le minimum, le reste '
                    'ensuite.',
     'code': """<style>
  /* Uniquement ce qui est visible au premier écran : remise à zéro, typographie,
     en-tête. Au-delà de 14 Ko, le gain disparaît (le HTML passe en plusieurs
     paquets TCP). */
  *,*::before,*::after{box-sizing:border-box}
  body{margin:0;font:16px/1.6 system-ui,sans-serif;color:#16161d;background:#fff}
  .entete{display:flex;gap:1rem;padding:.8rem 1rem;border-bottom:1px solid #ddd}
</style>

<!-- Le reste, sans bloquer le rendu -->
<link rel="stylesheet" href="/style.css" media="print" onload="this.media='all'">
<noscript><link rel="stylesheet" href="/style.css"></noscript>"""},
    {'id': 'polices-optimisees', 'groupe': 'Performance', 'langage': 'css',
     'titre': 'Polices : woff2, subset, font-display, unicité',
     'description': 'Quatre réglages qui évitent le texte invisible et le '
                    'téléchargement de glyphes jamais utilisés.',
     'code': """@font-face {
  font-family: "Texte";
  src: url("/polices/texte-latin.woff2") format("woff2");
  font-weight: 400;
  font-style: normal;
  font-display: swap;              /* texte immédiat dans la police de repli */
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+2000-206F;  /* latin seul */
}

body {
  font-family: "Texte", system-ui, -apple-system, "Segoe UI", sans-serif;
  /* Une métrique proche de la police de repli évite le saut de mise en page : */
  size-adjust: 100%;
}"""},
    {'id': 'mesure-performance', 'groupe': 'Performance', 'langage': 'javascript',
     'titre': 'Mesurer les Core Web Vitals en quelques lignes',
     'description': 'Les vraies métriques, mesurées dans le navigateur de '
                    'l\'utilisateur, pas dans un outil de laboratoire.',
     'code': """const mesurer = () => {
  const nav = performance.getEntriesByType('navigation')[0] || {};
  const rapport = {
    ttfb: Math.round((nav.responseStart || 0) - (nav.requestStart || 0)),
    fcp: 0, lcp: 0, cls: 0,
    dom: Math.round(nav.domContentLoadedEventEnd || 0),
    charge: Math.round(nav.loadEventEnd || 0),
    requetes: performance.getEntriesByType('resource').length,
    octets: performance.getEntriesByType('resource')
      .reduce((somme, r) => somme + (r.transferSize || 0), 0),
  };
  for (const e of performance.getEntriesByType('paint'))
    if (e.name === 'first-contentful-paint') rapport.fcp = Math.round(e.startTime);

  new PerformanceObserver((liste) => {
    for (const e of liste.getEntries()) rapport.lcp = Math.round(e.startTime);
  }).observe({ type: 'largest-contentful-paint', buffered: true });

  new PerformanceObserver((liste) => {
    for (const e of liste.getEntries())
      if (!e.hadRecentInput) rapport.cls += e.value;
  }).observe({ type: 'layout-shift', buffered: true });

  addEventListener('pagehide', () => console.table(rapport), { once: true });
};
addEventListener('load', mesurer, { once: true });"""},

    # --- Sécurité -------------------------------------------------------------
    {'id': 'echappement-html', 'groupe': 'Sécurité', 'langage': 'javascript',
     'titre': 'Échapper avant d\'insérer du HTML',
     'description': 'textContent suffit presque toujours. Quand il faut vraiment '
                    'construire du HTML, chaque donnée passe par l\'échappement.',
     'code': """/* Préférer ceci — aucune échappement nécessaire, aucune injection possible : */
element.textContent = donneeUtilisateur;

/* Quand la structure HTML est indispensable : */
const echapper = (texte) => String(texte ?? '')
  .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
  .replaceAll('"', '&quot;').replaceAll("'", '&#39;');

zone.innerHTML = `<li class="ligne"><b>${echapper(titre)}</b> — ${echapper(resume)}</li>`;

/* Ce qu'il ne faut PAS faire : */
// zone.innerHTML = '<b>' + titre + '</b>';           // injection directe
// zone.innerHTML = donnee.replace(/</g, '&lt;');     // les attributs passent
// a.setAttribute('href', saisie);                    // javascript: passe
const urlSure = (saisie) => {
  try { const u = new URL(saisie, location.href);
        return ['http:', 'https:', 'mailto:'].includes(u.protocol) ? u.href : '#'; }
  catch (e) { return '#'; }
};"""},
    {'id': 'cookie-securise', 'groupe': 'Sécurité', 'langage': 'javascript',
     'titre': 'Cookie posé depuis JavaScript, avec ses drapeaux',
     'description': 'Un cookie sans SameSite est envoyé sur les requêtes '
                    'transverses ; sans Secure il part en clair. HttpOnly ne peut '
                    'PAS être posé depuis JavaScript — c\'est au serveur de le '
                    'faire pour un cookie de session.',
     'code': """function poserCookie(nom, valeur, jours = 7, options = {}) {
  const parts = [
    `${encodeURIComponent(nom)}=${encodeURIComponent(valeur)}`,
    `Path=${options.chemin || '/'}`,
    `SameSite=${options.sameSite || 'Strict'}`,
    `Max-Age=${Math.round(jours * 86400)}`,
  ];
  if (location.protocol === 'https:' || options.secure) parts.push('Secure');
  // HttpOnly est IMPOSSIBLE ici : un cookie de session doit être posé par le
  // serveur avec Set-Cookie, sinon tout script de la page peut le lire.
  document.cookie = parts.join('; ');
}

poserCookie('preferences', JSON.stringify({ theme: 'sombre' }), 30);"""},
    {'id': 'validation-serveur', 'groupe': 'Sécurité', 'langage': 'javascript',
     'titre': 'Validation côté serveur (Node/Express)',
     'description': 'Le client valide pour le confort ; le serveur valide pour la '
                    'sécurité. Voici la forme minimale qui ne laisse rien passer.',
     'code': """const nettoyer = {
  texte: (v, max = 200) => String(v ?? '').trim().slice(0, max),
  courriel: (v) => {
    const s = String(v ?? '').trim().toLowerCase();
    return /^[^@\\s]+@[^@\\s.]+(\\.[^@\\s.]+)+$/.test(s) && s.length <= 254 ? s : null;
  },
  entier: (v, min, max) => {
    const n = Number.parseInt(v, 10);
    return Number.isInteger(n) && n >= min && n <= max ? n : null;
  },
  choix: (v, permis) => permis.includes(v) ? v : null,
};

app.post('/contact', express.urlencoded({ extended: false, limit: '32kb' }),
  (requete, reponse) => {
    const courriel = nettoyer.courriel(requete.body.courriel);
    const message = nettoyer.texte(requete.body.message, 4000);
    const motif = nettoyer.choix(requete.body.motif, ['devis', 'support']);
    const fautes = [];
    if (!courriel) fautes.push('courriel');
    if (!message || message.length < 20) fautes.push('message');
    if (!motif) fautes.push('motif');
    if (requete.body.csrf !== requete.session.csrf) fautes.push('csrf');
    if (fautes.length) return reponse.status(400).json({ champs: fautes });
    // … traitement, puis :
    reponse.status(201).json({ ok: true });
  });"""},

    # --- Données et stockage --------------------------------------------------
    {'id': 'url-parametres', 'groupe': 'Données', 'langage': 'javascript',
     'titre': 'État dans l\'URL (filtres, pagination, partage)',
     'description': 'Un état dans l\'URL survit au rechargement, se partage, et '
                    'permet le bouton retour — sans history.pushState oublié.',
     'code': """const lireEtat = () => Object.fromEntries(new URLSearchParams(location.search));

const ecrireEtat = (etat, remplacer = false) => {
  const params = new URLSearchParams();
  for (const [clef, valeur] of Object.entries(etat)) {
    if (valeur !== '' && valeur !== null && valeur !== undefined)
      params.set(clef, String(valeur));
  }
  const url = params.toString() ? `?${params}` : location.pathname;
  history[remplacer ? 'replaceState' : 'pushState'](etat, '', url);
};

addEventListener('popstate', (evenement) => appliquer(evenement.state || lireEtat()));
appliquer(lireEtat());"""},
    {'id': 'indexeddb-minimal', 'groupe': 'Données', 'langage': 'javascript',
     'titre': 'IndexedDB en trente lignes (stockage hors ligne)',
     'description': 'Pour plus que quelques clefs : localStorage est limité à '
                    'quelques mégaoctets et bloque le fil principal.',
     'code': """const ouvrir = (nom, version, migration) => new Promise((resoudre, rejeter) => {
  const requete = indexedDB.open(nom, version);
  requete.onupgradeneeded = () => migration(requete.result);
  requete.onsuccess = () => resoudre(requete.result);
  requete.onerror = () => rejeter(requete.error);
});

const base = await ouvrir('app', 1, (db) => {
  db.createObjectStore('articles', { keyPath: 'id' });
});

async function ecrire(store, valeur) {
  return new Promise((resoudre, rejeter) => {
    const tx = base.transaction(store, 'readwrite');
    tx.objectStore(store).put(valeur);
    tx.oncomplete = resoudre;
    tx.onerror = () => rejeter(tx.error);
  });
}
async function lireTout(store) {
  return new Promise((resoudre, rejeter) => {
    const requete = base.transaction(store).objectStore(store).getAll();
    requete.onsuccess = () => resoudre(requete.result);
    requete.onerror = () => rejeter(requete.error);
  });
}"""},

    # --- Débogage -------------------------------------------------------------
    {'id': 'console-utile', 'groupe': 'Débogage', 'langage': 'javascript',
     'titre': 'Console : les méthodes qu\'on n\'utilise jamais assez',
     'description': 'group, table, time, trace et dir rendent un débogage '
                    'lisible là où log empile des lignes inexploitables.',
     'code': """console.group('chargement du profil');
console.time('requete');
const profil = await fetch('/api/profil').then(r => r.json());
console.timeEnd('requete');
console.table(profil.roles);                 // un tableau d'objets -> une table
console.log('%cAttention%c valeur inattendue', 'background:#c00;color:#fff',
            'background:none;color:inherit', profil);
console.trace('qui a appelé cette fonction'); // la pile d'appel, pas seulement le message
console.groupEnd();

/* Compter sans accumuler de lignes : */
console.count('clic-sur-valider');

/* Un objet vivant (pas une copie) : utile pour inspecter l'état après coup */
console.dir(element, { depth: 2 });"""},
    {'id': 'attraper-erreurs', 'groupe': 'Débogage', 'langage': 'javascript',
     'titre': 'Capturer toutes les erreurs de la page',
     'description': 'Une promesse rejetée non interceptée ne déclenche PAS '
                    'window.onerror : sans unhandledrejection, elle disparaît '
                    'silencieusement.',
     'code': """const journal = [];
const noter = (type, detail) => {
  journal.push({ type, ...detail, url: location.href, quand: new Date().toISOString() });
  if (journal.length > 200) journal.shift();
};

addEventListener('error', (evenement) => {
  if (evenement.target && evenement.target !== window) {
    // Une ressource qui ne charge pas ne passe pas par window.onerror
    noter('ressource', { balise: evenement.target.tagName,
                         url: evenement.target.src || evenement.target.href });
  } else {
    noter('erreur', { message: evenement.message, fichier: evenement.filename,
                      ligne: evenement.lineno, colonne: evenement.colno,
                      pile: evenement.error?.stack });
  }
}, true);                                   // true : capter aussi la phase de capture

addEventListener('unhandledrejection', (evenement) => {
  const raison = evenement.reason;
  noter('promesse', { message: raison?.message || String(raison),
                      pile: raison?.stack });
});

/* À envoyer au serveur en fin de session, ou à lire dans le panneau dev web. */"""},
)

EXTRAITS_PAR_ID = {e['id']: e for e in EXTRAITS}
GROUPES_EXTRAITS = []
for _extrait in EXTRAITS:
    if _extrait['groupe'] not in GROUPES_EXTRAITS:
        GROUPES_EXTRAITS.append(_extrait['groupe'])


def extraits(groupe=None, recherche=None):
    """Les extraits, éventuellement filtrés par groupe et par texte cherché.

    La recherche porte sur le titre, la description ET le code : chercher
    « clamp » doit trouver l'extrait qui s'en sert, pas seulement celui qui en
    parle.
    """
    sortie = []
    termes = [t for t in re.split(r'[\s,]+', (recherche or '').lower()) if t]
    for extrait in EXTRAITS:
        if groupe and extrait['groupe'] != groupe:
            continue
        if termes:
            cible = ' '.join((extrait['titre'], extrait['description'],
                              extrait['code'])).lower()
            if not all(terme in cible for terme in termes):
                continue
        sortie.append(extrait)
    return sortie


def verifier_modeles():
    """Contrôle interne des générateurs et des extraits.

    Un générateur est exécuté avec SES VALEURS PAR DÉFAUT : un modèle qui
    attend une clef jamais fournie lèverait chez l'utilisateur, pas ici. C'est
    exactement le genre de défaut qu'une lecture ne voit pas.
    """
    problemes = []
    identifiants = [g['id'] for g in GENERATEURS]
    if len(identifiants) != len(set(identifiants)):
        problemes.append('GENERATEURS : identifiants en double')
    for generateur in GENERATEURS:
        for cle in ('id', 'nom', 'groupe', 'langage', 'fichier', 'description',
                    'parametres', 'rendre'):
            if cle not in generateur:
                problemes.append('GENERATEURS : %s sans champ %s'
                                 % (generateur.get('id'), cle))
        noms = [p['nom'] for p in generateur['parametres']]
        if len(noms) != len(set(noms)):
            problemes.append('GENERATEURS : %s a des paramètres en double'
                             % generateur['id'])
        for parametre in generateur['parametres']:
            for cle in ('nom', 'libelle', 'type'):
                if cle not in parametre:
                    problemes.append('GENERATEURS : %s.%s sans %s'
                                     % (generateur['id'], parametre.get('nom'), cle))
            if parametre.get('type') == 'choix' and not parametre.get('options'):
                problemes.append('GENERATEURS : %s.%s est un choix sans options'
                                 % (generateur['id'], parametre['nom']))
        defauts = {p['nom']: p.get('defaut') for p in generateur['parametres']}
        resultat = generer(generateur['id'], defauts)
        if not resultat.get('ok'):
            # Certains générateurs ne PEUVENT pas produire quelque chose sans
            # entrée (l'empreinte d'intégrité, par exemple). Échouer est alors
            # le comportement correct — à condition que la raison soit dite.
            if generateur.get('exige_une_entree'):
                erreur = resultat.get('erreur') or ''
                if len(erreur) < 25:
                    problemes.append(
                        'GENERATEURS : %s échoue sans expliquer pourquoi (%r)'
                        % (generateur['id'], erreur))
                continue
            problemes.append('GENERATEURS : %s échoue avec ses valeurs par '
                             'défaut : %s' % (generateur['id'],
                                              resultat.get('erreur')))
            continue
        if not resultat['contenu'].strip():
            problemes.append('GENERATEURS : %s rend un fichier vide'
                             % generateur['id'])
        if '{{' in resultat['contenu'] or '}}' in resultat['contenu']:
            problemes.append('GENERATEURS : %s laisse un {{…}} non rempli'
                             % generateur['id'])
        if resultat['langage'] not in ('html', 'css', 'javascript', 'json',
                                       'xml', 'text', 'apache', 'nginx'):
            problemes.append('GENERATEURS : %s a un langage inattendu (%s)'
                             % (generateur['id'], resultat['langage']))
    for extrait in EXTRAITS:
        for cle in ('id', 'groupe', 'langage', 'titre', 'description', 'code'):
            if cle not in extrait:
                problemes.append('EXTRAITS : %s sans champ %s'
                                 % (extrait.get('id'), cle))
        if len(extrait.get('code', '')) < 40:
            problemes.append('EXTRAITS : %s a un code trop court pour servir'
                             % extrait['id'])
    if len(EXTRAITS) != len(set(e['id'] for e in EXTRAITS)):
        problemes.append('EXTRAITS : identifiants en double')
    return problemes


if __name__ == '__main__':
    import sys

    defauts = verifier_modeles()
    if defauts:
        for defaut in defauts:
            print('ÉCHEC :', defaut)
        sys.exit(1)
    print('devweb_modeles : %d générateurs (%s) et %d extraits en %d groupes — '
          'tous les générateurs exécutés avec leurs valeurs par défaut.'
          % (len(GENERATEURS),
             ', '.join(sorted({g['groupe'] for g in GENERATEURS})),
             len(EXTRAITS), len(GROUPES_EXTRAITS)))
