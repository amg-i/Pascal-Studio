"""Références utilisées par les audits dev web : données, pas logique.

Ces listes sont séparées des audits pour deux raisons. La première est la
lisibilité : un audit doit se lire comme une règle, pas comme un catalogue. La
seconde est plus importante — une liste de référence EST un engagement. Quand
l'audit d'accessibilité déclare qu'un rôle ARIA est inconnu, il affirme que la
liste ci-dessous est à jour ; une liste incomplète ferait accuser du code
correct, ce qui est le pire défaut d'un analyseur. Chaque liste porte donc la
gravité qu'elle mérite :

  * ce qui est INTERDIT par le HTML (élément déprécié, imbrication impossible)
    peut être affirmé comme erreur ou avertissement ;
  * ce qui n'est pas RECONNU par une liste (propriété CSS, rôle ARIA récent)
    n'est jamais affirmé comme erreur : c'est une information, formulée de
    manière à dire que la liste peut être en retard.

Toutes les clefs sont en minuscules ; le banc de ce module vérifie l'absence de
doublon et la casse, parce qu'une entrée mal orthographiée rend une règle muette
sans qu'aucune erreur n'apparaisse nulle part.
"""

# --------------------------------------------------------------- ARIA/HTML ---
# Rôles ARIA (WAI-ARIA 1.2 + HTML-AAM). Un rôle hors de cette liste est signalé
# comme INFORMATION, pas comme erreur : la liste peut être en retard sur la
# spécification, et un rôle invalide est de toute façon ignoré sans danger par
# les technologies d'assistance.
ROLES_ARIA = frozenset((
    'alert', 'alertdialog', 'application', 'article', 'banner', 'blockquote',
    'button', 'canvas', 'caption', 'cell', 'checkbox', 'code', 'columnheader',
    'combobox', 'command', 'complementary', 'composite', 'contentinfo',
    'definition', 'deletion', 'dialog', 'directory', 'document', 'emphasis',
    'feed', 'figure', 'form', 'generic', 'grid', 'gridcell', 'group',
    'heading', 'img', 'input', 'insertion', 'landmark', 'link', 'list',
    'listbox', 'listitem', 'log', 'main', 'marquee', 'math', 'meter', 'menu',
    'menubar', 'menuitem', 'menuitemcheckbox', 'menuitemradio', 'navigation',
    'none', 'note', 'option', 'paragraph', 'presentation', 'progressbar',
    'radio', 'radiogroup', 'range', 'region', 'roletype', 'row', 'rowgroup',
    'rowheader', 'scrollbar', 'search', 'searchbox', 'section', 'sectionhead',
    'select', 'separator', 'slider', 'spinbutton', 'status', 'strong',
    'structure', 'switch', 'tab', 'table', 'tablist', 'tabpanel', 'term',
    'textbox', 'time', 'timer', 'toolbar', 'tooltip', 'tree', 'treegrid',
    'treeitem', 'widget', 'window',
))

# Attributs aria-* et états associés.
ATTRIBUTS_ARIA = frozenset((
    'aria-activedescendant', 'aria-atomic', 'aria-autocomplete',
    'aria-braillelabel', 'aria-brailleroledescription', 'aria-busy',
    'aria-checked', 'aria-colcount', 'aria-colindex', 'aria-colindextext',
    'aria-colspan', 'aria-controls', 'aria-current', 'aria-describedby',
    'aria-description', 'aria-details', 'aria-disabled', 'aria-dropeffect',
    'aria-errormessage', 'aria-expanded', 'aria-flowto', 'aria-grabbed',
    'aria-haspopup', 'aria-hidden', 'aria-invalid', 'aria-keyshortcuts',
    'aria-label', 'aria-labelledby', 'aria-level', 'aria-live', 'aria-modal',
    'aria-multiline', 'aria-multiselectable', 'aria-orientation',
    'aria-owns', 'aria-placeholder', 'aria-posinset', 'aria-pressed',
    'aria-readonly', 'aria-relevant', 'aria-required', 'aria-roledescription',
    'aria-rowcount', 'aria-rowindex', 'aria-rowindextext', 'aria-rowspan',
    'aria-selected', 'aria-setsize', 'aria-sort', 'aria-valuemax',
    'aria-valuemin', 'aria-valuenow', 'aria-valuetext',
))

# Éléments retirés ou dépréciés du HTML : leur usage est une erreur, pas une
# simple information, car ils ne font plus rien ou le font mal.
ELEMENTS_OBSOLETES = {
    'applet': 'Remplacé par <embed> ou <object>, et de toute façon par du JavaScript.',
    'acronym': 'Remplacé par <abbr title="…">.',
    'basefont': 'La typographie se règle en CSS.',
    'big': 'La taille se règle en CSS (font-size).',
    'blink': 'Retiré : il ne fonctionne plus et il était nuisible.',
    'center': 'Remplacé par CSS (text-align ou margin:auto).',
    'dir': 'Remplacé par <ul>.',
    'font': 'Remplacé par CSS.',
    'frame': 'Les cadres sont retirés du HTML.',
    'frameset': 'Les cadres sont retirés du HTML.',
    'marquee': 'Remplacé par une animation CSS.',
    'nobr': 'Remplacé par CSS (white-space:nowrap).',
    'noembed': 'Sans objet depuis la disparition des greffons.',
    'noframes': 'Sans objet depuis la disparition des cadres.',
    'plaintext': 'Utilisez <pre>.',
    'rb': 'Utilisez <ruby> seul.',
    'strike': 'Remplacé par <del> ou <s>.',
    'tt': 'Remplacé par CSS (font-family monospace).',
    'xmp': 'Utilisez <pre><code>.',
    'spacer': 'L’espacement se règle en CSS.',
    'keygen': 'Retiré : la génération de clefs passe par JavaScript/WebCrypto.',
}

# Attributs de présentation dépréciés : (élément ou '*', attribut) -> conseil.
ATTRIBUTS_OBSOLETES = {
    ('*', 'align'): 'CSS text-align ou display:flex.',
    ('*', 'bgcolor'): 'CSS background-color.',
    ('*', 'background'): 'CSS background-image.',
    ('*', 'bordercolor'): 'CSS border-color.',
    ('*', 'valign'): 'CSS vertical-align.',
    ('*', 'hspace'): 'CSS margin-left/margin-right.',
    ('*', 'vspace'): 'CSS margin-top/margin-bottom.',
    ('*', 'nowrap'): 'CSS white-space:nowrap.',
    ('*', 'clear'): 'CSS clear.',
    ('img', 'border'): 'CSS border.',
    ('img', 'hspace'): 'CSS margin.',
    ('img', 'vspace'): 'CSS margin.',
    ('table', 'border'): 'CSS border.',
    ('table', 'cellpadding'): 'CSS padding.',
    ('table', 'cellspacing'): 'CSS border-spacing.',
    ('table', 'width'): 'CSS width.',
    ('table', 'frame'): 'CSS border.',
    ('table', 'rules'): 'CSS border.',
    ('td', 'width'): 'CSS width.',
    ('td', 'height'): 'CSS height.',
    ('th', 'width'): 'CSS width.',
    ('hr', 'width'): 'CSS width.',
    ('hr', 'size'): 'CSS height.',
    ('body', 'text'): 'CSS color.',
    ('body', 'link'): 'CSS a{color}.',
    ('body', 'vlink'): 'CSS a:visited{color}.',
    ('body', 'alink'): 'CSS a:active{color}.',
    ('body', 'marginwidth'): 'CSS margin.',
    ('body', 'marginheight'): 'CSS margin.',
    ('a', 'name'): 'Utilisez id : name sur <a> est déprécié.',
    ('script', 'language'): 'L’attribut type suffit.',
    ('input', 'usemap'): 'Sans effet.',
}

# Éléments interactifs : un lien ou un bouton ne doit pas en contenir un autre,
# car le comportement au clic devient imprévisible et l’accessibilité casse.
INTERACTIFS = frozenset((
    'a', 'button', 'details', 'embed', 'input', 'label', 'select', 'textarea',
    'video', 'audio',
))

# Parents obligatoires : élément -> parents acceptés. Une occurrence ailleurs
# est une erreur de structure réelle (le navigateur la déplace, ce qui casse la
# mise en page et le CSS descendant).
PARENTS_OBLIGATOIRES = {
    'li': ('ul', 'ol', 'menu'),
    'dt': ('dl', 'div'),
    'dd': ('dl', 'div'),
    'tr': ('table', 'thead', 'tbody', 'tfoot'),
    'td': ('tr',),
    'th': ('tr',),
    'thead': ('table',),
    'tbody': ('table',),
    'tfoot': ('table',),
    'caption': ('table',),
    'colgroup': ('table',),
    'col': ('colgroup',),
    'option': ('select', 'datalist', 'optgroup'),
    'optgroup': ('select',),
    'figcaption': ('figure',),
    'summary': ('details',),
    'legend': ('fieldset',),
    'area': ('map',),
    'param': ('object',),
    'source': ('picture', 'video', 'audio'),
    'track': ('video', 'audio'),
    'rp': ('ruby',),
    'rt': ('ruby',),
    'title': ('head', 'svg'),
    'base': ('head',),
}

# Enfants directs autorisés d'un <table> : tout le reste est déplacé par le
# navigateur AVANT le tableau, ce qui est la cause classique d'un texte qui
# apparaît au mauvais endroit.
ENFANTS_TABLE = frozenset((
    'caption', 'colgroup', 'thead', 'tbody', 'tfoot', 'tr', 'script',
    'template', 'style',
))

# Balises dont le contenu est du texte brut : y trouver une balise est le signe
# d'une échappement oublié (<script>if (a<b)</script>).
CONTENU_BRUT = frozenset(('script', 'style'))

# ------------------------------------------------------------------ sécurité --
# En-têtes de réponse recommandés, avec leur gravité quand ils manquent.
# `https_uniquement` : l'en-tête n'a de sens que sur une réponse servie en
# HTTPS ; son absence en HTTP local n'est pas une erreur, c'est dit autrement.
EN_TETES_SECURITE = (
    {'nom': 'content-security-policy',
     'gravite': 'avertissement', 'https_uniquement': False,
     'role': 'Limite les origines d’où la page peut charger ses scripts, styles '
             'et images : c’est la principale défense contre une injection de '
             'script qui tournerait malgré une faille applicative.',
     'conseil': "Content-Security-Policy: default-src 'self'; "
                "script-src 'self'; object-src 'none'; base-uri 'self'; "
                "frame-ancestors 'none'"},
    {'nom': 'x-content-type-options', 'valeur_attendue': 'nosniff',
     'gravite': 'erreur', 'https_uniquement': False,
     'role': 'Interdit au navigateur de deviner le type d’un document : sans '
             'lui, un fichier téléversé peut être exécuté comme du JavaScript.',
     'conseil': 'X-Content-Type-Options: nosniff'},
    {'nom': 'x-frame-options', 'gravite': 'avertissement',
     'https_uniquement': False,
     'role': 'Empêche l’encadrement de la page par un site tiers, donc le '
             'détournement de clic. La directive frame-ancestors de la CSP le '
             'remplace avantageusement.',
     'conseil': 'X-Frame-Options: DENY   (ou frame-ancestors \'none\' en CSP)'},
    {'nom': 'strict-transport-security', 'gravite': 'erreur',
     'https_uniquement': True,
     'role': 'Force HTTPS pour toutes les visites suivantes : sans lui, la '
             'première requête en HTTP peut être interceptée.',
     'conseil': 'Strict-Transport-Security: max-age=31536000; includeSubDomains'},
    {'nom': 'referrer-policy', 'gravite': 'info', 'https_uniquement': False,
     'role': 'Contrôle ce que le site destinataire d’un lien reçoit comme '
             'adresse d’origine ; par défaut l’URL complète peut fuir.',
     'conseil': 'Referrer-Policy: strict-origin-when-cross-origin'},
    {'nom': 'permissions-policy', 'gravite': 'info', 'https_uniquement': False,
     'role': 'Désactive les API sensibles (caméra, micro, géolocalisation) que '
             'la page n’utilise pas, y compris dans ses iframes.',
     'conseil': 'Permissions-Policy: camera=(), microphone=(), geolocation=()'},
    {'nom': 'cross-origin-opener-policy', 'gravite': 'info',
     'https_uniquement': False,
     'role': 'Isole la fenêtre des autres origines et protège des fuites par '
             'canal auxiliaire (Spectre).',
     'conseil': 'Cross-Origin-Opener-Policy: same-origin'},
    {'nom': 'cross-origin-resource-policy', 'gravite': 'info',
     'https_uniquement': False,
     'role': 'Contrôle qui peut charger cette ressource depuis une autre '
             'origine.',
     'conseil': 'Cross-Origin-Resource-Policy: same-origin'},
)

# En-têtes qui TRAHISSENT le serveur : leur présence est une information, pas
# une faute, mais ils facilitent le ciblage d'une version vulnérable.
EN_TETES_BAVARDS = ('server', 'x-powered-by', 'x-aspnet-version',
                    'x-generator', 'x-drupal-cache', 'x-runtime')

# Motifs dangereux dans le code de la page, avec la raison.
MOTIFS_DANGEREUX = (
    {'motif': r'\beval\s*\(', 'langage': 'javascript', 'gravite': 'erreur',
     'code': 'eval',
     'raison': 'eval exécute une chaîne comme du code : toute donnée qui y '
               'arrive devient une injection de script.',
     'conseil': 'JSON.parse pour des données, Function() jamais sur une saisie, '
                'et un objet de correspondance pour un mini-langage.'},
    {'motif': r'\bnew\s+Function\s*\(', 'langage': 'javascript',
     'gravite': 'avertissement', 'code': 'new-function',
     'raison': 'new Function() est un eval déguisé, et il est bloqué par une '
               'CSP sans \'unsafe-eval\'.',
     'conseil': 'Remplacez par une table de correspondance de fonctions.'},
    {'motif': r'\bdocument\.write\s*\(', 'langage': 'javascript',
     'gravite': 'avertissement', 'code': 'document-write',
     'raison': 'document.write réécrit le document après son chargement et '
               'bloque le rendu ; sur une page déjà chargée il efface tout.',
     'conseil': 'createElement + append, ou insertAdjacentHTML sur une cible.'},
    {'motif': r'\.innerHTML\s*=\s*[^;]*[+`]', 'langage': 'javascript',
     'gravite': 'avertissement', 'code': 'innerhtml-concatene',
     'raison': 'innerHTML alimenté par concaténation interprète du HTML : si '
               'une donnée vient de l’utilisateur, c’est une injection.',
     'conseil': 'textContent pour du texte, ou échapper avant d’insérer.'},
    {'motif': r'javascript\s*:', 'langage': 'html', 'gravite': 'erreur',
     'code': 'url-javascript',
     'raison': 'Une URL javascript: exécute du code au clic et contourne la '
               'plupart des filtres.',
     'conseil': 'Un gestionnaire d’événement, jamais une URL javascript:.'},
    {'motif': r'<\s*script[^>]*\ssrc\s*=\s*["\']?http://', 'langage': 'html',
     'gravite': 'erreur', 'code': 'script-http',
     'raison': 'Un script chargé en HTTP clair peut être remplacé en route par '
               'qui contrôle le réseau.',
     'conseil': 'https://, ou // pour suivre le protocole de la page.'},
    {'motif': r'<\s*form[^>]*action\s*=\s*["\']?http://', 'langage': 'html',
     'gravite': 'erreur', 'code': 'formulaire-http',
     'raison': 'Un formulaire envoyé en HTTP clair transmet les saisies, mots '
               'de passe compris, sans chiffrement.',
     'conseil': 'action en https://, ou relative.'},
    {'motif': r'<\s*meta[^>]+http-equiv\s*=\s*["\']?refresh', 'langage': 'html',
     'gravite': 'avertissement', 'code': 'meta-refresh',
     'raison': 'Une redirection par meta refresh casse le bouton retour et '
               'l’accessibilité ; elle n’est pas suivie par tous les clients.',
     'conseil': 'Une redirection côté serveur (301/302).'},
)

# Fichiers de configuration reconnus pour la déclaration d'en-têtes, avec le
# motif qui prouve qu'un en-tête y est bien posé.
CONFIGURATIONS_EN_TETES = (
    {'fichier': '.htaccess', 'motif': r'Header\s+(?:always\s+)?set\s+"?%s"?',
     'note': 'Apache : Header set …'},
    {'fichier': 'nginx.conf', 'motif': r'add_header\s+%s\b',
     'note': 'nginx : add_header …'},
    {'fichier': '_headers', 'motif': r'^\s*%s\s*:', 'note': 'Netlify : _headers'},
    {'fichier': 'vercel.json', 'motif': r'"key"\s*:\s*"%s"',
     'note': 'Vercel : vercel.json'},
    {'fichier': 'web.config', 'motif': r'name="%s"',
     'note': 'IIS : web.config'},
)

# ------------------------------------------------------------------- poids ----
BUDGETS = {
    'page_octets': (1_000_000, 3_000_000),       # ok / avertissement / erreur
    'requetes': (30, 80),
    'image_octets': (200_000, 1_000_000),
    'script_octets': (300_000, 1_000_000),
    'feuille_octets': (100_000, 400_000),
    'police_octets': (150_000, 500_000),
}

# Types MIME compressibles : pour eux, l'audit estime ce qu'économiserait gzip.
COMPRESSIBLES = ('text/', 'application/javascript', 'application/json',
                 'application/xml', 'image/svg+xml', 'application/manifest+json')

EXTENSIONS_IMAGES = ('.png', '.jpg', '.jpeg', '.gif', '.webp', '.avif',
                     '.bmp', '.ico', '.svg')
EXTENSIONS_POLICES = ('.woff2', '.woff', '.ttf', '.otf', '.eot')
EXTENSIONS_SCRIPTS = ('.js', '.mjs', '.cjs')
EXTENSIONS_STYLES = ('.css',)

# ------------------------------------------------------------------ CSS -------
# Propriétés CSS reconnues. Une propriété absente de cette liste est signalée
# comme INFORMATION avec la mention explicite que la liste peut être en retard :
# affirmer « propriété inconnue » comme une erreur ferait accuser du code
# correct dès qu'une propriété nouvelle sort.
PROPRIETES_CSS = frozenset((
    'accent-color', 'align-content', 'align-items', 'align-self', 'all',
    'animation', 'animation-composition', 'animation-delay',
    'animation-direction', 'animation-duration', 'animation-fill-mode',
    'animation-iteration-count', 'animation-name', 'animation-play-state',
    'animation-timing-function', 'animation-range', 'animation-range-end',
    'animation-range-start', 'appearance', 'aspect-ratio', 'azimuth',
    'backdrop-filter', 'backface-visibility', 'background', 'background-attachment',
    'background-blend-mode', 'background-clip', 'background-color',
    'background-image', 'background-origin', 'background-position',
    'background-position-x', 'background-position-y', 'background-repeat',
    'background-size', 'block-size', 'border', 'border-block',
    'border-block-color', 'border-block-end', 'border-block-end-color',
    'border-block-end-style', 'border-block-end-width', 'border-block-start',
    'border-block-start-color', 'border-block-start-style',
    'border-block-start-width', 'border-block-style', 'border-block-width',
    'border-bottom', 'border-bottom-color', 'border-bottom-left-radius',
    'border-bottom-right-radius', 'border-bottom-style', 'border-bottom-width',
    'border-collapse', 'border-color', 'border-end-end-radius',
    'border-end-start-radius', 'border-image', 'border-image-outset',
    'border-image-repeat', 'border-image-slice', 'border-image-source',
    'border-image-width', 'border-inline', 'border-inline-color',
    'border-inline-end', 'border-inline-end-color', 'border-inline-end-style',
    'border-inline-end-width', 'border-inline-start',
    'border-inline-start-color', 'border-inline-start-style',
    'border-inline-start-width', 'border-inline-style', 'border-inline-width',
    'border-left', 'border-left-color', 'border-left-style', 'border-left-width',
    'border-radius', 'border-right', 'border-right-color', 'border-right-style',
    'border-right-width', 'border-spacing', 'border-start-end-radius',
    'border-start-start-radius', 'border-style', 'border-top',
    'border-top-color', 'border-top-left-radius', 'border-top-right-radius',
    'border-top-style', 'border-top-width', 'border-width', 'bottom',
    'box-decoration-break', 'box-shadow', 'box-sizing', 'break-after',
    'break-before', 'break-inside', 'caption-side', 'caret-color', 'caret-shape',
    'clear', 'clip', 'clip-path', 'clip-rule', 'color', 'color-interpolation',
    'color-interpolation-filters', 'color-scheme', 'column-count', 'column-fill',
    'column-gap', 'column-rule', 'column-rule-color', 'column-rule-style',
    'column-rule-width', 'column-span', 'column-width', 'columns', 'contain',
    'contain-intrinsic-block-size', 'contain-intrinsic-height',
    'contain-intrinsic-inline-size', 'contain-intrinsic-size',
    'contain-intrinsic-width', 'container', 'container-name', 'container-type',
    'content', 'content-visibility', 'counter-increment', 'counter-reset',
    'counter-set', 'cursor', 'cx', 'cy', 'd', 'direction', 'display',
    'dominant-baseline', 'empty-cells', 'field-sizing', 'fill', 'fill-opacity',
    'fill-rule', 'filter', 'flex', 'flex-basis', 'flex-direction',
    'flex-flow', 'flex-grow', 'flex-shrink', 'flex-wrap', 'float', 'flood-color',
    'flood-opacity', 'font', 'font-family', 'font-feature-settings',
    'font-kerning', 'font-language-override', 'font-optical-sizing',
    'font-palette', 'font-size', 'font-size-adjust', 'font-stretch',
    'font-style', 'font-synthesis', 'font-synthesis-small-caps',
    'font-synthesis-style', 'font-synthesis-weight', 'font-variant',
    'font-variant-alternates', 'font-variant-caps', 'font-variant-east-asian',
    'font-variant-emoji', 'font-variant-ligatures', 'font-variant-numeric',
    'font-variant-position', 'font-variation-settings', 'font-weight',
    'forced-color-adjust', 'gap', 'grid', 'grid-area', 'grid-auto-columns',
    'grid-auto-flow', 'grid-auto-rows', 'grid-column', 'grid-column-end',
    'grid-column-start', 'grid-row', 'grid-row-end', 'grid-row-start',
    'grid-template', 'grid-template-areas', 'grid-template-columns',
    'grid-template-rows', 'hanging-punctuation', 'height', 'hyphens',
    'image-orientation', 'image-rendering', 'inline-size',
    'inset', 'inset-block', 'inset-block-end', 'inset-block-start',
    'inset-inline', 'inset-inline-end', 'inset-inline-start', 'isolation',
    'justify-content', 'justify-items', 'justify-self', 'left', 'letter-spacing',
    'lighting-color', 'line-break', 'line-clamp', 'line-height', 'list-style',
    'list-style-image', 'list-style-position', 'list-style-type', 'margin',
    'margin-block', 'margin-block-end', 'margin-block-start', 'margin-bottom',
    'margin-inline', 'margin-inline-end', 'margin-inline-start', 'margin-left',
    'margin-right', 'margin-top', 'marker', 'marker-end', 'marker-mid',
    'marker-start', 'mask', 'mask-clip', 'mask-composite', 'mask-image',
    'mask-mode', 'mask-origin', 'mask-position', 'mask-repeat', 'mask-size',
    'mask-type', 'math-depth', 'math-style', 'max-block-size', 'max-height',
    'max-inline-size', 'max-width', 'min-block-size', 'min-height',
    'min-inline-size', 'min-width', 'mix-blend-mode', 'object-fit',
    'object-position', 'object-view-box', 'offset', 'offset-anchor',
    'offset-distance', 'offset-path', 'offset-position', 'offset-rotate',
    'opacity', 'order', 'orphans', 'outline', 'outline-color', 'outline-offset',
    'outline-style', 'outline-width', 'overflow', 'overflow-anchor',
    'overflow-block', 'overflow-clip-margin', 'overflow-inline',
    'overflow-wrap', 'overflow-x', 'overflow-y', 'overscroll-behavior',
    'overscroll-behavior-block', 'overscroll-behavior-inline',
    'overscroll-behavior-x', 'overscroll-behavior-y', 'padding',
    'padding-block', 'padding-block-end', 'padding-block-start',
    'padding-bottom', 'padding-inline', 'padding-inline-end',
    'padding-inline-start', 'padding-left', 'padding-right', 'padding-top',
    'page', 'page-break-after', 'page-break-before', 'page-break-inside',
    'paint-order', 'perspective', 'perspective-origin', 'place-content',
    'place-items', 'place-self', 'pointer-events', 'position', 'print-color-adjust',
    'quotes', 'r', 'resize', 'right', 'rotate', 'row-gap', 'rx', 'ry',
    'scale', 'scroll-behavior', 'scroll-margin', 'scroll-margin-block',
    'scroll-margin-block-end', 'scroll-margin-block-start',
    'scroll-margin-bottom', 'scroll-margin-inline', 'scroll-margin-inline-end',
    'scroll-margin-inline-start', 'scroll-margin-left', 'scroll-margin-right',
    'scroll-margin-top', 'scroll-padding', 'scroll-padding-block',
    'scroll-padding-block-end', 'scroll-padding-block-start',
    'scroll-padding-bottom', 'scroll-padding-inline',
    'scroll-padding-inline-end', 'scroll-padding-inline-start',
    'scroll-padding-left', 'scroll-padding-right', 'scroll-padding-top',
    'scroll-snap-align', 'scroll-snap-stop', 'scroll-snap-type',
    'scroll-timeline', 'scroll-timeline-axis', 'scroll-timeline-name',
    'scrollbar-color', 'scrollbar-gutter', 'scrollbar-width', 'shape-image-threshold',
    'shape-margin', 'shape-outside', 'shape-rendering', 'speak', 'src',
    'stop-color', 'stop-opacity', 'stroke', 'stroke-dasharray',
    'stroke-dashoffset', 'stroke-linecap', 'stroke-linejoin', 'stroke-miterlimit',
    'stroke-opacity', 'stroke-width', 'tab-size', 'table-layout', 'text-align',
    'text-align-last', 'text-anchor', 'text-combine-upright', 'text-decoration',
    'text-decoration-color', 'text-decoration-line', 'text-decoration-skip-ink',
    'text-decoration-style', 'text-decoration-thickness', 'text-emphasis',
    'text-emphasis-color', 'text-emphasis-position', 'text-emphasis-style',
    'text-indent', 'text-justify', 'text-orientation', 'text-overflow',
    'text-rendering', 'text-shadow', 'text-transform', 'text-underline-offset',
    'text-underline-position', 'text-wrap', 'text-wrap-mode', 'text-wrap-style',
    'top', 'touch-action', 'transform', 'transform-box', 'transform-origin',
    'transform-style', 'transition', 'transition-behavior',
    'transition-delay', 'transition-duration', 'transition-property',
    'transition-timing-function', 'translate', 'unicode-bidi', 'user-select',
    'vector-effect', 'vertical-align', 'view-timeline', 'view-timeline-axis',
    'view-timeline-name', 'view-transition-class', 'view-transition-name',
    'visibility', 'white-space', 'white-space-collapse', 'widows', 'width',
    'will-change', 'word-break', 'word-spacing', 'word-wrap',
    'writing-mode', 'x', 'y', 'z-index', 'zoom',
))

# Préfixes vendeurs acceptés sans vérification de la liste.
PREFIXES_VENDEURS = ('-webkit-', '-moz-', '-ms-', '-o-', '-apple-', '-khtml-')

# Valeurs de propriétés dont l'unité est suspecte : `0px`, `0em`, `0%` sont
# valides mais `0` suffit ; c'est une information, jamais une erreur.
UNITES_ZERO = ('px', 'em', 'rem', '%', 'pt', 'cm', 'mm', 'in', 'pc', 'vh',
               'vw', 'vmin', 'vmax', 'ch', 'ex')

# ---------------------------------------------------------------- métadonnées --
LONGUEUR_TITRE = (10, 60)
LONGUEUR_DESCRIPTION = (70, 160)

# Gravités choisies avec soin : rien ici n'empêche la page de fonctionner. Une
# métadonnée sociale manquante est un AVERTISSEMENT au plus — la déclarer
# « erreur » ferait baisser la note d'une page parfaitement valide et mettrait
# en doute la note entière.
OPENGRAPH = (
    ('og:title', 'avertissement', 'Titre partagé sur les réseaux sociaux.'),
    ('og:description', 'avertissement', 'Description partagée.'),
    ('og:image', 'avertissement',
     'Image partagée : sans elle, l’aperçu social est vide.'),
    ('og:url', 'info', 'Adresse canonique du partage.'),
    ('og:type', 'info', 'Type de contenu (website, article, product…).'),
    ('og:site_name', 'info', 'Nom du site, affiché sous le titre partagé.'),
    ('og:locale', 'info', 'Langue du contenu partagé.'),
)

TWITTER = (
    ('twitter:card', 'avertissement', 'Type de carte (summary, summary_large_image).'),
    ('twitter:title', 'info', 'Titre de la carte.'),
    ('twitter:description', 'info', 'Description de la carte.'),
    ('twitter:image', 'info', 'Image de la carte.'),
)

CONTEXTES_JSONLD = ('https://schema.org', 'http://schema.org',
                    'https://schema.org/')

# ---------------------------------------------------------------- viewports ---
VIEWPORTS = (
    {'id': 'mobile-s', 'nom': 'Mobile étroit', 'categorie': 'mobile',
     'largeur': 320, 'hauteur': 568, 'dpr': 2,
     'note': 'Le plus petit écran encore courant (iPhone SE 1re génération). '
             'Ce qui casse ici casse partout.'},
    {'id': 'mobile', 'nom': 'Mobile', 'categorie': 'mobile',
     'largeur': 375, 'hauteur': 667, 'dpr': 2,
     'note': 'Largeur de référence du mobile, celle des maquettes.'},
    {'id': 'mobile-l', 'nom': 'Mobile large', 'categorie': 'mobile',
     'largeur': 414, 'hauteur': 896, 'dpr': 3, 'note': 'Grands téléphones.'},
    {'id': 'pliable', 'nom': 'Pliable déplié', 'categorie': 'mobile',
     'largeur': 673, 'hauteur': 841, 'dpr': 2,
     'note': 'Écran intérieur d’un téléphone pliable : une largeur intermédiaire '
             'que la plupart des grilles oublient.'},
    {'id': 'tablette', 'nom': 'Tablette portrait', 'categorie': 'tablette',
     'largeur': 768, 'hauteur': 1024, 'dpr': 2, 'note': 'Point de passage classique.'},
    {'id': 'tablette-paysage', 'nom': 'Tablette paysage', 'categorie': 'tablette',
     'largeur': 1024, 'hauteur': 768, 'dpr': 2, 'note': ''},
    {'id': 'portable', 'nom': 'Portable', 'categorie': 'bureau',
     'largeur': 1366, 'hauteur': 768, 'dpr': 1,
     'note': 'Résolution d’écran la plus répandue au monde.'},
    {'id': 'bureau', 'nom': 'Bureau', 'categorie': 'bureau',
     'largeur': 1600, 'hauteur': 900, 'dpr': 1, 'note': ''},
    {'id': 'large', 'nom': 'Écran large', 'categorie': 'bureau',
     'largeur': 1920, 'hauteur': 1080, 'dpr': 1,
     'note': 'Vérifiez que le texte ne s’étale pas en lignes trop longues.'},
    {'id': 'ultra', 'nom': 'Ultra-large', 'categorie': 'bureau',
     'largeur': 2560, 'hauteur': 1440, 'dpr': 1, 'note': ''},
    {'id': 'impression', 'nom': 'Impression A4', 'categorie': 'autre',
     'largeur': 794, 'hauteur': 1123, 'dpr': 1,
     'note': 'Largeur d’une page A4 à 96 dpi : utile pour une feuille '
             '@media print.'},
)

# Points de rupture conseillés par les générateurs ; ils correspondent aux
# largeurs réelles ci-dessus, pas à des valeurs rondes arbitraires.
POINTS_RUPTURE = (480, 768, 1024, 1280, 1600)


def verifier_listes():
    """Contrôle interne : aucune liste ne doit contenir de doublon ou de majuscule.

    Un rôle ARIA écrit « Button » rendrait la règle muette et l'audit
    d'accessibilité accuserait à tort un code correct. Le banc appelle cette
    fonction ; elle est aussi exécutable directement.
    """
    problemes = []

    def controler(nom, collection, valeurs=False):
        """Vérifie la casse des identifiants, et les doublons d'une séquence.

        Les VALEURS d'un dictionnaire sont des phrases françaises qui
        commencent légitimement par une majuscule : les contrôler aussi ferait
        accuser la documentation. Seules les clefs (et, quand `valeurs` est
        demandé, les listes de valeurs qui sont comparées en minuscules par les
        audits) sont examinées.

        Un doublon n'est cherché que dans une séquence : un dictionnaire ou un
        ensemble ne peut pas en contenir, et l'affirmer donnerait un contrôle
        décoratif qui rassure sans rien vérifier.
        """
        clefs = list(collection)
        vus = set()
        for clef in clefs:
            elements = clef if isinstance(clef, tuple) else (clef,)
            for element in elements:
                if (isinstance(element, str) and element != element.lower()
                        and not element.startswith('http')):
                    problemes.append('%s : « %s » n’est pas en minuscules, '
                                     'la règle ne correspondra jamais'
                                     % (nom, element))
            identifiant = tuple(elements)
            if isinstance(collection, (list, tuple)):
                if identifiant in vus:
                    problemes.append('%s : « %s » apparaît deux fois'
                                     % (nom, clef))
            vus.add(identifiant)
        if valeurs:
            for clef, liste in collection.items():
                vus2 = set()
                for element in liste:
                    if element != element.lower():
                        problemes.append('%s[%s] : « %s » n’est pas en minuscules'
                                         % (nom, clef, element))
                    if element in vus2:
                        problemes.append('%s[%s] : « %s » apparaît deux fois'
                                         % (nom, clef, element))
                    vus2.add(element)

    controler('ROLES_ARIA', ROLES_ARIA)
    controler('ATTRIBUTS_ARIA', ATTRIBUTS_ARIA)
    controler('ELEMENTS_OBSOLETES', ELEMENTS_OBSOLETES)
    controler('INTERACTIFS', INTERACTIFS)
    controler('PARENTS_OBLIGATOIRES', PARENTS_OBLIGATOIRES, valeurs=True)
    controler('ENFANTS_TABLE', ENFANTS_TABLE)
    controler('PROPRIETES_CSS', PROPRIETES_CSS)
    controler('PREFIXES_VENDEURS', PREFIXES_VENDEURS)
    controler('ATTRIBUTS_OBSOLETES', ATTRIBUTS_OBSOLETES)
    controler('EN_TETES_BAVARDS', EN_TETES_BAVARDS)
    controler('EXTENSIONS_IMAGES', EXTENSIONS_IMAGES)
    controler('OPENGRAPH', [c[0] for c in OPENGRAPH])
    controler('TWITTER', [c[0] for c in TWITTER])
    controler('CONTENU_BRUT', CONTENU_BRUT)
    for en_tete in EN_TETES_SECURITE:
        if en_tete['nom'] != en_tete['nom'].lower():
            problemes.append('EN_TETES_SECURITE : %s n’est pas en minuscules'
                             % en_tete['nom'])
    for motif in MOTIFS_DANGEREUX:
        if motif['gravite'] not in ('erreur', 'avertissement', 'info'):
            problemes.append('MOTIFS_DANGEREUX : gravité inconnue %s'
                             % motif['gravite'])
        try:
            __import__('re').compile(motif['motif'])
        except Exception as exc:
            problemes.append('MOTIFS_DANGEREUX : motif %s invalide (%s)'
                             % (motif['code'], exc))
    identifiants = [v['id'] for v in VIEWPORTS]
    if len(identifiants) != len(set(identifiants)):
        problemes.append('VIEWPORTS : identifiants en double')
    for vue in VIEWPORTS:
        for cle in ('id', 'nom', 'categorie', 'largeur', 'hauteur', 'dpr', 'note'):
            if cle not in vue:
                problemes.append('VIEWPORTS : %s sans champ %s' % (vue.get('id'), cle))
        if not (100 <= vue['largeur'] <= 8000 and 100 <= vue['hauteur'] <= 8000):
            problemes.append('VIEWPORTS : %s a des dimensions invraisemblables'
                             % vue['id'])
    for cle, seuils in BUDGETS.items():
        if not (isinstance(seuils, tuple) and len(seuils) == 2
                and seuils[0] < seuils[1]):
            problemes.append('BUDGETS : %s mal formé' % cle)
    return problemes


if __name__ == '__main__':
    import sys

    defauts = verifier_listes()
    if defauts:
        for defaut in defauts:
            print('ÉCHEC :', defaut)
        sys.exit(1)
    print('devweb_references : %d rôles ARIA, %d attributs aria-*, '
          '%d éléments obsolètes, %d propriétés CSS, %d en-têtes de sécurité, '
          '%d motifs dangereux, %d viewports — listes cohérentes.'
          % (len(ROLES_ARIA), len(ATTRIBUTS_ARIA), len(ELEMENTS_OBSOLETES),
             len(PROPRIETES_CSS), len(EN_TETES_SECURITE),
             len(MOTIFS_DANGEREUX), len(VIEWPORTS)))
