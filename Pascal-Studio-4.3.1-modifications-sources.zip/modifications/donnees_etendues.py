#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
donnees_etendues.py — les formats de données étendus de l'éditeur d'onglet (4.0.0).

Trois rôles :

  1. RECONNAÎTRE un fichier de données par sa SIGNATURE et non par sa seule
     extension. Une base SQLite nommée « export.dat » est une base SQLite ; un
     fichier nommé « notes.sqlite » qui contient du texte n'en est pas une. Dans
     les deux cas l'ancienne règle se trompait, et le second produisait un onglet
     rempli de binaire illisible.
  2. LIRE les classeurs XLSX et ODS et les documents XML comme des tables, avec
     leurs feuilles ou leurs éléments répétitifs comme tables, et leurs cellules
     comme cases modifiables.
  3. INTERROGER ces formats par SQL, alors qu'ils n'ont aucun langage de
     requête : les tables sont chargées dans un miroir SQLite en mémoire, donc le
     champ de requête et le panneau de résultats fonctionnent de la même façon
     pour un classeur, un CSV, un XML et une vraie base.

HONNÊTETÉ SUR LES LIMITES. Un miroir SQLite est une COPIE en lecture : une
requête qui modifie (INSERT, UPDATE, DELETE, CREATE) ne touche pas le fichier
d'origine, et ce module le refuse explicitement au lieu de laisser croire que le
classeur a été changé. Les modifications du classeur passent par l'édition de
cases, de lignes, de colonnes et de feuilles, qui elles sont écrites pour de vrai.

Aucune dépendance hors bibliothèque standard pour l'ODS et l'XML : un classeur
ODS est une archive ZIP contenant content.xml, et la bibliothèque standard sait
lire les deux. XLSX passe par openpyxl quand il est installé ; absent, le module
le dit au lieu d'échouer obscurément.

Style : ce module suit l'indentation à quatre espaces, contrairement à
database_tools.py qui est à une espace. Les deux sont lisibles par Python, et
mélanger les styles dans un même fichier serait pire que cette différence.
"""

import copy
import mimetypes
import os
import re
import sqlite3
import zipfile
from pathlib import Path
from xml.etree import ElementTree

MARQUEUR = 'ps-4.0.0-donnees'

# ---------------------------------------------------------------------------
# Reconnaissance
# ---------------------------------------------------------------------------

SQLITE_AMORCE = b'SQLite format 3\x00'
ZIP_AMORCE = b'PK\x03\x04'
XML_AMORCES = (b'<?xml', b'\xef\xbb\xbf<?xml', b'\xff\xfe<\x00', b'\x00<\x00?')

EXTENSIONS_BASES = ('.sqlite', '.sqlite3', '.db', '.db3')
EXTENSIONS_TABLEUR = ('.xlsx', '.xlsm', '.ods')
EXTENSIONS_TEXTE = ('.csv', '.tsv', '.json', '.sql', '.xml')
EXTENSIONS_DONNEES = EXTENSIONS_BASES + EXTENSIONS_TABLEUR + EXTENSIONS_TEXTE

# Bornes reprises de database_tools.py : un onglet qui afficherait plus que cela
# deviendrait inutilisable avant même d'être utile.
MAX_LIGNES = 5000
MAX_COLONNES = 200
MAX_CELLULE = 100_000
LECTURE_SIGNATURE = 65_536


class DonneesRefusees(ValueError):
    """Un fichier qui n'est pas une donnée exploitable, avec la raison."""


def _amorce(chemin, taille=LECTURE_SIGNATURE):
    try:
        with open(chemin, 'rb') as fichier:
            return fichier.read(taille)
    except OSError as erreur:
        raise DonneesRefusees('Fichier illisible : %s' % erreur)


def _conteneur_zip(chemin):
    """XLSX, ODS, ou autre archive : le contenu tranche, pas l'extension."""
    try:
        with zipfile.ZipFile(chemin) as archive:
            noms = set(archive.namelist())
    except (zipfile.BadZipFile, OSError):
        return 'zip-invalide'
    if 'mimetype' in noms:
        try:
            with zipfile.ZipFile(chemin) as archive:
                type_mime = archive.read('mimetype')[:128].decode(
                    'ascii', 'replace').strip()
        except (OSError, zipfile.BadZipFile):
            type_mime = ''
        if 'opendocument.spreadsheet' in type_mime:
            return 'ods'
    if 'xl/workbook.xml' in noms or '[Content_Types].xml' in noms:
        return 'xlsx'
    if 'content.xml' in noms:
        return 'ods'
    return 'zip-autre'


def famille(chemin):
    """La famille réelle d'un fichier, d'après sa signature d'abord.

    Renvoie un dictionnaire :
      famille   sqlite | xlsx | ods | xml | csv | json | sql | texte | inconnu
      extension ce que le nom laissait croire
      accord    True si la signature confirme l'extension
      raison    ce qui a décidé, lisible

    Ne lève jamais : un fichier fantaisiste donne « inconnu » avec sa raison, et
    l'appelant décide. C'est ce qui permet d'ouvrir un fichier non reconnu COMME
    DU TEXTE en le disant, au lieu d'échouer.
    """
    chemin = Path(chemin)
    extension = chemin.suffix.lower()
    if not chemin.is_file():
        return {'famille': 'inconnu', 'extension': extension, 'accord': False,
                'raison': 'fichier introuvable'}
    amorce = _amorce(chemin)
    if amorce.startswith(SQLITE_AMORCE):
        return {'famille': 'sqlite', 'extension': extension,
                'accord': extension in EXTENSIONS_BASES or not extension,
                'raison': 'amorce « SQLite format 3 »'}
    if amorce.startswith(ZIP_AMORCE):
        contenu = _conteneur_zip(chemin)
        if contenu in ('xlsx', 'ods'):
            return {'famille': contenu, 'extension': extension,
                    'accord': extension in EXTENSIONS_TABLEUR,
                    'raison': 'archive ZIP contenant %s' % contenu}
        return {'famille': 'zip-autre', 'extension': extension,
                'accord': False,
                'raison': 'archive ZIP qui n’est ni un classeur XLSX ni un ODS'}
    if any(amorce.startswith(a) for a in XML_AMORCES):
        return {'famille': 'xml', 'extension': extension,
                'accord': extension == '.xml',
                'raison': 'déclaration XML en tête'}
    if extension == '.xml':
        return {'famille': 'xml', 'extension': extension, 'accord': True,
                'raison': 'extension .xml sans déclaration : analysé comme XML'}
    if extension in ('.csv', '.tsv'):
        return {'famille': 'csv', 'extension': extension, 'accord': True,
                'raison': 'extension %s' % extension}
    if extension == '.json':
        return {'famille': 'json', 'extension': extension, 'accord': True,
                'raison': 'extension .json'}
    if extension == '.sql':
        return {'famille': 'sql', 'extension': extension, 'accord': True,
                'raison': 'extension .sql'}
    if extension in EXTENSIONS_BASES:
        # Le nom promet une base, le contenu n'en est pas une. Le dire est plus
        # utile que d'ouvrir un onglet de binaire illisible.
        return {'famille': 'texte', 'extension': extension, 'accord': False,
                'raison': 'l’extension annonce une base SQLite mais l’amorce '
                          'n’est pas « SQLite format 3 » : ce fichier est ouvert '
                          'comme texte'}
    try:
        amorce.decode('utf-8')
        return {'famille': 'texte', 'extension': extension, 'accord': False,
                'raison': 'aucune signature de données reconnue : texte'}
    except UnicodeDecodeError:
        return {'famille': 'inconnu', 'extension': extension, 'accord': False,
                'raison': 'aucune signature reconnue et contenu non décodable en '
                          'UTF-8 : binaire, à ouvrir avec l’outil approprié'}


# ---------------------------------------------------------------------------
# Lecture des classeurs et de l'XML
# ---------------------------------------------------------------------------

def _nettoyer_nom(nom, indice):
    """Un nom de table exploitable en SQL, sans jamais mentir sur l'origine."""
    base = re.sub(r'[^\w]+', '_', str(nom or '').strip(), flags=re.UNICODE)
    base = base.strip('_')[:60]
    if not base:
        base = 'feuille'
    if base[0].isdigit():
        base = '_' + base
    return base or ('table_%d' % indice)


def _nom_table_unique(nom, deja_pris):
    """Un nom de table qui ne se confond avec aucun autre du même fichier.

    Nécessaire, et pas seulement pour le confort : deux feuilles « Feuille 1 » et
    « Feuille-1 » donnent toutes les deux « feuille_1 » après `_nettoyer_nom`, et
    deux éléments `<h>` sous des parents différents portent le même nom. Sans
    cette règle, le miroir SQL jetait la seconde table en silence — un SELECT
    dessus rendait les données de l'autre — et l'écrivain ne savait pas laquelle
    des deux il devait modifier. Le suffixe `_2`, `_3`… suit la règle déjà
    employée pour les colonnes en collision.
    """
    base, rang = nom, 2
    while nom.lower() in deja_pris:
        nom = '%s_%d' % (base, rang)
        rang += 1
    deja_pris.add(nom.lower())
    return nom


def _separer_entete(lignes):
    """Reconnaît la première ligne comme en-tête de colonnes, ou non.

    Règle prudente, et son pourquoi : une feuille de classeur commence presque
    toujours par des titres, et sans cette séparation le miroir SQL nommait les
    colonnes « colonne_1 », « colonne_2 »… — donc « SELECT nom FROM Clients »
    échouait sur un classeur qui contient bien une colonne « nom ».

    Mais il ne faut pas non plus MANGER une première ligne de données : un
    relevé de mesures purement numériques n'a pas d'en-tête. La première ligne
    n'est donc prise comme en-tête que si toutes ses cases sont non vides, si
    aucune n'est un simple nombre, et si les valeurs sont distinctes. Le résultat
    est annoncé par le drapeau « entete », pour que l'interface puisse dire ce
    qu'elle a fait au lieu de le laisser deviner.
    """
    if not lignes:
        return [], [], False
    premiere = [str(v).strip() for v in lignes[0]]
    if not premiere or any(v == '' for v in premiere):
        return ['colonne_%d' % (i + 1) for i in range(
            max(len(l) for l in lignes))], lignes, False
    if len(set(premiere)) != len(premiere):
        return ['colonne_%d' % (i + 1) for i in range(
            max(len(l) for l in lignes))], lignes, False
    for valeur in premiere:
        if re.match(r'^-?\d+(?:[.,]\d+)?$', valeur):
            return ['colonne_%d' % (i + 1) for i in range(
                max(len(l) for l in lignes))], lignes, False
    return premiere, lignes[1:], True


def _bornes(lignes, nom):
    if len(lignes) > MAX_LIGNES:
        raise DonneesRefusees(
            '%s : %d lignes, la limite de l’onglet est %d.'
            % (nom, len(lignes), MAX_LIGNES))
    for ligne in lignes:
        if len(ligne) > MAX_COLONNES:
            raise DonneesRefusees(
                '%s : %d colonnes, la limite de l’onglet est %d.'
                % (nom, len(ligne), MAX_COLONNES))


def lire_xlsx(chemin):
    """Les feuilles d'un classeur XLSX, comme tables.

    Les formules sont lues par leur VALEUR CALCULÉE et non par leur texte :
    openpyxl en mode data_only rend le dernier résultat enregistré par Excel.
    Pour un fichier jamais ouvert par Excel, ces cellules valent None, et c'est
    annoncé plutôt que masqué.
    """
    try:
        import openpyxl
    except ImportError:
        raise DonneesRefusees(
            'openpyxl n’est pas installé : les classeurs XLSX ne peuvent pas '
            'être lus. Installez-le, ou convertissez le classeur en CSV.')
    try:
        classeur = openpyxl.load_workbook(str(chemin), data_only=True,
                                          read_only=True)
    except Exception as erreur:
        raise DonneesRefusees('classeur XLSX illisible : %s' % erreur)
    tables = []
    vus = set()
    # DÉTECTÉ et non supposé, comme pour l'ODS : un classeur à formules lu en
    # mode « valeurs calculées » doit le dire, sinon l'interface propose
    # d'enregistrer et les formules seraient remplacées par leurs valeurs.
    formules = _possede_formules(chemin)
    try:
        for indice, nom in enumerate(classeur.sheetnames, 1):
            feuille = classeur[nom]
            lignes = []
            for ligne in feuille.iter_rows(values_only=True):
                valeurs = ['' if v is None else _cellule(v) for v in ligne]
                while valeurs and valeurs[-1] == '':
                    valeurs.pop()
                lignes.append(valeurs)
            while lignes and not lignes[-1]:
                lignes.pop()
            _bornes(lignes, 'la feuille « %s »' % nom)
            colonnes, donnees, entete = _separer_entete(lignes)
            tables.append({'nom': _nom_table_unique(_nettoyer_nom(nom, indice), vus),
                           'titre': nom,
                           'colonnes': colonnes, 'lignes': donnees,
                           'entete': entete, 'formules': formules})
    finally:
        classeur.close()
    if not tables:
        raise DonneesRefusees('classeur XLSX sans aucune feuille.')
    return tables


def _cellule(valeur):
    """Une cellule en texte, sans perte visible ni notation scientifique."""
    if valeur is None:
        return ''
    if isinstance(valeur, bool):
        return 'true' if valeur else 'false'
    if isinstance(valeur, float):
        if valeur.is_integer() and abs(valeur) < 1e15:
            return str(int(valeur))
        return repr(valeur)
    texte = str(valeur)
    if len(texte) > MAX_CELLULE:
        raise DonneesRefusees(
            'une cellule dépasse %d caractères : elle n’est pas éditable dans '
            'l’onglet.' % MAX_CELLULE)
    return texte


def lire_ods(chemin):
    """Les feuilles d'un classeur ODS, sans dépendance : ZIP puis content.xml."""
    try:
        with zipfile.ZipFile(str(chemin)) as archive:
            contenu = archive.read('content.xml')
    except (zipfile.BadZipFile, KeyError, OSError) as erreur:
        raise DonneesRefusees('classeur ODS illisible : %s' % erreur)
    try:
        racine = ElementTree.fromstring(contenu)
    except ElementTree.ParseError as erreur:
        raise DonneesRefusees('content.xml invalide : %s' % erreur)
    espace = {'table': 'urn:oasis:names:tc:opendocument:xmlns:table:1.0',
              'text': 'urn:oasis:names:tc:opendocument:xmlns:text:1.0',
              'office': 'urn:oasis:names:tc:opendocument:xmlns:office:1.0'}
    tables = []
    vus = set()
    # Détecté, pas supposé : annoncer « pas de formules » sans les chercher
    # ferait passer pour éditable un classeur qui ne l'est pas.
    formules = _possede_formules_ods(chemin)
    feuilles = racine.findall('.//table:table', espace)
    for indice, feuille in enumerate(feuilles, 1):
        nom = feuille.get('{%s}name' % espace['table']) or 'feuille%d' % indice
        lignes = []
        for ligne in feuille.findall('table:table-row', espace):
            repetees = int(ligne.get('{%s}number-rows-repeated'
                                     % espace['table']) or 1)
            valeurs = []
            for cellule in ligne.findall('table:table-cell', espace):
                repeets = int(cellule.get('{%s}number-columns-repeated'
                                          % espace['table']) or 1)
                texte = ''.join(cellule.itertext())
                # Une répétition énorme en fin de ligne est l'artefact classique
                # de l'ODS : la borner évite de fabriquer des milliers de
                # colonnes vides.
                repeets = min(repeets, MAX_COLONNES)
                valeurs.extend([texte] * repeets)
            while valeurs and valeurs[-1] == '':
                valeurs.pop()
            if valeurs or repetees <= 1:
                for _ in range(min(repetees, MAX_LIGNES)):
                    lignes.append(list(valeurs))
        while lignes and not lignes[-1]:
            lignes.pop()
        _bornes(lignes, 'la feuille « %s »' % nom)
        colonnes, donnees, entete = _separer_entete(lignes)
        tables.append({'nom': _nom_table_unique(_nettoyer_nom(nom, indice), vus),
                       'titre': nom,
                       'colonnes': colonnes, 'lignes': donnees,
                       'entete': entete, 'formules': formules})
    if not tables:
        raise DonneesRefusees('classeur ODS sans aucune feuille.')
    return tables


def _nom_colonne_xml(brut, deja_pris, prefixe=False):
    """Un nom de colonne SQL pour un attribut ou un enfant XML.

    Les noms XML peuvent porter un espace de noms, des espaces ou des tirets :
    « {http://…}prénom-client » doit devenir un identifiant qu'un SELECT
    accepte sans guillemets. Les accents sont conservés — la classe de
    caractères « mot » de Python les admet en Unicode — et seul ce qui n'est
    pas admis dans un identifiant est remplacé par un tiret bas.

    `prefixe` ajoute « @ », la notation XML d'un attribut, uniquement quand un
    enfant porte déjà le même nom : sans cela l'un des deux serait masqué.
    """
    base = re.sub(r'[^\w]+', '_', str(brut or ''), flags=re.UNICODE).strip('_')[:60]
    if not base:
        base = 'colonne'
    if base[0].isdigit():
        base = '_' + base
    if prefixe:
        base = '@' + base
    nom, i = base, 2
    while nom.lower() in deja_pris:
        nom = '%s_%d' % (base, i)
        i += 1
    deja_pris.add(nom.lower())
    return nom


def lire_xml(chemin):
    """Un document XML comme tables.

    La règle est simple et annoncée : chaque élément qui se répète au moins deux
    fois sous un même parent devient une table. Ses colonnes sont ses ATTRIBUTS
    puis ses ENFANTS feuilles, et son texte propre ne devient une colonne
    « valeur » que s'il existe vraiment — un document écrit
    <contact id="1" nom="Ada"/> n'a aucun enfant, et ne regarder que les enfants
    produisait une table d'une seule colonne « valeur » remplie de vides.

    Un document sans aucune répétition ne devient pas une table : il est renvoyé
    vide, et l'appelant l'ouvre comme texte en le disant. Deviner une structure
    tabulaire là où il n'y en a pas produirait un tableau faux, ce qui est pire
    qu'un refus. C'est aussi pourquoi rien n'est tronqué en silence : au-delà
    des limites, _bornes refuse et le dit, au lieu de rendre une table amputée
    qui aurait l'air complète.
    """
    try:
        arbre = ElementTree.parse(str(chemin))
    except (ElementTree.ParseError, OSError) as erreur:
        raise DonneesRefusees('document XML invalide : %s' % erreur)
    racine = arbre.getroot()
    tables, _plans = _tables_xml(racine)
    return tables


def _tables_xml(racine):
    """La découverte des tables d'un document XML, partagée par la lecture et
    l'écriture.

    Factorisée et non dupliquée : si l'écrivain rediscouvrait les tables avec son
    propre code, la moindre divergence d'ordre ou de règle lui ferait écrire dans
    les mauvais éléments — et le fichier serait abîmé sans erreur. Une seule
    découverte garantit que lire puis écrire retombe sur les mêmes éléments, dans
    le même ordre.

    Rend (tables, plans). Les tables sont ce que l'interface affiche ; les plans
    portent les objets Element et ne sortent jamais du module.
    """
    comptes = {}
    for parent in racine.iter():
        for enfant in parent:
            # Un commentaire ou une instruction de traitement a un `tag` qui
            # n'est pas une chaîne (c'est la fonction fabrique). Le compter
            # produirait une « table » fantôme, et _local() lèverait dessus.
            if not isinstance(enfant.tag, str):
                continue
            comptes.setdefault((parent, enfant.tag), 0)
            comptes[(parent, enfant.tag)] += 1
    tables = []
    plans = []
    noms_tables = set()
    for (parent, etiquette), nombre in comptes.items():
        if nombre < 2:
            continue
        elements = [e for e in parent if e.tag == etiquette]
        attributs, enfants, texte_present = [], [], False
        for element in elements:
            for nom in element.attrib:
                if nom not in attributs:
                    attributs.append(nom)
            for enfant in element:
                if len(enfant) == 0 and enfant.tag not in enfants:
                    enfants.append(enfant.tag)
            if (element.text or '').strip():
                texte_present = True
        # Trois listes parallèles : le nom brut (celui que ElementTree connaît),
        # la nature de la colonne (pour savoir où lire la valeur) et le nom
        # affiché (celui que le SQL utilisera).
        bruts, natures, affiches = [], [], []
        pris = set()
        locaux_enfants = {_local(n) for n in enfants}
        for nom in attributs:
            loc = _local(nom)
            bruts.append(nom)
            natures.append('attribut')
            affiches.append(_nom_colonne_xml(loc, pris, prefixe=loc in locaux_enfants))
        for nom in enfants:
            bruts.append(nom)
            natures.append('enfant')
            affiches.append(_nom_colonne_xml(_local(nom), pris))
        if texte_present or not bruts:
            bruts.append(None)
            natures.append('texte')
            affiches.append(_nom_colonne_xml('valeur', pris))
        lignes = []
        for element in elements:
            ligne = []
            for brut, nature in zip(bruts, natures):
                if nature == 'texte':
                    ligne.append((element.text or '').strip())
                elif nature == 'attribut':
                    valeur = element.get(brut)
                    ligne.append('' if valeur is None else valeur.strip())
                else:
                    trouve = element.find(brut)
                    ligne.append((trouve.text or '').strip()
                                 if trouve is not None and len(trouve) == 0 else '')
            lignes.append(ligne)
        _bornes(lignes, 'l’élément « %s »' % etiquette)
        # Deux éléments différents peuvent porter le même nom sous des parents
        # distincts (<g><h/><h/></g> répété). Sans cette désambiguïsation, le
        # miroir SQL jetait la seconde table en silence — un SELECT dessus
        # rendait les données de l'autre — et l'écrivain ne savait pas laquelle
        # des deux il devait modifier. Le suffixe suit la règle déjà employée
        # pour les colonnes en collision.
        nom = _nom_table_unique(_nettoyer_nom(_local(etiquette), len(tables) + 1),
                                noms_tables)
        tables.append({'nom': nom, 'titre': _local(etiquette), 'lignes': lignes,
                       'colonnes': affiches,
                       'entete': True, 'formules': False})
        # Le PLAN D'ÉCRITURE : où sont les éléments et comment chaque colonne y
        # est rangée. Jamais rendu à l'interface (des objets Element ne se
        # sérialisent pas en JSON), mais sans lui l'écrivain devrait redeviner la
        # structure et pourrait écrire au mauvais endroit.
        plans.append({'nom': nom, 'parent': parent,
                      'etiquette': etiquette, 'elements': elements,
                      'bruts': bruts, 'natures': natures,
                      'affiches': affiches})
    return tables, plans


def _local(etiquette):
    """Le nom sans son espace de noms : « {http://…}livre » devient « livre »."""
    return etiquette.rsplit('}', 1)[-1] if '}' in etiquette else etiquette


# ---------------------------------------------------------------------------
# Écriture XML
# ---------------------------------------------------------------------------

XML_BOM = b'\xef\xbb\xbf'
XML_DECLARATION = re.compile(rb'<\?xml\b.*?\?>', re.S)
XML_ENCODING = re.compile(rb'encoding\s*=\s*["\']([^"\']+)["\']')
XML_STANDALONE = re.compile(r'standalone\s*=\s*["\'](\w+)["\']')
XML_ESPACES = re.compile(r'xmlns(?::([\w.-]+))?\s*=\s*"([^"]+)"')
# Les jetons autorisés avant l'élément racine : déclaration, DOCTYPE (avec ou
# sans sous-ensemble interne), commentaires, instructions de traitement, espaces.
XML_JETON = re.compile(
    rb'\s*(<\?xml\b.*?\?>|<!DOCTYPE[^>\[]*(?:\[[^\]]*\])?[^>]*>|<!--.*?-->|<\?[^>]*?\?>)',
    re.S)

REFUS_FORMULES_XLSX = (
    'Ce classeur contient des formules. Réécrire par-dessus les remplacerait par '
    'leurs dernières valeurs calculées et perdrait styles et graphiques. '
    'Enregistrez une copie CSV, ou modifiez le classeur dans son application '
    'd’origine.')
REFUS_FORMULES_ODS = (
    'Ce classeur ODS contient des formules. Réécrire par-dessus les remplacerait '
    'par leurs dernières valeurs calculées. Enregistrez une copie CSV, ou '
    'modifiez le classeur dans son application d’origine.')
REFUS_OPENPYXL = (
    'openpyxl absent : l’écriture XLSX est impossible. Installez-le '
    '(apt install python3-openpyxl), ou enregistrez une copie CSV depuis le '
    'classeur.')


def _parser_conservateur():
    """Un analyseur qui CONSERVE les commentaires.

    L'analyseur par défaut les jette : réécrire un document avec lui effacerait
    tous les commentaires de l'utilisateur, sans erreur et sans trace. C'est une
    perte silencieuse, exactement ce que ce module s'interdit.
    """
    return ElementTree.XMLParser(
        target=ElementTree.TreeBuilder(insert_comments=True))


def _lire_xml_brut(chemin):
    try:
        with open(str(chemin), 'rb') as fichier:
            brut = fichier.read()
    except OSError as erreur:
        raise DonneesRefusees('document XML illisible : %s' % erreur)
    return brut


def _encodage_declare(brut):
    """L'encodage réel du document : déclaré, ou déduit de l'amorce.

    Un document XML sans déclaration est en UTF-8, c'est la norme qui le dit.
    Mais un document en UTF-16 ne peut PAS être reconnu par sa déclaration :
    dans son amorce, chaque caractère ASCII est suivi d'un octet nul, donc la
    recherche de « <?xml » échoue et l'on conclurait « utf-8 » — c'est-à-dire
    exactement l'encodage qui est faux. La marque d'ordre des octets et l'amorce
    sont donc regardées d'abord. Nommer le bon encodage n'est pas un détail :
    c'est lui que le refus cite, et sans lui l'utilisateur ne sait pas quoi
    convertir.
    """
    if brut.startswith(b'\xff\xfe'):
        return 'utf-16-le'
    if brut.startswith(b'\xfe\xff'):
        return 'utf-16-be'
    if brut[:4] in (b'<\x00?\x00', b'\x00<\x00?') or brut[:6] == b'\xff\xfe<\x00?\x00':
        return 'utf-16'
    if brut.startswith(b'\x00\x00\xfe\xff') or brut.startswith(b'\xff\xfe\x00\x00'):
        return 'utf-32'
    declaration = XML_DECLARATION.search(brut[:4096])
    if not declaration:
        return 'utf-8'
    trouve = XML_ENCODING.search(declaration.group(0))
    return (trouve.group(1).decode('ascii', 'replace').strip().lower()
            if trouve else 'utf-8')


def _reencoder(morceau, encodage):
    """Un morceau recopié, transcodé en UTF-8 si l'original ne l'était pas.

    Recopier des octets Latin-1 dans un fichier dont la déclaration annonce
    désormais UTF-8 produirait un document invalide : le préambule et la queue
    sont donc transcodés, pas seulement recopiés.
    """
    if not morceau or encodage.replace('-', '').replace('_', '') in ('utf8', 'ascii', 'usascii'):
        return morceau
    try:
        return morceau.decode(encodage).encode('utf-8')
    except LookupError:
        raise DonneesRefusees(
            'encodage XML inconnu : « %s ». Le fichier n’a pas été modifié ; '
            'ouvrez-le comme texte pour l’éditer.' % encodage)
    except UnicodeError as erreur:
        raise DonneesRefusees(
            'le préambule de ce document XML n’est pas du « %s » valable (%s). '
            'Le fichier n’a pas été modifié.' % (encodage, erreur))


def _fin_racine_xml(brut, debut):
    """La position qui suit la balise fermante de la racine, ou -1.

    La racine est le dernier élément du document : en retirant de la fin les
    commentaires et les instructions de traitement un par un, on tombe
    nécessairement sur sa balise fermante — ou sur sa forme auto-fermante
    `<r/>`. Le travail est borné par la taille de ces jetons, pas par celle du
    document.

    Rendre -1 plutôt que deviner : une position fausse ferait recopier deux fois
    un morceau du document, ou en perdre un, et le fichier ne se relirait plus.
    """
    fin = len(brut)
    while fin > debut:
        k = brut.rfind(b'>', debut, fin)
        if k < 0:
            return -1
        if brut[max(debut, k - 2):k + 1] == b'-->':
            ouverture = brut.rfind(b'<!--', debut, k - 2)
            if ouverture < 0:
                return -1
            fin = ouverture
            continue
        if brut[max(debut, k - 1):k + 1] == b'?>':
            ouverture = brut.rfind(b'<?', debut, k - 1)
            if ouverture < 0:
                return -1
            fin = ouverture
            continue
        j = fin - 1
        while j > debut and brut[j:j + 1].isspace():
            j -= 1
        if brut[j:j + 1] != b'>':
            return -1
        ouverture = brut.rfind(b'<', debut, j)
        if ouverture < 0:
            return -1
        if brut.startswith(b'</', ouverture):
            return j + 1
        if ouverture == debut and brut[max(debut, j - 1):j + 1] == b'/>':
            return j + 1          # racine auto-fermante : <config/>
        return -1
    return -1


def _decouper_xml(brut):
    """Le document en trois morceaux : avant la racine, la racine, après.

    Renvoie `(devant, debut, fin, encodage)`, avec `debut` et `fin` en OCTETS.
    La réécriture ne remplace que la racine ; le reste est recopié tel quel.

    Pourquoi ce découpage plutôt qu'une régénération : ElementTree ne conserve
    RIEN de ce qui est hors de l'élément racine. Un commentaire placé avant ou
    après elle n'est nulle part dans l'arbre, donc `tostring()` l'efface ; le
    DOCTYPE et les instructions de traitement disparaissent de la même façon.
    Recopier les deux extrémités du fichier est le seul moyen de ne rien perdre
    en silence. Travailler en octets évite de dépendre de l'encodage déclaré
    pour les retrouver, et le transcodage est fait à part, une fois localisées.

    Si la racine ne peut pas être localisée — document tronqué, préambule en
    UTF-16, DOCTYPE inhabituel — la fonction refuse au lieu de deviner.
    """
    encodage = _encodage_declare(brut)
    # Une marque d'ordre des octets n'est pas un jeton : elle reste dans
    # `devant` et sera recopiée telle quelle, mais le parcours commence après.
    debut = len(XML_BOM) if brut.startswith(XML_BOM) else 0
    while True:
        jeton = XML_JETON.match(brut, debut)
        if not jeton:
            break
        debut = jeton.end()
    # Les espaces qui séparent le dernier jeton de la racine ne font partie
    # d'aucun jeton : ils restent dans `devant`, et `debut` doit pointer sur le
    # « < » de la racine elle-même.
    while debut < len(brut) and brut[debut:debut + 1].isspace():
        debut += 1
    if brut[debut:debut + 1] != b'<' or brut[debut:debut + 2] in (b'<!', b'<?'):
        raise DonneesRefusees(
            'l’élément racine de ce document XML n’a pas pu être localisé '
            '(encodage déclaré : « %s » ; la réécriture travaille en UTF-8). Le '
            'fichier n’a pas été modifié : convertissez-le en UTF-8, ou '
            'ouvrez-le comme texte pour l’éditer.' % encodage)
    fin = _fin_racine_xml(brut, debut)
    if fin < 0:
        raise DonneesRefusees(
            'la fin de l’élément racine de ce document XML n’a pas pu être '
            'localisée. Le fichier n’a pas été modifié : ouvrez-le comme texte '
            'pour l’éditer.')
    return brut[:debut], debut, fin, encodage


def _preambule_utf8(devant, encodage):
    """Le préambule recopié, avec une déclaration qui dit vrai.

    Le document est réécrit en UTF-8 : annoncer encore l'encodage d'origine
    ferait lire les nouveaux octets pour ce qu'ils ne sont pas. Le `standalone`
    d'origine est conservé, et tout le reste du préambule — DOCTYPE,
    commentaires, instructions de traitement, espaces — est recopié tel quel.
    Un document sans déclaration en reçoit une, puisque l'UTF-8 n'y est alors
    que supposé.
    """
    marque = b''
    reste = devant
    if reste.startswith(XML_BOM):
        marque, reste = XML_BOM, reste[len(XML_BOM):]
    entete = b'<?xml version="1.0" encoding="UTF-8"?>'
    declaration = XML_DECLARATION.search(reste)
    if declaration:
        autonome = XML_STANDALONE.search(
            declaration.group(0).decode('ascii', 'replace'))
        if autonome:
            entete = ('<?xml version="1.0" encoding="UTF-8" standalone="%s"?>'
                      % autonome.group(1)).encode('utf-8')
        reste = reste[:declaration.start()] + entete + reste[declaration.end():]
    else:
        reste = entete + b'\n' + reste
    return marque + _reencoder(reste, encodage)


def ecriture_possible(chemin):
    """(possible, raison) — vérifié à l'OUVERTURE, pas au premier enregistrement.

    Une grille qui se dit modifiable puis refuse d'enregistrer fait perdre le
    travail saisi. Tout ce qui interdirait l'écriture est donc vérifié ici : les
    formules d'un classeur, l'absence d'openpyxl pour XLSX, et un document XML
    dont la racine ne peut pas être localisée. La raison est une phrase qui dit
    quoi faire à la place, et non un code d'erreur.
    """
    detection = famille(chemin)
    genre = detection['famille']
    try:
        if genre == 'xlsx':
            try:
                import openpyxl
            except ImportError:
                return False, REFUS_OPENPYXL
            # Vérifié sur la classe que l'écrivain emploie vraiment : un openpyxl
            # présent mais cassé doit être annoncé, pas découvert à
            # l'enregistrement.
            if not getattr(openpyxl, 'Workbook', None):
                return False, REFUS_OPENPYXL
            return (False, REFUS_FORMULES_XLSX) if _possede_formules(chemin) else (True, '')
        if genre == 'ods':
            return (False, REFUS_FORMULES_ODS) if _possede_formules_ods(chemin) else (True, '')
        if genre == 'xml':
            _decouper_xml(_lire_xml_brut(chemin))
            return True, ''
    except DonneesRefusees as erreur:
        return False, str(erreur)
    return False, ('« %s » n’est ni un classeur ni un document XML (%s) : ce '
                   'format ne s’édite pas comme une table.'
                   % (Path(chemin).name, detection['raison']))


def _nom_enfant_xml(colonne):
    """Un nom de colonne redevient un nom XML valide.

    La normalisation est EXACTEMENT celle de `_nom_colonne_xml`, dans l'autre
    sens : sans cela une colonne ajoutée serait relue sous un autre nom, et la
    deuxième écriture verrait une colonne supprimée plus une colonne ajoutée
    alors que l'utilisateur n'a rien changé. La stabilité du nom fait partie du
    résultat, pas du confort.

    Un préfixe « @ » demande un ATTRIBUT, la notation que le lecteur utilise
    quand un attribut et un enfant portent le même nom. Sans cette convention,
    une colonne ajoutée ne saurait pas où aller.
    """
    attribut = str(colonne).startswith('@')
    brut = str(colonne)[1:] if attribut else str(colonne)
    nom = re.sub(r'[^\w]+', '_', brut, flags=re.UNICODE).strip('_')[:60]
    if not nom:
        raise DonneesRefusees('nom de colonne XML invalide : %r' % (colonne,))
    if nom[0].isdigit():
        nom = '_' + nom
    return attribut, nom


def _valeur_colonne_xml(element, brut, nature, valeur):
    """Écrit UNE valeur dans l'élément, à l'endroit où le lecteur l'a prise."""
    texte = '' if valeur is None else str(valeur)
    if len(texte) > MAX_CELLULE:
        raise DonneesRefusees(
            'cellule de %d caractères : la limite de l’onglet est %d.'
            % (len(texte), MAX_CELLULE))
    if nature == 'texte':
        element.text = texte
    elif nature == 'attribut':
        if texte == '' and brut in element.attrib:
            # Un attribut vide n'a pas de sens en XML : absent plutôt que vide,
            # sinon la relecture rendrait une colonne de plus qu'à l'écriture.
            del element.attrib[brut]
        else:
            element.set(brut, texte)
    else:
        enfant = element.find(brut)
        if enfant is None:
            enfant = ElementTree.SubElement(element, brut)
        if len(enfant) > 0:
            raise DonneesRefusees(
                'l’élément « %s » a des enfants : ce n’est pas une valeur '
                'modifiable comme une case.' % _local(brut))
        enfant.text = texte


def _ecrire_table_xml(plan, table):
    """Reporte une table éditée sur les éléments XML qui la portaient."""
    parent = plan['parent']
    elements = list(plan['elements'])
    bruts, natures = list(plan['bruts']), list(plan['natures'])
    affiches = list(plan['affiches'])
    colonnes = [str(c) for c in (table.get('colonnes') or [])]
    lignes = [list(l) for l in (table.get('lignes') or [])]
    _bornes(lignes, 'l’élément « %s »' % _local(plan['etiquette']))

    # Colonnes supprimées : retirées de TOUS les éléments, sinon elles
    # réapparaîtraient à la relecture et la suppression semblerait n'avoir rien
    # fait.
    for indice, affiche in enumerate(affiches):
        if affiche in colonnes:
            continue
        brut, nature = bruts[indice], natures[indice]
        for element in elements:
            if nature == 'attribut':
                element.attrib.pop(brut, None)
            elif nature == 'enfant':
                for enfant in element.findall(brut):
                    element.remove(enfant)

    # Colonnes conservées et ajoutées, appariées PAR NOM et non par position :
    # une colonne insérée au milieu ne doit pas décaler toutes les autres.
    plan_colonnes = []
    for colonne in colonnes:
        if colonne in affiches:
            indice = affiches.index(colonne)
            plan_colonnes.append((bruts[indice], natures[indice], False))
        else:
            attribut, nom = _nom_enfant_xml(colonne)
            plan_colonnes.append((nom, 'attribut' if attribut else 'enfant', True))

    # Lignes en trop : les éléments correspondants sont retirés du parent.
    while len(elements) > len(lignes):
        element = elements.pop()
        indice = list(parent).index(element)
        if indice > 0:
            # Le retrait laisse sinon le « tail » (saut de ligne et indentation)
            # de l'élément disparu, et le document se creuse d'une ligne vide à
            # chaque suppression.
            parent[indice - 1].tail = element.tail
        parent.remove(element)

    # Lignes ajoutées : un élément neuf, de la même forme que le dernier.
    while len(elements) < len(lignes):
        if elements:
            nouveau = copy.deepcopy(elements[-1])
            for cle in list(nouveau.attrib):
                del nouveau.attrib[cle]
            for enfant in list(nouveau):
                nouveau.remove(enfant)
            nouveau.text = None
        else:
            nouveau = ElementTree.Element(plan['etiquette'])
        if len(elements):
            dernier = elements[-1]
            nouveau.tail = dernier.tail
            dernier_index = list(parent).index(dernier)
            parent.insert(dernier_index + 1, nouveau)
        else:
            parent.append(nouveau)
        elements.append(nouveau)

    for element, ligne in zip(elements, lignes):
        valeurs = dict(zip(colonnes, ligne))
        for colonne, (brut, nature, _neuf) in zip(colonnes, plan_colonnes):
            _valeur_colonne_xml(element, brut, nature, valeurs.get(colonne, ''))
    plan['elements'] = elements


def ecrire_xml(chemin, tables, supprimees=()):
    """Réécrit un document XML EN PLACE, sans réinventer sa structure.

    Pourquoi « en place » et non « régénéré » : le lecteur ne découvre qu'une
    PARTIE du document — les éléments qui se répètent au moins deux fois sous un
    même parent. Réécrire le document à partir des seules tables découvertes
    jetterait tout le reste : la racine, les éléments solitaires, les
    commentaires, les espaces de noms. Le fichier s'ouvrirait encore, mais il
    aurait perdu l'essentiel de son contenu, sans erreur nulle part.

    Ici, le document est rechargé, la découverte est REJOUÉE par le même code que
    la lecture (`_tables_xml`, d'où la factorisation), et seules les valeurs des
    éléments découverts sont modifiées. Les commentaires sont conservés grâce à
    un analyseur qui ne les jette pas, et la déclaration comme le DOCTYPE sont
    restitués.

    Une table du document qui n'est pas dans `tables` n'est PAS supprimée : elle
    est laissée telle quelle. La suppression d'un ensemble d'éléments ne se
    déduit jamais d'une absence — un appelant qui n'envoie que la table qu'il
    vient d'éditer ne demande pas la disparition des autres — elle passe par
    `supprimees`, la liste des tables que l'utilisateur a explicitement retirées.

    Ce que l'opération ne sait pas faire, et qu'elle NOMME au lieu de le deviner :
    ajouter une table à un document (rien ne dit où mettre les nouveaux
    éléments), et renommer une colonne (le nom affiché est dérivé du nom XML par
    une règle à sens unique). Le document reste alors intact, et l'éditeur de
    texte — qui reste disponible pour le XML — permet les deux.
    """
    if not isinstance(tables, list):
        raise DonneesRefusees('écrire un XML exige une liste de tables, pas %s.'
                              % type(tables).__name__)
    fournis = _noms_tables(tables, 'un document XML')
    a_supprimer = _noms_supprimes(supprimees, fournis, 'un document XML')
    brut = _lire_xml_brut(chemin)
    try:
        racine = ElementTree.fromstring(brut, parser=_parser_conservateur())
    except ElementTree.ParseError as erreur:
        raise DonneesRefusees('document XML invalide : %s' % erreur)
    for prefixe, uri in XML_ESPACES.findall(brut.decode('utf-8', 'replace')):
        try:
            ElementTree.register_namespace(prefixe, uri)
        except ValueError:
            pass
    _tables, plans = _tables_xml(racine)
    par_nom = {plan['nom']: plan for plan in plans}

    def _proches(nom):
        return [autre for autre in par_nom if autre.lower() == nom.lower()]

    for nom in fournis:
        if nom in par_nom:
            continue
        homonymes = _proches(nom)
        if homonymes:
            raise DonneesRefusees(
                'la table « %s » n’existe pas dans ce document, qui contient '
                '« %s » : la casse du nom compte.' % (nom, ' », « '.join(homonymes)))
        raise DonneesRefusees(
            'la table « %s » ne correspond à aucun élément répété de ce '
            'document. Ajouter une table à un XML n’est pas pris en charge : '
            'rien ne dit où placer ses éléments. Ouvrez le fichier comme '
            'texte pour le faire.' % nom)
    for nom in a_supprimer:
        if nom not in par_nom:
            raise DonneesRefusees(
                'la table « %s » à supprimer n’existe pas dans ce document. '
                'Rechargez-le : la liste affichée n’est plus à jour.' % nom)

    for table in tables:
        _ecrire_table_xml(par_nom[str(table['nom'])], table)

    for nom in a_supprimer:
        plan = par_nom[nom]
        parent = plan['parent']
        for element in plan['elements']:
            try:
                indice = list(parent).index(element)
            except ValueError:
                continue
            if indice > 0:
                # Sans ce rappel, le saut de ligne et l'indentation portés par
                # l'élément retiré disparaissent avec lui et le document se
                # resserre d'une ligne à chaque suppression.
                parent[indice - 1].tail = element.tail
            parent.remove(element)

    devant, debut, fin, encodage = _decouper_xml(brut)
    entete = _preambule_utf8(devant, encodage)
    queue = _reencoder(brut[fin:], encodage)
    corps = ElementTree.tostring(racine, encoding='utf-8')
    mode = _mode_actuel(chemin)
    temporaire = str(chemin) + '.part'
    try:
        with open(temporaire, 'wb') as fichier:
            fichier.write(entete)
            fichier.write(corps)
            fichier.write(queue)
            if not queue and not corps.endswith(b'\n'):
                fichier.write(b'\n')
        os.replace(temporaire, str(chemin))
    except OSError as erreur:
        try:
            os.unlink(temporaire)
        except OSError:
            pass
        raise DonneesRefusees('écriture XML impossible : %s' % erreur)
    _retablir_mode(chemin, mode)
    return str(chemin)

def lire(chemin):
    """Les tables d'un fichier de données étendu, quelle que soit sa famille."""
    detection = famille(chemin)
    if detection['famille'] == 'xlsx':
        return lire_xlsx(chemin), detection
    if detection['famille'] == 'ods':
        return lire_ods(chemin), detection
    if detection['famille'] == 'xml':
        return lire_xml(chemin), detection
    raise DonneesRefusees(
        '« %s » n’est pas un classeur ni un document XML (%s).'
        % (Path(chemin).name, detection['raison']))


# ---------------------------------------------------------------------------
# Le miroir SQLite : un champ de requête et des résultats pour tous les formats
# ---------------------------------------------------------------------------

MODIFICATION_INTERDITE = re.compile(
    r'\b(insert|update|delete|drop|alter|create|replace|truncate|attach|'
    r'detach|pragma|vacuum|reindex|grant|revoke)\b', re.IGNORECASE)


def est_lecture_seule(sql):
    """Vrai si la requête ne peut rien modifier.

    Le miroir est une COPIE en mémoire : autoriser un INSERT laisserait croire
    que le classeur a été modifié, alors que rien ne serait écrit. Le refus est
    donc explicite et explique la vraie voie — l'édition de cases, de lignes et
    de colonnes, qui elle écrit le fichier.
    """
    texte = re.sub(r'--[^\n]*', ' ', str(sql or ''))
    texte = re.sub(r'/\*.*?\*/', ' ', texte, flags=re.DOTALL)
    texte = re.sub(r"'(?:[^']|'')*'", "''", texte)
    return not MODIFICATION_INTERDITE.search(texte)


def miroir(tables):
    """Un SQLite en mémoire chargé des tables, pour les interroger par SQL."""
    connexion = sqlite3.connect(':memory:')
    noms = []
    for table in tables:
        nom = table['nom']
        if nom in noms:
            continue
        noms.append(nom)
        colonnes = table.get('colonnes')
        lignes = table.get('lignes') or []
        if not colonnes:
            largeur = max((len(l) for l in lignes), default=0)
            colonnes = ['colonne_%d' % (i + 1) for i in range(largeur)]
        colonnes = [_nettoyer_nom(c, i + 1) if not re.match(r'^[A-Za-z_]\w*$', str(c))
                    else str(c) for i, c in enumerate(colonnes)]
        if not colonnes:
            colonnes = ['valeur']
        uniques = []
        for colonne in colonnes:
            base, rang = colonne, 2
            while colonne in uniques:
                colonne = '%s_%d' % (base, rang)
                rang += 1
            uniques.append(colonne)
        connexion.execute('CREATE TABLE "%s" (%s)' % (
            nom.replace('"', '""'),
            ', '.join('"%s" TEXT' % c.replace('"', '""') for c in uniques)))
        marqueurs = ', '.join('?' * len(uniques))
        for ligne in lignes:
            valeurs = list(ligne) + [''] * (len(uniques) - len(ligne))
            connexion.execute(
                'INSERT INTO "%s" VALUES (%s)'
                % (nom.replace('"', '""'), marqueurs),
                [str(v)[:MAX_CELLULE] for v in valeurs[:len(uniques)]])
    connexion.commit()
    return connexion


def interroger(tables, sql, limite=1000):
    """Exécute une requête en lecture seule sur le miroir.

    Renvoie {'colonnes', 'lignes', 'tronque', 'miroir'} — la clef « miroir »
    rappelle à l'interface que le résultat vient d'une copie et non du fichier.
    """
    if not str(sql or '').strip():
        raise DonneesRefusees('Requête vide.')
    if not est_lecture_seule(sql):
        raise DonneesRefusees(
            'Le champ de requête interroge une COPIE en mémoire du fichier : une '
            'modification n’y serait pas écrite et ferait croire à tort que le '
            'classeur a changé. Pour modifier, éditez les cases, les lignes, les '
            'colonnes ou les feuilles — ces changements, eux, sont écrits.')
    connexion = miroir(tables)
    try:
        curseur = connexion.execute(str(sql))
        colonnes = [d[0] for d in (curseur.description or [])]
        lignes = []
        tronque = False
        for ligne in curseur:
            if len(lignes) >= limite:
                tronque = True
                break
            lignes.append(['' if v is None else _cellule(v) for v in ligne])
        return {'colonnes': colonnes, 'lignes': lignes, 'tronque': tronque,
                'miroir': True, 'tables': [t['nom'] for t in tables]}
    except sqlite3.Error as erreur:
        raise DonneesRefusees('Requête refusée par SQLite : %s' % erreur)
    finally:
        connexion.close()


# ---------------------------------------------------------------------------
# Écriture : ce qui modifie vraiment le fichier
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Les règles communes aux trois écrivains (XLSX, ODS, XML)
# ---------------------------------------------------------------------------

def _noms_tables(tables, quoi):
    """Vérifie une liste de tables et en rend les noms, dans l'ordre.

    Vérifiée ici et non dans chaque écrivain : une table sans nom, ou deux tables
    de même nom, feraient écrire au mauvais endroit sans erreur.
    """
    if not isinstance(tables, list):
        raise DonneesRefusees('écrire %s exige une liste de tables, pas %s.'
                              % (quoi, type(tables).__name__))
    noms = []
    for table in tables:
        if not isinstance(table, dict) or not str(table.get('nom') or '').strip():
            raise DonneesRefusees(
                'table invalide pour %s : %r — un nom est obligatoire.'
                % (quoi, table))
        noms.append(str(table['nom']))
    doublons = sorted({n for n in noms if noms.count(n) > 1})
    if doublons:
        raise DonneesRefusees(
            'plusieurs tables de %s portent le même nom (%s) : impossible de '
            'savoir laquelle écrire.'
            % (quoi, ', '.join('« %s »' % n for n in doublons)))
    return noms


def _noms_supprimes(supprimees, fournis, quoi):
    """Les tables que l'utilisateur a EXPLICITEMENT demandé de supprimer.

    La suppression n'est jamais déduite de l'absence : un appelant qui n'envoie
    que la feuille qu'il vient d'éditer ne demande pas la disparition des autres.
    """
    if supprimees is None:
        return []
    if isinstance(supprimees, (str, bytes)) or not isinstance(
            supprimees, (list, tuple, set, frozenset)):
        raise DonneesRefusees(
            '« supprimees » doit être une liste de noms de tables, pas %s.'
            % type(supprimees).__name__)
    noms = []
    for brut in supprimees:
        nom = str(brut)
        if nom in noms:
            continue
        if nom in fournis:
            raise DonneesRefusees(
                'la table « %s » de %s est à la fois fournie à écrire et '
                'demandée en suppression : laquelle des deux intentions est la '
                'bonne ?' % (nom, quoi))
        noms.append(nom)
    return noms


def _retablir_mode(chemin, mode):
    """Remet le mode d'origine après un `os.replace()`.

    Un fichier neuf hérite de l'umask : un classeur partagé en 0664 deviendrait
    0644 à chaque enregistrement, sans que rien ne le dise.
    """
    if mode is None:
        return
    try:
        os.chmod(str(chemin), mode)
    except OSError:
        pass


def _mode_actuel(chemin):
    try:
        return os.stat(str(chemin)).st_mode & 0o777 if Path(chemin).is_file() else None
    except OSError:
        return None


def _fusionner(chemin, tables, supprimees, lire, quoi):
    """Le jeu de tables COMPLET à écrire : celles qu'on reçoit, posées sur celles
    que le fichier contient déjà.

    C'est la garantie contre la perte la plus grave de tout ce module. Un
    classeur à cinq feuilles dont on n'envoie que la feuille éditée ne doit pas
    devenir un classeur d'une feuille : les feuilles non mentionnées sont
    CONSERVÉES telles quelles, dans leur ordre, et seule une demande explicite
    (`supprimees`) en retire une.

    Le fichier doit donc être RELU au moment d'écrire. S'il ne peut pas l'être,
    l'écriture est refusée et le fichier reste intact : écrire par-dessus sans
    l'avoir relu détruirait ce que la demande ne mentionne pas.
    """
    fournis = _noms_tables(tables, quoi)
    a_supprimer = _noms_supprimes(supprimees, fournis, quoi)
    existantes = []
    if Path(chemin).is_file():
        try:
            existantes = lire(chemin)
        except DonneesRefusees as erreur:
            raise DonneesRefusees(
                '%s n’a pas pu être relu pour être fusionné (%s) ; le fichier '
                'n’a pas été modifié. Écrire par-dessus sans le relire '
                'supprimerait les tables que cette demande ne mentionne pas.'
                % (Path(chemin).name, erreur))
    par_nom = {nom: table for nom, table in zip(fournis, tables)}
    noms_existants = [str(table['nom']) for table in existantes]

    def proches(nom):
        """Les tables du fichier qui ne diffèrent de `nom` que par la casse."""
        return [autre for autre in noms_existants if autre.lower() == nom.lower()]

    # L'appariement est EXACT. Un nom qui ne diffère que par la casse n'est pas
    # apparié en silence : il créerait une seconde table presque identique, et
    # l'utilisateur ne verrait que deux onglets au même titre. Le refus nomme les
    # deux écritures, ce qui dit immédiatement quoi corriger.
    for nom in fournis + a_supprimer:
        if nom in noms_existants:
            continue
        homonymes = proches(nom)
        if homonymes:
            raise DonneesRefusees(
                'la table « %s » n’existe pas dans %s, qui contient « %s » : la '
                'casse du nom compte. Écrire « %s » créerait une seconde table '
                'presque identique.'
                % (nom, Path(chemin).name, ' », « '.join(homonymes), nom))
    for nom in a_supprimer:
        if nom not in noms_existants:
            raise DonneesRefusees(
                'la table « %s » à supprimer n’existe pas dans %s. Rechargez le '
                'fichier : la liste affichée n’est plus à jour.'
                % (nom, Path(chemin).name))

    fusion = []
    vus = set()
    for table in existantes:
        nom = str(table['nom'])
        if nom in a_supprimer:
            continue
        fusion.append(par_nom.get(nom, table))
        vus.add(nom)
    for nom in fournis:
        if nom not in vus:
            fusion.append(par_nom[nom])
            vus.add(nom)
    return fusion


def ecrire_xlsx(chemin, tables, supprimees=()):
    """Réécrit un classeur XLSX après édition.

    Limitation assumée et annoncée : les formules, les styles, les graphiques et
    les macros du classeur d'origine ne sont pas conservés, parce que la lecture
    s'est faite en mode « valeurs calculées ». Réécrire par-dessus un classeur
    qui en contient perdrait ces éléments. C'est pourquoi l'écriture est refusée
    si le fichier source porte des formules, au lieu de les détruire en silence.

    Les feuilles qui ne sont pas mentionnées sont CONSERVÉES (`_fusionner`) : un
    appelant qui n'envoie que la feuille éditée ne demande pas la disparition des
    autres. Une suppression passe par `supprimees`.
    """
    try:
        import openpyxl
    except ImportError:
        raise DonneesRefusees(REFUS_OPENPYXL)
    if _possede_formules(chemin):
        raise DonneesRefusees(REFUS_FORMULES_XLSX)
    fusion = _fusionner(chemin, tables, supprimees, lire_xlsx, 'un classeur XLSX')
    classeur = openpyxl.Workbook()
    classeur.remove(classeur.active)
    pris = set()
    for indice, table in enumerate(fusion, 1):
        # La même règle de nommage que pour l'ODS : Excel et ODF interdisent les
        # mêmes caractères et la même longueur. Un titre brut ferait lever
        # openpyxl, et l'erreur remonterait comme un échec d'écriture alors que
        # le problème est un nom.
        titre = _nom_feuille_ods(table.get('titre') or table.get('nom'), indice, pris)
        feuille = classeur.create_sheet(title=titre)
        # `_lignes_a_ecrire` remet la ligne de titres quand le lecteur l'avait
        # séparée : sans elle, chaque enregistrement supprimait l'en-tête.
        for ligne in _lignes_a_ecrire(table):
            feuille.append([_ecrire_cellule(v) for v in ligne])
    if not classeur.sheetnames:
        classeur.create_sheet(title='Feuille1')
    mode = _mode_actuel(chemin)
    temporaire = str(chemin) + '.part'
    try:
        classeur.save(temporaire)
        os.replace(temporaire, str(chemin))
    except Exception as erreur:
        try:
            os.unlink(temporaire)
        except OSError:
            pass
        raise DonneesRefusees('écriture XLSX impossible : %s' % erreur)
    _retablir_mode(chemin, mode)
    return str(chemin)


def _possede_formules(chemin):
    try:
        import openpyxl
        classeur = openpyxl.load_workbook(str(chemin), data_only=False,
                                          read_only=True)
    except Exception:
        return False
    try:
        for feuille in classeur:
            for ligne in feuille.iter_rows(values_only=True):
                for valeur in ligne:
                    if isinstance(valeur, str) and valeur.startswith('='):
                        return True
    finally:
        classeur.close()
    return False


def _ecrire_cellule(valeur):
    """Un texte redevient un nombre quand il en est un, sans notation douteuse."""
    texte = '' if valeur is None else str(valeur)
    if texte in ('true', 'false'):
        return texte == 'true'
    if re.match(r'^-?\d{1,15}$', texte):
        return int(texte)
    if re.match(r'^-?\d*\.\d+$', texte):
        try:
            return float(texte)
        except ValueError:
            return texte
    return texte


# ---------------------------------------------------------------------------
# Écriture ODS
# ---------------------------------------------------------------------------
# Les espaces de noms d'un classeur ODS. ElementTree écrit « ns0: » par défaut,
# que les lecteurs ODF acceptent mal : les préfixes sont donc enregistrés, pour
# que le fichier produit ressemble à celui qui a été lu.
ODS_OFFICE = '{urn:oasis:names:tc:opendocument:xmlns:office:1.0}'
ODS_TABLE = '{urn:oasis:names:tc:opendocument:xmlns:table:1.0}'
ODS_TEXT = '{urn:oasis:names:tc:opendocument:xmlns:text:1.0}'
ODS_MANIFEST = '{urn:oasis:names:tc:opendocument:xmlns:manifest:1.0}'
ODS_MEDIA = 'application/vnd.oasis.opendocument.spreadsheet'
ODS_VERSION = '1.2'
for _prefixe, _uri in (
        ('office', 'urn:oasis:names:tc:opendocument:xmlns:office:1.0'),
        ('table', 'urn:oasis:names:tc:opendocument:xmlns:table:1.0'),
        ('text', 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'),
        ('manifest', 'urn:oasis:names:tc:opendocument:xmlns:manifest:1.0')):
    ElementTree.register_namespace(_prefixe, _uri)
del _prefixe, _uri

# Un classeur ODS est une archive : ces trois entrées sont réécrites, tout le
# reste (styles, métadonnées, images) est recopié tel quel pour ne pas le perdre.
ODS_REECRITES = ('mimetype', 'content.xml', 'META-INF/manifest.xml')


def _nom_feuille_ods(titre, indice, deja_pris):
    """Un nom de feuille ODS acceptable, et distinct de ses voisins.

    Les deux points-clefs : « : » est interdit dans un nom de feuille ODF, et
    deux feuilles homonymes font que le lecteur n'en ouvre qu'une — la seconde
    disparaîtrait sans message.
    """
    nom = re.sub(r'[\[\]:*?/\\]+', ' ', str(titre or '')).strip()[:60]
    if not nom:
        nom = 'feuille%d' % indice
    base, i = nom, 2
    while nom.lower() in deja_pris:
        suffixe = '_%d' % i
        nom = base[:60 - len(suffixe)] + suffixe
        i += 1
    deja_pris.add(nom.lower())
    return nom


def _cellule_ods(parent, valeur):
    """Une cellule ODS, avec son type écrit EXPLICITEMENT.

    Le type n'est jamais laissé à la déduction du lecteur : sans
    `office:value-type`, LibreOffice traite « 007 » comme le nombre 7 et « 1/2 »
    comme une date. Le texte affiché est le texte d'origine, mot pour mot, pour
    qu'un aller-retour lire/écrire/lire rende exactement ce qui était là.
    """
    cellule = ElementTree.SubElement(parent, ODS_TABLE + 'table-cell')
    texte = '' if valeur is None else str(valeur)
    if len(texte) > MAX_CELLULE:
        raise DonneesRefusees(
            'cellule de %d caractères : la limite de l’onglet est %d.'
            % (len(texte), MAX_CELLULE))
    if texte == '':
        cellule.set(ODS_OFFICE + 'value-type', 'string')
        return
    if texte in ('true', 'false'):
        cellule.set(ODS_OFFICE + 'value-type', 'boolean')
        cellule.set(ODS_OFFICE + 'boolean-value', texte)
    elif re.match(r'^-?\d{1,15}$', texte):
        cellule.set(ODS_OFFICE + 'value-type', 'float')
        cellule.set(ODS_OFFICE + 'value', str(int(texte)))
    elif re.match(r'^-?\d*\.\d+$', texte):
        cellule.set(ODS_OFFICE + 'value-type', 'float')
        cellule.set(ODS_OFFICE + 'value', texte)
    else:
        cellule.set(ODS_OFFICE + 'value-type', 'string')
    paragraphe = ElementTree.SubElement(cellule, ODS_TEXT + 'p')
    paragraphe.text = texte


def _lignes_a_ecrire(table):
    """Les lignes à écrire : l'en-tête d'abord, s'il y en a un.

    `lire_ods()` sépare la première ligne en `colonnes` quand elle ressemble à
    un en-tête, et met le reste dans `lignes`. Réécrire sans cette distinction
    ajouterait une ligne de titres à chaque enregistrement, ou supprimerait
    celle d'un tableau qui en a une — deux pertes silencieuses.
    """
    lignes = [list(l) for l in (table.get('lignes') or [])]
    if table.get('entete'):
        colonnes = list(table.get('colonnes') or [])
        if colonnes:
            lignes.insert(0, colonnes)
    _bornes(lignes, 'la feuille « %s »' % (table.get('titre') or table.get('nom')))
    return lignes


def _content_xml(tables):
    racine = ElementTree.Element(ODS_OFFICE + 'document-content')
    racine.set(ODS_OFFICE + 'version', ODS_VERSION)
    corps = ElementTree.SubElement(racine, ODS_OFFICE + 'body')
    classeur = ElementTree.SubElement(corps, ODS_OFFICE + 'spreadsheet')
    pris = set()
    for indice, table in enumerate(tables, 1):
        feuille = ElementTree.SubElement(classeur, ODS_TABLE + 'table')
        feuille.set(ODS_TABLE + 'name',
                    _nom_feuille_ods(table.get('titre') or table.get('nom'),
                                     indice, pris))
        for ligne in _lignes_a_ecrire(table):
            element_ligne = ElementTree.SubElement(feuille, ODS_TABLE + 'table-row')
            for valeur in ligne:
                _cellule_ods(element_ligne, valeur)
        if not (table.get('lignes') or []) and not table.get('entete'):
            # Une feuille vide doit tout de même avoir une ligne, sinon certains
            # lecteurs la rendent inutilisable et l'utilisateur croit l'avoir
            # perdue.
            ElementTree.SubElement(feuille, ODS_TABLE + 'table-row')
    if pris == set():
        feuille = ElementTree.SubElement(classeur, ODS_TABLE + 'table')
        feuille.set(ODS_TABLE + 'name', 'feuille1')
        ElementTree.SubElement(feuille, ODS_TABLE + 'table-row')
    return (b'<?xml version="1.0" encoding="UTF-8"?>\n'
            + ElementTree.tostring(racine, encoding='utf-8'))


def _manifeste_ods(noms):
    """Le manifeste liste TOUTES les entrées, y compris celles qui sont recopiées.

    Un manifeste qui omet styles.xml fait que LibreOffice ignore les styles du
    classeur sans rien dire : le fichier s'ouvre, mais il a perdu sa mise en
    forme.
    """
    racine = ElementTree.Element(ODS_MANIFEST + 'manifest')
    racine.set(ODS_MANIFEST + 'version', ODS_VERSION)

    def entree(chemin, media):
        element = ElementTree.SubElement(racine, ODS_MANIFEST + 'file-entry')
        element.set(ODS_MANIFEST + 'full-path', chemin)
        element.set(ODS_MANIFEST + 'media-type', media)

    entree('/', ODS_MEDIA)
    entree('content.xml', 'text/xml')
    for nom in noms:
        if nom.endswith('.xml'):
            media = 'text/xml'
        else:
            media = mimetypes.guess_type(nom)[0] or ''
        entree(nom, media)
    return (b'<?xml version="1.0" encoding="UTF-8"?>\n'
            + ElementTree.tostring(racine, encoding='utf-8'))


def _possede_formules_ods(chemin):
    """Vrai si le classeur ODS contient au moins une formule.

    DÉTECTÉ et non supposé : `lire_ods()` annonçait `formules: False` sans jamais
    regarder `table:formula`, donc un classeur à formules passait pour éditable
    et aurait été réécrit en valeurs — les formules perdues en silence, et
    l'interface affirmant qu'il n'y en avait pas.
    """
    try:
        with zipfile.ZipFile(str(chemin)) as archive:
            contenu = archive.read('content.xml')
    except (OSError, KeyError, zipfile.BadZipFile):
        return False
    try:
        racine = ElementTree.fromstring(contenu)
    except ElementTree.ParseError:
        return False
    cle = ODS_TABLE + 'formula'
    for element in racine.iter():
        if cle in element.attrib:
            return True
    return False


def ecrire_ods(chemin, tables, supprimees=()):
    """Réécrit un classeur ODS après édition, en bibliothèque standard.

    Trois exigences ODF, toutes vérifiées par le banc d'aller-retour :
      * l'entrée `mimetype` est la PREMIÈRE de l'archive et n'est PAS compressée,
        sinon LibreOffice refuse le fichier comme n'étant pas un document ODF ;
      * `META-INF/manifest.xml` liste toutes les entrées ;
      * chaque cellule porte son type.

    Ce qui est conservé et ce qui ne l'est pas : les entrées de l'archive qui ne
    sont pas `mimetype`, `content.xml` ni le manifeste (styles, métadonnées,
    images) sont RECOPIÉES telles quelles. Les formules, en revanche, ne peuvent
    pas l'être — l'édition s'est faite sur des valeurs — donc l'écriture est
    REFUSÉE si le classeur en contient, au lieu de les détruire en silence.

    L'écriture est atomique : un fichier `.part` puis `os.replace()`, pour qu'une
    interruption ne laisse jamais un classeur à moitié écrit. Le mode du fichier
    d'origine est rétabli, parce qu'un fichier neuf hérite de l'umask et qu'un
    classeur partagé en 0664 deviendrait 0644 sans ce rappel.
    """
    if not isinstance(tables, list):
        raise DonneesRefusees('écrire un ODS exige une liste de tables.')
    if _possede_formules_ods(chemin):
        raise DonneesRefusees(REFUS_FORMULES_ODS)
    fusion = _fusionner(chemin, tables, supprimees, lire_ods, 'un classeur ODS')
    try:
        contenu = _content_xml(fusion)
    except DonneesRefusees:
        raise
    except (TypeError, ValueError, AttributeError) as erreur:
        raise DonneesRefusees('tables invalides pour un classeur ODS : %s' % erreur)

    conservees = []
    if Path(chemin).is_file():
        try:
            with zipfile.ZipFile(str(chemin)) as origine:
                for info in origine.infolist():
                    if info.is_dir() or info.filename in ODS_REECRITES:
                        continue
                    conservees.append((info.filename, origine.read(info.filename)))
        except (zipfile.BadZipFile, OSError, KeyError):
            # L'original est illisible : on écrit un classeur neuf plutôt que de
            # refuser, puisque l'utilisateur demande justement à enregistrer.
            conservees = []
    manifeste = _manifeste_ods([nom for nom, _donnees in conservees])

    mode = _mode_actuel(chemin)
    temporaire = str(chemin) + '.part'
    try:
        with zipfile.ZipFile(temporaire, 'w', zipfile.ZIP_DEFLATED) as archive:
            amorce = zipfile.ZipInfo('mimetype')
            amorce.compress_type = zipfile.ZIP_STORED
            archive.writestr(amorce, ODS_MEDIA)
            for nom, donnees in conservees:
                archive.writestr(nom, donnees)
            archive.writestr('META-INF/manifest.xml', manifeste)
            archive.writestr('content.xml', contenu)
        os.replace(temporaire, str(chemin))
    except (OSError, zipfile.BadZipFile, TypeError, ValueError) as erreur:
        try:
            os.unlink(temporaire)
        except OSError:
            pass
        raise DonneesRefusees('écriture ODS impossible : %s' % erreur)
    _retablir_mode(chemin, mode)
    return str(chemin)


def capacites():
    """L'état réel, pour que l'interface et l'aide ne promettent rien de faux."""
    try:
        import openpyxl
        xlsx = True
        version = getattr(openpyxl, '__version__', 'inconnue')
    except ImportError:
        xlsx = False
        version = ''
    return {
        'marqueur': MARQUEUR,
        'extensions': list(EXTENSIONS_DONNEES),
        'xlsx': xlsx,
        'openpyxl': version,
        'ods': True,          # ZIP + XML, bibliothèque standard
        'xml': True,
        'signature_sqlite': True,
        'miroir_sql': True,
        'ecriture_xlsx': xlsx,
        'ecriture_ods': True,   # zipfile + ElementTree, bibliothèque standard
        'ecriture_xml': True,   # ElementTree, bibliothèque standard
        # Ces drapeaux disent ce que le MODULE sait faire. Ce qu'un FICHIER
        # donné autorise est dit par ecriture_possible(), qui nomme la raison
        # d'un refus : des formules, openpyxl absent, une racine introuvable.
        'ecriture_par_fichier': 'ecriture_possible',
        'ecritures_refusees': {
            # Ce que l'écriture NE SAIT PAS faire, nommé ici pour que l'aide et
            # l'interface ne laissent pas croire le contraire. Un refus silencieux
            # serait pris pour une réussite.
            'xml_nouvelle_table':
                'Ajouter une table à un XML : rien ne dit où placer ses éléments.',
            'xml_renommer_colonne':
                'Renommer une colonne d’un XML : le nom affiché est dérivé du nom '
                'XML par une règle à sens unique.',
        },
        'limites': {'lignes': MAX_LIGNES, 'colonnes': MAX_COLONNES,
                    'cellule': MAX_CELLULE},
    }


if __name__ == '__main__':
    import json
    print(json.dumps(capacites(), ensure_ascii=False, indent=2))
