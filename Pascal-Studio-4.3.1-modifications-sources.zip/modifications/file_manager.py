"""Local and GVFS remote file management, no credentials written by this module."""
import contextlib, ctypes, errno, fcntl, hashlib, json, os, re, shutil, stat, sys, threading, time, urllib.parse, uuid
from pathlib import Path

MAX_TEXT=3_000_000
MAX_TRANSFER=100_000_000
KEEPALIVE_SECONDS=30
_gio=None
_loop=None
_loop_lock=threading.Lock()

def gio():
 global _gio,_loop
 with _loop_lock:
  if _gio is None:
   try:
    try: import gi
    except ImportError:
     sys.path.append('/usr/lib/python3/dist-packages');import gi
    from gi.repository import Gio, GLib
   except Exception as e:raise ValueError('Composants GVFS indisponibles : installez python3-gi, gvfs-backends et gvfs-fuse. '+str(e)) from e
   _gio=(Gio,GLib);_loop=GLib.MainLoop();threading.Thread(target=_loop.run,daemon=True,name='ps-gvfs').start()
  return _gio

def local_path(path):
 if not isinstance(path,str) or not path or '\x00' in path or not Path(path).is_absolute():raise ValueError('Chemin local absolu requis.')
 return Path(path).expanduser().resolve()

def name_ok(name):
 if not isinstance(name,str) or name in ('','.','..') or '/' in name or '\x00' in name or len(name.encode())>255:raise ValueError('Nom de fichier invalide.')
 return name

def rename_no_overwrite(src,dst):
 # Linux renameat2 ensures that another process cannot create the target
 # between an existence check and rename. Do not fall back to os.rename.
 libc=ctypes.CDLL(None,use_errno=True);fn=getattr(libc,'renameat2',None)
 if fn is None:raise ValueError('Renommage sans écrasement indisponible sur ce système.')
 fn.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];fn.restype=ctypes.c_int
 if fn(-100,os.fsencode(src),-100,os.fsencode(dst),1)!=0:
  n=ctypes.get_errno()
  if n==errno.EEXIST:raise ValueError('La destination existe déjà.')
  raise OSError(n,os.strerror(n),str(dst))

def valid_relative(path):
 if not isinstance(path,str) or '\x00' in path or path.startswith('/') or any(x in ('.','..','') for x in path.split('/') if path):raise ValueError('Chemin distant invalide.')
 return path

def child(path,name):
 name_ok(name);return path+'/'+name if path else name

def checked_uri(uri):
 if not isinstance(uri,str) or len(uri)>2048 or any(c in uri for c in '\r\n\x00'):raise ValueError('Adresse invalide.')
 u=urllib.parse.urlsplit(uri.strip())
 if u.scheme not in ('ftp','ftps','ftpis','sftp','smb') or not u.hostname or u.password is not None or u.query or u.fragment:raise ValueError('Adresse attendue : FTP, FTPS, SFTP ou SMB ; sans mot de passe dans l’adresse.')
 try:port=u.port
 except ValueError:raise ValueError('Port invalide.')
 if u.scheme=='smb' and not u.path.strip('/'):raise ValueError('Indiquez le nom du partage SMB : smb://serveur/partage.')
 if port is not None and not 1<=port<=65535:raise ValueError('Port invalide.')
 return uri.strip()

def read_remote_limited(f):
 Gio,_=gio()
 def get_etag():
  try:return f.query_info('etag::value',Gio.FileQueryInfoFlags.NONE,None).get_attribute_string('etag::value')
  except Exception:return None
 before=get_etag();stream=f.read(None);parts=[];size=0
 try:
  while True:
   data=stream.read_bytes(min(65536,MAX_TEXT+1-size),None).get_data()
   if not data:break
   parts.append(data);size+=len(data)
   if size>MAX_TEXT:raise ValueError('Fichier supérieur à 3 Mo.')
 finally:stream.close(None)
 after=get_etag()
 if before and after and before!=after:raise ValueError('Le fichier distant a changé pendant la lecture : réessayez.')
 return b''.join(parts),after

class Job:
 def __init__(self,uri,username,password,domain,remember):
  self.id=uuid.uuid4().hex;self.uri=uri;self.user=username;self.password=password;self.domain=domain;self.remember=remember;self.state='connecting';self.error='';self.question=None;self.answer=None;self.event=threading.Event();self.lock=threading.RLock();self.used=False;self.pinging=False;self.auth_attempts=0;self.auth_failed=False;self.warning='';self.save_password=False
 def snapshot(self):
  with self.lock:return {'id':self.id,'uri':self.uri,'state':self.state,'error':self.error,'question':self.question,'warning':self.warning}
 def ask(self,question):
  with self.lock:self.question=question;self.answer=None;self.event.clear();self.state='question'
  if not self.event.wait(180):
   with self.lock:self.question=None;self.state='connecting'
   return None
  with self.lock:r=self.answer;self.answer=None;self.question=None;self.state='connecting';return r
 def respond(self,answer):
  with self.lock:
   if self.state!='question':raise ValueError('Aucune question en attente.')
   self.answer=answer;self.event.set()

def synchronized(fn):
 def wrapped(self,*args,**kwargs):
  with self.lock:return fn(self,*args,**kwargs)
 return wrapped

class Manager:
 def __init__(self,vault=None):
  self.jobs={};self.sessions={};self.files={};self.lock=threading.RLock();self.vault=vault
  self.profile=Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')/'pascal-studio'/'remote-locations.json'
  threading.Thread(target=self._heartbeat,daemon=True,name='ps-remote-keepalive').start()
 @synchronized
 def profiles(self):
  try:
   x=json.loads(self.profile.read_text('utf-8'))
   if not isinstance(x,list):raise ValueError('Format de liste invalide')
   return x
  except FileNotFoundError:return []
  except (OSError,ValueError) as e:raise ValueError('Liste des connexions illisible ; aucun profil n’a été écrasé : '+str(e)) from e
 @contextlib.contextmanager
 def _profile_lock(self):
  self.profile.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  fd=os.open(self.profile.parent/'remote-locations.lock',os.O_RDWR|os.O_CREAT|getattr(os,'O_NOFOLLOW',0),0o600)
  try:fcntl.flock(fd,fcntl.LOCK_EX);yield
  finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
 def _write_profiles(self,a):
  tmp=self.profile.with_name('.remote-locations-'+uuid.uuid4().hex);fd=os.open(tmp,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
  try:
   with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(a,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
   os.replace(tmp,self.profile)
  finally:tmp.unlink(missing_ok=True)
 @synchronized
 def remember_profile(self,uri,user,domain):
  with self._profile_lock():
   a=[x for x in self.profiles() if isinstance(x,dict) and x.get('uri')!=uri];a.append({'uri':uri,'username':user,'domain':domain});self._write_profiles(a)
 @synchronized
 def forget_profile(self,uri):
  with self._profile_lock():
   a=[x for x in self.profiles() if isinstance(x,dict) and x.get('uri')!=uri];self._write_profiles(a)
 def begin(self,uri,user='',password='',domain='',remember=False,_id=None,_retries=0,save_password=False):
  uri=checked_uri(uri)
  if not all(isinstance(x,str) and len(x)<2048 and '\x00' not in x for x in (user,password,domain)):raise ValueError('Identifiants invalides.')
  Gio,GLib=gio();j=Job(uri,user,password,domain,remember is True);j.save_password=bool(save_password)
  # Remember the connection settings even if authentication later fails.
  # The password is stored only after a successful connection.
  if j.remember:
   try:self.remember_profile(j.uri,j.user,j.domain)
   except Exception as e:j.warning='Connexion non enregistrée : '+str(e)
  if _id:j.id=_id
  with self.lock:self.jobs[j.id]=j;self.sessions[j.id]=j
  def initiate():
   f=Gio.File.new_for_uri(j.uri);op=Gio.MountOperation()
   def password_cb(op,msg,default_user,default_domain,flags):
    j.auth_attempts+=1
    if j.auth_attempts>3 or (j.uri.startswith(('ftp://','ftps://','ftpis://')) and j.used and j.password):
     j.auth_failed=True;op.reply(Gio.MountOperationResult.ABORTED);return
    supplied=None
    if not j.used and j.password:
     j.used=True;supplied={'username':j.user or default_user or '', 'password':j.password,'domain':j.domain or default_domain or '', 'remember':j.remember}
    if supplied is None:supplied=j.ask({'type':'password','message':msg,'username':j.user or default_user or '', 'domain':j.domain or default_domain or '', 'saving':bool(flags & Gio.AskPasswordFlags.SAVING_SUPPORTED)})
    if not isinstance(supplied,dict):op.reply(Gio.MountOperationResult.ABORTED);return
    j.user=str(supplied.get('username',''));j.domain=str(supplied.get('domain',''));j.password=str(supplied.get('password',''));j.used=bool(j.password);op.set_username(j.user);op.set_domain(j.domain);op.set_password(j.password)
    op.set_password_save(Gio.PasswordSave.NEVER)
    op.reply(Gio.MountOperationResult.HANDLED)
   def question_cb(op,msg,choices):
    answer=j.ask({'type':'choice','message':msg,'choices':list(choices)})
    if not isinstance(answer,int) or answer<0 or answer>=len(choices):op.reply(Gio.MountOperationResult.ABORTED);return
    op.set_choice(answer);op.reply(Gio.MountOperationResult.HANDLED)
   def done(f,result):
    try:
     try:f.mount_enclosing_volume_finish(result)
     except GLib.Error as e:
      if not e.matches(Gio.io_error_quark(),Gio.IOErrorEnum.ALREADY_MOUNTED):raise
    except Exception as e:
     return failure(e)
    def verify():
     try:
      info=f.query_info('standard::type',Gio.FileQueryInfoFlags.NONE,None)
      if info.get_file_type()!=Gio.FileType.DIRECTORY:raise ValueError('La destination distante n’est pas un dossier.')
      with self.lock:
       if self.sessions.get(j.id) is not j:return
      warnings=[j.warning] if j.warning else []
      if j.remember:
       try:self.remember_profile(j.uri,j.user,j.domain)
       except Exception as e:warnings.append('Connexion établie, mais profil non enregistré : '+str(e))
      if j.save_password and j.password:
       try:
        if not self.vault:raise ValueError('Coffre indisponible.')
        self.vault.put(j.uri,j.user,j.domain,j.password)
       except Exception as e:warnings.append('Connexion établie, mais mot de passe non enregistré : '+str(e))
      elif j.save_password:
       warnings.append('Aucun mot de passe serveur n’a été enregistré dans le coffre. Si nécessaire, saisissez-le avec Modifier l’accès….')
      with j.lock:j.state='connected';j.error='';j.warning=' '.join(warnings)
     except Exception as e:failure(e)
    threading.Thread(target=verify,daemon=True,name='ps-remote-verify').start()
   def failure(e):
    stale=isinstance(e,GLib.Error) and e.domain=='g-dbus-error-quark' and ('does not exist' in e.message or 'not provided' in e.message)
    if stale and _retries<4:
     with j.lock:j.state='connecting';j.error='Montage indisponible, nouvelle tentative…'
     def retry():
      with self.lock:current=self.sessions.get(j.id)
      if current is j:self.begin(j.uri,j.user,j.password,j.domain,j.remember,_id=j.id,_retries=_retries+1,save_password=j.save_password)
      return False
     GLib.timeout_add_seconds(3,retry)
    else:
     with j.lock:j.state='error';j.error=(('Le serveur a refusé ou redemandé l’authentification FTP/FTPS. Vérifiez l’utilisateur FTP complet, son mot de passe et le protocole ; utilisez Tester la connexion pour plus de détails.' if j.uri.startswith(('ftp://','ftps://','ftpis://')) else 'Authentification refusée ou redemandée. Vérifiez l’utilisateur, le mot de passe et le protocole.') if j.auth_failed else str(e)) + (' '+j.warning if j.warning else '')
   op.connect('ask-password',password_cb);op.connect('ask-question',question_cb)
   f.mount_enclosing_volume(Gio.MountMountFlags.NONE,op,None,done)
   return False
  GLib.idle_add(initiate);return j.snapshot()
 def _heartbeat(self):
  while True:
   time.sleep(KEEPALIVE_SECONDS)
   with self.lock:items=list(self.sessions.values())
   for j in items:
    with j.lock:
     if j.state!='connected' or j.pinging:continue
     j.pinging=True
    threading.Thread(target=self._ping,args=(j,),daemon=True,name='ps-remote-ping').start()
 def _ping(self,j):
  try:
   Gio,_=gio();f=Gio.File.new_for_uri(j.uri);f.query_info('standard::type',Gio.FileQueryInfoFlags.NONE,None)
  except Exception as e:
   Gio,GLib=gio()
   stale=isinstance(e,GLib.Error) and (e.matches(Gio.io_error_quark(),Gio.IOErrorEnum.NOT_MOUNTED) or (e.domain=='g-dbus-error-quark' and ('does not exist' in e.message or 'not provided' in e.message)))
   if stale:
    try:
     with self.lock:current=self.sessions.get(j.id)
     if current is j:self.begin(j.uri,j.user,j.password,j.domain,j.remember,_id=j.id,save_password=j.save_password)
    except Exception:pass
  finally:
   with j.lock:j.pinging=False
 def reconnect(self,id):
  with self.lock:j=self.sessions.get(id)
  if not j:raise ValueError('Connexion inconnue.')
  return self.begin(j.uri,j.user,j.password,j.domain,j.remember,_id=id,save_password=j.save_password)
 def disconnect(self,id):
  # Do not unmount shared desktop mounts. Forget this application's session.
  with self.lock:
   j=self.sessions.pop(id,None);self.jobs.pop(id,None)
   for k in [k for k,v in self.files.items() if v['session']==id]:self.files.pop(k,None)
  if j:j.password=''
 def job(self,id):
  with self.lock:j=self.jobs.get(id)
  if not j:raise ValueError('Connexion inconnue.')
  return j
 def session(self,id):
  with self.lock:j=self.sessions.get(id)
  if not j:raise ValueError('Connexion inconnue ou interrompue.')
  if j.state!='connected':raise ValueError('Connexion indisponible ou reconnexion en cours : vérifiez le gestionnaire.')
  return j
 def remote(self,id,path):
  Gio,_=gio();j=self.session(id);valid_relative(path);f=Gio.File.new_for_uri(j.uri)
  for part in path.split('/') if path else []:f=f.get_child(name_ok(part))
  return f
 def listing(self,kind,where,path):
  if kind=='local':
   p=local_path(path)
   if not p.is_dir():raise ValueError('Dossier local introuvable.')
   out=[]
   with os.scandir(p) as it:
    for e in it:
     try:
      if e.is_symlink():typ='link'
      elif e.is_dir(follow_symlinks=False):typ='folder'
      elif e.is_file(follow_symlinks=False):typ='file'
      else:continue
      out.append({'name':e.name,'type':typ,'size':e.stat(follow_symlinks=False).st_size if typ=='file' else None})
     except OSError:continue
  elif kind=='remote':
   Gio,_=gio();f=self.remote(where,path);out=[];en=f.enumerate_children('standard::name,standard::type,standard::size,standard::is-symlink',Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,None)
   try:
    while True:
     i=en.next_file(None)
     if not i:break
     # Some FTP servers return UNKNOWN types in listings. Try a specific
     # query rather than silently hiding the entry; retain it if still unknown.
     name=i.get_name();name_ok(name)
     if i.get_file_type()==Gio.FileType.UNKNOWN:
      try:i=f.get_child(name).query_info('standard::name,standard::type,standard::size,standard::is-symlink',Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,None)
      except Exception:pass
     typ='link' if (i.has_attribute('standard::is-symlink') and i.get_is_symlink()) or i.get_file_type()==Gio.FileType.SYMBOLIC_LINK else 'folder' if i.get_file_type()==Gio.FileType.DIRECTORY else 'file' if i.get_file_type()==Gio.FileType.REGULAR else 'unknown'
     out.append({'name':name,'type':typ,'size':i.get_size() if typ=='file' else None})
   finally:en.close(None)
  else:raise ValueError('Emplacement invalide.')
  out.sort(key=lambda x:(x['type']!='folder',x['name'].casefold()));return {'items':out[:10000],'truncated':len(out)>10000,'path':str(local_path(path)) if kind=='local' else path}
 def operation(self,kind,where,path,action,name=None,target=None):
  if action=='create':
   name_ok(name)
   if kind=='local':
    p=local_path(path)/name
    if target=='folder':p.mkdir()
    elif target=='file':p.touch(exist_ok=False)
    else:raise ValueError('Type invalide.')
   else:
    Gio,_=gio();f=self.remote(where,child(path,name))
    if target=='folder':f.make_directory(None)
    elif target=='file':f.create(Gio.FileCreateFlags.NONE,None).close(None)
    else:raise ValueError('Type invalide.')
  elif action in ('rename','delete'):
   if not path:raise ValueError('Impossible de modifier la racine.')
   if kind=='local':
    p0=Path(path)
    if not p0.is_absolute() or p0.name in ('','.','..'):raise ValueError('Chemin local invalide.')
    p=local_path(str(p0.parent))/p0.name
    if action=='rename':
     name_ok(name);dest=p.parent/name
     rename_no_overwrite(p,dest)
    elif p.is_symlink() or not p.is_dir():p.unlink()
    else:p.rmdir() # deliberately only empty directories
   else:
    Gio,_=gio();f=self.remote(where,path)
    if action=='rename':name_ok(name);f.move(f.get_parent().get_child(name),Gio.FileCopyFlags.NONE,None,None,None)
    else:f.delete(None) # directories must be empty
  else:raise ValueError('Opération invalide.')
  return {'ok':True}
 def open_text(self,id,path):
  Gio,_=gio();f=self.remote(id,path)
  info=f.query_info('standard::type,standard::size',Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,None)
  if info.get_file_type()!=Gio.FileType.REGULAR or info.get_size()>MAX_TEXT:raise ValueError('Seuls les fichiers texte ordinaires jusqu’à 3 Mo peuvent être ouverts à distance.')
  data,etag=read_remote_limited(f)
  if len(data)>MAX_TEXT or b'\x00' in data:raise ValueError('Fichier non textuel ou trop volumineux.')
  try:text=data.decode('utf8')
  except UnicodeDecodeError:raise ValueError('Ce fichier n’est pas en UTF-8. Téléchargez-le pour le traiter localement.')
  key='@remote:'+id+'/'+path
  with self.lock:self.files[key]={'session':id,'path':path,'etag':etag,'hash':hashlib.sha256(data).hexdigest(),'lock':threading.RLock()}
  return {'path':key,'content':text}
 def save_text(self,key,text):
  if not isinstance(text,str) or len(text.encode('utf8'))>MAX_TEXT:raise ValueError('Texte trop volumineux (maximum 3 Mo).')
  with self.lock:info=self.files.get(key)
  if not info:raise ValueError('Fichier distant fermé ou connexion perdue.')
  Gio,_=gio();f=self.remote(info['session'],info['path'])
  with info['lock']:
   current,etag=read_remote_limited(f)
   if hashlib.sha256(current).hexdigest()!=info['hash']:raise ValueError('Le fichier distant a changé : sauvegarde refusée. Copiez votre texte avant de le rouvrir.')
   new=text.encode('utf8')
   try:ok,newetag=f.replace_contents(new,etag,False,Gio.FileCreateFlags.NONE,None)
   except Exception as e:raise ValueError('Enregistrement distant impossible ou conflit : '+str(e)) from e
   info['hash']=hashlib.sha256(new).hexdigest();info['etag']=newetag
  return {'ok':True}
 def transfer(self,src_kind,src_id,src_path,dst_kind,dst_id,dst_dir,name):
  if src_kind==dst_kind:raise ValueError('Choisissez un panneau local et un panneau distant.')
  name_ok(name);Gio,_=gio()
  source=Gio.File.new_for_path(str(local_path(src_path))) if src_kind=='local' else self.remote(src_id,src_path)
  dest=Gio.File.new_for_path(str(local_path(dst_dir)/name)) if dst_kind=='local' else self.remote(dst_id,child(dst_dir,name))
  info=source.query_info('standard::type,standard::size,standard::is-symlink',Gio.FileQueryInfoFlags.NOFOLLOW_SYMLINKS,None)
  if (info.has_attribute('standard::is-symlink') and info.get_is_symlink()) or info.get_file_type()!=Gio.FileType.REGULAR:raise ValueError('Le transfert prend en charge les fichiers ordinaires, pas les dossiers ni les liens.')
  if info.get_size()>MAX_TRANSFER:raise ValueError('Fichier supérieur à 100 Mo : transférez-le avec un autre outil.')
  source.copy(dest,Gio.FileCopyFlags.NONE,None,None,None) # no overwrite
  return {'ok':True}
