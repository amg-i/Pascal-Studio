"""Identité de commit déduite du compte GitHub / GitLab associé au dépôt.

Règle appliquée : quand un dépôt est associé à un compte connecté, l'identité
locale (user.name / user.email) devient celle que le service publie pour ce
compte. Sans compte associé, AUCUNE identité n'est posée : le dépôt reste sans
identité locale et Git utilisera votre configuration globale, ou refusera le
commit si elle est absente.

Une identité posée automatiquement est marquée dans la configuration locale du
dépôt (pascal-studio.identity-auto). Ce marqueur permet de la remplacer ou de
l'effacer plus tard sans jamais toucher une identité que vous auriez saisie à la
main dans le panneau Git.

L'adresse utilisée est celle publiée par le service : adresse du compte si elle
est visible, sinon l'adresse noreply officielle (GitHub « id+login@… », GitLab
« login@… »). Elle est enregistrée dans les commits, donc visible par tous les
lecteurs du dépôt.
"""
import re
import urllib.parse

import oauth_accounts
from git_manager import GitManager, IDENTITY_MARKER as MARKER
HTTPS_RE = re.compile(r'^https://([a-z0-9.-]+)/(.+?)(?:\.git)?/?$', re.I)
SSH_RE = re.compile(r'^git@([a-z0-9.-]+):(.+?)(?:\.git)?/?$', re.I)


def parse_remote(url):
    """Retourne {'host','owner','path'} pour une URL HTTPS ou SSH, sinon None."""
    if not isinstance(url, str) or not url.strip():
        return None
    url = url.strip()
    m = HTTPS_RE.match(url) or SSH_RE.match(url)
    if not m:
        return None
    host = m.group(1).lower()
    # Les identifiants ne doivent jamais se retrouver dans un hôte exploitable.
    if '@' in host or not re.fullmatch(r'[a-z0-9.-]+', host):
        return None
    path = m.group(2).strip('/')
    parts = [p for p in path.split('/') if p and p not in ('.', '..')]
    if len(parts) < 2:
        return None
    return {'host': host, 'owner': parts[0], 'path': '/'.join(parts),
            'name': parts[-1], 'scheme': 'https' if url.lower().startswith('https') else 'ssh'}


def provider_for(host):
    """Service correspondant à un hôte ; None si l'hôte n'est pas géré."""
    if not host:
        return None
    for name, conf in oauth_accounts.PROVIDERS.items():
        official = urllib.parse.urlsplit(conf['origin']).hostname
        if host == official or host.endswith('.' + official):
            return name
    return None


def match_account(remote_url, accounts=None):
    """Compte associé à un dépôt, ou (None, raison).

    - hôte non géré (self-hosted, SSH vers un autre serveur) : aucune identité ;
    - un seul compte connecté pour ce service : celui-là ;
    - plusieurs comptes : celui dont l'identifiant correspond au propriétaire du
      dépôt. Sans correspondance on ne devine pas, pour ne jamais attribuer un
      commit au mauvais compte.
    """
    parsed = parse_remote(remote_url)
    if not parsed:
        return None, 'dépôt sans origine distante lisible'
    provider = provider_for(parsed['host'])
    if not provider:
        return None, 'hôte %s non associé à un compte connecté' % parsed['host']
    accounts = oauth_accounts.manager.all() if accounts is None else accounts
    candidates = [a for a in accounts if a.get('provider') == provider]
    if not candidates:
        return None, 'aucun compte %s connecté' % provider
    if len(candidates) == 1:
        return candidates[0], 'compte unique pour %s' % provider
    owner = parsed['owner'].lower()
    for account in candidates:
        if str(account.get('login', '')).lower() == owner:
            return account, 'propriétaire du dépôt'
    return None, ('plusieurs comptes %s connectés et aucun ne correspond au propriétaire « %s »'
                  % (provider, parsed['owner']))


def _git(root):
    return GitManager(root)


def is_repo(root):
    try:
        return _git(root).call('rev-parse', '--show-toplevel', check=False).returncode == 0
    except ValueError:
        return False


def remote_url(root):
    try:
        p = _git(root).call('remote', 'get-url', 'origin', check=False)
    except ValueError:
        return ''
    return p.stdout.strip() if p.returncode == 0 else ''


def current(root):
    """Identité locale effective + provenance."""
    try:
        git = _git(root)
    except ValueError:
        return {'repo': False}
    if git.call('rev-parse', '--show-toplevel', check=False).returncode:
        return {'repo': False}
    name = git.call('config', '--local', '--get', 'user.name', check=False).stdout.strip()
    email = git.call('config', '--local', '--get', 'user.email', check=False).stdout.strip()
    marker = git.call('config', '--local', '--get', MARKER, check=False).stdout.strip()
    auto = marker.startswith('auto:')
    return {'repo': True, 'localName': name, 'localEmail': email, 'marker': marker,
            # « auto » seulement si Pascal Studio a posé l'identité ; « manual »
            # si elle vient du panneau Git ; « none » si rien n'est défini.
            'source': 'auto' if auto else ('manual' if marker or name or email else 'none'),
            'auto': marker, 'accountId': marker.split(':', 1)[1] if auto else '',
            'remote': remote_url(root)}


def _set_local(git, key, value):
    if value is None:
        git.call('config', '--local', '--unset-all', key, check=False)
    else:
        git.call('config', '--local', key, value)


def clear_auto(root):
    """Efface l'identité locale SEULEMENT si Pascal Studio l'avait posée."""
    git = _git(root)
    marker = git.call('config', '--local', '--get', MARKER, check=False).stdout.strip()
    if not marker.startswith('auto:'):
        return {'ok': True, 'changed': False, 'reason': 'identité manuelle conservée'}
    for key in ('user.name', 'user.email', MARKER):
        _set_local(git, key, None)
    return {'ok': True, 'changed': True, 'reason': 'identité automatique effacée'}


def apply(root, account_id=None, confirm=True):
    """Pose l'identité du compte associé au dépôt ; efface sinon l'identité auto.

    Retourne un dict décrivant l'état final. Ne lève ValueError que si le dépôt
    est inutilisable. Une identité manuelle existante n'est jamais écrasée sans
    account_id explicite.
    """
    git = _git(root)
    if git.call('rev-parse', '--show-toplevel', check=False).returncode:
        raise ValueError('Ce projet ne contient pas de dépôt Git.')
    state = current(root)
    url = state['remote']

    # Un compte explicitement demandé prime (action volontaire de l'utilisateur).
    account = None
    reason = ''
    if account_id:
        try:
            info = oauth_accounts.manager.identity(account_id)
        except ValueError as e:
            raise ValueError(str(e))
        account = {'id': info['accountId'], 'provider': info['provider'], 'login': info['login'],
                   'name': info['name'], 'email': info['email'], 'emailSource': info['emailSource']}
        reason = 'compte choisi'
    else:
        found, reason = match_account(url)
        if found:
            try:
                info = oauth_accounts.manager.identity(found['id'])
            except ValueError as e:
                return {'ok': False, 'applied': False, 'reason': str(e), **state}
            account = {**found, 'name': info['name'], 'email': info['email'],
                       'emailSource': info['emailSource']}

    if not account:
        # Aucune identité par défaut : on retire celle qu'on avait posée.
        cleared = clear_auto(root)
        return {'ok': True, 'applied': False, 'identity': None, 'reason': reason,
                'cleared': cleared.get('changed', False), **current(root)}

    if not oauth_accounts.is_valid_email(account.get('email')) or not str(account.get('name', '')).strip():
        return {'ok': False, 'applied': False, 'identity': None,
                'reason': 'le service ne publie pas d’identité utilisable pour ce compte', **state}

    # Une identité existe déjà et ne vient pas de nous : on ne l'écrase pas sans
    # un choix explicite de compte. Le marqueur vaut « manual » dans ce cas, et
    # sa simple présence ne suffit donc pas à conclure.
    manual = bool(state['localName'] or state['localEmail']) and not state['auto'].startswith('auto:')
    if manual and not account_id and confirm:
        # On ne remplace pas silencieusement une identité saisie à la main.
        return {'ok': True, 'applied': False, 'identity': None, 'manualIdentity': True,
                'reason': 'une identité manuelle est déjà définie ; choisissez le compte pour la remplacer',
                **state}

    name = str(account['name']).strip()[:200]
    email = str(account['email']).strip()[:320]
    if '\n' in name or '\n' in email:
        raise ValueError('Identité invalide.')
    git.call('config', '--local', 'user.name', name)
    git.call('config', '--local', 'user.email', email)
    git.call('config', '--local', MARKER, 'auto:' + str(account['id']))
    return {'ok': True, 'applied': True, 'reason': reason,
            'identity': {'name': name, 'email': email, 'provider': account['provider'],
                         'login': account['login'], 'accountId': account['id'],
                         'emailSource': account.get('emailSource', '')},
            **current(root)}


EMAIL_SOURCE = {'compte': 'adresse du compte', 'commit': 'adresse de commit',
                'noreply': 'adresse privée du service'}


def explain(result):
    """Phrase lisible décrivant le résultat d'apply(), pour le panneau Git.

    Le panneau affiche le champ « output » de la réponse : cela permet de dire à
    l'utilisateur si une identité a été posée, conservée ou retirée, et pourquoi.
    """
    if not isinstance(result, dict):
        return ''
    if result.get('applied'):
        ident = result.get('identity') or {}
        service = ident.get('provider') or 'compte'
        login = ident.get('login') or ''
        qui = service + (' · ' + login if login else '')
        source = EMAIL_SOURCE.get(ident.get('emailSource'), '')
        return ('Identité posée depuis le compte %s : %s <%s>%s.'
                % (qui, ident.get('name', ''), ident.get('email', ''),
                   ' (' + source + ')' if source else ''))
    if not result.get('ok', True):
        return 'Identité non posée : %s.' % (result.get('reason') or 'raison inconnue')
    if result.get('manualIdentity'):
        return ('Identité manuelle conservée. %s.'
                % (result.get('reason') or 'Choisissez le compte pour la remplacer')).replace(' .', '.')
    if result.get('cleared'):
        return 'Identité retirée : aucun compte n’est associé à ce dépôt.'
    reason = result.get('reason') or 'aucun compte n’est associé à ce dépôt'
    return 'Aucune identité posée : %s.' % reason


def describe_remote(root):
    """Ce que Pascal Studio déduit de l'origine du dépôt, sans rien modifier."""
    url = remote_url(root)
    parsed = parse_remote(url)
    account, reason = match_account(url) if url else (None, 'dépôt sans origine distante')
    return {'remote': url, 'parsed': parsed, 'provider': provider_for(parsed['host']) if parsed else None,
            'account': ({k: account[k] for k in ('id', 'provider', 'login', 'name', 'email')}
                        if account else None),
            'reason': reason, **current(root)}
