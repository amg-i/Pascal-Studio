"""Git integration: commands run as the current user, without a shell."""
import os, re, shutil, subprocess, urllib.parse, datetime, tempfile
from pathlib import Path

# Provenance de l'identité locale : « manual » (saisie dans le panneau Git) ou
# « auto:<id de compte> » (déduite du compte GitHub/GitLab associé au dépôt).
# git_identity.py s'appuie sur cette valeur pour ne jamais écraser un choix manuel.
IDENTITY_MARKER = 'pascal-studio.identity-auto'

class GitManager:
    def __init__(self, root): self.root=Path(root).resolve()
    def call(self,*args,check=True,timeout=30,auth=None):
        if not shutil.which('git'): raise ValueError('Git est introuvable. Installez-le avec : sudo apt install git')
        env={**os.environ,'GIT_TERMINAL_PROMPT':'0','GIT_SSH_COMMAND':'ssh -o BatchMode=yes -o ConnectTimeout=12','LC_ALL':'C.UTF-8'}
        try:
            with tempfile.TemporaryDirectory(prefix='pascal-git-') as temp:
                if auth:
                    helper=Path(temp)/'askpass'
                    helper.write_text("""#!/bin/sh
case "$1" in *"'https://$PASCAL_GIT_HOST':"*|*"'https://$PASCAL_GIT_USER@$PASCAL_GIT_HOST':"*) ;; *) exit 1;; esac
case "$1" in *Username*) printf '%s\\n' "$PASCAL_GIT_USER";; *Password*) printf '%s\\n' "$PASCAL_GIT_TOKEN";; *) exit 1;; esac
""");helper.chmod(0o700)
                    env.update(GIT_ASKPASS=str(helper),PASCAL_GIT_USER=auth['user'],PASCAL_GIT_TOKEN=auth['token'],PASCAL_GIT_HOST=auth['host'],GIT_CONFIG_COUNT='2',GIT_CONFIG_KEY_0='credential.helper',GIT_CONFIG_VALUE_0='',GIT_CONFIG_KEY_1='http.followRedirects',GIT_CONFIG_VALUE_1='false')
                p=subprocess.run(['git',*args],cwd=self.root,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,errors='replace',timeout=timeout)
        except subprocess.TimeoutExpired: raise ValueError('Git a dépassé le délai autorisé. Vérifiez le réseau et les identifiants.')
        if check and p.returncode:
            msg=(p.stderr or p.stdout or 'La commande Git a échoué.').strip()
            msg=re.sub(r'(https?://)[^/@\s]+@',r'\1***@',msg)
            if auth:msg=msg.replace(auth['token'],'[masqué]')
            raise ValueError(msg)
        return p
    def require_repo(self):
        p=self.call('rev-parse','--show-toplevel',check=False)
        if p.returncode: raise ValueError('Ce projet ne contient pas de dépôt Git. Initialisez-en un.')
        if Path(p.stdout.strip()).resolve()!=self.root: raise ValueError('Ouvrez le dossier racine du dépôt Git, pas un sous-dossier.')
    def path(self,name):
        if not isinstance(name,str) or not name or '\0' in name: raise ValueError('Chemin invalide.')
        p=(self.root/name).resolve()
        if not p.is_relative_to(self.root) or p==self.root or '.pascal-studio' in p.relative_to(self.root).parts or '.git' in p.relative_to(self.root).parts: raise ValueError('Chemin interdit.')
        return name
    def status(self):
        if not shutil.which('git'): return {'installed':False,'repo':False}
        p=self.call('rev-parse','--show-toplevel',check=False)
        if p.returncode: return {'installed':True,'repo':False}
        if Path(p.stdout.strip()).resolve()!=self.root: return {'installed':True,'repo':False,'message':'Ouvrez le dossier racine du dépôt Git.'}
        output=self.call('status','--porcelain=v1','-z','--untracked-files=all').stdout.split('\0'); files=[]; i=0
        while i<len(output):
            item=output[i];i+=1
            if not item:continue
            xy=item[:2]; name=item[3:]; original=None
            if 'R' in xy or 'C' in xy:
                original=output[i] if i<len(output) else None; i+=1
            if name=='.pascal-studio' or name.startswith('.pascal-studio/'):continue
            files.append({'path':name,'index':xy[0], 'worktree':xy[1], 'original':original})
        branch=self.call('branch','--show-current',check=False).stdout.strip() or '(HEAD détachée)'
        branches=[x.strip() for x in self.call('branch','--format=%(refname:short)',check=False).stdout.splitlines() if x.strip()]
        remote=self.call('remote','get-url','origin',check=False).stdout.strip()
        remote=re.sub(r'(https?://)[^/@\s]+@',r'\1***@',remote)
        logs=self.call('log','-20','--format=%h%x1f%s%x1f%an%x1f%ar',check=False).stdout.splitlines()
        history=[]
        for line in logs:
            parts=line.split('\x1f');
            if len(parts)==4:history.append({'hash':parts[0],'subject':parts[1],'author':parts[2],'date':parts[3]})
        name=self.call('config','user.name',check=False).stdout.strip(); email=self.call('config','user.email',check=False).stdout.strip()
        return {'installed':True,'repo':True,'branch':branch,'branches':branches,'remote':remote,'files':files,'history':history,'name':name,'email':email,'graph':self.graph(),'graphNodes':self.graph_nodes(),'head':self.call('rev-parse','HEAD',check=False).stdout.strip()}
    def graph(self):
        self.require_repo()
        if self.call('rev-parse','--verify','HEAD',check=False).returncode: return []
        result=self.call('log','--all','HEAD','--graph','--date-order','--max-count=100',
            '--format=%x1e%H%x1f%h%x1f%s%x1f%an%x1f%ar%x1f%D',check=False)
        if result.returncode: raise ValueError('Impossible de lire le graphe des commits.')
        rows=[]
        for line in result.stdout.split('\n'):
            if '\x1e' not in line:
                if line.strip(): rows.append({'lanes':line,'connector':True})
                continue
            lanes,meta=line.split('\x1e',1);parts=meta.split('\x1f',5)
            if len(parts)==6 and re.fullmatch(r'[0-9a-f]{40,64}',parts[0]):
                rows.append({'lanes':lanes,'oid':parts[0],'hash':parts[1],'subject':parts[2],
                             'author':parts[3],'date':parts[4],'refs':parts[5]})
        return rows
    def graph_nodes(self):
        self.require_repo()
        if self.call('rev-parse','--verify','HEAD',check=False).returncode: return []
        r=self.call('log','--all','HEAD','--topo-order','--max-count=300','--format=%H%x1f%P%x1f%h%x1f%s%x1f%an%x1f%ar%x1f%D',check=False)
        if r.returncode: raise ValueError('Impossible de lire le graphe des commits.')
        nodes=[]
        for line in r.stdout.split('\n'):
            p=line.split('\x1f',6)
            if len(p)==7 and re.fullmatch(r'[0-9a-f]{40,64}',p[0]):
                nodes.append(dict(oid=p[0],parents=p[1].split(),hash=p[2],subject=p[3],author=p[4],date=p[5],refs=p[6]))
        return nodes
    def merge(self,source):
        self.require_repo()
        if not isinstance(source,str) or source not in self.status()['branches']: raise ValueError('Branche source inconnue.')
        if self.call('rev-parse','--verify','MERGE_HEAD',check=False).returncode==0: raise ValueError('Une fusion est déjà en cours.')
        if self.status()['files']: raise ValueError('Commitez ou mettez de côté toutes les modifications avant la fusion.')
        head=self.call('branch','--show-current').stdout.strip()
        if not head or source==head: raise ValueError('Choisissez une autre branche à fusionner dans la branche courante.')
        check=self.call('merge-tree','--write-tree','HEAD','refs/heads/'+source,check=False)
        if check.returncode: raise ValueError('Fusion annulée : des conflits seraient créés. Aucun fichier n’a été modifié.')
        result=self.call('merge','--no-edit','--no-ff','--no-overwrite-ignore','--','refs/heads/'+source,timeout=60)
        return result.stdout or result.stderr
    def branch_from_commit(self,oid):
        self.require_repo()
        if not isinstance(oid,str) or not re.fullmatch(r'[0-9a-f]{40,64}',oid):
            raise ValueError('Identifiant de commit invalide.')
        if self.call('cat-file','-e',oid+'^{commit}',check=False).returncode:
            raise ValueError('Ce commit est introuvable.')
        if self.status()['files']:
            raise ValueError('Enregistrez et commitez ou mettez de côté toutes les modifications avant de changer de commit.')
        base='retour/'+oid[:8]+'-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
        branch=base;i=2
        while not self.call('show-ref','--verify','--quiet','refs/heads/'+branch,check=False).returncode:
            branch=base+'-'+str(i);i+=1
        self.call('switch','--no-overwrite-ignore','-c',branch,oid,timeout=60)
        return {'ok':True,'branch':branch,'commit':oid}
    def init(self):
        p=self.call('rev-parse','--show-toplevel',check=False)
        if p.returncode==0: raise ValueError('Un dépôt Git existe déjà dans ce dossier ou un dossier parent.')
        self.call('init');return self.status()
    def stage(self,path=None):
        self.require_repo()
        if path:self.call('add','--',self.path(path))
        else:self.call('add','-A','--','.',' :(exclude).pascal-studio/**'.strip())
    def unstage(self,path=None):
        self.require_repo(); head=self.call('rev-parse','--verify','HEAD',check=False)
        if head.returncode==0:
            if path:self.call('restore','--staged','--',self.path(path))
            else:self.call('reset')
        else:
            self.call('rm','--cached','-r','--ignore-unmatch','--',self.path(path) if path else '.')
    def commit(self,message):
        self.require_repo()
        if not isinstance(message,str) or not message.strip() or len(message)>10000: raise ValueError('Saisissez un message de commit.')
        return self.call('commit','-m',message.strip(),timeout=60).stdout
    def identity(self,name,email):
        self.require_repo()
        if not all(isinstance(v,str) and v.strip() and '\n' not in v and len(v)<256 for v in (name,email)): raise ValueError('Nom et adresse e-mail requis.')
        self.call('config','--local','user.name',name.strip());self.call('config','--local','user.email',email.strip())
        # Marquée manuelle : l'identité déduite d'un compte ne l'écrasera pas
        # silencieusement. Voir git_identity.MARKER.
        self.call('config','--local',IDENTITY_MARKER,'manual')
    def clear_identity(self):
        """Retire l'identité locale, qu'elle soit manuelle ou automatique."""
        self.require_repo()
        for key in ('user.name','user.email',IDENTITY_MARKER):
            self.call('config','--local','--unset-all',key,check=False)
        return self.status()
    @staticmethod
    def validate_remote(url):
        if not isinstance(url,str) or '\n' in url or len(url)>2048: raise ValueError('URL distante invalide.')
        url=url.strip()
        if url.startswith('https://'):
            parsed=urllib.parse.urlsplit(url)
            if not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment: raise ValueError('Utilisez une URL HTTPS sans identifiants ni jeton.')
        elif not re.fullmatch(r'git@[A-Za-z0-9._-]+:[A-Za-z0-9._~/-]+(?:\.git)?',url):
            raise ValueError('Utilisez une URL HTTPS ou SSH de la forme git@hôte:organisation/dépôt.git.')
        return url
    def remote(self,url):
        self.require_repo(); url=self.validate_remote(url)
        existing=self.call('remote','get-url','origin',check=False)
        self.call('remote','set-url' if existing.returncode==0 else 'add','origin',url)
    @classmethod
    def clone(cls,parent,name,url,auth=None):
        parent=Path(parent).expanduser().resolve()
        if not parent.is_dir(): raise ValueError('Le dossier parent est introuvable.')
        if not isinstance(name,str) or not name.strip() or name in ('.','..') or '/' in name or '\\' in name or '\0' in name: raise ValueError('Nom de dossier invalide.')
        dest=parent/name.strip()
        if dest.exists(): raise ValueError('Ce dossier existe déjà.')
        cls(parent).call('clone','--',cls.validate_remote(url),str(dest),timeout=180,auth=auth)
        return dest
    def branch(self,name,create=False,source=None):
        self.require_repo()
        if not isinstance(name,str) or not name or name.startswith('-') or '\n' in name: raise ValueError('Nom de branche invalide.')
        self.call('check-ref-format','--branch',name)
        if self.status()['files']: raise ValueError('Commitez ou mettez de côté les modifications et fichiers non suivis avant de changer de branche.')
        if create:
            if source not in self.status()['branches']: raise ValueError('Choisissez une branche source existante.')
            self.call('switch','--no-overwrite-ignore','-c',name,'refs/heads/'+source)
        else: self.call('switch','--no-overwrite-ignore','--',name)

    def network(self,action,auth=None):
        self.require_repo()
        b=self.call('branch','--show-current').stdout.strip()
        if not b or b.startswith('-'): raise ValueError('Une branche courante est nécessaire.')
        if action=='push': return self.call('push','-u','origin','HEAD',timeout=90,auth=auth).stderr
        if action=='pull': return self.call('pull','--ff-only','origin',b,timeout=90,auth=auth).stdout
        raise ValueError('Action Git inconnue.')
    def diff(self,path,staged=False):
        self.require_repo(); path=self.path(path)
        return self.call('diff','--no-ext-diff',*(['--cached'] if staged else []),'--',path).stdout
