"""Documents manuscrits .psnote : JSON UTF-8, PDF de fond embarqué.
Sauvegarde atomique et vérification d'empreinte avant écrasement. Les fichiers
externes ou supprimés ne sont jamais recréés silencieusement.
"""
import hashlib,json,os,tempfile,threading,math,re
from pathlib import Path
MAX_NOTE=75_000_000
MAX_PDF=50_000_000
_lock=threading.RLock()
def digest(data):return hashlib.sha256(data).hexdigest()
def blank():return {'format':'PascalStudioNote','version':1,'background':{'type':'lined'},'pages':[{'items':[]}]}
def validate(d):
 if not isinstance(d,dict) or d.get('format')!='PascalStudioNote' or d.get('version')!=1:raise ValueError('Format de document manuscrit incompatible ou corrompu.')
 bg=d.get('background');pages=d.get('pages')
 if not isinstance(bg,dict) or bg.get('type') not in ('lined','pdf') or not isinstance(pages,list) or not 1<=len(pages)<=1000:raise ValueError('Document manuscrit invalide.')
 if bg['type']=='pdf':
  b=bg.get('data');
  if not isinstance(b,str) or len(b)>((MAX_PDF+2)//3)*4:raise ValueError('Fond PDF absent ou trop volumineux.')
 total=0
 def number(x,low,high):return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) and low<=x<=high
 for page in pages:
  if not isinstance(page,dict) or not isinstance(page.get('items'),list) or len(page['items'])>100000:raise ValueError('Page manuscrite invalide.')
  for item in page['items']:
   if not isinstance(item,dict) or item.get('type') not in ('stroke','text') or not isinstance(item.get('color'),str) or not re.fullmatch(r'#[0-9a-fA-F]{6}',item['color']):raise ValueError('Annotation manuscrite invalide.')
   if item['type']=='stroke':
    pts=item.get('points');total+=len(pts) if isinstance(pts,list) else 0
    if not isinstance(pts,list) or not 1<=len(pts)<=50000 or not number(item.get('width'),.1,100) or not number(item.get('opacity',1),0,1) or total>2_000_000:raise ValueError('Trait manuscrit invalide ou trop volumineux.')
    for pt in pts:
     if not isinstance(pt,dict) or not number(pt.get('x'),0,100000) or not number(pt.get('y'),0,100000) or not number(pt.get('p'),0,1):raise ValueError('Point de trait invalide.')
   else:
    if not number(item.get('x'),0,100000) or not number(item.get('y'),0,100000) or not number(item.get('size'),1,200) or not isinstance(item.get('text'),str) or len(item['text'])>100000:raise ValueError('Texte de page invalide.')
 return d
def load(path):
 p=Path(path)
 if p.suffix.lower()!='.psnote':raise ValueError('Fichier .psnote requis.')
 if p.stat().st_size>MAX_NOTE:raise ValueError('Document manuscrit trop volumineux (maximum 75 Mo).')
 data=p.read_bytes()
 if not data:return {'document':blank(),'revision':digest(data)}
 try:d=json.loads(data.decode('utf-8'))
 except (UnicodeError,json.JSONDecodeError):raise ValueError('Ce fichier .psnote est illisible ou corrompu.')
 return {'document':validate(d),'revision':digest(data)}
def create(path):
 p=Path(path)
 if p.suffix.lower()!='.psnote':raise ValueError('Le nom doit se terminer par .psnote.')
 if not p.parent.is_dir():raise ValueError('Dossier inexistant.')
 data=(json.dumps(blank(),ensure_ascii=False,separators=(',',':'))+'\n').encode()
 with p.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 return {'ok':True,'revision':digest(data)}
def save(path,revision,document):
 p=Path(path);validate(document)
 if p.suffix.lower()!='.psnote' or not isinstance(revision,str):raise ValueError('Document ou révision invalide.')
 data=(json.dumps(document,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf8')
 if len(data)>MAX_NOTE:raise ValueError('Document trop volumineux (maximum 75 Mo).')
 with _lock:
  try:
   if p.stat().st_size>MAX_NOTE:raise ValueError('Le fichier a été remplacé par un document trop volumineux.')
   old=p.read_bytes();mode=p.stat().st_mode&0o777
  except FileNotFoundError:raise ValueError('Fichier supprimé ou déplacé : document conservé dans l’éditeur, non recréé.')
  if digest(old)!=revision:raise ValueError('Conflit : le fichier a été modifié ailleurs. Les changements restent dans l’éditeur ; enregistrez une copie ou rouvrez le fichier.')
  fd,tmp=tempfile.mkstemp(prefix='.psnote-',dir=p.parent)
  try:
   with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
   os.chmod(tmp,mode)
   # Recheck before replacement; not a cross-process compare-and-swap.
   try:current=p.read_bytes()
   except FileNotFoundError:raise ValueError('Fichier supprimé ou déplacé : document non recréé.')
   if digest(current)!=revision:raise ValueError('Conflit : le fichier a été modifié ailleurs ; document conservé.')
   os.replace(tmp,p);tmp=None
  finally:
   if tmp:
    try:os.unlink(tmp)
    except OSError:pass
 return {'ok':True,'revision':digest(data)}
