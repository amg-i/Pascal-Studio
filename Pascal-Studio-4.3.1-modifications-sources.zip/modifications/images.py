#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""La visionneuse d'images : lecture, dimensions, voisinage, lien avec Piet.

POURQUOI CE MODULE EXISTE
  Jusqu'en 4.3.0, ouvrir une image dans Pascal Studio donnait un éditeur de
  texte plein d'octets illisibles : le bundle ne connaît pas les images, et
  `.png` est même l'extension de Piet. Un fichier qu'on ne peut pas voir n'est
  pas un fichier qu'on peut utiliser — et un projet web en contient partout.

  Ce module lit les octets, les porte en data URI (la seule forme qu'un
  <img> sait afficher sans serveur de fichiers), et LIT LES DIMENSIONS dans
  l'en-tête du format. Les dimensions ne sont pas un détail décoratif : sans
  elles, la visionneuse ne peut pas dire si l'image est plus grande que la
  fenêtre, ni proposer un zoom à 100 % qui ait un sens.

SANS AUCUNE BIBLIOTHÈQUE D'IMAGES
  Pillow n'est pas installé et ne doit pas le devenir pour ça. Les dimensions
  sont dans les premiers octets de chaque format : IHDR pour le PNG, marqueur
  SOF pour le JPEG, en-tête logique pour le GIF, fichier BITMAPINFOHEADER pour
  le BMP, sous-blocs VP8/VP8L/VP8X pour le WebP. Les lire est plus court, plus
  sûr et sans dépendance que d'ajouter une bibliothèque de 3 Mo — et c'est la
  même raison qui fait que `langages_esoteriques.decoder_png` décode le PNG à la
  main depuis la 3.8.0.

  Ce module ne REDESSINE JAMAIS une image. Redimensionner côté serveur
  demanderait un décodeur complet ; le navigateur le fait très bien, et le
  faire ici produirait une image dégradée que l'utilisateur prendrait pour
  l'originale.

LE LIEN AVEC PIET
  Un `.png` peut être un programme Piet. La visionneuse le dit quand c'est le
  cas — toutes les couleurs dans la palette des 20 — et propose la conversion
  vers le format texte `.piett` de `piet_texte.py`. Un PNG qui est un programme
  doit pouvoir s'éditer comme un programme.

GARANTIES
  - Ne lève jamais sur un fichier absent, illisible, trop grand ou d'un format
    inconnu : il rend `ok: False` avec la raison. Une visionneuse qui plante
    sur un fichier exotique fait croire que toute la visionneuse est cassée.
  - Borne la taille lue (OCTETS_MAX) : un fichier de 2 Go ne doit pas être
    chargé en mémoire pour être affiché.
  - `resolve()` du serveur est le seul juge des chemins autorisés : ce module ne
    réinvente pas la vérification, il reçoit un chemin déjà résolu.
"""

import base64
import io
import os
import struct
import sys

OCTETS_MAX = 32 * 1024 * 1024      # 32 Mo : au-delà, on refuse et on le dit
IMAGES_PAR_DOSSIER = 400           # borne du voisinage, pour ne pas tout lire

# Extension -> (mime, nom lisible). Les deux sont nécessaires : le mime va dans
# la data URI, le nom va dans l'interface.
FORMATS = {
    '.png': ('image/png', 'PNG'),
    '.jpg': ('image/jpeg', 'JPEG'),
    '.jpeg': ('image/jpeg', 'JPEG'),
    '.jpe': ('image/jpeg', 'JPEG'),
    '.gif': ('image/gif', 'GIF'),
    '.bmp': ('image/bmp', 'BMP'),
    '.webp': ('image/webp', 'WebP'),
    '.ico': ('image/x-icon', 'ICO'),
    '.tif': ('image/tiff', 'TIFF'),
    '.tiff': ('image/tiff', 'TIFF'),
    '.svg': ('image/svg+xml', 'SVG'),
    '.avif': ('image/avif', 'AVIF'),
}

# Ce que la visionneuse affiche sans décoder : tout ce qui a un mime ci-dessus.
# Le SVG est à part parce que c'est du TEXTE : il reste éditable dans Monaco, et
# la visionneuse ne doit pas le lui voler.
EXTENSIONS_IMAGES = tuple(FORMATS)
EXTENSIONS_VISIONNEUSE = tuple(e for e in FORMATS if e != '.svg')

# Les seuls formats dont une extension connue peut être CRUE sans signature :
# le SVG est du XML, et sa détection passe par une balise qu'un fichier
# parfaitement valide peut ne pas exposer dans les premiers octets (déclaration
# XML, commentaire, DOCTYPE, entités) ; l'AVIF peut porter une marque `ftyp` que
# la table des boîtes ne connaît pas encore. Tous les autres formats ont une
# signature fiable : un contenu qui n'en porte aucune n'est pas une image de ce
# format, et le dire vaut mieux que d'afficher une image cassée sans explication
# — c'était le comportement avant cette liste : `photo.png` contenant du texte
# rendait ok:True et une data URI de texte.
TOLERANTS = ('SVG', 'AVIF')


def est_image(chemin):
    """Une extension suffit ici : le contenu est vérifié par `lire()`."""
    return os.path.splitext(str(chemin or ''))[1].lower() in FORMATS


def mime_de(chemin):
    ext = os.path.splitext(str(chemin or ''))[1].lower()
    return FORMATS.get(ext, ('application/octet-stream', 'inconnu'))


# Signatures lisibles dans les OCTETS. L'extension est une déclaration du nom de
# fichier, pas une preuve : un PNG nommé « image » sans extension reste un PNG,
# et un texte nommé « photo.png » ne devient pas une image. Renifler coûte
# quelques comparaisons et évite les deux erreurs à la fois.
SIGNATURES = (
    (b'\x89PNG\r\n\x1a\n', 'image/png', 'PNG'),
    (b'GIF87a', 'image/gif', 'GIF'),
    (b'GIF89a', 'image/gif', 'GIF'),
    (b'BM', 'image/bmp', 'BMP'),
    (b'\xff\xd8\xff', 'image/jpeg', 'JPEG'),
    (b'\x00\x00\x01\x00', 'image/x-icon', 'ICO'),
    (b'II*\x00', 'image/tiff', 'TIFF'),
    (b'MM\x00*', 'image/tiff', 'TIFF'),
)
# Les formats conteneurs se reconnaissent par leurs boîtes, pas par un préfixe.
BOITES_WEBP = (b'WEBP',)
BOITES_AVIF = (b'avif', b'avis', b'mif1', b'msif', b'heic', b'heix')


def detecter_format(octets):
    """Le format lu dans le contenu : {'mime', 'format'}, ou None.

    None ne veut PAS dire « ce n'est pas une image » pour un fichier dont
    l'extension est connue : un SVG n'a aucune signature fiable (c'est du XML),
    et un AVIF peut porter une boîte que cette table ne connaît pas. C'est
    `lire()` qui décide, en croisant ce résultat avec l'extension.
    """
    if not octets:
        return None
    for signature, mime, nom in SIGNATURES:
        if octets.startswith(signature):
            return {'mime': mime, 'format': nom}
    if octets[:4] == b'RIFF' and octets[8:12] in BOITES_WEBP:
        return {'mime': 'image/webp', 'format': 'WebP'}
    if octets[4:8] == b'ftyp' and octets[8:12] in BOITES_AVIF:
        return {'mime': 'image/avif', 'format': 'AVIF'}
    tete = octets[:512].lstrip()
    if tete[:5].lower().lstrip(b'\xef\xbb\xbf').startswith(b'<svg') \
            or (b'<svg' in tete[:400].lower()
                and tete[:60].lower().startswith(b'<?xml')):
        return {'mime': 'image/svg+xml', 'format': 'SVG'}
    return None


# ---------------------------------------------------------------------------
# dimensions, format par format
# ---------------------------------------------------------------------------

def _png(octets):
    if len(octets) < 24 or octets[:8] != b'\x89PNG\r\n\x1a\n':
        return None
    if octets[12:16] != b'IHDR':
        return None
    largeur, hauteur = struct.unpack('>II', octets[16:24])
    return (largeur, hauteur)


def _gif(octets):
    if len(octets) < 10 or octets[:3] != b'GIF':
        return None
    largeur, hauteur = struct.unpack('<HH', octets[6:10])
    return (largeur, hauteur)


def _bmp(octets):
    if len(octets) < 26 or octets[:2] != b'BM':
        return None
    # Le champ « taille d'en-tête » distingue BITMAPCOREHEADER (12) des autres.
    taille_en_tete = struct.unpack('<I', octets[14:18])[0]
    if taille_en_tete == 12:
        if len(octets) < 22:
            return None
        largeur, hauteur = struct.unpack('<HH', octets[18:22])
    else:
        largeur, hauteur = struct.unpack('<ii', octets[18:26])
        hauteur = abs(hauteur)
    return (largeur, hauteur)


def _jpeg(octets):
    if len(octets) < 4 or octets[:2] != b'\xff\xd8':
        return None
    position = 2
    longueur = len(octets)
    while position + 9 < longueur:
        if octets[position] != 0xFF:
            position += 1
            continue
        # Les marqueurs de remplissage (FF FF …) se sautent, sinon la lecture
        # déraille sur les JPEG issus de certains appareils.
        while position < longueur and octets[position] == 0xFF:
            position += 1
        if position >= longueur:
            return None
        marqueur = octets[position]
        position += 1
        if marqueur == 0xD8 or marqueur == 0x01 or 0xD0 <= marqueur <= 0xD9:
            continue                      # marqueurs sans longueur
        if position + 2 > longueur:
            return None
        taille = struct.unpack('>H', octets[position:position + 2])[0]
        if taille < 2:
            return None
        # SOF0..SOF15, sauf DHT (C4), JPG (C8) et DAC (CC) : ce sont les seuls
        # blocs qui portent les dimensions.
        if 0xC0 <= marqueur <= 0xCF and marqueur not in (0xC4, 0xC8, 0xCC):
            if position + 7 > longueur:
                return None
            hauteur, largeur = struct.unpack('>HH',
                                             octets[position + 3:position + 7])
            return (largeur, hauteur)
        position += taille
    return None


def _webp(octets):
    # Le garde commun ne peut pas exiger 30 octets : un WebP sans perte valide
    # tient en 25. Chaque variante vérifie ensuite sa propre longueur — un garde
    # trop large faisait rendre None sur un fichier correct.
    if len(octets) < 16 or octets[:4] != b'RIFF' or octets[8:12] != b'WEBP':
        return None
    sous = octets[12:16]
    if sous == b'VP8 ':
        if len(octets) < 26:
            return None
        # Après l'en-tête de sous-bloc et la signature de trame 9D 0A 2A.
        index = octets.find(b'\x9d\x0a\x2a', 20)
        if index < 0 or index + 7 > len(octets):
            return None
        largeur, hauteur = struct.unpack('<HH', octets[index + 3:index + 7])
        return (largeur & 0x3FFF, hauteur & 0x3FFF)
    if sous == b'VP8L':
        if len(octets) < 25:
            return None
        if octets[20] != 0x2F:
            return None
        bits = struct.unpack('<I', octets[21:25])[0]
        return ((bits & 0x3FFF) + 1, ((bits >> 14) & 0x3FFF) + 1)
    if sous == b'VP8X':
        if len(octets) < 30:
            return None
        largeur = 1 + (octets[24] | (octets[25] << 8) | (octets[26] << 16))
        hauteur = 1 + (octets[27] | (octets[28] << 8) | (octets[29] << 16))
        return (largeur, hauteur)
    return None


def _ico(octets):
    if len(octets) < 22 or struct.unpack('<H', octets[:2])[0] != 0:
        return None
    if struct.unpack('<H', octets[2:4])[0] != 1:
        return None
    nombre = struct.unpack('<H', octets[4:6])[0]
    if nombre < 1:
        return None
    largeur = octets[6] or 256
    hauteur = octets[7] or 256
    return (largeur, hauteur)


def _tiff(octets):
    if len(octets) < 8:
        return None
    if octets[:2] in (b'II', b'MM'):
        pass
    else:
        return None
    petit = octets[:2] == b'II'
    format_nombre = '<' if petit else '>'
    magique = struct.unpack(format_nombre + 'H', octets[2:4])[0]
    if magique != 42:
        return None
    debut = struct.unpack(format_nombre + 'I', octets[4:8])[0]
    if debut + 2 > len(octets):
        return None
    nombre = struct.unpack(format_nombre + 'H', octets[debut:debut + 2])[0]
    if nombre > 4096:
        return None
    largeur = hauteur = None
    for i in range(nombre):
        entree = debut + 2 + i * 12
        if entree + 12 > len(octets):
            break
        etiquette = struct.unpack(format_nombre + 'H', octets[entree:entree + 2])[0]
        valeur = struct.unpack(format_nombre + 'I', octets[entree + 8:entree + 12])[0]
        if etiquette == 256:
            largeur = valeur
        elif etiquette == 257:
            hauteur = valeur
    if largeur and hauteur:
        return (largeur, hauteur)
    return None


LECTEURS_DIMENSIONS = {
    'image/png': _png,
    'image/gif': _gif,
    'image/bmp': _bmp,
    'image/jpeg': _jpeg,
    'image/webp': _webp,
    'image/x-icon': _ico,
    'image/tiff': _tiff,
}


def dimensions(octets, mime):
    """Les dimensions lues dans l'en-tête, ou None si le format ne les porte pas."""
    lecteur = LECTEURS_DIMENSIONS.get(mime)
    if lecteur is None:
        return None
    try:
        return lecteur(octets)
    except struct.error:
        return None
    except Exception:                                       # noqa: BLE001
        return None


# ---------------------------------------------------------------------------
# Piet
# ---------------------------------------------------------------------------

def _charger_esot():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import langages_esoteriques as esot
        return esot
    except Exception:                                       # noqa: BLE001
        return None


def analyser_piet(octets):
    """Un PNG est-il un programme Piet ? Répondu sans jamais lever.

    Le critère est POSITIF et non « ça ressemble » : le PNG se décode, et toutes
    ses couleurs sont dans la palette des 20. Un logo en 256 couleurs n'est pas
    un programme Piet, et le dire à tort ferait proposer une conversion qui
    produirait un fichier plein de blancs.
    """
    resultat = {'est_piet': False, 'raison': '', 'couleurs': 0,
                'hors_palette': 0, 'largeur': 0, 'hauteur': 0, 'codel': 0}
    if not isinstance(octets, bytes) or not octets:
        resultat['raison'] = 'Aucun octet à examiner.'
        return resultat
    esot = _charger_esot()
    if esot is None:
        resultat['raison'] = 'Le module des langages ésotériques est absent.'
        return resultat
    try:
        largeur, hauteur, pixels = esot.decoder_png(octets)
    except Exception as exc:                                # noqa: BLE001
        resultat['raison'] = 'PNG illisible : %s' % exc
        return resultat
    resultat['largeur'], resultat['hauteur'] = largeur, hauteur
    connues = set(tuple(v) for v in esot.COULEURS_PIET.values())
    connues.add(tuple(esot.BLANC_PIET))
    connues.add(tuple(esot.NOIR_PIET))
    vues = set()
    hors = 0
    for ligne in pixels:
        for pixel in ligne:
            vues.add(tuple(pixel))
            if tuple(pixel) not in connues:
                hors += 1
    resultat['couleurs'] = len(vues)
    resultat['hors_palette'] = hors
    if hors:
        resultat['raison'] = ('%d pixel(s) hors de la palette Piet : c’est une '
                              'image, pas un programme.' % hors)
        return resultat
    try:
        import piet_texte
        resultat['codel'] = piet_texte.detecter_codel(largeur, hauteur, pixels)
    except Exception:                                       # noqa: BLE001
        resultat['codel'] = 1
    resultat['est_piet'] = True
    resultat['raison'] = ('Toutes les couleurs sont dans la palette Piet '
                          '(%d couleurs, codel %d).'
                          % (len(vues), resultat['codel']))
    return resultat


def convertir_en_texte(octets, codel=None):
    """Le PNG Piet en source `.piett`, via `piet_texte.depuis_png`."""
    import piet_texte
    conversion = piet_texte.depuis_png(octets, codel=codel)
    conversion['ok'] = True
    return conversion


# ---------------------------------------------------------------------------
# lecture
# ---------------------------------------------------------------------------

def lire(chemin, dossier=None):
    """Lit une image et rend tout ce que la visionneuse affiche.

    `chemin` doit être DÉJÀ résolu et autorisé par le serveur : ce module ne
    réinvente pas la vérification des chemins, qui est le métier de
    `server.resolve()`. `dossier` sert au voisinage (image suivante/précédente).

    Ne lève jamais.
    """
    reponse = {'ok': False, 'chemin': str(chemin), 'nom': os.path.basename(
        str(chemin)), 'mime': '', 'format': '', 'taille': 0, 'uri': '',
        'largeur': 0, 'hauteur': 0, 'dimensions_connues': False,
        'modifie': '', 'piet': None, 'erreur': '', 'voisins': []}
    try:
        if not chemin or not os.path.isfile(chemin):
            reponse['erreur'] = 'Fichier introuvable : %s' % chemin
            return reponse
        taille = os.path.getsize(chemin)
        reponse['taille'] = taille
        try:
            reponse['modifie'] = __import__('datetime').datetime.fromtimestamp(
                os.path.getmtime(chemin)).strftime('%Y-%m-%d %H:%M:%S')
        except Exception:                                   # noqa: BLE001
            reponse['modifie'] = ''
        if taille > OCTETS_MAX:
            reponse['erreur'] = ('Image de %.1f Mo : la borne de la visionneuse '
                                 'est de %d Mo. Elle s’affiche dans un outil '
                                 'externe.'
                                 % (taille / 1048576.0, OCTETS_MAX // 1048576))
            return reponse
        if taille == 0:
            reponse['erreur'] = 'Fichier vide : rien à afficher.'
            return reponse
        mime, nom = mime_de(chemin)
        with open(chemin, 'rb') as flux:
            octets = flux.read()
        detecte = detecter_format(octets)
        if detecte:
            # Le contenu tranche : il corrige une extension absente ou menteuse.
            mime, nom = detecte['mime'], detecte['format']
        elif nom == 'inconnu':
            # Ni extension connue ni signature : sans cette garde, lire()
            # rendait ok:True avec une data URI de texte, et la visionneuse
            # affichait une image cassée en accusant Electron (« le navigateur
            # n'a pas pu afficher cette image ») pour un fichier qui n'est tout
            # simplement pas une image.
            reponse['mime'], reponse['format'] = mime, nom
            reponse['erreur'] = (
                '%s n’est pas une image reconnue : ni son extension ni son '
                'contenu ne correspondent aux %d formats lus ici (%s). Un '
                'fichier texte s’ouvre dans l’éditeur, pas dans la '
                'visionneuse.'
                % (reponse['nom'], len(FORMATS), ', '.join(sorted(FORMATS))))
            return reponse
        elif nom not in TOLERANTS:
            # Extension connue, signature fiable attendue, contenu qui n'en porte
            # aucune : ce n'est pas une image de ce format. Le refus est expliqué,
            # et il nomme l'écart entre le nom et le contenu — sans lui la
            # visionneuse affichait une image cassée et l'utilisateur accusait
            # l'application. Le SVG et l'AVIF passent outre : voir TOLERANTS.
            reponse['mime'], reponse['format'] = mime, nom
            reponse['erreur'] = (
                '%s porte l’extension d’un %s, mais son contenu ne commence par '
                'aucune signature d’image connue : ce n’est pas un %s lisible. '
                'S’il s’agit d’un fichier texte, ouvrez-le dans l’éditeur ; '
                's’il a été tronqué ou renommé, il est à recharger.'
                % (reponse['nom'], nom, nom))
            return reponse
        reponse['mime'], reponse['format'] = mime, nom
        dim = dimensions(octets, mime)
        if dim:
            reponse['largeur'], reponse['hauteur'] = dim
            reponse['dimensions_connues'] = True
        reponse['uri'] = ('data:%s;base64,%s'
                          % (mime, base64.b64encode(octets).decode('ascii')))
        if mime == 'image/png':
            reponse['piet'] = analyser_piet(octets)
        reponse['ok'] = True
        if dossier:
            reponse['voisins'] = voisins(chemin, dossier)
        return reponse
    except OSError as exc:
        reponse['erreur'] = 'Lecture impossible : %s' % exc
        return reponse
    except Exception as exc:                                # noqa: BLE001
        reponse['erreur'] = '%s : %s' % (type(exc).__name__, exc)
        return reponse


def voisins(chemin, dossier):
    """Les autres images du même dossier, pour « précédente » et « suivante ».

    Une visionneuse sans voisinage oblige à repasser par l'arborescence à chaque
    image. La liste est TRIÉE et BORNEE : un dossier de 10 000 captures ne doit
    pas produire une réponse de 10 000 entrées.
    """
    sortie = {'ok': False, 'images': [], 'position': -1, 'total': 0,
              'erreur': ''}
    try:
        cible = os.path.basename(str(chemin))
        if not dossier or not os.path.isdir(dossier):
            sortie['erreur'] = 'Dossier introuvable.'
            return sortie
        noms = []
        for nom in sorted(os.listdir(dossier)):
            if os.path.splitext(nom)[1].lower() not in EXTENSIONS_VISIONNEUSE:
                continue
            if not os.path.isfile(os.path.join(dossier, nom)):
                continue
            noms.append(nom)
            if len(noms) >= IMAGES_PAR_DOSSIER:
                break
        sortie['images'] = noms
        sortie['total'] = len(noms)
        sortie['position'] = noms.index(cible) if cible in noms else -1
        sortie['ok'] = True
        return sortie
    except OSError as exc:
        sortie['erreur'] = 'Lecture du dossier impossible : %s' % exc
        return sortie


def capacites():
    """Ce que la visionneuse sait faire, dit par elle-même."""
    return {'ok': True, 'formats': sorted(FORMATS),
            'formats_avec_dimensions': sorted(
                k for k in LECTEURS_DIMENSIONS),
            'octets_max': OCTETS_MAX, 'voisinage': True,
            'piet': True, 'conversion_piet_texte': True,
            'redimensionnement_serveur': False,
            'raison_redimensionnement': ('Le navigateur redimensionne à '
                                         'l’affichage ; le faire côté serveur '
                                         'dégradait l’image sans le dire.')}


# ---------------------------------------------------------------------------
# autocontrôle
# ---------------------------------------------------------------------------

COMPTEUR = {'verifs': 0}


def verif(condition, message):
    COMPTEUR['verifs'] += 1
    if not condition:
        raise AssertionError(message)


def _png_test(largeur, hauteur, couleur=(0xff, 0x00, 0x00)):
    import zlib
    brutes = bytearray()
    for _y in range(hauteur):
        brutes.append(0)
        brutes.extend(bytes(couleur) * largeur)

    def bloc(nom, donnees):
        import zlib as z
        corps = nom + donnees
        return (struct.pack('>I', len(donnees)) + corps
                + struct.pack('>I', z.crc32(corps) & 0xffffffff))
    return (b'\x89PNG\r\n\x1a\n'
            + bloc(b'IHDR', struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0))
            + bloc(b'IDAT', zlib.compress(bytes(brutes), 9))
            + bloc(b'IEND', b''))


def verifier():
    problemes = []
    depart = COMPTEUR['verifs']

    def sans_lever(titre, fonction):
        try:
            fonction()
        except AssertionError as exc:
            problemes.append('%s : %s' % (titre, exc))
        except Exception as exc:                            # noqa: BLE001
            problemes.append('%s : exception %s (%s)'
                             % (titre, type(exc).__name__, exc))

    import shutil
    import tempfile
    dossier = tempfile.mkdtemp(prefix='ps-images-')

    def tout():
        # --- la table des formats ---------------------------------------
        verif(len(FORMATS) >= 11, 'la table des formats est trop courte (%d)'
              % len(FORMATS))
        for ext in ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp', '.ico',
                    '.tiff', '.svg'):
            verif(ext in FORMATS, '%s manque dans la table des formats' % ext)
        verif('.svg' not in EXTENSIONS_VISIONNEUSE,
              'le SVG est du TEXTE : il doit rester éditable dans Monaco et ne '
              'pas être accaparé par la visionneuse')
        verif('.png' in EXTENSIONS_VISIONNEUSE, 'le PNG doit être vu')
        verif(mime_de('x.PNG') == ('image/png', 'PNG'),
              'l’extension doit être reconnue sans tenir compte de la casse')
        verif(mime_de('x.zzz')[0] == 'application/octet-stream',
              'une extension inconnue doit rendre un mime neutre')
        verif(est_image('a/b/c.jpeg') and not est_image('a/b/c.pas'),
              'est_image se trompe')
        verif(est_image('sans-extension') is False,
              'un fichier sans extension n’est pas une image')

        # --- dimensions par format --------------------------------------
        png = _png_test(7, 5)
        verif(dimensions(png, 'image/png') == (7, 5),
              'les dimensions du PNG sont fausses (%r)'
              % (dimensions(png, 'image/png'),))
        verif(dimensions(png[:20], 'image/png') is None,
              'un PNG tronqué ne doit pas lever')
        verif(dimensions(b'pas un png', 'image/png') is None,
              'un non-PNG ne doit pas lever')

        gif = b'GIF89a' + struct.pack('<HH', 11, 9) + b'\x00' * 20
        verif(dimensions(gif, 'image/gif') == (11, 9), 'les dimensions du GIF')
        verif(dimensions(b'GIF89a\x01', 'image/gif') is None, 'un GIF court')

        bmp = b'BM' + b'\x00' * 12 + struct.pack('<I', 40) \
            + struct.pack('<ii', 33, -22) + b'\x00' * 20
        verif(dimensions(bmp, 'image/bmp') == (33, 22),
              'un BMP de hauteur négative doit rendre une hauteur positive')
        bmp_core = b'BM' + b'\x00' * 12 + struct.pack('<I', 12) \
            + struct.pack('<HH', 8, 6) + b'\x00' * 10
        verif(dimensions(bmp_core, 'image/bmp') == (8, 6),
              'BITMAPCOREHEADER (en-tête de 12 octets) doit être reconnu')

        # JPEG : SOF0 après un APP0 et un DHT, pour vérifier le saut des blocs.
        app0 = b'\xff\xe0' + struct.pack('>H', 16) + b'JFIF\x00' + b'\x00' * 9
        dht = b'\xff\xc4' + struct.pack('>H', 8) + b'\x00' * 6
        sof = b'\xff\xc0' + struct.pack('>H', 17) + b'\x08' \
            + struct.pack('>HH', 480, 640) + b'\x03' + b'\x00' * 6
        jpeg = b'\xff\xd8' + app0 + dht + sof + b'\xff\xd9'
        verif(dimensions(jpeg, 'image/jpeg') == (640, 480),
              'les dimensions du JPEG sont fausses (%r) : la hauteur vient '
              'AVANT la largeur dans SOF' % (dimensions(jpeg, 'image/jpeg'),))
        # Un marqueur de remplissage avant SOF ne doit pas casser la lecture.
        jpeg_bourre = b'\xff\xd8' + b'\xff' * 5 + sof + b'\xff\xd9'
        verif(dimensions(jpeg_bourre, 'image/jpeg') == (640, 480),
              'les octets de remplissage FF doivent être sautés')
        # SOS : après lui, les données sont entropiques et ne doivent PAS être
        # parcourues comme des marqueurs.
        sos = b'\xff\xda' + struct.pack('>H', 8) + b'\x00' * 6
        verif(dimensions(b'\xff\xd8' + sos + b'\xff' * 200, 'image/jpeg') is None,
              'un JPEG sans SOF doit rendre None, pas une fausse dimension')
        verif(dimensions(b'\xff\xd8', 'image/jpeg') is None, 'un JPEG vide')

        # WebP : les trois variantes.
        vp8x = b'RIFF' + struct.pack('<I', 30) + b'WEBPVP8X' \
            + struct.pack('<I', 10) + b'\x00' * 4 \
            + bytes((99 & 0xff, (99 >> 8) & 0xff, (99 >> 16) & 0xff)) \
            + bytes((49 & 0xff, (49 >> 8) & 0xff, (49 >> 16) & 0xff))
        verif(dimensions(vp8x, 'image/webp') == (100, 50),
              'les dimensions du WebP étendu sont fausses (%r)'
              % (dimensions(vp8x, 'image/webp'),))
        vp8l = b'RIFF' + struct.pack('<I', 20) + b'WEBPVP8L' \
            + struct.pack('<I', 5) + b'\x2f' \
            + struct.pack('<I', ((30 - 1) & 0x3FFF) | (((20 - 1) & 0x3FFF) << 14))
        verif(dimensions(vp8l, 'image/webp') == (30, 20),
              'les dimensions du WebP sans perte sont fausses (%r)'
              % (dimensions(vp8l, 'image/webp'),))
        vp8 = (b'RIFF' + struct.pack('<I', 30) + b'WEBPVP8 '
               + struct.pack('<I', 20) + b'\x00' * 8 + b'\x9d\x0a\x2a'
               + struct.pack('<HH', 16, 12))
        verif(dimensions(vp8, 'image/webp') == (16, 12),
              'les dimensions du WebP avec perte sont fausses (%r)'
              % (dimensions(vp8, 'image/webp'),))
        verif(dimensions(b'RIFF\x00\x00\x00\x00AVI ', 'image/webp') is None,
              'un RIFF qui n’est pas du WebP doit rendre None')

        ico = struct.pack('<HHH', 0, 1, 1) + bytes((32, 32)) + b'\x00' * 14
        verif(dimensions(ico, 'image/x-icon') == (32, 32), 'les dimensions de l’ICO')
        ico256 = struct.pack('<HHH', 0, 1, 1) + bytes((0, 0)) + b'\x00' * 14
        verif(dimensions(ico256, 'image/x-icon') == (256, 256),
              'dans un ICO, 0 veut dire 256')

        # TIFF : les deux ordres d'octets. Une entrée d'IFD fait 12 octets —
        # étiquette(2) type(2) nombre(4) valeur(4) — et c'est le DERNIER champ
        # qui porte la dimension : écrire la valeur dans le champ « nombre »
        # donnait un TIFF de 0 x 0.
        for ordre, fmt in ((b'II', '<'), (b'MM', '>')):
            def entree(fmt2, etiquette, valeur):
                return (struct.pack(fmt2 + 'HHI', etiquette, 4, 1)
                        + struct.pack(fmt2 + 'I', valeur))
            tiff = (ordre + struct.pack(fmt + 'HI', 42, 8)
                    + struct.pack(fmt + 'H', 2)
                    + entree(fmt, 256, 123) + entree(fmt, 257, 77))
            verif(dimensions(tiff, 'image/tiff') == (123, 77),
                  'les dimensions du TIFF %s sont fausses (%r)'
                  % (fmt, dimensions(tiff, 'image/tiff')))
        # Un TIFF dont l'IFD annonce plus d'entrées qu'il n'y en a ne doit pas
        # lever : la lecture s'arrête au bout du fichier.
        tiff_court = b'II' + struct.pack('<HI', 42, 8) + struct.pack('<H', 40) \
            + struct.pack('<HHI', 256, 4, 1) + struct.pack('<I', 9)
        verif(dimensions(tiff_court, 'image/tiff') is None,
              'un IFD tronqué doit rendre None, pas lever')
        verif(dimensions(b'II' + b'\x00' * 30, 'image/tiff') is None,
              'un TIFF sans le magique 42 doit rendre None')

        verif(dimensions(b'\x00' * 40, 'image/svg+xml') is None,
              'le SVG ne porte pas de dimensions dans un en-tête binaire')
        verif(dimensions(b'\x00' * 40, 'inconnu/x') is None,
              'un mime inconnu doit rendre None sans lever')

        # --- Piet --------------------------------------------------------
        import piet_texte
        programme = piet_texte.vers_png(piet_texte.exemple())
        analyse = analyser_piet(programme)
        verif(analyse['est_piet'] is True,
              'le PNG de l’exemple doit être reconnu comme Piet (%r)' % analyse)
        verif(analyse['codel'] == 4, 'le codel doit être retrouvé (%d)'
              % analyse['codel'])
        verif(analyse['hors_palette'] == 0, 'aucune couleur hors palette')
        verif(analyse['largeur'] == 12 and analyse['hauteur'] == 4,
              'les dimensions du programme sont fausses')

        logo = _png_test(4, 4, (0x12, 0x34, 0x56))
        analyse_logo = analyser_piet(logo)
        verif(analyse_logo['est_piet'] is False,
              'une couleur hors palette ne doit PAS être annoncée comme Piet')
        verif(analyse_logo['hors_palette'] == 16,
              'les 16 pixels doivent être comptés hors palette (%d)'
              % analyse_logo['hors_palette'])
        verif('pas un programme' in analyse_logo['raison'],
              'la raison doit dire que ce n’est pas un programme')

        verif(analyser_piet(b'')['est_piet'] is False, 'rien à examiner')
        verif(analyser_piet(b'pas un png')['est_piet'] is False,
              'un non-PNG ne doit pas être annoncé comme Piet')
        verif(analyser_piet(None)['est_piet'] is False, 'None ne lève pas')
        # Le critère est positif : un PNG noir et blanc EST dans la palette.
        noir_blanc = _png_test(2, 2, (0x00, 0x00, 0x00))
        verif(analyser_piet(noir_blanc)['est_piet'] is True,
              'le noir est dans la palette Piet')

        conversion = convertir_en_texte(programme)
        verif(conversion['ok'] and conversion['texte'],
              'la conversion en .piett échoue')
        verif(piet_texte.decoder(conversion['texte'])['cellules']
              == [['rc', 'rn', 'ms']], 'la grille convertie est fausse')
        resultat = piet_texte.executer(conversion['texte'])
        verif('1' in (resultat.get('sortie') or resultat.get('output') or ''),
              'le programme converti doit encore écrire 1')

        # --- fichiers réels ---------------------------------------------
        chemin_png = os.path.join(dossier, 'programme.png')
        with open(chemin_png, 'wb') as flux:
            flux.write(programme)
        lu = lire(chemin_png, dossier=dossier)
        verif(lu['ok'] is True, 'la lecture du PNG échoue : %s' % lu['erreur'])
        verif(lu['mime'] == 'image/png' and lu['format'] == 'PNG', 'mime/format')
        verif(lu['taille'] == len(programme), 'la taille est fausse')
        verif(lu['uri'].startswith('data:image/png;base64,'), 'la data URI')
        verif(base64.b64decode(lu['uri'].split(',', 1)[1]) == programme,
              'la data URI doit porter exactement les octets du fichier')
        verif(lu['largeur'] == 12 and lu['hauteur'] == 4, 'les dimensions lues')
        verif(lu['dimensions_connues'] is True, 'les dimensions sont annoncées')
        verif(lu['modifie'] and len(lu['modifie']) == 19, 'la date de modification')
        verif(lu['piet'] and lu['piet']['est_piet'] is True,
              'un PNG Piet doit être signalé comme tel')
        verif(lu['voisins']['ok'] is True, 'le voisinage doit être rendu')

        chemin_jpg = os.path.join(dossier, 'photo.jpg')
        with open(chemin_jpg, 'wb') as flux:
            flux.write(jpeg)
        lu_jpg = lire(chemin_jpg)
        verif(lu_jpg['ok'] and lu_jpg['largeur'] == 640,
              'la lecture du JPEG échoue')
        verif(lu_jpg['piet'] is None,
              'un JPEG n’est pas analysé comme Piet : ce n’est pas un PNG')

        # Un fichier texte n'est PAS une image. L'autocontrôle affirmait ici le
        # contraire (« reste lisible, mime neutre ») : la visionneuse recevait
        # alors une data URI de texte et affichait une image cassée en accusant
        # Electron. Le refus est désormais le comportement attendu, et il est
        # expliqué.
        chemin_txt = os.path.join(dossier, 'notes.txt')
        with open(chemin_txt, 'w', encoding='utf8') as flux:
            flux.write('pas une image')
        lu_txt = lire(chemin_txt)
        verif(lu_txt['ok'] is False,
              'un fichier texte doit être refusé par la visionneuse')
        verif('n’est pas une image' in lu_txt['erreur'],
              'le refus doit dire que ce n’est pas une image (%r)'
              % lu_txt['erreur'])
        verif('.png' in lu_txt['erreur'] and '.svg' in lu_txt['erreur'],
              'le refus doit rappeler les formats acceptés (%r)'
              % lu_txt['erreur'][:120])
        verif(lu_txt['uri'] == '', 'un refus ne doit pas porter de data URI')
        verif(lu_txt['dimensions_connues'] is False,
              'des dimensions inconnues doivent être dites inconnues, pas 0 '
              'avec dimensions_connues vrai')

        # Le contenu prime sur le nom : un PNG sans extension reste lisible, et
        # un texte renommé .png ne devient pas une image valable.
        chemin_sans_extension = os.path.join(dossier, 'image_sans_extension')
        with open(chemin_sans_extension, 'wb') as flux:
            flux.write(_png_test(3, 2))
        lu_sans_extension = lire(chemin_sans_extension)
        verif(lu_sans_extension['ok'] is True,
              'un PNG sans extension doit rester lisible (%r)'
              % lu_sans_extension['erreur'])
        verif(lu_sans_extension['mime'] == 'image/png',
              'le mime doit venir du contenu, pas de l’extension (%r)'
              % lu_sans_extension['mime'])
        verif(lu_sans_extension['format'] == 'PNG',
              'le format doit être nommé d’après le contenu')
        verif((lu_sans_extension['largeur'], lu_sans_extension['hauteur'])
              == (3, 2), 'les dimensions doivent être lues dans l’en-tête')
        texte_deguise = os.path.join(dossier, 'deguise.png')
        with open(texte_deguise, 'w', encoding='utf8') as flux:
            flux.write('pas une image du tout')
        verif(detecter_format(b'pas une image du tout') is None,
              'le renifleur ne doit pas reconnaître du texte')
        verif(detecter_format(_png_test(2, 2))['mime'] == 'image/png',
              'le renifleur doit reconnaître un PNG')
        verif(detecter_format(b'') is None, 'le renifleur ne lève pas sur vide')
        verif(detecter_format(None) is None, 'le renifleur ne lève pas sur None')
        # Le commentaire ci-dessus annonce qu'un texte renommé .png « ne devient
        # pas une image valable » : encore fallait-il le vérifier. Sans ces
        # contrôles, lire() rendait ok:True et une data URI de texte, et la
        # visionneuse affichait une image cassée sans rien expliquer.
        lu_deguise = lire(texte_deguise)
        verif(lu_deguise['ok'] is False,
              'un texte nommé .png doit être refusé (%r)' % lu_deguise['erreur'])
        verif('signature' in lu_deguise['erreur'],
              'le refus doit nommer la signature absente (%r)'
              % lu_deguise['erreur'][:160])
        verif('PNG' in lu_deguise['erreur'],
              'le refus doit rappeler le format annoncé par le nom (%r)'
              % lu_deguise['erreur'][:160])
        verif(lu_deguise['uri'] == '', 'un refus ne porte pas de data URI')
        verif(lu_deguise['format'] == 'PNG',
              'le format annoncé reste celui de l’extension, pour que le refus '
              'soit lisible (%r)' % lu_deguise['format'])
        texte_deguise_jpg = os.path.join(dossier, 'deguise.jpg')
        with open(texte_deguise_jpg, 'w', encoding='utf8') as flux:
            flux.write('pas une photo')
        verif(lire(texte_deguise_jpg)['ok'] is False,
              'un texte nommé .jpg doit être refusé lui aussi')
        # La tolérance n'est pas supprimée, elle est CIBLÉE : les deux formats
        # sans signature fiable restent lus sur la foi de leur extension.
        verif(set(TOLERANTS) <= {n for _m, n in FORMATS.values()},
              'TOLERANTS nomme un format absent de FORMATS : %r' % (TOLERANTS,))
        svg_sans_marque = os.path.join(dossier, 'puzzle.svg')
        with open(svg_sans_marque, 'w', encoding='utf8') as flux:
            flux.write('<!-- aucune balise svg dans les premiers octets -->\n')
        lu_svg = lire(svg_sans_marque)
        verif(lu_svg['ok'] is True,
              'un SVG sans balise dans l’en-tête doit rester toléré (%r)'
              % lu_svg['erreur'])
        verif(lu_svg['dimensions_connues'] is False,
              'un SVG sans dimensions ne doit pas en inventer')
        verif(lu_svg['mime'] == 'image/svg+xml',
              'le mime d’un SVG toléré vient de l’extension (%r)'
              % lu_svg['mime'])

        # --- les refus ---------------------------------------------------
        manquant = lire(os.path.join(dossier, 'absent.png'))
        verif(manquant['ok'] is False and 'introuvable' in manquant['erreur'],
              'un fichier absent doit le dire (%r)' % manquant['erreur'])
        vide = os.path.join(dossier, 'vide.png')
        with open(vide, 'wb') as flux:
            flux.write(b'')
        lu_vide = lire(vide)
        verif(lu_vide['ok'] is False and 'vide' in lu_vide['erreur'],
              'un fichier vide doit le dire (%r)' % lu_vide['erreur'])
        verif(lire('')['ok'] is False, 'un chemin vide ne lève pas')
        verif(lire(None)['ok'] is False, 'None ne lève pas')
        dossier_inexistant = lire(chemin_png, dossier=os.path.join(dossier, 'x'))
        verif(dossier_inexistant['ok'] is True
              and dossier_inexistant['voisins']['ok'] is False,
              'un dossier de voisinage absent ne doit pas faire échouer la lecture')

        # La borne de taille doit refuser SANS lire le fichier en entier.
        gros = os.path.join(dossier, 'gros.png')
        with open(gros, 'wb') as flux:
            flux.write(_png_test(2, 2)[:24])
            flux.truncate(OCTETS_MAX + 1024)
        lu_gros = lire(gros)
        verif(lu_gros['ok'] is False, 'une image trop grande doit être refusée')
        verif(lu_gros['taille'] == OCTETS_MAX + 1024,
              'la taille doit être annoncée même en cas de refus')
        verif('borne' in lu_gros['erreur'], 'le refus doit donner la borne')
        verif(lu_gros['uri'] == '', 'un refus ne doit pas porter de data URI')

        # --- voisinage ---------------------------------------------------
        for nom in ('a.png', 'b.png', 'c.gif', 'd.txt', 'e.svg'):
            with open(os.path.join(dossier, nom), 'wb') as flux:
                flux.write(b'\x89PNG\r\n\x1a\n' if nom.endswith('png')
                           else b'x')
        voi = voisins(os.path.join(dossier, 'b.png'), dossier)
        verif(voi['ok'] is True, 'le voisinage échoue : %s' % voi['erreur'])
        verif('b.png' in voi['images'], 'l’image demandée doit être listée')
        verif(voi['position'] == voi['images'].index('b.png'),
              'la position doit être juste')
        verif('d.txt' not in voi['images'], 'un .txt n’est pas une image')
        verif('e.svg' not in voi['images'],
              'le SVG ne fait pas partie du voisinage de la visionneuse')
        verif(voi['images'] == sorted(voi['images']), 'la liste doit être triée')
        verif(len(voi['images']) <= IMAGES_PAR_DOSSIER, 'la borne du voisinage')
        verif(voisins('x.png', os.path.join(dossier, 'absent'))['ok'] is False,
              'un dossier absent doit le dire')
        verif(voisins('x.png', '')['ok'] is False, 'un dossier vide doit le dire')
        verif(voisins('x.png', chemin_png)['ok'] is False,
              'un fichier à la place du dossier doit le dire')
        inconnu = voisins(os.path.join(dossier, 'zzz.png'), dossier)
        verif(inconnu['ok'] is True and inconnu['position'] == -1,
              'une image absente de la liste doit rendre -1, pas lever')

        # --- capacités ---------------------------------------------------
        caps = capacites()
        verif(caps['ok'] is True, 'capacites doit être ok')
        verif('.png' in caps['formats'], 'les formats annoncés')
        verif('image/png' in caps['formats_avec_dimensions'],
              'les formats à dimensions annoncés')
        verif(caps['redimensionnement_serveur'] is False,
              'le module ne redimensionne PAS : l’annonce doit le dire')
        verif(caps['raison_redimensionnement'],
              'un « non » doit être expliqué')
        verif(caps['octets_max'] == OCTETS_MAX, 'la borne annoncée')
        # Confrontation BIDIRECTIONNELLE entre l'annonce et la réalité : une
        # capacité annoncée sans exister est le défaut le plus trompeur.
        for cle in caps['formats']:
            verif(cle in FORMATS, '%s est annoncé mais absent' % cle)
        for cle in FORMATS:
            verif(cle in caps['formats'], '%s existe mais n’est pas annoncé' % cle)
        for mime in caps['formats_avec_dimensions']:
            verif(mime in LECTEURS_DIMENSIONS,
                  '%s est annoncé lisible mais absent' % mime)

    try:
        sans_lever('autocontrôle images', tout)
    finally:
        shutil.rmtree(dossier, ignore_errors=True)
    if COMPTEUR['verifs'] == depart:
        problemes.append('aucun contrôle n’a été compté')
    return problemes


if __name__ == '__main__':
    soucis = verifier()
    if soucis:
        for souci in soucis:
            print('ÉCHEC :', souci)
        sys.exit(1)
    print('images : %d contrôles ; dimensions lues dans l’en-tête pour %s, '
          'aucune bibliothèque d’images, refus bornés annoncés, PNG Piet '
          'reconnu et convertible en .piett.'
          % (COMPTEUR['verifs'],
             ', '.join(sorted(LECTEURS_DIMENSIONS))))
