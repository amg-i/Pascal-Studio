#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Injecter les assets de l'interface 4.0.0 dans un index.html.

Cinq injections, et pas une de moins :

  1. `aide-assembleur.js` — script CLASSIQUE, AVANT le bundle. Le bundle
     construit sa base d'aide au moment de son évaluation, à partir de
     window.PS_LANG_HELP. Un attribut « defer » le ferait s'exécuter après, et
     l'assembleur n'aurait alors AUCUNE aide — sans qu'aucune erreur
     n'apparaisse nulle part. C'est le même acquis qu'`aide-esoteriques.js` en
     3.8.0, revérifié ici.
  2. à 5. les quatre paires de panneaux — `data-studio`, `navigateur-studio`,
     `devweb-studio`, `re-studio` — APRÈS le bundle, la FEUILLE DE STYLE avant
     le SCRIPT. Un script qui rend du DOM au chargement produit un éclair de
     contenu non stylé si sa feuille arrive après ; et une feuille chargée avant
     le bundle se fait écraser par certaines de ses règles.

`asm-studio.js` n'est PAS injecté ici et c'est voulu : le bundle le charge par
`import("./asm-studio.js")`. Sa présence dans le dossier des assets est
vérifiée, son absence d'index.html aussi — une balise script le chargerait une
seconde fois.

POURQUOI UN SEUL SCRIPT ET PAS CINQ
  La paire `re-studio` avait été oubliée : `re-studio.js` et `re-studio.css`
  n'étaient ni copiés dans les assets ni injectés dans index.html. Le bundle
  aurait donc créé `.ps-re-host`, et RIEN ne serait venu y rendre le panneau —
  une fonctionnalité livrée morte, sans aucun message d'erreur. Trois inséreurs
  séparés (navigateur, dev web, puis rétro) s'ancraient les uns sur les autres ;
  le dernier maillon manquait et aucun contrôle ne le disait. Un seul script qui
  connaît les CINQ injections et les vérifie ensemble rend l'oubli impossible :
  `--verifier` échoue si l'une manque.

IDEMPOTENCE ET ANCRAGE
  Chaque paire manquante est insérée après la dernière paire PRÉSENTE qui la
  précède dans l'ordre canonique, ou après la feuille de style du bundle si
  aucune ne l'est. Le script fonctionne donc aussi bien sur un index.html vierge
  (base 3.9.0 : les quatre paires sont ajoutées) que sur un index.html déjà
  préparé (seule la paire manquante est ajoutée), et ne double jamais une paire
  présente. Les ancres du bundle sont cherchées par EXPRESSION RÉGULIÈRE : leur
  empreinte (`index-BCuLwkpg.css`) change à chaque compilation du bundle, et une
  ancre littérale ferait échouer la construction suivante sans raison.

CONTRÔLE AVANT ÉCRITURE
  Le résultat est contrôlé EN MÉMOIRE avant d'être écrit : si l'ordre n'est pas
  bon, rien n'est écrit et le diagnostic porte sur le fichier fourni, pas sur un
  fichier déjà modifié.

Usage :
    python3 inserer-assets-4.0.0.py [CHEMIN/index.html] [--verifier]

Sans chemin, la cible est `interface-compilee/index.html` de l'arborescence
source. Le reconditionneur passe le chemin de l'image extraite.
"""

import io
import os
import re
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.abspath(os.path.join(ICI, '..'))
CIBLE_PAR_DEFAUT = os.path.join(RACINE, 'interface-compilee', 'index.html')

# Le catalogue d'aide de l'assembleur : script classique, avant le bundle.
AIDE = '<script src="/assets/aide-assembleur.js"></script>'
ANCRE_AIDE = '<script src="/assets/aide-esoteriques.js"></script>'

# Les quatre paires de panneaux, dans l'ordre canonique de chargement.
PAIRES = (
    ('data-studio',
     '<link rel="stylesheet" href="/assets/data-studio.css">',
     '<script defer src="/assets/data-studio.js"></script>'),
    ('navigateur-studio',
     '<link rel="stylesheet" href="/assets/navigateur-studio.css">',
     '<script defer src="/assets/navigateur-studio.js"></script>'),
    ('devweb-studio',
     '<link rel="stylesheet" href="/assets/devweb-studio.css">',
     '<script defer src="/assets/devweb-studio.js"></script>'),
    ('re-studio',
     '<link rel="stylesheet" href="/assets/re-studio.css">',
     '<script defer src="/assets/re-studio.js"></script>'),
)

# Le tokenizer de l'assembleur, chargé par le bundle via import() : présent dans
# les assets, absent d'index.html.
DYNAMIQUES = ('asm-studio.js',)

RE_CSS_BUNDLE = re.compile(
    r'<link rel="stylesheet" crossorigin href="/assets/index-[A-Za-z0-9_-]+\.css">')
RE_JS_BUNDLE = re.compile(
    r'<script type="module" crossorigin src="/assets/index-[A-Za-z0-9_-]+\.js">'
    r'</script>')


def dossier_assets(cible):
    return os.path.join(os.path.dirname(os.path.abspath(cible)), 'assets')


def verifier(texte, cible):
    """(ok, rapports). Contrôle la présence, l'unicité, l'ordre et les fichiers.

    L'ordre est MESURÉ sur les positions réelles, jamais supposé : un contrôle
    qui récite ce qu'il croit avoir écrit ne protège rien.
    """
    rapports = []
    ok = True

    def fautif(message):
        rapports.append('  ' + message)
        return False

    css = RE_CSS_BUNDLE.search(texte)
    js = RE_JS_BUNDLE.search(texte)
    if not css:
        ok = fautif('la feuille de style du bundle est introuvable : l’ancrage '
                    'des panneaux n’a pas pu être vérifié')
    if not js:
        ok = fautif('le script du bundle est introuvable : l’ordre du catalogue '
                    'd’aide n’a pas pu être vérifié')

    # 1. Le catalogue d'aide de l'assembleur.
    compte = texte.count(AIDE)
    if compte != 1:
        ok = fautif('aide-assembleur.js apparaît %d fois (1 attendue) : sans '
                    'lui l’assembleur n’a aucune aide, et chargé deux fois il '
                    'doublerait les fiches' % compte)
    else:
        rapports.append('  aide-assembleur.js présent une fois')
        if 'defer src="/assets/aide-assembleur.js"' in texte:
            ok = fautif('aide-assembleur.js est chargé en « defer » : il serait '
                        'évalué APRÈS le bundle, qui n’aurait alors aucune aide '
                        'pour l’assembleur')
        elif js and texte.index(AIDE) > js.start():
            ok = fautif('aide-assembleur.js vient APRÈS le bundle : la base '
                        'd’aide est construite à l’évaluation du bundle, elle '
                        'serait vide pour l’assembleur')
        else:
            rapports.append('  aide-assembleur.js précède le bundle, sans defer')
    if texte.count(ANCRE_AIDE) != 1:
        ok = fautif('l’ancre aide-esoteriques.js apparaît %d fois (1 attendue)'
                    % texte.count(ANCRE_AIDE))

    # 2. Les quatre paires de panneaux.
    positions = []
    for nom, feuille, script in PAIRES:
        cf, cs = texte.count(feuille), texte.count(script)
        if cf != 1 or cs != 1:
            ok = fautif('la paire %s apparaît %d fois (feuille) et %d fois '
                        '(script), 1 et 1 attendues' % (nom, cf, cs))
            continue
        pf, ps = texte.index(feuille), texte.index(script)
        if pf > ps:
            ok = fautif('%s : la feuille de style vient APRÈS le script, ce qui '
                        'produit un panneau non stylé à chaque ouverture' % nom)
        elif css and pf < css.end():
            ok = fautif('%s : la paire précède la feuille de style du bundle, '
                        'qui écraserait certaines de ses règles' % nom)
        else:
            rapports.append('  %s : feuille puis script, après le bundle' % nom)
        positions.append((nom, pf))

    # L'ordre canonique entre les paires : data, navigateur, dev web, rétro.
    if len(positions) == len(PAIRES):
        obtenu = [nom for nom, _p in sorted(positions, key=lambda x: x[1])]
        attendu = [p[0] for p in PAIRES]
        if obtenu != attendu:
            ok = fautif('l’ordre des panneaux est %s au lieu de %s'
                        % (', '.join(obtenu), ', '.join(attendu)))
        else:
            rapports.append('  l’ordre des quatre panneaux est canonique')

    # 3. Les fichiers eux-mêmes : une balise qui pointe vers un asset absent
    #    charge silencieusement une 404, et le panneau ne s'affiche pas.
    assets = dossier_assets(cible)
    for nom, _feuille, _script in PAIRES:
        for fichier in (nom + '.css', nom + '.js'):
            if not os.path.isfile(os.path.join(assets, fichier)):
                ok = fautif('%s est absent du dossier des assets (%s) : la '
                            'balise chargée donnerait une 404' % (fichier, assets))
    if not os.path.isfile(os.path.join(assets, 'aide-assembleur.js')):
        ok = fautif('aide-assembleur.js est absent du dossier des assets')
    for fichier in DYNAMIQUES:
        if not os.path.isfile(os.path.join(assets, fichier)):
            ok = fautif('%s est absent du dossier des assets : le bundle le '
                        'charge par import() et Monaco retomberait sur une '
                        'configuration par défaut, sans erreur' % fichier)
        if '/assets/%s"' % fichier in texte:
            ok = fautif('%s est référencé dans index.html : le bundle le charge '
                        'déjà par import(), une balise le chargerait deux fois'
                        % fichier)
    return ok, rapports


def inserer(texte):
    """Ajoute ce qui manque. Rend (nouveau_texte, ajoutés)."""
    ajoutés = []

    if AIDE not in texte:
        if texte.count(ANCRE_AIDE) != 1:
            raise SystemExit('ERREUR : l’ancre aide-esoteriques.js apparaît '
                             '%d fois (1 attendue). Rien n’est écrit.'
                             % texte.count(ANCRE_AIDE))
        texte = texte.replace(ANCRE_AIDE, ANCRE_AIDE + AIDE, 1)
        ajoutés.append('aide-assembleur.js')

    css = RE_CSS_BUNDLE.search(texte)
    if not css:
        raise SystemExit('ERREUR : la feuille de style du bundle est '
                         'introuvable. Rien n’est écrit.')
    for nom, feuille, script in PAIRES:
        if feuille in texte and script in texte:
            continue
        if feuille in texte or script in texte:
            raise SystemExit('ERREUR : la paire %s est partiellement présente. '
                             'Rien n’est écrit : corrigez index.html avant de '
                             'relancer.' % nom)
        # Point d'insertion : après la dernière paire PRÉSENTE qui précède celle
        #-ci dans l'ordre canonique. À défaut, après la feuille du bundle. C'est
        # ce qui rend le script utilisable aussi bien sur un index.html vierge
        # (base 3.9.0) que sur un index.html déjà partiellement préparé.
        endroit = css.end()
        for autre, f_autre, s_autre in PAIRES:
            if autre == nom:
                break
            if f_autre in texte and s_autre in texte:
                endroit = max(endroit, texte.index(s_autre) + len(s_autre))
        texte = texte[:endroit] + feuille + script + texte[endroit:]
        ajoutés.append(nom)
    return texte, ajoutés


def main(argv):
    verification = '--verifier' in argv
    chemins = [a for a in argv if not a.startswith('--')]
    cible = chemins[0] if chemins else CIBLE_PAR_DEFAUT
    if not os.path.isfile(cible):
        sys.stderr.write('ERREUR : %s est introuvable.\n' % cible)
        return 1
    texte = io.open(cible, encoding='utf-8').read()

    if verification:
        ok, rapports = verifier(texte, cible)
        for rapport in rapports:
            sys.stderr.write(rapport + '\n')
        sys.stderr.write('index.html : %s.\n'
                         % ('les cinq injections sont en place' if ok
                            else 'INCOMPLET ou mal ordonné'))
        return 0 if ok else 1

    resultat, ajoutés = inserer(texte)
    ok, rapports = verifier(resultat, cible)
    for rapport in rapports:
        sys.stderr.write(rapport + '\n')
    if not ok:
        sys.stderr.write('ERREUR : le résultat ne passe pas le contrôle, RIEN '
                         'n’est écrit.\n')
        return 1
    if not ajoutés:
        sys.stderr.write('index.html : les cinq injections étaient déjà en '
                         'place, rien à écrire.\n')
        return 0
    io.open(cible, 'w', encoding='utf-8').write(resultat)
    sys.stderr.write('index.html : %d -> %d caractères, %d injection(s) : %s.\n'
                     % (len(texte), len(resultat), len(ajoutés),
                        ', '.join(ajoutés)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
