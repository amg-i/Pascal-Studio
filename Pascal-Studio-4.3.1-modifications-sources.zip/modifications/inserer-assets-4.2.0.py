#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Injecter les assets de l'interface 4.0.0 dans un index.html.

Sept injections, et pas une de moins :

  1. `aide-assembleur.js` — script CLASSIQUE, AVANT le bundle. Le bundle
     construit sa base d'aide au moment de son évaluation, à partir de
     window.PS_LANG_HELP. Un attribut « defer » le ferait s'exécuter après, et
     l'assembleur n'aurait alors AUCUNE aide — sans qu'aucune erreur
     n'apparaisse nulle part. C'est le même acquis qu'`aide-esoteriques.js` en
     3.8.0, revérifié ici.
  2. `ps-hotes.js` — le registre partagé des hôtes, script defer placé EN TÊTE
     du groupe qui suit le bundle. Il doit être évalué AVANT les cinq panneaux :
     chacun lui délègue son observation du DOM, et sans lui ils retomberaient
     sur leur repli, donc sur cinq observateurs et cinq sondes. C'est précisément
     ce qui faisait qu'un bouton latéral mettait plusieurs secondes à agir.
  3. à 7. les cinq paires de panneaux — `data-studio`, `navigateur-studio`,
     `devweb-studio`, `re-studio`, `outils-studio` — APRÈS le bundle, la
     FEUILLE DE STYLE avant le SCRIPT. Un script qui rend du DOM au chargement produit un éclair de
     contenu non stylé si sa feuille arrive après ; et une feuille chargée avant
     le bundle se fait écraser par certaines de ses règles.

La cinquième paire, `outils-studio`, est la nouveauté de la 4.1.0 : la section
« Outils et dépendances » de la fenêtre des paramètres. Elle est injectée EN
DERNIER parce qu'elle n'a aucune dépendance sur les autres panneaux, et que son
hôte (`.ps-outils-host`) n'existe que tant que cette fenêtre est ouverte.

`asm-studio.js` n'est PAS injecté ici et c'est voulu : le bundle le charge par
`import("./asm-studio.js")`. Sa présence dans le dossier des assets est
vérifiée, son absence d'index.html aussi — une balise script le chargerait une
seconde fois.

POURQUOI UN SEUL SCRIPT ET PAS SEPT
  La paire `re-studio` avait été oubliée : `re-studio.js` et `re-studio.css`
  n'étaient ni copiés dans les assets ni injectés dans index.html. Le bundle
  aurait donc créé `.ps-re-host`, et RIEN ne serait venu y rendre le panneau —
  une fonctionnalité livrée morte, sans aucun message d'erreur. Trois inséreurs
  séparés (navigateur, dev web, puis rétro) s'ancraient les uns sur les autres ;
  le dernier maillon manquait et aucun contrôle ne le disait. Un seul script qui
  connaît les SEPT injections et les vérifie ensemble rend l'oubli impossible :
  `--verifier` échoue si l'une manque.

IDEMPOTENCE ET ANCRAGE
  Chaque paire manquante est insérée après la dernière paire PRÉSENTE qui la
  précède dans l'ordre canonique, ou après la feuille de style du bundle si
  aucune ne l'est. Le script fonctionne donc aussi bien sur un index.html vierge
  (base 3.9.0 : les quatre paires sont ajoutées) que sur un index.html déjà
  préparé (seule la paire manquante est ajoutée), et ne double jamais une paire
  présente. Les ancres du bundle sont cherchées par EXPRESSION RÉGULIÈRE : leur
  empreinte (`index-BCuLwkpg.css`) change à chaque compilation du bundle, et une
  ancre littérale ferait échouer la construction suivante sans raison.

CONTRÔLE AVANT ÉCRITURE
  Le résultat est contrôlé EN MÉMOIRE avant d'être écrit : si l'ordre n'est pas
  bon, rien n'est écrit et le diagnostic porte sur le fichier fourni, pas sur un
  fichier déjà modifié.

Usage :
    python3 inserer-assets-4.2.0.py [CHEMIN/index.html] [--verifier]

Sans chemin, la cible est `interface-compilee/index.html` de l'arborescence
source. Le reconditionneur passe le chemin de l'image extraite.
"""

import io
import os
import re
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.abspath(os.path.join(ICI, '..'))
CIBLE_PAR_DEFAUT = os.path.join(RACINE, 'interface-compilee', 'index.html')

# Le catalogue d'aide de l'assembleur : script classique, avant le bundle.
AIDE = '<script src="/assets/aide-assembleur.js"></script>'
ANCRE_AIDE = '<script src="/assets/aide-esoteriques.js"></script>'

# Les cinq paires de panneaux, dans l'ordre canonique de chargement.
PAIRES = (
    ('data-studio',
     '<link rel="stylesheet" href="/assets/data-studio.css">',
     '<script defer src="/assets/data-studio.js"></script>'),
    ('navigateur-studio',
     '<link rel="stylesheet" href="/assets/navigateur-studio.css">',
     '<script defer src="/assets/navigateur-studio.js"></script>'),
    ('devweb-studio',
     '<link rel="stylesheet" href="/assets/devweb-studio.css">',
     '<script defer src="/assets/devweb-studio.js"></script>'),
    ('re-studio',
     '<link rel="stylesheet" href="/assets/re-studio.css">',
     '<script defer src="/assets/re-studio.js"></script>'),
    ('outils-studio',
     '<link rel="stylesheet" href="/assets/outils-studio.css">',
     '<script defer src="/assets/outils-studio.js"></script>'),
)

# Les scripts seuls, sans feuille de style, injectés EN TÊTE du groupe qui suit
# le bundle. ps-hotes.js doit être évalué avant les cinq panneaux : chacun lui
# délègue son observation du DOM.
SOLOS = ('ps-hotes.js',)

# Le tokenizer de l'assembleur, chargé par le bundle via import() : présent dans
# les assets, absent d'index.html.
DYNAMIQUES = ('asm-studio.js',)

RE_CSS_BUNDLE = re.compile(
    r'<link rel="stylesheet" crossorigin href="/assets/index-[A-Za-z0-9_-]+\.css">')
RE_JS_BUNDLE = re.compile(
    r'<script type="module" crossorigin src="/assets/index-[A-Za-z0-9_-]+\.js">'
    r'</script>')


def references(texte, nom):
    """Combien de fois index.html référence les fichiers d'une paire.

    La détection porte sur le NOM DE FICHIER, pas sur la balise canonique : une
    base réelle peut référencer data-studio.js sans « defer », ou avec ses
    attributs dans un autre ordre. Ne reconnaître que la forme canonique ferait
    soit charger le panneau DEUX fois, soit arrêter la construction sur une base
    parfaitement bonne.
    """
    return (texte.count('/assets/%s.css' % nom),
            texte.count('/assets/%s.js' % nom))


def dossier_assets(cible):
    return os.path.join(os.path.dirname(os.path.abspath(cible)), 'assets')


def verifier(texte, cible):
    """(ok, rapports). Contrôle la présence, l'unicité, l'ordre et les fichiers.

    L'ordre est MESURÉ sur les positions réelles, jamais supposé : un contrôle
    qui récite ce qu'il croit avoir écrit ne protège rien.
    """
    rapports = []
    ok = True

    def fautif(message):
        rapports.append('  ' + message)
        return False

    css = RE_CSS_BUNDLE.search(texte)
    js = RE_JS_BUNDLE.search(texte)
    if not css:
        ok = fautif('la feuille de style du bundle est introuvable : l’ancrage '
                    'des panneaux n’a pas pu être vérifié')
    if not js:
        ok = fautif('le script du bundle est introuvable : l’ordre du catalogue '
                    'd’aide n’a pas pu être vérifié')

    # 1. Le catalogue d'aide de l'assembleur.
    compte = texte.count(AIDE)
    if compte != 1:
        ok = fautif('aide-assembleur.js apparaît %d fois (1 attendue) : sans '
                    'lui l’assembleur n’a aucune aide, et chargé deux fois il '
                    'doublerait les fiches' % compte)
    else:
        rapports.append('  aide-assembleur.js présent une fois')
        if 'defer src="/assets/aide-assembleur.js"' in texte:
            ok = fautif('aide-assembleur.js est chargé en « defer » : il serait '
                        'évalué APRÈS le bundle, qui n’aurait alors aucune aide '
                        'pour l’assembleur')
        elif js and texte.index(AIDE) > js.start():
            ok = fautif('aide-assembleur.js vient APRÈS le bundle : la base '
                        'd’aide est construite à l’évaluation du bundle, elle '
                        'serait vide pour l’assembleur')
        else:
            rapports.append('  aide-assembleur.js précède le bundle, sans defer')
    if texte.count(ANCRE_AIDE) != 1:
        ok = fautif('l’ancre aide-esoteriques.js apparaît %d fois (1 attendue)'
                    % texte.count(ANCRE_AIDE))

    # 1 bis. Les scripts seuls, qui doivent précéder les panneaux.
    position_solo = {}
    for nom in SOLOS:
        compte = texte.count('/assets/%s' % nom)
        if compte != 1:
            ok = fautif('%s apparaît %d fois dans index.html (1 attendue) : '
                        'chargé deux fois, il publierait deux registres et les '
                        'panneaux n’en verraient qu’un' % (nom, compte))
            continue
        position_solo[nom] = texte.index('/assets/%s' % nom)
        rapports.append('  %s : présent une fois' % nom)
    if css and position_solo:
        premiere_paire = min([texte.index('/assets/%s.css' % p[0])
                              for p in PAIRES
                              if texte.count('/assets/%s.css' % p[0])],
                             default=None)
        if premiere_paire is not None:
            for nom, position in position_solo.items():
                if position > premiere_paire:
                    ok = fautif('%s vient APRÈS les panneaux : il doit être '
                                'évalué avant, sinon chacun retombe sur son '
                                'repli et pose son propre observateur' % nom)
                else:
                    rapports.append('  %s précède les panneaux' % nom)

    # 2. Les cinq paires de panneaux. Le compte porte sur les NOMS DE
    #    FICHIER : c'est l'invariant réel. Une paire chargée deux fois — la
    #    forme canonique plus celle de la base — rendrait un panneau qui
    #    s'observe lui-même, et le contrôle des balises canoniques ne le voyait
    #    pas puisque chaque forme prise isolément n'apparaissait qu'une fois.
    positions = []
    for nom, feuille, script in PAIRES:
        rf, rs = references(texte, nom)
        if rf != 1 or rs != 1:
            ok = fautif('la paire %s est référencée %d fois (feuille) et %d '
                        'fois (script) dans index.html, 1 et 1 attendues — '
                        'chargée deux fois, elle s’observerait elle-même'
                        % (nom, rf, rs))
        cf, cs = texte.count(feuille), texte.count(script)
        if cf > 1 or cs > 1:
            ok = fautif('la paire %s apparaît %d fois sous la forme canonique '
                        '(feuille) et %d fois (script), 1 et 1 attendues'
                        % (nom, cf, cs))
        if not cf or not cs:
            rapports.append('  %s : référencé par la base sous une autre forme '
                            '(feuille %d, script %d) — non réinjecté'
                            % (nom, rf, rs))
            continue
        pf, ps = texte.index(feuille), texte.index(script)
        if pf > ps:
            ok = fautif('%s : la feuille de style vient APRÈS le script, ce qui '
                        'produit un panneau non stylé à chaque ouverture' % nom)
        elif css and pf < css.end():
            ok = fautif('%s : la paire précède la feuille de style du bundle, '
                        'qui écraserait certaines de ses règles' % nom)
        else:
            rapports.append('  %s : feuille puis script, après le bundle' % nom)
        positions.append((nom, pf))

    # L'ordre canonique, vérifié sur les paires dont la position est connue.
    # Une paire référencée par la base sous une autre forme n'a pas de position
    # canonique mesurable ici : elle est annoncée plus haut, pas devinée.
    if len(positions) >= 2:
        obtenu = [nom for nom, _p in sorted(positions, key=lambda x: x[1])]
        attendu = [p[0] for p in PAIRES if p[0] in obtenu]
        if obtenu != attendu:
            ok = fautif('l’ordre des panneaux est %s au lieu de %s'
                        % (', '.join(obtenu), ', '.join(attendu)))
        else:
            rapports.append('  l’ordre des %d panneaux mesurés est canonique'
                            % len(positions))

    # 3. Les fichiers eux-mêmes : une balise qui pointe vers un asset absent
    #    charge silencieusement une 404, et le panneau ne s'affiche pas.
    assets = dossier_assets(cible)
    for nom in SOLOS:
        if not os.path.isfile(os.path.join(assets, nom)):
            ok = fautif('%s est absent du dossier des assets (%s) : les cinq '
                        'panneaux retomberaient sur leur repli, donc sur cinq '
                        'observateurs et cinq sondes' % (nom, assets))
    for nom, _feuille, _script in PAIRES:
        for fichier in (nom + '.css', nom + '.js'):
            if not os.path.isfile(os.path.join(assets, fichier)):
                ok = fautif('%s est absent du dossier des assets (%s) : la '
                            'balise chargée donnerait une 404' % (fichier, assets))
    if not os.path.isfile(os.path.join(assets, 'aide-assembleur.js')):
        ok = fautif('aide-assembleur.js est absent du dossier des assets')
    for fichier in DYNAMIQUES:
        if not os.path.isfile(os.path.join(assets, fichier)):
            ok = fautif('%s est absent du dossier des assets : le bundle le '
                        'charge par import() et Monaco retomberait sur une '
                        'configuration par défaut, sans erreur' % fichier)
        if '/assets/%s"' % fichier in texte:
            ok = fautif('%s est référencé dans index.html : le bundle le charge '
                        'déjà par import(), une balise le chargerait deux fois'
                        % fichier)
    return ok, rapports


def inserer(texte):
    """Ajoute ce qui manque. Rend (nouveau_texte, ajoutés)."""
    ajoutés = []

    if AIDE not in texte:
        if texte.count(ANCRE_AIDE) != 1:
            raise SystemExit('ERREUR : l’ancre aide-esoteriques.js apparaît '
                             '%d fois (1 attendue). Rien n’est écrit.'
                             % texte.count(ANCRE_AIDE))
        texte = texte.replace(ANCRE_AIDE, ANCRE_AIDE + AIDE, 1)
        ajoutés.append('aide-assembleur.js')

    css = RE_CSS_BUNDLE.search(texte)
    if not css:
        raise SystemExit('ERREUR : la feuille de style du bundle est '
                         'introuvable. Rien n’est écrit.')
    # Les scripts seuls d'abord : ils doivent précéder les panneaux. La
    # détection porte sur le NOM DE FICHIER, comme pour les paires, donc une
    # base qui référencerait déjà ps-hotes.js ne le chargerait pas deux fois.
    # Les scripts seuls d'abord, et leur position devient le point de départ des
    # paires. Insérer les deux au même endroit (css.end()) mettait les paires
    # AVANT ps-hotes.js sur un index vierge : chaque panneau retombait alors sur
    # son repli, donc sur cinq observateurs et cinq sondes — exactement ce que
    # cette version supprime. Sur un index déjà complet, l'ordre était bon, ce
    # qui est pourquoi le défaut n'est apparu que dans la simulation, qui part
    # d'une base vierge.
    endroit_paires = css.end()
    for nom in SOLOS:
        balise = '<script defer src="/assets/%s"></script>' % nom
        if texte.count('/assets/%s' % nom):
            # La fin de la BALISE, pas la fin du nom de fichier : s'arrêter au
            # nom insérerait la paire AU MILIEU de <script src="…"></script> et
            # casserait la balise. C'est ce que le banc a trouvé, sur un index
            # portant déjà ps-hotes.js — la simulation ne le voyait pas, parce
            # qu'elle part d'une base vierge où ce fichier est absent.
            position = texte.index('/assets/%s' % nom)
            fin = texte.index('>', position) + 1
            # Et la balise fermante, s'il y en a une : <script defer src="…">
            # se ferme par </script>. S'arrêter au premier « > » insérerait la
            # paire DANS l'élément script, donc entre la balise ouvrante et la
            # fermante — le navigateur ne l'exécuterait jamais comme du HTML.
            for cloture in ('</script>', '</link>'):
                if texte.startswith(cloture, fin):
                    fin += len(cloture)
                    break
            endroit_paires = max(endroit_paires, fin)
            continue
        texte = texte[:endroit_paires] + balise + texte[endroit_paires:]
        endroit_paires += len(balise)
        ajoutés.append(nom)
    css = RE_CSS_BUNDLE.search(texte)
    for nom, feuille, script in PAIRES:
        if feuille in texte and script in texte:
            continue
        deja_feuille, deja_script = references(texte, nom)
        if deja_feuille and deja_script:
            # La base référence déjà les deux fichiers, sous une forme qui
            # n'est pas la nôtre. Ajouter nos balises chargerait le panneau DEUX
            # fois : deux exemplaires s'observent mutuellement le DOM et le
            # second écrase l'état du premier. On n'ajoute rien, et on le dit.
            ajoutés.append('%s (déjà référencé par la base, non réinjecté)' % nom)
            continue
        if deja_feuille or deja_script:
            # Un seul des deux : on complète, et seulement ce qui manque. Un
            # panneau sans sa feuille de style s'affiche non stylé ; un panneau
            # sans son script ne s'affiche pas du tout.
            manque = script if deja_feuille else feuille
            if texte.count(manque) != 0:
                raise SystemExit('ERREUR : la paire %s est dans un état '
                                 'incohérent. Rien n’est écrit.' % nom)
            endroit = max(css.end(), endroit_paires)
            for autre, f_autre, s_autre in PAIRES:
                if autre == nom:
                    break
                if f_autre in texte and s_autre in texte:
                    endroit = max(endroit,
                                  texte.index(s_autre) + len(s_autre))
            texte = texte[:endroit] + manque + texte[endroit:]
            ajoutés.append('%s (%s seul)' % (nom, 'script' if deja_feuille
                                             else 'feuille'))
            continue
        # Point d'insertion : après la dernière paire PRÉSENTE qui précède celle
        #-ci dans l'ordre canonique. À défaut, après la feuille du bundle. C'est
        # ce qui rend le script utilisable aussi bien sur un index.html vierge
        # (base 3.9.0) que sur un index.html déjà partiellement préparé.
        endroit = max(css.end(), endroit_paires)
        for autre, f_autre, s_autre in PAIRES:
            if autre == nom:
                break
            if f_autre in texte and s_autre in texte:
                endroit = max(endroit, texte.index(s_autre) + len(s_autre))
        texte = texte[:endroit] + feuille + script + texte[endroit:]
        ajoutés.append(nom)
    return texte, ajoutés


def main(argv):
    verification = '--verifier' in argv
    chemins = [a for a in argv if not a.startswith('--')]
    cible = chemins[0] if chemins else CIBLE_PAR_DEFAUT
    if not os.path.isfile(cible):
        sys.stderr.write('ERREUR : %s est introuvable.\n' % cible)
        return 1
    texte = io.open(cible, encoding='utf-8').read()

    if verification:
        ok, rapports = verifier(texte, cible)
        for rapport in rapports:
            sys.stderr.write(rapport + '\n')
        sys.stderr.write('index.html : %s.\n'
                         % ('les sept injections sont en place' if ok
                            else 'INCOMPLET ou mal ordonné'))
        return 0 if ok else 1

    resultat, ajoutés = inserer(texte)
    ok, rapports = verifier(resultat, cible)
    for rapport in rapports:
        sys.stderr.write(rapport + '\n')
    if not ok:
        sys.stderr.write('ERREUR : le résultat ne passe pas le contrôle, RIEN '
                         'n’est écrit.\n')
        return 1
    if not ajoutés:
        sys.stderr.write('index.html : les sept injections étaient déjà en '
                         'place, rien à écrire.\n')
        return 0
    io.open(cible, 'w', encoding='utf-8').write(resultat)
    sys.stderr.write('index.html : %d -> %d caractères, %d injection(s) : %s.\n'
                     % (len(texte), len(resultat), len(ajoutés),
                        ', '.join(ajoutés)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
