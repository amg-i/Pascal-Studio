#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Insérer dans server.py les routes de la visionneuse d'images et de Piet (4.3.0).

DEUX ROUTES, ET POURQUOI ELLES SONT SÉPARÉES
  `/api/image` sert la visionneuse : lire les octets, les porter en data URI,
  donner les dimensions lues dans l'en-tête, lister les images voisines, dire si
  un PNG est un programme Piet et le convertir en source texte.
  `/api/piet` sert l'éditeur graphique : le catalogue des 20 couleurs et des 17
  commandes, le décodage et l'encodage du format texte, l'aperçu PNG,
  l'exécution, la lecture et l'écriture du fichier.

  Les réunir aurait fait une route à dix-huit branches dont la moitié ne
  concernerait pas l'autre moitié des appels. Séparées, chacune a un verbe par
  action et un refus nommé.

CE QUI EST VÉRIFIÉ ICI ET NULLE PART AILLEURS
  Les chemins passent par `resolve()`, qui est le seul juge des chemins
  autorisés : ni `images.py` ni `piet_texte.py` ne réinventent cette
  vérification, ils reçoivent un chemin déjà résolu. Un module qui refait sa
  propre vérification finit par en avoir une moins bonne.

  L'écriture d'un fichier `.piett` ou `.png` est bornée en taille, et refuse
  d'écraser un fichier qui n'est ni `.piett` ni `.png` : une route d'export qui
  écrit n'importe où est une route qui efface le projet.

IDEMPOTENCE
  Chaque insertion est signée par le texte ajouté. Relancer ce script sur un
  server.py déjà préparé ne fait rien.

Usage :
    python3 inserer-images-piet-serveur.py --verifier server.py
    python3 inserer-images-piet-serveur.py server.py
"""

import io
import os
import sys

RACINE = os.path.dirname(os.path.abspath(__file__))

ANCRE_IMPORT = "import outils_manquants\n"
NOUVEL_IMPORT = """import outils_manquants
# 4.3.0 : la visionneuse d'images et le format texte de Piet. Les deux modules
# sont sans dépendance externe — les dimensions d'une image se lisent dans son
# en-tête, et le PNG de Piet s'écrit avec struct et zlib.
import images
import piet_texte
"""

ANCRE_ROUTES = """                else:
                    raise ValueError('Action d’outils inconnue : %s' % nom)
"""

NOUVELLES_ROUTES = '''                else:
                    raise ValueError('Action d’outils inconnue : %s' % nom)
            elif action == '/api/image':
                self.local_auth_allowed()
                nom = str(d.get('action') or 'lire')
                # Une branche par action. `resolve()` est le SEUL juge des
                # chemins : images.py reçoit un chemin déjà autorisé et ne
                # refait pas la vérification.
                if nom == 'capacites':
                    result = images.capacites()
                elif nom == 'lire':
                    chemin = resolve(str(d.get('chemin') or d.get('path') or ''))
                    dossier = None
                    try:
                        dossier = str(chemin.parent)
                    except Exception:
                        dossier = None
                    result = images.lire(str(chemin), dossier=dossier)
                    if not result.get('ok'):
                        # Un refus de lecture est un résultat, pas une erreur
                        # HTTP : la visionneuse doit pouvoir afficher la raison.
                        result.setdefault('erreur', 'Image non lisible.')
                elif nom == 'voisins':
                    chemin = resolve(str(d.get('chemin') or d.get('path') or ''))
                    parent = str(Path(chemin).parent)
                    result = images.voisins(str(chemin), parent)
                elif nom == 'piet':
                    chemin = resolve(str(d.get('chemin') or d.get('path') or ''))
                    try:
                        octets = Path(chemin).read_bytes()
                    except OSError as exc:
                        raise ValueError('Lecture impossible : %s' % exc)
                    result = images.analyser_piet(octets)
                    result['ok'] = True
                elif nom == 'convertir-piet':
                    # Écrit la SOURCE texte d'un programme Piet PNG. La
                    # destination est imposée : même dossier, même nom,
                    # extension .piett. Une route qui laisse choisir le chemin
                    # d'écriture est une route qui peut écraser le projet.
                    chemin = resolve(str(d.get('chemin') or d.get('path') or ''))
                    if Path(chemin).suffix.lower() != '.png':
                        raise ValueError(
                            'Seul un PNG peut être un programme Piet.')
                    try:
                        octets = Path(chemin).read_bytes()
                    except OSError as exc:
                        raise ValueError('Lecture impossible : %s' % exc)
                    analyse = images.analyser_piet(octets)
                    if not analyse.get('est_piet'):
                        raise ValueError(
                            'Ce PNG n’est pas un programme Piet : %s'
                            % analyse.get('raison') or 'couleurs hors palette.')
                    codel = d.get('codel') or analyse.get('codel') or 1
                    conversion = images.convertir_en_texte(octets, codel=codel)
                    destination = Path(str(chemin)[:-4] + piet_texte.EXTENSION)
                    if destination.exists():
                        raise ValueError(
                            '%s existe déjà : aucune écriture n’est faite. '
                            'Renommez-le ou supprimez-le d’abord.' % destination)
                    texte = conversion['texte']
                    if len(texte.encode('utf8')) > 4_000_000:
                        raise ValueError('Source trop grande (borne 4 Mo).')
                    destination.write_text(texte, encoding='utf8')
                    result = {'ok': True, 'destination': str(destination),
                              'chemin': destination.name, 'texte': texte,
                              'codel': conversion['codel'],
                              'largeur': conversion['largeur'],
                              'hauteur': conversion['hauteur'],
                              'couleurs_hors_palette':
                                  conversion['couleurs_hors_palette']}
                else:
                    raise ValueError('Action d’image inconnue : %s' % nom)
            elif action == '/api/piet':
                self.local_auth_allowed()
                nom = str(d.get('action') or 'capacites')
                # Le format texte est la SOURCE, le PNG la forme COMPILÉE que le
                # moteur Piet existant exécute : aucun second interpréteur n'est
                # introduit ici.
                if nom == 'capacites':
                    result = piet_texte.capacites()
                elif nom == 'catalogue':
                    result = {'ok': True, 'palette': piet_texte.palette(),
                              'commandes': piet_texte.transitions(),
                              'extension': piet_texte.EXTENSION,
                              'version': piet_texte.VERSION_FORMAT}
                elif nom == 'exemple':
                    result = {'ok': True, 'texte': piet_texte.exemple()}
                elif nom == 'decoder':
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    result = piet_texte.decoder(texte)
                elif nom == 'encoder':
                    cellules = d.get('cellules')
                    if not isinstance(cellules, list) or not cellules:
                        raise ValueError('La grille est manquante.')
                    try:
                        result = {'ok': True, 'texte': piet_texte.encoder(
                            cellules, codel=d.get('codel') or 1)}
                    except ValueError as exc:
                        raise ValueError(str(exc))
                elif nom == 'analyser':
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    result = piet_texte.analyser(texte)
                elif nom == 'png':
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    try:
                        result = {'ok': True,
                                  'uri': piet_texte.vers_uri_png(texte)}
                    except ValueError as exc:
                        raise ValueError(str(exc))
                elif nom == 'executer':
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    entree = d.get('entree')
                    limite = d.get('limite')
                    result = piet_texte.executer(
                        texte,
                        entree if isinstance(entree, str) else '',
                        limite=int(limite) if isinstance(limite, (int, float))
                        and limite > 0 else None,
                        chemin=str(d.get('chemin') or 'programme.piett'))
                elif nom == 'lire':
                    chemin = resolve(str(d.get('chemin') or ''))
                    if chemin.suffix.lower() != piet_texte.EXTENSION:
                        raise ValueError(
                            'L’éditeur Piet lit des fichiers %s.'
                            % piet_texte.EXTENSION)
                    try:
                        texte = chemin.read_text('utf8')
                    except OSError as exc:
                        raise ValueError('Lecture impossible : %s' % exc)
                    result = {'ok': True, 'chemin': str(chemin),
                              'texte': texte}
                    result['decode'] = piet_texte.decoder(texte)
                elif nom == 'ecrire':
                    chemin = resolve(str(d.get('chemin') or ''))
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    if chemin.suffix.lower() != piet_texte.EXTENSION:
                        raise ValueError(
                            'Refus d’écrire %s : l’éditeur Piet n’écrit que des '
                            'fichiers %s.' % (chemin.name, piet_texte.EXTENSION))
                    if len(texte.encode('utf8')) > 4_000_000:
                        raise ValueError('Source trop grande (borne 4 Mo).')
                    # Un texte invalide n'est PAS écrit : il vaut mieux refuser
                    # que laisser un fichier que l'éditeur ne saura plus rouvrir.
                    decode = piet_texte.decoder(texte)
                    if not decode['ok']:
                        erreurs = [x['message'] for x in decode['diagnostics']
                                   if x['severity'] == piet_texte.SEVERITE_ERREUR]
                        raise ValueError('Programme invalide, rien n’est écrit : %s'
                                         % (erreurs[0] if erreurs else 'voir les diagnostics'))
                    chemin.write_text(texte, encoding='utf8')
                    result = {'ok': True, 'chemin': str(chemin),
                              'octets': len(texte.encode('utf8')),
                              'diagnostics': decode['diagnostics']}
                elif nom == 'exporter-png':
                    chemin = resolve(str(d.get('chemin') or ''))
                    texte = d.get('texte')
                    if not isinstance(texte, str):
                        raise ValueError('Le texte du programme est manquant.')
                    if chemin.suffix.lower() != piet_texte.EXTENSION:
                        raise ValueError(
                            'L’export PNG part d’un fichier %s.'
                            % piet_texte.EXTENSION)
                    try:
                        octets = piet_texte.vers_png(texte)
                    except ValueError as exc:
                        raise ValueError(str(exc))
                    destination = Path(str(chemin)[:-len(piet_texte.EXTENSION)] + '.png')
                    if destination.exists():
                        raise ValueError(
                            '%s existe déjà : aucune écriture n’est faite.'
                            % destination)
                    destination.write_bytes(octets)
                    result = {'ok': True, 'destination': str(destination),
                              'octets': len(octets)}
                elif nom == 'depuis-png':
                    chemin = resolve(str(d.get('chemin') or ''))
                    try:
                        octets = Path(chemin).read_bytes()
                    except OSError as exc:
                        raise ValueError('Lecture impossible : %s' % exc)
                    # Même critère que /api/image convertir-piet, et pour la même
                    # raison : depuis_png() remplace toute couleur hors palette
                    # par du BLANC. Sans ce contrôle, une photographie donnait
                    # une grille entièrement blanche et la route répondait
                    # ok:true — un programme qui ne fait rien, à la place de la
                    # raison du refus. Mieux vaut refuser en expliquant.
                    analyse = images.analyser_piet(octets)
                    if not analyse.get('est_piet'):
                        raise ValueError(
                            'Ce PNG n’est pas un programme Piet : %s'
                            % (analyse.get('raison') or 'couleurs hors palette.'))
                    try:
                        result = piet_texte.depuis_png(octets,
                                                       codel=d.get('codel'))
                    except ValueError as exc:
                        raise ValueError(str(exc))
                    result['ok'] = True
                    result['analyse'] = analyse
                else:
                    raise ValueError('Action Piet inconnue : %s' % nom)
'''

SIGNATURES = (
    ('import images', 'import images\n'),
    ('import piet_texte', 'import piet_texte\n'),
    ('route /api/image', "elif action == '/api/image':"),
    ('route /api/piet', "elif action == '/api/piet':"),
    ('branche convertir-piet', "elif nom == 'convertir-piet':"),
    ('branche exporter-png', "elif nom == 'exporter-png':"),
    ('refus d’écraser', 'existe déjà : aucune écriture n’est faite'),
    ('resolve() sur les chemins', "chemin = resolve(str(d.get('chemin') or ''))"),
)


def verifier(chemin):
    if not os.path.isfile(chemin):
        return 2, ['%s : introuvable.' % chemin]
    texte = io.open(chemin, encoding='utf-8').read()
    lignes = ['%s : %d caractères' % (os.path.basename(chemin), len(texte))]
    appliquees = 0
    for titre, signature in SIGNATURES:
        if signature in texte:
            lignes.append('  %-26s appliquée' % titre)
            appliquees += 1
        else:
            lignes.append('  %-26s manquante' % titre)
    if appliquees == len(SIGNATURES):
        lignes.append('  conforme (routes images et Piet en place)')
        return 0, lignes
    if appliquees == 0:
        if texte.count(ANCRE_IMPORT) == 1 and texte.count(ANCRE_ROUTES) == 1:
            lignes.append('  applicable (les deux ancres sont présentes)')
            return 1, lignes
        lignes.append('  ANCRE IMPORT %d fois, ANCRE ROUTES %d fois.'
                      % (texte.count(ANCRE_IMPORT), texte.count(ANCRE_ROUTES)))
        return 2, lignes
    lignes.append('  ÉTAT MIXTE : %d signature(s) sur %d. Rien n’est écrit : '
                  'un server.py à moitié préparé produirait des routes '
                  'silencieusement absentes.' % (appliquees, len(SIGNATURES)))
    return 2, lignes


def appliquer(chemin):
    code, rapport = verifier(chemin)
    for ligne in rapport:
        sys.stderr.write(ligne + '\n')
    if code == 0:
        sys.stderr.write('  rien à faire.\n')
        return 0
    if code == 2:
        return 2
    texte = io.open(chemin, encoding='utf-8').read()
    depart = len(texte)
    assert texte.count(ANCRE_IMPORT) == 1, 'l’ancre d’import n’est pas unique'
    texte = texte.replace(ANCRE_IMPORT, NOUVEL_IMPORT, 1)
    assert texte.count(ANCRE_ROUTES) == 1, 'l’ancre des routes n’est pas unique'
    texte = texte.replace(ANCRE_ROUTES, NOUVELLES_ROUTES, 1)
    for titre, signature in SIGNATURES:
        assert signature in texte, 'la signature %r manque après application' % titre
    io.open(chemin, 'w', encoding='utf-8').write(texte)
    sys.stderr.write('%s : %d -> %d caractères, deux routes ajoutées.\n'
                     % (os.path.basename(chemin), depart, len(texte)))
    return 0


def main(argv):
    if not argv or argv[0] in ('-h', '--aide'):
        sys.stderr.write(__doc__)
        return 2
    seulement_verifier = '--verifier' in argv
    cibles = [a for a in argv if a != '--verifier']
    if not cibles:
        cibles = [os.path.join(RACINE, 'server.py')]
    rc = 0
    for cible in cibles:
        chemin = cible if os.path.isabs(cible) else os.path.join(RACINE, cible)
        if seulement_verifier:
            code, rapport = verifier(chemin)
            for ligne in rapport:
                sys.stderr.write(ligne + '\n')
            rc = max(rc, code)
        else:
            rc = max(rc, appliquer(chemin))
    return rc


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
