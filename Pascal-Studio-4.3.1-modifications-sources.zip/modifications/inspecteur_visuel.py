"""Inspecteur visuel : le débogage des langages qui produisent un rendu.

HTML, CSS, SVG, Markdown, LaTeX et XML ne s'exécutent pas en console : leurs
erreurs se voient. Cet inspecteur superpose donc au rendu une couche visible :

  • un badge flottant qui suit le survol et nomme l'élément (balise, id,
    classes) avec sa ligne dans le fichier source ;
  • un panneau au clic qui liste les attributs, les styles calculés et la
    règle CSS appliquée ;
  • les diagnostics épinglés sur le rendu lui-même, à l'élément fautif, et
    repris dans une barre latérale ;
  • une barre d'outils toujours affichée dans un coin, pour que l'on voie
    d'un coup d'œil que l'inspection est active.

Deux parties : la « carte » (ce module, côté Python) qui relie chaque ligne du
source à un élément du rendu, et la surcouche (SCRIPT et STYLE) injectée dans
la page servie par web_preview.

La carte est volontairement tolérante : un document mal formé doit malgré tout
produire quelque chose d'affichable, car c'est précisément quand il est cassé
qu'on a besoin de l'inspecteur.
"""

import html as _html
import json
import re
from html.parser import HTMLParser

import langages

LIMITE_ELEMENTS = 4000
LIMITE_TEXTE = 2_000_000

STYLE = """
#__ps_inspecteur_barre{position:fixed;top:8px;right:8px;z-index:2147483646;
 display:flex;gap:6px;align-items:center;background:#1e1e2e;color:#e6e6f0;
 border:1px solid #45475a;border-radius:8px;padding:6px 9px;
 font:12px/1.4 system-ui,sans-serif;box-shadow:0 4px 14px rgba(0,0,0,.35)}
#__ps_inspecteur_barre b{font-weight:600;color:#89b4fa}
#__ps_inspecteur_barre button{background:#313244;color:#e6e6f0;border:1px solid #45475a;
 border-radius:5px;padding:3px 8px;font:inherit;cursor:pointer}
#__ps_inspecteur_barre button[aria-pressed="true"]{background:#89b4fa;color:#11111b;border-color:#89b4fa}
#__ps_inspecteur_barre .ps-nb{color:#f38ba8;font-weight:600}
#__ps_inspecteur_survol{position:fixed;z-index:2147483645;pointer-events:none;
 background:#1e1e2e;color:#cdd6f4;border:1px solid #89b4fa;border-radius:5px;
 padding:3px 7px;font:11px/1.45 ui-monospace,Menlo,Consolas,monospace;
 white-space:pre;display:none;max-width:60vw}
#__ps_inspecteur_cadre{position:fixed;z-index:2147483644;pointer-events:none;
 outline:2px solid #89b4fa;outline-offset:1px;background:rgba(137,180,250,.10);
 display:none}
#__ps_inspecteur_panneau{position:fixed;top:52px;right:8px;z-index:2147483646;
 width:min(360px,92vw);max-height:70vh;overflow:auto;background:#1e1e2e;
 color:#cdd6f4;border:1px solid #45475a;border-radius:8px;padding:10px 12px;
 font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;display:none;
 box-shadow:0 8px 24px rgba(0,0,0,.45)}
#__ps_inspecteur_panneau h4{margin:0 0 6px;font:600 12px/1.4 system-ui,sans-serif;color:#89b4fa}
#__ps_inspecteur_panneau table{width:100%;border-collapse:collapse}
#__ps_inspecteur_panneau td{padding:1px 0;vertical-align:top;border-bottom:1px solid #313244}
#__ps_inspecteur_panneau td:first-child{color:#a6adc8;white-space:nowrap;padding-right:8px}
#__ps_inspecteur_panneau .ps-fermer{float:right;cursor:pointer;color:#a6adc8}
.ps-erreur-marqueur{position:fixed;z-index:2147483643;width:10px;height:10px;
 border-radius:50%;background:#f38ba8;border:1px solid #11111b;pointer-events:none;
 box-shadow:0 0 0 2px rgba(243,139,168,.35)}
.ps-erreur-ligne{outline:2px dashed #f38ba8 !important;outline-offset:1px}
#__ps_inspecteur_liste{position:fixed;bottom:8px;right:8px;z-index:2147483646;
 width:min(380px,92vw);max-height:34vh;overflow:auto;background:#1e1e2e;
 color:#cdd6f4;border:1px solid #f38ba8;border-radius:8px;padding:8px 10px;
 font:12px/1.5 system-ui,sans-serif;display:none}
#__ps_inspecteur_liste div.ps-ligne{cursor:pointer;padding:2px 0;border-bottom:1px solid #313244}
#__ps_inspecteur_liste div.ps-ligne:hover{color:#89b4fa}
#__ps_inspecteur_piet{position:absolute;left:0;top:0;z-index:2147483642;pointer-events:none}
#__ps_inspecteur_piet .ps-codel{position:absolute;box-sizing:border-box;outline:1px solid rgba(17,17,27,.45)}
#__ps_inspecteur_piet .ps-codel-actif{outline:3px solid #f9e2af;box-shadow:0 0 0 2px rgba(17,17,27,.85),0 0 16px rgba(249,226,175,.95)}
#__ps_inspecteur_legende{position:fixed;bottom:8px;left:8px;z-index:2147483646;max-width:min(520px,92vw);background:#1e1e2e;color:#cdd6f4;border:1px solid #f9e2af;border-radius:8px;padding:6px 10px;font:12px/1.5 ui-monospace,Menlo,Consolas,monospace;display:none;box-shadow:0 6px 20px rgba(0,0,0,.45)}
#__ps_inspecteur_legende b{color:#f9e2af}
"""

SCRIPT = r"""
(function(){
  if(window.__PS_INSPECTEUR_INSTALLE) return;
  window.__PS_INSPECTEUR_INSTALLE=true;
  var ACTIF=true, CARTE={}, DIAGS=[], EL=null;
  var PIET_IMG=null, PIET_ACTIF=null, PIET_TIMER=null;

  // Rectangle d'un codel dans les coordonnées de l'image affichée.
  // `rect` vient du moteur en PIXELS de l'image source ; l'aperçu peut montrer
  // l'image agrandie ou réduite, d'où cette mise à l'échelle. Fonction pure :
  // elle est testée hors navigateur.
  function echelleCodel(rect, geo, largeur, hauteur){
    if(!rect||rect.length<4) return null;
    var w=(geo&&geo.largeur)||0, h=(geo&&geo.hauteur)||0;
    if(!(w>0)||!(h>0)||!(largeur>0)||!(hauteur>0)) return null;
    var kx=largeur/w, ky=hauteur/h;
    return [rect[0]*kx, rect[1]*ky, rect[2]*kx, rect[3]*ky];
  }

  function creer(id, parent, texte){
    var n=document.createElement('div'); n.id=id;
    if(texte) n.textContent=texte;
    (parent||document.body).appendChild(n); return n;
  }
  function construire(){
    var barre=creer('__ps_inspecteur_barre',null);
    barre.innerHTML='<b>Inspecteur</b> <span id="__ps_nb"></span>'
      +'<button id="__ps_btn_actif" aria-pressed="true">Survol</button>'
      +'<button id="__ps_btn_erreurs">Erreurs</button>';
    EL={barre:barre,
        survol:creer('__ps_inspecteur_survol'),
        cadre:creer('__ps_inspecteur_cadre'),
        panneau:creer('__ps_inspecteur_panneau'),
        liste:creer('__ps_inspecteur_liste'),
        nb:barre.querySelector('#__ps_nb'),
        btnActif:barre.querySelector('#__ps_btn_actif'),
        btnErreurs:barre.querySelector('#__ps_btn_erreurs'),
        marqueurs:[]};
    EL.btnActif.addEventListener('click',function(){
      ACTIF=!ACTIF; EL.btnActif.setAttribute('aria-pressed',ACTIF?'true':'false');
      if(!ACTIF) cacher();
    });
    EL.btnErreurs.addEventListener('click',function(){
      var ouvert=EL.liste.style.display==='block';
      EL.liste.style.display=ouvert?'none':'block';
    });
  }
  function cacher(){
    EL.survol.style.display='none'; EL.cadre.style.display='none';
    EL.panneau.style.display='none';
  }
  function etiqueter(e){
    if(!e||e.nodeType!==1) return '';
    var s=e.tagName.toLowerCase();
    if(e.id) s+='#'+e.id;
    if(e.classList&&e.classList.length) s+='.'+Array.prototype.join.call(e.classList,'.');
    return s;
  }
  var PAIRES=null;
  function apparier(){
    // Les nœuds ne se sérialisent pas : on reconstruit la correspondance ici.
    // HTMLParser et querySelectorAll('*') parcourent le document dans le même
    // ordre, donc le n-ième élément d'une clef donnée répond au n-ième de la
    // carte. C'est exact même quand une balise se répète sans id.
    PAIRES=new WeakMap();
    var parCle={}, attendus={};
    (CARTE.elements||[]).forEach(function(c){
      (parCle[c.cle]=parCle[c.cle]||[]).push(c);
    });
    var tous=document.querySelectorAll('*');
    for(var i=0;i<tous.length;i++){
      var n=tous[i];
      if(n.id&&String(n.id).indexOf('__ps_inspecteur')===0) continue;
      var cle=n.tagName.toLowerCase()+(n.id?'#'+n.id:'');
      var rang=attendus[cle]||0; attendus[cle]=rang+1;
      var liste=parCle[cle];
      if(liste&&liste[rang]) PAIRES.set(n,liste[rang].ligne);
    }
  }
  function ligneDe(e){
    if(!e||!e.tagName) return null;
    if(!PAIRES) apparier();
    var ligne=PAIRES.get(e);
    if(ligne) return ligne;
    // Repli : un élément apparu après l'initialisation (DOM modifié).
    var cle=e.tagName.toLowerCase()+(e.id?'#'+e.id:'');
    var trouve=null;
    (CARTE.elements||[]).forEach(function(c){
      if(c.cle===cle&&trouve===null) trouve=c.ligne;});
    return trouve;
  }
  function surbrillance(e){
    if(!e||e===document.body||e===document.documentElement||e.id
       && e.id.indexOf('__ps_inspecteur')===0){ cacher(); return; }
    var r=e.getBoundingClientRect();
    EL.cadre.style.display='block';
    EL.cadre.style.left=(r.left+window.scrollX)+'px';
    EL.cadre.style.top=(r.top+window.scrollY)+'px';
    EL.cadre.style.width=r.width+'px'; EL.cadre.style.height=r.height+'px';
    var ligne=ligneDe(e);
    EL.survol.style.display='block';
    EL.survol.textContent=etiqueter(e)+(ligne?('\nligne '+ligne):'');
    var x=r.left+window.scrollX, y=r.top+window.scrollY-EL.survol.offsetHeight-6;
    if(y<0) y=r.bottom+window.scrollY+6;
    EL.survol.style.left=Math.max(2,x)+'px'; EL.survol.style.top=y+'px';
  }
  function echapper(t){
    return String(t).replace(/[&<>]/g,function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;'}[c];});
  }
  function panneau(e){
    var lignes=[['Élément',echapper(etiqueter(e))]];
    var l=ligneDe(e); if(l) lignes.push(['Source','ligne '+l]);
    var attrs=e.attributes||[];
    for(var i=0;i<attrs.length;i++) lignes.push(['@'+attrs[i].name,echapper(attrs[i].value)]);
    var cs=getComputedStyle(e);
    ['display','position','width','height','color','background-color',
     'font-family','font-size','margin','padding','border'].forEach(function(p){
      lignes.push([p,echapper(cs.getPropertyValue(p))]);
    });
    var h='<span class="ps-fermer" id="__ps_fermer">✕</span><h4>Inspecter</h4><table>';
    lignes.forEach(function(c){ h+='<tr><td>'+c[0]+'</td><td>'+c[1]+'</td></tr>'; });
    EL.panneau.innerHTML=h+'</table>';
    EL.panneau.style.display='block';
    EL.panneau.querySelector('#__ps_fermer').addEventListener('click',function(){
      EL.panneau.style.display='none';});
  }
  function marquer(){
    EL.marqueurs.forEach(function(m){ m.remove(); }); EL.marqueurs=[];
    document.querySelectorAll('.ps-erreur-ligne')
      .forEach(function(n){ n.classList.remove('ps-erreur-ligne'); });
    var html=[];
    if(!PAIRES) apparier();
    var parLigne={};
    var tous=document.querySelectorAll('*');
    for(var i=0;i<tous.length;i++){
      var l=PAIRES.get(tous[i]);
      if(l&&!(l in parLigne)) parLigne[l]=tous[i];
    }
    DIAGS.forEach(function(d){
      var cible=parLigne[d.line]||null;
      if(cible&&cible.getBoundingClientRect){
        var r=cible.getBoundingClientRect();
        if(r.width||r.height){
          cible.classList.add('ps-erreur-ligne');
          var m=document.createElement('div'); m.className='ps-erreur-marqueur';
          m.style.left=(r.left+window.scrollX-5)+'px';
          m.style.top=(r.top+window.scrollY-5)+'px';
          document.body.appendChild(m); EL.marqueurs.push(m);
        }
      }
      html.push('<div class="ps-ligne" data-ligne="'+d.line+'">'
        +'l.'+d.line+' — '+echapper(d.message)+'</div>');
    });
    EL.nb.textContent=DIAGS.length?('<span class="ps-nb">'+DIAGS.length
      +' erreur'+(DIAGS.length>1?'s':'')+'</span>'):'';
    EL.liste.innerHTML=html.length?html.join('')
      :'<div>Aucune erreur détectée.</div>';
    EL.liste.querySelectorAll('.ps-ligne').forEach(function(n){
      n.addEventListener('click',function(){
        var l=parseInt(n.getAttribute('data-ligne'),10);
        var cible=parLigne[l];
        if(cible&&cible.scrollIntoView){
          cible.scrollIntoView({block:'center',behavior:'smooth'});
          surbrillance(cible);
        }
        if(window.parent&&window.parent!==window){
          window.parent.postMessage({type:'ps-inspecteur-ligne',ligne:l,path:CARTE.path},'*');
        }
      });
    });
  }
  function tracerPiet(){
    if(!EL||!EL.piet||!PIET_IMG) return;
    var r=PIET_IMG.getBoundingClientRect();
    if(!(r.width>0)||!(r.height>0)) return;
    var geo=CARTE.geometrie||{};
    EL.piet.style.left=(r.left+window.scrollX)+'px';
    EL.piet.style.top=(r.top+window.scrollY)+'px';
    EL.piet.style.width=r.width+'px'; EL.piet.style.height=r.height+'px';
    var actif=PIET_ACTIF?PIET_ACTIF.index:null, html='';
    (CARTE.codels||[]).forEach(function(c){
      var rect=echelleCodel(c.rectangle,geo,r.width,r.height);
      if(!rect) return;
      var w=Math.max(1,rect[2]-rect[0]), h=Math.max(1,rect[3]-rect[1]);
      html+='<div class="ps-codel'+(actif!==null&&actif===c.index?' ps-codel-actif':'')
        +'" data-index="'+c.index+'" style="left:'+rect[0]+'px;top:'+rect[1]
        +'px;width:'+w+'px;height:'+h+'px"></div>';
    });
    EL.piet.innerHTML=html;
  }
  function codelSous(x, y){
    if(!PIET_IMG) return null;
    var r=PIET_IMG.getBoundingClientRect(), geo=CARTE.geometrie||{}, trouve=null;
    (CARTE.codels||[]).forEach(function(c){
      var rect=echelleCodel(c.rectangle,geo,r.width,r.height);
      if(rect&&x>=rect[0]&&x<rect[2]&&y>=rect[1]&&y<rect[3]) trouve=c;
    });
    return trouve;
  }
  function survolPiet(ev){
    if(!EL||!PIET_IMG||!(CARTE.codels||[]).length) return false;
    var r=PIET_IMG.getBoundingClientRect();
    var c=codelSous(ev.clientX-r.left, ev.clientY-r.top);
    if(!c) return false;
    var rect=echelleCodel(c.rectangle,CARTE.geometrie||{},r.width,r.height);
    EL.cadre.style.display='block';
    EL.cadre.style.left=(r.left+window.scrollX+rect[0])+'px';
    EL.cadre.style.top=(r.top+window.scrollY+rect[1])+'px';
    EL.cadre.style.width=(rect[2]-rect[0])+'px';
    EL.cadre.style.height=(rect[3]-rect[1])+'px';
    EL.survol.style.display='block';
    EL.survol.textContent='bloc '+c.index+' — '+(c.classe||((c.teinte||'')+' '
      +(c.luminosite||'')).trim())+'\n'+c.taille+' codel'
      +(c.taille>1?'s':'')+' · '+c.rvb;
    EL.survol.style.left=Math.max(2,ev.clientX+window.scrollX+12)+'px';
    EL.survol.style.top=(ev.clientY+window.scrollY+14)+'px';
    return true;
  }
  function legendePiet(){
    if(!EL||!EL.legende) return;
    var a=PIET_ACTIF;
    if(!a){ EL.legende.style.display='none'; return; }
    var c=null;
    (CARTE.codels||[]).forEach(function(x){ if(x.index===a.index) c=x; });
    var texte='<b>Piet</b> bloc '+a.index+' — '+echapper(a.libelle||a.commande||'rien');
    if(c) texte+=' · '+echapper(c.classe||'')+' · '+c.taille+' codel'+(c.taille>1?'s':'');
    if(a.dp!==undefined&&a.cc!==undefined) texte+=' · DP '+a.dp+' CC '+a.cc;
    EL.legende.innerHTML=texte;
    EL.legende.style.display='block';
  }
  function installerPiet(){
    if(!EL) return;
    PIET_IMG=document.querySelector('img#__ps_piet_image')
      ||document.querySelector('main img')||document.querySelector('img');
    if(!PIET_IMG) return;
    if(!EL.piet){
      EL.piet=creer('__ps_inspecteur_piet');
      EL.legende=creer('__ps_inspecteur_legende');
    }
    if(!PIET_IMG.__ps_piet_branche){
      PIET_IMG.__ps_piet_branche=true;
      PIET_IMG.addEventListener('load',tracerPiet);
      window.addEventListener('resize',tracerPiet);
      window.addEventListener('scroll',tracerPiet);
    }
    tracerPiet(); legendePiet();
    // La session de pas à pas vit dans le serveur, l'aperçu dans un iframe :
    // c'est l'aperçu qui vient chercher le bloc actif. Sans session, la réponse
    // ne porte aucun « actif » et la légende reste cachée.
    if(PIET_TIMER) return;
    PIET_TIMER=setInterval(function(){
      fetch('/__ps_inspecteur_data').then(function(r){ return r.json(); })
        .then(function(d){
          if(!d||d.langage!=='piet') return;
          var avant=PIET_ACTIF?PIET_ACTIF.index:null;
          CARTE=d; DIAGS=d.diagnostics||[];
          PIET_ACTIF=(d.geometrie&&d.geometrie.actif)||null;
          var apres=PIET_ACTIF?PIET_ACTIF.index:null;
          if(avant!==apres) tracerPiet();
          legendePiet();
        }).catch(function(){});
    },900);
  }
  function demarrer(donnees){
    CARTE=donnees||{elements:[]}; DIAGS=(donnees&&donnees.diagnostics)||[];
    if(!EL) construire();
    marquer();
    if(CARTE.langage==='piet'){
      PIET_ACTIF=(CARTE.geometrie&&CARTE.geometrie.actif)||null;
      installerPiet();
    }
  }
  document.addEventListener('mouseover',function(ev){
    if(!ACTIF) return;
    if(CARTE.langage==='piet'&&survolPiet(ev)) return;
    surbrillance(ev.target);},true);
  document.addEventListener('mouseout',function(){ if(ACTIF) cacher(); },true);
  document.addEventListener('click',function(ev){
    if(!ACTIF) return;
    if(ev.target.id&&String(ev.target.id).indexOf('__ps_inspecteur')===0) return;
    ev.preventDefault(); ev.stopPropagation(); panneau(ev.target);},true);
  window.addEventListener('message',function(ev){
    var d=ev.data||{};
    if(d.type==='ps-inspecteur-init') demarrer(d.carte);
    if(d.type==='ps-inspecteur-diagnostics'){ DIAGS=d.diagnostics||[]; if(EL) marquer(); }
  });
  fetch('/__ps_inspecteur_data').then(function(r){ return r.json(); })
    .then(demarrer).catch(function(){});
  if(document.readyState==='loading')
    document.addEventListener('DOMContentLoaded',construire);
  else construire();
})();
"""


class _CarteHTML(HTMLParser):
    """Associe chaque élément à sa ligne, pour épingler les diagnostics."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.elements = []

    def handle_starttag(self, tag, attrs):
        if len(self.elements) >= LIMITE_ELEMENTS:
            return
        ligne, colonne = self.getpos()
        dictionnaire = dict(attrs)
        cle = tag.lower() + ('#' + dictionnaire['id'] if dictionnaire.get('id') else '')
        self.elements.append({'tag': tag.lower(), 'cle': cle, 'ligne': ligne,
                              'colonne': colonne,
                              'id': dictionnaire.get('id', ''),
                              'classes': dictionnaire.get('class', '')})

    handle_startendtag = handle_starttag


_MOTIF_REGLE_CSS = re.compile(
    r'([^{}@][^{}]*)\{([^{}]*)\}', re.MULTILINE)
_MOTIF_TITRE_MD = re.compile(r'^(#{1,6})\s+(.+?)\s*$', re.MULTILINE)
_MOTIF_BLOC_MD = re.compile(r'^(```|~~~|>\s|[-*+]\s|\d+\.\s|\|)', re.MULTILINE)
_MOTIF_ENV_LATEX = re.compile(r'\\begin\{([^}]+)\}', re.MULTILINE)
_MOTIF_ELEMENT_XML = re.compile(r'<\s*([A-Za-z_][\w:.-]*)', re.MULTILINE)


def carte_html(contenu):
    analyseur = _CarteHTML()
    try:
        analyseur.feed(contenu)
        analyseur.close()
    except Exception:
        pass
    return analyseur.elements


def carte_css(contenu):
    """Sélecteurs et propriétés, avec leur ligne."""
    regles = []
    for correspondance in _MOTIF_REGLE_CSS.finditer(contenu):
        if len(regles) >= LIMITE_ELEMENTS:
            break
        selecteur = correspondance.group(1).strip()
        if not selecteur:
            continue
        # group(1) commence au séparateur de la règle précédente : compter
        # depuis là donnerait la ligne d'avant. On part du premier caractère
        # non blanc du sélecteur.
        debut = correspondance.start(1)
        while debut < len(contenu) and contenu[debut] in ' \t\r\n':
            debut += 1
        ligne = contenu.count('\n', 0, debut) + 1
        proprietes = {}
        for declaration in correspondance.group(2).split(';'):
            nom, _, valeur = declaration.partition(':')
            nom, valeur = nom.strip(), valeur.strip()
            if nom:
                proprietes[nom] = valeur
        regles.append({'selecteur': selecteur, 'ligne': ligne,
                       'proprietes': proprietes})
    return regles


def carte_markdown(contenu):
    blocs = []
    for correspondance in _MOTIF_TITRE_MD.finditer(contenu):
        blocs.append({'type': 'titre', 'niveau': len(correspondance.group(1)),
                      'texte': correspondance.group(2),
                      'ligne': contenu.count('\n', 0, correspondance.start()) + 1})
    for correspondance in _MOTIF_BLOC_MD.finditer(contenu):
        blocs.append({'type': 'bloc',
                      'ligne': contenu.count('\n', 0, correspondance.start()) + 1})
    return sorted(blocs, key=lambda b: b['ligne'])[:LIMITE_ELEMENTS]


def carte_latex(contenu):
    environnements = []
    for correspondance in _MOTIF_ENV_LATEX.finditer(contenu):
        environnements.append({
            'nom': correspondance.group(1),
            'ligne': contenu.count('\n', 0, correspondance.start()) + 1})
    return environnements[:LIMITE_ELEMENTS]


def carte_xml(contenu):
    elements = []
    for correspondance in _MOTIF_ELEMENT_XML.finditer(contenu):
        elements.append({'tag': correspondance.group(1),
                         'cle': correspondance.group(1),
                         'ligne': contenu.count('\n', 0, correspondance.start()) + 1})
        if len(elements) >= LIMITE_ELEMENTS:
            break
    return elements


def _nuance_piet(classe, teintes, luminosites):
    """Libellé français d\'un codel Piet.

    Le moteur classe un codel par le couple (luminosité, teinte), ou par la
    chaîne 'blanc' / 'noir' pour les deux zones qui ne sont pas des codels : le
    blanc se traverse sans commande, le noir est infranchissable.
    """
    if not isinstance(classe, tuple) or len(classe) != 2:
        return {'teinte': str(classe), 'luminosite': '', 'classe': str(classe)}
    luminosite, teinte = classe
    nom_teinte = teintes[teinte] if 0 <= teinte < len(teintes) else '?%d' % teinte
    nom_lum = (luminosites[luminosite]
               if 0 <= luminosite < len(luminosites) else '?%d' % luminosite)
    return {'teinte': nom_teinte, 'luminosite': nom_lum,
            'classe': '%s %s' % (nom_teinte, nom_lum)}


def carte_piet(programme):
    """Carte des blocs de couleur d'un programme Piet.

    `programme` est un data URI ou les octets d'un PNG. Le programme Piet EST
    une image : l'inspecteur ne peut donc pas y chercher des balises ou des
    règles, il y découpe les blocs de couleur et rend leur rectangle en PIXELS,
    pour que la surcouche puisse surligner celui qui s'exécute.

    Les diagnostics viennent du chargement du moteur, sans exécution : couleurs
    hors de la palette officielle, image non décodable, entrelacement Adam7.
    """
    try:
        import langages_esoteriques
    except Exception:
        return {'codels': [], 'geometrie': {}, 'diagnostics': [],
                'message': 'Module langages_esoteriques introuvable.'}
    moteur = langages_esoteriques.Piet(programme)
    diagnostics = moteur.charger()
    taille = moteur.taille_codel or 1
    teintes = getattr(langages_esoteriques, 'TEINTES_PIET', ())
    luminosites = getattr(langages_esoteriques, 'LUMINOSITES_PIET', ())
    codels = []
    for bloc in moteur.blocs[:LIMITE_ELEMENTS]:
        codel = {
            'index': bloc['index'],
            'taille': bloc['taille'],
            'rvb': '#%02X%02X%02X' % bloc['rvb'],
            'rectangle': [bloc['x0'] * taille, bloc['y0'] * taille,
                          (bloc['x1'] + 1) * taille, (bloc['y1'] + 1) * taille],
        }
        codel.update(_nuance_piet(bloc['classe'], teintes, luminosites))
        codels.append(codel)
    return {'codels': codels,
            'geometrie': {'largeur': moteur.largeur, 'hauteur': moteur.hauteur,
                          'taille_codel': taille, 'blocs': len(moteur.blocs)},
            'diagnostics': diagnostics,
            'message': moteur.message or ''}


def est_graphique(kind):
    return langages.est_graphique(kind)


def payload(kind, chemin, contenu, diagnostics=None, actif=None):
    """Les données de l'inspecteur, sans les nœuds du DOM.

    Les nœuds ne se sérialisent pas : la surcouche les retrouve en comparant la
    clef « balise#id » et la ligne, ce qui suffit à épingler un diagnostic.
    """
    identifiant = langages.resoudre(kind) or kind
    if not isinstance(contenu, str):
        contenu = ''
    # Un programme Piet est un data URI : le tronquer couperait le base64 et
    # rendrait l'image illisible. La borne de taille ne s'y applique pas.
    if identifiant != 'piet' and len(contenu.encode('utf8')) > LIMITE_TEXTE:
        contenu = contenu[:LIMITE_TEXTE]
    donnees = {'langage': identifiant, 'path': str(chemin),
               'diagnostics': list(diagnostics or [])[:200],
               'elements': [], 'regles': [], 'blocs': [], 'environnements': [],
               'codels': [], 'geometrie': {}, 'message': ''}
    if identifiant in ('html',):
        donnees['elements'] = carte_html(contenu)
    elif identifiant in ('svg', 'xml', 'csproj'):
        donnees['elements'] = carte_xml(contenu)
    elif identifiant == 'css':
        donnees['regles'] = carte_css(contenu)
    elif identifiant == 'markdown':
        donnees['blocs'] = carte_markdown(contenu)
    elif identifiant == 'latex':
        donnees['environnements'] = carte_latex(contenu)
    elif identifiant == 'piet':
        carte = carte_piet(contenu)
        donnees['codels'] = carte['codels']
        donnees['geometrie'] = carte['geometrie']
        # Les diagnostics du moteur s'ajoutent à ceux déjà fournis : pour Piet,
        # l'analyse statique et le découpage de l'image sont la même opération.
        for diagnostic in carte['diagnostics']:
            if diagnostic not in donnees['diagnostics']:
                donnees['diagnostics'].append(diagnostic)
        donnees['diagnostics'] = donnees['diagnostics'][:200]
        donnees['message'] = carte['message']
    if actif and identifiant == 'piet':
        # Le bloc de couleur en cours d'exécution, publié par la session de pas
        # à pas. Il est porté DANS « geometrie » et non comme clef de premier
        # niveau : la liste des clefs du payload doit rester identique d'un
        # langage à l'autre, c'est ce que vérifie le banc de l'inspecteur.
        donnees['geometrie'] = dict(donnees['geometrie'])
        donnees['geometrie']['actif'] = dict(actif)
    return donnees


def injecter(document, base=''):
    """Insère la surcouche dans un document HTML servi par l'aperçu.

    Sans balise </body>, on ajoute en fin de document : un rendu cassé doit
    malgré tout être inspectable.
    """
    if isinstance(document, bytes):
        texte = document.decode('utf8', 'replace')
        encode = True
    else:
        texte = document
        encode = False
    # La barre est créée à l'exécution : c'est la balise injectée qu'il faut
    # repérer, sinon on réinjecterait à chaque affichage.
    if '__ps_inspecteur_js' in texte:
        return document
    url_style = (base or '/') + '__ps_inspecteur_css'
    url_script = (base or '/') + '__ps_inspecteur_js'
    surcouche = ('<link rel="stylesheet" href="%s">'
                 '<script src="%s" defer></script>'
                 % (_html.escape(url_style, quote=True),
                    _html.escape(url_script, quote=True)))
    motif = re.compile(r'</body\s*>', re.IGNORECASE)
    correspondance = None
    for correspondance in motif.finditer(texte):
        pass
    if correspondance:
        texte = (texte[:correspondance.start()] + surcouche
                 + texte[correspondance.start():])
    else:
        texte = texte + surcouche
    return texte.encode('utf8') if encode else texte


def donnees_json(kind, chemin, contenu, diagnostics=None, actif=None):
    return json.dumps(payload(kind, chemin, contenu, diagnostics, actif),
                      ensure_ascii=False)
