"""Single local interactive shell using a PTY, separate from run/debug sessions.
Commands run without isolation as the user. API access must be local and same-origin.
"""
import base64, fcntl, os, pty, secrets, shutil, signal, struct, subprocess, termios, threading, select
from pathlib import Path

class Terminal:
 def __init__(self):
  self.lock=threading.RLock();self.stoplock=threading.Lock();self.proc=None;self.master=None;self.sid=None;self.buffer=bytearray();self.offset=0;self.exited=None;self.cwd='';self.shell=''
 def start(self,root,cols=100,rows=24):
  with self.stoplock:
   with self.lock:
    if self.proc and self.proc.poll() is None:return self.info()
   shell=os.environ.get('SHELL','');p=Path(shell) if shell.startswith('/') else None
   if p is None or not p.is_file() or not os.access(str(p),os.X_OK):shell=shutil.which('bash') or '/bin/sh'
   setsid=shutil.which('setsid')
   if not setsid:raise ValueError('La commande setsid (util-linux) est nécessaire au terminal.')
   master,slave=pty.openpty();cols,rows=self.size(cols,rows);fcntl.ioctl(slave,termios.TIOCSWINSZ,struct.pack('HHHH',rows,cols,0,0))
   env={**os.environ,'TERM':'xterm-256color','COLORTERM':'truecolor'}
   env.pop('NODE_OPTIONS',None)
   try:proc=subprocess.Popen([setsid,'--ctty',shell,'-i'],cwd=str(root),stdin=slave,stdout=slave,stderr=slave,env=env)
   except Exception:os.close(master);raise
   finally:os.close(slave)
   sid=secrets.token_urlsafe(18)
   with self.lock:self.proc=proc;self.master=master;self.sid=sid;self.buffer=bytearray();self.offset=0;self.exited=None;self.cwd=str(root);self.shell=shell
   def reader():
    try:
     while True:
      try:chunk=os.read(master,65536)
      except OSError:break
      if not chunk:break
      with self.lock:
       if self.proc is not proc:break
       self.buffer.extend(chunk)
       if len(self.buffer)>2_000_000:
        remove=len(self.buffer)-2_000_000;del self.buffer[:remove];self.offset+=remove
    finally:
     try:os.close(master)
     except OSError:pass
     code=proc.wait()
     with self.lock:
      if self.proc is proc:self.exited=code;self.master=None
   threading.Thread(target=reader,daemon=True).start()
   return self.info()
 @staticmethod
 def size(cols,rows):
  try:cols,rows=int(cols),int(rows)
  except (TypeError,ValueError):raise ValueError('Dimensions invalides.')
  if not 2<=cols<=500 or not 2<=rows<=300:raise ValueError('Dimensions invalides.')
  return cols,rows
 def info(self):
  with self.lock:return {'id':self.sid,'running':bool(self.proc and self.proc.poll() is None),'exitCode':self.exited,'cwd':self.cwd,'shell':self.shell,'offset':self.offset}
 def check(self,sid):
  if not isinstance(sid,str) or not self.sid or not secrets.compare_digest(sid,self.sid):raise ValueError('Session du terminal expirée.')
 def read(self,sid,offset):
  with self.lock:
   self.check(sid)
   try:pos=int(offset)
   except (TypeError,ValueError):raise ValueError('Position invalide.')
   if pos<0:raise ValueError('Position invalide.')
   start=max(pos,self.offset);end=self.offset+len(self.buffer)
   if start>end:start=end
   chunk=bytes(self.buffer[start-self.offset:min(end,start+262144)-self.offset]);nextpos=start+len(chunk)
   return {'data':base64.b64encode(chunk).decode('ascii'),'next':nextpos,'skipped':pos<self.offset,'running':bool(self.proc and self.proc.poll() is None),'exitCode':self.exited}
 def write(self,sid,data):
  if not isinstance(data,str) or len(data)>350000:raise ValueError('Entrée trop volumineuse.')
  try:buf=base64.b64decode(data,validate=True)
  except Exception:raise ValueError('Entrée invalide.')
  view=memoryview(buf)
  while view:
   with self.lock:
    self.check(sid)
    if not self.proc or self.proc.poll() is not None or self.master is None:raise ValueError('Terminal terminé.')
    if not select.select([],[self.master],[],0.2)[1]:raise ValueError('Terminal occupé ; une partie du collage peut manquer.')
    try:n=os.write(self.master,view[:512])
    except OSError as e:raise ValueError('Terminal fermé.') from e
   if not n:break
   view=view[n:]
 def resize(self,sid,cols,rows):
  cols,rows=self.size(cols,rows)
  with self.lock:
   self.check(sid)
   if self.master is not None:
    try:fcntl.ioctl(self.master,termios.TIOCSWINSZ,struct.pack('HHHH',rows,cols,0,0))
    except OSError:pass
 def stop(self,sid=None):
  with self.stoplock:
   with self.lock:
    if sid is not None:self.check(sid)
    proc=self.proc;master=self.master
   if proc and proc.poll() is None:
    # Shell job control may put the foreground command in a separate process group.
    try:foreground=os.tcgetpgrp(master) if master is not None else None
    except OSError:foreground=None
    for pg in set(x for x in (foreground,proc.pid) if x and x>0):
     try:os.killpg(pg,signal.SIGHUP)
     except (OSError,ProcessLookupError):pass
    try:proc.wait(timeout=1.5)
    except subprocess.TimeoutExpired:
     for pg in set(x for x in (foreground,proc.pid) if x and x>0):
      try:os.killpg(pg,signal.SIGKILL)
      except (OSError,ProcessLookupError):pass
     try:proc.wait(timeout=2)
     except subprocess.TimeoutExpired:pass
    # A foreground child may ignore SIGHUP even if its shell has already exited.
    # Only target groups still belonging to the PTY shell's original session.
    if foreground and foreground!=proc.pid:
     try:
      if os.getsid(foreground)==proc.pid:os.killpg(foreground,signal.SIGKILL)
     except (OSError,ProcessLookupError):pass
   with self.lock:
    if self.proc is proc:self.exited=proc.poll() if proc else None
