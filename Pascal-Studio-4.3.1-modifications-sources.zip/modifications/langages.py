"""Registre des langages de Pascal Studio.

Source unique de vérité pour quatre fonctions : la complétion, les diagnostics
en continu, le débogage et l'exécution des exemples de l'aide. Tout ce qui,
ailleurs, dépend d'un langage passe par ce module, afin qu'ajouter un langage
ou améliorer un service ne se fasse qu'à un seul endroit.

Deux voies coexistent pour la complétion et les diagnostics, dans cet ordre :

  1. un serveur de langage (LSP) s'il est installé — qualité contextuelle ;
  2. un moteur local — index des symboles du projet et bibliothèques de
     mots-clés, plus un vérificateur statique quand il existe.

La voie 2 ne dépend d'aucune installation : elle fonctionne toujours. Sous
Debian 13, seuls clangd, rust-analyzer, gopls, fortls, pylsp et sourcekit-lsp
(fourni par swiftlang) sont empaquetés ; les autres serveurs viennent de npm,
pip, gem, opam ou d'un binaire amont. Ce registre indique, pour chaque langage,
la commande d'installation vérifiée au moment de l'écriture.

Les noms de langages diffèrent entre le moteur et l'interface : le moteur dit
« cs » et « make », l'interface dit « csharp » et « makefile ». Le champ
« alias » fait le lien, et « resoudre() » normalise dans les deux sens.

Aucun module lourd n'est importé ici : les vérificateurs et les moteurs de
débogage sont désignés par leur nom et résolus à la demande, ce qui évite les
importations circulaires et le coût au démarrage.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class ServeurLsp:
    """Un serveur de langage candidat.

    binaire        nom cherché dans le PATH par shutil.which
    args           arguments de lancement
    langage_id     valeur du champ languageId du protocole LSP
    installation   commande conseillée si le binaire manque
    """
    binaire: str
    langage_id: str = ''
    args: tuple = ()
    installation: str = ''


@dataclass(frozen=True)
class AdaptateurDap:
    """Un adaptateur « Debug Adapter Protocol » candidat."""
    binaire: str
    args: tuple = ()
    installation: str = ''
    type_dap: str = ''


@dataclass(frozen=True)
class Langage:
    """Tout ce que Pascal Studio sait d'un langage."""
    identifiant: str                     # nom utilisé par polyglot.kind()
    libelle: str                         # nom affiché à l'utilisateur
    alias: tuple = ()                    # autres noms, dont celui de l'interface
    extensions: tuple = ()               # extensions reconnues, point compris
    lsp: tuple = ()                      # ServeurLsp, par ordre de préférence
    verificateur: tuple = ()             # (module, fonction) d'analyse statique
    debogueur: str = ''                  # gdb | script | php | dap | visuel | ''
    dap: tuple = ()                      # AdaptateurDap candidats
    graphique: bool = False              # produit un résultat visuel, pas du texte
    essai: str = 'non'                   # compile | interprete | graphique | non
    commande_essai: tuple = ()           # commande d'exécution d'un exemple
    bibliotheque: str = ''               # clef dans bibliotheque_langages
    compilateur: str = ''                # binaire de compilation, pour l'aide
    remarque: str = ''                   # limite connue, affichée telle quelle


# --------------------------------------------------------------------------
# Serveurs de langage, référencés une fois pour éviter les doublons.
# --------------------------------------------------------------------------

CLANGD = ServeurLsp('clangd', '', ('--background-index=false',
                                    '--header-insertion=never', '--log=error'),
                    'sudo apt install clangd')
RUST_ANALYZER = ServeurLsp('rust-analyzer', 'rust', (),
                           'sudo apt install rust-analyzer')
GOPLS = ServeurLsp('gopls', 'go', (), 'sudo apt install gopls')
FORTLS = ServeurLsp('fortls', 'fortran', (),
                    'sudo apt install fortran-language-server')
PYLSP = ServeurLsp('pylsp', 'python', (), 'sudo apt install python3-pylsp')
SOURCEKIT = ServeurLsp('sourcekit-lsp', 'swift', (),
                       'sudo apt install swiftlang')
TEXLAB = ServeurLsp('texlab', 'latex', (), 'sudo apt install texlab')
TS_LS = ServeurLsp('typescript-language-server', 'javascript', ('--stdio'),
                   'sudo npm i -g typescript typescript-language-server')
HTML_LS = ServeurLsp('vscode-html-language-server', 'html', ('--stdio'),
                     'sudo npm i -g vscode-langservers-extracted')
CSS_LS = ServeurLsp('vscode-css-language-server', 'css', ('--stdio'),
                    'sudo npm i -g vscode-langservers-extracted')
JSON_LS = ServeurLsp('vscode-json-language-server', 'json', ('--stdio'),
                     'sudo npm i -g vscode-langservers-extracted')
MARKDOWN_LS = ServeurLsp('vscode-markdown-language-server', 'markdown',
                         ('--stdio'), 'sudo npm i -g vscode-langservers-extracted')
BASH_LS = ServeurLsp('bash-language-server', 'shellscript', ('start'),
                     'sudo npm i -g bash-language-server')
LUA_LS = ServeurLsp('lua-language-server', 'lua', (),
                    'voir https://luals.github.io (binaire amont, hors apt)')
OCAML_LSP = ServeurLsp('ocamllsp', 'ocaml', (), 'opam install ocaml-lsp-server')
SOLARGRAPH = ServeurLsp('solargraph', 'ruby', ('stdio'), 'gem install solargraph')
INTELEPHENSE = ServeurLsp('intelephense', 'php', ('--stdio'),
                          'sudo npm i -g intelephense')
CMAKE_LS = ServeurLsp('cmake-language-server', 'cmake', (),
                      'pipx install cmake-language-server')
CSHARP_LS = ServeurLsp('csharp-ls', 'csharp', (),
                       'dotnet tool install --global csharp-ls')
KOTLIN_LS = ServeurLsp('kotlin-language-server', 'kotlin', (),
                       'voir https://github.com/fwcd/kotlin-language-server')
PASCAL_LS = ServeurLsp('pasls', 'pascal', (),
                       'voir https://github.com/genericptr/pasls')
PERL_LS = ServeurLsp('perl-language-server', 'perl', (),
                     'cpan install Perl::LanguageServer')
MARKSMAN = ServeurLsp('marksman', 'markdown', (),
                      'voir https://github.com/artempyanykh/marksman')

# --------------------------------------------------------------------------
# Adaptateurs DAP, référencés une fois.
# --------------------------------------------------------------------------

CODELLDB = AdaptateurDap('codelldb', (), 'voir https://github.com/vadimcn/codelldb',
                         'lldb')
JAVA_DEBUG = AdaptateurDap('jdtls', (), 'sudo apt install jdtls', 'java')
RUBY_DEBUG = AdaptateurDap('rdbg', ('--open'), 'gem install debug', 'rdbg')
LUA_DEBUG = AdaptateurDap('lua-debug', (), 'voir amont', 'lua')
PYTHON_DEBUGPY = AdaptateurDap('debugpy', (), 'pipx install debugpy', 'debugpy')
NODE_INSPECT = AdaptateurDap('node', ('--inspect-brk',), '', 'node')
PERL_DEBUG = AdaptateurDap('perl', ('-d',), '', 'perl')
OCAML_DEBUG = AdaptateurDap('ocamldebug', (), 'sudo apt install ocaml', 'ocaml')
BASH_DEBUG = AdaptateurDap('bashdb', (), 'sudo apt install bashdb', 'bash')

# --------------------------------------------------------------------------
# Le registre.
# --------------------------------------------------------------------------

LANGAGES = {
    'pascal': Langage(
        'pascal', 'Pascal', ('freepascal', 'delphi'),
        ('.pas', '.pp', '.p', '.lpr', '.inc'),
        (PASCAL_LS,), ('live_analysis', 'analyze'), 'gdb', (),
        False, 'compile', (), 'pascal', 'fpc',
        'Les points d’arrêt doivent porter sur une ligne exécutable, '
        'après compilation avec -g.'),
    'c': Langage(
        'c', 'C', (), ('.c', '.h'), (CLANGD,), ('polyglot', 'analyze_native'),
        'gdb', (CODELLDB,), False, 'compile', (), 'c', 'gcc', ''),
    'cpp': Langage(
        'cpp', 'C++', ('cplusplus', 'cxx'), ('.cc', '.cpp', '.cxx', '.c++',
                                             '.hh', '.hpp', '.hxx'),
        (CLANGD,), ('polyglot', 'analyze_native'), 'gdb', (CODELLDB,),
        False, 'compile', (), 'cpp', 'g++', ''),
    'cs': Langage(
        'cs', 'C#', ('csharp',), ('.cs',), (CSHARP_LS,),
        ('verificateurs_statiques', 'analyze'), '', (),
        False, 'compile', (), 'csharp', 'dotnet',
        'Aucun débogueur intégré : les erreurs apparaissent à la compilation.'),
    'csproj': Langage(
        'csproj', 'Projet C#', (), ('.csproj',), (), (), '', (),
        False, 'non', (), 'xml', '', 'Fichier de projet, non exécutable.'),
    'make': Langage(
        'make', 'Makefile', ('makefile',), ('.mk',), (),
        ('verificateurs_statiques', 'analyze'), '', (),
        False, 'compile', (), 'makefile', 'make',
        'Débogage par trace : make -n puis make --trace.'),
    'cmake': Langage(
        'cmake', 'CMake', (), ('.cmake',), (CMAKE_LS,),
        ('verificateurs_statiques', 'analyze'), '', (),
        False, 'compile', (), 'cmake', 'cmake',
        'Configuration par trace : cmake --trace-expand.'),
    'latex': Langage(
        'latex', 'LaTeX', ('tex',), ('.tex', '.sty', '.cls', '.bib'),
        (TEXLAB,), ('latex_live', 'analyze'), 'visuel', (),
        True, 'graphique', ('pdflatex',), 'latex', 'pdflatex',
        'Le débogage est visuel : rendu page à page et erreurs épinglées.'),
    'rust': Langage(
        'rust', 'Rust', (), ('.rs',), (RUST_ANALYZER,),
        ('live_new_languages', 'analyze'), 'gdb', (CODELLDB,),
        False, 'compile', (), 'rust', 'rustc', ''),
    'go': Langage(
        'go', 'Go', ('golang',), ('.go',), (GOPLS,),
        ('live_new_languages', 'analyze'), 'dap', (), False, 'compile', (),
        'go', 'go', 'Le débogage passe par delve (dlv), via DAP.'),
    'ruby': Langage(
        'ruby', 'Ruby', (), ('.rb', '.rake', '.gemspec'), (SOLARGRAPH,),
        ('scripting', 'analyze'),
        'dap', (RUBY_DEBUG,), False, 'interprete', ('ruby',), 'ruby', 'ruby', ''),
    'python': Langage(
        'python', 'Python', ('python3',), ('.py', '.pyw', '.pyi'),
        (PYLSP,), ('python_analyzer', 'analyze'), 'script',
        (PYTHON_DEBUGPY,), False, 'interprete', ('python3',), 'python',
        'python3', ''),
    'javascript': Langage(
        'javascript', 'JavaScript', ('js', 'node'), ('.js', '.mjs', '.cjs'),
        (TS_LS,), ('scripting', 'analyze'), 'script',
        (NODE_INSPECT,), False, 'interprete', ('node',), 'javascript', 'node',
        'Exécuté hors navigateur, par Node : pas de DOM ni de window.'),
    'php': Langage(
        'php', 'PHP', (), ('.php', '.phtml'), (INTELEPHENSE,),
        ('scripting', 'analyze'), 'php', (), False, 'interprete', ('php',),
        'php', 'php', 'Le débogage exige Xdebug (php-xdebug).'),
    'html': Langage(
        'html', 'HTML', ('html5',), ('.html', '.htm'), (HTML_LS,),
        ('verificateurs_statiques', 'analyze'), 'visuel', (), True, 'graphique', (),
        'html', '',
        'Débogage visuel : aperçu, surbrillance des éléments et styles calculés.'),
    'css': Langage(
        'css', 'CSS', ('css3',), ('.css',), (CSS_LS,),
        ('verificateurs_statiques', 'analyze'), 'visuel', (), True, 'graphique', (),
        'css', '',
        'Débogage visuel : règles appliquées et styles calculés par élément.'),
    'svg': Langage(
        'svg', 'SVG', (), ('.svg',), (HTML_LS,), ('verificateurs_statiques', 'analyze'),
        'visuel', (), True, 'graphique', (), 'xml', '',
        'Débogage visuel : rendu et surbrillance des formes.'),
    'markdown': Langage(
        'markdown', 'Markdown', ('md',), ('.md', '.markdown'),
        (MARKDOWN_LS, MARKSMAN), ('verificateurs_statiques', 'analyze'), 'visuel', (),
        True, 'graphique', (), 'markdown', '',
        'Débogage visuel : rendu côte à côte et liens cassés signalés.'),
    'shell': Langage(
        'shell', 'Shell', ('bash', 'sh'), ('.sh', '.bash', '.zsh'),
        (BASH_LS,), ('verificateurs_statiques', 'analyze'), 'instrumente',
        (BASH_DEBUG,), False, 'interprete', ('bash',), 'bash', 'bash',
        'Débogage par trace : chaque commande est affichée avant exécution.'),
    'swift': Langage(
        'swift', 'Swift', (), ('.swift',), (SOURCEKIT,),
        ('swift_kotlin', 'analyze'), 'dap', (CODELLDB,), False, 'compile', (),
        'swift', 'swiftc',
        'Le débogage passe par CodeLLDB ou swift-lldb ; il n’est pas encore '
        'câblé dans l’interface.'),
    'kotlin': Langage(
        'kotlin', 'Kotlin', (), ('.kt', '.kts'), (KOTLIN_LS,), (), 'dap',
        (JAVA_DEBUG,), False, 'compile', (), 'kotlin', 'kotlinc',
        'Analyse en continu désactivée : le démarrage de la JVM coûte plus '
        'que la frappe. Les erreurs apparaissent à la compilation.'),
    'perl': Langage(
        'perl', 'Perl', (), ('.pl', '.pm'), (PERL_LS,),
        ('additional_languages', 'analyze'), 'instrumente', (PERL_DEBUG,),
        False, 'interprete', ('perl',), 'perl', 'perl',
        'Débogage par trace : perl -d affiche chaque ligne exécutée.'),
    'basic': Langage(
        'basic', 'Yabasic', ('yabasic',), ('.bas',), (),
        ('additional_languages', 'analyze'), 'instrumente', (),
        False, 'interprete', ('yabasic',), 'basic', 'yabasic',
        'Yabasic n’a pas de débogueur : exécution tracée ligne à ligne.'),
    'fortran': Langage(
        'fortran', 'Fortran', (), ('.f', '.f90', '.f95', '.f03', '.f08',
                                   '.for', '.fpp'),
        (FORTLS,), ('additional_languages', 'analyze'), 'gdb', (),
        False, 'compile', (), 'fortran', 'gfortran', ''),
    'lua': Langage(
        'lua', 'Lua', (), ('.lua',), (LUA_LS,),
        ('additional_languages', 'analyze'), 'instrumente', (LUA_DEBUG,),
        False, 'interprete', ('lua5.4',), 'lua', 'lua5.4', ''),
    'ocaml': Langage(
        'ocaml', 'OCaml', (), ('.ml', '.mli'), (OCAML_LSP,),
        ('additional_languages', 'analyze'), 'instrumente', (OCAML_DEBUG,),
        False, 'compile', (), 'ocaml', 'ocamlfind', ''),
    'json': Langage(
        'json', 'JSON', (), ('.json',), (JSON_LS,), ('verificateurs_statiques', 'analyze'),
        '', (), False, 'non', (), 'json', '', 'Données, non exécutable.'),
    'xml': Langage(
        'xml', 'XML', (), ('.xml', '.xsd', '.xsl'), (HTML_LS,),
        ('verificateurs_statiques', 'analyze'), 'visuel', (), True, 'graphique', (),
        'xml', '', 'Données, non exécutable.'),
    'plaintext': Langage(
        'plaintext', 'Texte', ('text', 'textfile', 'note'), ('.txt',), (), (),
        '', (), False, 'non', (), 'plaintext', '', ''),

    # ------------------------------------------------------------------
    # Les dix langages ésotériques. Aucun n'est empaqueté pour Debian 13 :
    # les interpréteurs sont écrits dans langages_esoteriques.py, donc le
    # pas à pas, les points d'arrêt et l'inspection des variables sont
    # NATIFS (débogueur « esoterique », mode réel) — aucun binaire externe
    # n'est requis et rien n'est injecté dans le programme de l'utilisateur.
    # ------------------------------------------------------------------
    'brainfuck': Langage(
        'brainfuck', 'Brainfuck', ('bf', 'b', 'oxblood'), ('.bf', '.b'),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'brainfuck', '',
        'Huit commandes sur un ruban de 30 000 cellules de 8 bits. Moteur local, '
        'pas à pas natif.'),
    'whitespace': Langage(
        'whitespace', 'Whitespace', ('ws', 'espace'), ('.ws',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'whitespace', '',
        'Le code source est invisible : seuls espace, tabulation et fin de ligne '
        'comptent, tout autre caractère est ignoré.'),
    'piet': Langage(
        'piet', 'Piet', ('mondrian',), ('.png',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        True, 'graphique', (), 'piet', '',
        'Le programme EST une image PNG : aperçu, inspecteur visuel surlignant le '
        'bloc de couleur actif et son opération.'),
    # 4.3.0 : la SOURCE texte d'un programme Piet. Entrée DISTINCTE de « piet »,
    # et ce n'est pas un détail — server.analyser_en_direct() convertit le
    # contenu en binaire dès que resoudre(kind) == 'piet', ce qui est juste pour
    # un PNG et détruirait une source texte. Son débogueur n'est pas
    # « esoterique » : la machine à pas est piet_texte.pas_a_pas(), appelée par
    # l'éditeur Piet. polyglot.kind() a donc une branche explicite pour
    # l'extension, sans quoi un .piett n'aurait aucune analyse en direct.
    'piet_texte': Langage(
        'piet_texte', 'Piet (source texte)', ('piett', 'piet texte'), ('.piett',),
        (), ('verificateurs_statiques', 'analyze'), '', (),
        True, 'graphique', (), 'piet', '',
        'La source d’un programme Piet : une cellule de deux lettres par codel. '
        'Le PNG reste la forme COMPILÉE, celle que lit l’interpréteur Piet de '
        'langages_esoteriques.py — aucun second moteur n’est introduit. '
        'L’éditeur Piet donne la grille à peindre, l’aperçu PNG, l’exécution et '
        'le pas à pas.'),
    'lolcode': Langage(
        'lolcode', 'LOLCODE', ('lol',), ('.lol',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'lolcode', '',
        'Spécification 1.2. Le type BUKKIT (tableaux) n\'est volontairement pas '
        'pris en charge.'),
    'arnoldc': Langage(
        'arnoldc', 'ArnoldC', ('arnold',), ('.arnoldc',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'arnoldc', '',
        'Mots-clefs en majuscules, une commande par ligne, entiers seulement. Une '
        'variable non déclarée n\'est détectée qu\'à l\'exécution.'),
    'chef': Langage(
        'chef', 'Chef', ('recette',), ('.chef',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'chef', '',
        'Le programme est une recette de cuisine. Sans « Serves N. » la recette '
        'n\'imprime rien ; « Mix … well » est aléatoire.'),
    'shakespeare': Langage(
        'shakespeare', 'Shakespeare', ('spl',), ('.spl',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'shakespeare', '',
        'Le programme est une pièce de théâtre ; les personnages sont des '
        'variables. Lexique de noms et d\'adjectifs fourni, non exhaustif.'),
    'intercal': Langage(
        'intercal', 'INTERCAL', ('i', 'c-intercal'), ('.i',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'intercal', '',
        'Entre un cinquième et un tiers des instructions doivent commencer par '
        'PLEASE, sinon le programme est refusé.'),
    'fractran': Langage(
        'fractran', 'FRACTRAN', ('fra',), ('.fra',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'fractran', '',
        'Une fraction par ligne. Le langage n\'a aucune sortie : le résultat est '
        'l\'état n, visible dans l\'inspecteur de variables.'),
    'malbolge': Langage(
        'malbolge', 'Malbolge', ('mal',), ('.mal',),
        (), ('verificateurs_statiques', 'analyze'), 'esoterique', (),
        False, 'interprete', (), 'malbolge', '',
        'Auto-modifiant : aucun programme ne s\'écrit à la main. En fin d\'entrée '
        'le langage ne s\'arrête jamais, par spécification.'),
    # L’assembleur (4.0.0). Un langage de l’éditeur à part entière, et non pas
    # seulement une cible du panneau de rétro-ingénierie : le désassemblage d’un
    # binaire doit pouvoir s’ouvrir, se modifier et se réassembler ici.
    # Deux syntaxes coexistent et ne se mélangent pas — AT&T pour GAS (as),
    # Intel pour NASM (nasm) — donc l’analyse et la complétion doivent dire
    # laquelle elles ont reconnue plutôt que de deviner en silence.
    'asm': Langage(
        'asm', 'Assembleur', ('assembly', 'assembleur', 'x86', 'x86-64',
                              'x86_64', 'x64', 'nasm', 'gas', 'masm'),
        ('.asm', '.s', '.S', '.nasm'),
        (), ('verificateurs_statiques', 'analyze'), 'gdb', (),
        False, 'compile', (), 'asm', 'as',
        'Deux syntaxes : AT&T pour as (binutils), Intel pour nasm. L’assemblage '
        'passe par l’un des deux puis par ld, le débogage par gdb. Ces outils '
        's’installent séparément : sudo apt install binutils nasm gdb.'),
}

# Index des alias vers l'identifiant canonique, construit une seule fois.
_ALIAS = {}
for _identifiant, _langage in LANGAGES.items():
    _ALIAS[_identifiant.lower()] = _identifiant
    for _a in _langage.alias:
        if _a.lower() in _ALIAS and _ALIAS[_a.lower()] != _identifiant:
            raise ValueError('alias en conflit : %s' % _a)
        _ALIAS[_a.lower()] = _identifiant
    for _ext in _langage.extensions:
        _ALIAS.setdefault(_ext.lower(), _identifiant)


def resoudre(nom):
    """Normalise un nom de langage ou une extension en identifiant canonique.

    Accepte « csharp », « cs », « Makefile », « makefile », « .cpp », « C++ ».
    Renvoie None si rien ne correspond.
    """
    if not nom:
        return None
    cle = str(nom).strip().lower().lstrip('.')
    if cle in _ALIAS:
        return _ALIAS[cle]
    cle_ponctuee = '.' + cle
    if cle_ponctuee in _ALIAS:
        return _ALIAS[cle_ponctuee]
    for identifiant, langage in LANGAGES.items():
        if cle in (langage.libelle.lower(),):
            return identifiant
    return None


def langage(nom):
    """Le Langage correspondant, ou None."""
    identifiant = resoudre(nom)
    return LANGAGES.get(identifiant) if identifiant else None


def tous():
    """Les identifiants canoniques, dans l'ordre du registre."""
    return list(LANGAGES)


def extensions(nom):
    langage_ = langage(nom)
    return langage_.extensions if langage_ else ()


def est_graphique(nom):
    """Vrai si le langage produit un résultat visuel plutôt que du texte."""
    langage_ = langage(nom)
    return bool(langage_ and langage_.graphique)


def serveurs_lsp(nom):
    """Les serveurs de langage candidats, dans l'ordre de préférence."""
    langage_ = langage(nom)
    return langage_.lsp if langage_ else ()


def adaptateurs_dap(nom):
    langage_ = langage(nom)
    return langage_.dap if langage_ else ()


def verificateur(nom):
    """(module, fonction) du vérificateur statique local, ou None."""
    langage_ = langage(nom)
    return langage_.verificateur or None if langage_ else None


def debogueur(nom):
    """Le moteur de débogage : gdb, script, php, dap, visuel, instrumente, ''."""
    langage_ = langage(nom)
    return langage_.debogueur if langage_ else ''


def est_debogable(nom):
    """Vrai si un débogage, même visuel ou tracé, est proposé."""
    return bool(debogueur(nom))


def commande_essai(nom):
    """La commande qui exécute un exemple, ou () si le langage ne s'exécute pas."""
    langage_ = langage(nom)
    return langage_.commande_essai if langage_ else ()


def essayable(nom):
    """Le mode d'essai : compile, interprete, graphique, non."""
    langage_ = langage(nom)
    return langage_.essai if langage_ else 'non'


def libelle(nom):
    langage_ = langage(nom)
    return langage_.libelle if langage_ else str(nom or '')


def remarque(nom):
    langage_ = langage(nom)
    return langage_.remarque if langage_ else ''


def bibliotheque(nom):
    """Clef de la bibliothèque de mots-clés, ou '' si aucune."""
    langage_ = langage(nom)
    return langage_.bibliotheque if langage_ else ''


def installer_lsp(nom):
    """La commande d'installation du premier serveur candidat, ou ''."""
    for serveur in serveurs_lsp(nom):
        if serveur.installation:
            return serveur.installation
    return ''


def etat(nom):
    """Résumé affichable : ce qui est disponible pour ce langage, ici, maintenant."""
    import shutil
    langage_ = langage(nom)
    if langage_ is None:
        return {'langage': None}
    lsp = next((s for s in langage_.lsp if shutil.which(s.binaire)), None)
    dap = next((a for a in langage_.dap if shutil.which(a.binaire)), None)
    return {
        'langage': langage_.identifiant,
        'libelle': langage_.libelle,
        'lsp': lsp.binaire if lsp else None,
        'lsp_installation': lsp.installation if lsp else installer_lsp(langage_.identifiant),
        'verificateur': bool(langage_.verificateur),
        'debogueur': langage_.debogueur,
        'dap': dap.binaire if dap else None,
        'graphique': langage_.graphique,
        'essai': langage_.essai,
        'remarque': langage_.remarque,
    }
