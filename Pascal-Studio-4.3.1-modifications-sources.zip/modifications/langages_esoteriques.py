"""Moteurs des langages ésotériques (3.8.0).

Chaque langage est écrit comme une MACHINE À PAS, et non comme une fonction qui
avale le programme et rend la sortie. C'est un choix délibéré : il permet un
débogage pas à pas NATIF et exact — points d'arrêt, avancement d'une
instruction, inspection des registres, pile d'appels, évaluation — sans
l'injection de prélude ni les tubes nommés qu'exigent bash et Perl en 3.7.0.

Contrat commun, respecté par tous les moteurs :

    charger()    -> liste de diagnostics (analyse statique, sans exécuter)
    pas()        -> True si une instruction a été exécutée, False si terminé
    termine      -> booléen
    sortie       -> chaîne produite
    variables()  -> [{'name': …, 'value': …}]
    frames()     -> [{'file': …, 'line': …, 'function': …, 'level': …}]
    position     -> (ligne, colonne), en base 1, de l'instruction courante

Les spécifications ne sont pas devinées. Malbolge et Whitespace suivent la
spécification publiée sur esolangs.org ; la règle de chargement de Malbolge a
été retrouvée indépendamment puis vérifiée sur les exemples de la spécification.
Chaque moteur est validé par un programme connu au résultat documenté, voir
tests/test_langages_esoteriques.py. Ce qui n'est pas validé est déclaré comme
tel, jamais livré silencieusement.

Aucun moteur n'écrit de fichier, n'ouvre de socket et ne lance de processus.
Tous sont bornés : nombre d'instructions, taille de sortie, taille de mémoire.
"""

import random
import re


LIMITE_PAS = 2_000_000
LIMITE_SORTIE = 200_000
LIMITE_ENTREE = 200_000

SEVERITE_ERREUR = 'error'
SEVERITE_AVIS = 'warning'


def _diagnostic(severite, message, ligne, colonne=1):
    return {'severity': severite, 'message': message,
            'line': int(ligne), 'column': int(colonne)}


# Nombre maximal de facteurs premiers affichés par l'inspecteur. Sans plafond, un
# état de la forme 2 puissance 200 000 produirait 200 000 entrées et une chaîne
# de 400 ko dans le panneau de variables.
PLAFOND_FACTEURS = 200


def _texte_entier(valeur):
    """Chaîne lisible d'un entier, qui ne lève jamais sur les grandes valeurs.

    Python plafonne par défaut la conversion entier -> chaîne à 4300 chiffres.
    FRACTRAN dépasse ce plafond en quelques milliers de pas (l'état 1 avec la
    fraction 2/1 double à chaque pas), et Whitespace, Chef, ArnoldC, Shakespeare
    et Piet y parviennent aussi en multipliant. L'inspecteur doit afficher une
    forme résumée plutôt que de lever : le nombre de chiffres se déduit de la
    taille binaire, et les derniers chiffres s'obtiennent par un modulo, donc
    sans jamais convertir l'entier entier.
    """
    if valeur is None:
        return ''
    if isinstance(valeur, bool):
        return '1' if valeur else '0'
    if not isinstance(valeur, int):
        return str(valeur)
    try:
        return str(valeur)
    except ValueError:
        pass
    absolu = abs(valeur)
    chiffres = int(absolu.bit_length() * 0.30102999566398120) + 1
    return '%s%d chiffres, se termine par %030d' % (
        '-' if valeur < 0 else '', chiffres, absolu % (10 ** 30))


def _texte_valeurs(valeurs):
    """Chaîne lisible d'une suite de valeurs : pile, bol ou plat."""
    return '[' + ', '.join(_texte_entier(v) for v in valeurs) + ']'


# Taille binaire maximale d'une valeur produite par un moteur. 4096 bits font
# environ 1234 chiffres décimaux : largement au-delà de tout usage réel dans ces
# langages, et en dessous du plafond de conversion entier -> chaîne de Python.
LIMITE_BITS = 4096


class DebordementCapacite(Exception):
    """Une valeur intermédiaire dépasse la capacité admise par le moteur."""


def borne(valeur, quoi='la valeur'):
    """Refuse un entier démesuré au lieu de laisser la mémoire s'épuiser.

    Seules les multiplications et les puissances sont concernées : une addition
    ne fait croître la taille que d'un bit, et une division la réduit. Comme
    chaque résultat est contrôlé, la croissance exponentielle s'arrête dès le
    premier dépassement, quand les opérandes sont encore petits.
    """
    if isinstance(valeur, bool) or valeur is None:
        return valeur
    # FRACTRAN calcule son état via fractions.Fraction : le numérateur est la
    # seule partie dont la taille puisse exploser, le dénominateur restant petit.
    nombre = valeur.numerator if hasattr(valeur, 'numerator') else valeur
    if isinstance(nombre, int) and nombre.bit_length() > LIMITE_BITS:
        raise DebordementCapacite(
            '%s dépasse %d bits' % (quoi, LIMITE_BITS))
    return valeur


class _Entree(object):
    """File de caractères d'entrée, avec fin de fichier explicite."""

    def __init__(self, texte):
        if not isinstance(texte, str):
            texte = '' if texte is None else str(texte)
        if len(texte) > LIMITE_ENTREE:
            texte = texte[:LIMITE_ENTREE]
        self.texte = texte
        self.position = 0

    def ajouter(self, texte):
        """Ajoute de l'entrée PENDANT l'exécution, pour le débogage pas à pas.

        Un programme arrêté sur une lecture — la virgule de Brainfuck, GIMMEH en
        LOLCODE, « Take ... from refrigerator » en Chef, WRITE IN en INTERCAL —
        voit aussitôt ce qui est fourni. Renvoie False quand la borne d'entrée
        est déjà atteinte, pour que l'appelant puisse le dire à l'utilisateur au
        lieu de donner l'impression que le texte a été accepté.
        """
        if not isinstance(texte, str):
            texte = '' if texte is None else str(texte)
        reste = LIMITE_ENTREE - len(self.texte)
        if reste <= 0 or not texte:
            return False
        self.texte += texte[:reste]
        return True

    def caractere(self):
        if self.position >= len(self.texte):
            return None
        valeur = self.texte[self.position]
        self.position += 1
        return valeur

    def nombre(self):
        """Lit un entier signé, en sautant les blancs. None en fin d'entrée."""
        texte = self.texte
        i = self.position
        while i < len(texte) and texte[i] in ' \t\r\n':
            i += 1
        debut = i
        if i < len(texte) and texte[i] in '+-':
            i += 1
        chiffres = ''
        while i < len(texte) and texte[i].isdigit():
            chiffres += texte[i]
            i += 1
        if not chiffres:
            self.position = min(debut, len(texte))
            return None
        self.position = i
        valeur = int(chiffres)
        if texte[debut] == '-':
            valeur = -valeur
        return valeur

    def ligne(self):
        """Lit une ligne, sans son retour final. None en fin d'entrée.

        Une entrée entièrement consommée renvoie None, mais une dernière ligne
        sans retour à la ligne est bien renvoyée : c'est ce qu'attend GIMMEH.
        """
        if self.position >= len(self.texte):
            return None
        fin = self.texte.find('\n', self.position)
        if fin < 0:
            valeur = self.texte[self.position:]
            self.position = len(self.texte)
        else:
            valeur = self.texte[self.position:fin]
            self.position = fin + 1
        if valeur.endswith('\r'):
            valeur = valeur[:-1]
        return valeur

    def epuisee(self):
        return self.position >= len(self.texte)


class Moteur(object):
    """Base commune : bornes, sortie, état, et ce que voit le débogueur."""

    langage = ''
    libelle = ''

    def __init__(self, code, entree='', chemin=None):
        if not isinstance(code, str):
            code = '' if code is None else str(code)
        self.code = code
        self.entree = _Entree(entree)
        self.chemin = chemin or ('programme' + (self.extension or '.txt'))
        self._sortie = []
        self._taille_sortie = 0
        self.termine = False
        self.pas_fait = 0
        self.message = ''
        self.diagnostiques = []
        self.arret_anormal = False
        self.ligne_positions = self._indexer_lignes(code)

    # -- utilitaires partagés ------------------------------------------------
    @staticmethod
    def _indexer_lignes(code):
        """Début absolu de chaque ligne, pour convertir un index en ligne."""
        debuts = [0]
        for i, caractere in enumerate(code):
            if caractere == '\n':
                debuts.append(i + 1)
        return debuts

    def position_depuis_index(self, index):
        """(ligne, colonne) en base 1 pour un index absolu dans le source."""
        if index is None or index < 0:
            return (1, 1)
        index = min(index, max(0, len(self.code) - 1))
        ligne = 1
        for numero, debut in enumerate(self.ligne_positions, start=1):
            if debut <= index:
                ligne = numero
            else:
                break
        colonne = index - self.ligne_positions[ligne - 1] + 1
        return (ligne, colonne)

    @property
    def position(self):
        return self.position_depuis_index(getattr(self, 'index_courant', None))

    # -- sortie --------------------------------------------------------------
    def _ecrire(self, texte):
        if self._taille_sortie >= LIMITE_SORTIE:
            return
        reste = LIMITE_SORTIE - self._taille_sortie
        if len(texte) > reste:
            texte = texte[:reste]
            self.message = (self.message + ' Sortie tronquée à %d caractères.'
                            % LIMITE_SORTIE).strip()
        self._sortie.append(texte)
        self._taille_sortie += len(texte)

    @property
    def sortie(self):
        return ''.join(self._sortie)

    # -- contrat de débogage -------------------------------------------------
    def charger(self):
        """Analyse statique : ne modifie aucun état, n'exécute rien."""
        return []

    def pas(self):
        raise NotImplementedError

    def variables(self):
        return []

    def frames(self):
        ligne, _colonne = self.position
        return [{'file': self.chemin, 'line': ligne,
                 'function': self.libelle or self.langage, 'level': 0}]

    def executer(self, limite=LIMITE_PAS):
        """Exécution complète, bornée. Renvoie le compte rendu habituel."""
        for diagnostic in self.charger():
            self.diagnostiques.append(diagnostic)
        if any(d['severity'] == SEVERITE_ERREUR for d in self.diagnostiques):
            self.arret_anormal = True
            self.message = (self.message or
                            'Exécution refusée : le programme contient des erreurs.')
            return self.compte_rendu()
        while not self.termine and self.pas_fait < limite:
            try:
                if not self.pas():
                    break
            except DebordementCapacite as debordement:
                self.message = ('Capacité dépassée : %s. Exécution interrompue '
                                'pour protéger la mémoire.' % debordement)
                self.arret_anormal = True
                break
        if not self.termine and self.pas_fait >= limite:
            self.message = ('Limite de %d instructions atteinte : exécution '
                            'interrompue.' % limite)
            self.arret_anormal = True
        return self.compte_rendu()

    def compte_rendu(self):
        erreurs = [d for d in self.diagnostiques
                   if d['severity'] == SEVERITE_ERREUR]
        return {
            'ok': not self.arret_anormal and not erreurs,
            'state': 'error' if (self.arret_anormal or erreurs) else 'success',
            'diagnostics': self.diagnostiques,
            'message': self.message,
            'output': self.sortie,
            'sortie': self.sortie,
            'erreur': self.message,
            'pas': self.pas_fait,
            'termine': self.termine,
            'langage': self.langage,
        }


# =========================================================================
# BRAINFUCK
# =========================================================================
class Brainfuck(Moteur):
    """Huit commandes, ruban de 30 000 cellules de 8 bits.

    Toute autre octet est un commentaire, comme dans la référence. La
    correspondance des crochets est vérifiée à la lecture, avant toute
    exécution, ce qui permet de signaler l'erreur sur la bonne ligne.
    """

    langage = 'brainfuck'
    libelle = 'Brainfuck'
    extension = '.bf'
    TAILLE_RUBAN = 30_000
    COMMANDES = '><+-.,[]'

    def __init__(self, code, entree='', chemin=None):
        super(Brainfuck, self).__init__(code, entree, chemin)
        self.ruban = [0] * self.TAILLE_RUBAN
        self.pointeur = 0
        self.index_courant = 0
        self.sauts = {}
        self._programme = []

    def _preparer(self):
        """Repère les commandes et leurs positions, puis appareille les crochets."""
        if self._programme:
            return True
        for index, caractere in enumerate(self.code):
            if caractere in self.COMMANDES:
                self._programme.append((index, caractere))
        appareilles = []
        erreurs = []
        for position, (index, commande) in enumerate(self._programme):
            if commande == '[':
                appareilles.append(position)
            elif commande == ']':
                if not appareilles:
                    ligne, colonne = self.position_depuis_index(index)
                    erreurs.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'Crochet fermant « ] » sans ouvrant correspondant.',
                        ligne, colonne))
                    continue
                ouverture = appareilles.pop()
                self.sauts[ouverture] = position
                self.sauts[position] = ouverture
        for position in appareilles:
            index = self._programme[position][0]
            ligne, colonne = self.position_depuis_index(index)
            erreurs.append(_diagnostic(
                SEVERITE_ERREUR,
                'Crochet ouvrant « [ » jamais refermé.', ligne, colonne))
        self._erreurs_chargement = erreurs
        return not erreurs

    def charger(self):
        self._preparer()
        diagnostics = list(getattr(self, '_erreurs_chargement', []))
        if not self._programme:
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS,
                'Le programme ne contient aucune des huit commandes.', 1, 1))
        return diagnostics

    def pas(self):
        if self.termine:
            return False
        if not self._preparer():
            self.termine = True
            self.arret_anormal = True
            return False
        if self.index_courant >= len(self._programme):
            self.termine = True
            return False
        self.pas_fait += 1
        index, commande = self._programme[self.index_courant]
        self.position_brute = index
        if commande == '>':
            self.pointeur = (self.pointeur + 1) % self.TAILLE_RUBAN
        elif commande == '<':
            self.pointeur = (self.pointeur - 1) % self.TAILLE_RUBAN
        elif commande == '+':
            self.ruban[self.pointeur] = (self.ruban[self.pointeur] + 1) % 256
        elif commande == '-':
            self.ruban[self.pointeur] = (self.ruban[self.pointeur] - 1) % 256
        elif commande == '.':
            self._ecrire(chr(self.ruban[self.pointeur]))
        elif commande == ',':
            caractere = self.entree.caractere()
            self.ruban[self.pointeur] = 0 if caractere is None else ord(caractere) % 256
        elif commande == '[':
            if self.ruban[self.pointeur] == 0:
                self.index_courant = self.sauts[self.index_courant]
        elif commande == ']':
            if self.ruban[self.pointeur] != 0:
                self.index_courant = self.sauts[self.index_courant]
        self.index_courant += 1
        if self.index_courant >= len(self._programme):
            self.termine = True
        return True

    @property
    def position(self):
        if self._programme and self.index_courant < len(self._programme):
            return self.position_depuis_index(self._programme[self.index_courant][0])
        return (1, 1)

    def variables(self):
        cellules = []
        debut = max(0, self.pointeur - 4)
        fin = min(self.TAILLE_RUBAN, self.pointeur + 5)
        for adresse in range(debut, fin):
            marque = '*' if adresse == self.pointeur else ' '
            cellules.append({'name': 'cellule[%d]%s' % (adresse, marque),
                             'value': str(self.ruban[adresse])})
        non_nulles = sum(1 for v in self.ruban if v)
        return ([{'name': 'pointeur', 'value': str(self.pointeur)},
                 {'name': 'cellule courante',
                  'value': '%d (%r)' % (self.ruban[self.pointeur],
                                        chr(self.ruban[self.pointeur])
                                        if 32 <= self.ruban[self.pointeur] < 127 else '')},
                 {'name': 'cellules non nulles', 'value': str(non_nulles)}]
                + cellules)


# =========================================================================
# FRACTRAN
# =========================================================================
class Fractran(Moteur):
    """Registre unique, liste de fractions.

    L'état est un entier n. À chaque pas, n est multiplié par la PREMIÈRE fraction
    de la liste dont le produit est entier ; si aucune ne convient, le programme
    s'arrête. C'est la définition complète du langage : il n'y a pas d'autre
    instruction. Les nombres premiers servent de registres, puisqu'un entier n'est
    divisible que par les facteurs premiers de son état.
    """

    langage = 'fractran'
    libelle = 'FRACTRAN'
    extension = '.fra'

    def __init__(self, code, entree='', chemin=None):
        super(Fractran, self).__init__(code, entree, chemin)
        self.fractions = []
        self.etat = None
        self.index_courant = 0
        self.derniere_appliquee = None
        self._lignes = []

    def charger(self):
        from fractions import Fraction
        import re
        self.fractions = []
        self._lignes = []
        diagnostics = []
        for numero, ligne in enumerate(self.code.split('\n'), start=1):
            propre = ligne.strip()
            if not propre or propre.startswith('#') or propre.startswith(';'):
                continue
            if propre.lower().startswith(('n=', 'n =', 'etat=', 'état=')):
                valeur = propre.split('=', 1)[1].strip()
                if not valeur.isdigit():
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'État initial « %s » : un entier positif est attendu.' % valeur,
                        numero, 1))
                    continue
                self.etat = int(valeur)
                continue
            if re.fullmatch(r'\d+', propre):
                if self.etat is None:
                    self.etat = int(propre)
                    self._lignes.append((numero, propre, None))
                else:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'Entier isolé « %s » : une fraction « a/b » est attendue.' % propre,
                        numero, 1))
                continue
            if re.fullmatch(r'\d+\s*/\s*\d+', propre):
                numerateur, denominateur = propre.split('/')
                denominateur = denominateur.strip()
                if denominateur == '0':
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'Dénominateur nul.', numero,
                        propre.index('/') + 1))
                    continue
                fraction = Fraction(int(numerateur.strip()), int(denominateur))
                position = len(self.fractions)
                self.fractions.append(fraction)
                self._lignes.append((numero, propre, position))
                continue
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Ligne incompréhensible : « %s ». Une fraction « a/b » est attendue.'
                % propre, numero, 1))
        if not self.fractions:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Aucune fraction : un programme FRACTRAN en '
                'contient au moins une.', 1, 1))
        if self.etat is None:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Aucun état initial : indiquez « n = 2 » ou un entier seul en '
                'première ligne.', 1, 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    def pas(self):
        if self.termine:
            return False
        if self.etat is None:
            self.termine = True
            self.arret_anormal = True
            return False
        self.pas_fait += 1
        for position, fraction in enumerate(self.fractions):
            produit = borne(self.etat * fraction, "l'état")
            if produit.denominator == 1:
                self.etat = int(produit)
                self.derniere_appliquee = position
                self.index_courant = position
                return True
        self.termine = True
        return False

    @property
    def position(self):
        if self.derniere_appliquee is None:
            return (1, 1)
        for numero, _texte, position in self._lignes:
            if position == self.derniere_appliquee:
                return (numero, 1)
        return (1, 1)

    def variables(self):
        facteurs = self._factoriser(self.etat) if self.etat else []
        retour = [{'name': 'n (état)', 'value': _texte_entier(self.etat)}]
        if self.derniere_appliquee is not None:
            retour.append({'name': 'fraction appliquée',
                           'value': '#%d = %s' % (self.derniere_appliquee + 1,
                                                  self.fractions[self.derniere_appliquee])})
        if facteurs:
            retour.append({'name': 'décomposition en facteurs premiers',
                           'value': ' × '.join(_texte_entier(f) for f in facteurs)
                                    + (' × … (liste tronquée à %d facteurs)'
                                       % PLAFOND_FACTEURS
                                       if len(facteurs) >= PLAFOND_FACTEURS
                                       else '')})
            compte = {}
            for f in facteurs:
                compte[f] = compte.get(f, 0) + 1
            retour.append({'name': 'exposants (registres)',
                           'value': ', '.join('p%d=%d' % (p, e)
                                              for p, e in sorted(compte.items()))})
        return retour

    @staticmethod
    def _factoriser(n):
        """Facteurs premiers, au plus PLAFOND_FACTEURS d'entre eux.

        Le plafond compte aussi les facteurs répétés : c'est le seul moyen de
        borner le travail sur un état comme 2 puissance 200 000, dont la
        décomposition exacte comporterait 200 000 termes.
        """
        facteurs = []
        if n is None or n < 2:
            return facteurs
        diviseur = 2
        while diviseur * diviseur <= n and len(facteurs) < PLAFOND_FACTEURS:
            while n % diviseur == 0 and len(facteurs) < PLAFOND_FACTEURS:
                facteurs.append(diviseur)
                n //= diviseur
            diviseur += 1
        if n > 1 and len(facteurs) < PLAFOND_FACTEURS:
            facteurs.append(n)
        return facteurs


# =========================================================================
# WHITESPACE
# =========================================================================
class Whitespace(Moteur):
    """Espace, tabulation et saut de ligne sont la seule syntaxe.

    Tout autre caractère est ignoré : c'est le mécanisme de commentaire du
    langage. Les instructions sont groupées par IMP (Instruction Modification
    Parameter) : Espace = pile, Tabulation+Espace = arithmétique,
    Tabulation+Tabulation = tas, Tabulation+Saut = entrées/sorties,
    Saut = contrôle du flot.
    """

    langage = 'whitespace'
    libelle = 'Whitespace'
    extension = '.ws'
    ESPACE = ' '
    TAB = '\t'
    SAUT = '\n'

    def __init__(self, code, entree='', chemin=None):
        super(Whitespace, self).__init__(code, entree, chemin)
        self.pile = []
        self.tas = {}
        self.appels = []
        self.etiquettes = {}
        self.index_courant = 0
        self._programme = []
        self._position_absolue = None

    def _lire_nombre(self):
        """Signe (Espace +, Tabulation -), chiffres binaires, terminé par Saut."""
        flux = self._flux
        longueur = len(flux)
        if self._position_lecture is None:
            return None
        position = self._position_lecture
        if position >= longueur:
            return None
        signe = flux[position][1]
        if signe not in (self.ESPACE, self.TAB):
            return None
        position += 1
        valeur = 0
        chiffres = 0
        while position < longueur:
            caractere = flux[position][1]
            if caractere == self.SAUT:
                position += 1
                self._position_lecture = position
                if chiffres > 100:
                    return None
                return -valeur if signe == self.TAB else valeur
            if caractere == self.ESPACE:
                valeur = valeur * 2
            elif caractere == self.TAB:
                valeur = valeur * 2 + 1
            else:
                return None
            chiffres += 1
            position += 1
        return None

    def _lire_etiquette(self):
        flux = self._flux
        longueur = len(flux)
        position = self._position_lecture
        if position is None or position >= longueur:
            return None
        morceaux = []
        while position < longueur:
            caractere = flux[position][1]
            if caractere == self.SAUT:
                position += 1
                self._position_lecture = position
                return ''.join(morceaux)
            morceaux.append(self.ESPACE if caractere == self.ESPACE else 'T')
            position += 1
            if len(morceaux) > 200:
                return None
        return None

    def charger(self):
        self._position_lecture = None
        self._programme = []
        self.etiquettes = {}
        # La première passe parcourt le flux ; _position_lecture suit la lecture.
        self._flux = [(i, c) for i, c in enumerate(self.code)
                      if c in (self.ESPACE, self.TAB, self.SAUT)]
        self._position_lecture = 0
        self._index_lecture = 0
        self._preparer()
        return list(getattr(self, '_erreurs_chargement', []))

    def _preparer(self):
        """Découpage du flux en instructions, en suivant la position de lecture."""
        self._programme = []
        self.etiquettes = {}
        erreurs = []
        self._position_lecture = 0
        flux = self._flux
        longueur = len(flux)

        def prendre(n):
            if self._position_lecture + n > longueur:
                return None
            morceaux = flux[self._position_lecture:self._position_lecture + n]
            self._position_lecture += n
            return morceaux

        while self._position_lecture < longueur:
            depart = self._position_lecture
            marque = prendre(1)
            if marque is None:
                break
            imp = marque[0][1]
            if imp == self.ESPACE:
                commande = prendre(1)
                if commande is None:
                    erreurs.append((depart, 'Instruction de pile tronquée.')); break
                sous = commande[0][1]
                if sous == self.ESPACE:
                    nombre = self._lire_nombre()
                    if nombre is None:
                        erreurs.append((depart, 'PUSH sans nombre valide.')); break
                    self._programme.append(('push', depart, nombre))
                elif sous == self.TAB:
                    suite = prendre(1)
                    if suite is None:
                        erreurs.append((depart, 'Instruction tronquée.')); break
                    deuxieme = suite[0][1]
                    nombre = self._lire_nombre()
                    if nombre is None:
                        erreurs.append((depart, 'COPY/SLIDE sans nombre valide.')); break
                    if deuxieme == self.ESPACE:
                        self._programme.append(('copy', depart, nombre))
                    elif deuxieme == self.SAUT:
                        self._programme.append(('slide', depart, nombre))
                    else:
                        erreurs.append((depart, 'Instruction de pile inconnue.')); break
                else:
                    code = sous
                    suite = prendre(1)
                    if suite is None:
                        erreurs.append((depart, 'Instruction de pile tronquée.')); break
                    code = code + suite[0][1]
                    table = {self.SAUT + self.ESPACE: 'dup',
                             self.SAUT + self.TAB: 'swap',
                             self.SAUT + self.SAUT: 'discard'}
                    if code not in table:
                        erreurs.append((depart, 'Instruction de pile inconnue.')); break
                    self._programme.append((table[code], depart, None))
            elif imp == self.TAB:
                deuxieme = prendre(1)
                if deuxieme is None:
                    erreurs.append((depart, 'Instruction tronquée.')); break
                categorie = deuxieme[0][1]
                if categorie == self.TAB:
                    suite = prendre(1)
                    if suite is None:
                        erreurs.append((depart, 'Accès au tas tronqué.')); break
                    premier = suite[0][1]
                    table = {self.ESPACE: 'store', self.TAB: 'retrieve'}
                    if premier not in table:
                        erreurs.append((depart, 'Accès au tas inconnu.')); break
                    self._programme.append((table[premier], depart, None))
                else:
                    suite = prendre(2)
                    if suite is None:
                        erreurs.append((depart, 'Instruction tronquée.')); break
                    code = ''.join(c[1] for c in suite)
                    if categorie == self.ESPACE:
                        table = {self.ESPACE + self.ESPACE: 'add',
                                 self.ESPACE + self.TAB: 'sub',
                                 self.ESPACE + self.SAUT: 'mul',
                                 self.TAB + self.ESPACE: 'div',
                                 self.TAB + self.TAB: 'mod'}
                    else:
                        table = {self.ESPACE + self.ESPACE: 'out_char',
                                 self.ESPACE + self.TAB: 'out_nombre',
                                 self.TAB + self.ESPACE: 'in_char',
                                 self.TAB + self.TAB: 'in_nombre'}
                    if code not in table:
                        erreurs.append((depart, 'Instruction inconnue.')); break
                    self._programme.append((table[code], depart, None))
            else:
                commande = prendre(2)
                if commande is None:
                    erreurs.append((depart, 'Contrôle de flot tronqué.')); break
                code = ''.join(c[1] for c in commande)
                if code == self.SAUT + self.SAUT:
                    # On NE S'ARRÊTE PAS à « end » : il termine l'exécution, pas
                    # l'analyse. Les sous-programmes placés après sont courants en
                    # Whitespace, et leurs étiquettes doivent être enregistrées,
                    # sinon un CALL échoue sur une étiquette pourtant définie.
                    self._programme.append(('end', depart, None)); continue
                if code == self.TAB + self.SAUT:
                    self._programme.append(('ret', depart, None)); continue
                table = {self.ESPACE + self.ESPACE: 'label',
                         self.ESPACE + self.TAB: 'call',
                         self.ESPACE + self.SAUT: 'jmp',
                         self.TAB + self.ESPACE: 'jz',
                         self.TAB + self.TAB: 'jn'}
                if code not in table:
                    erreurs.append((depart, 'Contrôle de flot inconnu.')); break
                etiquette = self._lire_etiquette()
                if etiquette is None:
                    erreurs.append((depart, 'Étiquette absente ou non terminée.')); break
                ordre = table[code]
                self._programme.append((ordre, depart, etiquette))
                if ordre == 'label':
                    if etiquette in self.etiquettes:
                        erreurs.append((depart, 'Étiquette « %s » définie deux fois.'
                                        % etiquette)); break
                    self.etiquettes[etiquette] = len(self._programme) - 1
        diagnostics = []
        for index, message in erreurs:
            absolue = flux[index][0] if index < longueur else 0
            ligne, colonne = self.position_depuis_index(absolue)
            diagnostics.append(_diagnostic(SEVERITE_ERREUR, message, ligne, colonne))
        if not erreurs and not self._programme:
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS, 'Aucune instruction : le programme est vide.', 1, 1))
        self._erreurs_chargement = diagnostics

    def pas(self):
        if self.termine:
            return False
        if not self._programme and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        if self.index_courant >= len(self._programme):
            self.termine = True
            return False
        self.pas_fait += 1
        ordre, depart, parametre = self._programme[self.index_courant]
        self._position_absolue = self._flux[depart][0] if depart < len(self._flux) else None
        self.index_courant += 1
        if ordre == 'push':
            self.pile.append(parametre)
        elif ordre in ('dup', 'swap', 'discard', 'copy', 'slide'):
            if not self.pile and ordre != 'slide':
                return self._erreur_pile(ordre, depart)
            if ordre == 'dup':
                self.pile.append(self.pile[-1])
            elif ordre == 'swap':
                if len(self.pile) < 2:
                    return self._erreur_pile(ordre, depart)
                self.pile[-1], self.pile[-2] = self.pile[-2], self.pile[-1]
            elif ordre == 'discard':
                self.pile.pop()
            elif ordre == 'copy':
                if parametre < 0 or parametre >= len(self.pile):
                    return self._erreur_pile('copy (rang %d hors pile)' % parametre, depart)
                self.pile.append(self.pile[-1 - parametre])
            else:
                if parametre >= len(self.pile):
                    return self._erreur_pile('slide (n=%d)' % parametre, depart)
                sommet = self.pile.pop()
                for _ in range(parametre):
                    self.pile.pop()
                self.pile.append(sommet)
        elif ordre in ('add', 'sub', 'mul', 'div', 'mod'):
            if len(self.pile) < 2:
                return self._erreur_pile(ordre, depart)
            droite = self.pile.pop()
            gauche = self.pile.pop()
            if ordre == 'add':
                self.pile.append(gauche + droite)
            elif ordre == 'sub':
                self.pile.append(gauche - droite)
            elif ordre == 'mul':
                self.pile.append(borne(gauche * droite, 'le résultat'))
            elif ordre == 'div':
                if droite == 0:
                    return self._erreur('Division par zéro.', depart)
                self.pile.append(int(gauche / droite) if gauche * droite >= 0
                                 else -(-gauche // droite))
            else:
                if droite == 0:
                    return self._erreur('Modulo par zéro.', depart)
                self.pile.append(gauche - droite * int(gauche / droite))
        elif ordre == 'store':
            if len(self.pile) < 2:
                return self._erreur_pile('store', depart)
            valeur = self.pile.pop()
            adresse = self.pile.pop()
            if len(self.tas) > 100_000:
                return self._erreur('Tas saturé (100 000 cellules).', depart)
            self.tas[adresse] = valeur
        elif ordre == 'retrieve':
            if not self.pile:
                return self._erreur_pile('retrieve', depart)
            adresse = self.pile.pop()
            if adresse not in self.tas:
                return self._erreur('Adresse %d jamais écrite dans le tas.' % adresse,
                                    depart)
            self.pile.append(self.tas[adresse])
        elif ordre == 'out_char':
            if not self.pile:
                return self._erreur_pile('out_char', depart)
            self._ecrire(chr(self.pile.pop() % 0x110000))
        elif ordre == 'out_nombre':
            if not self.pile:
                return self._erreur_pile('out_nombre', depart)
            self._ecrire(str(self.pile.pop()))
        elif ordre == 'in_char':
            if not self.pile:
                return self._erreur_pile('in_char', depart)
            adresse = self.pile.pop()
            caractere = self.entree.caractere()
            self.tas[adresse] = 0 if caractere is None else ord(caractere)
        elif ordre == 'in_nombre':
            if not self.pile:
                return self._erreur_pile('in_nombre', depart)
            adresse = self.pile.pop()
            nombre = self.entree.nombre()
            self.tas[adresse] = 0 if nombre is None else nombre
        elif ordre in ('jmp', 'jz', 'jn', 'call', 'label'):
            if parametre not in self.etiquettes:
                return self._erreur('Étiquette « %s » introuvable.' % parametre, depart)
            cible = self.etiquettes[parametre]
            if ordre == 'jmp':
                self.index_courant = cible
            elif ordre == 'call':
                self.appels.append(self.index_courant)
                self.index_courant = cible
            elif ordre == 'jz':
                if not self.pile:
                    return self._erreur_pile('jz', depart)
                if self.pile.pop() == 0:
                    self.index_courant = cible
            elif ordre == 'jn':
                if not self.pile:
                    return self._erreur_pile('jn', depart)
                if self.pile.pop() < 0:
                    self.index_courant = cible
        elif ordre == 'ret':
            if not self.appels:
                return self._erreur('RETURN sans appel de sous-programme.', depart)
            self.index_courant = self.appels.pop()
        elif ordre == 'end':
            self.termine = True
        return True

    def _erreur_pile(self, quoi, depart):
        return self._erreur('Pile trop petite pour %s.' % quoi, depart)

    def _erreur(self, message, depart):
        absolue = self._flux[depart][0] if depart < len(self._flux) else 0
        ligne, colonne = self.position_depuis_index(absolue)
        self.diagnostiques.append(_diagnostic(SEVERITE_ERREUR, message, ligne, colonne))
        self.message = message
        self.termine = True
        self.arret_anormal = True
        return False

    @property
    def position(self):
        if self._position_absolue is not None:
            return self.position_depuis_index(self._position_absolue)
        if self._programme and self.index_courant < len(self._programme):
            depart = self._programme[self.index_courant][1]
            if depart < len(getattr(self, '_flux', [])):
                return self.position_depuis_index(self._flux[depart][0])
        return (1, 1)

    def variables(self):
        retour = [{'name': 'profondeur de pile', 'value': str(len(self.pile))}]
        for rang, valeur in enumerate(reversed(self.pile[-8:])):
            retour.append({'name': 'pile[%d]' % rang,
                           'value': _texte_entier(valeur)})
        if self.tas:
            retour.append({'name': 'cellules du tas', 'value': str(len(self.tas))})
            for adresse in sorted(self.tas)[:6]:
                retour.append({'name': 'tas[%d]' % adresse,
                               'value': _texte_entier(self.tas[adresse])})
        retour.append({'name': 'appels en cours', 'value': str(len(self.appels))})
        return retour

    def frames(self):
        ligne, _colonne = self.position
        cadres = [{'file': self.chemin, 'line': ligne,
                   'function': 'principal', 'level': 0}]
        for niveau, retour in enumerate(reversed(self.appels), start=1):
            if retour < len(self._programme):
                depart = self._programme[retour][1]
                absolue = self._flux[depart][0] if depart < len(self._flux) else 0
                cadre_ligne, _ = self.position_depuis_index(absolue)
                cadres.append({'file': self.chemin, 'line': cadre_ligne,
                               'function': 'sous-programme', 'level': niveau})
        return cadres


# =========================================================================
# MALBOLGE
# =========================================================================
# Table de l'opération « crazy », trit par trit. Lignes = la valeur de [D],
# colonnes = la valeur de A :  TABLE[d*3 + a].
#        A=0 A=1 A=2
#  D=0     1   0   0
#  D=1     1   0   2
#  D=2     2   2   1
TABLE_CRAZY = (1, 0, 0, 1, 0, 2, 2, 2, 1)

# Chiffrement appliqué à [C] après chaque instruction qui n'arrête pas,
# indexé par (valeur - 33). Les deux chaînes font 94 caractères.
MALBOLGE_ORIGINE = (
    '!"#$%&\'()*+,-./0123456789:;<=>?@'
    'ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`'
    'abcdefghijklmnopqrstuvwxyz{|}~')
MALBOLGE_TRADUCTION = (
    '5z]&gqtyfr$(we4{WP)H-Zn,[%\\3dL+Q;>U!pJS72FhOA1C'
    'B6v^=I_0/8|jsb9m<.TVac`uY*MK\'X~xDl}REokN:#?G"i@')

# Valeurs de (C + [C]) % 94 correspondant à une instruction. Toute autre valeur
# est un NOP à l'exécution, mais est INTERDITE dans le source au chargement.
# Garde-fou : la table doit couvrir exactement les 94 caractères graphiques,
# sinon l'indexation par (valeur - 33) décalerait tout le chiffrement.
assert MALBOLGE_ORIGINE == ''.join(chr(i) for i in range(33, 127)), \
    'table originale de Malbolge incorrecte'
assert len(MALBOLGE_TRADUCTION) == 94, \
    'table de traduction de Malbolge : %d caractères au lieu de 94' \
    % len(MALBOLGE_TRADUCTION)

MALBOLGE_OPS = frozenset((4, 5, 23, 39, 40, 62, 68, 81))
MALBOLGE_INSTRUCTIONS = {
    4: 'jmp [d]', 5: 'out a', 23: 'in a', 39: 'rotr [d]; mov a,[d]',
    40: 'mov d,[d]', 62: 'crz a,[d]', 68: 'nop', 81: 'end'}
MALBOLGE_LETTRES = {4: 'i', 5: '<', 23: '/', 39: '*', 40: 'j', 62: 'p',
                    68: 'o', 81: 'v'}
TAILLE_MEMOIRE_MALBOLGE = 59049      # 3^10
MOT_MAX_MALBOLGE = 59048             # 2222222222 en base 3
FIN_ENTREE_MALBOLGE = 59048          # valeur de A en fin d'entrée, sans arrêt


def crazy(a, d):
    """Opération « crazy » trit par trit sur des mots de 10 trits."""
    resultat = 0
    puissance = 1
    for _ in range(10):
        resultat += TABLE_CRAZY[(d % 3) * 3 + (a % 3)] * puissance
        a //= 3
        d //= 3
        puissance *= 3
    return resultat


def rotation_droite(mot):
    """Fait tourner un mot d'un trit vers la droite : 0002111112 -> 2000211111."""
    return (mot % 3) * 19683 + mot // 3


class Malbolge(Moteur):
    """Machine ternaire auto-modifiante.

    Trois registres de dix trits : C (pointeur de code), D (pointeur de données)
    et A (accumulateur). Une mémoire de 59 049 mots, partagée entre le code et
    les données. L'instruction exécutée dépend de (C + [C]) % 94, donc du mot
    pointé ET de sa position : le même caractère ne fait pas la même chose selon
    l'adresse. Après chaque instruction qui n'arrête pas, le mot en C est
    chiffré par une table de traduction, ce qui rend le programme
    auto-modifiant.

    La formule a été vérifiée sur une trace d'exécution publiée, et la règle de
    chargement sur les exemples de la spécification : un caractère est autorisé
    à la position i si et seulement si son code est dans 33..126 et
    (code + i) % 94 appartient à {4, 5, 23, 39, 40, 62, 68, 81}.
    """

    langage = 'malbolge'
    libelle = 'Malbolge'
    extension = '.mal'

    def __init__(self, code, entree='', chemin=None):
        super(Malbolge, self).__init__(code, entree, chemin)
        self.A = 0
        self.C = 0
        self.D = 0
        self.memoire = [0] * TAILLE_MEMOIRE_MALBOLGE
        self.index_courant = 0
        self._programme = []
        self.derniere_instruction = None
        self.charge = False

    # -- chargement ----------------------------------------------------------
    def _charger_memoire(self):
        """Place le programme en mémoire, blancs ignorés, puis complète."""
        if self.charge:
            return
        caracteres = []
        for index, caractere in enumerate(self.code):
            if caractere.isspace():
                continue
            caracteres.append((index, caractere))
        self._programme = caracteres
        for position, (_index, caractere) in enumerate(caracteres):
            self.memoire[position] = ord(caractere)
        longueur = len(caracteres)
        # Au-delà du programme, chaque mot est l'opération crazy appliquée au
        # précédent et à l'avant-précédent, dans cet ordre.
        for adresse in range(longueur, TAILLE_MEMOIRE_MALBOLGE):
            precedent = self.memoire[adresse - 1] if adresse >= 1 else 0
            avant = self.memoire[adresse - 2] if adresse >= 2 else 0
            self.memoire[adresse] = crazy(precedent, avant)
        self.charge = True

    def charger(self):
        self._charger_memoire()
        diagnostics = []
        for position, (index, caractere) in enumerate(self._programme):
            code = ord(caractere)
            ligne, colonne = self.position_depuis_index(index)
            if code < 33 or code > 126:
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Caractère %r (code %d) hors de la plage graphique 33-126.'
                    % (caractere, code), ligne, colonne))
                continue
            operation = (code + position) % 94
            if operation not in MALBOLGE_OPS:
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Caractère %r à la position %d donne l\'opération %d, qui '
                    'n\'est pas une instruction autorisée au chargement. Un '
                    'seul NOP est permis, celui dont (C + [C]) %% 94 vaut 68.'
                    % (caractere, position, operation), ligne, colonne))
        if not self._programme:
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS, 'Programme vide : aucune instruction.', 1, 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    def instruction_courante(self):
        """(opération, libellé, lettre) à l'adresse C, ou None si invalide."""
        mot = self.memoire[self.C]
        if mot < 33 or mot > 126:
            return None
        operation = (mot + self.C) % 94
        return (operation,
                MALBOLGE_INSTRUCTIONS.get(operation, 'nop (non autorisé)'),
                MALBOLGE_LETTRES.get(operation, 'o'))

    # -- exécution -----------------------------------------------------------
    def pas(self):
        if self.termine:
            return False
        if not self.charge:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        self.pas_fait += 1
        mot = self.memoire[self.C]
        if mot < 33 or mot > 126:
            # La spécification arrête l'exécution ; l'interpréteur de référence
            # boucle sans changer d'état. On suit la spécification.
            self.termine = True
            self.arret_anormal = True
            self.message = ('Mot %d à l\'adresse %d hors de la plage 33-126 : '
                            'exécution arrêtée.' % (mot, self.C))
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR, self.message, *self.position))
            return False
        operation = (mot + self.C) % 94
        self.derniere_instruction = operation
        self.index_courant = self.C

        if operation == 81:
            # L'arrêt rend la main AVANT chiffrement et incrémentation.
            self.termine = True
            return False
        if operation == 4:
            self.C = self.memoire[self.D]
        elif operation == 5:
            self._ecrire(chr(self.A % 256))
        elif operation == 23:
            caractere = self.entree.caractere()
            self.A = FIN_ENTREE_MALBOLGE if caractere is None else ord(caractere)
        elif operation == 39:
            self.memoire[self.D] = rotation_droite(self.memoire[self.D])
            self.A = self.memoire[self.D]
        elif operation == 40:
            self.D = self.memoire[self.D]
        elif operation == 62:
            self.memoire[self.D] = crazy(self.A, self.memoire[self.D])
            self.A = self.memoire[self.D]
        # 68 et toute autre valeur : NOP.

        # Chiffrement du mot en C, puis incrémentation de C et D.
        if 33 <= self.memoire[self.C] <= 126:
            self.memoire[self.C] = ord(
                MALBOLGE_TRADUCTION[self.memoire[self.C] - 33])
        self.C = (self.C + 1) % TAILLE_MEMOIRE_MALBOLGE
        self.D = (self.D + 1) % TAILLE_MEMOIRE_MALBOLGE
        return True

    @property
    def position(self):
        index = self.index_courant if self.index_courant is not None else self.C
        if index < len(self._programme):
            return self.position_depuis_index(self._programme[index][0])
        return (1, 1)

    def variables(self):
        instruction = self.instruction_courante()
        retour = [{'name': 'A (accumulateur)', 'value': str(self.A)},
                  {'name': 'C (pointeur de code)', 'value': str(self.C)},
                  {'name': 'D (pointeur de données)', 'value': str(self.D)},
                  {'name': '[C]', 'value': '%d %r' % (
                      self.memoire[self.C],
                      chr(self.memoire[self.C])
                      if 32 <= self.memoire[self.C] < 127 else '')},
                  {'name': '[D]', 'value': str(self.memoire[self.D])}]
        if instruction:
            operation, libelle, lettre = instruction
            retour.append({'name': 'opération (C+[C])%94',
                           'value': '%d = %s  [%s]' % (operation, libelle, lettre)})
        retour.append({'name': 'A en base 3', 'value': self._en_base3(self.A)})
        retour.append({'name': '[D] en base 3',
                       'value': self._en_base3(self.memoire[self.D])})
        return retour

    @staticmethod
    def _en_base3(mot):
        chiffres = []
        for _ in range(10):
            chiffres.append(str(mot % 3))
            mot //= 3
        return ''.join(reversed(chiffres))


# =========================================================================
# ARNOLDC
# =========================================================================
# Mots-clefs d'ArnoldC, d'après la spécification. Les variables sont en
# minuscules, les mots-clefs en MAJUSCULES, et chaque commande occupe sa ligne.
ARNOLD = {
    'IT\'S SHOWTIME': 'debut',
    'YOU HAVE BEEN TERMINATED': 'fin',
    'HEY CHRISTMAS TREE': 'declarer',
    'YOU SET US UP': 'valeur_initiale',
    'TALK TO THE HAND': 'imprimer',
    'I WANT TO ASK YOU A BUNCH OF QUESTIONS AND I WANT TO HAVE THEM ANSWERED '
    'IMMEDIATELY': 'lire',
    'GET TO THE CHOPPER': 'affecter',
    'HERE IS MY INVITATION': 'poser',
    'ENOUGH TALK': 'fin_affectation',
    'GET UP': 'ajouter',
    'GET DOWN': 'soustraire',
    'YOU\'RE FIRED': 'multiplier',
    'HE HAD TO SPLIT': 'diviser',
    'I LET HIM GO': 'modulo',
    'YOU ARE NOT YOU YOU ARE ME': 'egal',
    'LET OFF SOME STEAM BENNET': 'superieur',
    'CONSIDER THAT A DIVORCE': 'ou',
    'KNOCK KNOCK': 'et',
    'STICK AROUND': 'tantque',
    'CHILL': 'fin_tantque',
    'BECAUSE I\'M GOING TO SAY PLEASE': 'si',
    'BULLSHIT': 'sinon',
    'YOU HAVE NO RESPECT FOR LOGIC': 'fin_si',
    'LISTEN TO ME VERY CAREFULLY': 'methode',
    'GIVE THESE PEOPLE AIR': 'methode_valeur',
    'I NEED YOUR CLOTHES YOUR BOOTS AND YOUR MOTORCYCLE': 'parametre',
    'I\'LL BE BACK': 'retourner',
    'HASTA LA VISTA, BABY': 'fin_methode',
    'DO IT NOW': 'appeler',
    'GET YOUR ASS TO MARS': 'appeler_affecter',
}
# Les plus longs d'abord : « GET UP » ne doit pas voler la priorité à
# « GET TO THE CHOPPER », ni « GET DOWN » à « GET YOUR ASS TO MARS ».
ARNOLD_TRIES = sorted(ARNOLD, key=len, reverse=True)
FAUX_ARNOLD = '@I LIED'
VRAI_ARNOLD = '@NO PROBLEMO'


class ArnoldC(Moteur):
    """Répliques d'Arnold Schwarzenegger comme jeu d'instructions.

    Les valeurs sont des entiers ; VRAI vaut 1 et FAUX 0. L'affectation se fait
    par blocs : GET TO THE CHOPPER ouvre, les opérations s'enchaînent, ENOUGH
    TALK referme. Les méthodes peuvent rendre une valeur (GIVE THESE PEOPLE AIR)
    ou non (LISTEN TO ME VERY CAREFULLY), et l'appel récupère cette valeur avec
    GET YOUR ASS TO MARS.
    """

    langage = 'arnoldc'
    libelle = 'ArnoldC'
    extension = '.arnoldc'

    def __init__(self, code, entree='', chemin=None):
        super(ArnoldC, self).__init__(code, entree, chemin)
        self.valeurs = {}
        self.index_courant = 0
        self._instructions = []
        self._methodes = {}
        self.pile_appels = []
        self._lignes = []
        self._pile_blocs = []
        self._cible = None
        self._accumulateur = None
        self._ligne_courante = 1
        self._corps_courant = None

    # -- analyse -------------------------------------------------------------
    def _decouper(self, ligne):
        """Sépare le mot-clef de ses opérandes, en respectant les guillemets."""
        propre = ligne.strip()
        if not propre:
            return None
        if propre.startswith('#') or propre.startswith('//'):
            return None
        majuscule = propre.upper()
        for mot in ARNOLD_TRIES:
            if majuscule == mot or majuscule.startswith(mot + ' ') \
                    or majuscule.startswith(mot + '\t'):
                reste = propre[len(mot):].strip()
                return (ARNOLD[mot], reste, mot)
        return ('inconnu', propre, propre)

    @staticmethod
    def _operateur(texte):
        """Un nom de variable, une chaîne entre guillemets, ou un littéral."""
        texte = texte.strip()
        if texte.startswith('"') and texte.endswith('"') and len(texte) >= 2:
            return ('texte', texte[1:-1])
        if texte == FAUX_ARNOLD:
            return ('nombre', 0)
        if texte == VRAI_ARNOLD:
            return ('nombre', 1)
        try:
            return ('nombre', int(texte))
        except ValueError:
            pass
        if texte and texte.lower() == texte and texte.replace('_', '').isalnum():
            return ('variable', texte)
        return ('invalide', texte)

    def charger(self):
        self._instructions = []
        self._methodes = {}
        self._lignes = []
        diagnostics = []
        blocs_affectation = 0
        boucles = 0
        conditions = 0
        methode_courante = None
        vu_debut = False
        vu_fin = False
        for numero, ligne in enumerate(self.code.split('\n'), start=1):
            decoupe = self._decouper(ligne)
            if decoupe is None:
                continue
            ordre, reste, mot = decoupe
            if ordre == 'inconnu':
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Commande inconnue : « %s ». Les mots-clefs d\'ArnoldC sont '
                    'en majuscules et les variables en minuscules.' % reste,
                    numero, 1))
                continue
            if ordre == 'methode':
                if not reste:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'Déclaration de méthode sans nom.',
                        numero, 1))
                    continue
                nom = reste.split()[0]
                methode_courante = {'nom': nom, 'sans_valeur': True,
                                    'parametres': [], 'corps': [],
                                    'ligne': numero}
                self._methodes[nom] = methode_courante
            elif ordre == 'methode_valeur':
                nom = reste.split()[0] if reste else ''
                methode_courante = {'nom': nom, 'sans_valeur': False,
                                    'parametres': [], 'corps': [],
                                    'ligne': numero}
                if nom:
                    self._methodes[nom] = methode_courante
                else:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'Méthode à valeur sans nom.', numero, 1))
            elif ordre == 'parametre':
                if methode_courante is None:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'Paramètre hors d\'une déclaration de méthode.', numero, 1))
                elif reste:
                    methode_courante['parametres'].append(reste.split()[0])
            elif ordre == 'fin_methode':
                if methode_courante is None:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'HASTA LA VISTA, BABY sans méthode ouverte.', numero, 1))
                methode_courante = None
            elif methode_courante is not None:
                methode_courante['corps'].append((ordre, reste, numero))
                if ordre in ('affecter', 'si', 'tantque'):
                    pass
            else:
                self._instructions.append((ordre, reste, numero))
                if ordre == 'debut':
                    vu_debut = True
            if ordre == 'fin':
                vu_fin = True
            if ordre == 'affecter':
                blocs_affectation += 1
            elif ordre == 'fin_affectation':
                blocs_affectation -= 1
                if blocs_affectation < 0:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'ENOUGH TALK sans GET TO THE CHOPPER.', numero, 1))
                    blocs_affectation = 0
            elif ordre == 'tantque':
                boucles += 1
            elif ordre == 'fin_tantque':
                boucles -= 1
                if boucles < 0:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'CHILL sans STICK AROUND.', numero, 1))
                    boucles = 0
            elif ordre == 'si':
                conditions += 1
            elif ordre == 'fin_si':
                conditions -= 1
                if conditions < 0:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'YOU HAVE NO RESPECT FOR LOGIC sans BECAUSE I\'M GOING '
                        'TO SAY PLEASE.', numero, 1))
                    conditions = 0
        if blocs_affectation > 0:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                '%d bloc(s) d\'affectation jamais refermé(s) par ENOUGH TALK.'
                % blocs_affectation, 1, 1))
        if boucles > 0:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                '%d boucle(s) jamais refermée(s) par CHILL.' % boucles, 1, 1))
        if conditions > 0:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                '%d condition(s) jamais refermée(s).' % conditions, 1, 1))
        if not vu_debut:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Programme sans IT\'S SHOWTIME.', 1, 1))
        if vu_debut and not vu_fin:
            # Avertissement et non erreur : le programme s'exécute quand même,
            # il s'arrête en fin de fichier. C'est une omission fréquente.
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS,
                'Programme sans YOU HAVE BEEN TERMINATED : il s\'arrêtera en '
                'fin de fichier.', 1, 1))
        if methode_courante is not None:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Méthode « %s » jamais terminée par HASTA LA VISTA, BABY.'
                % methode_courante['nom'], methode_courante['ligne'], 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    # -- exécution -----------------------------------------------------------
    def _valeur(self, operande, ligne):
        genre, contenu = self._operateur(operande)
        if genre == 'nombre' or genre == 'texte':
            return contenu, None
        if genre == 'variable':
            if contenu not in self.valeurs:
                return None, 'Variable « %s » jamais déclarée par HEY CHRISTMAS TREE.' % contenu
            return self.valeurs[contenu], None
        return None, 'Opérande invalide : « %s ».' % operande

    def pas(self):
        if self.termine:
            return False
        if not self._instructions and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        instructions = self.pile_appels[-1]['corps'] if self.pile_appels \
            else self._instructions
        if self.index_courant >= len(instructions):
            if self.pile_appels:
                # Fin du corps sans I'LL BE BACK : retour au point d'appel.
                cadre = self.pile_appels.pop()
                if cadre['cible'] and cadre.get('valeur') is not None:
                    self.valeurs[cadre['cible']] = cadre['valeur']
                self._pile_blocs = cadre.get('blocs', [])
                self.index_courant = cadre['retour']
                return True
            self.termine = True
            return False
        self.pas_fait += 1
        ordre, reste, ligne = instructions[self.index_courant]
        self._ligne_courante = ligne
        self.index_courant += 1
        return self._executer(ordre, reste, ligne)

    def _echec(self, message, ligne):
        self.diagnostiques.append(_diagnostic(SEVERITE_ERREUR, message, ligne, 1))
        self.message = message
        self.termine = True
        self.arret_anormal = True
        return False

    def _executer(self, ordre, reste, ligne):
        if ordre in ('debut', 'declarer', 'parametre'):
            if ordre == 'declarer':
                nom = reste.split()[0] if reste else ''
                if nom:
                    self.valeurs.setdefault(nom, 0)
                    # YOU SET US UP, sur la ligne suivante, vise cette variable.
                    self._cible = nom
            return True
        if ordre == 'fin':
            self.termine = True
            return False
        if ordre == 'valeur_initiale':
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            if self._cible:
                self.valeurs[self._cible] = valeur
            return True
        if ordre == 'imprimer':
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            self._ecrire(str(valeur))
            return True
        if ordre == 'lire':
            nom = reste.split()[0] if reste else ''
            nombre = self.entree.nombre()
            if nombre is None:
                return self._echec('Plus aucun entier à lire en entrée.', ligne)
            self.valeurs[nom] = nombre
            return True
        if ordre == 'affecter':
            self._cible = reste.split()[0] if reste else ''
            if self._cible not in self.valeurs:
                return self._echec(
                    'Variable « %s » jamais déclarée par HEY CHRISTMAS TREE.'
                    % self._cible, ligne)
            self._accumulateur = None
            return True
        if ordre == 'poser':
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            self._accumulateur = valeur
            return True
        if ordre == 'fin_affectation':
            if getattr(self, '_cible', None) is None:
                return self._echec('ENOUGH TALK hors d\'un bloc d\'affectation.', ligne)
            self.valeurs[self._cible] = self._accumulateur
            self._cible = None
            return True
        if ordre in ('ajouter', 'soustraire', 'multiplier', 'diviser', 'modulo',
                     'egal', 'superieur', 'ou', 'et'):
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            if not isinstance(valeur, int):
                return self._echec(
                    'Opération arithmétique sur le texte « %s ».' % valeur, ligne)
            gauche = self._accumulateur
            if not isinstance(gauche, int):
                return self._echec(
                    'Opération « %s » sans valeur à gauche.' % ordre, ligne)
            if ordre == 'ajouter':
                resultat = gauche + valeur
            elif ordre == 'soustraire':
                resultat = gauche - valeur
            elif ordre == 'multiplier':
                resultat = borne(gauche * valeur, 'le résultat')
            elif ordre == 'diviser':
                if valeur == 0:
                    return self._echec('Division par zéro.', ligne)
                resultat = int(gauche / valeur)
            elif ordre == 'modulo':
                if valeur == 0:
                    return self._echec('Modulo par zéro.', ligne)
                resultat = gauche % valeur
            elif ordre == 'egal':
                resultat = 1 if gauche == valeur else 0
            elif ordre == 'superieur':
                resultat = 1 if gauche > valeur else 0
            elif ordre == 'ou':
                resultat = 1 if (gauche or valeur) else 0
            else:
                resultat = 1 if (gauche and valeur) else 0
            self._accumulateur = resultat
            return True
        if ordre == 'tantque':
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            if not valeur:
                self.index_courant = self._saut_apparie(
                    'tantque', 'fin_tantque', ligne)
            else:
                self._pile_blocs.append(('tantque', self.index_courant - 1, ligne))
            return True
        if ordre == 'fin_tantque':
            if not self._pile_blocs:
                return self._echec('CHILL sans STICK AROUND.', ligne)
            _genre, depart, _ligne = self._pile_blocs.pop()
            self.index_courant = depart
            return True
        if ordre == 'si':
            valeur, erreur = self._valeur(reste, ligne)
            if erreur:
                return self._echec(erreur, ligne)
            if valeur:
                self._pile_blocs.append(('si', self.index_courant - 1, ligne))
            else:
                self.index_courant = self._saut_vers_sinon_ou_fin(ligne)
            return True
        if ordre == 'sinon':
            if not self._pile_blocs:
                return self._echec('BULLSHIT sans BECAUSE I\'M GOING TO SAY PLEASE.',
                                   ligne)
            self._pile_blocs.pop()
            self.index_courant = self._saut_apparie('si', 'fin_si', ligne,
                                                    depuis='sinon')
            return True
        if ordre == 'fin_si':
            if self._pile_blocs and self._pile_blocs[-1][0] == 'si':
                self._pile_blocs.pop()
            return True
        if ordre == 'retourner':
            valeur, erreur = self._valeur(reste, ligne) if reste else (None, None)
            if erreur:
                return self._echec(erreur, ligne)
            if self.pile_appels:
                self.pile_appels[-1]['valeur'] = valeur
            if self.pile_appels:
                cadre = self.pile_appels.pop()
                if cadre['cible']:
                    self.valeurs[cadre['cible']] = valeur
                self._pile_blocs = cadre.get('blocs', [])
                self.index_courant = cadre['retour']
            return True
        if ordre in ('appeler', 'appeler_affecter'):
            return self._appel(ordre, reste, ligne)
        return self._echec('Commande non prise en charge : « %s ».' % ordre, ligne)

    def _appel(self, ordre, reste, ligne):
        cible = None
        mots = reste.split()
        if ordre == 'appeler_affecter':
            if not mots:
                return self._echec('GET YOUR ASS TO MARS sans variable cible.', ligne)
            cible = mots[0]
            mots = mots[1:]
        if not mots:
            return self._echec('Appel de méthode sans nom.', ligne)
        nom = mots[0]
        if nom not in self._methodes:
            return self._echec('Méthode « %s » jamais déclarée.' % nom, ligne)
        methode = self._methodes[nom]
        attendus = methode['parametres']
        fournis = mots[1:]
        if len(fournis) != len(attendus):
            return self._echec(
                'La méthode « %s » attend %d paramètre(s), %d fourni(s).'
                % (nom, len(attendus), len(fournis)), ligne)
        sauvegarde = dict(self.valeurs)
        for parametre, operande in zip(attendus, fournis):
            valeur, erreur = self._valeur(operande, ligne)
            if erreur:
                self.valeurs = sauvegarde
                return self._echec(erreur, ligne)
            self.valeurs[parametre] = valeur
        self.pile_appels.append({'retour': self.index_courant, 'cible': cible,
                                 'sauvegarde': sauvegarde, 'valeur': None,
                                 'corps': methode['corps'], 'nom': nom,
                                 'blocs': list(self._pile_blocs)})
        self._pile_blocs = []
        self.index_courant = 0
        return True

    def _saut_apparie(self, ouvrant, fermant, ligne, depuis=None):
        """Cherche le fermant apparié, en respectant l'imbrication."""
        corps = self.pile_appels[-1]['corps'] if self.pile_appels \
            else self._instructions
        profondeur = 0
        debut = self.index_courant
        for position in range(debut, len(corps)):
            ordre = corps[position][0]
            if ordre == ouvrant:
                profondeur += 1
            elif ordre == fermant:
                if profondeur == 0:
                    return position + 1
                profondeur -= 1
        return len(corps)

    def _saut_vers_sinon_ou_fin(self, ligne):
        corps = self.pile_appels[-1]['corps'] if self.pile_appels \
            else self._instructions
        profondeur = 0
        for position in range(self.index_courant, len(corps)):
            ordre = corps[position][0]
            if ordre == 'si':
                profondeur += 1
            elif ordre == 'sinon' and profondeur == 0:
                return position + 1
            elif ordre == 'fin_si':
                if profondeur == 0:
                    return position + 1
                profondeur -= 1
        return len(corps)

    @property
    def position(self):
        return (getattr(self, '_ligne_courante', 1), 1)

    def variables(self):
        retour = [{'name': nom, 'value': _texte_entier(valeur)}
                  for nom, valeur in sorted(self.valeurs.items())][:30]
        retour.append({'name': 'méthodes déclarées',
                       'value': ', '.join(sorted(self._methodes)) or 'aucune'})
        retour.append({'name': 'appels en cours', 'value': str(len(self.pile_appels))})
        return retour

    def frames(self):
        ligne = getattr(self, '_ligne_courante', 1)
        cadres = [{'file': self.chemin, 'line': ligne,
                   'function': 'principal', 'level': 0}]
        for niveau, cadre in enumerate(reversed(self.pile_appels), start=1):
            cadres.append({'file': self.chemin, 'line': cadre['retour'],
                           'function': 'méthode', 'level': niveau})
        return cadres


# =========================================================================
# LOLCODE
# =========================================================================
TYPES_LOL = ('NOOB', 'TROOF', 'NUMBR', 'NUMBAR', 'YARN', 'BUKKIT')
# Opérateurs binaires, écrits sous forme préfixée : « SUM OF a AN b ».
BINAIRES_LOL = {
    'SUM OF': '+', 'DIFF OF': '-', 'PRODUKT OF': '*', 'QUOSHUNT OF': '/',
    'MOD OF': '%', 'BIGGR OF': 'max', 'SMALLR OF': 'min',
    'BOTH SAEM': '==', 'DIFFRINT': '!=',
}
DEFAUTS_LOL = {'NOOB': None, 'TROOF': False, 'NUMBR': 0, 'NUMBAR': 0.0,
               'YARN': '', 'BUKKIT': None}


def _decouper_lol(texte):
    """Découpe en jetons en gardant les YARN entre guillemets d'un seul bloc."""
    jetons = []
    tampon = ''
    dans_chaine = False
    i = 0
    while i < len(texte):
        c = texte[i]
        if dans_chaine:
            if c == '\\' and i + 1 < len(texte):
                tampon += c + texte[i + 1]
                i += 2
                continue
            if c == '"':
                tampon += c
                dans_chaine = False
            else:
                tampon += c
        elif c == '"':
            if tampon.strip():
                jetons.append(tampon.strip())
            tampon = '"'
            dans_chaine = True
        elif c in ' \t':
            if tampon.strip():
                jetons.append(tampon.strip())
            tampon = ''
        else:
            tampon += c
        i += 1
    if tampon.strip():
        jetons.append(tampon.strip())
    if dans_chaine:
        jetons.append('@@CHAINE_NON_FERMEE@@')
    return jetons


class Lolcode(Moteur):
    """Le pidgin lolcat : une syntaxe bavarde pour un langage procédural.

    Les valeurs sont typées (NOOB, TROOF, NUMBR, NUMBAR, YARN) et les
    conversions sont implicites selon la spécification. Les structures de
    contrôle s'écrivent « O RLY? / YA RLY / NO WAI / OIC » et
    « IM IN YR / IM OUTTA YR ». Les BUKKIT (tableaux et objets) ne sont pas
    pris en charge et produisent un diagnostic explicite.
    """

    langage = 'lolcode'
    libelle = 'LOLCODE'
    extension = '.lol'

    def __init__(self, code, entree='', chemin=None):
        super(Lolcode, self).__init__(code, entree, chemin)
        self.valeurs = {}
        self.index_courant = 0
        self._instructions = []
        self._fonctions = {}
        self.pile_appels = []
        self._ligne_courante = 1
        self._pile_boucles = []
        self._retour = None
        self._types = {}

    # -- valeurs -------------------------------------------------------------
    @staticmethod
    def _en_chaine(valeur):
        if valeur is None:
            return ''
        if valeur is True:
            return 'WIN'
        if valeur is False:
            return 'FAIL'
        if isinstance(valeur, bool):
            return 'WIN' if valeur else 'FAIL'
        if isinstance(valeur, float):
            # La spécification tronque à deux décimales PAR DÉFAUT : 3.5 reste
            # « 3.5 » et 3.456 devient « 3.45 », pas « 3.50 ».
            return ('%.2f' % valeur).rstrip('0').rstrip('.') or '0'
        return str(valeur)

    @staticmethod
    def _vrai(valeur):
        if valeur is None:
            return False
        if isinstance(valeur, bool):
            return valeur
        if isinstance(valeur, (int, float)):
            return valeur != 0
        if isinstance(valeur, str):
            return valeur != ''
        return True

    @staticmethod
    def _en_nombre(valeur):
        if valeur is None:
            return 0
        if isinstance(valeur, bool):
            return 1 if valeur else 0
        if isinstance(valeur, (int, float)):
            return valeur
        texte = valeur.strip()
        try:
            return int(texte)
        except ValueError:
            pass
        try:
            return float(texte)
        except ValueError:
            return None

    def _convertir(self, valeur, genre):
        if genre == 'NOOB':
            return None
        if genre == 'TROOF':
            # La spécification : une chaîne vide et le zéro numérique donnent
            # FAIL ; toute autre valeur donne WIN. « 0 » doit donc être FAIL.
            if isinstance(valeur, str):
                texte = valeur.strip()
                if texte == '':
                    return False
                nombre = self._en_nombre(texte)
                if nombre is not None:
                    return nombre != 0
                return True
            return self._vrai(valeur)
        if genre == 'NUMBR':
            nombre = self._en_nombre(valeur)
            return None if nombre is None else int(nombre)
        if genre == 'NUMBAR':
            nombre = self._en_nombre(valeur)
            return None if nombre is None else float(nombre)
        if genre == 'YARN':
            return self._en_chaine(valeur)
        return valeur

    def _yarn(self, texte, ligne):
        """Développe les séquences d'échappement : :) :> :O :" :: :( :(hex) :{var}."""
        corps = texte[1:-1]
        sortie = []
        i = 0
        while i < len(corps):
            c = corps[i]
            if c == ':' and i + 1 < len(corps):
                suivant = corps[i + 1]
                if suivant == ')':
                    sortie.append('\n'); i += 2; continue
                if suivant == '>':
                    sortie.append('\t'); i += 2; continue
                if suivant == 'O':
                    sortie.append('\a'); i += 2; continue
                if suivant == '"':
                    sortie.append('"'); i += 2; continue
                if suivant == ':':
                    sortie.append(':'); i += 2; continue
                if suivant == '(':
                    fin = corps.find(')', i)
                    if fin < 0:
                        self.diagnostiques.append(_diagnostic(
                            SEVERITE_ERREUR,
                            'Séquence :( sans parenthèse fermante dans le YARN.',
                            ligne, 1))
                        sortie.append(':('); i += 2; continue
                    try:
                        sortie.append(chr(int(corps[i + 2:fin], 16)))
                    except ValueError:
                        self.diagnostiques.append(_diagnostic(
                            SEVERITE_ERREUR,
                            ':(%s) n\'est pas un nombre hexadécimal valide.'
                            % corps[i + 2:fin], ligne, 1))
                    i = fin + 1
                    continue
                if suivant == '{':
                    fin = corps.find('}', i)
                    if fin > 0:
                        nom = corps[i + 2:fin]
                        sortie.append(self._en_chaine(self.valeurs.get(nom)))
                        i = fin + 1
                        continue
            sortie.append(c)
            i += 1
        return ''.join(sortie)

    # -- chargement ----------------------------------------------------------
    def charger(self):
        self._instructions = []
        self._fonctions = {}
        diagnostics = []
        lignes = self.code.split('\n')
        i = 0
        pile = []          # (genre, index, ligne)
        dans_commentaire = False
        fonction = None
        while i < len(lignes):
            numero = i + 1
            i += 1
            brut = lignes[i - 1]
            if dans_commentaire:
                if 'TLDR' in brut.upper():
                    dans_commentaire = False
                continue
            majuscule = brut.upper()
            if 'OBTW' in majuscule:
                if 'TLDR' not in majuscule[majuscule.index('OBTW') + 4:]:
                    dans_commentaire = True
                continue
            if 'BTW' in majuscule:
                brut = brut[:majuscule.index('BTW')]
                if not brut.strip():
                    continue
            propre = brut.strip()
            if not propre:
                continue
            cible = self._instructions if fonction is None else fonction['corps']
            haut = propre.upper()

            if haut.startswith('HAI'):
                cible.append(('hai', numero))
            elif haut == 'KTHXBYE':
                cible.append(('kthxbye', numero))
            elif haut.startswith('CAN HAS'):
                cible.append(('canhas', numero))
            elif haut.startswith('HOW IZ I '):
                reste = propre[len('HOW IZ I '):]
                nom = reste.split()[0]
                parametres = [m for m in reste.split(' YR ')[1:]]
                parametres = [p.replace('AN YR', ' ').strip() for p in parametres]
                parametres = [x for p in parametres for x in p.split() if x
                              and x.upper() != 'AN']
                fonction = {'nom': nom, 'parametres': parametres, 'corps': [],
                            'ligne': numero}
                self._fonctions[nom] = fonction
                pile.append(('fonction', len(pile), numero))
            elif haut == 'IF U SAY SO':
                if fonction is None:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'IF U SAY SO sans HOW IZ I.', numero, 1))
                fonction = None
            elif haut.endswith(', O RLY?'):
                jetons = _decouper_lol(propre[:-len(', O RLY?')])
                index = len(cible)
                cible.append(('si', jetons, None, None, numero))
                pile.append(('si', index, numero))
            elif haut == 'YA RLY' or haut.startswith('YA RLY,'):
                if not pile or pile[-1][0] != 'si':
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'YA RLY sans O RLY?.', numero, 1))
                else:
                    # YA RLY introduit la branche VRAIE : on y entre en tombant
                    # dedans. Seul NO WAI doit sauter.
                    cible.append(('marqueur', numero))
            elif haut == 'NO WAI' or haut.startswith('NO WAI,'):
                if not pile or pile[-1][0] != 'si':
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'NO WAI sans O RLY?.', numero, 1))
                else:
                    cible.append(('sinon', None, numero))
            elif haut.endswith(', WTF?'):
                jetons = _decouper_lol(propre[:-len(', WTF?')])
                index = len(cible)
                cible.append(('wtf', jetons, None, None, numero))
                pile.append(('wtf', index, numero))
            elif haut.startswith('OMGWTF'):
                cible.append(('omgwtf', numero))
            elif haut.startswith('OMG '):
                valeur = propre[4:].strip()
                cible.append(('omg', valeur, numero))
            elif haut == 'GTFO':
                cible.append(('gtfo', numero))
            elif haut == 'OIC':
                if not pile or pile[-1][0] not in ('si', 'wtf'):
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'OIC sans bloc ouvert.', numero, 1))
                else:
                    genre, index, _ligne = pile.pop()
                    fin = len(cible)
                    if genre == 'si':
                        self._resoudre_si(cible, index, fin)
                    else:
                        self._resoudre_wtf(cible, index, fin)
                    cible.append(('oic', numero))
            elif haut.startswith('IM IN YR'):
                reste = propre[len('IM IN YR'):].strip()
                index = len(cible)
                cible.append(('boucle', reste, None, numero))
                pile.append(('boucle', index, numero))
            elif haut.startswith('IM OUTTA YR'):
                etiquette = haut[len('IM OUTTA YR'):].strip()
                ouverte = None
                for position in range(len(pile) - 1, -1, -1):
                    if pile[position][0] == 'boucle':
                        ouverte = pile[position]
                        del pile[position:]
                        break
                if ouverte is None:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR, 'IM OUTTA YR sans IM IN YR.', numero, 1))
                else:
                    index = ouverte[1]
                    ordre, reste, _saut, ligne = cible[index]
                    # len(cible) est la place qu'occupera fin_boucle : la sortie
                    # de boucle est donc la case suivante.
                    cible[index] = (ordre, reste, len(cible) + 1, ligne)
                    if etiquette and reste.split()[0].upper() != etiquette:
                        diagnostics.append(_diagnostic(
                            SEVERITE_AVIS,
                            'IM OUTTA YR %s ferme la boucle IM IN YR %s.'
                            % (etiquette, reste.split()[0]), numero, 1))
                    cible.append(('fin_boucle', index, numero))
            elif haut.startswith('FOUND YR'):
                cible.append(('found', _decouper_lol(propre[8:]), numero))
            elif haut.startswith('I IZ ') or (haut.startswith('GIMMEH ')):
                if haut.startswith('GIMMEH '):
                    cible.append(('gimmeh', propre[7:].strip(), numero))
                else:
                    cible.append(('expr', _decouper_lol(propre), numero))
            elif haut.startswith('VISIBLE'):
                # Un « ! » final SUPPRIME le retour à la ligne, mais seulement
                # s'il est hors d'un YARN. Un nombre pair de guillemets avant
                # lui signifie qu'on est à l'extérieur de toute chaîne.
                sans_retour = propre.endswith('!') \
                    and propre.count('"') % 2 == 0
                corps = propre[7:].strip()
                if sans_retour:
                    corps = corps[:-1].strip()
                cible.append(('visible', _decouper_lol(corps), sans_retour, numero))
            elif haut.startswith('I HAS A '):
                cible.append(('declarer', propre[8:].strip(), numero))
            elif ' IS NOW A ' in haut:
                avant, _x, apres = propre.partition(' IS NOW A ')
                cible.append(('caster', avant.strip(), apres.strip().upper(), numero))
            elif ' R ' in haut:
                avant, _x, apres = propre.partition(' R ')
                cible.append(('assigner', avant.strip(),
                              _decouper_lol(apres.strip()), numero))
            else:
                cible.append(('expr', _decouper_lol(propre), numero))
                diagnostics.append(_diagnostic(
                    SEVERITE_AVIS,
                    'Ligne interprétée comme une expression : « %s ».'
                    % propre[:60], numero, 1))
        if dans_commentaire:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Commentaire OBTW jamais terminé par TLDR.', 1, 1))
        for genre, index, ligne in pile:
            if genre == 'boucle':
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Boucle IM IN YR ouverte ligne %d sans IM OUTTA YR.' % ligne,
                    ligne, 1))
            elif genre in ('si', 'wtf'):
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Bloc ouvert ligne %d sans OIC.' % ligne, ligne, 1))
        if fonction is not None:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Fonction « %s » jamais terminée par IF U SAY SO.'
                % fonction['nom'], fonction['ligne'], 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    def _resoudre_si(self, cible, index, fin):
        """Renseigne le saut « sinon » et le saut « fin » d'un bloc O RLY?."""
        sinon = None
        for position in range(index + 1, fin):
            if cible[position][0] == 'sinon':
                sinon = position
                break
        ordre, jetons, _s, _f, ligne = cible[index]
        # « sinon » est l'indice du marqueur NO WAI : la branche alternative
        # commence juste après.
        cible[index] = (ordre, jetons,
                        sinon + 1 if sinon is not None else fin, fin, ligne)
        if sinon is not None:
            _o, _v, _l = cible[sinon]
            cible[sinon] = ('sinon', fin, _l)

    def _resoudre_wtf(self, cible, index, fin):
        cas = []
        defaut = fin
        for position in range(index + 1, fin):
            ordre = cible[position][0]
            if ordre == 'omg':
                cas.append((cible[position][1], position + 1))
            elif ordre == 'omgwtf':
                defaut = position + 1   # on tombe dans le bloc par défaut
        _o, jetons, _c, _d, ligne = cible[index]
        cible[index] = ('wtf', jetons, cas, defaut, ligne)

    # -- expressions ---------------------------------------------------------
    def _evaluer(self, jetons, ligne, index=0):
        if index >= len(jetons):
            return None, index
        # Les opérateurs s'écrivent en un, deux ou trois mots (« DIFFRINT »,
        # « SUM OF », « YOU ARE NOT... ») : on essaie du plus long au plus court.
        for longueur in (3, 2, 1):
            cle = ' '.join(jetons[index:index + longueur]).upper()
            if cle in BINAIRES_LOL:
                gauche, suivant = self._evaluer(jetons, ligne, index + longueur)
                if suivant < len(jetons) and jetons[suivant].upper() == 'AN':
                    suivant += 1
                elif suivant < len(jetons) and jetons[suivant] == ',':
                    suivant += 1
                droite, suivant = self._evaluer(jetons, ligne, suivant)
                return self._operer(BINAIRES_LOL[cle], gauche, droite, ligne), suivant
        haut = jetons[index].upper()
        if haut == 'MAEK':
            reste = jetons[index + 1:]
            if len(reste) >= 2 and reste[-2].upper() == 'A':
                genre = reste[-1].upper()
                if genre not in DEFAUTS_LOL:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'MAEK vers un type inconnu : « %s ».' % genre, ligne, 1))
                    return None, len(jetons)
                valeur, _x = self._evaluer(reste[:-2], ligne, 0)
                return self._convertir(valeur, genre), len(jetons)
        if haut == 'NOT':
            valeur, suivant = self._evaluer(jetons, ligne, index + 1)
            return not self._vrai(valeur), suivant
        if haut == 'SMOOSH':
            morceaux = []
            position = index + 1
            while position < len(jetons):
                if jetons[position].upper() in ('AN', 'MKAY', ','):
                    position += 1
                    continue
                valeur, position = self._evaluer(jetons, ligne, position)
                morceaux.append(self._en_chaine(valeur))
            return ''.join(morceaux), len(jetons)
        if haut == 'I' and index + 1 < len(jetons) \
                and jetons[index + 1].upper() == 'IZ':
            return self._appel_fonction(jetons, index + 2, ligne)
        return self._atome(jetons, index, ligne)

    def _atome(self, jetons, index, ligne):
        jeton = jetons[index]
        if jeton == '@@CHAINE_NON_FERMEE@@':
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR, 'YARN sans guillemet fermant.', ligne, 1))
            return '', index + 1
        if jeton.startswith('"') and jeton.endswith('"') and len(jeton) >= 2:
            return self._yarn(jeton, ligne), index + 1
        haut = jeton.upper()
        if haut == 'WIN':
            return True, index + 1
        if haut == 'FAIL':
            return False, index + 1
        if haut == 'NOOB':
            return None, index + 1
        try:
            return int(jeton), index + 1
        except ValueError:
            pass
        try:
            return float(jeton), index + 1
        except ValueError:
            pass
        if jeton in self.valeurs:
            return self.valeurs[jeton], index + 1
        # Une variable non déclarée vaut NOOB, comme dans l'implémentation lci.
        return None, index + 1

    def _operer(self, operation, gauche, droite, ligne):
        if operation in ('==', '!='):
            egal = self._egaux(gauche, droite)
            return egal if operation == '==' else not egal
        if operation in ('max', 'min'):
            a, b = self._en_nombre(gauche), self._en_nombre(droite)
            if a is None or b is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR, 'Comparaison de valeurs non numériques.',
                    ligne, 1))
                return gauche
            return max(a, b) if operation == 'max' else min(a, b)
        a = self._en_nombre(gauche)
        b = self._en_nombre(droite)
        if a is None or b is None:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                'Opération arithmétique sur une valeur non numérique.', ligne, 1))
            return 0
        reel = isinstance(a, float) or isinstance(b, float)
        if operation == '/':
            if b == 0:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR, 'Division par zéro (QUOSHUNT OF).', ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return 0
            resultat = a / b
            return resultat if reel else int(resultat)
        if operation == '%':
            if b == 0:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR, 'Modulo par zéro (MOD OF).', ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return 0
            return a % b
        if operation == '+':
            return a + b
        if operation == '-':
            return a - b
        return borne(a * b, 'le résultat')

    def _egaux(self, gauche, droite):
        if isinstance(gauche, bool) or isinstance(droite, bool):
            return self._vrai(gauche) == self._vrai(droite)
        if gauche is None or droite is None:
            return gauche is None and droite is None
        if isinstance(gauche, str) and isinstance(droite, str):
            return gauche == droite
        if isinstance(gauche, str) or isinstance(droite, str):
            return self._en_chaine(gauche) == self._en_chaine(droite)
        return gauche == droite

    def _appel_fonction(self, jetons, index, ligne):
        nom = jetons[index]
        arguments = []
        position = index + 1
        while position < len(jetons):
            if jetons[position].upper() in ('YR', 'AN', 'MKAY'):
                position += 1
                continue
            valeur, position = self._evaluer(jetons, ligne, position)
            arguments.append(valeur)
        if nom not in self._fonctions:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR, 'Fonction « %s » jamais déclarée par HOW IZ I.'
                % nom, ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None, len(jetons)
        fonction = self._fonctions[nom]
        if len(arguments) != len(fonction['parametres']):
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                'La fonction « %s » attend %d argument(s), %d fourni(s).'
                % (nom, len(fonction['parametres']), len(arguments)), ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None, len(jetons)
        if len(self.pile_appels) >= 200:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                'Récursion trop profonde (plus de 200 appels imbriqués).',
                ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None, len(jetons)
        sauves = {p: self.valeurs.get(p, '@@ABSENT@@')
                  for p in fonction['parametres']}
        for parametre, valeur in zip(fonction['parametres'], arguments):
            self.valeurs[parametre] = valeur
        profondeur = len(self.pile_appels)
        self.pile_appels.append({'retour': self.index_courant, 'sauves': sauves,
                                 'corps': fonction['corps'], 'nom': nom,
                                 'valeur': None})
        self.index_courant = 0
        self._retour = None
        # Exécution synchrone du corps : l'appelant attend la valeur, il ne peut
        # donc pas être suspendu puis repris.
        while len(self.pile_appels) > profondeur and not self.termine \
                and self.pas_fait < LIMITE_PAS:
            corps = self.pile_appels[-1]['corps']
            if self.index_courant >= len(corps):
                self._revenir()
                continue
            instruction = corps[self.index_courant]
            self.index_courant += 1
            self.pas_fait += 1
            self._executer(instruction)
        return self._retour, len(jetons)

    # -- exécution -----------------------------------------------------------
    def pas(self):
        if self.termine:
            return False
        if not self._instructions and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        instructions = self.pile_appels[-1]['corps'] if self.pile_appels \
            else self._instructions
        if self.index_courant >= len(instructions):
            if self.pile_appels:
                self._revenir()
                return True
            self.termine = True
            return False
        self.pas_fait += 1
        instruction = instructions[self.index_courant]
        self.index_courant += 1
        return self._executer(instruction)

    def _revenir(self):
        cadre = self.pile_appels.pop()
        self._retour = cadre.get('valeur')
        for nom, valeur in cadre['sauves'].items():
            if valeur == '@@ABSENT@@':
                self.valeurs.pop(nom, None)
            else:
                self.valeurs[nom] = valeur
        self.index_courant = cadre['retour']

    def _executer(self, instruction):
        ordre = instruction[0]
        ligne = instruction[-1]
        self._ligne_courante = ligne
        if ordre in ('hai', 'canhas', 'oic', 'marqueur'):
            return True
        if ordre == 'kthxbye':
            self.termine = True
            return False
        if ordre == 'visible':
            jetons, sans_retour = instruction[1], instruction[2]
            morceaux = []
            position = 0
            while position < len(jetons):
                if jetons[position] == ',':
                    position += 1
                    continue
                valeur, position = self._evaluer(jetons, ligne, position)
                morceaux.append(self._en_chaine(valeur))
            self._ecrire(''.join(morceaux) + ('' if sans_retour else '\n'))
            return True
        if ordre == 'gimmeh':
            nom = instruction[1]
            texte = self.entree.ligne()
            if texte is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'GIMMEH %s : plus aucune ligne à lire en entrée.' % nom,
                    ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return False
            genre = self._types.get(nom)
            self.valeurs[nom] = self._convertir(texte, genre) \
                if genre else texte
            return True
        if ordre == 'declarer':
            reste = instruction[1]
            if ' ITZ LIEK A ' in reste.upper():
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Les BUKKIT ne sont pas pris en charge : « %s ».' % reste[:60],
                    ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return False
            if ' ITZ A ' in reste.upper():
                nom, _x, genre = reste.partition(' ITZ A ')
                genre = genre.strip().upper()
                if genre == 'BUKKIT':
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'Les BUKKIT (tableaux et objets) ne sont pas pris en '
                        'charge par ce moteur : « %s ».' % reste[:60], ligne, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return False
                if genre not in DEFAUTS_LOL:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR, 'Type inconnu : « %s ».' % genre, ligne, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return False
                self.valeurs[nom.strip()] = dict(DEFAUTS_LOL)[genre]
                self._types[nom.strip()] = genre
                return True
            if ' ITZ ' in reste.upper():
                position = reste.upper().index(' ITZ ')
                nom = reste[:position].strip()
                jetons = _decouper_lol(reste[position + 5:].strip())
                valeur, _x = self._evaluer(jetons, ligne, 0)
                self.valeurs[nom] = valeur
                return True
            self.valeurs[reste.strip()] = None
            return True
        if ordre == 'caster':
            nom, genre = instruction[1], instruction[2]
            if genre not in DEFAUTS_LOL:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR, 'Type inconnu : « %s ».' % genre, ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return False
            self.valeurs[nom] = self._convertir(self.valeurs.get(nom), genre)
            return True
        if ordre == 'assigner':
            nom, jetons = instruction[1], instruction[2]
            valeur, _x = self._evaluer(jetons, ligne, 0)
            self.valeurs[nom] = valeur
            return True
        if ordre == 'si':
            valeur, _x = self._evaluer(instruction[1], ligne, 0)
            if not self._vrai(valeur) and instruction[2] is not None:
                self.index_courant = instruction[2]
            return True
        if ordre == 'sinon':
            self.index_courant = instruction[1]
            return True
        if ordre == 'wtf':
            valeur, _x = self._evaluer(instruction[1], ligne, 0)
            for littéral, saut in instruction[2]:
                if self._egaux(valeur, self._litteral_omg(littéral, ligne)):
                    self.index_courant = saut
                    return True
            self.index_courant = instruction[3]
            return True
        if ordre == 'omg' or ordre == 'omgwtf':
            return True
        if ordre == 'gtfo':
            # GTFO sort de la boucle la plus interne ; hors d'une boucle, dans
            # une fonction, il revient sans valeur (NOOB).
            if self._pile_boucles:
                self.index_courant = self._pile_boucles.pop()[4]
                return True
            if self.pile_appels:
                self.pile_appels[-1]['valeur'] = None
                self._revenir()
                return True
            self.termine = True
            return False
        if ordre == 'found':
            valeur, _x = self._evaluer(instruction[1], ligne, 0)
            if self.pile_appels:
                self.pile_appels[-1]['valeur'] = valeur
                self._revenir()
            return True
        if ordre == 'boucle':
            reste, saut = instruction[1], instruction[2]
            mots = reste.split()
            sens = variable = condition = None
            jetons_condition = []
            for position, mot in enumerate(mots):
                haut = mot.upper()
                if haut in ('UPPIN', 'NERFIN') and position + 2 < len(mots):
                    sens = haut
                    variable = mots[position + 2]
                elif haut in ('TIL', 'WILE'):
                    condition = haut
                    jetons_condition = mots[position + 1:]
            # La pile porte tout l'état de la boucle : une boucle imbriquée ne
            # peut donc pas écraser celle qui l'entoure.
            if sens and variable and variable not in self.valeurs:
                # La spécification compte « de 0 à 9 » sans déclarer var :
                # un compteur de boucle non déclaré démarre donc à 0.
                self.valeurs[variable] = 0
            self._pile_boucles.append((sens, variable, condition,
                                       jetons_condition, saut,
                                       self.index_courant))
            if condition:
                valeur, _x = self._evaluer(jetons_condition, ligne, 0)
                if self._arreter_boucle(condition, valeur):
                    self._pile_boucles.pop()
                    self.index_courant = saut
            return True
        if ordre == 'fin_boucle':
            if not self._pile_boucles:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR, 'IM OUTTA YR sans boucle ouverte.', ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return False
            sens, variable, condition, jetons_condition, saut, corps = \
                self._pile_boucles[-1]
            if sens and variable:
                nombre = self._en_nombre(self.valeurs.get(variable))
                nombre = 0 if nombre is None else nombre
                self.valeurs[variable] = nombre + 1 if sens == 'UPPIN' \
                    else nombre - 1
            if condition:
                valeur, _x = self._evaluer(jetons_condition, ligne, 0)
                if self._arreter_boucle(condition, valeur):
                    self._pile_boucles.pop()
                    return True
                self.index_courant = corps
                return True
            # Boucle sans condition : elle tourne jusqu'à GTFO.
            self.index_courant = corps
            return True
        if ordre == 'expr':
            valeur, _x = self._evaluer(instruction[1], ligne, 0)
            return True
        self.diagnostiques.append(_diagnostic(
            SEVERITE_ERREUR, 'Instruction interne inconnue : « %s ».' % ordre,
            ligne, 1))
        self.termine = True
        self.arret_anormal = True
        return False

    @staticmethod
    def _arreter_boucle(condition, valeur):
        """TIL s'arrête quand l'expression vaut WIN, WILE quand elle vaut FAIL."""
        vrai = Lolcode._vrai(valeur)
        return vrai if condition == 'TIL' else not vrai

    def _litteral_omg(self, texte, ligne):
        texte = texte.strip()
        if texte.startswith('"') and texte.endswith('"'):
            return self._yarn(texte, ligne)
        haut = texte.upper()
        if haut == 'WIN':
            return True
        if haut == 'FAIL':
            return False
        try:
            return int(texte)
        except ValueError:
            pass
        try:
            return float(texte)
        except ValueError:
            return texte

    @property
    def position(self):
        return (self._ligne_courante, 1)

    def variables(self):
        retour = [{'name': nom, 'value': self._en_chaine(valeur)}
                  for nom, valeur in sorted(self.valeurs.items())][:30]
        retour.append({'name': 'fonctions',
                       'value': ', '.join(sorted(self._fonctions)) or 'aucune'})
        retour.append({'name': 'profondeur d\'appels',
                       'value': str(len(self.pile_appels))})
        return retour

    def frames(self):
        cadres = [{'file': self.chemin, 'line': self._ligne_courante,
                   'function': 'principal', 'level': 0}]
        for niveau, cadre in enumerate(reversed(self.pile_appels), start=1):
            cadres.append({'file': self.chemin, 'line': cadre['retour'],
                           'function': cadre['nom'], 'level': niveau})
        return cadres


# =========================================================================
# CHEF
# =========================================================================
CHEF_SEC = frozenset(('g', 'kg', 'pinch', 'pinches'))
CHEF_LIQUIDE = frozenset(('ml', 'l', 'dash', 'dashes'))
CHEF_MIXTE = frozenset(('cup', 'cups', 'teaspoon', 'teaspoons',
                        'tablespoon', 'tablespoons'))
CHEF_TYPE_SEC = frozenset(('heaped', 'level'))
CHEF_BOL = r'(?:the\s+)?(?:\d+(?:st|nd|rd|th)\s+)?mixing\s+bowl'
CHEF_PLAT = r'(?:the\s+)?(?:\d+(?:st|nd|rd|th)\s+)?baking\s+dish'
IRREGULIERS_CHEF = {
    'stir': 'stirred', 'grind': 'ground', 'beat': 'beaten', 'shake': 'shaken',
    'set': 'set', 'put': 'put', 'knead': 'kneaded', 'cream': 'creamed',
    'melt': 'melted', 'dissolve': 'dissolved', 'agitate': 'agitated',
    'bake': 'baked', 'wait': 'waited', 'liquefy': 'liquefied',
    'liquify': 'liquified', 'blend': 'blended', 'dry': 'dried', 'fry': 'fried',
    'chop': 'chopped', 'spread': 'spread', 'simmer': 'simmered',
}


def _passe_chef(verbe):
    """Formes passées plausibles d'un verbe, pour apparier une boucle Chef."""
    v = verbe.lower()
    formes = {v + 'ed', v + 'd'}
    if v in IRREGULIERS_CHEF:
        formes.add(IRREGULIERS_CHEF[v])
    if v.endswith('e'):
        formes.add(v + 'd')
    if v.endswith('y') and len(v) > 1 and v[-2] not in 'aeiou':
        formes.add(v[:-1] + 'ied')
    if len(v) >= 3 and v[-1] not in 'aeiouwxy' and v[-2] in 'aeiou' \
            and v[-3] not in 'aeiou':
        formes.add(v + v[-1] + 'ed')
    return formes


def _ordinal_chef(texte):
    """Numéro d'un bol ou d'un plat : « the 2nd mixing bowl » -> 2."""
    trouve = re.search(r'(\d+)\s*(?:st|nd|rd|th)\b', texte, re.I)
    return int(trouve.group(1)) if trouve else 1


def _nettoyer_nom_chef(nom):
    nom = re.sub(r'\s+', ' ', nom.strip())
    if nom.lower().startswith('the '):
        nom = nom[4:]
    return nom.strip()


class Chef(Moteur):
    """Des recettes de cuisine comme programmes.

    Les ingrédients portent des valeurs numériques ; secs ils s'impriment en
    chiffres, liquides en caractères Unicode. Les bols et les plats sont des
    piles numérotées. Chaque ingrédient poussé dans un bol y est figé : changer
    ensuite la valeur de l'ingrédient ne change pas le contenu du bol.
    « Serves N » imprime les N premiers plats en les vidant par le haut.
    Les recettes auxiliaires sont préparées par des sous-chefs qui reçoivent une
    copie des bols et des plats, et rendent leur premier bol à l'appelant.
    """

    langage = 'chef'
    libelle = 'Chef'
    extension = '.chef'

    def __init__(self, code, entree='', chemin=None):
        super(Chef, self).__init__(code, entree, chemin)
        self.recettes = {}
        self.ordre = []
        self.ingredients = {}
        self.liquides = set()
        self.bols = {}
        self.plats = {}
        self.pile_appels = []
        self.index_courant = 0
        self._recette_courante = None
        self._ligne_courante = 1
        self._pile_boucles = []
        self._fin_recette = False
        self._nombre = 0

    # -- analyse de la structure --------------------------------------------
    @staticmethod
    def _blocs(code):
        """Découpe en blocs séparés par des lignes vides, avec leurs numéros."""
        blocs = []
        courant = []
        debut = 1
        for numero, ligne in enumerate(code.split('\n'), start=1):
            if ligne.strip():
                if not courant:
                    debut = numero
                courant.append(ligne)
            elif courant:
                blocs.append((debut, courant))
                courant = []
        if courant:
            blocs.append((debut, courant))
        return blocs

    _STRUCTURELS = re.compile(
        r'^\s*(ingredients\.|method\.|cooking time:|pre-heat oven|serves\s+\d+\.)',
        re.I)

    def _titre_possible(self, lignes):
        if len(lignes) != 1:
            return None
        ligne = lignes[0].strip()
        if not ligne.endswith('.'):
            return None
        if self._STRUCTURELS.match(ligne):
            return None
        return ligne[:-1].strip()

    def charger(self):
        self.recettes = {}
        self.ordre = []
        diagnostics = []
        recette = None
        dans_methode = False
        en_tete = False
        tampon_methode = []

        def cloturer_methode():
            if recette is not None and tampon_methode:
                recette['texte'] = ' '.join(tampon_methode)
                recette['instructions'] = self._analyser_methode(
                    recette['texte'], recette['ligne_methode'], diagnostics)
                del tampon_methode[:]

        for debut, lignes in self._blocs(self.code):
            titre = self._titre_possible(lignes)
            premier = lignes[0].strip()
            if titre is not None:
                cloturer_methode()
                dans_methode = False
                recette = {'titre': titre, 'ligne': debut, 'ingredients': {},
                           'liquides': set(), 'texte': '', 'instructions': [],
                           'serves': 0, 'ligne_methode': debut}
                if titre in self.recettes:
                    diagnostics.append(_diagnostic(
                        SEVERITE_AVIS,
                        'Recette « %s » déclarée deux fois : la seconde écrase '
                        'la première.' % titre, debut, 1))
                self.recettes[titre] = recette
                self.ordre.append(titre)
                en_tete = True
                continue
            if recette is None:
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Texte avant le titre de la recette : « %s ».' % premier[:50],
                    debut, 1))
                continue
            haut = premier.lower()
            if haut.startswith('ingredients.'):
                en_tete = False
                cloturer_methode()
                dans_methode = False
                for ligne in lignes[1:]:
                    self._lire_ingredient(ligne, recette, diagnostics)
            elif haut.startswith('method.'):
                en_tete = False
                dans_methode = True
                tampon_methode[:] = []
                recette['ligne_methode'] = debut
                reste = premier[len('Method.'):].strip()
                if reste:
                    tampon_methode.append(reste)
                tampon_methode.extend(l.strip() for l in lignes[1:])
            elif haut.startswith('cooking time:') or haut.startswith('pre-heat oven'):
                pass                       # décoratif, sans effet à l'exécution
            elif re.match(r'^serves\s+\d+\.$', premier, re.I):
                cloturer_methode()
                dans_methode = False
                recette['serves'] = int(re.search(r'\d+', premier).group(0))
            elif dans_methode:
                tampon_methode.extend(l.strip() for l in lignes)
            elif en_tete:
                pass        # paragraphe de commentaires, libre et facultatif
            else:
                diagnostics.append(_diagnostic(
                    SEVERITE_AVIS,
                    'Bloc ignoré hors d\'une section reconnue : « %s ».'
                    % premier[:50], debut, 1))
        cloturer_methode()
        if not self.ordre:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Aucune recette trouvée. La première ligne doit être un titre '
                'suivi d\'un point, séparé par une ligne vide.', 1, 1))
        elif self.recettes[self.ordre[0]]['serves'] == 0:
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS,
                'La recette principale n\'a pas d\'instruction « Serves N. » : '
                'elle n\'imprimera rien par elle-même.',
                self.recettes[self.ordre[0]]['ligne'], 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    def _lire_ingredient(self, ligne, recette, diagnostics):
        mots = ligne.split()
        if not mots:
            return
        valeur = 0
        if re.match(r'^-?\d+$', mots[0]):
            valeur = int(mots[0])
            mots = mots[1:]
        liquide = None
        if mots and mots[0].lower() in CHEF_TYPE_SEC:
            liquide = False
            mots = mots[1:]
        if mots and mots[0].lower() in (CHEF_SEC | CHEF_LIQUIDE | CHEF_MIXTE):
            unite = mots[0].lower()
            if unite in CHEF_LIQUIDE:
                liquide = True
            elif unite in CHEF_SEC:
                liquide = False
            mots = mots[1:]
        nom = _nettoyer_nom_chef(' '.join(mots))
        if not nom:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Ingrédient sans nom : « %s ».' % ligne, 1, 1))
            return
        if nom in recette['ingredients']:
            diagnostics.append(_diagnostic(
                SEVERITE_AVIS,
                'Ingrédient « %s » répété : seule la dernière valeur compte.'
                % nom, 1, 1))
        recette['ingredients'][nom] = valeur
        if liquide is True:
            recette['liquides'].add(nom)
        else:
            recette['liquides'].discard(nom)

    # -- analyse de la méthode ----------------------------------------------
    def _analyser_methode(self, texte, ligne_base, diagnostics):
        instructions = []
        phrases = [p.strip() for p in texte.split('.') if p.strip()]
        for rang, phrase in enumerate(phrases):
            # La spécification ignore les retours à la ligne dans la méthode :
            # les phrases sont donc repérées par leur rang, et la ligne
            # signalée est celle du mot « Method. ».
            numero = ligne_base
            ordre = self._classifier(phrase, diagnostics, numero)
            if ordre is not None:
                instructions.append((rang, numero) + ordre)
        self._apparier_boucles(instructions, diagnostics)
        return instructions

    def _classifier(self, phrase, diagnostics, numero):
        p = re.sub(r'\s+', ' ', phrase.strip()).lower()
        m = re.match(r'^take\s+(.+?)\s+from\s+refrigerator$', p)
        if m:
            return ('lire', _nettoyer_nom_chef(m.group(1)),)
        m = re.match(r'^pour\s+contents\s+of\s+' + CHEF_BOL +
                     r'\s+into\s+' + CHEF_PLAT + r'$', p)
        if m:
            # Deux ordinaux dans la même phrase : chacun se lit dans SA moitié,
            # sinon « into the 2nd baking dish » fait croire que le bol est le 2e.
            coupure = p.index(' into ')
            return ('verser', _ordinal_chef(p[:coupure]),
                    _ordinal_chef(p[coupure:]))
        if re.match(r'^add\s+dry\s+ingredients(\s+to\s+' + CHEF_BOL + r')?$', p):
            return ('ajouter_secs', _ordinal_chef(p))
        m = re.match(r'^put\s+(.+?)\s+into\s+' + CHEF_BOL + r'$', p)
        if m:
            return ('poser', _nettoyer_nom_chef(m.group(1)), _ordinal_chef(p))
        m = re.match(r'^fold\s+(.+?)\s+into\s+' + CHEF_BOL + r'$', p)
        if m:
            return ('plier', _nettoyer_nom_chef(m.group(1)), _ordinal_chef(p))
        for motif, ordre in ((r'^add\s+(.+?)(\s+to\s+' + CHEF_BOL + r')?$',
                              'ajouter'),
                             (r'^remove\s+(.+?)(\s+from\s+' + CHEF_BOL + r')?$',
                              'retirer'),
                             (r'^combine\s+(.+?)(\s+into\s+' + CHEF_BOL + r')?$',
                              'combiner'),
                             (r'^divide\s+(.+?)(\s+into\s+' + CHEF_BOL + r')?$',
                              'diviser')):
            m = re.match(motif, p)
            if m:
                return (ordre, _nettoyer_nom_chef(m.group(1)), _ordinal_chef(p))
        m = re.match(r'^(?:liquefy|liquify)\s+(?:the\s+)?contents\s+of\s+'
                     + CHEF_BOL + r'$', p)
        if m:
            return ('liquefier_bol', _ordinal_chef(p))
        m = re.match(r'^(?:liquefy|liquify)\s+(.+?)$', p)
        if m:
            return ('liquefier', _nettoyer_nom_chef(m.group(1)))
        m = re.match(r'^stir\s+(?:(?:the\s+)?(?:\d+(?:st|nd|rd|th)\s+)?'
                     r'mixing\s+bowl\s+)?for\s+(\d+)\s+minutes?$', p)
        if m:
            return ('remuer_minutes', int(m.group(1)), _ordinal_chef(p))
        m = re.match(r'^stir\s+(.+?)\s+into\s+' + CHEF_BOL + r'$', p)
        if m:
            return ('remuer_ingredient', _nettoyer_nom_chef(m.group(1)),
                    _ordinal_chef(p))
        if re.match(r'^mix\s*(?:' + CHEF_BOL + r')?\s*well$', p):
            return ('melanger', _ordinal_chef(p))
        if re.match(r'^clean\s*' + CHEF_BOL + r'$', p):
            return ('nettoyer', _ordinal_chef(p))
        m = re.match(r'^serve\s+with\s+(.+?)$', p)
        if m:
            return ('servir_avec', m.group(1).strip())
        m = re.match(r'^refrigerate(?:\s+for\s+(\d+)\s+hours?)?$', p)
        if m:
            return ('refroidir', int(m.group(1)) if m.group(1) else 0)
        m = re.match(r'^(.+?)\s+until\s+(\w+)$', p)
        if m:
            # « Verb [the ingredient] until verbed. » : le VERBE est arbitraire
            # et doit être ignoré. Seule la partie après « the » est l'ingrédient
            # à décrémenter — et il peut être absent.
            avant = m.group(1)
            trouve = re.match(r'^\w+\s+the\s+(.+)$', avant)
            if trouve:
                nom = trouve.group(1)
            else:
                trouve = re.match(r'^the\s+(.+)$', avant)
                nom = trouve.group(1) if trouve else ''
            return ('fin_boucle', _nettoyer_nom_chef(nom), m.group(2).lower())
        if p == 'set aside':
            return ('set_aside',)
        m = re.match(r'^(\w+)\s+the\s+(.+?)$', p)
        if m:
            return ('debut_boucle', m.group(1).lower(),
                    _nettoyer_nom_chef(m.group(2)))
        diagnostics.append(_diagnostic(
            SEVERITE_ERREUR,
            'Instruction de méthode non reconnue : « %s ».' % phrase[:70],
            numero, 1))
        return None

    def _apparier_boucles(self, instructions, diagnostics):
        """Associe chaque « Verb the X. » au « ... until verbed. » qui le clôt."""
        ouverts = []
        for position, item in enumerate(instructions):
            ordre = item[2]
            if ordre == 'debut_boucle':
                ouverts.append([position, item[3], None])
            elif ordre == 'fin_boucle':
                verbed = item[4]
                choix = None
                for candidate in reversed(ouverts):
                    if candidate[2] is None and \
                            verbed in _passe_chef(candidate[1]):
                        choix = candidate
                        break
                if choix is None:
                    for candidate in reversed(ouverts):
                        if candidate[2] is None:
                            choix = candidate
                            diagnostics.append(_diagnostic(
                                SEVERITE_AVIS,
                                'Boucle « %s » appariée à « until %s » sans '
                                'correspondance de temps.'
                                % (candidate[1], verbed), item[1], 1))
                            break
                if choix is None:
                    diagnostics.append(_diagnostic(
                        SEVERITE_ERREUR,
                        '« until %s » sans instruction de boucle ouvrante.'
                        % verbed, item[1], 1))
                    continue
                choix[2] = position
        for position, verbe, fin in ouverts:
            if fin is None:
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Boucle « %s the ... » jamais refermée par « until ».'
                    % verbe, instructions[position][1], 1))

    # -- exécution -----------------------------------------------------------
    def _bol(self, numero):
        return self.bols.setdefault(numero, [])

    def _plat(self, numero):
        return self.plats.setdefault(numero, [])

    def _valeur(self, nom, ligne):
        if nom not in self.ingredients:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                'Ingrédient « %s » jamais déclaré dans la liste des ingrédients.'
                % nom, ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None
        return self.ingredients[nom]

    def pas(self):
        if self.termine:
            return False
        if not self.ordre and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        if self._recette_courante is None:
            if not self.ordre:
                self.termine = True
                return False
            self._ouvrir_recette(self.ordre[0])
        recette = self.recettes[self._recette_courante]
        if self.index_courant >= len(recette['instructions']):
            self._terminer_recette()
            return not self.termine
        self.pas_fait += 1
        item = recette['instructions'][self.index_courant]
        self.index_courant += 1
        # item = (rang, numero) + ordre : la ligne est en position 1.
        self._ligne_courante = item[1]
        return self._executer(item[2:])

    def _ouvrir_recette(self, titre, bols=None, plats=None, ingredients=None,
                        liquides=None):
        self._recette_courante = titre
        self.index_courant = 0
        self.bols = bols if bols is not None else {}
        self.plats = plats if plats is not None else {}
        self.ingredients = dict(ingredients) if ingredients is not None \
            else dict(self.recettes[titre]['ingredients'])
        self.liquides = set(liquides) if liquides is not None \
            else set(self.recettes[titre]['liquides'])
        self._pile_boucles = []

    def _terminer_recette(self):
        recette = self.recettes[self._recette_courante]
        if recette['serves']:
            self._imprimer_plats(recette['serves'])
        if self.pile_appels:
            cadre = self.pile_appels.pop()
            retour = list(self._bol(1))
            self.bols = cadre['bols']
            self.plats = cadre['plats']
            self.ingredients = cadre['ingredients']
            self.liquides = cadre['liquides']
            self._recette_courante = cadre['recette']
            self.index_courant = cadre['retour']
            self._pile_boucles = cadre.get('boucles', [])
            # Le premier bol du sous-chef est reversé dans celui de l'appelant.
            self._bol(1).extend(retour)
            return
        self.termine = True

    def _imprimer_plats(self, nombre):
        for numero in range(1, nombre + 1):
            plat = self._plat(numero)
            while plat:
                valeur, liquide = plat.pop()
                if liquide:
                    self._ecrire(chr(valeur % 1114112) if valeur >= 0 else '')
                else:
                    self._ecrire('%d\n' % valeur)

    def _executer(self, instruction):
        ordre = instruction[0]
        ligne = getattr(self, '_ligne_courante', 1)
        if ordre == 'poser':
            nom, numero = instruction[1], instruction[2]
            valeur = self._valeur(nom, ligne)
            if valeur is None:
                return False
            self._bol(numero).append((valeur, nom in self.liquides))
            return True
        if ordre == 'plier':
            nom, numero = instruction[1], instruction[2]
            bol = self._bol(numero)
            if not bol:
                return self._echec_chef('Bol %d vide : rien à plier.' % numero, ligne)
            valeur, liquide = bol.pop()
            if nom not in self.ingredients:
                self.ingredients[nom] = 0
            self.ingredients[nom] = valeur
            if liquide:
                self.liquides.add(nom)
            else:
                self.liquides.discard(nom)
            return True
        if ordre in ('ajouter', 'retirer', 'combiner', 'diviser'):
            nom, numero = instruction[1], instruction[2]
            valeur = self._valeur(nom, ligne)
            if valeur is None:
                return False
            bol = self._bol(numero)
            if not bol:
                return self._echec_chef('Bol %d vide pour « %s ».'
                                        % (numero, ordre), ligne)
            haut, liquide = bol[-1]
            if ordre == 'ajouter':
                resultat = haut + valeur
            elif ordre == 'retirer':
                resultat = haut - valeur
            elif ordre == 'combiner':
                resultat = borne(haut * valeur, 'le résultat')
            else:
                if valeur == 0:
                    return self._echec_chef('Division par l\'ingrédient « %s » '
                                            'qui vaut 0.' % nom, ligne)
                resultat = int(haut / valeur)
            bol[-1] = (resultat, liquide)
            return True
        if ordre == 'ajouter_secs':
            numero = instruction[1]
            total = sum(v for n, v in self.ingredients.items()
                        if n not in self.liquides)
            self._bol(numero).append((total, False))
            return True
        if ordre == 'liquefier':
            nom = instruction[1]
            if self._valeur(nom, ligne) is None:
                return False
            self.liquides.add(nom)
            return True
        if ordre == 'liquefier_bol':
            bol = self._bol(instruction[1])
            bol[:] = [(v, True) for v, _l in bol]
            return True
        if ordre == 'remuer_minutes':
            return self._rouler(instruction[1], instruction[2], ligne)
        if ordre == 'remuer_ingredient':
            nom, numero = instruction[1], instruction[2]
            valeur = self._valeur(nom, ligne)
            if valeur is None:
                return False
            return self._rouler(abs(int(valeur)), numero, ligne)
        if ordre == 'melanger':
            bol = self._bol(instruction[1])
            random.shuffle(bol)
            return True
        if ordre == 'nettoyer':
            del self._bol(instruction[1])[:]
            return True
        if ordre == 'verser':
            bol, plat = self._bol(instruction[1]), self._plat(instruction[2])
            plat.extend(bol)
            return True
        if ordre == 'lire':
            nom = instruction[1]
            nombre = self.entree.nombre()
            if nombre is None:
                return self._echec_chef(
                    'Plus aucune valeur numérique à lire pour « %s ».' % nom, ligne)
            self.ingredients[nom] = nombre
            return True
        if ordre == 'debut_boucle':
            nom = instruction[2]
            valeur = self._valeur(nom, ligne)
            if valeur is None:
                return False
            if not valeur:
                self.index_courant = self._saut_boucle(ligne)
                return True
            self._pile_boucles.append((self.index_courant - 1, nom))
            return True
        if ordre == 'fin_boucle':
            nom = instruction[1]
            if nom and nom in self.ingredients:
                # « Si l'ingrédient apparaît dans cette instruction, sa valeur
                # est décrémentée de 1 quand elle s'exécute. »
                self.ingredients[nom] -= 1
            if not self._pile_boucles:
                return self._echec_chef('« until » sans boucle ouverte.', ligne)
            depart, _nom = self._pile_boucles[-1]
            self.index_courant = depart
            return True
        if ordre == 'set_aside':
            if self._pile_boucles:
                depart, _nom = self._pile_boucles.pop()
                self.index_courant = self._saut_depuis(depart, ligne)
            return True
        if ordre == 'servir_avec':
            nom = instruction[1]
            if nom not in self.recettes:
                return self._echec_chef(
                    'Recette auxiliaire « %s » introuvable.' % nom, ligne)
            if len(self.pile_appels) >= 50:
                return self._echec_chef(
                    'Trop de sous-chefs imbriqués (plus de 50).', ligne)
            self.pile_appels.append({
                'recette': self._recette_courante, 'retour': self.index_courant,
                'bols': self.bols, 'plats': self.plats,
                'ingredients': self.ingredients, 'liquides': self.liquides,
                'boucles': list(self._pile_boucles)})
            # Le sous-chef reçoit une COPIE : ses modifications sont isolées.
            self._ouvrir_recette(
                nom,
                bols={k: list(v) for k, v in self.bols.items()},
                plats={k: list(v) for k, v in self.plats.items()},
                ingredients=dict(self.recettes[nom]['ingredients']),
                liquides=set(self.recettes[nom]['liquides']))
            return True
        if ordre == 'refroidir':
            heures = instruction[1]
            if heures:
                self._imprimer_plats(heures)
            self._fin_recette = True
            if self.pile_appels:
                self._terminer_recette()
            else:
                self.termine = True
            return not self.termine
        return self._echec_chef('Instruction interne inconnue : « %s ».' % ordre,
                                ligne)

    def _echec_chef(self, message, ligne):
        self.diagnostiques.append(_diagnostic(SEVERITE_ERREUR, message, ligne, 1))
        self.message = message
        self.termine = True
        self.arret_anormal = True
        return False

    def _rouler(self, nombre, numero, ligne):
        bol = self._bol(numero)
        if not bol:
            return True
        k = min(nombre, len(bol))
        if k <= 1:
            return True
        groupe = bol[len(bol) - k:]
        # Le sommet descend de k places, les autres montent d'un cran.
        bol[len(bol) - k:] = [groupe[-1]] + groupe[:-1]
        return True

    def _saut_boucle(self, ligne):
        """Position de l'instruction suivant le « until » apparié."""
        instructions = self.recettes[self._recette_courante]['instructions']
        return self._saut_depuis(self.index_courant - 1, ligne, instructions)

    def _saut_depuis(self, depart, ligne, instructions=None):
        instructions = instructions or \
            self.recettes[self._recette_courante]['instructions']
        profondeur = 0
        for position in range(depart + 1, len(instructions)):
            ordre = instructions[position][2]
            if ordre == 'debut_boucle':
                profondeur += 1
            elif ordre == 'fin_boucle':
                if profondeur == 0:
                    return position + 1
                profondeur -= 1
        return len(instructions)

    @property
    def position(self):
        return (self._ligne_courante, 1)

    def variables(self):
        retour = [{'name': nom, 'value': '%d%s' % (valeur, ' (liquide)'
                  if nom in self.liquides else '')}
                  for nom, valeur in sorted(self.ingredients.items())][:30]
        for numero in sorted(self.bols):
            retour.append({'name': 'bol %d' % numero,
                           'value': _texte_valeurs(
                               [v for v, _l in self.bols[numero]])})
        for numero in sorted(self.plats):
            retour.append({'name': 'plat %d' % numero,
                           'value': _texte_valeurs(
                               [v for v, _l in self.plats[numero]])})
        retour.append({'name': 'recette', 'value': self._recette_courante or ''})
        return retour

    def frames(self):
        cadres = [{'file': self.chemin, 'line': self._ligne_courante,
                   'function': self._recette_courante or 'recette', 'level': 0}]
        for niveau, cadre in enumerate(reversed(self.pile_appels), start=1):
            cadres.append({'file': self.chemin, 'line': cadre['retour'],
                           'function': cadre['recette'], 'level': niveau})
        return cadres


# =========================================================================
# INTERCAL
# =========================================================================
# Noms des commandes pour ABSTAIN FROM / REINSTATE.
ABSTENTION_INTERCAL = {
    'CALCULATING': 'assigner', 'STASHING': 'stash', 'RETRIEVING': 'retrieve',
    'NEXTING': 'next', 'RESUMING': 'resume', 'FORGETTING': 'forget',
    'ABSTAINING': 'abstain', 'REINSTATING': 'reinstate', 'IGNORING': 'ignore',
    'REMEMBERING': 'remember', 'WRITING IN': 'write_in',
    'READING OUT': 'read_out', 'COMING FROM': 'come_from',
    'GIVING UP': 'give_up',
}
CHIFFRES_INTERCAL = {
    'OH': '0', 'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4',
    'FIVE': '5', 'SIX': '6', 'SEVEN': '7', 'EIGHT': '8', 'NINE': '9',
    'WON': '1',
}
# Symboles romains « abîmés » de READ OUT. Les valeurs 32 bits ajoutent
# W (500 000) et R (1 000 000) aux symboles 16 bits.
ROMAINS_INTERCAL_16 = ((1000, 'M'), (900, 'CM'), (500, 'D'), (400, 'CD'),
                       (100, 'C'), (90, 'XC'), (50, 'L'), (40, 'XL'),
                       (10, 'X'), (9, 'IX'), (5, 'V'), (4, 'IV'), (1, 'I'))
ROMAINS_INTERCAL_32 = ((1000000, 'R'), (900000, 'WR'), (500000, 'W'),
                       (400000, 'VW')) + ROMAINS_INTERCAL_16


def romain_intercal(valeur, largeur):
    """Écrit un entier en chiffres romains « abîmés », comme READ OUT.

    Convention retenue (celle de C-INTERCAL pour une sortie 16 bits) : les
    symboles s'arrêtent à M = 1000, donc une valeur supérieure à 3999 répète
    autant de M que nécessaire. Zéro s'écrit « O » (la lettre, pas le chiffre).
    Les valeurs 32 bits disposent en plus de W = 500 000 et R = 1 000 000.
    """
    if valeur == 0:
        return 'O'
    table = ROMAINS_INTERCAL_32 if largeur == 32 else ROMAINS_INTERCAL_16
    sortie = []
    reste = valeur
    for poids, symbole in table:
        while reste >= poids:
            sortie.append(symbole)
            reste -= poids
    return ''.join(sortie)


def _mingle(gauche, droite):
    """$ : les bits sont entrelacés, le bit de poids faible de DROITE devenant
    celui du résultat. Le résultat fait toujours 32 bits."""
    resultat = 0
    for position in range(16):
        if (droite >> position) & 1:
            resultat |= 1 << (2 * position)
        if (gauche >> position) & 1:
            resultat |= 1 << (2 * position + 1)
    return resultat


def _select(gauche, droite):
    """~ : seuls les bits de GAUCHE aux positions où DROITE vaut 1 comptent,
    justifiés vers le poids faible. « #12 ~ #5 » vaut 10 en binaire, soit 2.
    La largeur du résultat suit celle de l'opérande de droite."""
    resultat = 0
    cible = 0
    for position in range(32):
        if (droite >> position) & 1:
            if (gauche >> position) & 1:
                resultat |= 1 << cible
            cible += 1
    return resultat


def _unaire(operation, valeur, largeur):
    """V/?/& agissent sur des bits CONSÉCUTIFS : le bit k du résultat combine les
    bits k et k+1 de l'entrée, et le bit de poids fort combine le plus et le
    moins significatif."""
    resultat = 0
    for position in range(largeur):
        suivant = (position + 1) % largeur
        a = (valeur >> position) & 1
        b = (valeur >> suivant) & 1
        if operation == 'V':
            bit = a | b
        elif operation == '?':
            bit = a ^ b
        else:
            bit = a & b
        if bit:
            resultat |= 1 << position
    return resultat


class Intercal(Moteur):
    """Compiler Language With No Pronounceable Acronym (1972).

    Quatre types de variables : « .n » 16 bits, « :n » 32 bits, « ,n » et « ;n »
    pour les tableaux. Cinq opérateurs, sans AUCUNE priorité : il faut grouper
    avec les sparks (') et les rabbit-ears ("). Chaque instruction est précédée
    de DO, PLEASE ou PLEASE DO, et la politesse du programme doit rester entre
    un cinquième et un tiers des instructions. COME FROM est un GOTO à l'envers.
    """

    langage = 'intercal'
    libelle = 'INTERCAL'
    extension = '.i'

    def __init__(self, code, entree='', chemin=None):
        super(Intercal, self).__init__(code, entree, chemin)
        self.spots = {}
        self.twospots = {}
        self.tails = {}
        self.hybrids = {}
        self.reserves = {}
        self.ignores = set()
        self.instructions = []
        self.index_courant = 0
        self.pile_next = []
        self._ligne_courante = 1
        self._donne_abandon = False

    # -- variables -----------------------------------------------------------
    def _table(self, genre):
        return {'.': self.spots, ':': self.twospots,
                ',': self.tails, ';': self.hybrids}[genre]

    def _cle(self, genre, numero):
        return '%s%d' % (genre, numero)

    def _lire_variable(self, genre, numero, ligne):
        if genre in (',', ';'):
            tableau = self._table(genre).get(numero)
            if tableau is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Le tableau %s%d n\'a jamais été dimensionné.'
                    % (genre, numero), ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return None
            return tableau
        return self._table(genre).get(numero, 0)

    def _ecrire_variable(self, genre, numero, valeur, ligne):
        cle = self._cle(genre, numero)
        if cle in self.ignores:
            return True            # IGNORE : l'écriture est silencieusement ignorée
        if genre == '.':
            self.spots[numero] = valeur & 0xFFFF
        elif genre == ':':
            self.twospots[numero] = valeur & 0xFFFFFFFF
        else:
            self._table(genre)[numero] = valeur
        return True

    # -- analyse -------------------------------------------------------------
    def charger(self):
        self.instructions = []
        diagnostics = []
        for numero, ligne in enumerate(self.code.split('\n'), start=1):
            propre = ligne.strip()
            if not propre:
                continue
            instruction = self._analyser_ligne(propre, numero, diagnostics)
            if instruction is not None:
                self.instructions.append(instruction)
        self._verifier_politesse(diagnostics)
        self._erreurs_chargement = diagnostics
        return diagnostics

    def _verifier_politesse(self, diagnostics):
        total = len(self.instructions)
        if total < 5:
            return
        polies = sum(1 for i in self.instructions if i['polie'])
        # La spécification impose entre un cinquième et un tiers d'instructions
        # polies. C-INTERCAL refuse le programme hors de ces bornes.
        if polies * 5 < total:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Programme impoli : %d instruction(s) PLEASE sur %d, il en faut '
                'au moins un cinquième.' % (polies, total), 1, 1))
        elif polies * 3 > total:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Programme trop poli : %d instruction(s) PLEASE sur %d, il en '
                'faut au plus un tiers.' % (polies, total), 1, 1))

    def _analyser_ligne(self, texte, numero, diagnostics):
        reste = texte
        etiquette = None
        m = re.match(r'^\(\s*(\d+)\s*\)\s*', reste)
        if m:
            etiquette = int(m.group(1))
            reste = reste[m.end():]
        polie = False
        haut = reste.upper()
        # Formes négatives : sans effet, sauf REINSTATE.
        for negatif in ('PLEASE DON\'T', 'PLEASE DO NOT', 'PLEASEN\'T',
                        'DON\'T', 'DO NOT'):
            if haut.startswith(negatif):
                corps = reste[len(negatif):].strip()
                return {'ligne': numero, 'label': etiquette, 'polie': False,
                        'chance': None, 'ordre': 'inactif', 'texte': texte,
                        'corps': corps, 'abstenu': True}
        if haut.startswith('PLEASE DO'):
            polie = True
            reste = reste[len('PLEASE DO'):].strip()
        elif haut.startswith('PLEASE'):
            polie = True
            reste = reste[len('PLEASE'):].strip()
            # PLEASE NOTE ... est la façon usuelle de commenter : la faute de
            # syntaxe voulue rend la ligne impossible à REINSTATE.
            if reste.upper().startswith('NOTE'):
                return None
        elif haut.startswith('DO'):
            reste = reste[len('DO'):].strip()
        else:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Ligne sans DO ni PLEASE : « %s ».' % texte[:60], numero, 1))
            return None
        chance = None
        m = re.match(r'^%\s*(\d+)\s*', reste)
        if m:
            chance = int(m.group(1))
            reste = reste[m.end():]
            if chance > 100:
                diagnostics.append(_diagnostic(
                    SEVERITE_ERREUR,
                    '%% %d : une chance doit être comprise entre 0 et 100.'
                    % chance, numero, 1))
        ordre, args, commande = self._analyser_commande(reste, numero, diagnostics)
        if ordre is None:
            return None
        return {'ligne': numero, 'label': etiquette, 'polie': polie,
                'chance': chance, 'ordre': ordre, 'args': args,
                'commande': commande, 'texte': texte, 'abstenu': False}

    def _analyser_commande(self, texte, numero, diagnostics):
        haut = texte.upper().strip()
        if haut in ('GIVE UP',):
            return 'give_up', {}, 'GIVING UP'
        m = re.match(r'^COME\s+FROM\s+\(\s*(\d+)\s*\)$', haut)
        if m:
            return 'come_from', {'cible': int(m.group(1))}, 'COMING FROM'
        m = re.match(r'^\(\s*(\d+)\s*\)\s*NEXT$', haut)
        if m:
            return 'next', {'cible': int(m.group(1))}, 'NEXTING'
        m = re.match(r'^(RESUME|FORGET)\s+(.+)$', haut)
        if m:
            return (m.group(1).lower(), {'expression': m.group(2).strip()},
                    'RESUMING' if m.group(1) == 'RESUME' else 'FORGETTING')
        m = re.match(r'^(ABSTAIN\s+FROM|REINSTATE)\s+(.+)$', haut)
        if m:
            ordre = 'abstain' if m.group(1).startswith('ABSTAIN') else 'reinstate'
            cible = m.group(2).strip()
            return ordre, {'cible': cible}, \
                'ABSTAINING' if ordre == 'abstain' else 'REINSTATING'
        for mot, ordre, commande in (
                ('STASH', 'stash', 'STASHING'),
                ('RETRIEVE', 'retrieve', 'RETRIEVING'),
                ('IGNORE', 'ignore', 'IGNORING'),
                ('REMEMBER', 'remember', 'REMEMBERING'),
                ('WRITE IN', 'write_in', 'WRITING IN'),
                ('READ OUT', 'read_out', 'READING OUT')):
            m = re.match(r'^%s\s+(.+)$' % mot.replace(' ', r'\s+'), haut)
            if m:
                return ordre, {'cible': m.group(1).strip()}, commande
        m = re.match(r'^(.+?)\s*<-\s*(.+)$', texte)
        if m:
            return 'assigner', {'cible': m.group(1).strip(),
                                'expression': m.group(2).strip()}, 'CALCULATING'
        diagnostics.append(_diagnostic(
            SEVERITE_ERREUR,
            'Commande INTERCAL non reconnue : « %s ».' % texte[:60], numero, 1))
        return None, None, None

    # -- expressions ---------------------------------------------------------
    def _atomes(self, texte):
        """Découpe en jetons en respectant les groupes ' et "."""
        jetons = []
        i = 0
        texte = texte.strip()
        while i < len(texte):
            c = texte[i]
            if c in ' \t':
                i += 1
                continue
            if c in '\'"':
                profondeur = 1
                j = i + 1
                while j < len(texte) and profondeur:
                    if texte[j] in '\'"':
                        profondeur -= 1 if texte[j] == c else 0
                        if texte[j] != c:
                            profondeur += 1
                    j += 1
                jetons.append(('groupe', texte[i:j]))
                i = j
                continue
            if c == '#':
                j = i + 1
                while j < len(texte) and texte[j].isdigit():
                    j += 1
                jetons.append(('constante', texte[i:j]))
                i = j
                continue
            if c in '.:,;':
                j = i + 1
                while j < len(texte) and texte[j].isdigit():
                    j += 1
                # Un opérateur unaire se place JUSTE APRÈS le signe de ponctuation.
                if j == i + 1 and j < len(texte) and texte[j] in 'V?&':
                    j += 1
                    while j < len(texte) and texte[j].isdigit():
                        j += 1
                jetons.append(('variable', texte[i:j]))
                i = j
                continue
            if c in 'V?&$~':
                jetons.append(('operateur', c))
                i += 1
                continue
            if texte[i:i + 3].upper() == 'SUB':
                jetons.append(('sub', 'SUB'))
                i += 3
                continue
            if c.isdigit():
                j = i
                while j < len(texte) and texte[j].isdigit():
                    j += 1
                jetons.append(('nombre', texte[i:j]))
                i = j
                continue
            i += 1
        return jetons

    def _evaluer(self, texte, ligne):
        jetons = self._atomes(texte)
        if not jetons:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR, 'Expression vide.', ligne, 1))
            return None
        valeur, position = self._expression(jetons, 0, ligne)
        if valeur is None:
            return None
        if position < len(jetons):
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                'Expression mal formée près de « %s ».'
                % jetons[position][1], ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None
        return valeur

    def _expression(self, jetons, position, ligne):
        """INTERCAL n'a AUCUNE priorité : on associe simplement de gauche à
        droite, le groupement étant explicite par ' et "."""
        gauche, position = self._atome(jetons, position, ligne)
        if gauche is None:
            return None, position
        while position < len(jetons) and jetons[position][0] == 'operateur' \
                and jetons[position][1] in '$~':
            operateur = jetons[position][1]
            droite, position = self._atome(jetons, position + 1, ligne)
            if droite is None:
                return None, position
            if operateur == '$':
                if gauche > 0xFFFF or droite > 0xFFFF:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'Mingle ($) en débordement : les deux opérandes doivent '
                        'tenir sur 16 bits.', ligne, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return None, position
                gauche = _mingle(gauche & 0xFFFF, droite & 0xFFFF)
            else:
                gauche = _select(gauche, droite)
        return gauche, position

    def _atome(self, jetons, position, ligne):
        if position >= len(jetons):
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR, 'Expression tronquée.', ligne, 1))
            self.termine = True
            self.arret_anormal = True
            return None, position
        genre, texte = jetons[position]
        if genre == 'groupe':
            interieur = texte[1:-1]
            operateur = None
            if interieur[:1] in ('V', '?', '&'):
                operateur = interieur[0]
                interieur = interieur[1:]
            valeur = self._evaluer(interieur, ligne)
            if valeur is None:
                return None, position + 1
            largeur = 32 if valeur > 0xFFFF else 16
            if operateur:
                valeur = _unaire(operateur, valeur, largeur)
            return valeur, position + 1
        if genre == 'constante':
            return int(texte[1:]), position + 1
        if genre == 'nombre':
            return int(texte), position + 1
        if genre == 'variable':
            return self._lire_atome_variable(texte, jetons, position, ligne)
        self.diagnostiques.append(_diagnostic(
            SEVERITE_ERREUR, 'Jeton inattendu : « %s ».' % texte, ligne, 1))
        self.termine = True
        self.arret_anormal = True
        return None, position + 1

    def _lire_atome_variable(self, texte, jetons, position, ligne):
        prefixe = texte[0]
        reste = texte[1:]
        operateur = None
        if reste[:1] in ('V', '?', '&'):
            operateur = reste[0]
            reste = reste[1:]
        numero = int(reste) if reste else 0
        # « ,1 SUB .1 » : l'indice suit le mot SUB.
        if position + 1 < len(jetons) and jetons[position + 1][0] == 'sub':
            if prefixe not in (',', ';'):
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'SUB s\'applique à un tableau, pas à %s%d.'
                    % (prefixe, numero), ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return None, position + 2
            indice, suivant = self._expression(jetons, position + 2, ligne)
            if indice is None:
                return None, suivant
            tableau = self._lire_variable(prefixe, numero, ligne)
            if tableau is None:
                return None, suivant
            if indice < 1 or indice > len(tableau):
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Indice %d hors du tableau %s%d (dimension %d).'
                    % (indice, prefixe, numero, len(tableau)), ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return None, suivant
            valeur = tableau[indice - 1]     # les tableaux sont basés à 1
            position = suivant - 1
        else:
            valeur = self._lire_variable(prefixe, numero, ligne)
            if valeur is None:
                return None, position + 1
            if isinstance(valeur, list):
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Le tableau %s%d est utilisé sans SUB.' % (prefixe, numero),
                    ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return None, position + 1
        largeur = 32 if prefixe == ':' else 16
        if operateur:
            valeur = _unaire(operateur, valeur & (0xFFFFFFFF if largeur == 32
                                                  else 0xFFFF), largeur)
        return valeur, position + 1

    # -- cibles (STASH, RETRIEVE, IGNORE, ...) -------------------------------
    def _cibles(self, texte):
        """« .1 + .2 + :3 » -> [('.', 1), ('.', 2), (':', 3)]."""
        retour = []
        for morceau in texte.split('+'):
            morceau = morceau.strip()
            if morceau and morceau[0] in '.:,;':
                numero = morceau[1:].strip()
                if numero.isdigit():
                    retour.append((morceau[0], int(numero)))
        return retour

    # -- exécution -----------------------------------------------------------
    def pas(self):
        if self.termine:
            return False
        if not self.instructions and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        if self.index_courant >= len(self.instructions):
            self.termine = True
            return False
        self.pas_fait += 1
        instruction = self.instructions[self.index_courant]
        self.index_courant += 1
        self._ligne_courante = instruction['ligne']
        if instruction['abstenu'] or instruction['ordre'] == 'inactif':
            return True
        if instruction['chance'] is not None:
            # Tirage sur 1..100 : %0 ne s'exécute JAMAIS et %100 TOUJOURS,
            # sans dépendre d'un tirage qui tomberait exactement sur la borne.
            if random.randint(1, 100) > instruction['chance']:
                return True       # « double-oh-seven » : la ligne ne s'exécute pas
        if not self._executer(instruction):
            return False
        self._venir_depuis()
        return not self.termine

    def _venir_depuis(self):
        """COME FROM : quand la ligne visée vient d'être exécutée, le contrôle
        part vers le COME FROM au lieu de la ligne suivante."""
        if self.termine or self._donne_abandon:
            return
        suivant = self.index_courant
        if suivant >= len(self.instructions):
            return
        cible = self.instructions[suivant]['label']
        if cible is None:
            return
        for position, instruction in enumerate(self.instructions):
            if instruction['ordre'] == 'come_from' and not instruction['abstenu'] \
                    and instruction['args']['cible'] == cible:
                self.index_courant = position + 1
                return

    def _executer(self, instruction):
        ordre = instruction['ordre']
        ligne = instruction['ligne']
        if ordre == 'give_up':
            self.termine = True
            self._donne_abandon = True
            return False
        if ordre == 'come_from':
            return True                    # effet pris en compte par _venir_depuis
        if ordre == 'assigner':
            cible = instruction['args']['cible']
            if not cible or cible[0] not in '.:,;':
                return self._echec('Membre gauche invalide : « %s ».' % cible, ligne)
            genre = cible[0]
            valeur = self._evaluer(instruction['args']['expression'], ligne)
            if valeur is None:
                return not self.termine
            sous = re.match(r'^([,;])\s*(\d+)\s+SUB\s+(.+)$', cible, re.I)
            if sous:
                # Écriture dans une case : « DO ,1 SUB #2 <- #20 ».
                genre_tableau = sous.group(1)
                numero_tableau = int(sous.group(2))
                indice = self._evaluer(sous.group(3), ligne)
                if indice is None:
                    return not self.termine
                tableau = self._lire_variable(genre_tableau, numero_tableau, ligne)
                if tableau is None:
                    return False
                if indice < 1 or indice > len(tableau):
                    return self._echec(
                        'Indice %d hors du tableau %s%d (dimension %d).'
                        % (indice, genre_tableau, numero_tableau, len(tableau)),
                        ligne)
                if self._cle(genre_tableau, numero_tableau) not in self.ignores:
                    masque = 0xFFFFFFFF if genre_tableau == ';' else 0xFFFF
                    tableau[indice - 1] = valeur & masque
                return True
            numero = cible[1:].strip()
            if not numero.isdigit():
                return self._echec('Numéro de variable invalide : « %s ».' % cible,
                                   ligne)
            numero = int(numero)
            if genre in (',', ';'):
                # Dimensionner un tableau : la valeur donne sa taille.
                if valeur < 0 or valeur > 65535:
                    return self._echec(
                        'Dimension de tableau invalide : %d.' % valeur, ligne)
                self._table(genre)[numero] = [0] * valeur
                return True
            self._ecrire_variable(genre, numero, valeur, ligne)
            return True
        if ordre in ('stash', 'retrieve'):
            for genre, numero in self._cibles(instruction['args']['cible']):
                cle = self._cle(genre, numero)
                pile = self.reserves.setdefault(cle, [])
                if ordre == 'stash':
                    valeur = self._lire_variable(genre, numero, ligne)
                    if valeur is None:
                        return False
                    if len(pile) >= 1000:
                        return self._echec(
                            'Pile de STASH saturée pour %s.' % cle, ligne)
                    pile.append(list(valeur) if isinstance(valeur, list) else valeur)
                else:
                    if not pile:
                        return self._echec(
                            'RETRIEVE %s : rien n\'a été STASHé.' % cle, ligne)
                    valeur = pile.pop()
                    if cle not in self.ignores:
                        if genre in ('.', ':'):
                            self._table(genre)[numero] = valeur
                        else:
                            self._table(genre)[numero] = list(valeur)
            return True
        if ordre in ('ignore', 'remember'):
            for genre, numero in self._cibles(instruction['args']['cible']):
                cle = self._cle(genre, numero)
                if ordre == 'ignore':
                    self.ignores.add(cle)
                else:
                    self.ignores.discard(cle)
            return True
        if ordre in ('write_in', 'read_out'):
            for genre, numero in self._cibles(instruction['args']['cible']):
                if ordre == 'write_in':
                    if genre in (',', ';'):
                        return self._echec(
                            'WRITE IN ne s\'applique pas à un tableau.', ligne)
                    lu = self._lire_entree(ligne)
                    if lu is None:
                        return False
                    self._ecrire_variable(genre, numero, lu, ligne)
                else:
                    valeur = self._lire_variable(genre, numero, ligne)
                    if valeur is None:
                        return False
                    if isinstance(valeur, list):
                        for element in valeur:
                            self._ecrire(romain_intercal(
                                element, 32 if genre == ';' else 16) + '\n')
                    else:
                        self._ecrire(romain_intercal(
                            valeur, 32 if genre == ':' else 16) + '\n')
            return True
        if ordre == 'next':
            cible = instruction['args']['cible']
            index = self._index_depuis_label(cible)
            if index is None:
                return self._echec('NEXT vers l\'étiquette (%d) introuvable.'
                                   % cible, ligne)
            if len(self.pile_next) >= 80:
                return self._echec(
                    'Pile de NEXT saturée (80 adresses), comme dans INTERCAL-72.',
                    ligne)
            self.pile_next.append(self.index_courant)
            self.index_courant = index
            return True
        if ordre in ('resume', 'forget'):
            nombre = self._evaluer(instruction['args']['expression'], ligne)
            if nombre is None:
                return not self.termine
            if nombre > len(self.pile_next):
                return self._echec(
                    '%s %d alors que la pile ne contient que %d adresse(s).'
                    % (ordre.upper(), nombre, len(self.pile_next)), ligne)
            adresse = None
            for _ in range(nombre):
                adresse = self.pile_next.pop()
            if ordre == 'resume' and adresse is not None:
                self.index_courant = adresse
            return True
        if ordre in ('abstain', 'reinstate'):
            return self._abstenir(instruction['args']['cible'],
                                  ordre == 'abstain', ligne)
        return self._echec('Commande interne inconnue : « %s ».' % ordre, ligne)

    def _abstenir(self, cible, abstenir, ligne):
        cible = cible.strip()
        if cible.startswith('(') and cible.endswith(')'):
            etiquette = cible[1:-1].strip()
            if not etiquette.isdigit():
                return self._echec('Étiquette invalide : « %s ».' % cible, ligne)
            index = self._index_depuis_label(int(etiquette))
            if index is None:
                return self._echec('Étiquette (%s) introuvable.' % etiquette, ligne)
            self.instructions[index]['abstenu'] = abstenir
            return True
        for morceau in cible.split('+'):
            nom = morceau.strip().upper()
            if nom not in ABSTENTION_INTERCAL:
                return self._echec(
                    'Nom de commande inconnu pour ABSTAIN FROM : « %s ».'
                    % morceau.strip(), ligne)
            cherche = ABSTENTION_INTERCAL[nom]
            for instruction in self.instructions:
                if instruction['ordre'] == cherche:
                    instruction['abstenu'] = abstenir
        return True

    def _index_depuis_label(self, etiquette):
        for position, instruction in enumerate(self.instructions):
            if instruction['label'] == etiquette:
                return position
        return None

    def _lire_entree(self, ligne):
        """WRITE IN lit des chiffres épelés en toutes lettres (« ONE TWO » = 12).
        Les chiffres décimaux sont aussi acceptés, par commodité documentée."""
        while True:
            texte = self.entree.ligne()
            if texte is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'WRITE IN : plus aucune ligne à lire en entrée.', ligne, 1))
                self.termine = True
                self.arret_anormal = True
                return None
            propre = texte.strip()
            if not propre:
                continue
            if propre.isdigit():
                return int(propre)
            chiffres = []
            for mot in re.split(r'[\s,]+', propre.upper()):
                if not mot:
                    continue
                if mot in CHIFFRES_INTERCAL:
                    chiffres.append(CHIFFRES_INTERCAL[mot])
                else:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR,
                        'WRITE IN : « %s » n\'est pas un chiffre épelé '
                        '(OH, ONE…NINE).' % mot, ligne, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return None
            if chiffres:
                return int(''.join(chiffres))

    def _echec(self, message, ligne):
        self.diagnostiques.append(_diagnostic(SEVERITE_ERREUR, message, ligne, 1))
        self.message = message
        self.termine = True
        self.arret_anormal = True
        return False

    @property
    def position(self):
        return (self._ligne_courante, 1)

    def variables(self):
        retour = [{'name': '.%d' % n, 'value': str(v)}
                  for n, v in sorted(self.spots.items())][:20]
        retour += [{'name': ':%d' % n, 'value': str(v)}
                   for n, v in sorted(self.twospots.items())][:10]
        retour += [{'name': '%s%d' % (g, n), 'value': str(v)}
                   for g, t in ((',', self.tails), (';', self.hybrids))
                   for n, v in sorted(t.items())][:10]
        retour.append({'name': 'pile NEXT', 'value': str(len(self.pile_next))})
        retour.append({'name': 'variables IGNORE',
                       'value': ', '.join(sorted(self.ignores)) or 'aucune'})
        return retour

    def frames(self):
        return [{'file': self.chemin, 'line': self._ligne_courante,
                 'function': 'principal', 'level': 0}]


# =========================================================================
# SHAKESPEARE
# =========================================================================
# Lexique : le SIGNE vient du nom, chaque adjectif double la valeur. Vérifié sur
# l'exemple de la spécification : « a vile coward » = -2, « a brave tree » = +2.
NOMS_POSITIFS_SPL = frozenset("""
tree horse cat town purse sky squirrel rose father mother brother sister son
daughter kingdom hero summer day morning night sun moon star light flower garden
river mountain hill valley forest wood field meadow castle palace house home
town city village road path bridge tower wall door window roof gold silver jewel
crown throne sword shield banner feast banquet wine bread meat fruit apple bread
lamb dove eagle lion unicorn angel saint prophet king queen prince princess lord
lady knight squire page servant shepherd farmer sailor soldier captain friend
love heart mind soul spirit wisdom truth beauty joy peace hope faith virtue grace
mercy pity kindness honour glory praise song poem tale story play music dance
smile laugh kiss embrace blessing prayer heaven paradise
""".split())
NOMS_NEGATIFS_SPL = frozenset("""
coward villain traitor murderer liar fool jester idiot knave rogue rascal
scoundrel varlet wretch cur dog hound hog swine pig rat mouse serpent snake toad
frog wolf fox bear ape monkey ass donkey goat sheep crow raven vulture bat spider
fly worm insect beetle codpiece devil fiend demon ghost spirit witch warlock
monster ogre giant tyrant slave prisoner beggar thief pirate bandit enemy foe
stranger fool idiot blockhead dunce coward heartless gutless spineless
sickness plague pox disease wound sore scar poison venom bile gall rot rust dust
mud dirt filth rubbish garbage waste dung cesspit sewer grave tomb hell dungeon
prison chain fetter shackle noose gallows whip lash curse hex spell doom death
murder treason betrayal deceit fraud theft robbery sin vice crime shame disgrace
dishonour scorn contempt hatred anger rage fury spite malice envy greed lust pride
sorrow grief pain misery woe despair fear dread terror horror panic
""".split())
ADJECTIFS_POSITIFS_SPL = frozenset("""
brave handsome rich huge green peaceful large rural amazing bottomless
embroidered bluest clearest sweetest white red sweet fair warm sunny beautiful
mighty proud lovely good healthy honest noble gentle kind tender soft bright
shining golden silver crystal clear pure fresh young new fine fair pretty
splendid glorious magnificent excellent wonderful marvellous superb splendid
grand stately tall strong sturdy swift fleet nimble clever wise learned cunning
faithful loyal true honest upright righteous holy sacred blessed heavenly divine
angelic serene calm quiet still tranquil joyful merry cheerful happy glad
delightful pleasant pleasing charming winning lovable amiable gracious courteous
polite civil modest humble meek patient forbearing forgiving merciful compassionate
generous liberal bountiful plentiful abundant fertile fruitful productive
""".split())
ADJECTIFS_NEGATIFS_SPL = frozenset("""
vile lying stupid fatherless big smelly half-witted fat little stuffed misused
dusty old rotten black ugly foul filthy dirty filthy base vile abject mean low
poor wretched miserable sorry sad sorry sick diseased diseased leprous mangy
scabby scurvy foul loathsome hateful odious detestable abominable execrable
horrid horrible hideous monstrous deformed misshapen crooked bent twisted
gnarled withered shrivelled shrunk shrunken pale wan sallow sickly wan gaunt
thin lean skinny bony scrawny scraggy puny weak feeble frail fragile flimsy
slight slender tender soft limp flabby slack loose idle lazy slothful sluggish
slow dull dim dense thick heavy leaden clumsy awkward ungainly maladroit
foolish silly simple witless brainless mindless senseless senseless stupid
dull obtuse doltish asinine foolish crazy mad lunatic insane deranged distracted
frenzied wild fierce savage cruel brutal barbarous barbaric ruthless merciless
pitiless heartless cruel vicious malicious spiteful malignant malevolent evil
wicked sinful wicked naughty bad naughty false untrue unfaithful faithless
treacherous traitorous perfidious deceitful lying mendacious dishonest corrupt
venal crooked base vile low mean sordid squalid seedy shabby shoddy cheap
""".split())
OPERATIONS_SPL = {
    'sum': '+', 'difference': '-', 'product': '*', 'quotient': '/',
    'remainder': '%', 'square': '**2', 'cube': '**3',
}
COMPARAISONS_SPL = {
    'better': '>', 'worse': '<', 'bigger': '>', 'smaller': '<',
    'greater': '>', 'lesser': '<', 'happier': '>', 'sadder': '<',
    'fatter': '>', 'leaner': '<', 'prettier': '>', 'uglier': '<',
    'good': '==', 'bad': '!=', 'nice': '==', 'as': '==',
}


class Shakespeare(Moteur):
    """Une pièce de théâtre comme programme.

    Les personnages sont des variables numériques. Deux personnages au plus sont
    sur scène ; celui qui parle s'adresse à l'autre, et c'est l'INTERLOCUTEUR qui
    est modifié : « Thou art a vile coward » donne -2 à l'interlocuteur (le nom
    « coward » vaut -1, l'adjectif « vile » double). « Speak your mind » imprime
    l'interlocuteur comme caractère, « Open your heart » sa valeur numérique,
    « Open your mind » lit un caractère, « Listen to your heart » un nombre.
    Les scènes servent d'étiquettes de saut.
    """

    langage = 'shakespeare'
    libelle = 'Shakespeare'
    extension = '.spl'

    def __init__(self, code, entree='', chemin=None):
        super(Shakespeare, self).__init__(code, entree, chemin)
        self.titre = ''
        self.personnages = {}
        self.valeurs = {}
        self.piles = {}
        self.scenes = {}
        self.instructions = []
        self.index_courant = 0
        self.sur_scene = []
        self._ligne_courante = 1
        self._locuteur = None
        self._condition = False

    # -- chargement ----------------------------------------------------------
    def charger(self):
        self.personnages = {}
        self.scenes = {}
        self.instructions = []
        diagnostics = []
        titre_vu = False
        acte_vu = False
        acte_courant = 0
        scene_courante = 0
        for numero, ligne in enumerate(self.code.split('\n'), start=1):
            propre = ligne.strip()
            if not propre:
                continue
            m = re.match(r'^Act\s+([IVXLCDM]+)\s*:\s*(.*)$', propre, re.I)
            if m:
                acte_courant += 1
                scene_courante = 0
                acte_vu = True
                continue
            m = re.match(r'^Scene\s+([IVXLCDM]+)\s*:\s*(.*)$', propre, re.I)
            if m:
                scene_courante += 1
                self.scenes[scene_courante] = len(self.instructions)
                self.scenes[(acte_courant, scene_courante)] = len(self.instructions)
                acte_vu = True
                continue
            if not acte_vu:
                # Avant le premier acte : la PREMIÈRE ligne non vide est le
                # titre, toutes les suivantes sont des présentations de
                # personnages. Marquer titre_vu sur le titre lui-même cassait
                # l'analyse des présentations : chaque « Romeo, a young man. »
                # était alors pris pour une réplique.
                if not titre_vu:
                    titre_vu = True
                    self.titre = propre.rstrip('.')
                    continue
                m = re.match(r'^([A-Z][A-Za-z\']*)\s*,\s*(.+?)\.?$', propre)
                if m:
                    self.personnages[m.group(1)] = m.group(2).strip()
                    self.valeurs[m.group(1)] = 0
                    self.piles[m.group(1)] = []
                else:
                    diagnostics.append(_diagnostic(
                        SEVERITE_AVIS,
                        'Ligne ignorée avant le premier acte : « %s ».'
                        % propre[:50], numero, 1))
                continue
            for morceau in self._decouper_statuts(propre):
                ordre = self._analyser_statut(morceau, numero, diagnostics)
                if ordre is not None:
                    self.instructions.append((numero,) + ordre)
        if not self.personnages:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR,
                'Aucun personnage présenté. Chaque ligne de présentation suit le '
                'modèle « Romeo, a young man with a remarkable patience. »', 1, 1))
        if not self.scenes:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Aucune scène : il en faut au moins une.', 1, 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    @staticmethod
    def _decouper_statuts(texte):
        """Découpe une ligne en statuts, sur « . » et « ! », hors crochets."""
        morceaux = []
        tampon = ''
        dans_crochets = False
        for c in texte:
            if c == '[':
                dans_crochets = True
            elif c == ']':
                dans_crochets = False
            if c in '.!' and not dans_crochets:
                if tampon.strip():
                    morceaux.append(tampon.strip())
                tampon = ''
            else:
                tampon += c
        if tampon.strip():
            morceaux.append(tampon.strip())
        return morceaux

    def _analyser_statut(self, texte, numero, diagnostics):
        bas = texte.lower().strip()
        m = re.match(r'^\[?\s*enter\s+([a-z\']+)(?:\s+and\s+([a-z\']+))?\s*\]?$', bas)
        if m:
            return ('entrer', m.group(1), m.group(2))
        if re.match(r'^\[?\s*exeunt\s*\]?$', bas):
            return ('exeunt',)
        m = re.match(r'^\[?\s*exit\s+([a-z\']+)\s*\]?$', bas)
        if m:
            return ('sortir', m.group(1))
        m = re.match(r'^([a-z\']+)\s*:$', bas)
        if m:
            return ('parle', m.group(1))
        if bas in ('speak your mind', 'speak thy mind'):
            return ('imprimer_caractere',)
        if bas in ('open your heart', 'open thy heart'):
            return ('imprimer_nombre',)
        if bas in ('open your mind', 'open thy mind'):
            return ('lire_caractere',)
        if bas in ('listen to your heart', 'listen to thy heart'):
            return ('lire_nombre',)
        if bas in ('remember', 'remember me'):
            return ('empiler',)
        if bas in ('recall', 'recall me'):
            return ('depiler',)
        m = re.match(r'^if so,?\s*let us (?:proceed|return)\s+to\s+(.+)$', bas)
        if m:
            return ('saut_si_vrai', m.group(1).strip())
        m = re.match(r'^let us (?:proceed|return)\s+to\s+(.+)$', bas)
        if m:
            return ('saut', m.group(1).strip())
        m = re.match(r'^am i (.+?) than (?:you|thee)\??$', bas)
        if m:
            return ('comparer', m.group(1).strip(), False)
        m = re.match(r'^am i as (.+?) as (?:you|thee)\??$', bas)
        if m:
            return ('comparer', m.group(1).strip(), True)
        m = re.match(r'^(?:you are|thou art)\s+(.+)$', bas)
        if m:
            # On garde la casse d'origine : les noms de personnages sont
            # capitalisés et le lexique est en minuscules.
            return ('assigner', m.group(1))
        diagnostics.append(_diagnostic(
            SEVERITE_ERREUR,
            'Réplique non reconnue : « %s ».' % texte[:70], numero, 1))
        return None

    # -- expressions ---------------------------------------------------------
    def _valeur_expression(self, texte, ligne):
        """Évalue une expression SPL : constante, simile, opération ou personnage."""
        texte = texte.strip().rstrip('.!?').strip()
        m = re.match(r'^as\s+\w+\s+as\s+(.+)$', texte, re.I)
        if m:
            # Une simile « as lovely as X » ne change rien : elle vaut X.
            return self._valeur_expression(m.group(1), ligne)
        return self._operation_ou_constante(texte, ligne)

    def _operation_ou_constante(self, texte, ligne):
        bas = texte.lower()
        m = re.match(r'^the\s+(\w+)\s+(?:of|between)\s+(.+)$', bas)
        if m and m.group(1) in OPERATIONS_SPL:
            operation = OPERATIONS_SPL[m.group(1)]
            reste = texte[len(m.group(0)) - len(m.group(2)):]
            parties = self._separer_et(reste)
            if operation == '**2' or operation == '**3':
                if len(parties) != 1:
                    return self._echec_spl(
                        '« the %s of » attend un seul opérande.' % m.group(1), ligne)
                base = self._valeur_expression(parties[0], ligne)
                if base is None:
                    return None
                return borne(base ** 2 if operation == '**2' else base ** 3,
                             'le résultat')
            if len(parties) != 2:
                return self._echec_spl(
                    '« the %s of » attend deux opérandes séparés par « and ».'
                    % m.group(1), ligne)
            gauche = self._valeur_expression(parties[0], ligne)
            droite = self._valeur_expression(parties[1], ligne)
            if gauche is None or droite is None:
                return None
            if operation == '+':
                return gauche + droite
            if operation == '-':
                return gauche - droite
            if operation == '*':
                return borne(gauche * droite, 'le résultat')
            if operation == '/':
                if droite == 0:
                    return self._echec_spl('Division par zéro.', ligne)
                return int(gauche / droite)
            if droite == 0:
                return self._echec_spl('Reste par zéro.', ligne)
            return gauche % droite
        return self._constante(texte, ligne)

    @staticmethod
    def _separer_et(texte):
        """Coupe sur le « and » de plus haut niveau (hors expression imbriquée)."""
        mots = texte.split()
        profondeur = 0
        for position, mot in enumerate(mots):
            if mot.lower() in ('sum', 'difference', 'product', 'quotient') \
                    and position > 0 and mots[position - 1].lower() == 'the':
                profondeur += 1
            if mot.lower() == 'and':
                if profondeur > 0:
                    profondeur -= 1
                else:
                    return [' '.join(mots[:position]), ' '.join(mots[position + 1:])]
        return [texte]

    def _constante(self, texte, ligne):
        """Personnage, ou nom précédé d'adjectifs (chaque adjectif double)."""
        bas = texte.lower().strip()
        bas = re.sub(r'^(a|an|the|my|your|thy|his|her|their|our)\s+', '', bas)
        if bas in ('yourself', 'thyself', 'you', 'thee'):
            return self._interlocuteur_valeur(ligne)
        if bas in ('myself', 'me', 'i'):
            return self._locuteur_valeur(ligne)
        nom = self._chercher_personnage(bas)
        if nom:
            return self.valeurs[nom]
        mots = re.findall(r"[a-z']+(?:-[a-z]+)*", bas)
        if not mots:
            return self._echec_spl('Expression incompréhensible : « %s ».' % texte,
                                   ligne)
        nom_final = mots[-1]
        nom_final = self._racine(nom_final)
        if nom_final in NOMS_POSITIFS_SPL:
            signe = 1
        elif nom_final in NOMS_NEGATIFS_SPL:
            signe = -1
        else:
            return self._echec_spl(
                'Nom « %s » absent du lexique positif ou négatif.' % nom_final,
                ligne)
        MOTS_OUTILS = ('a', 'an', 'the', 'my', 'your', 'thy', 'his', 'her',
                       'of', 'and', 'most', 'more', 'so', 'as')
        adjectifs = [self._racine(m) for m in mots[:-1]
                     if self._racine(m) not in MOTS_OUTILS]
        return signe * (2 ** len(adjectifs))

    @staticmethod
    def _racine(mot):
        """Retire les marques de superlatif et de pluriel les plus courantes."""
        for suffixe in ('est', 'er'):
            if mot.endswith(suffixe) and len(mot) > len(suffixe) + 2:
                return mot[:-len(suffixe)]
        if mot.endswith('s') and not mot.endswith('ss') and len(mot) > 3:
            return mot[:-1]
        return mot

    def _chercher_personnage(self, texte):
        for nom in self.personnages:
            if texte == nom.lower() or texte.endswith(' ' + nom.lower()):
                return nom
        return None

    def _interlocuteur(self, ligne):
        if len(self.sur_scene) < 2:
            return self._echec_spl(
                'Deux personnages doivent être sur scène pour qu\'il y ait un '
                'interlocuteur.', ligne)
        return self.sur_scene[1] if self.sur_scene[0] == self._locuteur else \
            self.sur_scene[0]

    def _interlocuteur_valeur(self, ligne):
        """Valeur numérique de l'interlocuteur, pour « yourself »/« thyself »."""
        cible = self._interlocuteur(ligne)
        if cible is None:
            return None
        return self.valeurs.get(cible, 0)

    def _locuteur_valeur(self, ligne):
        """Valeur du locuteur, pour « myself »/« me »."""
        return self.valeurs.get(self._locuteur, 0)

    def _echec_spl(self, message, ligne):
        self.diagnostiques.append(_diagnostic(SEVERITE_ERREUR, message, ligne, 1))
        self.message = message
        self.termine = True
        self.arret_anormal = True
        return None

    # -- exécution -----------------------------------------------------------
    def pas(self):
        if self.termine:
            return False
        if not self.instructions and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        if self.index_courant >= len(self.instructions):
            self.termine = True
            return False
        self.pas_fait += 1
        instruction = self.instructions[self.index_courant]
        self._ligne_courante = instruction[0]
        self.index_courant += 1
        return self._executer(instruction)

    def _executer(self, instruction):
        ordre = instruction[1]
        ligne = instruction[0]
        if ordre == 'entrer':
            for nom in instruction[2:]:
                if nom:
                    cle = self._resoudre(nom, ligne)
                    if cle is None:
                        return False
                    if cle not in self.sur_scene:
                        if len(self.sur_scene) >= 2:
                            return self._echec_spl_retour(
                                'Trois personnages sur scène : deux au maximum.',
                                ligne)
                        self.sur_scene.append(cle)
            return True
        if ordre == 'sortir':
            cle = self._resoudre(instruction[2], ligne)
            if cle is None:
                return False
            if cle in self.sur_scene:
                self.sur_scene.remove(cle)
            return True
        if ordre == 'exeunt':
            self.sur_scene = []
            return True
        if ordre == 'parle':
            cle = self._resoudre(instruction[2], ligne)
            if cle is None:
                return False
            self._locuteur = cle
            if cle not in self.sur_scene:
                self.sur_scene.append(cle)
            return True
        if ordre == 'assigner':
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            valeur = self._valeur_expression(instruction[2], ligne)
            if valeur is None:
                return not self.termine
            self.valeurs[cible] = valeur
            return True
        if ordre in ('imprimer_caractere', 'imprimer_nombre'):
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            valeur = self.valeurs[cible]
            if ordre == 'imprimer_caractere':
                self._ecrire(chr(valeur % 256) if valeur >= 0 else '')
            else:
                self._ecrire('%d\n' % valeur)
            return True
        if ordre in ('lire_caractere', 'lire_nombre'):
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            if ordre == 'lire_caractere':
                c = self.entree.caractere()
                if c is None:
                    return self._echec_spl_retour(
                        'Plus aucun caractère à lire en entrée.', ligne)
                self.valeurs[cible] = ord(c)
            else:
                n = self.entree.nombre()
                if n is None:
                    return self._echec_spl_retour(
                        'Plus aucun nombre à lire en entrée.', ligne)
                self.valeurs[cible] = n
            return True
        if ordre == 'empiler':
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            self.piles.setdefault(cible, []).append(self.valeurs[cible])
            return True
        if ordre == 'depiler':
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            pile = self.piles.setdefault(cible, [])
            if not pile:
                return self._echec_spl_retour(
                    'Recall : la pile de %s est vide.' % cible, ligne)
            self.valeurs[cible] = pile.pop()
            return True
        if ordre == 'comparer':
            cible = self._interlocuteur(ligne)
            if cible is None:
                return False
            comparateur = self._comparateur(instruction[2], instruction[3], ligne)
            if comparateur is None:
                return False
            gauche = self.valeurs.get(self._locuteur, 0)
            droite = self.valeurs.get(cible, 0)
            self._condition = self._comparer(gauche, comparateur, droite)
            return True
        if ordre in ('saut', 'saut_si_vrai'):
            if ordre == 'saut_si_vrai' and not getattr(self, '_condition', False):
                return True
            cible = self._index_scene(instruction[2], ligne)
            if cible is None:
                return False
            self.index_courant = cible
            return True
        return self._echec_spl_retour('Instruction interne inconnue : « %s ».'
                                       % ordre, ligne)

    def _echec_spl_retour(self, message, ligne):
        self._echec_spl(message, ligne)
        return False

    def _comparateur(self, mot, egalite, ligne):
        base = mot.lower().strip().rstrip('?')
        base = re.sub(r'^as\s+|\s+as$', '', base)
        # Chercher d'abord la forme LITTÉRALE : « better » figure tel quel dans
        # la table. Retirer « er » avant la recherche le transformait en « bett »
        # et faisait échouer toutes les comparaisons en -er.
        if base in COMPARAISONS_SPL:
            return COMPARAISONS_SPL[base]
        racine = base
        for suffixe in ('est', 'er'):
            if racine.endswith(suffixe):
                racine = racine[:-len(suffixe)]
                break
        if racine in COMPARAISONS_SPL:
            return COMPARAISONS_SPL[racine]
        if egalite:
            return '=='
        if base in ('good', 'nice', 'well', 'fair', 'sweet'):
            return '=='
        return self._echec_spl('Comparaison inconnue : « %s ».' % mot, ligne)

    @staticmethod
    def _comparer(gauche, comparateur, droite):
        if comparateur == '>':
            return gauche > droite
        if comparateur == '<':
            return gauche < droite
        if comparateur == '>=':
            return gauche >= droite
        if comparateur == '<=':
            return gauche <= droite
        if comparateur == '!=':
            return gauche != droite
        return gauche == droite

    def _index_scene(self, cible, ligne):
        texte = cible.strip().rstrip('.').lower()
        m = re.search(r'scene\s+([ivxlcdm]+)', texte)
        scene = self._romain(m.group(1)) if m else None
        m2 = re.search(r'act\s+([ivxlcdm]+)', texte)
        acte = self._romain(m2.group(1)) if m2 else None
        if scene is not None:
            cle = (acte, scene) if acte is not None else None
            if cle in self.scenes:
                return self.scenes[cle]
            if scene in self.scenes:
                return self.scenes[scene]
        return self._echec_spl('Scène introuvable : « %s ».' % cible, ligne)

    @staticmethod
    def _romain(texte):
        valeurs = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}
        total = 0
        precedent = 0
        for c in reversed(texte.upper()):
            if c not in valeurs:
                return None
            v = valeurs[c]
            total += -v if v < precedent else v
            precedent = max(precedent, v)
        return total

    def _resoudre(self, nom, ligne):
        for cle in self.personnages:
            if cle.lower() == nom.lower():
                return cle
        return self._echec_spl('Personnage « %s » jamais présenté.' % nom, ligne)

    @property
    def position(self):
        return (self._ligne_courante, 1)

    def variables(self):
        retour = [{'name': nom,
                   'value': _texte_entier(self.valeurs.get(nom, 0))}
                  for nom in sorted(self.personnages)]
        retour.append({'name': 'sur scène',
                       'value': ' et '.join(self.sur_scene) or 'personne'})
        retour.append({'name': 'locuteur',
                       'value': getattr(self, '_locuteur', 'aucun')})
        return retour

    def frames(self):
        return [{'file': self.chemin, 'line': self._ligne_courante,
                 'function': 'pièce', 'level': 0}]


# =========================================================================
# PIET
# =========================================================================
# Les 18 couleurs « vives » : 6 teintes x 3 luminosités, dans l'ordre de la
# spécification. Les valeurs RVB exactes sont imposées par le langage.
TEINTES_PIET = ('rouge', 'jaune', 'vert', 'cyan', 'bleu', 'magenta')
LUMINOSITES_PIET = ('claire', 'normale', 'sombre')
COULEURS_PIET = {
    (0, 0): (0xFF, 0xC0, 0xC0), (1, 0): (0xFF, 0xFF, 0xC0),
    (2, 0): (0xC0, 0xFF, 0xC0), (3, 0): (0xC0, 0xFF, 0xFF),
    (4, 0): (0xC0, 0xC0, 0xFF), (5, 0): (0xFF, 0xC0, 0xFF),
    (0, 1): (0xFF, 0x00, 0x00), (1, 1): (0xFF, 0xFF, 0x00),
    (2, 1): (0x00, 0xFF, 0x00), (3, 1): (0x00, 0xFF, 0xFF),
    (4, 1): (0x00, 0x00, 0xFF), (5, 1): (0xFF, 0x00, 0xFF),
    (0, 2): (0xC0, 0x00, 0x00), (1, 2): (0xC0, 0xC0, 0x00),
    (2, 2): (0x00, 0xC0, 0x00), (3, 2): (0x00, 0xC0, 0xC0),
    (4, 2): (0x00, 0x00, 0xC0), (5, 2): (0xC0, 0x00, 0xC0),
}
PIET_PAR_RVB = {v: k for k, v in COULEURS_PIET.items()}
BLANC_PIET = (0xFF, 0xFF, 0xFF)
NOIR_PIET = (0x00, 0x00, 0x00)

# Les 17 commandes. Indice : (changement de teinte, changement de luminosité),
# les deux mesurés dans le sens DIRECT et cyclique. La case (0, 0) ne fait rien,
# et la colonne « luminosité 0 » N'EST PAS vide : elle porte add, divide,
# greater, duplicate et in(char). C'est le point le plus facile à rater.
COMMANDES_PIET = {
    (0, 1): 'push', (0, 2): 'pop',
    (1, 0): 'add', (1, 1): 'subtract', (1, 2): 'multiply',
    (2, 0): 'divide', (2, 1): 'mod', (2, 2): 'not',
    (3, 0): 'greater', (3, 1): 'pointer', (3, 2): 'switch',
    (4, 0): 'duplicate', (4, 1): 'roll', (4, 2): 'in_nombre',
    (5, 0): 'in_caractere', (5, 1): 'out_nombre', (5, 2): 'out_caractere',
}
LIBELLES_PIET = {
    'push': 'push (empile la taille du bloc)', 'pop': 'pop',
    'add': 'add', 'subtract': 'subtract', 'multiply': 'multiply',
    'divide': 'divide', 'mod': 'mod', 'not': 'not', 'greater': 'greater',
    'pointer': 'pointer (tourne le DP)', 'switch': 'switch (bascule le CC)',
    'duplicate': 'duplicate', 'roll': 'roll',
    'in_nombre': 'in(number)', 'in_caractere': 'in(char)',
    'out_nombre': 'out(number)', 'out_caractere': 'out(char)',
    'rien': 'aucune (même couleur)', 'blanc': 'traversée de blanc',
}
# DP : 0=droite, 1=bas, 2=gauche, 3=haut (rotation horaire).
VECTEURS_PIET = ((1, 0), (0, 1), (-1, 0), (0, -1))
NOMS_DP_PIET = ('droite', 'bas', 'gauche', 'haut')
# Valeur renvoyée par _bloc_suivant quand le pas sort de l'image : le programme
# se termine. À ne pas confondre avec -1, qui signifie « obstacle, basculer ».
HORS_IMAGE_PIET = -2


def decoder_png(donnees):
    """Décode un PNG en grille RVB, sans aucune dépendance externe.

    Renvoie (largeur, hauteur, pixels) où pixels est une liste de lignes de
    triplets. Gère les types de couleur 0, 2, 3, 4 et 6, les profondeurs 1, 2,
    4, 8 et 16 bits, et les cinq filtres de ligne.
    """
    import struct
    import zlib
    if donnees[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('Signature PNG absente.')
    position = 8
    ihdr = None
    palette = []
    idat = []
    while position + 8 <= len(donnees):
        longueur = struct.unpack('>I', donnees[position:position + 4])[0]
        type_bloc = donnees[position + 4:position + 8]
        contenu = donnees[position + 8:position + 8 + longueur]
        position += 12 + longueur
        if type_bloc == b'IHDR':
            (largeur, hauteur, profondeur, couleur, _comp, _filtre,
             entrelace) = struct.unpack('>IIBBBBB', contenu)
            ihdr = (largeur, hauteur, profondeur, couleur, entrelace)
        elif type_bloc == b'PLTE':
            palette = [tuple(contenu[i:i + 3]) for i in range(0, len(contenu), 3)]
        elif type_bloc == b'IDAT':
            idat.append(contenu)
        elif type_bloc == b'IEND':
            break
    if ihdr is None:
        raise ValueError('Chunk IHDR introuvable.')
    largeur, hauteur, profondeur, couleur, entrelace = ihdr
    if entrelace:
        raise ValueError('PNG entrelacé (Adam7) non pris en charge.')
    brut = zlib.decompress(b''.join(idat))
    canaux = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[couleur]
    if profondeur == 16:
        octets_par_pixel = canaux * 2
    elif profondeur == 8:
        octets_par_pixel = canaux
    else:
        if couleur not in (0, 3):
            raise ValueError('Profondeur %d invalide pour ce type de couleur.'
                             % profondeur)
        octets_par_pixel = None
    if octets_par_pixel:
        pas_ligne = 1 + largeur * octets_par_pixel
    else:
        pixels_par_octet = 8 // profondeur
        pas_ligne = 1 + (largeur + pixels_par_octet - 1) // pixels_par_octet
    if len(brut) < pas_ligne * hauteur:
        raise ValueError('Données PNG tronquées : %d octets pour %d attendus.'
                         % (len(brut), pas_ligne * hauteur))

    # Dé-filtrage ligne par ligne.
    precedent = bytearray(pas_ligne - 1)
    lignes = []
    for y in range(hauteur):
        base = y * pas_ligne
        filtre = brut[base]
        courante = bytearray(brut[base + 1:base + pas_ligne])
        bpp = octets_par_pixel or 1
        for i in range(len(courante)):
            a = courante[i - bpp] if i >= bpp else 0
            b = precedent[i]
            c = precedent[i - bpp] if i >= bpp else 0
            if filtre == 1:
                courante[i] = (courante[i] + a) & 0xFF
            elif filtre == 2:
                courante[i] = (courante[i] + b) & 0xFF
            elif filtre == 3:
                courante[i] = (courante[i] + ((a + b) >> 1)) & 0xFF
            elif filtre == 4:
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                courante[i] = (courante[i] + pr) & 0xFF
            elif filtre != 0:
                raise ValueError('Type de filtre inconnu : %d.' % filtre)
        lignes.append(courante)
        precedent = courante

    pixels = []
    masque = (1 << profondeur) - 1
    for y in range(hauteur):
        ligne = lignes[y]
        pixels.append([])
        for x in range(largeur):
            if profondeur >= 8:
                if profondeur == 16:
                    i = x * canaux * 2
                    valeurs = [struct.unpack('>H', ligne[i + k * 2:i + k * 2 + 2])[0]
                               >> 8 for k in range(canaux)]
                else:
                    i = x * canaux
                    valeurs = list(ligne[i:i + canaux])
            else:
                par_octet = 8 // profondeur
                i = x // par_octet
                decalage = (par_octet - 1 - (x % par_octet)) * profondeur
                valeurs = [(ligne[i] >> decalage) & masque]
            if couleur == 0:
                g = valeurs[0]
                pixels[y].append((g, g, g))
            elif couleur == 2:
                pixels[y].append(tuple(valeurs[:3]))
            elif couleur == 3:
                index = valeurs[0]
                pixels[y].append(palette[index] if index < len(palette)
                                 else BLANC_PIET)
            elif couleur == 4:
                g = valeurs[0]
                pixels[y].append((g, g, g))
            else:
                pixels[y].append(tuple(valeurs[:3]))
    return largeur, hauteur, pixels


class Piet(Moteur):
    """Le programme EST une image : une peinture abstraite exécutable.

    Vingt couleurs, dont 18 reliées par un cycle de teinte et un cycle de
    luminosité. Le pointeur de direction (DP) part du bloc contenant le codel le
    plus en haut à gauche, orienté à droite ; le sélecteur de codel (CC) part à
    gauche. La commande exécutée dépend du CHANGEMENT de teinte et de luminosité
    entre le bloc quitté et le bloc rejoint, jamais de la couleur elle-même.
    Les blocs blancs se traversent sans commande, les noirs sont infranchissables
    ; quand les huit états DP x CC sont épuisés sans issue, le programme
    s'arrête — c'est la seule façon de terminer.
    """

    langage = 'piet'
    libelle = 'Piet'
    extension = '.png'
    graphique = True

    def __init__(self, code, entree='', chemin=None, taille_codel=None):
        # Le « code » d'un programme Piet est binaire : on ne le convertit PAS
        # en texte. On accepte des octets, un chemin, du base64 ou du texte brut.
        self.code = code
        self.entree = _Entree(entree)
        self.chemin = chemin or 'programme.png'
        self.taille_codel = taille_codel
        self._sortie = []
        self._taille_sortie = 0
        self.termine = False
        self.pas_fait = 0
        self.arret_anormal = False
        self.message = ''
        self.diagnostiques = []
        self.largeur = 0
        self.hauteur = 0
        self.pixels = []
        self.blocs = []
        self.index_bloc = 0
        self.grille_blocs = []
        self.dp = 0
        self.cc = 0
        self.pile = []
        self.commande = 'rien'
        self._tentatives = 0

    # -- chargement ----------------------------------------------------------
    def _octets(self):
        code = self.code
        if isinstance(code, bytes):
            return code
        if isinstance(code, str):
            if code[:5] == '\x89PNG':
                return code.encode('latin-1')
            import os
            if os.path.isfile(code):
                with open(code, 'rb') as fichier:
                    return fichier.read()
            propre = code.strip()
            # « data:image/png;base64,.... » : c'est sous cette forme que
            # l'aperçu et l'inspecteur visuel transmettent l'image.
            if propre.startswith('data:'):
                propre = propre.split(',', 1)[1] if ',' in propre else ''
            propre = ''.join(propre.split())
            try:
                import base64
                return base64.b64decode(propre, validate=True)
            except Exception:
                pass
            try:
                return code.encode('latin-1')
            except Exception:
                raise ValueError('Source Piet illisible.')
        raise ValueError('Source Piet d\'un type inattendu : %s.' % type(code))

    def charger(self):
        self.blocs = []
        self.grille_blocs = []
        diagnostics = []
        try:
            donnees = self._octets()
            self.largeur, self.hauteur, self.pixels = decoder_png(donnees)
        except ValueError as exc:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Image PNG illisible : %s' % exc, 1, 1))
            self._erreurs_chargement = diagnostics
            return diagnostics
        except Exception as exc:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Décodage PNG impossible : %s' % exc, 1, 1))
            self._erreurs_chargement = diagnostics
            return diagnostics
        if self.largeur == 0 or self.hauteur == 0:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Image de taille nulle.', 1, 1))
        taille = self.taille_codel or self._deviner_codel()
        self.taille_codel = taille
        self._construire_blocs(taille)
        inconnues = self._couleurs_inconnues()
        if inconnues:
            for rvb, compte in inconnues[:8]:
                diagnostics.append(_diagnostic(
                    SEVERITE_AVIS,
                    'Couleur #%02X%02X%02X (%d codel) hors des 20 couleurs de '
                    'Piet : traitée comme blanche.' % (rvb[0], rvb[1], rvb[2],
                                                       compte), 1, 1))
        if not self.blocs:
            diagnostics.append(_diagnostic(
                SEVERITE_ERREUR, 'Aucun bloc de couleur reconnu.', 1, 1))
        self._erreurs_chargement = diagnostics
        return diagnostics

    def _deviner_codel(self):
        """Déduit la taille d'un codel : le plus grand diviseur commun des runs
        horizontaux et verticaux de couleur identique, borné raisonnablement."""
        plus_petit = None
        for y in range(min(self.hauteur, 40)):
            run = 1
            for x in range(1, self.largeur):
                if self.pixels[y][x] == self.pixels[y][x - 1]:
                    run += 1
                else:
                    plus_petit = run if plus_petit is None \
                        else min(plus_petit, run)
                    run = 1
            plus_petit = run if plus_petit is None else min(plus_petit, run)
        for x in range(min(self.largeur, 40)):
            run = 1
            for y in range(1, self.hauteur):
                if self.pixels[y][x] == self.pixels[y - 1][x]:
                    run += 1
                else:
                    plus_petit = run if plus_petit is None \
                        else min(plus_petit, run)
                    run = 1
            plus_petit = run if plus_petit is None else min(plus_petit, run)
        return max(1, min(plus_petit or 1, 64))

    def _couleur_classe(self, rvb):
        """(teinte, luminosite) ou 'blanc' / 'noir'."""
        if rvb == BLANC_PIET:
            return 'blanc'
        if rvb == NOIR_PIET:
            return 'noir'
        if rvb in PIET_PAR_RVB:
            teinte, luminosite = PIET_PAR_RVB[rvb]
            return (luminosite, teinte)
        return 'blanc'

    def couleurs_inconnues(self):
        """Les couleurs de l'image qui ne sont pas dans la palette de Piet.

        Liste de couples ((r, v, b), nombre de pixels), du plus fréquent au plus
        rare. Accès public : c'est le seul moyen fiable de distinguer un
        programme Piet d'une image ordinaire qui contiendrait par hasard un
        rouge pur — l'aperçu s'en sert pour décider s'il ouvre la page Piet.
        """
        return self._couleurs_inconnues()

    def _couleurs_inconnues(self):
        comptes = {}
        for ligne in self.pixels:
            for rvb in ligne:
                if rvb not in PIET_PAR_RVB and rvb not in (BLANC_PIET, NOIR_PIET):
                    comptes[rvb] = comptes.get(rvb, 0) + 1
        return sorted(comptes.items(), key=lambda kv: -kv[1])

    def _construire_blocs(self, taille):
        cols = max(1, (self.largeur + taille - 1) // taille)
        rows = max(1, (self.hauteur + taille - 1) // taille)
        self.grille_blocs = [[-1] * cols for _ in range(rows)]
        for cy in range(rows):
            for cx in range(cols):
                if self.grille_blocs[cy][cx] != -1:
                    continue
                px, py = cx * taille, cy * taille
                if px >= self.largeur or py >= self.hauteur:
                    continue
                rvb = self.pixels[py][px]
                classe = self._couleur_classe(rvb)
                # Regroupement par codel (et non par pixel) : on parcourt la
                # grille des codels en 4-connexité.
                pile = [(cx, cy)]
                membres = []
                self.grille_blocs[cy][cx] = -2
                while pile:
                    x, y = pile.pop()
                    membres.append((x, y))
                    for vx, vy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + vx, y + vy
                        if 0 <= nx < cols and 0 <= ny < rows \
                                and self.grille_blocs[ny][nx] == -1:
                            npx, npy = nx * taille, ny * taille
                            if npx < self.largeur and npy < self.hauteur \
                                    and self._couleur_classe(
                                        self.pixels[npy][npx]) == classe:
                                self.grille_blocs[ny][nx] = -2
                                pile.append((nx, ny))
                index = len(self.blocs)
                for x, y in membres:
                    self.grille_blocs[y][x] = index
                xmin = min(x for x, _y in membres)
                xmax = max(x for x, _y in membres)
                ymin = min(y for _x, y in membres)
                ymax = max(y for _x, y in membres)
                self.blocs.append({
                    'index': index, 'classe': classe, 'codels': membres,
                    'taille': len(membres), 'rvb': rvb,
                    'x0': xmin, 'x1': xmax, 'y0': ymin, 'y1': ymax,
                })

    def _bloc_depart(self):
        """Bloc contenant le codel le plus en haut à gauche."""
        for cy in range(len(self.grille_blocs)):
            for cx in range(len(self.grille_blocs[cy])):
                if self.grille_blocs[cy][cx] >= 0:
                    return self.grille_blocs[cy][cx]
        return None

    # -- déplacement ---------------------------------------------------------
    def _codel_cible(self, bloc):
        """Le codel du bloc d'où part le DP : le plus loin dans la direction du
        DP, puis départagé par le CC (à gauche du DP par défaut)."""
        dx, dy = VECTEURS_PIET[self.dp]
        if dx > 0:
            extreme = bloc['x1']
            candidats = [(x, y) for x, y in bloc['codels'] if x == extreme]
        elif dx < 0:
            extreme = bloc['x0']
            candidats = [(x, y) for x, y in bloc['codels'] if x == extreme]
        elif dy > 0:
            extreme = bloc['y1']
            candidats = [(x, y) for x, y in bloc['codels'] if y == extreme]
        else:
            extreme = bloc['y0']
            candidats = [(x, y) for x, y in bloc['codels'] if y == extreme]
        # Le CC est relatif au DP : « gauche » signifie 90° anti-horaire.
        cx, cy = VECTEURS_PIET[(self.dp + 3) % 4] if self.cc == 0 \
            else VECTEURS_PIET[(self.dp + 1) % 4]
        return max(candidats, key=lambda p: p[0] * cx + p[1] * cy)

    def _bloc_voisin(self, cx, cy):
        taille = self.taille_codel
        px, py = cx * taille, cy * taille
        if not (0 <= px < self.largeur and 0 <= py < self.hauteur):
            return -1
        return self.grille_blocs[cy][cx]

    def _bloc_suivant(self, bloc):
        """Algorithme canonique : depuis le codel choisi sur l'arête la plus
        loin dans le sens du DP, on avance d'un pas.

        Renvoie l'index du bloc suivant, HORS_IMAGE si le pas sort de l'image,
        et -1 si le pas tombe sur un bloc noir ou sur le bloc courant (dans ces
        deux cas le DP doit basculer de CC puis tourner).

        La distinction est essentielle : traiter la sortie d'image comme un
        simple obstacle déclenche la danse des huit états, qui rebondit vers la
        gauche et RÉEXÉCUTE des commandes parasites. Presque tout programme Piet
        réel se termine en sortant de l'image.
        """
        cx, cy = self._codel_cible(bloc)
        dx, dy = VECTEURS_PIET[self.dp]
        nx, ny = cx + dx, cy + dy
        lignes = len(self.grille_blocs)
        colonnes = len(self.grille_blocs[0]) if lignes else 0
        if not (0 <= nx < colonnes and 0 <= ny < lignes):
            return HORS_IMAGE_PIET
        index = self.grille_blocs[ny][nx]
        if index < 0 or index == bloc['index']:
            return -1
        if self.blocs[index]['classe'] == 'noir':
            return -1          # le noir est infranchissable : faire basculer
        return index

    # -- exécution -----------------------------------------------------------
    def pas(self):
        if self.termine:
            return False
        if not self.blocs and not self.diagnostiques:
            self.charger()
        if any(d['severity'] == SEVERITE_ERREUR
               for d in getattr(self, '_erreurs_chargement', [])):
            self.termine = True
            self.arret_anormal = True
            return False
        if not self.blocs:
            self.termine = True
            return False
        if self.pas_fait == 0:
            depart = self._bloc_depart()
            if depart is None:
                self.termine = True
                return False
            self.index_bloc = depart
        self.pas_fait += 1
        # Le DP essaie ses huit états ; s'il n'y a pas d'issue, le programme
        # s'arrête — c'est la seule sortie possible.
        for _tentative in range(8):
            suivant = self._bloc_suivant(self.blocs[self.index_bloc])
            if suivant == HORS_IMAGE_PIET:
                # Sortir de l'image termine le programme, sans commande parasite.
                self.termine = True
                self.commande = 'termine'
                return False
            if suivant >= 0:
                precedent = self.blocs[self.index_bloc]
                self.index_bloc = suivant
                bloc = self.blocs[suivant]
                self.commande = self._appliquer(precedent, bloc)
                return not self.termine
            self.cc = 1 - self.cc
            if self.cc == 0:
                self.dp = (self.dp + 1) % 4
        self.termine = True
        self.commande = 'termine'
        return False

    def _appliquer(self, precedent, bloc):
        if bloc['classe'] == 'blanc':
            return 'blanc'          # traversée sans commande
        if precedent['classe'] in ('blanc', 'noir'):
            return 'rien'           # sortir d'un blanc n'exécute rien
        teinte_avant, luminosite_avant = precedent['classe'][1], \
            precedent['classe'][0]
        teinte_apres, luminosite_apres = bloc['classe'][1], bloc['classe'][0]
        delta_teinte = (teinte_apres - teinte_avant) % 6
        delta_luminosite = (luminosite_apres - luminosite_avant) % 3
        commande = COMMANDES_PIET.get((delta_teinte, delta_luminosite))
        if commande is None:
            return 'rien'
        self._executer(commande, precedent)
        return commande

    def _manque(self, nombre, commande):
        if len(self.pile) < nombre:
            self.diagnostiques.append(_diagnostic(
                SEVERITE_ERREUR,
                '%s exige %d valeur(s) sur la pile, il y en a %d.'
                % (LIBELLES_PIET.get(commande, commande), nombre, len(self.pile)),
                1, 1))
            self.message = 'Pile trop petite pour %s.' % commande
            self.termine = True
            self.arret_anormal = True
            return True
        return False

    def _executer(self, commande, precedent):
        if commande == 'push':
            self.pile.append(precedent['taille'])
        elif commande == 'pop':
            if self._manque(1, commande):
                return
            self.pile.pop()
        elif commande in ('add', 'subtract', 'multiply', 'divide', 'mod',
                          'greater'):
            if self._manque(2, commande):
                return
            haut = self.pile.pop()
            second = self.pile.pop()
            if commande == 'add':
                self.pile.append(second + haut)
            elif commande == 'subtract':
                self.pile.append(second - haut)
            elif commande == 'multiply':
                self.pile.append(borne(second * haut, 'le résultat'))
            elif commande == 'divide':
                if haut == 0:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR, 'Division par zéro.', 1, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return
                self.pile.append(second // haut)
            elif commande == 'mod':
                if haut == 0:
                    self.diagnostiques.append(_diagnostic(
                        SEVERITE_ERREUR, 'Modulo par zéro.', 1, 1))
                    self.termine = True
                    self.arret_anormal = True
                    return
                self.pile.append(second % haut)
            else:
                self.pile.append(1 if second > haut else 0)
        elif commande == 'not':
            if self._manque(1, commande):
                return
            self.pile.append(0 if self.pile.pop() else 1)
        elif commande == 'pointer':
            if self._manque(1, commande):
                return
            n = self.pile.pop()
            self.dp = (self.dp + n) % 4
        elif commande == 'switch':
            if self._manque(1, commande):
                return
            n = abs(self.pile.pop())
            if n % 2:
                self.cc = 1 - self.cc
        elif commande == 'duplicate':
            if self._manque(1, commande):
                return
            self.pile.append(self.pile[-1])
        elif commande == 'roll':
            if self._manque(2, commande):
                return
            x = self.pile.pop()          # premier dépilé : le sommet
            y = self.pile.pop()          # second : la profondeur à rouler
            if y < 0 or y > len(self.pile):
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'roll : profondeur %d invalide pour une pile de %d.'
                    % (y, len(self.pile)), 1, 1))
                self.termine = True
                self.arret_anormal = True
                return
            if y > 0:
                portion = self.pile[-y:]
                decalage = x % y
                roulee = portion[-decalage:] + portion[:-decalage] \
                    if decalage else portion
                self.pile[-y:] = roulee
        elif commande == 'in_nombre':
            nombre = self.entree.nombre()
            if nombre is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'in(number) : plus aucun nombre à lire en entrée.', 1, 1))
                self.termine = True
                self.arret_anormal = True
                return
            self.pile.append(nombre)
        elif commande == 'in_caractere':
            c = self.entree.caractere()
            if c is None:
                self.diagnostiques.append(_diagnostic(
                    SEVERITE_ERREUR,
                    'in(char) : plus aucun caractère à lire en entrée.', 1, 1))
                self.termine = True
                self.arret_anormal = True
                return
            self.pile.append(ord(c))
        elif commande == 'out_nombre':
            if self._manque(1, commande):
                return
            self._ecrire('%d' % self.pile.pop())
        elif commande == 'out_caractere':
            if self._manque(1, commande):
                return
            self._ecrire(chr(self.pile.pop() % 1114112))

    # -- ce que voit le débogueur et l'inspecteur visuel ---------------------
    @property
    def position(self):
        if not self.blocs:
            return (1, 1)
        bloc = self.blocs[self.index_bloc]
        return (bloc['y0'] * self.taille_codel + 1,
                bloc['x0'] * self.taille_codel + 1)

    def bloc_actif(self):
        """Accroche pour l'inspecteur visuel : le bloc courant, sa couleur et la
        commande en cours, en coordonnées PIXELS pour pouvoir surligner l'image."""
        if not self.blocs:
            return None
        bloc = self.blocs[self.index_bloc]
        taille = self.taille_codel
        return {
            'index': bloc['index'],
            'taille': bloc['taille'],
            'rvb': '#%02X%02X%02X' % bloc['rvb'],
            'classe': str(bloc['classe']),
            'commande': self.commande,
            'libelle': LIBELLES_PIET.get(self.commande, self.commande),
            'dp': NOMS_DP_PIET[self.dp],
            'cc': 'gauche' if self.cc == 0 else 'droite',
            'rectangle': [bloc['x0'] * taille, bloc['y0'] * taille,
                          (bloc['x1'] + 1) * taille, (bloc['y1'] + 1) * taille],
        }

    def variables(self):
        retour = [{'name': 'pile (%d)' % len(self.pile),
                   'value': (_texte_valeurs(self.pile[-8:])
                              if self.pile else 'vide')}]
        retour.append({'name': 'pointeur de direction',
                       'value': NOMS_DP_PIET[self.dp]})
        retour.append({'name': 'sélecteur de codel',
                       'value': 'gauche' if self.cc == 0 else 'droite'})
        retour.append({'name': 'dernière commande',
                       'value': LIBELLES_PIET.get(self.commande, self.commande)})
        if self.blocs:
            bloc = self.blocs[self.index_bloc]
            retour.append({'name': 'bloc courant',
                           'value': '#%d, %d codel(s), %s'
                                    % (bloc['index'], bloc['taille'],
                                       '#%02X%02X%02X' % bloc['rvb'])})
        retour.append({'name': 'image',
                       'value': '%d×%d px, codel %d'
                                % (self.largeur, self.hauteur,
                                   self.taille_codel or 1)})
        return retour

    def frames(self):
        ligne, colonne = self.position
        return [{'file': self.chemin, 'line': ligne, 'function': 'bloc',
                 'level': 0}]


# =========================================================================
# Façade publique
# =========================================================================
# Le reste de Pascal Studio (registre, vérificateurs statiques, débogueur,
# complétion, aide) ne doit connaître QUE ces fonctions : il n'a jamais besoin
# d'instancier un moteur lui-même.

MOTEURS = {
    'brainfuck': Brainfuck,
    'fractran': Fractran,
    'whitespace': Whitespace,
    'malbolge': Malbolge,
    'arnoldc': ArnoldC,
    'lolcode': Lolcode,
    'chef': Chef,
    'intercal': Intercal,
    'shakespeare': Shakespeare,
    'piet': Piet,
}
# Ordre d'affichage dans l'aide et les onglets : du plus connu au plus rare.
ORDRE_ESOTERIQUES = ('brainfuck', 'whitespace', 'piet', 'lolcode', 'arnoldc',
                     'chef', 'shakespeare', 'intercal', 'fractran', 'malbolge')


def est_esoterique(kind):
    """Vrai si cet identifiant est l'un des dix langages ésotériques."""
    return str(kind or '').strip().lower() in MOTEURS


def moteur(kind):
    """La classe moteur d'un langage, ou None."""
    return MOTEURS.get(str(kind or '').strip().lower())


def liste_moteurs():
    """Les dix langages, dans l'ordre d'affichage, avec leurs métadonnées."""
    retour = []
    for identifiant in ORDRE_ESOTERIQUES:
        classe = MOTEURS[identifiant]
        retour.append({
            'langage': identifiant,
            'libelle': classe.libelle,
            'extension': classe.extension,
            'graphique': bool(getattr(classe, 'graphique', False)),
        })
    return retour


def analyser(code, kind, chemin=None):
    """Analyse statique : charge le programme SANS l'exécuter.

    Renvoie la liste de diagnostics du moteur, chacun avec les clefs
    « severity », « message », « line », « column ». Une liste vide signifie que
    le programme est syntaxiquement correct.
    """
    classe = moteur(kind)
    if classe is None:
        return []
    try:
        instance = classe(code, chemin=chemin)
        return instance.charger()
    except Exception as exc:                      # un moteur ne doit jamais
        return [_diagnostic(SEVERITE_ERREUR,      # faire tomber l'analyse
                            'Analyse impossible : %s' % exc, 1, 1)]


def executer(code, kind, entree='', limite=LIMITE_PAS, chemin=None):
    """Exécute un programme et renvoie le dictionnaire de résultat uniforme."""
    classe = moteur(kind)
    if classe is None:
        return {'ok': False, 'state': 'unsupported', 'output': '', 'sortie': '',
                'diagnostics': [], 'pas': 0, 'termine': True, 'langage': kind,
                'message': 'Aucun moteur pour « %s ».' % kind, 'erreur': ''}
    instance = classe(code, entree=entree, chemin=chemin)
    return instance.executer(limite=limite)


def pas_a_pas(code, kind, entree='', chemin=None):
    """Crée un moteur arrêté avant la première instruction.

    C'est ce que consomme le débogueur : les moteurs sont des machines à pas
    NATIVES, donc le débogage est réel — pas de prélude injecté, pas de tube
    nommé, aucune dépendance envers un interpréteur externe inexistant.
    """
    classe = moteur(kind)
    if classe is None:
        return None
    instance = classe(code, entree=entree, chemin=chemin)
    instance.charger()
    return instance


def apercu_programme(kind):
    """Un programme minimal valide, pour le bouton « essayer » de l'aide."""
    return APERCUS_ESOTERIQUES.get(str(kind or '').strip().lower(), '')


APERCUS_ESOTERIQUES = {
    # Le Hello World! canonique : 906 pas, « Hello World! ».
    'brainfuck':
        '++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]>>.'
        '>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>+'
        '+.',
    # Espace/Tabulation/Fin de ligne uniquement : le source est INVISIBLE.
        # Celui-ci empile 72 puis 105 et les imprime comme caractères -> « Hi ».
    'whitespace':
        '   \t  \t   \n\t\n     \t\t \t  \t\n\t\n  \n\n\n',
    # Le programme EST une image. Aperçu : un PNG 67x1 en data URI, qui
        # empille 65 (taille du bloc rouge) puis out(char) -> « A ».
    'piet':
        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEMAAAABCAIAAAAKOIRDAAAAEklEQVR42mP4z8Aw1NEBEPkfAJkjQ34qNXjxAAAAAElFTkSuQmCC',
    # Le seul Hello World connu, trouvé par recherche : 75 pas,
        # « Hello World! ». Aucun humain ne peut l’écrire à la main.
    'malbolge':
        "('&%:9]!~}|z2Vxwv-,POqponl$Hjig%eB@@>}=<M:9wv6WsU2T|"
        'nm-,jcL(I&%$#"`CB]V?Tx<uVtT`Rpo3NlF.Jh++FdbCBA@?]!~|'
        '4XzyTT43Qsqq(Lnmkj"Fhg${z@>',
    'lolcode':
        'HAI 1.2\n  VISIBLE "Hello, world!"\nKTHXBYE\n',
    'arnoldc':
        'IT\'S SHOWTIME\nTALK TO THE HAND "Hello, world!"\nYOU H'
        'AVE BEEN TERMINATED\n',
    # Les ingrédients sont en ml donc LIQUIDES : imprimés en caractères.
    'chef':
        'Hello World!.\n\nIngredients.\n72 ml h\n101 ml e\n108 ml '
        'l1\n108 ml l2\n111 ml o1\n32 ml sp\n119 ml w\n111 ml o2\n1'
        '14 ml r\n108 ml l3\n100 ml d\n33 ml bang\n\nMethod.\nPut b'
        'ang into the mixing bowl.\nPut d into the mixing bowl'
        '.\nPut l3 into the mixing bowl.\nPut r into the mixing'
        ' bowl.\nPut o2 into the mixing bowl.\nPut w into the m'
        'ixing bowl.\nPut sp into the mixing bowl.\nPut o1 into'
        ' the mixing bowl.\nPut l2 into the mixing bowl.\nPut l'
        '1 into the mixing bowl.\nPut e into the mixing bowl.\n'
        'Put h into the mixing bowl.\nPour contents of the mix'
        'ing bowl into the baking dish.\n\nServes 1.\n',
    # « a big big big big big big tree » = +64 (chaque adjectif
        # double), « a tree » = +1 ; la somme vaut 65 = « A », affectée à Juliet
        # — c’est l’INTERLOCUTEUR qui reçoit la valeur, jamais le locuteur.
    'shakespeare':
        'Hello.\n\nRomeo, a young man with a remarkable patienc'
        'e.\nJuliet, a likewise young woman of remarkable grac'
        'e.\n\nAct I: The only act.\n\nScene I: The only scene.\n\n'
        '[Enter Romeo and Juliet]\n\nRomeo:\n Thou art as good a'
        's the sum of a big big big big big big tree and a tr'
        'ee!\n Speak thy mind!\n\n[Exeunt]\n',
    # READ OUT écrit en chiffres romains : 72 -> LXXII, 33 -> XXXIII.
        # Deux PLEASE sur huit instructions : la politesse doit rester entre 1/5 et 1/3.
    'intercal':
        'DO .1 <- #72\nDO .2 <- #33\nPLEASE READ OUT .1\nDO .3 <'
        '- #0\nPLEASE READ OUT .2\nDO .1 <- #0\nDO .2 <- #0\nDO G'
        'IVE UP\n',
    'fractran':
        "# FRACTRAN n'imprime rien : le résultat est l'état n"
        ", visible\n# dans l'inspecteur de variables. Ici 2 ->"
        " 3 -> 1, puis aucune\n# fraction ne s'applique et le "
        "programme s'arrête.\nn = 2\n3/2\n1/3\n",
}
