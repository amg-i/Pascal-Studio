"""Conservative, non-executing LaTeX structure checks on the unsaved buffer.

This is not TeX: macro expansion, custom category codes, conditional branches,
external files and packages cannot be interpreted reliably. No commands run.
"""
import re

VERBATIM={'verbatim','verbatim*','lstlisting','lstlisting*','minted','minted*','Verbatim','Verbatim*'}
ENV_NAME=re.compile(r'[A-Za-z@][A-Za-z0-9@*:_-]*\Z')

def analyze(key,content):
 if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
 lines=content.splitlines(keepends=True); rows=[];groups=[];envs=[];math=None;verbatim=None
 def report(line,col,msg,severity='warning'):
  if len(rows)>=100:return
  # Monaco columns are UTF-16, not Python code points.
  text=lines[line-1] if line<=len(lines) else ''
  column=len(text[:col].encode('utf-16-le'))//2+1
  rows.append({'file':key,'line':line,'column':column,'severity':severity,'message':msg})
 for ln,line in enumerate(lines,1):
  if verbatim:
   end=re.search(r'\\end\s*\{\s*'+re.escape(verbatim)+r'\s*\}',line)
   if not end:continue
   verbatim=None;i=end.start()
  else:i=0
  while i<len(line):
   c=line[i]
   if c=='%':break
   if c=='\\':
    start=i;i+=1
    if i>=len(line) or line[i] in '\r\n':break
    if line[i].isalpha() or line[i]=='@':
     j=i+1
     while j<len(line) and (line[j].isalpha() or line[j]=='@'):j+=1
     command=line[i:j];i=j
     if command=='verb':
      if i<len(line) and line[i]=='*':i+=1
      if i<len(line) and line[i] not in '\r\n':
       delimiter=line[i];end=line.find(delimiter,i+1)
       if end<0:report(ln,start,'Commande \\verb probablement non terminée sur cette ligne.') ;break
       i=end+1
      continue
     if command in ('begin','end'):
      match=re.match(r'[ \t]*\{\s*([^{}\r\n]+?)\s*\}',line[i:])
      if match:
       name=match.group(1).strip()
       if ENV_NAME.fullmatch(name):
        i+=match.end()
        if command=='begin':
         envs.append((name,ln,start))
         if name in VERBATIM:
          ending=re.search(r'\\end\s*\{\s*'+re.escape(name)+r'\s*\}',line[i:])
          if ending:i+=ending.start();continue
          verbatim=name;break
        elif not envs:report(ln,start,'Environnement '+name+' fermé sans ouverture correspondante dans ce fichier.')
        elif envs[-1][0]==name:envs.pop()
        else:
         expected,opened,_=envs[-1]
         report(ln,start,'Environnement '+name+' fermé alors que '+expected+' (ligne '+str(opened)+') est encore ouvert.')
         # Resynchronize on a known opener, avoiding a cascade of misleading warnings.
         for n in range(len(envs)-1,-1,-1):
          if envs[n][0]==name:del envs[n:];break
       continue
     continue
    # An escaped non-letter is a control symbol: \%, \{, \}, \$, \\ etc.
    i+=1;continue
   if c=='{':groups.append((ln,i))
   elif c=='}':
    if groups:groups.pop()
    else:report(ln,i,'Accolade fermante sans accolade ouvrante dans ce fichier.')
   elif c=='$':
    marker='$$' if i+1<len(line) and line[i+1]=='$' else '$'
    if marker=='$$':i+=1
    if math is None:math=(marker,ln,i-(1 if marker=='$$' else 0))
    elif math[0]==marker:math=None
    else:report(ln,i,'Délimiteurs mathématiques $ et $$ probablement incompatibles.')
   i+=1
 for name,ln,col in envs:report(ln,col,'Environnement '+name+' ouvert mais non fermé dans ce fichier.')
 for ln,col in groups:report(ln,col,'Accolade ouvrante sans fermeture dans ce fichier.')
 if math:report(math[1],math[2],'Délimiteur mathématique '+math[0]+' ouvert mais non fermé dans ce fichier.')
 rows.sort(key=lambda x:(x['line'],x['column']))
 return {'state':'ready','diagnostics':rows,'ok':True,'message':'Structure LaTeX (analyse indicative, sans exécution) : '+str(len(rows))+' avertissement(s)'}
