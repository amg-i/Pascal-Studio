"""Compile one trusted .tex file with pdflatex into a private cache.
TeX is NOT sandboxed: even with shell escape disabled, it can read files.
"""
import os,re,secrets,shutil,subprocess,threading,hashlib
from pathlib import Path

class LatexManager:
 def __init__(self):self.lock=threading.RLock();self.entries={}
 def compile(self,root,build_dir,path,key,external_files):
  exe=shutil.which('pdflatex')
  if not exe:raise ValueError('Installez pdfLaTeX : sudo apt install texlive-latex-base')
  root=Path(root).resolve();path=Path(path).resolve();build_dir=Path(build_dir).resolve()
  if not path.is_file() or path.suffix.lower()!='.tex':raise ValueError('Choisissez un fichier .tex principal.')
  ident=secrets.token_urlsafe(18);work=build_dir/('latex-'+ident);work.mkdir(parents=True)
  cmd=[exe,'-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-file-line-error','-output-directory',str(work),str(path)]
  try:
   r=subprocess.run(cmd,cwd=path.parent,capture_output=True,text=True,encoding='utf8',errors='replace',timeout=90,env={**os.environ,'TERM':'dumb','max_print_line':'1000'})
   out=(r.stdout+r.stderr)[-2_000_000:];pdf=work/(path.stem+'.pdf');rows=[]
   for line in out.splitlines():
    match=re.match(r'^(.*?\.(?:tex|sty)):(\d+):\s*(.*)$',line,re.I)
    if not match:continue
    filename,row,msg=match.groups();f=Path(filename);f=(f if f.is_absolute() else path.parent/f).resolve()
    try:rel=f.relative_to(root).as_posix()
    except ValueError:
     rel=next((k for k,v in external_files.items() if Path(v).resolve()==f),'')
     if not rel and f.is_file():rel='@external:'+str(f);external_files[rel]=f
    if rel and not msg.startswith('==> Fatal error'):
     item={'file':rel,'line':int(row),'column':1,'severity':'error','message':msg}
     try:
      if f.stat().st_size<=2_000_000:item['sourceHash']=hashlib.sha256(f.read_bytes()).hexdigest()
     except OSError:pass
     rows.append(item)
   # pdfTeX sometimes reports the useful error on a ! line and only later gives
   # an unhelpful file:line: Emergency stop. Keep both the reason and location.
   detail=next((m.group(1).strip() for line in out.splitlines() if (m:=re.match(r'^!\s*(?:LaTeX Error:\s*)?(.+)',line)) and not m.group(1).startswith('==>')),None)
   if r.returncode and detail:
    anchor=next((x for x in rows if x['message'].startswith('Emergency stop')),rows[0] if rows else {'file':key,'line':1,'column':1,'severity':'error'})
    item={**anchor,'message':detail}
    # Missing packages often cause an emergency stop on the next input line.
    pkg=re.search(r"File [`']([^`']+\.sty)['`] not found",detail,re.I)
    if pkg and anchor['file']==key:
     try:
      package=Path(pkg.group(1)).stem
      for lineno,line in enumerate(path.read_text(encoding='utf8').splitlines(),1):
       m=re.search(r'\\(?:usepackage|RequirePackage)(?:\[[^]]*\])?\{([^}]*)\}',line)
       if m and package in [x.strip() for x in m.group(1).split(',')]:item['line']=lineno;break
     except (UnicodeError,OSError):pass
    if not any(x['message']==detail and x['file']==item['file'] for x in rows):rows.insert(0,item)
   if r.returncode or not pdf.is_file():
    no_pages=r.returncode==0 and not pdf.is_file() and 'No pages of output.' in out
    if no_pages:
     message=('pdfLaTeX n’a produit aucune page : le document est peut-être vide ou ne contient pas de contenu à afficher. Ajoutez du texte entre \\begin{document} et \\end{document}, puis recompilez.')
     try:
      text=path.read_text(encoding='utf8');line=next((i for i,s in enumerate(text.splitlines(),1) if re.search(r'\\end\s*\{document\}',s)),1);digest=hashlib.sha256(path.read_bytes()).hexdigest()
     except (UnicodeError,OSError):line=1;digest=''
     rows.append({'file':key,'line':line,'column':1,'severity':'warning','message':message,'sourceHash':digest})
     out='AUCUNE PAGE PRODUITE — la compilation ne signale pas nécessairement d’erreur de syntaxe.\n'+message+'\n\n'+out
    elif r.returncode and not rows:
     rows.append({'file':key,'line':1,'column':1,'severity':'error','message':detail or 'La compilation LaTeX a échoué. Consultez la sortie complète.'})
    for diagnostic in rows:
     if diagnostic.get('sourceHash'):continue
     target=external_files.get(diagnostic['file']) if diagnostic['file'].startswith('@external:') else root/diagnostic['file']
     try:
      if target and Path(target).stat().st_size<=2_000_000:diagnostic['sourceHash']=hashlib.sha256(Path(target).read_bytes()).hexdigest()
     except OSError:pass
    shutil.rmtree(work,ignore_errors=True);return {'kind':'latex','ok':False,'noPages':no_pages,'output':out,'diagnostics':rows}
   with self.lock:
    self.entries[ident]=(pdf,work,path)
    while len(self.entries)>8:
     first=next(iter(self.entries));_,old,_=self.entries.pop(first)
     shutil.rmtree(old,ignore_errors=True)
   return {'kind':'latex','ok':True,'output':out,'diagnostics':rows,'pdfId':ident}
  except subprocess.TimeoutExpired:
   shutil.rmtree(work,ignore_errors=True);return {'kind':'latex','ok':False,'output':'Compilation LaTeX interrompue après 90 secondes.','diagnostics':[]}
  except Exception:
   shutil.rmtree(work,ignore_errors=True);raise
 def get(self,ident):
  with self.lock:
   item=self.entries.get(ident)
   if not item or not item[0].is_file():raise ValueError('PDF introuvable ou expiré. Recompilez le document.')
   return item[0]
 def get_for_source(self,ident,source):
  with self.lock:
   item=self.entries.get(ident)
   if not item or not item[0].is_file() or item[2]!=Path(source).resolve():raise ValueError('PDF expiré ou associé à un autre fichier. Recompilez le document.')
   return item[0]
 def close(self):
  with self.lock:items=list(self.entries.values());self.entries.clear()
  for _,folder,_ in items:shutil.rmtree(folder,ignore_errors=True)
