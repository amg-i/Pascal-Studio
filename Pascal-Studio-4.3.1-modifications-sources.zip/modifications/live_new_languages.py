"""Live Rust/Go diagnostics from unsaved buffers; never runs the target.

Rust uses rustc metadata-only with source on stdin; Go uses gofmt parser.
The compiler may still read referenced files and expand compiler macros.
"""
import json, os, re, shutil, subprocess, tempfile
from pathlib import Path

def analyze(kind,path,key,content):
 if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
 exe=shutil.which('rustc' if kind=='rust' else 'gofmt')
 if not exe:return {'state':'unavailable','diagnostics':[],'message':'Installez '+('rustc' if kind=='rust' else 'gofmt (golang-go)')+' pour l’analyse.'}
 with tempfile.TemporaryDirectory(prefix='ps-analyse-') as temp:
  cmd=[exe,'--edition=2021','--crate-name','studio_program','--error-format=json','--emit=metadata','-o',str(Path(temp)/'out.rmeta'),'-'] if kind=='rust' else [exe,'-e']
  try:r=subprocess.run(cmd,input=content,capture_output=True,text=True,errors='replace',cwd=Path(path).parent,timeout=12,env={**os.environ,'TERM':'dumb'})
  except subprocess.TimeoutExpired:return {'state':'timeout','diagnostics':[],'message':'Analyse interrompue après 12 secondes.'}
 rows=[];lines=content.splitlines()
 def col(row,col):
  try:return len(lines[row-1][:col-1].encode('utf-16-le'))//2+1
  except IndexError:return max(1,col)
 if kind=='rust':
  for raw in r.stderr.splitlines()[:500]:
   try:item=json.loads(raw)
   except ValueError:continue
   severity=item.get('level');code=(item.get('code') or {}).get('code','')
   if severity not in ('error','warning') or code=='E0601':continue
   for span in item.get('spans',[]):
    if not span.get('is_primary') or span.get('file_name') not in ('<anon>','-'):continue
    line=int(span.get('line_start',1));column=col(line,int(span.get('column_start',1)));end_line=int(span.get('line_end',line));end_col=col(end_line,int(span.get('column_end',column+1)))
    if line>len(lines) or line<1:continue
    rows.append({'file':key,'line':line,'column':column,'endLine':end_line,'endColumn':max(column+1,end_col) if line==end_line else end_col,'severity':severity,'message':item.get('message','Erreur Rust'),'code':code})
 else:
  for line in r.stderr.splitlines()[:100]:
   match=re.match(r'^<standard input>:(\d+):(\d+):\s*(.*)$',line)
   if not match:continue
   row,byte_col,message=match.groups();row=int(row)
   try:prefix=lines[row-1].encode('utf8')[:max(0,int(byte_col)-1)].decode('utf8','ignore');column=len(prefix.encode('utf-16-le'))//2+1
   except IndexError:row=min(max(row,1),max(1,len(lines)));column=1
   item={'file':key,'line':row,'column':column,'severity':'error','message':message}
   if item not in rows:rows.append(item)
 return {'state':'ready','diagnostics':rows[:100],'ok':not any(x['severity']=='error' for x in rows),'message':('Analyse Rust (rustc) : ' if kind=='rust' else 'Syntaxe Go (gofmt) : ')+str(sum(x['severity']=='error' for x in rows))+' erreur(s), '+str(sum(x['severity']=='warning' for x in rows))+' avertissement(s)'}
