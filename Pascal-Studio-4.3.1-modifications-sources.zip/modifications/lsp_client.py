"""Client LSP générique sur stdio : complétion et diagnostics en continu.

Une seule implémentation sert tous les langages. Le registre (langages.py)
indique, pour chacun, le binaire à lancer, ses arguments et son languageId ;
ce module s'occupe du protocole.

Deux services sont exposés :

  completer(chemin, contenu, ligne, colonne)
      requête textDocument/completion, renvoyée telle quelle à Monaco.

  diagnostiquer(chemin, contenu)
      synchronise le document puis attend la notification
      textDocument/publishDiagnostics que le serveur pousse de lui-même, et la
      convertit au format de Pascal Studio.

Un fil de lecture unique décode les trames « Content-Length », distribue les
réponses aux appelants qui attendent et met de côté les notifications. Sans ce
fil, il serait impossible de recevoir les diagnostics, qui ne sont la réponse
d'aucune requête.

Comportement en cas d'absence : si le binaire n'est pas installé, « disponible() »
renvoie False et rien n'est lancé. L'appelant retombe alors sur le moteur local.
Aucune exception ne remonte vers l'interface : un serveur muet ou planté
produit une liste vide, jamais une erreur.

Les positions LSP sont déjà exprimées en unités UTF-16, comme Monaco : aucune
conversion n'est nécessaire, seulement le passage de 0 à 1 comme base.
"""

import json
import os
import select
import shutil
import subprocess
import threading
import time
from pathlib import Path

import langages

DELAI_DEMARRAGE = 12
DELAI_REQUETE = 6
DELAI_DIAGNOSTICS = 3.0
LIMITE_OCTETS = 2_000_000
LIMITE_REPONSE = 8_000_000
LIMITE_DIAGNOSTICS = 200
SEVERITES = {1: 'error', 2: 'warning', 3: 'info', 4: 'hint'}


class ServeurLsp:
    """Un serveur de langage en cours d'exécution, pour un projet donné."""

    def __init__(self, spec, racine):
        self.spec = spec
        self.racine = Path(racine).resolve()
        # RLock, et non Lock : completer() tient le verrou puis appelle
        # fermer() et demarrer(), qui le reprennent sur le même fil.
        self.verrou = threading.RLock()
        self.processus = None
        self.tampon = b''
        self.serial = 0
        self.documents = {}
        self.attentes = {}                 # identifiant -> (événement, résultat)
        # Le fil de lecture répond parfois au serveur (requêtes initiées par
        # lui) pendant que le fil appelant écrit : il faut sérialiser.
        self.verrou_ecriture = threading.Lock()
        self.diagnostics = {}              # uri -> (instant, lignes)
        self.lecteur = None
        self.arrete = threading.Event()
        self.erreur = ''

    # -- disponibilité -----------------------------------------------------

    def disponible(self):
        return shutil.which(self.spec.binaire) is not None

    def installation(self):
        return self.spec.installation

    # -- cycle de vie ------------------------------------------------------

    def demarrer(self):
        """Lance le serveur et négocie les capacités. Renvoie True si prêt."""
        if self.processus and self.processus.poll() is None:
            return True
        exe = shutil.which(self.spec.binaire)
        if not exe:
            self.erreur = 'Binaire « %s » absent. %s' % (
                self.spec.binaire, self.spec.installation)
            return False
        try:
            self.processus = subprocess.Popen(
                [exe, *self.spec.args],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL, bufsize=0, cwd=self.racine,
                start_new_session=True)
        except OSError as e:
            self.erreur = 'Impossible de lancer %s : %s' % (self.spec.binaire, e)
            self.processus = None
            return False
        self.arrete.clear()
        self.lecteur = threading.Thread(target=self._boucle_lecture, daemon=True)
        self.lecteur.start()
        try:
            self._requete('initialize', {
                'processId': os.getpid(),
                'rootUri': self.racine.as_uri(),
                'capabilities': {
                    'general': {'positionEncodings': ['utf-16']},
                    'textDocument': {
                        'completion': {'completionItem': {
                            'snippetSupport': True, 'insertReplaceSupport': True}},
                        'publishDiagnostics': {'relatedInformation': False},
                    },
                },
            }, delai=DELAI_DEMARRAGE)
            self._notification('initialized', {})
        except Exception as e:
            self.erreur = '%s n’a pas répondu à initialize : %s' % (
                self.spec.binaire, e)
            self.fermer()
            return False
        return True

    def fermer(self):
        with self.verrou:
            processus = self.processus
            self.processus = None
            self.documents = {}
            self.diagnostics = {}
            self.tampon = b''
        self.arrete.set()
        if processus:
            try:
                processus.terminate()
                processus.wait(timeout=2)
            except Exception:
                try:
                    processus.kill()
                    processus.wait(timeout=2)
                except Exception:
                    pass
            for flux in (processus.stdin, processus.stdout):
                try:
                    flux.close()
                except Exception:
                    pass
        for evenement, _ in list(self.attentes.values()):
            evenement.set()
        self.attentes.clear()

    def vivant(self):
        return bool(self.processus) and self.processus.poll() is None

    # -- protocole ---------------------------------------------------------

    def _envoyer(self, message):
        corps = json.dumps(message, ensure_ascii=False).encode('utf8')
        trame = ('Content-Length: %d\r\n\r\n' % len(corps)).encode('ascii') + corps
        with self.verrou_ecriture:
            self.processus.stdin.write(trame)
            self.processus.stdin.flush()

    def _notification(self, methode, params):
        self._envoyer({'jsonrpc': '2.0', 'method': methode, 'params': params})

    def _requete(self, methode, params, delai=None):
        delai = DELAI_REQUETE if delai is None else delai
        with self.verrou:
            self.serial += 1
            identifiant = self.serial
        evenement = threading.Event()
        self.attentes[identifiant] = (evenement, None)
        try:
            self._envoyer({'jsonrpc': '2.0', 'id': identifiant,
                           'method': methode, 'params': params})
        except Exception as e:
            self.attentes.pop(identifiant, None)
            raise ValueError('envoi impossible vers %s : %s' % (self.spec.binaire, e))
        if not evenement.wait(delai):
            self.attentes.pop(identifiant, None)
            raise TimeoutError('%s ne répond pas à %s.' % (self.spec.binaire, methode))
        _, message = self.attentes.pop(identifiant, (None, None))
        if not isinstance(message, dict):
            raise ValueError('%s a renvoyé une réponse inexploitable.'
                             % self.spec.binaire)
        if 'error' in message:
            raise ValueError(str(message['error']))
        # On renvoie le PAYLOAD, pas l'enveloppe JSON-RPC : les appelants
        # attendent directement les items ou la liste de diagnostics.
        return message.get('result')

    def _boucle_lecture(self):
        """Décode les trames, distribue les réponses, garde les notifications."""
        while not self.arrete.is_set():
            processus = self.processus
            if not processus or processus.poll() is not None:
                return
            try:
                if not select.select([processus.stdout], [], [], 0.25)[0]:
                    continue
                bloc = os.read(processus.stdout.fileno(), 65536)
            except (OSError, ValueError):
                return
            if not bloc:
                return
            self.tampon += bloc
            while True:
                message = self._extraire_message()
                if message is None:
                    break
                self._distribuer(message)

    def _extraire_message(self):
        separation = self.tampon.find(b'\r\n\r\n')
        if separation < 0:
            return None
        entetes = self.tampon[:separation].decode('ascii', 'replace')
        longueur = None
        for ligne in entetes.split('\r\n'):
            if ligne.lower().startswith('content-length:'):
                try:
                    longueur = int(ligne.split(':', 1)[1])
                except ValueError:
                    longueur = None
        if longueur is None or longueur > LIMITE_REPONSE:
            self.tampon = b''
            return None
        fin = separation + 4 + longueur
        if len(self.tampon) < fin:
            return None
        corps = self.tampon[separation + 4:fin]
        self.tampon = self.tampon[fin:]
        try:
            return json.loads(corps)
        except ValueError:
            return None

    def _distribuer(self, message):
        if not isinstance(message, dict):
            return
        methode = message.get('method')
        if methode == 'textDocument/publishDiagnostics':
            params = message.get('params') or {}
            uri = params.get('uri')
            if uri:
                self.diagnostics[uri] = (time.monotonic(),
                                         params.get('diagnostics') or [])
            return
        if 'id' in message and methode:
            # Requête initiée par le serveur : répondre pour ne pas le bloquer.
            try:
                self._envoyer({'jsonrpc': '2.0', 'id': message['id'], 'result': None})
            except Exception:
                pass
            return
        if 'id' in message:
            attente = self.attentes.get(message['id'])
            if attente:
                self.attentes[message['id']] = (attente[0], message)
                attente[0].set()

    # -- documents ---------------------------------------------------------

    def _synchroniser(self, chemin, contenu):
        """Ouvre ou met à jour le document, renvoie son uri."""
        uri = Path(chemin).resolve().as_uri()
        langage_id = self._language_id(chemin)
        version = self.documents.get(uri, 0) + 1
        if version == 1:
            self._notification('textDocument/didOpen', {'textDocument': {
                'uri': uri, 'languageId': langage_id, 'version': version,
                'text': contenu}})
        else:
            self._notification('textDocument/didChange', {
                'textDocument': {'uri': uri, 'version': version},
                'contentChanges': [{'text': contenu}]})
        self.documents[uri] = version
        return uri

    def _language_id(self, chemin):
        if self.spec.langage_id:
            return self.spec.langage_id
        identifiant = langages.resoudre(Path(chemin).suffix) or 'plaintext'
        return identifiant

    # -- services ----------------------------------------------------------

    def completer(self, chemin, contenu, ligne, colonne):
        """Items de complétion LSP, ou [] si le serveur n'est pas utilisable."""
        if not self._contenu_valide(contenu):
            return []
        try:
            with self.verrou:
                if not self.vivant():
                    self.fermer()
                    if not self.demarrer():
                        return []
                uri = self._synchroniser(chemin, contenu)
            resultat = self._requete('textDocument/completion', {
                'textDocument': {'uri': uri},
                'position': {'line': max(0, ligne - 1),
                             'character': max(0, colonne - 1)},
                'context': {'triggerKind': 1},
            })
            items = resultat if isinstance(resultat, list) else (resultat or {}).get('items', [])
            return items[:LIMITE_DIAGNOSTICS] if isinstance(items, list) else []
        except Exception:
            self.fermer()
            return []

    def diagnostiquer(self, chemin, contenu, cle=None, delai=None):
        delai = DELAI_DIAGNOSTICS if delai is None else delai
        """Diagnostics au format de Pascal Studio, ou None si indisponible.

        Renvoie None quand le serveur ne peut pas être lancé : l'appelant
        distingue ainsi « aucune erreur » d'« analyse impossible » et peut
        retomber sur le moteur local.
        """
        if not self._contenu_valide(contenu):
            return None
        try:
            with self.verrou:
                if not self.vivant():
                    self.fermer()
                    if not self.demarrer():
                        return None
                uri = self._synchroniser(chemin, contenu)
            self.diagnostics.pop(uri, None)
            # Le serveur pousse ses diagnostics après didOpen/didChange ; on
            # les attend sans requête explicite.
            echeance = time.monotonic() + delai
            lignes = None
            while time.monotonic() < echeance:
                trouve = self.diagnostics.get(uri)
                if trouve:
                    lignes = trouve[1]
                    break
                time.sleep(0.02)
            if lignes is None:
                try:
                    resultat = self._requete('textDocument/diagnostic',
                                             {'textDocument': {'uri': uri}},
                                             delai=max(0.5, delai))
                    lignes = (resultat or {}).get('items', [])
                except Exception:
                    lignes = []
            return [_convertir(d, cle or str(chemin)) for d in lignes]
        except Exception:
            self.fermer()
            return None

    def _contenu_valide(self, contenu):
        return (isinstance(contenu, str)
                and len(contenu.encode('utf8')) <= LIMITE_OCTETS)


def _convertir(diagnostic, cle):
    """Un diagnostic LSP vers le format de Pascal Studio."""
    plage = diagnostic.get('range') or {}
    debut = plage.get('start') or {}
    fin = plage.get('end') or debut
    ligne = int(debut.get('line', 0)) + 1
    colonne = int(debut.get('character', 0)) + 1
    fin_ligne = int(fin.get('line', debut.get('line', 0))) + 1
    fin_colonne = int(fin.get('character', debut.get('character', 0))) + 1
    if fin_ligne < ligne or (fin_ligne == ligne and fin_colonne < colonne):
        fin_ligne, fin_colonne = ligne, colonne
    severity = diagnostic.get('severity')
    message = str(diagnostic.get('message', '')).strip() or 'Diagnostic du serveur.'
    source = diagnostic.get('source')
    code = diagnostic.get('code')
    if code not in (None, ''):
        message = '%s [%s]' % (message, code)
    if source:
        message = '%s (%s)' % (message, source)
    return {'file': cle, 'line': ligne, 'column': colonne,
            'endLine': fin_ligne, 'endColumn': max(colonne + 1, fin_colonne),
            'severity': SEVERITES.get(severity, 'warning'),
            'message': message[:2000]}


class GestionnaireLsp:
    """Un serveur par langage et par projet, démarré à la demande."""

    def __init__(self, racine):
        self.racine = Path(racine).resolve()
        self.verrou = threading.RLock()
        self.serveurs = {}

    def reinitialiser(self, racine):
        self.fermer()
        self.racine = Path(racine).resolve()

    def serveur(self, kind):
        """Le serveur préféré pour ce langage, s'il est installé."""
        specs = langages.serveurs_lsp(kind)
        if not specs:
            return None
        spec = next((s for s in specs if shutil.which(s.binaire)), None)
        if spec is None:
            return None
        with self.verrou:
            cle = (spec.binaire, str(self.racine))
            existant = self.serveurs.get(cle)
            if existant is None:
                existant = ServeurLsp(spec, self.racine)
                self.serveurs[cle] = existant
            return existant

    def fermer(self):
        with self.verrou:
            serveurs = list(self.serveurs.values())
            self.serveurs.clear()
        for s in serveurs:
            s.fermer()

    def etat(self, kind):
        """Ce qui est disponible ici, maintenant, pour l'affichage."""
        specs = langages.serveurs_lsp(kind)
        if not specs:
            return {'disponible': False, 'binaire': None, 'installation': ''}
        for spec in specs:
            if shutil.which(spec.binaire):
                return {'disponible': True, 'binaire': spec.binaire,
                        'installation': spec.installation}
        return {'disponible': False, 'binaire': None,
                'installation': specs[0].installation}
