"""Moteur de complétion universel : serveur de langage, sinon moteur local.

C'est le repli demandé : quand aucun serveur de langage n'est installé, la
complétion reste utile grâce à

  1. l'index du projet — les symboles déclarés dans tous les fichiers voisins,
     plus ceux du tampon en cours d'édition, même non enregistré ;
  2. les bibliothèques — mots-clefs, types et extraits avec tabulations ;
  3. le contexte de saisie — après « < » en HTML on propose des balises, après
     « : » en CSS des valeurs, après « \\ref{ » en LaTeX les étiquettes, etc.

Ordre de recherche, toujours : serveur de langage s'il est installé, sinon
moteur local. Le format renvoyé est celui des CompletionItem du protocole LSP,
identique à ce que produisait déjà clangd, donc l'interface n'a rien à changer.

Aucune exception ne remonte pour un problème d'index ou de serveur : seule une
entrée manifestement invalide (position négative, tampon énorme) lève
ValueError, comme le faisait ClangCompletion.
"""

import os
import re
import threading
import time
from pathlib import Path

import bibliotheques_completion as bib
import langages
import lsp_client

LIMITE_ITEMS = 200
LIMITE_FICHIERS = 3000
LIMITE_OCTETS = 2_000_000
LIMITE_OCTETS_INDEX = 512_000
FRAICHEUR_INDEX = 2.0
FRAICHEUR_TAMPON = 0.05
BUDGET_LECTURES = 400

DOSSIERS_IGNORES = frozenset((
    '.git', '.hg', '.svn', '.idea', '.vscode', 'node_modules', '__pycache__',
    '.mypy_cache', '.pytest_cache', '.ruff_cache', '.venv', 'venv', 'env',
    'build', 'dist', 'out', 'target', 'vendor', '.next', '.nuxt', '.output',
    '.cache', '.tox', '.nox', '.turbo', 'Pods', 'obj', 'bin',
))

IDENTIFIANT = re.compile(r'[A-Za-z0-9_À-ÖØ-öø-ÿ$]+')
# Un nom extrait doit ressembler à un identifiant. On autorise « : » et « . »
# (étiquettes LaTeX « sec:methode », paquets Perl « Foo::Bar », membres C++),
# le tiret (noms CSS « flow-root ») et le préfixe « -- » des variables CSS.
MOT = re.compile(r'^(?:--[A-Za-z0-9_]|[A-Za-z_$À-ÖØ-öø-ÿ])[\w$À-ÖØ-öø-ÿ:.-]*$')

# Contextes de saisie.
(CTX_INCONNU, CTX_CODE, CTX_BALISE_HTML, CTX_ATTRIBUT_HTML,
 CTX_VALEUR_ATTRIBUT, CTX_PROPRIETE_CSS, CTX_VALEUR_CSS, CTX_SELECTEUR_CSS,
 CTX_COMMANDE_LATEX, CTX_ARGUMENT_LATEX, CTX_CLE_JSON, CTX_CLE_XML,
 CTX_LIEN_MARKDOWN) = range(13)

# Rangs de tri : plus le chiffre est petit, plus la proposition est pertinente.
# Ce que le contexte exige (une valeur après « : », une balise après « < »)
# passe avant les symboles, eux-mêmes avant les mots-clefs.
RANG_CONTEXTE = '0'
RANG_TAMPON = '1'
RANG_PROJET = '2'
RANG_MOT_CLEF = '3'
RANG_TYPE = '4'
RANG_EXTRAIT = '5'


class Symbole:
    """Un nom déclaré quelque part dans le projet."""

    __slots__ = ('nom', 'genre', 'detail', 'fichier', 'ligne')

    def __init__(self, nom, genre, detail='', fichier='', ligne=0):
        self.nom = nom
        self.genre = genre
        self.detail = detail
        self.fichier = fichier
        self.ligne = ligne


def _item(libelle, genre, detail='', insertion=None, rang='', filtre=None,
          documentation=''):
    """Un CompletionItem au format du protocole."""
    item = {'label': libelle, 'kind': genre,
            'insertText': insertion if insertion is not None else libelle,
            'insertTextFormat': 2 if insertion else 1}
    if detail:
        item['detail'] = detail
    if rang:
        item['sortText'] = '%s%s' % (rang, libelle.lower())
    if filtre:
        item['filterText'] = filtre
    if documentation:
        item['documentation'] = documentation
    return item


def _ancre(depuis):
    """Transforme un titre en ancre de lien : « Mon Titre » -> « mon-titre »."""
    propre = re.sub(r'[^\wÀ-ÿ -]', '', depuis.lower()).strip()
    return re.sub(r'\s+', '-', propre)


def _noms_extraits(brut, genre, detail=''):
    """Découpe une capture en noms proposables.

    Les motifs HTML capturent « a b c » pour class="a b c" : on découpe alors
    en trois symboles. Un titre, en revanche, ne se découpe pas : proposer
    « de » et « section » après <h2>Mon titre de section</h2> serait du bruit.
    On en fait une ancre, qui est ce qu'on écrit réellement dans un lien.
    """
    brut = brut.strip()
    if not brut or '\n' in brut or '\t' in brut:
        return []
    if detail == 'titre':
        ancre = _ancre(brut)
        return [ancre] if ancre and len(ancre) <= 64 else []
    if detail == 'ancre':
        ancre = _ancre(brut)
        return ['#' + ancre] if ancre and len(ancre) <= 64 else []
    noms = []
    if ' ' in brut:
        noms.extend(m for m in brut.split() if MOT.match(m) and len(m) <= 64)
    elif MOT.match(brut) and len(brut) <= 64:
        noms.append(brut)
    # Sans doublon, ordre préservé.
    vus = set()
    return [n for n in noms if not (n in vus or vus.add(n))]


def _positionner(contenu, ligne, colonne):
    """Le texte avant le curseur, sur sa ligne. None si position hors texte."""
    lignes = contenu.split('\n')
    if ligne < 1 or ligne > len(lignes):
        return ''
    texte = lignes[ligne - 1]
    if colonne < 1:
        return ''
    return texte[:colonne - 1]


def _prefixe(avant):
    """Le mot partiel en cours de frappe, juste avant le curseur."""
    m = re.search(r'[A-Za-z0-9_$À-ÖØ-öø-ÿ-]+$', avant)
    return m.group(0) if m else ''


def _contexte(kind, avant):
    """Devine ce que l'utilisateur est en train d'écrire."""
    if kind == 'html':
        if re.search(r'\b[\w-]+\s*=\s*["\'][^"\']*$', avant):
            return CTX_VALEUR_ATTRIBUT
        m = re.search(r'<\s*/?\s*([\w-]*)$', avant)
        if m:
            return CTX_BALISE_HTML
        if re.search(r'<\s*[\w-]+(?:\s+[^<>]*)?$', avant) and not avant.endswith('>'):
            return CTX_ATTRIBUT_HTML
        return CTX_CODE
    if kind == 'css':
        if re.search(r'[{;]\s*[-\w]*$', avant) or re.search(r'^\s*[-\w]*$', avant):
            return CTX_PROPRIETE_CSS
        if re.search(r':\s*[^;{}]*$', avant):
            return CTX_VALEUR_CSS
        if re.search(r'[.#][-\w]*$', avant):
            return CTX_SELECTEUR_CSS
        return CTX_CODE
    if kind == 'latex':
        if re.search(r'\\(?:ref|pageref|eqref|cite|citep|citet|autocite|label'
                     r'|include|input|bibliography|usepackage|documentclass)'
                     r'\s*(?:\[[^\]]*\])?\s*\{[^}]*$', avant):
            return CTX_ARGUMENT_LATEX
        if re.search(r'\\[\w@]*$', avant):
            return CTX_COMMANDE_LATEX
        return CTX_CODE
    if kind == 'markdown':
        if re.search(r'\]\([^)]*$', avant):
            return CTX_LIEN_MARKDOWN
        return CTX_CODE
    if kind == 'json':
        if re.search(r'[{,]\s*"[^"]*$', avant) or re.search(r'^\s*"[^"]*$', avant):
            return CTX_CLE_JSON
        return CTX_CODE
    if kind in ('xml', 'csproj', 'svg'):
        if re.search(r'<\s*/?\s*[\w:.-]*$', avant):
            return CTX_BALISE_HTML
        if re.search(r'\b[\w:.-]+\s*=\s*"[^"]*$', avant):
            return CTX_VALEUR_ATTRIBUT
        if re.search(r'<\s*[\w:.-]+(?:\s+[^<>]*)?$', avant):
            return CTX_ATTRIBUT_HTML
        return CTX_CODE
    return CTX_CODE


def _attribut_courant(avant):
    """L'attribut dont on écrit la valeur, en HTML/XML."""
    m = re.search(r'([\w:-]+)\s*=\s*["\'][^"\']*$', avant)
    return m.group(1).lower() if m else ''


def _commande_latex_courante(avant):
    m = re.search(r'\\([\w@]+)\s*(?:\[[^\]]*\])?\s*\{[^}]*$', avant)
    return m.group(1).lower() if m else ''


class IndexProjet:
    """Les symboles déclarés dans le projet, mis en cache par fichier."""

    def __init__(self, racine):
        self.racine = Path(racine)
        self.verrou = threading.RLock()
        self.cache = {}          # chemin -> (signature, [Symbole])
        self.par_langage = {}    # clef de bibliothèque -> {nom: Symbole}
        self.instant = 0.0

    def reinitialiser(self, racine):
        with self.verrou:
            self.racine = Path(racine)
            self.cache = {}
            self.par_langage = {}
            self.instant = 0.0

    def _signature(self, chemin):
        try:
            info = chemin.stat()
            return (info.st_mtime_ns, info.st_size)
        except OSError:
            return None

    def fichiers(self):
        """Les fichiers à indexer, en nombre borné."""
        racine = self.racine
        if not racine.is_dir():
            return []
        trouves = []
        try:
            for chemin, dossiers, fichiers in os.walk(racine, followlinks=False):
                dossiers[:] = [d for d in dossiers
                               if d not in DOSSIERS_IGNORES and not d.startswith('.')]
                for nom in fichiers:
                    if nom.startswith('.'):
                        continue
                    suffixe = Path(nom).suffix.lower()
                    if not suffixe or suffixe in ('.pyc', '.o', '.so', '.a', '.png',
                                                  '.jpg', '.jpeg', '.gif', '.ico',
                                                  '.pdf', '.zip', '.gz', '.xz',
                                                  '.woff', '.woff2', '.ttf', '.mp4'):
                        continue
                    trouves.append(Path(chemin) / nom)
                    if len(trouves) >= LIMITE_FICHIERS:
                        return trouves
        except OSError:
            return trouves
        return trouves

    def extraire(self, cle, contenu, chemin='', depart=1):
        """Les symboles d'un texte, selon les motifs de sa bibliothèque."""
        bibliotheque = bib.bibliotheque(cle)
        if not bibliotheque.motifs or not contenu:
            return []
        symboles = []
        vus = set()
        for motif in bibliotheque.motifs:
            for correspondance in motif.expression.finditer(contenu):
                try:
                    brut = correspondance.group(motif.groupe)
                except IndexError:
                    continue
                if not brut:
                    continue
                ligne = depart + contenu.count('\n', 0, correspondance.start())
                for nom in _noms_extraits(brut, motif.genre, motif.detail):
                    cle_symbole = (nom, motif.genre)
                    if cle_symbole in vus:
                        continue
                    vus.add(cle_symbole)
                    detail = motif.detail
                    if chemin:
                        detail = '%s — %s' % (detail, Path(chemin).name) if detail \
                            else Path(chemin).name
                    symboles.append(Symbole(nom, motif.genre, detail,
                                            str(chemin), ligne))
        return symboles

    def symboles(self, cle, force=False):
        """Les symboles du projet pour une bibliothèque, avec cache.

        Le parcours est borné : au plus BUDGET_LECTURES fichiers lus par appel.
        S'il ne va pas au bout, on ne touche pas au cache des fichiers non
        visités — sinon on les relirait indéfiniment — et on y retourne dès le
        prochain appel.
        """
        now = time.monotonic()
        with self.verrou:
            if not force and self.par_langage and now - self.instant < FRAICHEUR_INDEX:
                return self.par_langage.get(cle, {})
            complet = self._analyser(BUDGET_LECTURES)
            # Un parcours incomplet doit être repris sans attendre ; un parcours
            # complet ouvre la fenêtre de fraîcheur normale.
            self.instant = now if complet else now - FRAICHEUR_INDEX
            return self.par_langage.get(cle, {})

    def _analyser(self, budget):
        """Parcourt le projet. Renvoie True si le parcours est allé au bout."""
        vus = set()
        lus = 0
        for chemin in self.fichiers():
            clef = _cle_pour(chemin)
            if not clef:
                continue
            signature = self._signature(chemin)
            if signature is None:
                continue
            vus.add(chemin)
            en_cache = self.cache.get(chemin)
            if en_cache and en_cache[0] == signature:
                symboles = en_cache[1]
            elif signature[1] > LIMITE_OCTETS_INDEX:
                # Trop gros pour être lu à chaque frappe : on l'ignore.
                self.cache[chemin] = (signature, [])
                symboles = []
            elif lus >= budget:
                return False
            else:
                try:
                    contenu = chemin.read_text('utf8', 'replace')
                except (OSError, ValueError):
                    contenu = ''
                symboles = self.extraire(clef, contenu, chemin)
                self.cache[chemin] = (signature, symboles)
                lus += 1
            cible = self.par_langage.setdefault(clef, {})
            for symbole in symboles:
                cible.setdefault(symbole.nom, symbole)
        # Parcours complet : on oublie ce qui a disparu du disque.
        for chemin in list(self.cache):
            if chemin not in vus:
                del self.cache[chemin]
        for clef in list(self.par_langage):
            cible = self.par_langage[clef]
            for nom in [n for n, s in cible.items()
                        if s.fichier and not Path(s.fichier).exists()]:
                del cible[nom]
        return True

    def vider(self):
        with self.verrou:
            self.cache = {}
            self.par_langage = {}
            self.instant = 0.0


def _cle_pour(chemin):
    """La clef de bibliothèque d'un fichier, ou '' s'il n'est pas indexable."""
    identifiant = langages.resoudre(Path(chemin).suffix.lower())
    if not identifiant:
        return ''
    return langages.langage(identifiant).bibliotheque


class MoteurLocal:
    """La complétion sans aucun serveur de langage."""

    def __init__(self, racine):
        self.index = IndexProjet(racine)

    def reinitialiser(self, racine):
        self.index.reinitialiser(racine)

    def completer(self, kind, chemin, contenu, ligne, colonne):
        if not isinstance(contenu, str):
            return []
        cle = langages.bibliotheque(kind)
        bibliotheque = bib.bibliotheque(cle)
        avant = _positionner(contenu, ligne, colonne)
        debut = _prefixe(avant)
        contexte = _contexte(kind, avant)
        items = []
        items.extend(self._contextuels(bibliotheque, kind, contexte, avant, debut))
        items.extend(self._tampon(bibliotheque, cle, contenu))
        items.extend(self._projet(cle))
        items.extend(self._statiques(bibliotheque, contexte))
        if debut and contexte in (CTX_BALISE_HTML, CTX_COMMANDE_LATEX):
            _ancrer(items, _plage_prefixe(ligne, colonne, debut))
        filtres = _filtrer(items, debut)
        if not filtres and items:
            # Le préfixe ne correspond à rien de connu : on rend quand même les
            # propositions, c'est Monaco qui tranchera. Mieux vaut trop que rien.
            filtres = items
        return _dedoublonner(filtres)[:LIMITE_ITEMS]

    # -- sources -----------------------------------------------------------

    def _tampon(self, bibliotheque, cle, contenu):
        """Les symboles du fichier en cours, même non enregistré."""
        if not bibliotheque.motifs:
            return []
        symboles = self.index.extraire(cle, contenu, '')
        return [_item(s.nom, s.genre, 'ce fichier', rang=RANG_TAMPON)
                for s in symboles]

    def _projet(self, cle):
        try:
            symboles = self.index.symboles(cle)
        except Exception:
            return []
        return [_item(s.nom, s.genre, s.detail or 'projet', rang=RANG_PROJET)
                for s in symboles.values()]

    def _statiques(self, bibliotheque, contexte):
        """Mots-clefs, types et extraits, restreints au contexte de saisie.

        Quand le contexte est reconnu, on ne propose QUE ce qui a du sens à cet
        endroit : après « < » en HTML, des balises, pas les 117 attributs ;
        après « display: » en CSS, rien du tout, car les valeurs viennent
        déjà de _contextuels. Sans cela le bruit noie la bonne proposition.
        """
        extraits = [_item(e.libelle, bib.EXTRAIT, e.detail or 'extrait',
                          insertion=e.insertion, filtre=e.libelle,
                          rang=RANG_EXTRAIT)
                    for e in bibliotheque.extraits]
        if contexte == CTX_PROPRIETE_CSS:
            return extraits + [
                _item(m, bib.PROPRIETE, 'propriété CSS',
                      insertion='%s: $0;' % m, rang=RANG_CONTEXTE)
                for m in bibliotheque.mots_clefs]
        if contexte == CTX_BALISE_HTML:
            return extraits + [
                # Sans le « < » initial : la plage remplacée commence après lui.
                _item(m, bib.MODULE, 'balise',
                      insertion=('%s>' % m) if m in _VIDES else '%s>$0</%s>' % (m, m),
                      filtre=m, rang=RANG_CONTEXTE)
                for m in bibliotheque.mots_clefs]
        if contexte == CTX_ATTRIBUT_HTML:
            return extraits + [
                _item(m, bib.PROPRIETE, 'attribut',
                      insertion='%s="$0"' % m, rang=RANG_CONTEXTE)
                for m in bibliotheque.types]
        if contexte == CTX_COMMANDE_LATEX:
            return extraits + [
                _item(m, bib.FONCTION, 'commande LaTeX',
                      insertion=m, filtre=m, rang=RANG_CONTEXTE)
                for m in bibliotheque.mots_clefs]
        if contexte in (CTX_VALEUR_CSS, CTX_VALEUR_ATTRIBUT, CTX_LIEN_MARKDOWN,
                        CTX_SELECTEUR_CSS, CTX_ARGUMENT_LATEX, CTX_CLE_JSON,
                        CTX_CLE_XML):
            # Ces contextes sont entièrement servis par _contextuels.
            return extraits
        return extraits + [
            _item(m, bib.MOT_CLEF, 'mot-clef', rang=RANG_MOT_CLEF)
            for m in bibliotheque.mots_clefs] + [
            _item(m, bib.CLASSE, 'type', rang=RANG_TYPE)
            for m in bibliotheque.types]

    def _contextuels(self, bibliotheque, kind, contexte, avant, debut):
        """Propositions qui dépendent de ce qui est déjà écrit."""
        items = []
        if contexte == CTX_VALEUR_ATTRIBUT:
            attribut = _attribut_courant(avant)
            valeurs = bibliotheque.valeurs.get(attribut, '')
            items.extend(_item(v, bib.VALEUR, 'valeur de %s' % attribut,
                               rang=RANG_CONTEXTE)
                         for v in valeurs.split() if v)
            if attribut in ('href', 'src', 'action', 'poster', 'data'):
                items.extend(_item(n, bib.FICHIER, 'fichier du projet',
                                   rang=RANG_PROJET)
                             for n in _fichiers_voisins(self.index))
        elif contexte == CTX_VALEUR_CSS:
            propriete = _propriete_courante(avant)
            valeurs = bibliotheque.valeurs.get(propriete, '')
            items.extend(_item(v, bib.VALEUR, 'valeur de %s' % propriete,
                               rang=RANG_CONTEXTE)
                         for v in valeurs.split() if v)
            items.extend(_item(n, bib.VARIABLE, 'variable CSS', rang=RANG_PROJET)
                         for n in _variables_css(self.index, 'css'))
        elif contexte == CTX_SELECTEUR_CSS:
            for nom, symbole in _classes_html(self.index).items():
                items.append(_item(nom, symbole.genre, symbole.detail or 'sélecteur',
                                   rang=RANG_PROJET))
        elif contexte == CTX_ARGUMENT_LATEX:
            commande = _commande_latex_courante(avant)
            genre = bib.REFERENCE
            detail = {'ref': 'renvoi', 'pageref': 'page', 'eqref': 'équation',
                      'cite': 'citation', 'citep': 'citation', 'citet': 'citation',
                      'autocite': 'citation', 'label': 'étiquette',
                      'usepackage': 'paquet', 'documentclass': 'classe'}.get(
                          commande, 'argument')
            for nom, symbole in _etiquettes_latex(self.index).items():
                items.append(_item(nom, genre, '%s (%s)' % (detail, symbole.detail)
                                   if symbole.detail else detail, rang=RANG_PROJET))
            if commande in ('usepackage', 'documentclass'):
                items.extend(_item(t, bib.MODULE, detail, rang=RANG_CONTEXTE)
                             for t in bibliotheque.types)
        elif contexte == CTX_CLE_JSON:
            for nom in _clefs_document(self.index, 'json'):
                items.append(_item(nom, bib.PROPRIETE, 'clef déjà utilisée',
                                   rang=RANG_PROJET))
        elif contexte == CTX_LIEN_MARKDOWN:
            for nom in _ancres_markdown(self.index):
                items.append(_item(nom, bib.REFERENCE, 'titre du document',
                                   rang=RANG_CONTEXTE))
            items.extend(_item(n, bib.FICHIER, 'fichier du projet',
                               rang=RANG_PROJET)
                         for n in _fichiers_voisins(self.index))
        return items


_VIDES = frozenset(('area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input',
                   'link', 'meta', 'param', 'source', 'track', 'wbr'))


def _propriete_courante(avant):
    m = re.search(r'(?:^|[;{])\s*([-A-Za-z]+)\s*:\s*[^;{}]*$', avant)
    return m.group(1).lower() if m else ''


def _fichiers_voisins(index, limite=80):
    """Quelques fichiers du projet, pour compléter un chemin."""
    try:
        noms = [c.name for c in index.fichiers()[:limite * 4]]
    except Exception:
        return []
    return sorted(set(noms))[:limite]


def _symboles_par_genre(index, cle, genres):
    try:
        symboles = index.symboles(cle)
    except Exception:
        return {}
    return {n: s for n, s in symboles.items() if s.genre in genres}


def _classes_html(index):
    """Classes et identifiants vus dans le HTML et le CSS du projet."""
    resultats = {}
    for cle, genres, detail in (('html', (bib.CLASSE, bib.CONSTANT), 'HTML'),
                                ('css', (bib.CLASSE, bib.CONSTANT), 'CSS')):
        for nom, symbole in _symboles_par_genre(index, cle, genres).items():
            prefixe = '.' if symbole.genre == bib.CLASSE else '#'
            clef = prefixe + nom
            if clef not in resultats:
                resultats[clef] = Symbole(clef, symbole.genre,
                                          '%s (%s)' % (detail, symbole.detail)
                                          if symbole.detail else detail)
    return resultats


def _etiquettes_latex(index):
    return _symboles_par_genre(index, 'latex', (bib.REFERENCE,))


def _clefs_document(index, cle):
    return sorted(_symboles_par_genre(index, cle, (bib.PROPRIETE,)))


def _ancres_markdown(index):
    """Les ancres des titres, telles qu'on les écrit dans un lien."""
    return sorted(_symboles_par_genre(index, 'markdown', (bib.REFERENCE,)))


def _variables_css(index, cle):
    try:
        symboles = index.symboles(cle or 'css')
    except Exception:
        return []
    return sorted({s.nom for s in symboles.values()
                   if s.genre == bib.VARIABLE and s.nom.startswith('--')})


_JETONS = re.compile(r'[_\-.\s:]+|(?<=[a-zÀ-ÿ])(?=[A-ZÀ-Ÿ])')


def _pertinence(nom, prefixe):
    """0 = commence par, 1 = contient ou préfixe d'un mot, 2 = acronyme.

    None quand le nom ne correspond pas du tout : il est alors écarté, ce qui
    évite de renvoyer 200 propositions à chaque frappe.
    """
    if not prefixe:
        return 0
    cible = nom.lower()
    attendu = prefixe.lower()
    if cible.startswith(attendu):
        return 0
    if attendu in cible:
        return 1
    # Les jetons sont découpés sur le nom ORIGINAL : passer d'abord en
    # minuscules effacerait les frontières de casse et « gs » ne retrouverait
    # jamais « GestionnaireStock ».
    jetons = [j.lower() for j in _JETONS.split(nom) if j]
    if any(j.startswith(attendu) for j in jetons):
        return 1
    if len(jetons) > 1 and ''.join(j[0] for j in jetons) == attendu:
        return 2
    return None


def _filtrer(items, prefixe):
    """Ne garde que ce qui correspond au préfixe, et classe par pertinence."""
    if not prefixe:
        return items
    gardes = []
    for item in items:
        cible = item.get('filterText') or item['label']
        score = _pertinence(cible, prefixe)
        if score is None:
            continue
        nouveau = dict(item)
        rang = str(item.get('sortText', '9'))[:1]
        nouveau['sortText'] = '%s%d%s' % (rang, score, cible.lower())
        gardes.append(nouveau)
    return gardes


def _plage_prefixe(ligne, colonne, prefixe):
    r"""La plage LSP couvrant exactement le préfixe déjà saisi.

    Sans elle, Monaco calcule sa propre plage mot à mot. Après « < » ou « \ »,
    ce calcul dépend de la définition de mot du langage : la fournir rend le
    remplacement déterministe quel que soit le langage.
    """
    zero = max(0, ligne - 1)
    debut = max(0, colonne - 1 - len(prefixe))
    fin = max(debut, colonne - 1)
    return {'start': {'line': zero, 'character': debut},
            'end': {'line': zero, 'character': fin}}


def _ancrer(items, plage):
    """Attache un textEdit explicite, que l'interface sait déjà exploiter."""
    for item in items:
        item['textEdit'] = {'newText': item['insertText'], 'range': plage}
    return items


def _dedoublonner(items):
    """Garde la meilleure proposition pour chaque couple libellé/insertion."""
    meilleurs = {}
    for item in items:
        clef = (item['label'], item.get('insertText', ''))
        existant = meilleurs.get(clef)
        if existant is None or str(item.get('sortText', '')) < str(existant.get('sortText', '')):
            meilleurs[clef] = item
    return sorted(meilleurs.values(),
                  key=lambda i: (i.get('sortText', i['label'].lower()), i['label']))


class CompletionUniverselle:
    """Façade utilisée par server.py : même contrat que ClangCompletion.

    Essaie le serveur de langage du registre, puis retombe sur le moteur
    local. Le repli est transparent pour l'interface.
    """

    def __init__(self, racine):
        self.racine = Path(racine).resolve()
        self.lsp = lsp_client.GestionnaireLsp(self.racine)
        self.local = MoteurLocal(self.racine)
        self.verrou = threading.RLock()
        self.source = 'locale'

    def reinitialiser(self, racine):
        with self.verrou:
            self.racine = Path(racine).resolve()
            self.lsp.reinitialiser(self.racine)
            self.local.reinitialiser(self.racine)

    def close(self):
        with self.verrou:
            self.lsp.fermer()
            self.local.index.vider()

    # Alias francophone, pour la cohérence avec le reste du projet.
    fermer = close

    def source_derniere(self):
        """D'où viennent les dernières propositions : utile au diagnostic."""
        return self.source

    def complete(self, chemin, contenu, ligne, colonne):
        chemin = Path(chemin)
        if not isinstance(contenu, str):
            raise ValueError('Tampon manquant.')
        if len(contenu.encode('utf8')) > LIMITE_OCTETS:
            raise ValueError('Tampon trop volumineux.')
        if not isinstance(ligne, int) or not isinstance(colonne, int) \
                or ligne < 1 or colonne < 1:
            raise ValueError('Position invalide.')
        kind = langages.resoudre(chemin.suffix.lower()) or 'plaintext'
        with self.verrou:
            serveur = self.lsp.serveur(kind)
            if serveur is not None:
                items = serveur.completer(chemin, contenu, ligne, colonne)
                if items:
                    self.source = 'lsp:%s' % serveur.spec.binaire
                    return items[:LIMITE_ITEMS]
            self.source = 'locale'
            return self.local.completer(kind, chemin, contenu, ligne, colonne)

    def etat(self, chemin):
        """Ce qui alimente la complétion pour ce fichier, pour l'affichage."""
        kind = langages.resoudre(Path(chemin).suffix.lower()) or 'plaintext'
        serveur = self.lsp.etat(kind)
        return {'langage': kind, 'libelle': langages.libelle(kind),
                'source': 'serveur' if serveur['disponible'] else 'moteur local',
                'binaire': serveur['binaire'],
                'installation': serveur['installation'],
                'mots_clefs': len(bib.bibliotheque(
                    langages.bibliotheque(kind)).mots_clefs),
                'extraits': len(bib.bibliotheque(
                    langages.bibliotheque(kind)).extraits),
                'symboles_indexes': len(self.local.index.par_langage.get(
                    langages.bibliotheque(kind), {}))}
