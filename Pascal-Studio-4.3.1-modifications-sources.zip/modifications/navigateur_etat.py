"""Persistance de l'état du panneau navigateur : historique, signets, onglets.

POURQUOI CÔTÉ SERVEUR ET PAS DANS localStorage
----------------------------------------------
    L'application choisit un port libre au démarrage (`net` dans main.cjs), donc
    son origine http://127.0.0.1:PORT change d'un lancement à l'autre. Un
    localStorage est attaché à une origine : les signets enregistrés un jour
    auraient disparu le lendemain sans qu'aucune erreur n'apparaisse. C'est un
    piège silencieux, et la seule parade est de confier l'état au serveur, qui
    écrit dans le répertoire de configuration de l'utilisateur.

Vie privée
----------
    Un historique de navigation révèle quels sites ont été consultés. Rien
    n'est chiffré ici — le chiffrement d'account_store.py protège des jetons
    d'accès, pas une liste d'URL, et ajouter une clé non chiffrée à côté
    n'apporterait rien. En revanche le fichier est écrit en 0600, et la
    persistance se désactive par PS_NAVIGATEUR_PERSIST=0 : l'état reste alors en
    mémoire pour la durée du processus, ce qui est le comportement d'un
    navigateur en mode privé.

Limites
-------
    Tout est borné. Un historique sans plafond grossirait indéfiniment sur une
    machine qui reste allumée, et un fichier d'état illisible au chargement
    doit dégrader, pas empêcher le panneau de s'ouvrir.
"""
import contextlib
import fcntl
import json
import os
import stat
import tempfile
import threading
import time
from pathlib import Path

MAX_HISTORIQUE = 500
MAX_SIGNETS = 500
MAX_ONGLETS = 24
MAX_URL = 4000
MAX_TITRE = 300
MAX_FICHIER = 2_000_000

_verrou = threading.RLock()


def active():
    """La persistance peut être désactivée, comme pour les comptes Git."""
    return os.environ.get('PS_NAVIGATEUR_PERSIST', '1').strip().lower() \
        not in ('0', 'false', 'non', 'no')


def config_dir():
    return Path(os.environ.get('PS_NAVIGATEUR_DIR')
                or (os.environ.get('XDG_CONFIG_HOME')
                    or str(Path.home() / '.config'))) / 'pascal-studio'


def chemin():
    return config_dir() / 'navigateur.json'


def etat_vide():
    return {'historique': [], 'signets': [], 'onglets': [], 'geometrie': {},
            'version': 1}


# Une seule copie en mémoire, comme le fait account_store : les écritures sont
# rares et courtes, et relire le fichier à chaque visite coûterait plus cher
# que le bénéfice.
_cache = None


def _texte(value, limite):
    if not isinstance(value, str):
        return ''
    value = value.strip()
    return value[:limite]


# Les schémas acceptés. Cette liste DOIT rester identique à la garde posée sur
# l'invité par patch_desktop_navigateur.py, qui n'autorise que
# ^(https?:|about:blank) et bloque tout le reste :
#
#   * file://  -> un navigateur intégré qui lit le système de fichiers est un
#                 risque sans contrepartie ; l'aperçu du projet passe par le
#                 serveur HTTP local, jamais par file://.
#   * data:    -> même raisonnement, et un data: persisté serait un vecteur
#                 d'hameçonnage enregistré dans les signets.
#   * ftp://, javascript:, chrome:// -> un <webview> ne les charge pas.
#
# Une entrée persistée que l'invité refuse de charger ferait croire à tort
# qu'elle est utilisable : les deux gardes sont donc la même politique, et
# modifier l'une sans l'autre est une faute.
SCHEMAS = ('http://', 'https://', 'about:blank')


def _url_exploitable(url):
    return bool(url) and url.lower().startswith(SCHEMAS)


def _url_valide(brute):
    """Une URL exploitable, ou None.

    Une URL trop longue est REFUSÉE, pas tronquée : tronquer produirait une
    adresse différente, et un signet tronqué ouvrirait autre chose que ce que
    l'utilisateur a enregistré — sans qu'aucune erreur n'apparaisse. C'est le
    même arbitrage que pour une structure tabulaire devinée : une donnée fausse
    est pire qu'un refus. Le titre, lui, ne sert qu'à l'affichage et peut être
    raccourci sans danger.
    """
    if not isinstance(brute, str):
        return None
    url = brute.strip()
    if not url or len(url) > MAX_URL:
        return None
    return url if _url_exploitable(url) else None


def _nettoyer_visite(entree):
    """Une visite exploitable, ou None. Mieux vaut jeter que stocker du bruit."""
    if not isinstance(entree, dict):
        return None
    url = _url_valide(entree.get('url'))
    if not url:
        return None
    visite = {'url': url,
              'titre': _texte(entree.get('titre'), MAX_TITRE) or url,
              'vu': entree.get('vu')}
    if not isinstance(visite['vu'], (int, float)) or visite['vu'] <= 0:
        visite['vu'] = time.time()
    else:
        visite['vu'] = float(visite['vu'])
    if isinstance(entree.get('visites'), int) and entree['visites'] > 0:
        visite['visites'] = min(entree['visites'], 10 ** 6)
    else:
        visite['visites'] = 1
    return visite


def _nettoyer_signet(entree):
    if not isinstance(entree, dict):
        return None
    url = _url_valide(entree.get('url'))
    if not url:
        return None
    signet = {'url': url,
              'titre': _texte(entree.get('titre'), MAX_TITRE) or url,
              'groupe': _texte(entree.get('groupe'), 80)}
    if isinstance(entree.get('ajoute'), (int, float)) and entree['ajoute'] > 0:
        signet['ajoute'] = float(entree['ajoute'])
    else:
        signet['ajoute'] = time.time()
    return signet


def _nettoyer_onglet(entree):
    if not isinstance(entree, dict):
        return None
    url = _url_valide(entree.get('url'))
    if not url:
        return None
    return {'url': url, 'titre': _texte(entree.get('titre'), MAX_TITRE) or url}


def _nettoyer_geometrie(valeur):
    """La géométrie du panneau : quatre nombres bornés, ou rien.

    Des coordonnées hors écran rendraient le panneau invisible sans qu'aucune
    erreur n'apparaisse — l'utilisateur croirait que le navigateur est en
    panne. Chaque valeur est donc bornée, et une géométrie incohérente est
    jetée plutôt que corrigée en silence.
    """
    if not isinstance(valeur, dict):
        return {}
    sortie = {}
    for cle in ('x', 'y', 'largeur', 'hauteur'):
        nombre = valeur.get(cle)
        if isinstance(nombre, bool) or not isinstance(nombre, (int, float)):
            continue
        nombre = int(nombre)
        if cle in ('largeur', 'hauteur'):
            if 260 <= nombre <= 8000:
                sortie[cle] = nombre
        else:
            if -8000 <= nombre <= 16000:
                sortie[cle] = nombre
    if len(sortie) != 4:
        return {}
    sortie['plein'] = bool(valeur.get('plein'))
    return sortie


def _valider(etat):
    """Un état exploitable, quoi qu'il y ait dans le fichier."""
    if not isinstance(etat, dict):
        return etat_vide()
    sortie = etat_vide()
    for entree in etat.get('historique') or []:
        propre = _nettoyer_visite(entree)
        if propre:
            sortie['historique'].append(propre)
    for entree in etat.get('signets') or []:
        propre = _nettoyer_signet(entree)
        if propre:
            sortie['signets'].append(propre)
    for entree in etat.get('onglets') or []:
        propre = _nettoyer_onglet(entree)
        if propre:
            sortie['onglets'].append(propre)
    sortie['historique'] = sortie['historique'][:MAX_HISTORIQUE]
    sortie['signets'] = sortie['signets'][:MAX_SIGNETS]
    sortie['onglets'] = sortie['onglets'][:MAX_ONGLETS]
    sortie['geometrie'] = _nettoyer_geometrie(etat.get('geometrie'))
    return sortie


def lire():
    """L'état courant. Un fichier absent, illisible ou corrompu dégrade."""
    global _cache
    with _verrou:
        if _cache is not None:
            return json.loads(json.dumps(_cache))
        if not active():
            _cache = etat_vide()
            return json.loads(json.dumps(_cache))
        fichier = chemin()
        try:
            if fichier.is_file() and fichier.stat().st_size <= MAX_FICHIER:
                with fichier.open('r', encoding='utf-8') as flux:
                    fcntl.flock(flux, fcntl.LOCK_SH)
                    try:
                        brut = flux.read()
                    finally:
                        fcntl.flock(flux, fcntl.LOCK_UN)
                _cache = _valider(json.loads(brut))
            else:
                _cache = etat_vide()
        except (OSError, ValueError):
            # Ne jamais empêcher le panneau de s'ouvrir à cause d'un état
            # illisible : on repart à vide et on le dit dans `degrade`.
            _cache = etat_vide()
            _cache['degrade'] = 'état illisible, reparti à vide'
        return json.loads(json.dumps(_cache))


def _ecrire_disque(etat):
    fichier = chemin()
    with contextlib.suppress(OSError):
        fichier.parent.mkdir(parents=True, exist_ok=True)
    # Écriture atomique : un plantage en cours de route ne doit pas laisser un
    # fichier tronqué qui ferait perdre tout l'historique au lancement suivant.
    descripteur, temporaire = tempfile.mkstemp(
        dir=str(fichier.parent), prefix='navigateur-', suffix='.tmp')
    try:
        with os.fdopen(descripteur, 'w', encoding='utf-8') as flux:
            fcntl.flock(flux, fcntl.LOCK_EX)
            try:
                json.dump(etat, flux, ensure_ascii=False, indent=1)
                flux.flush()
                os.fsync(flux.fileno())
            finally:
                fcntl.flock(flux, fcntl.LOCK_UN)
        # mkstemp crée en 0600 ; os.replace ne conserve pas le mode de la
        # cible. On pose explicitement 0600 : un historique de navigation ne
        # se partage pas avec les autres comptes de la machine.
        os.chmod(temporaire, stat.S_IRUSR | stat.S_IWUSR)
        os.replace(temporaire, fichier)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(temporaire)
        raise


def _publier(etat):
    global _cache
    etat = _valider(etat)
    _cache = etat
    if active():
        try:
            _ecrire_disque(etat)
        except OSError as erreur:
            # L'état reste utilisable en mémoire : le panneau continue de
            # fonctionner, et l'échec d'écriture est remonté plutôt que tu.
            etat = dict(etat)
            etat['degrade'] = 'écriture impossible : %s' % erreur
    return json.loads(json.dumps(etat))


def visiter(url, titre=''):
    """Une visite : regroupe par URL, remonte l'entrée en tête, plafonne."""
    with _verrou:
        etat = lire()
        propre = _nettoyer_visite({'url': url, 'titre': titre, 'vu': time.time()})
        if not propre:
            return etat
        historique = [e for e in etat['historique'] if e['url'] != propre['url']]
        precedent = next((e for e in etat['historique']
                          if e['url'] == propre['url']), None)
        propre['visites'] = (precedent.get('visites', 0) + 1) if precedent else 1
        historique.insert(0, propre)
        etat['historique'] = historique[:MAX_HISTORIQUE]
        etat.pop('degrade', None)
        return _publier(etat)


def signet_ajouter(url, titre='', groupe=''):
    with _verrou:
        etat = lire()
        propre = _nettoyer_signet({'url': url, 'titre': titre, 'groupe': groupe})
        if not propre:
            return etat
        signets = [s for s in etat['signets'] if s['url'] != propre['url']]
        # L'ordre d'ajout est conservé, pas l'ordre de visite.
        signets.insert(0, propre)
        etat['signets'] = signets[:MAX_SIGNETS]
        etat.pop('degrade', None)
        return _publier(etat)


def signet_supprimer(url):
    with _verrou:
        etat = lire()
        url = _url_valide(url) or ''
        etat['signets'] = [s for s in etat['signets'] if s['url'] != url]
        return _publier(etat)


def onglets_enregistrer(onglets):
    """Les onglets ouverts, pour retrouver son travail au prochain lancement."""
    with _verrou:
        etat = lire()
        propres = []
        for entree in (onglets if isinstance(onglets, list) else [])[:MAX_ONGLETS]:
            propre = _nettoyer_onglet(entree)
            if propre:
                propres.append(propre)
        etat['onglets'] = propres
        return _publier(etat)


def geometrie_enregistrer(geometrie):
    with _verrou:
        etat = lire()
        propre = _nettoyer_geometrie(geometrie)
        # Une géométrie refusée ne doit pas effacer la précédente : garder
        # l'ancienne vaut mieux que replacer le panneau n'importe où.
        if propre:
            etat['geometrie'] = propre
        return _publier(etat)


def historique_effacer():
    with _verrou:
        etat = lire()
        etat['historique'] = []
        return _publier(etat)


def purge():
    """Tout effacer, fichier compris."""
    global _cache
    with _verrou:
        _cache = None
        fichier = chemin()
        with contextlib.suppress(OSError):
            fichier.unlink()
        return lire()


def capacites():
    """Ce que le panneau peut afficher de façon fiable, sans deviner."""
    return {'persistant': active(),
            'chemin': str(chemin()) if active() else '',
            'max_historique': MAX_HISTORIQUE,
            'max_signets': MAX_SIGNETS,
            'max_onglets': MAX_ONGLETS,
            'chiffre': False}


ACTIONS = {
    'visite': visiter,
    'signet': signet_ajouter,
    'signet-supprimer': signet_supprimer,
    'onglets': onglets_enregistrer,
    'geometrie': geometrie_enregistrer,
    'historique-effacer': historique_effacer,
    'purge': purge,
}
