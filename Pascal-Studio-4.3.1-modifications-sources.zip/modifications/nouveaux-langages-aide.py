"""Catalogue hors ligne : Rust, Go et Ruby. Génère nouveaux-langages-aide.js."""
import json
from pathlib import Path
articles=[]
def intro(lang,texte):
 articles.append(dict(id=f'new-{lang.lower()}-intro',lang=lang,group='Introduction',title='Utilité et présentation',summary='',intro=True,blocks=[dict(title='',text=texte,code='')]))
def add(lang,group,rows):
 for title,text,code in rows:
  articles.append(dict(id=f'new-{lang.lower()}-{len(articles)}',lang=lang,group=group,title=title,summary=text,blocks=[dict(title='Explication',text=text,code=''),dict(title='Exemple',text='Exemple à adapter au contexte ; certains extraits supposent des imports ou une fonction englobante.',code=code)]))
intro('Rust',"Rust sert à créer des programmes système, outils en ligne de commande, services et composants où performance et maîtrise de la mémoire sont importantes. Son système de types et de possession aide à prévenir de nombreuses erreurs de mémoire sans ramasse-miettes traditionnel.\n\nLe projet a commencé chez Mozilla, avec une première version stable en 2015. Rust évolue par éditions ; ces fiches utilisent principalement l’édition 2021.\n\nDans cet IDE, un fichier .rs est compilé individuellement avec rustc. Les projets Cargo et leurs dépendances ne sont pas construits automatiquement par ce bouton ; utilisez Cargo dans un terminal ou un Makefile de confiance. La référence n’est pas exhaustive : consultez https://doc.rust-lang.org/book/ et https://doc.rust-lang.org/std/.")
add('Rust','Bases et types',[
('main et println!',"main est le point d’entrée d’un programme ; println! est une macro qui écrit une ligne.",'fn main() {\n    println!("Bonjour {}", "Rust");\n}'),
('let et mut',"Une liaison est immuable par défaut. mut permet de modifier sa valeur.",'let mut compteur = 1;\ncompteur += 1;'),
('Constantes const',"Une constante porte un type explicite et doit être évaluée à la compilation.",'const LIMITE: u32 = 100;'),
('Entiers i32, u64 et usize',"Les entiers signés et non signés ont une taille définie ; usize convient notamment aux indices.",'let temperature: i32 = -3;\nlet index: usize = 0;'),
('Flottants f32 et f64',"f64 est le type flottant par défaut ; attention aux arrondis binaires.",'let prix: f64 = 2.5;'),
('bool et char',"bool vaut true ou false ; char représente une valeur scalaire Unicode, pas nécessairement un caractère visible complet.","let actif: bool = true;\nlet symbole: char = 'é';"),
('Tuple',"Un tuple regroupe des valeurs de types éventuellement différents ; on accède aux champs avec .0, .1, etc.",'let point = (3, 4);\nprintln!("{}", point.0);'),
('Tableau et tranche',"Un tableau a une taille fixe ; une tranche emprunte une plage contiguë.",'let nombres = [1, 2, 3];\nlet tranche = &nombres[0..2];'),
('String et &str',"String possède un texte UTF-8 modifiable ; &str est une vue empruntée sur du texte.",'let mut nom = String::from("Ada");\nnom.push_str(" Lovelace");\nlet vue: &str = &nom;'),
('Vec<T>',"Vec est un tableau dynamique qui possède ses éléments ; push ajoute une valeur.",'let mut valeurs = vec![1, 2];\nvaleurs.push(3);'),
('HashMap',"HashMap associe des clés à des valeurs ; les méthodes get et insert permettent de les consulter ou modifier.",'use std::collections::HashMap;\nlet mut scores = HashMap::new();\nscores.insert("Ada", 10);'),
('Option<T>',"Option représente une valeur présente Some ou absente None ; évitez unwrap si l’absence est possible.",'let premier = [4, 5].first();\nif let Some(n) = premier { println!("{n}"); }'),
('Result<T, E>',"Result représente un succès Ok ou une erreur Err, à traiter explicitement.",'let n: Result<i32, _> = "42".parse();\nmatch n { Ok(v) => println!("{v}"), Err(e) => eprintln!("{e}") }'),
])
add('Rust','Contrôle et fonctions',[
('if et else',"if est une expression : ses branches peuvent fournir une valeur de même type.",'let note = 12;\nlet resultat = if note >= 10 { "admis" } else { "ajourné" };'),
('match',"match compare une valeur à des motifs et doit couvrir tous les cas possibles.",'let texte = match Some(2) { Some(n) => n.to_string(), None => "absent".into() };'),
('for et range',"for parcourt un itérateur ; 0..3 exclut 3 et 0..=3 l’inclut.",'for i in 0..3 { println!("{i}"); }'),
('loop et while',"loop répète jusqu’à break ; while continue tant qu’une condition est vraie.",'let mut n = 0;\nwhile n < 3 { n += 1; }'),
('fn et retour',"Les paramètres et le type de retour sont déclarés ; la dernière expression sans point-virgule est retournée.",'fn carre(n: i32) -> i32 { n * n }\nprintln!("{}", carre(4));'),
('Fermetures',"Une fermeture peut capturer son environnement. Les règles de possession restent applicables.",'let facteur = 2;\nlet double = |n: i32| n * facteur;\nprintln!("{}", double(5));'),
('Itérateurs map et collect',"map transforme les éléments ; collect rassemble le résultat dans une collection choisie.",'let doubles: Vec<_> = [1, 2, 3].iter().map(|n| n * 2).collect();'),
('filter',"filter conserve les éléments vérifiant un prédicat ; les itérateurs sont évalués à la demande.",'let pairs: Vec<_> = (0..6).filter(|n| n % 2 == 0).collect();'),
('Propagation avec ?',"? renvoie immédiatement l’erreur à l’appelant ; la fonction doit retourner un type compatible.",'fn lire() -> std::io::Result<String> {\n    let texte = std::fs::read_to_string("notes.txt")?;\n    Ok(texte)\n}'),
])
add('Rust','Possession et structures',[
('Possession et déplacement',"Une valeur possède ses ressources. L’affectation d’un String déplace généralement la possession ; la première liaison ne peut plus être utilisée.",'let premier = String::from("bonjour");\nlet second = premier;\nprintln!("{second}");'),
('Emprunt & et &mut',"Une référence emprunte une valeur ; plusieurs références partagées ou une référence mutable sont possibles selon les règles d’emprunt.",'let mut texte = String::from("a");\nlet vue = &mut texte;\nvue.push(\'b\');'),
('Durées de vie',"Les annotations de durée de vie expriment les relations entre références ; elles ne prolongent pas la vie des données.","fn premier<'a>(a: &'a str, _b: &str) -> &'a str { a }"),
('struct et impl',"Une structure rassemble des champs ; un bloc impl définit ses méthodes.",'struct Point { x: i32, y: i32 }\nimpl Point { fn somme(&self) -> i32 { self.x + self.y } }'),
('enum',"Une enum définit des variantes pouvant porter des données différentes.",'enum Message { Quitter, Texte(String), Position { x: i32, y: i32 } }'),
('trait',"Un trait décrit un comportement partagé ; une implémentation le fournit pour un type.",'trait Saluer { fn saluer(&self) -> String; }\nstruct Personne;\nimpl Saluer for Personne { fn saluer(&self) -> String { "Bonjour".into() } }'),
('Génériques',"Les paramètres génériques permettent d’écrire du code réutilisable pour plusieurs types.",'fn identite<T>(v: T) -> T { v }\nlet nombre = identite(42);'),
('mod et use',"mod déclare un module ; use rapproche un chemin dans la portée courante.",'mod calcul { pub fn deux() -> i32 { 2 } }\nuse calcul::deux;\nprintln!("{}", deux());'),
])
add('Rust','Bibliothèque standard et outils',[
('read_line',"stdin().read_line ajoute la ligne à une chaîne ; traitez le Result et retirez éventuellement le retour à la ligne.",'let mut ligne = String::new();\nstd::io::stdin().read_line(&mut ligne).expect("lecture");\nprintln!("{}", ligne.trim());'),
('read_to_string',"Lit un fichier texte UTF-8 et renvoie Result ; une erreur doit être traitée.",'let texte = std::fs::read_to_string("notes.txt")?;'),
('write',"std::fs::write écrit un contenu dans un fichier et le remplace s’il existe.",'std::fs::write("sortie.txt", "Bonjour")?;'),
('format!',"format! construit une chaîne sans l’écrire à l’écran.",'let message = format!("Valeur : {}", 42);'),
('parse',"parse convertit une chaîne vers un type choisi et renvoie Result.",'let nombre: i32 = "42".parse()?;'),
('thread::spawn',"spawn démarre un thread ; join attend sa fin. move peut transférer des valeurs au thread.",'let t = std::thread::spawn(|| 2 + 2);\nprintln!("{:?}", t.join());'),
('Cargo et rustc',"rustc compile un fichier ; Cargo gère projets, dépendances et tests. Ces commandes se tapent dans un terminal.",'rustc --edition=2021 main.rs -o programme\ncargo build\ncargo test'),
])
intro('Go',"Go sert à développer des services réseau, outils en ligne de commande et programmes concurrents. Il privilégie une syntaxe compacte, la compilation native et une bibliothèque standard riche.\n\nConçu chez Google par Robert Griesemer, Rob Pike et Ken Thompson, il a été annoncé en 2009 et publié en version 1 en 2012. Les goroutines et canaux facilitent l’organisation de tâches concurrentes.\n\nL’IDE construit le fichier .go sélectionné avec go build, dans son dossier. Les fichiers voisins ne sont pas ajoutés automatiquement ; les imports peuvent utiliser le module Go et télécharger des dépendances selon la configuration. Pour un paquet multi-fichiers, utilisez go build depuis un terminal ou un Makefile de confiance. Références : https://go.dev/doc/ et https://pkg.go.dev/std.")
add('Go','Bases et types',[
('package main et main',"Un exécutable Go utilise package main et une fonction main sans paramètre.",'package main\nimport "fmt"\nfunc main() { fmt.Println("Bonjour Go") }'),
('var et :=',"var déclare une variable ; := déclare et initialise des variables à l’intérieur d’une fonction.",'var age int = 30\nnom := "Ada"\nfmt.Println(nom, age)'),
('const',"const déclare une constante ; plusieurs constantes peuvent être regroupées.",'const pi = 3.14159'),
('Entiers',"int dépend de l’architecture ; int32 et int64 ont une taille explicite. Les conversions entre types sont explicites.",'var a int32 = 42\nb := int64(a)'),
('float64 et bool',"float64 représente un nombre flottant ; bool vaut true ou false.",'prix := 2.5\nactif := true'),
('string et rune',"Une string contient des octets souvent encodés en UTF-8 ; rune représente un point de code Unicode.",'texte := "été"\nfor _, r := range texte { fmt.Printf("%c\\n", r) }'),
('Tableau',"Un tableau a une longueur fixe qui fait partie de son type.",'var points [3]int\npoints[0] = 12'),
('Slice',"Une slice décrit une fenêtre sur un tableau sous-jacent ; append peut allouer un nouveau tableau.",'n := []int{1, 2}\nn = append(n, 3)'),
('map',"Une map associe des clés comparables à des valeurs ; la seconde valeur de lecture indique si une clé existe.",'scores := map[string]int{"Ada": 10}\nscore, ok := scores["Ada"]\nfmt.Println(score, ok)'),
('Pointeurs',"& prend l’adresse d’une variable et * déréférence un pointeur. Go ne permet pas l’arithmétique générale des pointeurs.",'n := 3\np := &n\n*p = 4'),
('struct',"Une structure regroupe des champs ; leurs noms exportés commencent par une majuscule.",'type Point struct { X, Y int }\np := Point{X: 2, Y: 3}'),
('interface',"Une interface décrit un ensemble de méthodes ; un type l’implémente implicitement lorsqu’il possède ces méthodes.",'type Salueur interface { Saluer() string }'),
('nil',"nil est la valeur nulle de certains types, notamment pointeurs, slices, maps, canaux et interfaces.",'var p *int\nif p == nil { fmt.Println("absent") }'),
])
add('Go','Contrôle et fonctions',[
('if et else',"if évalue une condition booléenne ; une initialisation courte peut précéder la condition.",'if n := 4; n > 0 { fmt.Println("positif") } else { fmt.Println("autre") }'),
('for',"for est l’unique mot-clé de boucle ; il peut exprimer une boucle comptée ou conditionnelle.",'for i := 0; i < 3; i++ { fmt.Println(i) }'),
('range',"range parcourt notamment slices, maps, chaînes et canaux ; _ ignore une valeur.",'for i, valeur := range []int{2, 4} { fmt.Println(i, valeur) }'),
('switch',"switch choisit un cas ; les cas ne tombent pas automatiquement dans le suivant.",'switch jour { case 1: fmt.Println("lundi"); default: fmt.Println("autre") }'),
('func',"Une fonction déclare les types des paramètres et du résultat.",'func carre(n int) int { return n * n }'),
('Retours multiples et erreurs',"Les fonctions renvoient souvent une valeur et une erreur ; il faut tester err avant d’utiliser le résultat.",'n, err := strconv.Atoi("42")\nif err != nil { return err }\nfmt.Println(n)'),
('defer',"defer reporte un appel à la sortie de la fonction englobante, utile pour fermer une ressource.",'f, err := os.Open("notes.txt")\nif err != nil { return err }\ndefer f.Close()'),
('Méthodes',"Une méthode est une fonction dotée d’un récepteur ; un récepteur pointeur peut modifier la structure.",'type Compteur struct { N int }\nfunc (c *Compteur) Inc() { c.N++ }'),
('Fermetures',"Une fonction anonyme peut capturer les variables de son environnement.",'facteur := 2\ndouble := func(n int) int { return n * facteur }'),
('panic et recover',"panic interrompt le flot normal ; recover ne fonctionne que dans une fonction différée du même goroutine. Préférez error pour les échecs ordinaires.",'defer func() { if r := recover(); r != nil { fmt.Println(r) } }()\npanic("problème")'),
])
add('Go','Concurrence et bibliothèque',[
('goroutine',"Le mot-clé go lance une fonction concurremment ; le programme principal doit attendre son résultat.",'ch := make(chan int)\ngo func() { ch <- 42 }()\nfmt.Println(<-ch)'),
('canal chan',"Un canal transporte des valeurs typées entre goroutines ; un canal non tamponné synchronise émission et réception.",'ch := make(chan string, 1)\nch <- "ok"\nfmt.Println(<-ch)'),
('select',"select attend une opération disponible sur plusieurs canaux ; default rend la sélection non bloquante.",'select { case v := <-ch: fmt.Println(v); default: fmt.Println("pas prêt") }'),
('sync.WaitGroup',"WaitGroup permet d’attendre plusieurs goroutines ; ajoutez-les avant de les lancer.",'var wg sync.WaitGroup\nwg.Add(1)\ngo func() { defer wg.Done(); fmt.Println("travail") }()\nwg.Wait()'),
('fmt.Println',"Println écrit des valeurs avec espaces et retour à la ligne sur la sortie standard.",'fmt.Println("Résultat", 42)'),
('fmt.Printf et Sprintf',"Printf écrit une chaîne formatée ; Sprintf la construit sans l’afficher.",'fmt.Printf("%.2f\\n", 3.14159)\ns := fmt.Sprintf("%s: %d", "score", 10)'),
('len et cap',"len donne la longueur ; cap indique la capacité pour les types concernés comme les slices.",'s := make([]int, 2, 5)\nfmt.Println(len(s), cap(s))'),
('append et copy',"append ajoute des éléments à une slice et renvoie la slice obtenue ; copy copie dans une destination existante.",'a := append([]int{1}, 2)\nb := make([]int, len(a))\ncopy(b, a)'),
('make et new',"make initialise slice, map ou canal ; new alloue la valeur nulle et renvoie un pointeur.",'m := make(map[string]int)\np := new(int)'),
('os.ReadFile et os.WriteFile',"ReadFile lit un fichier ; WriteFile écrit ou remplace le contenu et prend des permissions.",'data, err := os.ReadFile("notes.txt")\nif err == nil { err = os.WriteFile("copie.txt", data, 0644) }'),
('strings.Contains et Split',"Contains cherche une sous-chaîne ; Split découpe un texte selon un séparateur.",'ok := strings.Contains("bonjour", "jour")\nmots := strings.Split("a,b", ",")'),
('strconv.Atoi',"Atoi convertit une chaîne décimale en int et renvoie aussi une erreur.",'n, err := strconv.Atoi("42")\nif err == nil { fmt.Println(n) }'),
('encoding/json',"Marshal encode une valeur JSON ; Unmarshal décode les données dans une destination.",'data, err := json.Marshal(map[string]int{"score": 10})\nfmt.Println(string(data), err)'),
('net/http',"http.Get effectue une requête ; vérifiez l’erreur et fermez le corps de réponse. Le réseau n’est pas isolé.",'resp, err := http.Get("https://example.com")\nif err != nil { return err }\ndefer resp.Body.Close()'),
('go build et go test',"go build compile un fichier ou un paquet ; go test exécute les tests du paquet. Les dépendances peuvent nécessiter le réseau.",'go build -o programme main.go\ngo test ./...'),
])
intro('Ruby',"Ruby sert notamment à écrire des scripts, des outils d’automatisation, des applications web et des prototypes. Sa syntaxe expressive et son modèle objet dynamique rendent les programmes faciles à lire et à modifier.\n\nRuby a été créé par Yukihiro Matsumoto et publié en 1995. Il dispose d’un riche écosystème de bibliothèques, distribuées notamment sous forme de gems.\n\nL’IDE vérifie la syntaxe Ruby à la frappe avec ruby -c, puis lance directement le fichier .rb avec Ruby. Les gems doivent être installées séparément ; un projet Bundler peut nécessiter bundle exec dans un terminal. Références : https://www.ruby-lang.org/fr/documentation/ et https://docs.ruby-lang.org/.")
add('Ruby','Bases et types',[
('puts et print',"puts écrit une ligne avec retour à la ligne ; print écrit sans en ajouter automatiquement.",'puts "Bonjour Ruby"\nprint "Votre nom ? "'),
('Variables et constantes',"Une variable locale commence par une minuscule ; une constante commence par une majuscule.",'nom = "Ada"\nLIMITE = 100'),
('Integer et Float',"Les entiers peuvent grandir au-delà d’une taille machine fixe ; Float représente un nombre flottant approximatif.",'total = 40 + 2\nprix = 3.5'),
('String',"String est une chaîne mutable ; les doubles guillemets permettent l’interpolation #{...}.",'nom = "Ada"\nputs "Bonjour #{nom}"'),
('Symbol',"Un symbole est un identifiant immuable fréquemment utilisé comme clé de Hash.",'etat = :pret\nputs etat'),
('Array',"Array est une collection ordonnée ; << ajoute un élément à la fin.",'nombres = [1, 2]\nnombres << 3'),
('Hash',"Hash associe des clés à des valeurs ; une clé absente renvoie nil par défaut.",'scores = { ada: 10, grace: 12 }\nputs scores[:ada]'),
('Range',".. inclut la borne finale ; ... l’exclut.",'(1..3).each { |n| puts n }'),
('true, false et nil',"Seuls false et nil sont faux dans une condition ; zéro et chaîne vide sont vrais.",'valeur = nil\nputs "absent" if valeur.nil?'),
('Conversions Integer et to_i',"Integer peut lever une exception sur une chaîne invalide ; to_i est plus permissif et peut renvoyer zéro.",'n = Integer("42")\nputs "13".to_i'),
])
add('Ruby','Contrôle et méthodes',[
('if, elsif et else',"if exécute une branche selon une condition ; end ferme le bloc.",'if age >= 18\n  puts "majeur"\nelse\n  puts "mineur"\nend'),
('unless',"unless exécute le bloc lorsque la condition est fausse ; évitez les doubles négations.",'puts "absent" unless fichier_existe'),
('case et when',"case compare une valeur à plusieurs motifs et choisit la première branche correspondante.",'case note\nwhen 0..9 then puts "insuffisant"\nelse puts "réussi"\nend'),
('while',"while répète un bloc tant que sa condition est vraie.",'n = 0\nwhile n < 3\n  puts n\n  n += 1\nend'),
('each et blocs',"each parcourt les éléments ; le bloc reçoit une valeur entre barres verticales.",'[1, 2, 3].each do |n|\n  puts n\nend'),
('times',"times répète un bloc le nombre de fois indiqué et lui fournit un indice débutant à zéro.",'3.times { |i| puts i }'),
('def et return',"def définit une méthode ; la valeur de la dernière expression est renvoyée implicitement.",'def carre(n)\n  n * n\nend\nputs carre(4)'),
('Arguments par défaut',"Une méthode peut prévoir une valeur par défaut pour certains arguments.",'def saluer(nom = "monde")\n  "Bonjour #{nom}"\nend'),
('Bloc et yield',"yield invoque le bloc fourni à la méthode ; block_given? permet de vérifier sa présence.",'def repeter\n  yield if block_given?\nend\nrepeter { puts "bonjour" }'),
('Exceptions rescue et ensure',"rescue intercepte une exception ; ensure est exécuté lors de la sortie du bloc même en cas d’erreur.",'begin\n  n = Integer("abc")\nrescue ArgumentError => e\n  warn e.message\nensure\n  puts "terminé"\nend'),
('raise',"raise déclenche une exception ; choisissez un type d’erreur adapté.",'raise ArgumentError, "valeur invalide" if age < 0'),
])
add('Ruby','Objets, modules et collections',[
('class et initialize',"class définit un type ; initialize prépare un nouvel objet créé avec new.",'class Personne\n  def initialize(nom)\n    @nom = nom\n  end\nend\np = Personne.new("Ada")'),
('attr_reader et attr_accessor',"attr_reader crée un lecteur ; attr_accessor crée lecteur et écrivain pour une variable d’instance.",'class Point\n  attr_accessor :x\nend\np = Point.new\np.x = 3'),
('Héritage',"Une classe peut hériter d’une autre avec < ; super appelle la méthode correspondante du parent.",'class Animal\n  def cri; "?"; end\nend\nclass Chat < Animal\n  def cri; "miaou"; end\nend'),
('module et include',"Un module regroupe des constantes et méthodes ; include ajoute ses méthodes d’instance à une classe.",'module Salutation\n  def saluer; "bonjour"; end\nend\nclass Personne\n  include Salutation\nend'),
('require et require_relative',"require charge une bibliothèque accessible ; require_relative résout le chemin à partir du fichier courant.",'require "json"\nrequire_relative "calcul"'),
('map',"map applique un bloc à chaque élément et renvoie un nouveau tableau de résultats.",'doubles = [1, 2, 3].map { |n| n * 2 }'),
('select',"select renvoie les éléments pour lesquels le bloc est vrai.",'pairs = [1, 2, 3, 4].select { |n| n.even? }'),
('reduce',"reduce combine les éléments à l’aide d’un accumulateur initial.",'somme = [1, 2, 3].reduce(0) { |total, n| total + n }'),
('sort',"sort renvoie une collection triée ; sort! modifie le tableau initial.",'tries = [3, 1, 2].sort'),
('length et empty?',"length donne la taille ; empty? indique si la collection est vide.",'texte = "Ruby"\nputs texte.length\nputs texte.empty?'),
('split et join',"split découpe une chaîne ; join assemble les éléments d’un tableau.",'mots = "a,b,c".split(",")\nputs mots.join(" - ")'),
])
add('Ruby','Entrées, fichiers et outils',[
('gets et chomp',"gets lit une ligne depuis l’entrée standard et peut renvoyer nil en fin de fichier ; chomp retire le retour à la ligne.",'print "Nom ? "\nligne = gets\nputs "Bonjour #{ligne.chomp}" if ligne'),
('File.read et File.write',"File.read lit un fichier ; File.write crée ou remplace son contenu.",'texte = File.read("notes.txt")\nFile.write("copie.txt", texte)'),
('File.open',"Avec un bloc, File.open ferme automatiquement le fichier à la sortie du bloc.",'File.open("notes.txt", "r") do |f|\n  puts f.read\nend'),
('JSON.parse et JSON.generate',"La bibliothèque standard json décode et encode du JSON ; les erreurs de syntaxe doivent être traitées.",'require "json"\nobjet = JSON.parse(\'{"score": 10}\')\nputs JSON.generate(objet)'),
('ARGV et exit',"ARGV contient les arguments du programme ; exit termine avec un code choisi.",'puts ARGV.first || "aucun argument"\nexit 0'),
('ruby et gem',"ruby lance le fichier ; ruby -c vérifie la syntaxe. gem installe des bibliothèques dans l’environnement Ruby.",'ruby -c main.rb\nruby main.rb\ngem install nom_de_gem'),
])
assert len({a['id'] for a in articles})==len(articles)
result={'languages':['Rust','Go','Ruby'],'articles':articles}
out=Path(__file__).with_name('nouveaux-langages-aide.js');out.write_text('/* Catalogue Rust, Go et Ruby : source nouveaux-langages-aide.py. */\nwindow.PS_LANG_HELP='+json.dumps(result,ensure_ascii=False,separators=(',',':'))+';\n',encoding='utf8')
from collections import Counter
print('Fiches',len(articles),dict(Counter(a['lang'] for a in articles)))
