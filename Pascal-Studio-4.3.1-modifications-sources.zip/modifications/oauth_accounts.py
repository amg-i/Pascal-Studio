"""OAuth device flow for GitHub / GitLab.

Connections are persistent by default: tokens are stored AES-256-GCM encrypted
in ~/.config/pascal-studio/git-accounts.json next to a 0600 local key, following
the same model as the FTP/SMB vault. See account_store.py for the limits — a
process running as this Linux user can decrypt them. Set
PS_GIT_ACCOUNTS_PERSIST=0 to keep tokens in memory only.

Each account also carries the commit identity published by the service (display
name and commit/e-mail address, falling back to the service's noreply address)
so a repository can be attributed to the account that owns it.
"""
import json, re, threading, time, urllib.error, urllib.parse, urllib.request, uuid, ssl, subprocess, shutil
import account_store
try:
    import certifi
    _SSL = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    _SSL = ssl.create_default_context()

PROVIDERS={
 'github':{'origin':'https://github.com','api':'https://api.github.com','device':'/login/device/code','token':'/login/oauth/access_token','scope':'repo read:user read:org','noreply':'users.noreply.github.com'},
 'gitlab':{'origin':'https://gitlab.com','api':'https://gitlab.com/api/v4','device':'/oauth/authorize_device','token':'/oauth/token','scope':'api read_user write_repository','noreply':'users.noreply.gitlab.com'},
}
PUBLIC_FIELDS=('id','provider','login','name','email','emailSource','avatar','persisted')

def profile(provider,token):
    """Identité publique + adresse de commit publiée par le service.

    GitHub renvoie « email » null quand l'adresse est privée ; l'adresse noreply
    « id+login@users.noreply.github.com » attribue quand même les commits au
    compte. GitLab expose « commit_email », prévu exactement pour cet usage.
    Aucune adresse n'est inventée : si le service n'en publie aucune, on utilise
    son domaine noreply officiel, et « emailSource » indique d'où elle vient.
    """
    if provider not in PROVIDERS:raise ValueError('Service inconnu.')
    user,_=request(PROVIDERS[provider]['api']+'/user',token=token)
    if not isinstance(user,dict):raise ValueError('Impossible de vérifier le compte.')
    if provider=='github':
        login=user.get('login');name=(user.get('name') or '').strip() or (login or '')
        email=(user.get('email') or '').strip();source='compte'
        if not email:
            ident=user.get('id')
            if not isinstance(ident,int) or not login:raise ValueError('Impossible de vérifier le compte.')
            email='%d+%s@%s'%(ident,login,PROVIDERS[provider]['noreply']);source='noreply'
    else:
        login=user.get('username');name=(user.get('name') or '').strip() or (login or '')
        email='';source='compte'
        for field in ('commit_email','email','public_email'):
            value=(user.get(field) or '').strip()
            if value:email=value;source='commit' if field=='commit_email' else 'compte';break
        if not email:
            if not login:raise ValueError('Impossible de vérifier le compte.')
            email='%s@%s'%(login,PROVIDERS[provider]['noreply']);source='noreply'
    if not login:raise ValueError('Impossible de vérifier le compte.')
    if not re.fullmatch(r'[^@\s]+@[^@\s.]+(\.[^@\s.]+)+',email):raise ValueError('Adresse de commit invalide.')
    avatar=user.get('avatar_url') or user.get('avatar_url'.replace('_url','')) or ''
    return {'login':str(login),'name':str(name)[:200],'email':email[:320],'emailSource':source,
            'avatar':str(avatar)[:500] if isinstance(avatar,str) else '','providerId':user.get('id')}

def is_valid_email(value):
    return isinstance(value,str) and bool(re.fullmatch(r'[^@\s]+@[^@\s.]+(\.[^@\s.]+)+',value)) and len(value)<=320
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs): return None

def request(url, *, form=None, body=None, token=None):
    # All URLs are assembled internally from hard-coded endpoints; never follow redirects with credentials.
    if not url.startswith(('https://github.com/','https://api.github.com/','https://gitlab.com/')): raise ValueError('Hôte non autorisé.')
    headers={'Accept':'application/json','User-Agent':'Pascal-Studio/1.6'}
    data=None
    if form is not None:data=urllib.parse.urlencode(form).encode();headers['Content-Type']='application/x-www-form-urlencoded'
    if body is not None:data=json.dumps(body).encode();headers['Content-Type']='application/json'
    if token:headers['Authorization']='Bearer '+token
    req=urllib.request.Request(url,data=data,headers=headers)
    try:
        opener=urllib.request.build_opener(_NoRedirect(),urllib.request.HTTPSHandler(context=_SSL))
        with opener.open(req,timeout=25) as res:
            raw=res.read(3_000_001)
            if len(raw)>3_000_000:raise ValueError('Réponse trop volumineuse.')
            return json.loads(raw or b'{}'),dict(res.headers)
    except urllib.error.HTTPError as e:
        try: obj=json.loads(e.read(16384)); code=obj.get('error') or obj.get('message') or ''
        except Exception: code=''
        if code in ('authorization_pending','slow_down','expired_token','access_denied','authorization_declined'): return {'error':code},{}
        raise ValueError('Service distant : requête refusée (HTTP %s). Vérifiez les autorisations du compte.'%e.code)
    except (urllib.error.URLError,TimeoutError,OSError): raise ValueError('Connexion au service distant impossible.')

class AccountManager:
    def __init__(self):
        self.pending={};self.accounts={};self.lock=threading.RLock()
        self.restore()
    # --- persistance -------------------------------------------------------
    def restore(self):
        """Recharge les comptes chiffrés au démarrage ; n'échoue jamais bruyamment."""
        stored=account_store.store.load()
        with self.lock:
            for key,value in stored.items():
                if not isinstance(value,dict):continue
                provider=value.get('provider')
                token=value.get('token')
                if provider not in PROVIDERS:continue
                if not isinstance(token,str) or not 8<=len(token)<=500 or any(c.isspace() for c in token):continue
                expiry=value.get('expiry')
                # Sans jeton de renouvellement, un compte expiré ne sert à rien.
                if isinstance(expiry,(int,float)) and time.time()>=expiry and not value.get('refresh'):continue
                account={'id':str(value.get('id') or key),'provider':provider,
                         'login':str(value.get('login') or ''),'name':str(value.get('name') or ''),
                         'email':str(value.get('email') or ''),'emailSource':str(value.get('emailSource') or ''),
                         'avatar':str(value.get('avatar') or ''),'providerId':value.get('providerId'),
                         'token':token,'client_id':value.get('client_id'),'refresh':value.get('refresh'),
                         'expiry':expiry if isinstance(expiry,(int,float)) else None}
                if not account['login']:continue
                self.accounts[account['id']]=account
            return len(self.accounts)
    def persist(self):
        with self.lock:snapshot=dict(self.accounts)
        return account_store.store.save(snapshot)
    def add_token(self,provider,token):
        if provider not in PROVIDERS:raise ValueError('Service inconnu.')
        if not isinstance(token,str) or not 8<=len(token)<=500 or any(c.isspace() for c in token):raise ValueError('Jeton invalide.')
        info=profile(provider,token)
        account={'id':uuid.uuid4().hex,'provider':provider,'login':info['login'],'name':info['name'],
                 'email':info['email'],'emailSource':info['emailSource'],'avatar':info['avatar'],
                 'providerId':info['providerId'],'token':token,'client_id':None,'refresh':None,'expiry':None}
        with self.lock:
            # Un même compte reconnecté remplace l'ancienne entrée : pas de doublon.
            for old in [k for k,v in self.accounts.items() if v['provider']==provider and v['login']==account['login']]:
                self.accounts.pop(old,None);account_store.store.remove(old)
            self.accounts[account['id']]=account
        self.persist()
        return {'account':self.public(account)}
    def import_cli(self,provider):
        if provider not in PROVIDERS:raise ValueError('Service inconnu.')
        exe='gh' if provider=='github' else 'glab'
        if not shutil.which(exe):raise ValueError('Installez '+exe+' pour utiliser la connexion navigateur.')
        cmd=['gh','auth','token','--hostname','github.com'] if provider=='github' else ['glab','auth','git-credential','get']
        input_data=None if provider=='github' else 'protocol=https\nhost=gitlab.com\n\n'
        try: result=subprocess.run(cmd,input=input_data,capture_output=True,text=True,timeout=15)
        except Exception:raise ValueError('Impossible de lire la connexion '+exe+'.')
        if result.returncode:raise ValueError('Aucun compte connecté avec '+exe+'. Effectuez d’abord la connexion.')
        token=result.stdout.strip() if provider=='github' else next((x[9:] for x in result.stdout.splitlines() if x.startswith('password=')),'')
        return self.add_token(provider,token)
    def start(self,provider,client_id):
        if provider not in PROVIDERS: raise ValueError('Service inconnu.')
        if not isinstance(client_id,str) or not re.fullmatch(r'[A-Za-z0-9._-]{5,200}',client_id):raise ValueError('Identifiant client OAuth invalide.')
        p=PROVIDERS[provider];r,_=request(p['origin']+p['device'],form={'client_id':client_id,'scope':p['scope']})
        if r.get('error') or not r.get('device_code') or not r.get('user_code'):raise ValueError('Demande OAuth refusée. Vérifiez le client ID et activez le flux appareil.')
        uri=r.get('verification_uri','');expected=urllib.parse.urlsplit(p['origin']).hostname
        if urllib.parse.urlsplit(uri).scheme!='https' or urllib.parse.urlsplit(uri).hostname!=expected:raise ValueError('URL de vérification non autorisée.')
        key=uuid.uuid4().hex; now=time.monotonic(); interval=max(5,int(r.get('interval',5)))
        with self.lock:self.pending[key]={'provider':provider,'client_id':client_id,'code':r['device_code'],'next':now+interval,'interval':interval,'expires':now+min(1800,int(r.get('expires_in',600)))}
        return {'id':key,'userCode':r['user_code'],'uri':uri,'interval':interval}
    def poll(self,key):
        with self.lock:
            item=self.pending.get(key)
            if not item:raise ValueError('Demande expirée ou annulée.')
            now=time.monotonic()
            if now>=item['expires']:self.pending.pop(key,None);return {'state':'expired'}
            if now<item['next']:return {'state':'pending'}
            item['next']=now+item['interval'];p=PROVIDERS[item['provider']]
            r,_=request(p['origin']+p['token'],form={'client_id':item['client_id'],'device_code':item['code'],'grant_type':'urn:ietf:params:oauth:grant-type:device_code'})
            if r.get('error')=='slow_down':item['interval']+=5;item['next']=now+item['interval'];return {'state':'pending'}
            if r.get('error')=='authorization_pending':return {'state':'pending'}
            if r.get('error') or not r.get('access_token'):self.pending.pop(key,None);return {'state':'denied'}
            token=r['access_token'];info=profile(item['provider'],token)
            account={'id':uuid.uuid4().hex,'provider':item['provider'],'login':info['login'],'name':info['name'],
                     'email':info['email'],'emailSource':info['emailSource'],'avatar':info['avatar'],
                     'providerId':info['providerId'],'token':token,'client_id':item['client_id'],
                     'refresh':r.get('refresh_token'),'expiry':(time.time()+int(r['expires_in'])-60) if r.get('expires_in') else None}
            for old in [k for k,v in self.accounts.items() if v['provider']==account['provider'] and v['login']==account['login']]:
                self.accounts.pop(old,None);account_store.store.remove(old)
            self.accounts[account['id']]=account;self.pending.pop(key,None)
        self.persist()
        with self.lock:return {'state':'connected','account':self.public(self.accounts[account['id']])}
    @staticmethod
    def public(a):
        out={k:a.get(k,'') for k in PUBLIC_FIELDS}
        out['persisted']=bool(account_store.enabled())
        return out
    def all(self):
        with self.lock:return [self.public(a) for a in self.accounts.values()]
    def logout(self,key):
        with self.lock:
            self.accounts.pop(key,None);self.pending.pop(key,None)
        # Le retrait est répercuté sur le disque, sinon le compte reviendrait au
        # démarrage suivant.
        account_store.store.remove(key);self.persist()
        return {'ok':True}
    def identity(self,key):
        """Identité de commit publiée par le service pour ce compte."""
        with self.lock:
            a=self._account(key)
            return {'provider':a['provider'],'login':a['login'],'name':a['name'] or a['login'],
                    'email':a['email'],'emailSource':a.get('emailSource',''),'accountId':a['id']}
    def _account(self,key):
        a=self.accounts.get(key)
        if not a:raise ValueError('Compte déconnecté ou session expirée.')
        if a['expiry'] and time.time()>=a['expiry']:
            if not a['refresh']:
                self.accounts.pop(key,None);account_store.store.remove(key);self.persist()
                raise ValueError('Session expirée : reconnectez-vous.')
            p=PROVIDERS[a['provider']];r,_=request(p['origin']+p['token'],form={'grant_type':'refresh_token','client_id':a['client_id'],'refresh_token':a['refresh']})
            if not r.get('access_token'):
                self.accounts.pop(key,None);account_store.store.remove(key);self.persist()
                raise ValueError('Session expirée : reconnectez-vous.')
            a['token']=r['access_token'];a['refresh']=r.get('refresh_token');a['expiry']=time.time()+int(r.get('expires_in',7200))-60
            # Le jeton renouvelé doit survivre au redémarrage.
            self.persist()
        return a
    def credentials(self,key,url):
        with self.lock:
            a=self._account(key);u=urllib.parse.urlsplit(url)
            if u.scheme!='https' or u.hostname!=urllib.parse.urlsplit(PROVIDERS[a['provider']]['origin']).hostname or u.username or u.password or u.port not in (None,443):raise ValueError('Le compte ne correspond pas à ce dépôt HTTPS.')
            return {'user':'x-access-token' if a['provider']=='github' else 'oauth2','token':a['token']}
    def repositories(self,key,page=1):
        with self.lock:
            a=self._account(key);page=max(1,min(1000,int(page)));p=PROVIDERS[a['provider']]
            path=('/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member&page=' if a['provider']=='github' else '/projects?membership=true&simple=true&per_page=100&order_by=last_activity_at&page=')+str(page)
            data,headers=request(p['api']+path,token=a['token']);rows=[]
            if not isinstance(data,list):raise ValueError('Liste des dépôts indisponible.')
            for v in data:
                url=v.get('clone_url') if a['provider']=='github' else v.get('http_url_to_repo');full=v.get('full_name') if a['provider']=='github' else v.get('path_with_namespace')
                if url and full:rows.append({'name':full,'url':url,'private':bool(v.get('private',v.get('visibility')=='private'))})
            link=headers.get('Link','');nextpage=(('rel="next"' in link) if a['provider']=='github' else bool(headers.get('X-Next-Page')))
            return {'repos':rows,'next':nextpage,'page':page}
    def create(self,key,name,private=True,namespace=''):
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,100}',name) or name in ('.','..'):raise ValueError('Nom de dépôt invalide.')
        with self.lock:
            a=self._account(key);p=PROVIDERS[a['provider']];namespace=str(namespace).strip()
            if a['provider']=='github':
                if namespace and not re.fullmatch(r'[A-Za-z0-9-]{1,100}',namespace):raise ValueError('Nom d’organisation invalide.')
                path='/orgs/'+namespace+'/repos' if namespace else '/user/repos';body={'name':name,'private':bool(private),'auto_init':False}
            else:
                if namespace and not namespace.isdigit():raise ValueError('Pour GitLab, indiquez l’identifiant numérique du groupe ou laissez vide.')
                path='/projects';body={'name':name,'visibility':'private' if private else 'public'}
                if namespace:body['namespace_id']=int(namespace)
            data,_=request(p['api']+path,body=body,token=a['token']);url=data.get('clone_url') if a['provider']=='github' else data.get('http_url_to_repo');full=data.get('full_name') if a['provider']=='github' else data.get('path_with_namespace')
            if not url:raise ValueError('Dépôt créé mais URL absente dans la réponse.')
            return {'name':full,'url':url,'private':bool(private)}

manager=AccountManager()
def dispatch(raw):
    try:
        arg=json.loads(raw);action=arg['action']
        if action=='import-cli':result=manager.import_cli(arg.get('provider'))
        elif action=='token':result=manager.add_token(arg.get('provider'),arg.get('token'))
        elif action=='start':result=manager.start(arg.get('provider'),arg.get('clientId'))
        elif action=='poll':result=manager.poll(arg.get('id'))
        elif action=='accounts':result={'accounts':manager.all()}
        elif action=='identity':result=manager.identity(arg.get('id'))
        elif action=='persist-status':result={'status':account_store.store.status()}
        elif action=='persist-purge':
            # Destructif : supprime le fichier chiffré et la clé locale, puis
            # oublie les comptes de la session — l'équivalent d'une déconnexion
            # générale. Le marquage local d'identité Git n'est pas touché : un
            # dépôt garde l'identité que l'utilisateur y a posée.
            with manager.lock:
                manager.accounts.clear();manager.pending.clear()
            result=account_store.store.purge();result['accounts']=manager.all()
        elif action=='logout':result=manager.logout(arg.get('id'))
        elif action=='repos':result=manager.repositories(arg.get('id'),arg.get('page',1))
        elif action=='create':result=manager.create(arg.get('id'),arg.get('name'),arg.get('private',True),arg.get('namespace',''))
        else:raise ValueError('Action inconnue.')
        return json.dumps({'ok':True,**result})
    except Exception as e:return json.dumps({'ok':False,'error':str(e)})
def credentials(key,url):return json.dumps(manager.credentials(key,url))
