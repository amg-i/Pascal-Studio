#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Outils manquants : inventaire réel, et téléchargement de ce qui manque.

POURQUOI CE MODULE EXISTE
    Pascal Studio est un IDE polyglotte : quarante et un langages, donc des dizaines
    de compilateurs, de serveurs de langage, d'adaptateurs de débogage et
    d'outils d'analyse. Aucun n'est livré dans l'AppImage — ce serait illégal
    pour les licences, et ce serait des centaines de mégaoctets. Jusqu'ici,
    quand un outil manquait, chaque panneau affichait la commande à taper et
    s'arrêtait là : l'utilisateur devait ouvrir un terminal, copier, coller,
    recommencer pour l'outil suivant, et deviner l'ordre.

    Ce module fait l'inventaire COMPLET, dit ce qui manque, et installe ce qui
    peut l'être — y compris Ghidra et un JDK, soit près de 800 Mo.

OÙ L'INVENTAIRE EST PRIS (rien n'est inventé ici)
    Ce module ne déclare PAS une seconde fois ce que les autres modules savent
    déjà. Il moissonne quatre sources qui existent dans le produit :

      1. `langages.LANGAGES` — le registre unique des quarante et un langages : ses
         champs `compilateur`, `lsp` (ServeurLsp.binaire et .installation) et
         `dap` (AdaptateurDap.binaire et .installation). C'est la source la plus
         riche : la commande d'installation y est déjà écrite, et elle a été
         vérifiée quand le registre a été écrit.
      2. `retro_detection.OUTILS`, `.BIBLIOTHEQUES`, `.PAQUETS` et
         `.INSTALLATIONS` — les quinze outils d'analyse binaire, les cinq
         bibliothèques Python opportunistes, la table binaire → paquet Debian,
         et les quatre voies d'obtention de Ghidra (dont l'URL amont).
      3. `debogueur_universel.INSTALLATIONS` — la commande d'installation par
         moteur de débogage.
      4. `construire-appimage.py` — `asar` et `mksquashfs`. Ce fichier vit HORS
         de l'image, donc ses deux déclarations sont recopiées ici, et
         `verifier()` contrôle qu'elles n'ont pas changé de sens.

    Conséquence : ajouter un langage au registre fait apparaître son
    compilateur et son serveur ici, sans toucher ce module. L'autocontrôle
    vérifie cette propriété dans les deux sens (défaut connu : une annonce
    dérivée périt en silence quand le module décrit change).

LES TROIS CHOIX DE L'UTILISATEUR (2026-11-11), appliqués tels quels
    1. Paquets Debian : l'application EXÉCUTE l'installation elle-même, via
       `pkexec`, après une confirmation explicite outil par outil, la commande
       exacte étant affichée AVANT. Rien n'est lancé sans clic.
    2. Téléchargements lourds : un bouton « Tout installer » enchaîne tout ce
       qui manque, Ghidra (~570 Mo) et JDK (~200 Mo) compris.
    3. Destination : `~/.local/share/pascal-studio/outils`, un seul exemplaire
       pour tous les projets. `PS_OUTILS_DIR` en change.

CE QUE CE MODULE NE FAIT PAS, ET POURQUOI
    * Il n'installe JAMAIS rien en root sans que l'appelant ait passé
      `racine_autorisee=True`, et cette valeur ne vient que d'un clic. Même
      alors, c'est `pkexec` qui est lancé — donc c'est le système qui demande
      le mot de passe, pas nous, et nous ne le voyons jamais.
    * Il ne modifie aucun paquet déjà installé : `apt-get install`, jamais
      `remove`, `purge`, `autoremove` ni `upgrade`. Aucune commande reçue de
      l'interface n'est concaténée dans une chaîne passée à un interpréteur de
      commandes : tout est une liste d'arguments, et les noms de paquets sont
      filtrés sur `[A-Za-z0-9.+-]`.
    * Il n'invente aucune URL. Trois origines seulement, toutes résolues à
      l'exécution : l'API des publications GitHub pour le dépôt que le registre
      cite déjà, l'API Adoptium pour le JDK, et PyPI/npm via leurs gestionnaires
      officiels. Une archive introuvable dans une publication est ANNONCÉE avec
      la liste de ce que la publication contient vraiment, jamais devinée.
    * Il ne prétend jamais avoir réussi : après chaque installation il
      RE-DÉTECTE le binaire. Une installation qui n'a rien donné est un échec
      nommé, pas un succès.
    * Il ne télécharge pas sans vérifier la place : une archive de 570 Mo
      extraite pèse plus d'un gigaoctet, et un disque plein produit une erreur
      illisible. La place est mesurée avant, et le refus donne les chiffres.
    * Il ne vérifie pas une somme de contrôle qu'il n'a pas : GitHub ne publie
      pas de `.sha256` pour toutes ses archives. Quand l'origine en publie une
      (Adoptium le fait), elle est vérifiée et un écart arrête tout. Quand elle
      n'existe pas, le journal le DIT au lieu de laisser croire à un contrôle.
    * Il n'exécute aucun binaire téléchargé pour « voir s'il marche », sauf
      `--version`, et seulement après extraction complète : c'est ce que
      l'application fera de toute façon au premier usage.

LE CHEMIN DES OUTILS TÉLÉCHARGÉS
    Ce qui est installé sans root atterrit dans le dossier d'état, et
    `etendre_path()` ajoute `<dossier>/bin` à PATH. Sans cela, télécharger ne
    servirait à rien : `shutil.which` continuerait de ne rien trouver. Cette
    fonction est appelée par le serveur au démarrage, AVANT toute résolution
    d'outil.

Usage autonome :
    python3 outils_manquants.py            # inventaire + autocontrôle
"""

import hashlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import re
import shutil
import signal
import subprocess
import sys
import tarfile
import threading
import time
import urllib.error
import urllib.request
import uuid
import zipfile
from pathlib import Path

VERSION = '4.1.0'
MARQUEUR = 'ps-4.1.0-outils'

# Le dossier d'état, partagé entre projets (choix 3 de l'utilisateur).
DOSSIER_ENV = 'PS_OUTILS_DIR'
DOSSIER_DEFAUT = ('.local', 'share', 'pascal-studio', 'outils')

# Bornes. Aucune n'est arbitraire :
LIMITE_JOURNAL = 4000        # entrées conservées par tâche
LIMITE_LIGNE = 4000          # caractères par ligne de sortie d'outil
LIMITE_VERSION = 4           # secondes pour un `--version`
LIMITE_API = 25              # secondes pour une résolution d'URL
LIMITE_LECTURE = 120         # secondes sans aucun octet reçu
OCTETS_PAR_MORCEAU = 262144  # 256 Ko par lecture de téléchargement
MARGE_DISQUE = 3             # archive + extraction + marge
LIMITE_PROBLEMES = 200       # lignes d'un journal d'erreur remonté

# Les deux déclarations recopiées depuis construire-appimage.py, qui vit hors de
# l'image. verifier() contrôle qu'elles correspondent toujours.
CONSTRUCTION = (
    ('asar', 'sudo npm i -g @electron/asar',
     'Empaquetage de l’archive asar de l’interface, nécessaire pour '
     'reconditionner une AppImage.'),
    ('mksquashfs', 'sudo apt install squashfs-tools',
     'Compression SquashFS de l’AppImage, nécessaire pour reconditionner.'),
)

# Binaire → paquet Debian. Chaque ligne est corroborée par une déclaration qui
# existe déjà dans le produit ; verifier() contrôle que TOUT paquet que le
# produit déclare est couvert ici (et non l'inverse : ce module peut couvrir
# plus, par exemple gfortran, que le registre nomme sans donner de commande).
PAQUETS_APT = {
    'gcc': 'build-essential', 'g++': 'build-essential', 'cc': 'build-essential',
    'make': 'make', 'cmake': 'cmake', 'fpc': 'fp-compiler', 'rustc': 'rustc',
    'go': 'golang-go', 'ruby': 'ruby', 'python3': 'python3', 'node': 'nodejs',
    'php': 'php-cli', 'perl': 'perl', 'bash': 'bash', 'lua5.4': 'lua5.4',
    'ocamlfind': 'ocaml', 'ocaml': 'ocaml', 'yabasic': 'yabasic',
    'mcs': 'mono-mcs', 'dotnet': '', 'pdflatex': 'texlive-latex-base',
    'swiftc': 'swiftlang', 'kotlinc': 'kotlin', 'gfortran': 'gfortran',
    'gdb': 'gdb', 'dlv': 'delve', 'rdbg': 'ruby', 'git': 'git',
    'strace': 'strace', 'upx': 'upx-ucl', 'java': 'openjdk-21-jdk',
    'mksquashfs': 'squashfs-tools', 'unzip': 'unzip', 'tar': 'tar',
    'xxd': 'vim-common', 'objdump': 'binutils', 'readelf': 'binutils',
    'nm': 'binutils', 'as': 'binutils', 'ld': 'binutils',
    'c++filt': 'binutils', 'strings': 'binutils', 'od': 'coreutils',
    'file': 'file', 'radare2': 'radare2', 'rizin': 'rizin', 'nasm': 'nasm',
    'clangd': 'clangd', 'rust-analyzer': 'rust-analyzer', 'gopls': 'gopls',
    'fortls': 'fortran-language-server', 'pylsp': 'python3-pylsp',
    'sourcekit-lsp': 'swiftlang', 'texlab': 'texlab', 'jdtls': 'jdtls',
    'bashdb': 'bashdb', 'ocamldebug': 'ocaml', 'pkexec': 'policykit-1',
    'npm': 'npm', 'pip': 'python3-pip', 'pip3': 'python3-pip',
    'gem': 'ruby', 'opam': 'opam', 'cpanm': 'cpanminus',
}

# Paquets Debian que le produit nomme dans ses annonces, et qui ne sont PAS des
# outils avec un exécutable : une bibliothèque Python, un dépôt tiers, une
# dépendance d'exécution. Ils ne peuvent pas figurer dans PAQUETS_APT, qui relie
# un binaire à son paquet, mais l'inventaire doit les connaître — sinon le
# contrôle de synchronisation les signale comme perdus, ou pire, il est affaibli
# pour ne plus les signaler.
PAQUETS_PREREQUIS = {
    'python3-venv': 'Création des environnements virtuels de la voie pip.',
    'python3-jpype': 'Pont Python/JVM : PyGhidra en dépend, et il vient d’apt, '
                     'pas de PyPI.',
    'python3-openpyxl': 'Lecture des classeurs .xlsx par l’onglet Données.',
    'python3-gi': 'Accès aux clefs du trousseau GNOME par le gestionnaire de '
                  'comptes.',
    'default-jre-headless': 'Machine virtuelle Java d’exécution, sans '
                            'interface : Kotlin en dépend.',
    'ruby-debug': 'Adaptateur de débogage Ruby (rdbg).',
    'php-xdebug': 'Pas à pas et variables pour PHP, avec php-cli.',
    'gvfs': 'Accès aux emplacements distants (sftp, smb, dav) par le '
            'gestionnaire de fichiers.',
    'gvfs-backends': 'Les protocoles distants de GVFS.',
    'gvfs-fuse': 'Montage GVFS en système de fichiers FUSE.',
    'gnome-keyring': 'Le trousseau de clefs où les mots de passe des dépôts '
                     'sont gardés.',
    'ghidra': 'Paquet d’un dépôt tiers ou de Kali — Ghidra n’est pas dans '
              'Debian ; retro_detection.INSTALLATIONS donne les quatre voies.',
}

# Outils obtenus d'une publication GitHub. Le dépôt est celui que le produit
# cite déjà, SAUF mention contraire dans `note_depot` — auquel cas la raison est
# écrite, parce qu'un dépôt ajouté ici est une décision, pas une moisson.
AMONT = {
    'lua-language-server': {
        'depot': 'LuaLS/lua-language-server',
        'motif': r'^lua-language-server-.+-linux-{arch}\.tar\.gz$',
        'archive': 'tar.gz', 'racine_archive': True,
        'note_depot': 'Le registre pointe vers https://luals.github.io, le site '
                      'de documentation ; les binaires sont publiés sur ce '
                      'dépôt, vérifié le 2026-11-11 (publication 3.19.2).',
    },
    'marksman': {
        'depot': 'artempyanykh/marksman',
        'motif': r'^marksman-linux-{arch}$',
        'archive': None, 'racine_archive': False,
        'note_depot': '',
    },
    'kotlin-language-server': {
        'depot': 'fwcd/kotlin-language-server',
        'motif': r'^server\.zip$',
        'archive': 'zip', 'racine_archive': True,
        'note_depot': '',
    },
    'ghidra': {
        'depot': 'NationalSecurityAgency/ghidra',
        'motif': r'^ghidra_.+_PUBLIC_.+\.zip$',
        'archive': 'zip', 'racine_archive': True,
        'note_depot': '',
    },
    'pasls': {
        'depot': 'genericptr/pasls',
        'motif': '', 'archive': None, 'racine_archive': False,
        'sans_publication': True,
        'note_depot': 'Ce dépôt ne publie AUCUNE archive : vérifié le '
                      '2026-11-11, /releases/latest rend « Not Found ». Il '
                      'faut le compiler (Nim). Le module l’annonce au lieu de '
                      'télécharger autre chose à sa place.',
    },
    'codelldb': {
        'depot': 'vadimcn/codelldb',
        'motif': '', 'archive': None, 'racine_archive': False,
        'sans_publication': True,
        'note_depot': 'Les archives publiées sont des .vsix (vérifié le '
                      '2026-11-11 : codelldb-linux-x64.vsix, 55 Mo). Un .vsix '
                      'est une extension pour éditeur : la disposition interne '
                      'de l’adaptateur n’est pas un contrat stable, et '
                      'l’extraire ici produirait un chemin qui cesse '
                      'd’exister à la prochaine publication. Le module donne la '
                      'page de publication au lieu de deviner.',
    },
}

# Moteur de débogage → binaire réel. Les clefs de
# debogueur_universel.INSTALLATIONS sont des noms de MOTEURS (« basic », « cs »,
# « script »), pas des exécutables : les prendre pour des binaires ferait
# vérifier `which basic`, qui n’existe pas, et l’outil resterait « manquant »
# même après une installation réussie — donc « Tout installer » recommencerait
# sans fin. Chaque valeur est une clef de PAQUETS_APT, et verifier() le
# contrôle.
MOTEURS = {
    'gdb': 'gdb', 'php': 'php', 'script': 'python3', 'perl': 'perl',
    'bash': 'bash', 'lua': 'lua5.4', 'ocaml': 'ocamlfind', 'basic': 'yabasic',
    'make': 'make', 'cmake': 'cmake', 'cs': 'mcs', 'dap': '',
}

# Les architectures que les publications nomment, et comment elles s'écrivent.
ARCHITECTURES = {'x86_64': ('x64', 'amd64', 'x86_64'),
                 'amd64': ('x64', 'amd64', 'x86_64'),
                 'aarch64': ('arm64', 'aarch64'),
                 'arm64': ('arm64', 'aarch64'),
                 'i386': ('x86', 'i386'),
                 'i686': ('x86', 'i686')}

ADOPTIUM = ('https://api.adoptium.net/v3/assets/latest/{majeure}/hotspot'
            '?architecture={arch}&image_type=jdk&os=linux&vendor=eclipse')
GITHUB_PUBLICATION = 'https://api.github.com/repos/{depot}/releases/latest'
AGENT = 'Pascal-Studio/%s (outil de diagnostic local)' % VERSION

# Un binaire peut porter plusieurs noms selon la distribution.
ALIASES = {'ocamlfind': ('ocamlfind', 'ocaml'), 'mcs': ('mcs', 'mono-mcs'),
           'lua5.4': ('lua5.4', 'lua', 'lua5.3'), 'php': ('php', 'php8'),
           'g++': ('g++', 'c++'), 'node': ('node', 'nodejs')}

FAMILLES = ('compilateurs', 'serveurs de langage', 'débogage',
            'rétro-ingénierie', 'bibliothèques Python', 'construction',
            'analyse avancée', 'gestionnaires')

_CACHE = {'instant': 0.0, 'duree': 30.0, 'etat': None}
_VERROU = threading.RLock()
_TACHES = {}


# --------------------------------------------------------------------------- #
# Le dossier d'état, et le PATH.
# --------------------------------------------------------------------------- #

def dossier_outils():
    """Le dossier où ce qui est téléchargé est rangé.

    `PS_OUTILS_DIR` a priorité : un utilisateur qui veut tout dans son projet,
    ou qui teste, ne doit pas avoir à déplacer son dossier personnel.
    """
    fixe = os.environ.get(DOSSIER_ENV, '').strip()
    if fixe:
        return Path(fixe).expanduser()
    return Path.home().joinpath(*DOSSIER_DEFAUT)


def _sous(nom):
    return dossier_outils() / nom


def preparer_dossier():
    """Crée l'arborescence et rend ses chemins. Ne lève jamais."""
    base = dossier_outils()
    chemins = {'dossier': base, 'bin': base / 'bin',
               'telechargements': base / 'telechargements',
               'extraits': base / 'extraits', 'venvs': base / 'venvs',
               'node': base / 'node', 'journal': base / 'journal.json'}
    notes = []
    for cle, chemin in chemins.items():
        if cle == 'journal':
            continue
        try:
            chemin.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            notes.append('Le dossier %s n’a pas pu être créé : %s'
                         % (chemin, exc.strerror or exc))
    chemins['notes'] = notes
    return chemins


def etendre_path():
    """Ajoute `<dossier>/bin` à PATH, une seule fois, et rend le chemin.

    Sans cet appel, télécharger ne servirait à rien : `shutil.which('marksman')`
    continuerait de ne rien trouver alors que le binaire est là. Le serveur
    l'appelle au démarrage, avant toute résolution d'outil.

    Le dossier est ajouté EN TÊTE : un outil installé ici doit l'emporter sur
    une version ancienne du système, sinon l'utilisateur qui vient d'installer
    un serveur de langage verrait encore « manquant ».
    """
    with _VERROU:
        binaires = _sous('bin')
        try:
            binaires.mkdir(parents=True, exist_ok=True)
        except OSError:
            return str(binaires)
        actuel = os.environ.get('PATH', '')
        morceaux = [m for m in actuel.split(os.pathsep) if m]
        if str(binaires) not in morceaux:
            os.environ['PATH'] = os.pathsep.join([str(binaires)] + morceaux)
        return str(binaires)


def chemin_outils():
    """L'état du dossier d'outils : chemins, place libre, présence dans PATH."""
    base = dossier_outils()
    binaires = base / 'bin'
    try:
        usage = shutil.disk_usage(str(base if base.exists() else Path.home()))
        libre = usage.free
    except OSError:
        libre = 0
    morceaux = [m for m in os.environ.get('PATH', '').split(os.pathsep) if m]
    return {'dossier': str(base), 'bin': str(binaires),
            'telechargements': str(base / 'telechargements'),
            'extraits': str(base / 'extraits'), 'venvs': str(base / 'venvs'),
            'node': str(base / 'node'),
            'existe': base.is_dir(), 'dans_path': str(binaires) in morceaux,
            'libre_octets': libre,
            'variable': DOSSIER_ENV}


# --------------------------------------------------------------------------- #
# Détection d'un binaire.
# --------------------------------------------------------------------------- #

def _candidats(nom):
    """Les noms à chercher dans PATH pour un binaire déclaré."""
    vus = [nom]
    for autre in ALIASES.get(nom, ()):
        if autre not in vus:
            vus.append(autre)
    return vus


def _localiser(nom):
    """Cherche un binaire, en suivant les liens symboliques.

    `shutil.which` ne résout pas les liens : /usr/bin/readelf peut désigner
    ../bin/x86_64-linux-gnu-readelf. Nommer un chemin et en lancer un autre
    rendrait un diagnostic faux, donc le chemin rendu est le chemin réel quand
    il existe et qu'il est exécutable.
    """
    for candidat in _candidats(nom):
        trouve = shutil.which(candidat)
        if not trouve:
            continue
        try:
            reel = os.path.realpath(trouve)
        except OSError:
            return trouve
        if os.path.isfile(reel) and os.access(reel, os.X_OK):
            return reel
        return trouve
    return None


def _environnement_outil():
    """Environnement où la locale est imposée, pour LIRE une version.

    `--version` de binutils, de gcc et de java est traduit : « gcc (Debian
    14.2.0-1) 14.2.0 » devient « gcc (Debian …) » entouré de texte français, et
    la lecture du numéro échoue. C'est exactement la panne qui a arrêté une
    construction en Debian 13 sur readelf. Ici nous LISONS la sortie, donc la
    locale est imposée. Elle ne l'est PAS pour apt : nous ne lisons pas sa
    sortie, nous la montrons à l'utilisateur, qui la préfère dans sa langue.
    """
    environnement = dict(os.environ)
    environnement['LC_ALL'] = 'C.UTF-8'
    environnement['LC_MESSAGES'] = 'C'
    environnement['LANGUAGE'] = 'C'
    environnement['TERM'] = 'dumb'
    return environnement


def _version(chemin, arguments=('--version',)):
    """Lit la version d'un outil déjà trouvé. Rend '' plutôt que de lever."""
    try:
        termine = subprocess.run([chemin] + list(arguments),
                                 capture_output=True, text=True,
                                 timeout=LIMITE_VERSION, errors='replace',
                                 stdin=subprocess.DEVNULL,
                                 env=_environnement_outil())
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return ''
    brut = ((termine.stdout or '') + (termine.stderr or '')).strip()
    if not brut:
        return ''
    # Un numéro de version, s'il y en a un ; sinon la première ligne, bornée.
    trouve = re.search(r'(\d+(?:\.\d+){1,3}[A-Za-z0-9+._-]*)', brut)
    return (trouve.group(1) if trouve else brut.splitlines()[0])[:80]


def detecter(nom, avec_version=False):
    """L'état d'un binaire : présent, chemin, version."""
    chemin = _localiser(nom)
    if not chemin:
        return {'nom': nom, 'present': False, 'chemin': '', 'version': ''}
    version = _version(chemin) if avec_version else ''
    return {'nom': nom, 'present': True, 'chemin': chemin, 'version': version}


def detecter_plusieurs(noms, avec_version=False):
    return [detecter(n, avec_version) for n in noms]


def detecter_groupe(groupe, avec_version=False):
    """L'état des binaires d'un groupe, selon ce que ce groupe EST.

    Une bibliothèque Python n'a pas d'exécutable dans PATH : chercher `which
    capstone` la déclare absente pour toujours, même installée, et « Tout
    installer » la réinstallerait à chaque passage. Sa présence se lit par
    `importlib.util.find_spec`, qui ne l'importe pas — importer capstone
    chargerait une extension C pour un simple état.

    La version vient d'`importlib.metadata`, qui lit les métadonnées du paquet
    sans importer le module non plus.
    """
    if groupe.get('famille') != 'bibliothèques Python':
        return detecter_plusieurs(groupe['binaires'], avec_version)
    etendre_syspath()
    # Sans ça, un paquet qui vient d'être installé dans --target peut rester
    # invisible : les « finders » ont mis en cache le contenu des chemins.
    importlib.invalidate_caches()
    sortie = []
    for module in groupe['binaires']:
        try:
            present = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):
            present = False
        version = ''
        if avec_version and present:
            for candidat in (groupe.get('nom', ''), module):
                try:
                    version = importlib.metadata.version(candidat)
                    break
                except Exception:
                    continue
        sortie.append({'nom': module, 'present': present, 'chemin': '',
                       'version': version, 'module': module})
    return sortie


# --------------------------------------------------------------------------- #
# Les voies d'obtention, lues dans les commandes déjà déclarées.
# --------------------------------------------------------------------------- #

_MOTIFS_VOIE = (
    ('apt', re.compile(r'^(?:sudo\s+)?apt(?:-get)?\s+(?:install|i)\s+(.+)$')),
    ('npm', re.compile(r'^(?:sudo\s+)?npm\s+(?:i|install|add)\s+'
                       r'(?:-g\s+|--global\s+)?(.+)$')),
    ('pipx', re.compile(r'^pipx\s+install\s+(.+)$')),
    ('pip', re.compile(r'^(?:pip3?|python3?\s+-m\s+pip)\s+install\s+(.+)$')),
    ('gem', re.compile(r'^gem\s+install\s+(.+)$')),
    ('opam', re.compile(r'^opam\s+install\s+(.+)$')),
    ('cpan', re.compile(r'^cpan(?:m)?\s+install\s+(.+)$')),
    ('dotnet', re.compile(r'^dotnet\s+tool\s+install\s+'
                          r'(?:--global\s+)?(.+)$')),
)
_MOTIF_ADOPTIUM = re.compile(r'^adoptium\s+jdk\s+(\d{2})$')
_MOTIF_URL = re.compile(r'https?://[^\s)\]]+')
_MOTIF_DEPOT = re.compile(r'https?://github\.com/([A-Za-z0-9_.-]+)/'
                          r'([A-Za-z0-9_.-]+)')
_MOTIF_PAQUET = re.compile(r'^[A-Za-z0-9][A-Za-z0-9.+-]*$')
# Les méta-caractères d'un interpréteur de commandes. S'il y en a un seul dans
# une commande déclarée, TOUT est refusé en bloc et la raison est rendue : trier
# mot à mot laissait passer `rm` dans « binutils; rm -rf / », parce que le
# premier mot était refusé pour son point-virgule et que le deuxième ressemblait
# à un nom de paquet. Les caractères de développement glob (!*?[]{}), qui ne
# figurent dans aucun nom de paquet réel, sont refusés pour la même raison :
# refuser tout vaut mieux que deviner lesquels sont inoffensifs.
_META_CARACTERES = (';', '|', '&', '$', '<', '>', '`', '(', ')', '{', '}',
                    '[', ']', '!', '*', '?', '\\', '\n', '\r', "'", '"')


def _nettoyer_paquets(brut):
    """Filtre une liste de noms : rien qui ne soit un nom de paquet plausible.

    Une commande déclarée dans une phrase peut porter un point final, une
    parenthèse ou un commentaire. Passer cela à apt-get installerait n'importe
    quoi ; le filtre refuse au lieu de deviner.
    """
    propres = []
    refuses = []
    brut = str(brut)
    dangereux = [c for c in _META_CARACTERES if c in brut]
    if dangereux:
        return [], ['entrée refusée en bloc (%s) : %s'
                    % (' '.join(sorted(set(dangereux))), brut)]
    for morceau in brut.split():
        nom = morceau.strip().strip('.').strip()
        if not nom or nom.startswith('-'):
            if nom:
                refuses.append(morceau)
            continue
        if _MOTIF_PAQUET.match(nom):
            if nom not in propres:
                propres.append(nom)
        else:
            refuses.append(morceau)
    return propres, refuses


def route(commande_declaree, binaire=''):
    """Traduit la commande d'installation déclarée en une voie exploitable.

    Rend un dictionnaire : voie, paquets, cible, racine, url, depot, notes.
    Une commande non reconnue rend `voie='manuel'` et la commande telle quelle :
    ce module ne devine pas une voie, il la lit.
    """
    brut = (commande_declaree or '').strip()
    # `racine` vaut False par défaut : seul apt a besoin des droits root, et
    # c'est la branche apt qui le dit. Une voie non reconnue n'est jamais
    # exécutée, donc elle ne demande rien.
    sortie = {'voie': 'manuel', 'paquets': [], 'cible': binaire,
              'racine': False, 'url': '', 'depot': '', 'commande': brut,
              'notes': [], 'refuses': []}
    if not brut:
        sortie['voie'] = 'inconnue'
        sortie['notes'].append('Aucune commande d’installation n’est déclarée '
                               'pour %s.' % (binaire or 'cet outil'))
        return sortie
    sortie['url'] = (_MOTIF_URL.search(brut).group(0) if _MOTIF_URL.search(brut)
                     else '')
    correspondance = _MOTIF_ADOPTIUM.match(brut)
    if correspondance:
        # Une voie à part : l'API Adoptium rend l'URL ET la somme de
        # contrôle SHA-256 publiée. Aucune URL n'est écrite ici.
        majeure = correspondance.group(1)
        sortie['voie'] = 'adoptium'
        sortie['paquets'] = [majeure]
        sortie['cible'] = 'jdk-temurin-%s' % majeure
        sortie['racine'] = False
        sortie['url'] = ADOPTIUM.format(majeure=majeure, arch='{arch}')
        sortie['notes'].append('Résolu à l’exécution par l’API Adoptium, qui '
                               'publie l’URL et sa somme SHA-256.')
        return sortie
    if brut.startswith('voir'):
        sortie['voie'] = 'amont'
        sortie['racine'] = False
        correspondance = _MOTIF_DEPOT.search(brut)
        if correspondance:
            sortie['depot'] = '%s/%s' % (correspondance.group(1),
                                         correspondance.group(2).rstrip('/.'))
        else:
            sortie['notes'].append('La commande déclarée renvoie vers %s, qui '
                                   'n’est pas une publication GitHub : aucune '
                                   'archive ne peut être résolue ici.'
                                   % (sortie['url'] or 'une page amont'))
        return sortie
    for voie, motif in _MOTIFS_VOIE:
        correspondance = motif.match(brut)
        if not correspondance:
            continue
        paquets, refuses = _nettoyer_paquets(correspondance.group(1))
        sortie['voie'] = voie
        sortie['paquets'] = paquets
        sortie['refuses'] = refuses
        sortie['cible'] = paquets[0] if paquets else binaire
        # Seul apt a besoin de root. npm et pip sont DÉTOURNÉS vers le dossier
        # d'outils : la commande déclarée dit « sudo npm i -g », qui écrit dans
        # /usr/lib/node_modules ; ici c'est installé dans le dossier de
        # l'utilisateur, sans root, et l'écart est ANNONCÉ plutôt que tu.
        sortie['racine'] = voie == 'apt'
        if voie == 'npm' and brut.startswith('sudo'):
            sortie['notes'].append(
                'La commande déclarée installe en root (`%s`). Ici '
                'l’installation se fait dans %s, sans droits root.'
                % (brut, _sous('node')))
        if voie in ('pipx', 'pip'):
            sortie['voie'] = 'pip'
            sortie['notes'].append(
                'La commande déclarée passe par %s. Ici un environnement '
                'virtuel est créé dans %s : rien n’est écrit dans le Python du '
                'système, que Debian 13 protège (PEP 668).'
                % ('pipx' if voie == 'pipx' else 'pip', _sous('venvs')))
        if refuses:
            sortie['notes'].append('Morceaux non reconnus comme des noms de '
                                   'paquet, ignorés : %s' % ', '.join(refuses))
        return sortie
    sortie['notes'].append('La commande déclarée « %s » ne correspond à aucune '
                           'voie automatisable : elle est affichée telle quelle.'
                           % brut)
    return sortie


# --------------------------------------------------------------------------- #
# L'inventaire, moissonné.
# --------------------------------------------------------------------------- #

def _registre_langages():
    """Charge `langages` même si le module a un nom à point ou tiret."""
    try:
        import langages
        return langages
    except Exception:
        return None


def _retro_detection():
    try:
        import retro_detection
        return retro_detection
    except Exception:
        return None


def _debogueur():
    try:
        import debogueur_universel
        return debogueur_universel
    except Exception:
        return None


def _moisson():
    """Les déclarations brutes : (binaire, commande, rôle, famille, langages).

    C'est la seule fonction qui connaît la forme des registres. Tout le reste
    trie et regroupe.
    """
    declarations = []
    registre = _registre_langages()
    if registre is None:
        return declarations, ['Le registre langages.py n’a pas pu être chargé : '
                              'l’inventaire des compilateurs et des serveurs de '
                              'langage est vide.']
    for cle, langage in sorted(getattr(registre, 'LANGAGES', {}).items()):
        libelle = getattr(langage, 'libelle', cle)
        compilateur = getattr(langage, 'compilateur', '') or ''
        if compilateur:
            declarations.append((
                compilateur, '',
                'Compilation et exécution des fichiers %s.' % libelle,
                'compilateurs', [libelle]))
        for serveur in getattr(langage, 'lsp', ()) or ():
            declarations.append((
                serveur.binaire, serveur.installation or '',
                'Complétion et diagnostics en continu pour %s.' % libelle,
                'serveurs de langage', [libelle]))
        for adaptateur in getattr(langage, 'dap', ()) or ():
            declarations.append((
                adaptateur.binaire, adaptateur.installation or '',
                'Débogage pas à pas de %s (protocole DAP).' % libelle,
                'débogage', [libelle]))
        for commande in getattr(langage, 'commande_essai', ()) or ():
            if commande and commande != compilateur:
                declarations.append((
                    commande, '',
                    'Exécution des exemples de l’aide %s.' % libelle,
                    'compilateurs', [libelle]))
    detection = _retro_detection()
    if detection is None:
        return declarations, ['retro_detection.py n’a pas pu être chargé : les '
                              'outils d’analyse binaire ne sont pas inventoriés.']
    for nom, commande, role, _indispensable in getattr(detection, 'OUTILS', ()):
        paquet = getattr(detection, 'PAQUETS', {}).get(commande, '')
        declarations.append((
            commande,
            ('sudo apt install %s' % paquet) if paquet else '',
            role, 'rétro-ingénierie', []))
    for nom, module, role in getattr(detection, 'BIBLIOTHEQUES', ()):
        declarations.append((module, 'pip install %s' % nom, role,
                             'bibliothèques Python', []))
    debogueur = _debogueur()
    if debogueur is not None:
        for moteur, commande in sorted(
                getattr(debogueur, 'INSTALLATIONS', {}).items()):
            if not commande.startswith(('sudo', 'gem', 'pip', 'npm', 'opam',
                                        'cpan', 'dotnet', 'voir')):
                continue
            binaire = MOTEURS.get(moteur, '')
            if not binaire:
                continue
            declarations.append((binaire, commande,
                                 'Débogage des langages dont le moteur est '
                                 '« %s ».' % moteur, 'débogage', []))
    for binaire, commande, role in CONSTRUCTION:
        declarations.append((binaire, commande, role, 'construction', []))
    # Les gestionnaires dont dépendent les voies ci-dessus. Sans npm, la voie
    # npm ne peut rien ; le dire ici plutôt que dans une erreur d'exécution.
    for binaire, paquet, role in (
            ('npm', 'npm', 'Voie npm : serveurs de langage JavaScript, asar.'),
            ('pkexec', 'policykit-1',
             'Exécution des installations apt avec la demande de mot de passe '
             'du système.'),
            ('unzip', 'unzip', 'Extraction des archives .zip (Ghidra).'),
            ('opam', 'opam', 'Voie opam : serveur de langage OCaml.'),
            ('cpanm', 'cpanminus', 'Voie cpan : serveur de langage Perl.'),
            ('gem', 'ruby', 'Voie gem : solargraph, debug.')):
        declarations.append((binaire, 'sudo apt install %s' % paquet, role,
                             'gestionnaires', []))
    # L'analyse avancée : Ghidra et le JDK, moissonnés depuis les voies que
    # retro_detection déclare déjà — dont l'URL amont, jamais recopiée ici.
    installations = {i.get('id'): i
                     for i in getattr(detection, 'INSTALLATIONS', ())}
    amont_ghidra = installations.get('zip-amont', {})
    source = amont_ghidra.get('source', '')
    declarations.append((
        'ghidraRun', 'voir %s' % (source or 'https://github.com/'
                                  'NationalSecurityAgency/ghidra/releases'),
        'Décompilation, références croisées et graphe d’appels. Environ 570 Mo, '
        'et un JDK 21 ou plus récent.', 'analyse avancée', []))
    declarations.append((
        'jdk-temurin', 'adoptium jdk 21',
        'JDK 21 sans droits root, téléchargé depuis l’API Adoptium avec sa '
        'somme de contrôle SHA-256 publiée. Utile quand openjdk-21-jdk ne peut '
        'pas être installé.', 'analyse avancée', []))
    return declarations, []


def _identifiant(voie, cible, binaire):
    return '%s:%s' % (voie, cible or binaire)


def inventaire(avec_versions=False):
    """L'inventaire complet, regroupé par CE QUI S'INSTALLE ENSEMBLE.

    Quatre serveurs `vscode-*-language-server` viennent d'un seul paquet npm :
    ils font une seule entrée, avec les quatre binaires listés. Sans ce
    regroupement, l'utilisateur verrait quatre fois la même installation et
    « Tout installer » la lancerait quatre fois.
    """
    declarations, notes = _moisson()
    groupes = {}
    ordre = []
    for binaire, commande, role, famille, langages in declarations:
        voie = route(commande, binaire)
        if voie['voie'] == 'apt' and binaire in PAQUETS_APT and PAQUETS_APT[binaire]:
            # Le registre ne donne pas toujours la commande ; la table des
            # paquets complète, et c'est la même information.
            paquet = PAQUETS_APT[binaire]
            if paquet not in voie['paquets']:
                voie['paquets'] = [paquet] + voie['paquets']
                voie['cible'] = paquet
                voie['commande'] = 'sudo apt install %s' % paquet
        if voie['voie'] == 'amont' and binaire in AMONT and not voie['depot']:
            voie['depot'] = AMONT[binaire]['depot']
            if AMONT[binaire].get('note_depot'):
                voie['notes'].append(AMONT[binaire]['note_depot'])
        if voie['voie'] == 'inconnue' and binaire in PAQUETS_APT \
                and PAQUETS_APT[binaire]:
            voie = route('sudo apt install %s' % PAQUETS_APT[binaire], binaire)
        cible = voie['cible']
        if len(voie['paquets']) > 1 and binaire in voie['paquets']:
            # `sudo npm i -g typescript typescript-language-server` : nommer le
            # groupe « typescript » cacherait ce qu'il installe vraiment.
            cible = binaire
            voie['cible'] = cible
        identifiant = _identifiant(voie['voie'], cible, binaire)
        if identifiant not in groupes:
            groupes[identifiant] = {
                'id': identifiant, 'nom': voie['cible'] or binaire,
                'famille': famille, 'roles': [], 'binaires': [],
                'langages': [], 'voie': voie['voie'], 'paquets': voie['paquets'],
                'racine': voie['racine'], 'commande': voie['commande'],
                'url': voie['url'], 'depot': voie['depot'], 'notes': [],
                'refuses': voie['refuses'],
            }
            ordre.append(identifiant)
        groupe = groupes[identifiant]
        if binaire not in groupe['binaires']:
            groupe['binaires'].append(binaire)
        if role and role not in groupe['roles']:
            groupe['roles'].append(role)
        for nom in langages:
            if nom not in groupe['langages']:
                groupe['langages'].append(nom)
        for note in voie['notes']:
            if note not in groupe['notes']:
                groupe['notes'].append(note)

    # Détection réelle, binaire par binaire.
    outils = []
    for identifiant in ordre:
        groupe = groupes[identifiant]
        etats = detecter_groupe(groupe, avec_versions)
        manquants = [e['nom'] for e in etats if not e['present']]
        groupe['present'] = not manquants
        groupe['manquants'] = manquants
        groupe['detection'] = etats
        groupe['role'] = ' '.join(groupe['roles'])[:600]
        groupe['langage'] = ', '.join(groupe['langages'][:8])
        groupe['gestionnaire'] = _gestionnaire(groupe['voie'])
        groupe['telechargeable'] = _telechargeable(groupe)
        if groupe['voie'] == 'manuel' or groupe['voie'] == 'inconnue':
            groupe['telechargeable'] = False
        if groupe['gestionnaire'] and not _localiser(groupe['gestionnaire']):
            # PAQUETS_APT peut mapper un gestionnaire sur une chaîne VIDE : c'est
            # le cas de dotnet, que Debian ne paquet pas. Recopier cette chaîne
            # vide donnait « (paquet Debian : ). » — une remarque qui montre son
            # propre trou. Le paquet n'est nommé que s'il existe.
            paquet = PAQUETS_APT.get(groupe['gestionnaire'],
                                     groupe['gestionnaire'])
            suite = (' (paquet Debian : %s).' % paquet) if paquet else \
                ' et aucun paquet Debian ne le fournit.'
            groupe['notes'].append(
                'Le gestionnaire `%s` est absent : cette installation ne peut '
                'pas être lancée tant qu’il n’est pas là%s'
                % (groupe['gestionnaire'], suite))
            groupe['telechargeable'] = False
        if groupe['voie'] == 'apt' and groupe['racine'] \
                and not _localiser('pkexec'):
            groupe['notes'].append(
                'L’installation demande les droits root et `pkexec` est '
                'absent : la commande est donnée, mais elle ne peut pas être '
                'lancée d’ici. Paquet Debian : policykit-1.')
            groupe['telechargeable'] = False
        if groupe['paquets'] == [] and groupe['voie'] == 'apt':
            groupe['notes'].append('Aucun paquet Debian n’est connu pour %s.'
                                   % ', '.join(groupe['binaires']))
            groupe['telechargeable'] = False
        if groupe['voie'] == 'inconnue' and groupe['nom'] == 'dotnet':
            groupe['notes'].append(
                'Le SDK .NET n’est pas dans Debian : il vient de son éditeur. '
                'Sans lui, C# reste analysé statiquement et compilé par mono '
                '(paquet mono-mcs), qui est dans Debian.')
        fiche_amont, clef_amont = _fiche_amont(groupe)
        groupe['amont_clef'] = clef_amont
        groupe['amont'] = dict(fiche_amont)
        if fiche_amont.get('sans_publication'):
            groupe['notes'].append(fiche_amont['note_depot'])
        if groupe['voie'] == 'adoptium':
            groupe['notes'].append('Aucun droit root : l’archive est extraite '
                                   'dans %s et son `bin` est lié dans %s.'
                                   % (_sous('extraits'), _sous('bin')))
        if groupe['refuses']:
            groupe['telechargeable'] = False
        outils.append(groupe)
    return {'ok': not notes, 'outils': outils, 'notes': notes,
            'avec_versions': bool(avec_versions)}


def _gestionnaire(voie):
    return {'npm': 'npm', 'pip': 'python3', 'gem': 'gem', 'opam': 'opam',
            'cpan': 'cpanm', 'dotnet': 'dotnet', 'apt': 'apt-get',
            'amont': 'python3', 'adoptium': 'python3'}.get(voie, '')


def _fiche_amont(groupe):
    """La fiche AMONT d'un groupe, par son nom OU par son dépôt.

    Le binaire de Ghidra s'appelle `ghidraRun` et sa fiche `ghidra` :
    chercher par le seul nom laisserait l'outil le plus attendu sans
    archive reconnue. Le dépôt, lui, vient de l'URL que retro_detection
    déclare déjà : le rapprochement ne devine donc rien.
    """
    for clef in [groupe['nom']] + list(groupe['binaires']):
        if clef in AMONT:
            return AMONT[clef], clef
    if groupe['depot']:
        for clef, fiche in sorted(AMONT.items()):
            if fiche.get('depot') == groupe['depot']:
                return fiche, clef
    return {}, groupe['nom']


def _telechargeable(groupe):
    """Ce qui peut être obtenu sans intervention manuelle de l'utilisateur."""
    voie = groupe['voie']
    if voie == 'apt':
        return bool(groupe['paquets'])
    if voie == 'npm':
        return bool(groupe['paquets'])
    if voie == 'pip':
        return bool(groupe['paquets'])
    if voie in ('gem', 'opam', 'cpan', 'dotnet'):
        return bool(groupe['paquets'])
    if voie == 'adoptium':
        return True
    if voie == 'amont':
        if not groupe['depot']:
            return False
        fiche, _clef = _fiche_amont(groupe)
        if fiche.get('sans_publication'):
            return False
        return bool(fiche.get('motif'))
    return False


def etat(avec_versions=False, rafraichir=False):
    """L'inventaire, mis en cache trente secondes.

    Le cache existe parce que la fenêtre des paramètres peut être ouverte
    plusieurs fois de suite, et que soixante `shutil.which` plus les notes
    coûtent assez pour être visibles.
    """
    with _VERROU:
        if (not rafraichir and _CACHE['etat'] is not None
                and _CACHE['etat'].get('avec_versions') == bool(avec_versions)
                and (time.monotonic() - _CACHE['instant']) < _CACHE['duree']):
            return _CACHE['etat']
    resultat = inventaire(avec_versions)
    outils = resultat['outils']
    manquants = [o for o in outils if not o['present']]
    installables = [o for o in manquants if o['telechargeable']]
    resultat.update({
        'ok': True,
        'marqueur': MARQUEUR,
        'version': VERSION,
        'avec_versions': bool(avec_versions),
        'chemins': chemin_outils(),
        'gestionnaires': etat_gestionnaires(),
        'total': len(outils),
        'presents': len(outils) - len(manquants),
        'manquants': len(manquants),
        'installables': len(installables),
        'manuels': len(manquants) - len(installables),
        'familles': {f: {'total': 0, 'manquants': 0} for f in FAMILLES},
        'resume': '',
    })
    for outil in outils:
        famille = resultat['familles'].setdefault(
            outil['famille'], {'total': 0, 'manquants': 0})
        famille['total'] += 1
        if not outil['present']:
            famille['manquants'] += 1
    resultat['liste'] = [
        {'id': o['id'], 'nom': o['nom'], 'famille': o['famille'],
         'role': o['role'], 'langage': o['langage'], 'present': o['present'],
         'binaires': o['binaires'], 'manquants': o['manquants'],
         'voie': o['voie'], 'racine': o['racine'], 'paquets': o['paquets'],
         'commande': o['commande'] or _commande_proposee(o),
         'telechargeable': o['telechargeable'],
         'gestionnaire': o['gestionnaire'], 'depot': o['depot'], 'url': o['url'],
         'notes': o['notes'], 'detection': o['detection']}
        for o in outils]
    # Les groupes COMPLETS : la liste légère ci-dessus est ce que le panneau
    # affiche, pas ce que le plan exécute. Les installeurs ont besoin des
    # fiches amont, des binaires et des notes.
    resultat['groupes'] = {o['id']: o for o in outils}
    resultat['resume'] = (
        '%d outil(s) inventoriés, %d présent(s), %d manquant(s) dont %d '
        'installable(s) d’ici et %d à la main.'
        % (resultat['total'], resultat['presents'], resultat['manquants'],
           resultat['installables'], resultat['manuels']))
    with _VERROU:
        _CACHE['etat'] = resultat
        _CACHE['instant'] = time.monotonic()
    return resultat


def _commande_proposee(outil):
    """La commande à taper soi-même quand l'application ne peut pas la lancer."""
    voie = outil['voie']
    if voie == 'apt' and outil['paquets']:
        return 'sudo apt-get install -y %s' % ' '.join(outil['paquets'])
    if voie == 'npm' and outil['paquets']:
        return 'sudo npm install -g %s' % ' '.join(outil['paquets'])
    if voie == 'pip' and outil['paquets']:
        return 'pipx install %s' % outil['paquets'][0]
    if voie == 'adoptium':
        return 'voir https://adoptium.net/ (JDK %s, archive vérifiée par sa ' \
               'somme SHA-256)' % (outil['paquets'] or ['21'])[0]
    if voie == 'amont':
        if outil['depot']:
            return 'voir https://github.com/%s/releases' % outil['depot']
        return 'voir %s' % (outil['url'] or 'la page du projet')
    if outil['commande']:
        return outil['commande']
    if outil['url']:
        return 'voir %s' % outil['url']
    return ''


def etat_gestionnaires():
    """Les gestionnaires dont dépendent les voies, détectés."""
    sortie = {}
    for nom in ('apt-get', 'pkexec', 'npm', 'node', 'python3', 'pip3', 'pip',
                'gem', 'opam', 'cpanm', 'dotnet', 'unzip', 'tar', 'curl',
                'wget'):
        sortie[nom] = bool(_localiser(nom))
    try:
        sortie['module_venv'] = importlib.util.find_spec('venv') is not None
    except (ImportError, ValueError):
        sortie['module_venv'] = False
    sortie['pip_utilisable'] = bool(sortie['module_venv']) or sortie['pip3'] \
        or sortie['pip']
    return sortie


def capacites():
    """Ce que ce module affirme de lui-même. Le panneau l'affiche telle quelle."""
    gestionnaires = etat_gestionnaires()
    return {
        'marqueur': MARQUEUR,
        'version': VERSION,
        'resume': 'Inventaire des outils externes de Pascal Studio et '
                  'installation de ce qui manque.',
        'dossier': chemin_outils(),
        'gestionnaires': gestionnaires,
        'installe_en_root_apres_confirmation': True,
        'root_par_defaut': False,
        'telecharge_depuis': ('api.github.com', 'api.adoptium.net', 'pypi.org',
                              'registry.npmjs.org'),
        'invente_des_urls': False,
        'execute_des_binaires_telecharges': 'seulement --version, après '
                                            'extraction complète',
        'modifie_des_paquets_installes': False,
        'commandes_interdites': ('remove', 'purge', 'autoremove', 'upgrade',
                                 'dist-upgrade'),
        'familles': list(FAMILLES),
        'sources': ('langages.LANGAGES', 'retro_detection.OUTILS',
                    'retro_detection.BIBLIOTHEQUES',
                    'retro_detection.PAQUETS', 'retro_detection.INSTALLATIONS',
                    'debogueur_universel.INSTALLATIONS',
                    'construire-appimage.py'),
        'ok': True,
    }


# --------------------------------------------------------------------------- #
# Les tâches : un journal borné, un arrêt réel.
# --------------------------------------------------------------------------- #

def _nouvelle_tache(identifiants, racine_autorisee=False, agent=None):
    """Ouvre une tâche d'installation et rend son identifiant."""
    identifiant = uuid.uuid4().hex[:16]
    tache = {
        'sid': identifiant,
        'identifiants': list(identifiants),
        'racine_autorisee': bool(racine_autorisee),
        'agent': agent or '',
        'etat': 'en attente',
        'etape': 0,
        'etapes': 0,
        'journal': [],
        'arret': threading.Event(),
        'progression': {'octets': 0, 'total': 0, 'pourcentage': None,
                        'vitesse': 0.0, 'reste': None},
        'resultats': [],
        'debut': time.time(),
        'fin': None,
        'processus': None,
        'verrou': threading.Lock(),
    }
    with _VERROU:
        _TACHES[identifiant] = tache
    return tache


def _dire(tache, niveau, texte, **suite):
    """Ajoute une ligne au journal d'une tâche. Le journal est BORNÉ.

    Une installation de Ghidra peut produire des dizaines de milliers de lignes
    (npm et pip sont bavards). Sans borne, la tâche mangerait la mémoire de la
    machine — 16 Go partagés avec l'éditeur. Les lignes les plus anciennes sont
    jetées, et le journal dit qu'elles l'ont été.
    """
    if tache is None:
        return
    texte = str(texte)
    if len(texte) > LIMITE_LIGNE:
        texte = texte[:LIMITE_LIGNE] + '… [ligne tronquée]'
    entree = {'t': round(time.time(), 3), 'niveau': niveau, 'texte': texte}
    entree.update(suite)
    with tache['verrou']:
        tache['journal'].append(entree)
        perdus = len(tache['journal']) - LIMITE_JOURNAL
        if perdus > 0:
            del tache['journal'][:perdus]
            if not tache.get('journal_tronque'):
                tache['journal_tronque'] = perdus
                tache['journal'].insert(
                    0, {'t': round(time.time(), 3), 'niveau': 'info',
                        'texte': '%d ligne(s) plus ancienne(s) ont été jetées : '
                                 'le journal est borné à %d entrées.'
                                 % (perdus, LIMITE_JOURNAL)})
            else:
                tache['journal_tronque'] += perdus


def suivre(sid, depuis=0):
    """L'état d'une tâche et les lignes ajoutées depuis `depuis`."""
    with _VERROU:
        tache = _TACHES.get(str(sid))
    if tache is None:
        return {'ok': False, 'erreur': 'Tâche inconnue : %s' % sid,
                'lignes': [], 'depuis': depuis}
    with tache['verrou']:
        journal = list(tache['journal'])
        etat = tache['etat']
        progression = dict(tache['progression'])
        resultats = list(tache['resultats'])
        etape, etapes = tache['etape'], tache['etapes']
        tronque = tache.get('journal_tronque', 0)
        ids = list(tache['identifiants'])
        debut, fin = tache['debut'], tache['fin']
    lignes = journal[depuis:] if depuis >= 0 else journal
    return {'ok': True, 'sid': tache['sid'], 'etat': etat,
            'identifiants': ids, 'etape': etape, 'etapes': etapes,
            'progression': progression, 'resultats': resultats,
            'lignes': lignes, 'depuis': depuis + len(lignes),
            'journal_tronque': tronque,
            'duree': round((fin or time.time()) - debut, 2),
            'arrete': tache['arret'].is_set()}


def taches():
    """Les tâches connues, sans leur journal."""
    with _VERROU:
        cles = list(_TACHES)
    return {'ok': True, 'taches': [
        {k: v for k, v in suivre(sid).items() if k != 'lignes'}
        for sid in cles]}


def arreter(sid):
    """Arrête une tâche : le signal, puis le groupe de processus.

    `start_new_session=True` place l'enfant dans son propre groupe : sans cela,
    `apt-get` survivrait et continuerait d'écrire dans le journal d'une tâche
    que l'utilisateur croit arrêtée — et npm laisse des processus fils.
    """
    with _VERROU:
        tache = _TACHES.get(str(sid))
    if tache is None:
        return {'ok': False, 'erreur': 'Tâche inconnue : %s' % sid}
    tache['arret'].set()
    processus = tache.get('processus')
    tue = False
    if processus is not None and processus.poll() is None:
        try:
            os.killpg(os.getpgid(processus.pid), signal.SIGTERM)
            tue = True
        except (OSError, ProcessLookupError):
            tue = False
    with tache['verrou']:
        if tache['etat'] in ('en cours', 'en attente'):
            tache['etat'] = 'arrêté'
    _dire(tache, 'arret', 'Arrêt demandé par l’utilisateur.')
    return {'ok': True, 'sid': str(sid), 'processus_tue': tue,
            'etat': suivre(sid)['etat']}


# --------------------------------------------------------------------------- #
# L'exécution d'une commande, avec sa sortie dans le journal.
# --------------------------------------------------------------------------- #

def _flux(commande, tache=None, cwd=None, environnement=None, racine=False):
    """Lance une commande en liste d'arguments et journalise sa sortie.

    Trois règles, et chacune vient d'un défaut réel du projet :
      * JAMAIS d'interpréteur de commandes : `commande` est une liste, donc un
        nom de paquet contenant une espace ou un point-virgule ne peut pas
        devenir une seconde commande ;
      * la locale N'EST PAS imposée ici : nous ne lisons pas cette sortie, nous
        la montrons. apt, npm et pip répondent dans la langue de l'utilisateur
        et c'est ce qu'il veut lire. La locale est imposée seulement là où une
        expression régulière travaille (`_version`) ;
      * le code de retour est rendu TEL QUEL. Une sortie exploitable avec un
        code non nul est marquée `averti`, pas `échec` : c'est la leçon de
        readelf, qui avertit sur le segment PHDR puis répond correctement.
    """
    if not commande:
        return {'ok': False, 'code': None, 'sortie': '',
                'erreur': 'Aucune commande à lancer.'}
    if tache is not None and tache['arret'].is_set():
        return {'ok': False, 'code': None, 'sortie': '', 'arrete': True,
                'erreur': 'Arrêt déjà demandé : la commande n’est pas lancée.'}
    texte_commande = ' '.join(str(c) for c in commande)
    _dire(tache, 'commande', ('$ ' if racine else '$ ') + texte_commande)
    try:
        processus = subprocess.Popen(
            [str(c) for c in commande], stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL, text=True,
            bufsize=1, errors='replace', cwd=str(cwd) if cwd else None,
            env=environnement, start_new_session=True)
    except FileNotFoundError:
        return {'ok': False, 'code': None, 'sortie': '',
                'erreur': 'Commande introuvable : %s' % commande[0]}
    except OSError as exc:
        return {'ok': False, 'code': None, 'sortie': '',
                'erreur': 'La commande n’a pas pu être lancée : %s'
                          % (exc.strerror or exc)}
    if tache is not None:
        with tache['verrou']:
            tache['processus'] = processus
    # Un chien de garde, et ce n'est pas un luxe : la boucle ci-dessous lit la
    # sortie ligne à ligne, donc un enfant SILENCIEUX (sleep, un apt-get qui
    # attend, un npm qui résout) la bloque indéfiniment et le drapeau d'arrêt
    # n'est jamais regardé. Sans ce fil, « Arrêter » ne faisait rien tant que
    # l'enfant n'écrivait pas.
    garde = None
    if tache is not None:
        def _surveiller():
            while processus.poll() is None:
                if tache['arret'].is_set():
                    try:
                        os.killpg(os.getpgid(processus.pid), signal.SIGTERM)
                    except (OSError, ProcessLookupError):
                        try:
                            processus.terminate()
                        except OSError:
                            pass
                    return
                if tache['arret'].wait(0.2):
                    continue
        garde = threading.Thread(target=_surveiller,
                                 name='garde-outils', daemon=True)
        garde.start()
    lignes = []
    try:
        for ligne in processus.stdout:
            ligne = ligne.rstrip('\n')
            if not ligne.strip():
                continue
            lignes.append(ligne[-LIMITE_PROBLEMES:])
            if len(lignes) > LIMITE_PROBLEMES:
                del lignes[0]
            _dire(tache, 'sortie', ligne)
            if tache is not None and tache['arret'].is_set():
                try:
                    os.killpg(os.getpgid(processus.pid), signal.SIGTERM)
                except (OSError, ProcessLookupError):
                    processus.terminate()
                _dire(tache, 'arret', 'Le processus a été terminé : '
                                      'arrêt demandé.')
                break
    except (OSError, ValueError) as exc:
        _dire(tache, 'erreur', 'La lecture de la sortie a échoué : %s' % exc)
    finally:
        try:
            processus.stdout.close()
        except Exception:
            pass
    try:
        code = processus.wait(timeout=30)
    except subprocess.TimeoutExpired:
        processus.kill()
        code = processus.wait()
        _dire(tache, 'erreur', 'Le processus ne s’est pas arrêté en 30 s : il '
                               'a été tué.')
    if tache is not None:
        with tache['verrou']:
            tache['processus'] = None
    if garde is not None:
        garde.join(timeout=2)
    arrete = tache is not None and tache['arret'].is_set()
    return {'ok': code == 0 and not arrete, 'code': code, 'arrete': arrete,
            'sortie': '\n'.join(lignes[-LIMITE_PROBLEMES:]),
            'commande': texte_commande, 'erreur': ''}


def _code_interdit(commande):
    """Refuse les verbes apt qui détruiraient quelque chose.

    Ce module installe. Il ne désinstalle, ne purge, ne nettoie et ne met pas à
    jour la distribution : une case cochée dans une fenêtre ne doit pas pouvoir
    casser un système. Le contrôle porte sur la commande construite, pas sur
    l'intention.
    """
    interdits = ('remove', 'purge', 'autoremove', 'upgrade', 'dist-upgrade',
                 'full-upgrade', '--purge', '--remove')
    mots = [str(m) for m in commande]
    for mot in mots:
        if mot in interdits:
            return mot
    return ''


# --------------------------------------------------------------------------- #
# Le réseau : trois origines, aucune URL inventée.
# --------------------------------------------------------------------------- #

def _machine():
    """L'architecture, et les noms que les publications emploient pour elle."""
    machine = platform.machine() or ''
    jetons = ARCHITECTURES.get(machine)
    if not jetons:
        return machine, ()
    return machine, jetons


def _requete(url, entetes=None, delai=LIMITE_API):
    """Une requête HTTP GET. Rend (code, entetes, corps). Ne lève jamais.

    Rendre le code plutôt que lever est un choix : une publication absente (404)
    et une limite de débit atteinte (403) sont deux informations différentes
    pour l'utilisateur, et une exception les écraserait toutes les deux en
    « impossible de joindre le réseau ».
    """
    demande = urllib.request.Request(url)
    demande.add_header('User-Agent', AGENT)
    demande.add_header('Accept', 'application/vnd.github+json, application/json')
    for cle, valeur in (entetes or {}).items():
        demande.add_header(cle, valeur)
    try:
        with urllib.request.urlopen(demande, timeout=delai) as reponse:
            return reponse.status, dict(reponse.headers), reponse.read()
    except urllib.error.HTTPError as exc:
        try:
            corps = exc.read()
        except Exception:
            corps = b''
        return exc.code, dict(exc.headers or {}), corps
    except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
        raison = getattr(exc, 'reason', exc)
        return 0, {}, str(raison).encode('utf-8', 'replace')


def resoudre_amont(groupe, delai=LIMITE_API):
    """Résout l'archive d'un outil publié sur GitHub, à l'exécution.

    Rien n'est écrit à l'avance : l'API des publications rend la version
    courante, la liste des archives, leurs tailles et leurs adresses. Choisir
    une archive se fait par le motif déclaré dans AMONT — et si aucune archive
    ne correspond, la réponse NOMME la publication et liste ce qu'elle contient
    vraiment. Deviner une adresse, ou télécharger « la première archive venue »,
    installerait un binaire Windows sur une Debian.
    """
    fiche, clef = _fiche_amont(groupe)
    depot = groupe.get('depot') or fiche.get('depot') or ''
    page = 'https://github.com/%s/releases' % depot if depot else ''
    if not depot:
        return {'ok': False, 'raison': 'Aucun dépôt GitHub n’est déclaré pour '
                                       '%s.' % groupe.get('nom'),
                'page': page, 'clef': clef}
    if fiche.get('sans_publication'):
        return {'ok': False, 'raison': fiche.get('note_depot') or
                'Ce dépôt ne publie aucune archive exploitable.',
                'page': page, 'clef': clef}
    motif = fiche.get('motif') or ''
    if not motif:
        return {'ok': False, 'raison': 'Aucun motif d’archive n’est déclaré '
                                       'pour %s : rien ne peut être choisi sans '
                                       'deviner.' % clef,
                'page': page, 'clef': clef}
    machine, jetons = _machine()
    if not jetons:
        return {'ok': False,
                'raison': 'L’architecture %s n’est pas reconnue : aucune '
                          'archive ne peut être choisie sans risquer un '
                          'binaire inutilisable.' % (machine or 'inconnue'),
                'page': page, 'clef': clef}
    expression = motif.replace('{arch}', '(?:%s)' % '|'.join(jetons))
    try:
        expression_re = re.compile(expression)
    except re.error as exc:
        return {'ok': False, 'raison': 'Le motif d’archive %r n’est pas une '
                                       'expression régulière valable : %s'
                                       % (expression, exc),
                'page': page, 'clef': clef}
    code, entetes, corps = _requete(GITHUB_PUBLICATION.format(depot=depot),
                                    delai=delai)
    if code == 0:
        return {'ok': False, 'raison': 'L’API GitHub n’a pas répondu : %s'
                % corps.decode('utf-8', 'replace')[:200],
                'page': page, 'clef': clef}
    if code == 404:
        return {'ok': False,
                'raison': 'Le dépôt %s ne publie aucune version (l’API rend '
                          '404). Il faut compiler cet outil.' % depot,
                'page': page, 'clef': clef}
    if code == 403 or code == 429:
        reste = entetes.get('X-RateLimit-Remaining', entetes.get(
            'x-ratelimit-remaining', '?'))
        return {'ok': False,
                'raison': 'L’API GitHub a refusé la requête (code %d, '
                          'requêtes restantes : %s). Sans compte, la limite '
                          'est de 60 requêtes par heure et par adresse IP.'
                          % (code, reste),
                'page': page, 'clef': clef}
    if code != 200:
        return {'ok': False, 'raison': 'L’API GitHub a répondu %d.' % code,
                'page': page, 'clef': clef}
    try:
        publication = json.loads(corps.decode('utf-8', 'replace'))
    except ValueError as exc:
        return {'ok': False, 'raison': 'La réponse de l’API n’est pas du JSON '
                                       'valable : %s' % exc,
                'page': page, 'clef': clef}
    actifs = publication.get('assets') or []
    candidats = [a for a in actifs
                 if isinstance(a, dict) and expression_re.match(str(a.get('name', '')))]
    if not candidats:
        noms = [str(a.get('name', '?')) for a in actifs if isinstance(a, dict)]
        return {'ok': False,
                'raison': 'Aucune archive de la publication %s ne correspond à '
                          '%s pour une architecture %s. La publication '
                          'contient : %s'
                          % (publication.get('tag_name', '?'), expression,
                             machine, ', '.join(noms[:20]) or 'rien'),
                'page': page, 'clef': clef,
                'publication': publication.get('tag_name', ''),
                'actifs': noms[:40]}
    choix = candidats[0]
    url = str(choix.get('browser_download_url') or '')
    if not url.startswith('https://'):
        return {'ok': False, 'raison': 'L’adresse rendue par l’API n’est pas '
                                       'HTTPS : %r' % url,
                'page': page, 'clef': clef}
    return {'ok': True, 'clef': clef, 'depot': depot,
            'publication': publication.get('tag_name', ''),
            'nom_archive': str(choix.get('name', '')),
            'url': url, 'taille': int(choix.get('size') or 0),
            'archive': fiche.get('archive'),
            'racine_archive': bool(fiche.get('racine_archive')),
            'somme': '', 'somme_algorithme': '', 'page': page,
            'notes': ['Aucune somme de contrôle n’est publiée avec cette '
                      'archive : le téléchargement est vérifié par sa taille, '
                      'pas par son contenu.']}


def resoudre_adoptium(majeure='21', delai=LIMITE_API):
    """Résout un JDK Temurin par l'API Adoptium, avec sa somme SHA-256.

    Contrairement à GitHub, Adoptium publie la somme de contrôle : elle est
    vérifiée après téléchargement, et un écart supprime le fichier. C'est la
    seule origine de ce module dont le contenu est contrôlé, et le journal le
    dit — annoncer une vérification qui n'a pas eu lieu serait pire que ne pas
    en faire.
    """
    machine, jetons = _machine()
    architecture = 'x64' if machine in ('x86_64', 'amd64') else (
        'aarch64' if machine in ('aarch64', 'arm64') else '')
    if not architecture:
        return {'ok': False, 'raison': 'L’architecture %s n’est pas reconnue '
                                       'par l’API Adoptium.' % (machine or '?')}
    url = ADOPTIUM.format(majeure=str(majeure), arch=architecture)
    code, _entetes, corps = _requete(url, delai=delai)
    if code != 200:
        return {'ok': False, 'raison': 'L’API Adoptium a répondu %d pour %s.'
                % (code, url), 'url': url}
    try:
        assets = json.loads(corps.decode('utf-8', 'replace'))
    except ValueError as exc:
        return {'ok': False, 'raison': 'La réponse Adoptium n’est pas du JSON '
                                       'valable : %s' % exc, 'url': url}
    if not isinstance(assets, list) or not assets:
        return {'ok': False, 'raison': 'L’API Adoptium n’a rendu aucun JDK %s '
                                       'pour linux/%s.' % (majeure, architecture),
                'url': url}
    premier = assets[0]
    paquet = ((premier.get('binary') or {}).get('package') or {})
    lien = str(paquet.get('link') or '')
    if not lien.startswith('https://'):
        return {'ok': False, 'raison': 'L’adresse rendue par Adoptium n’est '
                                       'pas HTTPS : %r' % lien, 'url': url}
    return {'ok': True, 'clef': 'jdk-temurin-%s' % majeure,
            'publication': premier.get('release_name', ''),
            'nom_archive': str(paquet.get('name') or ''),
            'url': lien, 'taille': int(paquet.get('size') or 0),
            'archive': 'tar.gz', 'racine_archive': True,
            'somme': str(paquet.get('checksum') or ''),
            'somme_algorithme': 'sha256',
            'somme_url': str(paquet.get('checksum_link') or ''),
            'page': 'https://adoptium.net/', 'notes': []}


# --------------------------------------------------------------------------- #
# Télécharger, vérifier, extraire.
# --------------------------------------------------------------------------- #

def _place_necessaire(taille_attendue, marge=MARGE_DISQUE):
    """La place est-elle suffisante ? Le refus donne les chiffres."""
    chemins = preparer_dossier()
    try:
        libre = shutil.disk_usage(str(chemins['dossier'])).free
    except OSError as exc:
        return False, 'La place libre n’a pas pu être mesurée : %s' % (
            exc.strerror or exc)
    necessaire = int(taille_attendue) * marge
    if necessaire and libre < necessaire:
        return False, ('Place insuffisante : %s disponibles, %s nécessaires '
                       '(archive de %s, extraite, plus la marge ×%d). Libérez '
                       'de la place ou changez %s.'
                       % (_octets(libre), _octets(necessaire),
                          _octets(taille_attendue), marge, DOSSIER_ENV))
    return True, ''


def _octets(n):
    n = float(n or 0)
    for unite in ('o', 'Ko', 'Mo', 'Go', 'To'):
        if abs(n) < 1024 or unite == 'To':
            return ('%.0f %s' % (n, unite)) if unite == 'o' else (
                '%.1f %s' % (n, unite))
        n /= 1024.0
    return '%.1f To' % n


def telecharger_fichier(url, destination, tache=None, somme_attendue='',
                        taille_attendue=0, delai=LIMITE_LECTURE):
    """Télécharge un fichier, avec reprise et somme de contrôle.

    La reprise compte : 570 Mo sur une ligne domestique, c'est plusieurs
    minutes, et une coupure ne doit pas tout faire recommencer. Elle n'est
    possible que si le serveur répond 206 à un en-tête Range ; s'il répond 200,
    le fichier est repris de zéro et le journal le dit.

    Le fichier est écrit dans un `.part` et renommé à la fin : un fichier
    interrompu ne doit jamais ressembler à un fichier complet, sinon la
    prochaine exécution l'extrairait.
    """
    destination = Path(destination)
    temporaire = destination.with_suffix(destination.suffix + '.part')
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {'ok': False, 'erreur': 'Le dossier %s n’a pas pu être créé : %s'
                % (destination.parent, exc.strerror or exc)}
    deja = temporaire.stat().st_size if temporaire.exists() else 0
    if destination.exists() and taille_attendue \
            and destination.stat().st_size == taille_attendue:
        _dire(tache, 'info', 'L’archive %s est déjà téléchargée (%s).'
              % (destination.name, _octets(taille_attendue)))
        if somme_attendue:
            reelle = _somme_fichier(destination, tache)
            if reelle != somme_attendue:
                return {'ok': False,
                        'erreur': 'L’archive déjà présente ne correspond pas à '
                                  'la somme publiée : attendue %s, lue %s. '
                                  'Elle est supprimée.'
                                  % (somme_attendue, reelle)}
            _dire(tache, 'ok', 'Somme de contrôle SHA-256 conforme.')
        return {'ok': True, 'chemin': str(destination), 'repris': 0,
                'octets': destination.stat().st_size, 'somme': somme_attendue}
    entetes = {}
    if deja:
        entetes['Range'] = 'bytes=%d-' % deja
        _dire(tache, 'info', 'Reprise du téléchargement à %s.' % _octets(deja))
    demande = urllib.request.Request(url)
    demande.add_header('User-Agent', AGENT)
    for cle, valeur in entetes.items():
        demande.add_header(cle, valeur)
    try:
        reponse = urllib.request.urlopen(demande, timeout=delai)
    except urllib.error.HTTPError as exc:
        return {'ok': False, 'erreur': 'Le serveur a répondu %d pour %s.'
                % (exc.code, url)}
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return {'ok': False, 'erreur': 'Le téléchargement n’a pas pu démarrer : '
                                       '%s' % getattr(exc, 'reason', exc)}
    with reponse:
        statut = getattr(reponse, 'status', 200)
        if deja and statut == 200:
            _dire(tache, 'info', 'Le serveur ignore l’en-tête Range (réponse '
                                 '200) : le fichier est repris de zéro.')
            deja = 0
        elif deja and statut not in (200, 206):
            return {'ok': False, 'erreur': 'Réponse inattendue %d pour une '
                                           'reprise.' % statut}
        total = taille_attendue or int(
            reponse.headers.get('Content-Length') or 0) + deja
        mode = 'ab' if (deja and statut == 206) else 'wb'
        hachoir = hashlib.sha256()
        if mode == 'ab' and deja:
            # La somme doit porter sur le fichier ENTIER, pas sur la suite.
            hachoir.update(_lire_morceaux(temporaire, deja))
        recu = 0 if mode == 'wb' else deja
        depart = time.monotonic()
        annonce = depart
        try:
            with temporaire.open(mode) as fichier:
                while True:
                    if tache is not None and tache['arret'].is_set():
                        _dire(tache, 'arret', 'Téléchargement interrompu à %s '
                                              'sur %s ; le fichier partiel est '
                                              'conservé pour une reprise.'
                              % (_octets(recu), _octets(total)))
                        return {'ok': False, 'arrete': True,
                                'erreur': 'Arrêté par l’utilisateur.',
                                'chemin': str(temporaire), 'octets': recu}
                    morceau = reponse.read(OCTETS_PAR_MORCEAU)
                    if not morceau:
                        break
                    fichier.write(morceau)
                    hachoir.update(morceau)
                    recu += len(morceau)
                    maintenant = time.monotonic()
                    if tache is not None and maintenant - annonce >= 1.0:
                        vitesse = recu / max(maintenant - depart, 0.001)
                        with tache['verrou']:
                            tache['progression'] = {
                                'octets': recu, 'total': total,
                                'pourcentage': (round(100.0 * recu / total, 1)
                                                if total else None),
                                'vitesse': round(vitesse, 1),
                                'reste': (round((total - recu) / vitesse)
                                          if total and vitesse > 0 else None)}
                        _dire(tache, 'progression',
                              '%s / %s (%s/s)%s' % (
                                  _octets(recu), _octets(total) or '?',
                                  _octets(vitesse),
                                  '' if not total else ' — %.1f %%'
                                  % (100.0 * recu / total)),
                              octets=recu, total=total)
                        annonce = maintenant
        except (OSError, TimeoutError) as exc:
            return {'ok': False,
                    'erreur': 'Le téléchargement s’est arrêté à %s : %s. Le '
                              'fichier partiel est conservé pour une reprise.'
                              % (_octets(recu), exc),
                    'chemin': str(temporaire), 'octets': recu}
    if total and recu != total:
        return {'ok': False,
                'erreur': 'Le téléchargement est incomplet : %s reçus sur %s '
                          'annoncés. Le fichier partiel est conservé ; '
                          'relancez pour reprendre.'
                          % (_octets(recu), _octets(total)),
                'chemin': str(temporaire), 'octets': recu}
    somme = hachoir.hexdigest()
    if somme_attendue and somme != somme_attendue.lower():
        try:
            temporaire.unlink()
        except OSError:
            pass
        return {'ok': False,
                'erreur': 'La somme de contrôle ne correspond pas : attendue '
                          '%s, lue %s. Le fichier a été supprimé, rien n’est '
                          'extrait.' % (somme_attendue, somme)}
    try:
        os.replace(str(temporaire), str(destination))
        os.chmod(str(destination), 0o644)
    except OSError as exc:
        return {'ok': False, 'erreur': 'Le fichier téléchargé n’a pas pu être '
                                       'mis en place : %s' % (exc.strerror or exc)}
    duree = round(time.monotonic() - depart, 1)
    _dire(tache, 'ok', '%s téléchargé : %s en %s s (SHA-256 %s%s).'
          % (destination.name, _octets(recu), duree, somme[:16],
             '…, conforme à la somme publiée' if somme_attendue
             else '…, aucune somme publiée par l’origine'))
    return {'ok': True, 'chemin': str(destination), 'octets': recu,
            'somme': somme, 'somme_conforme': bool(somme_attendue),
            'duree': duree}


def _lire_morceaux(chemin, limite):
    """Relit le début d'un fichier partiel pour poursuivre sa somme."""
    lu = bytearray()
    try:
        with Path(chemin).open('rb') as fichier:
            while len(lu) < limite:
                morceau = fichier.read(min(OCTETS_PAR_MORCEAU,
                                           limite - len(lu)))
                if not morceau:
                    break
                lu.extend(morceau)
    except OSError:
        return bytes(lu)
    return bytes(lu)


def _somme_fichier(chemin, tache=None):
    hachoir = hashlib.sha256()
    try:
        with Path(chemin).open('rb') as fichier:
            while True:
                morceau = fichier.read(OCTETS_PAR_MORCEAU)
                if not morceau:
                    break
                hachoir.update(morceau)
    except OSError as exc:
        _dire(tache, 'erreur', 'La somme de %s n’a pas pu être lue : %s'
              % (chemin, exc.strerror or exc))
        return ''
    return hachoir.hexdigest()


def _nom_sur(nom):
    """Un nom d'archive est-il sans danger pour un chemin ?

    Une archive peut contenir `../../.bashrc` ou `/etc/passwd` : l'extraire
    aveuglément écrirait hors du dossier voulu. C'est la faille dite « zip
    slip ». Chaque membre est refusé s'il est absolu ou s'il remonte.
    """
    if not nom or nom.startswith('/') or nom.startswith('\\'):
        return False
    if ':' in nom:
        return False
    parties = Path(nom).parts
    return not any(p == '..' for p in parties)


def _extraire(archive, cible, tache=None, racine_archive=False):
    """Extrait une archive dans `cible`. Rend {'ok', 'racine', 'entrees'}."""
    archive = Path(archive)
    cible = Path(cible)
    nom = archive.name.lower()
    try:
        cible.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {'ok': False, 'erreur': 'Le dossier %s n’a pas pu être créé : %s'
                % (cible, exc.strerror or exc)}
    refuses = []
    entrees = 0
    _dire(tache, 'info', 'Extraction de %s dans %s' % (archive.name, cible))
    if nom.endswith('.zip'):
        try:
            with zipfile.ZipFile(archive) as paquet:
                for info in paquet.infolist():
                    if not _nom_sur(info.filename):
                        refuses.append(info.filename)
                        continue
                    paquet.extract(info, str(cible))
                    entrees += 1
        except (zipfile.BadZipFile, OSError, ValueError) as exc:
            return {'ok': False, 'erreur': 'L’archive zip est illisible : %s'
                    % exc, 'refuses': refuses}
    elif nom.endswith(('.tar.gz', '.tgz', '.tar.xz', '.tar.bz2', '.tar')):
        try:
            with tarfile.open(archive) as paquet:
                membres = []
                for membre in paquet.getmembers():
                    if not _nom_sur(membre.name):
                        refuses.append(membre.name)
                        continue
                    membres.append(membre)
                try:
                    # Python 3.12+ : le filtre 'data' refuse en plus les liens
                    # hors de l'arborescence, les périphériques et les modes
                    # setuid. Python 3.11 ne le connaît pas : le tri ci-dessus
                    # reste appliqué, et l'écart est annoncé.
                    paquet.extractall(str(cible), members=membres,
                                      filter='data')
                except TypeError:
                    _dire(tache, 'info',
                          'Ce Python ne connaît pas le filtre d’extraction '
                          '« data » : le tri des membres a été fait à la main.')
                    paquet.extractall(str(cible), members=membres)
                entrees = len(membres)
        except (tarfile.TarError, OSError, ValueError) as exc:
            return {'ok': False, 'erreur': 'L’archive tar est illisible : %s'
                    % exc, 'refuses': refuses}
    else:
        return {'ok': False,
                'erreur': 'Le format de %s n’est pas reconnu : ni .zip ni '
                          '.tar.gz. Rien n’est extrait au hasard.'
                          % archive.name}
    if refuses:
        _dire(tache, 'averti', '%d entrée(s) refusée(s) parce que leur nom '
                               'remonte hors du dossier ou est absolu : %s'
              % (len(refuses), ', '.join(refuses[:5])))
    racine = ''
    try:
        visibles = [p for p in cible.iterdir() if not p.name.startswith('.')]
        if len(visibles) == 1 and visibles[0].is_dir():
            racine = str(visibles[0])
    except OSError:
        visibles = []
    _dire(tache, 'ok', '%d entrée(s) extraite(s)%s.'
          % (entrees, ', sous %s' % Path(racine).name if racine else ''))
    return {'ok': True, 'entrees': entrees, 'refuses': refuses,
            'racine': racine, 'cible': str(cible)}


def _lier(exe, tache=None):
    """Lie un exécutable dans `<dossier>/bin`, qui est dans PATH."""
    exe = Path(exe)
    if not exe.is_file():
        return {'ok': False, 'erreur': '%s n’est pas un fichier.' % exe}
    if not os.access(str(exe), os.X_OK):
        try:
            exe.chmod(exe.stat().st_mode | 0o111)
        except OSError as exc:
            return {'ok': False,
                    'erreur': '%s n’est pas exécutable et n’a pas pu le '
                              'devenir : %s' % (exe, exc.strerror or exc)}
    binaires = preparer_dossier()['bin']
    lien = binaires / exe.name
    try:
        if lien.is_symlink() or lien.exists():
            lien.unlink()
        lien.symlink_to(exe.resolve())
    except OSError as exc:
        return {'ok': False, 'erreur': 'Le lien %s n’a pas pu être créé : %s'
                % (lien, exc.strerror or exc)}
    _dire(tache, 'ok', '%s est maintenant dans %s' % (exe.name, binaires))
    return {'ok': True, 'lien': str(lien), 'cible': str(exe.resolve())}


def _chercher_executables(racine, noms, limite=20000):
    """Les exécutables d'une arborescence extraite, par nom demandé.

    Borné : une arborescence de Ghidra compte plus de dix mille fichiers, et
    une recherche sans borne sur un disque lent se verrait. Rend aussi les
    exécutables trouvés dans un dossier `bin`, qui servent de repli annoncé.
    """
    voulus = {n: None for n in noms}
    binaires = []
    vus = 0
    for chemin, dossiers, fichiers in os.walk(str(racine)):
        dossiers[:] = [d for d in dossiers if not d.startswith('.')]
        vus += len(fichiers)
        if vus > limite:
            break
        dans_bin = Path(chemin).name == 'bin'
        for nom in fichiers:
            complet = Path(chemin) / nom
            if nom in voulus and voulus[nom] is None:
                voulus[nom] = str(complet)
            elif dans_bin and len(binaires) < 50:
                try:
                    if os.access(str(complet), os.X_OK):
                        binaires.append(str(complet))
                except OSError:
                    continue
    return voulus, binaires, vus > limite


def etendre_syspath():
    """Ajoute `<dossier>/python` à sys.path, EN FIN, une seule fois.

    Les bibliothèques Python opportunistes (capstone, pyelftools, pefile, lief,
    unicorn) ne servent à rien dans un environnement virtuel : c'est
    l'interpréteur du serveur qui doit les voir, puisqu'il appelle
    `importlib.util.find_spec`. Elles sont donc installées avec
    `pip install --target` dans ce dossier, qui est ajouté à sys.path.

    EN FIN, et ce n'est pas un détail : une bibliothèque installée ici ne doit
    jamais masquer celle du système. Et `vendor-python` — les pilotes de bases
    de données livrés dans l'image — n'entre JAMAIS dans sys.path : ils sont
    chargés explicitement par leur module, parce qu'une copie pure Python mise
    en tête de chemin masquerait le vrai pilote. verifier() contrôle les deux.
    """
    with _VERROU:
        cible = str(_sous('python'))
        try:
            Path(cible).mkdir(parents=True, exist_ok=True)
        except OSError:
            return cible
        if cible not in sys.path:
            sys.path.append(cible)
        return cible


# --------------------------------------------------------------------------- #
# Les installeurs, un par voie.
# --------------------------------------------------------------------------- #

def _apres(groupe, tache):
    """Re-détecte les binaires d'un groupe. Rien n'est déclaré réussi sans ça.

    Un gestionnaire peut rendre 0 et n'avoir rien installé (npm le fait quand le
    paquet est déjà satisfait ailleurs, apt quand un paquet virtuel est choisi).
    La seule preuve qui vaille est que le binaire est maintenant dans PATH.
    """
    etats = detecter_groupe(groupe, True)
    encore = [e['nom'] for e in etats if not e['present']]
    if encore:
        _dire(tache, 'echec', 'Toujours absent(s) après l’installation : %s.'
              % ', '.join(encore))
    else:
        _dire(tache, 'ok', 'Présent(s) maintenant : %s.'
              % ', '.join('%s%s' % (e['nom'], ' (%s)' % e['version']
                                    if e['version'] else '')
                          for e in etats))
    return {'ok': not encore, 'encore': encore, 'detection': etats}


def _installer_apt(groupe, tache):
    """apt-get install, via pkexec, et seulement si l'utilisateur l'a autorisé.

    Tous les paquets apt du plan sont installés EN UNE commande : une seule
    demande de mot de passe pour quarante outils, au lieu de quarante. C'est le
    système (polkit) qui demande le mot de passe, jamais nous.
    """
    paquets = groupe['paquets']
    if not paquets:
        return {'ok': False, 'erreur': 'Aucun paquet Debian à installer.'}
    if not tache['racine_autorisee']:
        commande = 'sudo apt-get install -y %s' % ' '.join(paquets)
        _dire(tache, 'refus', 'Installation en root non autorisée : rien n’est '
                              'lancé. Commande à taper vous-même : %s'
              % commande)
        return {'ok': False, 'refus': True, 'erreur': 'Droits root non '
                                                      'autorisés.',
                'commande': commande}
    pkexec = _localiser('pkexec')
    if not pkexec:
        commande = 'sudo apt-get install -y %s' % ' '.join(paquets)
        _dire(tache, 'echec', '`pkexec` est absent (paquet policykit-1) : '
                              'aucune demande de mot de passe ne peut être '
                              'présentée depuis l’application. Commande à '
                              'taper vous-même : %s' % commande)
        return {'ok': False, 'erreur': 'pkexec absent.', 'commande': commande}
    commande = [pkexec, 'env', 'DEBIAN_FRONTEND=noninteractive',
                'apt-get', 'install', '-y', '--no-install-recommends'] + paquets
    interdit = _code_interdit(commande)
    if interdit:
        return {'ok': False,
                'erreur': 'La commande construite contient « %s », qui est '
                          'interdit : ce module installe, il ne détruit pas.'
                          % interdit}
    resultat = _flux(commande, tache, racine=True)
    if not resultat['ok']:
        sortie = resultat.get('sortie', '')
        notes = []
        if resultat.get('code') in (126, 127, 128):
            notes.append('pkexec a rendu le code %s : le plus souvent, aucun '
                         'agent d’authentification polkit n’est joignable '
                         'depuis cette session. Lancez la commande dans un '
                         'terminal.' % resultat.get('code'))
        notes.append('Si un paquet est introuvable, l’index est peut-être '
                     'périmé : sudo apt-get update, puis relancez.')
        if sortie:
            notes.append('Dernières lignes : %s'
                         % ' | '.join(sortie.splitlines()[-6:]))
        return {'ok': False, 'erreur': 'apt-get a échoué (code %s).'
                % resultat.get('code'), 'notes': notes,
                'commande': resultat.get('commande')}
    apres = _apres(groupe, tache)
    return {'ok': apres['ok'], 'detection': apres['detection'],
            'encore': apres['encore'], 'commande': resultat.get('commande'),
            'erreur': '' if apres['ok'] else 'Le binaire reste introuvable '
                                             'après l’installation.'}


def _installer_npm(groupe, tache):
    """npm, sans root, dans le dossier d'outils.

    La commande déclarée par le registre est `sudo npm i -g`, qui écrit dans
    /usr/lib/node_modules. Ici c'est `npm install --prefix <dossier>/node`, qui
    n'a besoin d'aucun droit : les exécutables sont dans
    `<dossier>/node/node_modules/.bin`, lié dans `<dossier>/bin`, qui est dans
    PATH. L'écart avec la commande déclarée est ANNONCÉ dans l'inventaire.
    """
    npm = _localiser('npm')
    if not npm:
        return {'ok': False,
                'erreur': 'npm est absent (paquet Debian : npm). Sans lui, '
                          'aucun serveur de langage JavaScript ne peut être '
                          'installé d’ici.'}
    chemins = preparer_dossier()
    commande = [npm, 'install', '--prefix', str(chemins['node']),
                '--no-audit', '--no-fund', '--loglevel=warn'] + groupe['paquets']
    if not groupe['paquets']:
        return {'ok': False, 'erreur': 'Aucun paquet npm à installer.'}
    resultat = _flux(commande, tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'npm a échoué (code %s).'
                % resultat.get('code'),
                'notes': ['Dernières lignes : %s'
                          % ' | '.join(resultat.get('sortie', '').splitlines()[-6:])]}
    executables = chemins['node'] / 'node_modules' / '.bin'
    lies = _lier_attendus(executables, groupe, tache)
    if not lies['lies'] and not lies['vus']:
        return {'ok': False,
                'erreur': 'npm a rendu 0 mais %s ne contient aucun exécutable : '
                          'rien n’est lié, donc rien n’est installé.'
                          % executables}
    lies = lies['lies']
    apres = _apres(groupe, tache)
    return {'ok': apres['ok'], 'lies': lies, 'detection': apres['detection'],
            'encore': apres['encore'],
            'erreur': '' if apres['ok'] else 'Installé mais toujours '
                                             'introuvable dans PATH.'}


def _installer_pip(groupe, tache):
    """pip, sans root : --target pour une bibliothèque, un venv pour un outil.

    Debian 13 protège son Python (PEP 668) : `pip install` dans le système est
    refusé, et `--break-system-packages` casserait apt. Deux voies propres :
      * une BIBLIOTHÈQUE (capstone, pefile…) doit être vue par l'interpréteur du
        serveur, donc `pip install --target <dossier>/python`, ajouté EN FIN de
        sys.path par `etendre_syspath()` ;
      * un OUTIL en ligne de commande (cmake-language-server, debugpy) veut son
        environnement isolé : un venv par outil, dont les scripts sont liés dans
        `<dossier>/bin`.
    """
    python = sys.executable or _localiser('python3')
    if not python or not Path(python).exists():
        python = _localiser('python3')
    if not python:
        return {'ok': False, 'erreur': 'python3 est introuvable.'}
    paquets = groupe['paquets']
    if not paquets:
        return {'ok': False, 'erreur': 'Aucun paquet Python à installer.'}
    verif_pip = _flux([python, '-m', 'pip', '--version'], tache,
                      environnement=_environnement_outil())
    if not verif_pip['ok']:
        return {'ok': False,
                'erreur': 'pip n’est pas utilisable par %s.' % python,
                'notes': ['Paquet Debian : python3-pip. Commande : '
                          'sudo apt-get install -y python3-pip']}
    chemins = preparer_dossier()
    if groupe['famille'] == 'bibliothèques Python':
        cible = _sous('python')
        commande = [python, '-m', 'pip', 'install', '--target', str(cible),
                    '--upgrade', '--no-input',
                    '--disable-pip-version-check'] + paquets
        resultat = _flux(commande, tache)
        if not resultat['ok']:
            return {'ok': False, 'erreur': 'pip a échoué (code %s).'
                    % resultat.get('code'),
                    'notes': ['Dernières lignes : %s' % ' | '.join(
                        resultat.get('sortie', '').splitlines()[-6:])]}
        etendre_syspath()
        importlib.invalidate_caches()
        absents = []
        for paquet in paquets:
            module = paquet
            for nom, module_python, _role in _bibliotheques():
                if nom == paquet:
                    module = module_python
            if importlib.util.find_spec(module) is None:
                absents.append('%s (module %s)' % (paquet, module))
        if absents:
            return {'ok': False,
                    'erreur': 'Installé dans %s mais toujours invisible de '
                              'l’interpréteur : %s.' % (cible, ', '.join(absents)),
                    'notes': ['Redémarrez Pascal Studio : sys.path est lu au '
                              'démarrage des modules déjà importés.']}
        _dire(tache, 'ok', '%s installé dans %s et visible de l’interpréteur.'
              % (', '.join(paquets), cible))
        return {'ok': True, 'cible': str(cible)}
    venv = chemins['venvs'] / re.sub(r'[^A-Za-z0-9._-]', '-', groupe['nom'])
    python_venv = venv / 'bin' / 'python3'
    if not python_venv.exists():
        creation = _flux([python, '-m', 'venv', str(venv)], tache)
        if not creation['ok'] or not python_venv.exists():
            return {'ok': False,
                    'erreur': 'La création de l’environnement %s a échoué.'
                    % venv,
                    'notes': ['Paquet Debian : python3-venv. Commande : '
                              'sudo apt-get install -y python3-venv',
                              'Dernières lignes : %s' % ' | '.join(
                                  creation.get('sortie', '').splitlines()[-6:])]}
    commande = [str(python_venv), '-m', 'pip', 'install', '--upgrade',
                '--no-input', '--disable-pip-version-check'] + paquets
    resultat = _flux(commande, tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'pip a échoué dans le venv (code %s).'
                % resultat.get('code'),
                'notes': ['Dernières lignes : %s' % ' | '.join(
                    resultat.get('sortie', '').splitlines()[-6:])]}
    lies = _lier_attendus(venv / 'bin', groupe, tache,
                          ignorer=INTERPRETEURS)['lies']
    apres = _apres(groupe, tache)
    return {'ok': apres['ok'], 'lies': lies, 'venv': str(venv),
            'detection': apres['detection'], 'encore': apres['encore'],
            'erreur': '' if apres['ok'] else
            'Installé dans le venv mais aucun exécutable lié ne correspond à '
            '%s.' % ', '.join(groupe['binaires'])}


# Ce qui ne doit JAMAIS être lié depuis un environnement virtuel. Le dossier
# d'outils est EN TÊTE de PATH : un `python3.13` de venv masquerait celui du
# système, et le serveur démarrerait sur un interpréteur qui n'a aucune des
# dépendances de l'application. L'exclusion porte sur le DÉBUT du nom, parce que
# les noms sont versionnés (python3.13, pip3.13) et qu'une liste de noms exacts
# les laissait passer.
INTERPRETEURS = ('python', 'pip', 'activate', 'wheel', 'setuptools',
                 'easy_install', 'idle', 'pydoc', '2to3')


def _lier_attendus(dossier, groupe, tache=None, ignorer=()):
    """Lie d'abord les exécutables ATTENDUS, et seulement eux.

    Un paquet npm pose dans `.bin` les exécutables de ses dépendances aussi :
    installer bash-language-server y met `semver` et `editorconfig`. Tout lier
    peut masquer un outil du système, puisque le dossier d'outils est en tête de
    PATH. Le repli — tout lier — n'existe que si aucun nom attendu n'est trouvé,
    il est borné, et il est ANNONCÉ : un outil lié à la place d'un autre doit se
    voir.
    """
    resultat = {'lies': [], 'vus': [], 'repli': False}
    try:
        entrees = sorted(Path(dossier).iterdir())
    except OSError as exc:
        _dire(tache, 'erreur', 'Le dossier %s n’a pas pu être lu : %s'
              % (dossier, exc.strerror or exc))
        return resultat
    resultat['vus'] = [e.name for e in entrees if not e.name.startswith('.')]
    attendus = set(groupe.get('binaires') or ())
    autres = []
    for entree in entrees:
        nom = entree.name
        if nom.startswith('.') or nom.endswith('.ps1'):
            continue
        if any(nom.startswith(prefixe) for prefixe in ignorer):
            continue
        if not (entree.is_file() or entree.is_symlink()):
            continue
        if not os.access(str(entree), os.X_OK):
            continue
        if nom in attendus:
            lien = _lier(entree, tache)
            if lien['ok']:
                resultat['lies'].append(lien['lien'])
        elif len(autres) < 20:
            autres.append(entree)
    if not resultat['lies'] and autres:
        resultat['repli'] = True
        _dire(tache, 'averti',
              'Aucun exécutable ne porte le nom attendu (%s). Ceux du dossier '
              'sont liés à la place : %s. Vérifiez que c’est bien le bon.'
              % (', '.join(sorted(attendus)) or 'aucun nom déclaré',
                 ', '.join(e.name for e in autres[:5])))
        for entree in autres:
            lien = _lier(entree, tache)
            if lien['ok']:
                resultat['lies'].append(lien['lien'])
    return resultat


def _bibliotheques():
    detection = _retro_detection()
    return list(getattr(detection, 'BIBLIOTHEQUES', ())) if detection else []


def _installer_gem(groupe, tache):
    gem = _localiser('gem')
    if not gem:
        return {'ok': False, 'erreur': 'gem est absent (paquet Debian : ruby).'}
    resultat = _flux([gem, 'install', '--user-install', '--no-document']
                     + groupe['paquets'], tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'gem a échoué (code %s).'
                % resultat.get('code')}
    return _lier_depuis_glob(tache, '~/.local/share/gem/ruby/*/bin', groupe)


def _installer_opam(groupe, tache):
    opam = _localiser('opam')
    if not opam:
        return {'ok': False,
                'erreur': 'opam est absent (paquet Debian : opam).'}
    resultat = _flux([opam, 'install', '-y'] + groupe['paquets'], tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'opam a échoué (code %s).'
                % resultat.get('code')}
    return _lier_depuis_glob(tache, '~/.opam/*/bin', groupe)


def _installer_cpan(groupe, tache):
    cpanm = _localiser('cpanm')
    if not cpanm:
        return {'ok': False,
                'erreur': 'cpanm est absent (paquet Debian : cpanminus).'}
    cible = _sous('perl')
    resultat = _flux([cpanm, '--local-lib', str(cible)] + groupe['paquets'],
                     tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'cpanm a échoué (code %s).'
                % resultat.get('code')}
    return _lier_depuis_glob(tache, str(cible / 'bin'), groupe)


def _installer_dotnet(groupe, tache):
    dotnet = _localiser('dotnet')
    if not dotnet:
        return {'ok': False,
                'erreur': 'Le SDK .NET est absent et n’est pas dans Debian : '
                          'il vient de son éditeur. Sans lui, cette '
                          'installation ne peut pas être lancée d’ici.'}
    resultat = _flux([dotnet, 'tool', 'install', '--global']
                     + groupe['paquets'], tache)
    if not resultat['ok']:
        return {'ok': False, 'erreur': 'dotnet a échoué (code %s).'
                % resultat.get('code')}
    return _lier_depuis_glob(tache, '~/.dotnet/tools', groupe)


def _lier_depuis_glob(tache, motif, groupe):
    """Lie les exécutables d'un dossier d'installation, puis re-détecte."""
    import glob as _glob
    lies = []
    for dossier in _glob.glob(os.path.expanduser(motif)):
        chemin = Path(dossier)
        if not chemin.is_dir():
            continue
        for entree in sorted(chemin.iterdir()):
            if entree.is_file() and os.access(str(entree), os.X_OK):
                lien = _lier(entree, tache)
                if lien['ok']:
                    lies.append(lien['lien'])
    apres = _apres(groupe, tache)
    return {'ok': apres['ok'], 'lies': lies, 'detection': apres['detection'],
            'encore': apres['encore'],
            'erreur': '' if apres['ok'] else
            'Le gestionnaire a rendu 0 mais %s reste introuvable dans %s.'
            % (', '.join(groupe['binaires']), motif)}


def _installer_archive(groupe, tache, resolu):
    """Télécharge, vérifie, extrait et lie. Commun à GitHub et à Adoptium."""
    if not resolu.get('ok'):
        _dire(tache, 'echec', resolu.get('raison', 'Résolution impossible.'))
        return {'ok': False, 'erreur': resolu.get('raison', ''),
                'page': resolu.get('page', ''), 'notes': resolu.get('notes', [])}
    taille = int(resolu.get('taille') or 0)
    _dire(tache, 'info', '%s %s : %s%s'
          % (resolu.get('clef', groupe['nom']),
             resolu.get('publication', ''), _octets(taille) if taille
             else 'taille inconnue',
             '' if not resolu.get('somme') else ', somme SHA-256 publiée'))
    place, raison = _place_necessaire(taille)
    if not place:
        _dire(tache, 'echec', raison)
        return {'ok': False, 'erreur': raison}
    chemins = preparer_dossier()
    archive = Path(chemins['telechargements']) / resolu['nom_archive']
    tele = telecharger_fichier(resolu['url'], archive, tache,
                               resolu.get('somme', ''), taille)
    if not tele['ok']:
        return {'ok': False, 'erreur': tele.get('erreur', ''),
                'arrete': tele.get('arrete', False), 'notes': [
                    'Reprise possible : le fichier partiel est conservé.']}
    if not resolu.get('archive'):
        # Un binaire unique (marksman) : pas d'extraction.
        destination = chemins['extraits'] / resolu['clef']
        try:
            destination.mkdir(parents=True, exist_ok=True)
            os.replace(str(archive), str(destination / archive.name))
        except OSError as exc:
            return {'ok': False, 'erreur': 'Le binaire n’a pas pu être mis en '
                                           'place : %s' % (exc.strerror or exc)}
        lien = _lier(destination / archive.name, tache)
        if not lien['ok']:
            return {'ok': False, 'erreur': lien['erreur']}
    else:
        destination = chemins['extraits'] / resolu['clef']
        extraction = _extraire(archive, destination, tache,
                               resolu.get('racine_archive'))
        if not extraction['ok']:
            return {'ok': False, 'erreur': extraction['erreur'],
                    'notes': ['L’archive est conservée dans %s : rien n’est '
                              'retéléchargé pour un second essai.'
                              % chemins['telechargements']]}
        racine = extraction.get('racine') or extraction['cible']
        voulus, binaires, borne = _chercher_executables(
            racine, groupe['binaires'])
        if borne:
            _dire(tache, 'averti', 'La recherche d’exécutables a atteint sa '
                                   'borne : certains fichiers n’ont pas été '
                                   'visités.')
        lies = []
        for nom, chemin in voulus.items():
            if chemin:
                lien = _lier(chemin, tache)
                if lien['ok']:
                    lies.append(lien['lien'])
        if not lies:
            for chemin in binaires[:20]:
                lien = _lier(chemin, tache)
                if lien['ok']:
                    lies.append(lien['lien'])
            if lies:
                _dire(tache, 'averti',
                      'Aucun exécutable ne porte le nom attendu (%s) : ceux du '
                      'dossier `bin` de l’archive ont été liés à la place (%s). '
                      'Vérifiez que c’est bien le bon.'
                      % (', '.join(groupe['binaires']),
                         ', '.join(Path(l).name for l in lies[:5])))
        if not lies:
            return {'ok': False,
                    'erreur': 'L’archive est extraite dans %s mais aucun '
                              'exécutable n’y a été trouvé : rien n’est lié, '
                              'donc rien n’est installé.' % racine}
    apres = _apres(groupe, tache)
    if groupe['nom'].startswith('jdk-temurin') and apres['ok']:
        _dire(tache, 'info', 'Ghidra cherche un JDK : relancez la détection '
                             'depuis le panneau de rétro-ingénierie.')
    return {'ok': apres['ok'], 'detection': apres['detection'],
            'encore': apres['encore'], 'archive': str(archive),
            'extrait_dans': str(chemins['extraits'] / resolu['clef']),
            'erreur': '' if apres['ok'] else
            'Téléchargé et extrait, mais le binaire attendu reste '
            'introuvable dans PATH.'}


def _installer_amont(groupe, tache, resolu=None):
    if groupe['voie'] == 'adoptium':
        majeure = (groupe['paquets'] or ['21'])[0]
        return _installer_archive(groupe, tache,
                                  resolu or resoudre_adoptium(majeure))
    return _installer_archive(groupe, tache, resolu or resoudre_amont(groupe))


INSTALLEURS = {
    'apt': _installer_apt,
    'npm': _installer_npm,
    'pip': _installer_pip,
    'gem': _installer_gem,
    'opam': _installer_opam,
    'cpan': _installer_cpan,
    'dotnet': _installer_dotnet,
    'amont': _installer_amont,
    'adoptium': _installer_amont,
}

# L'ordre d'exécution. Les gestionnaires d'abord : sans npm la voie npm échoue,
# et sans unzip Ghidra ne s'extrait pas. Installer un serveur de langage avant
# son gestionnaire produirait un échec que l'utilisateur lirait comme un refus.
ORDRE = ('gestionnaires', 'apt', 'npm', 'pip', 'gem', 'opam', 'cpan',
         'dotnet', 'adoptium', 'amont')


# --------------------------------------------------------------------------- #
# Le plan.
# --------------------------------------------------------------------------- #

def plan(identifiants=None, tout=False, racine_autorisee=False, resoudre=False):
    """Ce qui serait exécuté, dans quel ordre, et à quel prix.

    Le plan est rendu AVANT l'exécution, et c'est la fenêtre de confirmation :
    chaque étape porte sa commande exacte. Un plan qui ne montrerait que des
    noms d'outils cacherait ce qui est réellement lancé — et ce qui est lancé
    ici peut demander les droits root.

    `resoudre=True` interroge le réseau pour connaître les tailles. Sans ça,
    Ghidra est annoncé « taille inconnue » : le module ne recopie pas un poids
    qui changerait à la prochaine publication.
    """
    inventaire = etat(rafraichir=True)
    groupes = inventaire['groupes']
    choisis, notes = [], []
    if tout:
        for identifiant, groupe in groupes.items():
            if groupe['present']:
                continue
            if not groupe['telechargeable']:
                notes.append('%s : aucune voie automatisable. %s'
                             % (groupe['nom'],
                                ' '.join(groupe['notes'][:2]) or
                                'Aucune raison n’est déclarée.'))
                continue
            choisis.append(identifiant)
    else:
        for identifiant in (identifiants or []):
            groupe = groupes.get(str(identifiant))
            if groupe is None:
                notes.append('%s : identifiant inconnu de l’inventaire.'
                             % identifiant)
                continue
            if groupe['present']:
                notes.append('%s : déjà présent, rien à installer.'
                             % groupe['nom'])
                continue
            if not groupe['telechargeable']:
                notes.append('%s : ne peut pas être installé d’ici. %s'
                             % (groupe['nom'],
                                ' '.join(groupe['notes'][:2]) or
                                'Aucune raison n’est déclarée.'))
                continue
            choisis.append(groupe['id'])
    if not choisis:
        return {'ok': True, 'etapes': [], 'notes': notes, 'racine': False,
                'taille_totale': 0, 'outils': 0,
                'resume': 'Rien à installer.' if not notes
                else 'Rien à installer : %d remarque(s).' % len(notes)}

    par_voie = {}
    for identifiant in choisis:
        groupe = groupes[identifiant]
        par_voie.setdefault(groupe['voie'], []).append(groupe)
    etapes = []
    # Les gestionnaires manquants passent en premier, quelle que soit leur voie.
    gestion = [g for g in par_voie.get('apt', []) + par_voie.get('npm', [])
               if g['famille'] == 'gestionnaires' and not g['present']]
    for voie in ORDRE:
        groupes_voie = par_voie.get(voie)
        if not groupes_voie:
            continue
        if voie == 'apt':
            paquets = []
            outils = []
            for groupe in groupes_voie:
                outils.append(groupe['id'])
                for paquet in groupe['paquets']:
                    if paquet not in paquets:
                        paquets.append(paquet)
            if not paquets:
                continue
            pkexec = _localiser('pkexec')
            commande = ([pkexec or 'pkexec', 'env',
                         'DEBIAN_FRONTEND=noninteractive', 'apt-get',
                         'install', '-y', '--no-install-recommends'] + paquets)
            etape = {
                'voie': 'apt', 'outils': outils, 'paquets': paquets,
                'commande': commande, 'racine': True,
                'commande_texte': ' '.join(commande),
                'commande_manuelle': 'sudo apt-get install -y %s'
                                     % ' '.join(paquets),
                'taille_attendue': 0, 'notes': [
                    'Une seule demande de mot de passe pour %d paquet(s).'
                    % len(paquets)],
                'executable': bool(pkexec) and bool(racine_autorisee),
            }
            if not pkexec:
                etape['notes'].append(
                    '`pkexec` est absent : cette étape ne peut pas être lancée '
                    'depuis l’application. Tapez la commande manuelle.')
            elif not racine_autorisee:
                etape['notes'].append(
                    'Les droits root ne sont pas autorisés par cet appel : '
                    'l’étape sera sautée, et la commande affichée.')
            etapes.append(etape)
            continue
        if voie == 'npm':
            paquets, outils = [], []
            for groupe in groupes_voie:
                outils.append(groupe['id'])
                for paquet in groupe['paquets']:
                    if paquet not in paquets:
                        paquets.append(paquet)
            chemins = preparer_dossier()
            commande = [_localiser('npm') or 'npm', 'install', '--prefix',
                        str(chemins['node']), '--no-audit', '--no-fund',
                        '--loglevel=warn'] + paquets
            etapes.append({
                'voie': 'npm', 'outils': outils, 'paquets': paquets,
                'commande': commande, 'racine': False,
                'commande_texte': ' '.join(commande),
                'commande_manuelle': 'sudo npm install -g %s'
                                     % ' '.join(paquets),
                'taille_attendue': 0,
                'notes': ['Installé dans %s, sans droits root.'
                          % chemins['node']],
                'executable': bool(_localiser('npm'))})
            continue
        if voie == 'pip':
            # Les BIBLIOTHÈQUES partagent une destination (`--target`) : une
            # seule étape pour toutes. Les OUTILS en ligne de commande ont
            # chacun leur environnement : une étape par outil.
            python = sys.executable or _localiser('python3') or 'python3'
            bibliotheques = [g for g in groupes_voie
                             if g['famille'] == 'bibliothèques Python']
            if bibliotheques:
                paquets = []
                for groupe in bibliotheques:
                    for paquet in groupe['paquets']:
                        if paquet not in paquets:
                            paquets.append(paquet)
                cible = _sous('python')
                commande = [python, '-m', 'pip', 'install', '--target',
                            str(cible), '--upgrade', '--no-input',
                            '--disable-pip-version-check'] + paquets
                etapes.append({
                    'voie': 'pip',
                    'outils': [g['id'] for g in bibliotheques],
                    'paquets': paquets, 'commande': commande, 'racine': False,
                    'commande_texte': ' '.join(str(c) for c in commande),
                    'commande_manuelle': 'python3 -m pip install --target %s %s'
                                         % (cible, ' '.join(paquets)),
                    'taille_attendue': 0, 'resolution': None,
                    'notes': [
                        'Bibliothèques : installées dans %s, ajouté EN FIN de '
                        'sys.path pour ne jamais masquer un paquet du système.'
                        % cible,
                        'Aucun droit root : Debian 13 protège son Python '
                        '(PEP 668). Redémarrez Pascal Studio ensuite.'],
                    'executable': bool(_localiser('python3'))})
            for groupe in groupes_voie:
                if groupe['famille'] == 'bibliothèques Python':
                    continue
                venv = _sous('venvs') / re.sub(r'[^A-Za-z0-9._-]', '-',
                                               groupe['nom'])
                commande = [python, '-m', 'venv', str(venv)]
                suite = '%s/bin/pip install --upgrade --no-input %s' % (
                    venv, ' '.join(groupe['paquets']))
                etapes.append({
                    'voie': 'pip', 'outils': [groupe['id']],
                    'paquets': groupe['paquets'], 'commande': commande,
                    'racine': False,
                    'commande_texte': '%s -m venv %s, puis %s'
                                      % (python, venv, suite),
                    'commande_manuelle': 'pipx install %s'
                                         % ' '.join(groupe['paquets']),
                    'taille_attendue': 0, 'resolution': None,
                    'notes': list(groupe['notes'])[:2] + [
                        'Outil en ligne de commande : environnement dédié, '
                        'puis ses scripts sont liés dans %s.' % _sous('bin')],
                    'executable': bool(_localiser('python3'))})
            continue
        # Les voies restantes : une étape par groupe, parce qu'une archive ne
        # se partage pas.
        for groupe in groupes_voie:
            taille = 0
            notes_etape = list(groupe['notes'])[:2]
            resolution = None
            if resoudre and groupe['voie'] in ('amont', 'adoptium'):
                resolution = (resoudre_adoptium(groupe['paquets'][0])
                              if groupe['voie'] == 'adoptium'
                              else resoudre_amont(groupe))
                if resolution.get('ok'):
                    taille = int(resolution.get('taille') or 0)
                    notes_etape.append('Publication %s, archive %s, %s.'
                                       % (resolution.get('publication', '?'),
                                          resolution.get('nom_archive', '?'),
                                          _octets(taille)))
                    if resolution.get('somme'):
                        notes_etape.append(
                            'Somme SHA-256 publiée par l’origine : elle sera '
                            'vérifiée après le téléchargement.')
                    elif resolution.get('notes'):
                        notes_etape.extend(resolution['notes'])
                else:
                    notes_etape.append('Adresse non résolue : %s'
                                       % resolution.get('raison', '?'))
            if groupe['voie'] in ('amont', 'adoptium'):
                # Ce n'est pas une commande shell, et l'afficher comme telle
                # inviterait à la copier-coller. C'est la description de ce qui
                # va être fait : quoi télécharger, où l'extraire, quoi lier.
                clef = (resolution or {}).get('clef') or groupe['nom']
                commande = ['télécharger',
                            (resolution or {}).get('url')
                            or 'l’archive, dont l’adresse est résolue à '
                               'l’exécution',
                            'puis l’extraire dans', str(_sous('extraits') / clef),
                            'et lier ses exécutables dans', str(_sous('bin'))]
                gestionnaire = 'python3'
            else:
                commande = [groupe['gestionnaire'] or groupe['voie']] \
                    + groupe['paquets']
                gestionnaire = groupe['gestionnaire']
            etapes.append({
                'voie': groupe['voie'], 'outils': [groupe['id']],
                'paquets': groupe['paquets'], 'commande': commande,
                'racine': False,
                'commande_texte': ' '.join(str(c) for c in commande),
                'commande_manuelle': _commande_proposee(groupe),
                'taille_attendue': taille, 'notes': notes_etape,
                'resolution': resolution,
                'executable': bool(gestionnaire and
                                   (_localiser(gestionnaire)
                                    or gestionnaire == 'python3'))})
    taille_totale = sum(e.get('taille_attendue', 0) for e in etapes)
    racine = any(e['racine'] for e in etapes)
    resume = ('%d étape(s) pour %d outil(s)%s%s.'
              % (len(etapes), len(choisis),
                 ', dont %s de téléchargement' % _octets(taille_totale)
                 if taille_totale else
                 '' if resoudre else ', tailles non résolues (hors ligne)',
                 ' et une demande de droits root' if racine else ''))
    return {'ok': True, 'etapes': etapes, 'notes': notes, 'racine': racine,
            'racine_autorisee': bool(racine_autorisee),
            'taille_totale': taille_totale, 'outils': len(choisis),
            'identifiants': choisis, 'resume': resume,
            'gestionnaires_manquants': [g['nom'] for g in gestion],
            'resolu': bool(resoudre)}


# --------------------------------------------------------------------------- #
# L'exécution.
# --------------------------------------------------------------------------- #

def _executer(planification, tache):
    etapes = planification['etapes']
    with tache['verrou']:
        tache['etat'] = 'en cours'
        tache['etapes'] = len(etapes)
    _dire(tache, 'info', 'Plan : %s' % planification['resume'])
    for remarque in planification.get('notes', []):
        _dire(tache, 'info', remarque)
    reussites, echecs, sautes = [], [], []
    for index, etape in enumerate(etapes, 1):
        if tache['arret'].is_set():
            _dire(tache, 'arret', 'Arrêt avant l’étape %d/%d.'
                  % (index, len(etapes)))
            break
        with tache['verrou']:
            tache['etape'] = index
            tache['progression'] = {'octets': 0, 'total': 0,
                                    'pourcentage': None, 'vitesse': 0.0,
                                    'reste': None}
        _dire(tache, 'etape', 'Étape %d/%d — voie %s, %d outil(s) : %s'
              % (index, len(etapes), etape['voie'], len(etape['outils']),
                 ', '.join(etape['outils'])))
        if etape['racine'] and not tache['racine_autorisee']:
            _dire(tache, 'refus', 'Étape en root sautée : les droits root ne '
                                  'sont pas autorisés par cet appel. '
                                  'Commande : %s' % etape['commande_manuelle'])
            sautes.extend(etape['outils'])
            continue
        interdit = _code_interdit(etape['commande'])
        if interdit:
            _dire(tache, 'echec', 'L’étape %d contient « %s », qui est '
                                  'interdit : étape sautée.' % (index, interdit))
            echecs.extend(etape['outils'])
            continue
        installeur = INSTALLEURS.get(etape['voie'])
        if installeur is None:
            _dire(tache, 'echec', 'Aucun installeur pour la voie %r.'
                  % etape['voie'])
            echecs.extend(etape['outils'])
            continue
        # Un plan peut regrouper plusieurs outils dans une étape (apt, npm) :
        # l'installeur reçoit un groupe synthétique dont les binaires sont ceux
        # de tous les outils de l'étape, pour que la re-détection les couvre.
        groupes = [planification['groupes'][i]
                   for i in etape['outils'] if i in planification['groupes']]
        groupe = {
            'id': '+'.join(etape['outils']), 'nom': etape['voie'],
            'famille': groupes[0]['famille'] if groupes else '',
            'binaires': [b for g in groupes for b in g['binaires']],
            'paquets': etape['paquets'], 'voie': etape['voie'],
            'notes': etape.get('notes', []), 'depot': '',
        }
        if len(groupes) == 1:
            groupe = dict(groupes[0])
            groupe['paquets'] = etape['paquets']
        try:
            resultat = installeur(groupe, tache, etape.get('resolution')) \
                if etape['voie'] in ('amont', 'adoptium') \
                else installeur(groupe, tache)
        except Exception as exc:                    # aucune fuite vers l'UI
            resultat = {'ok': False,
                        'erreur': '%s : %s' % (type(exc).__name__, exc)}
            _dire(tache, 'echec', 'L’étape %d a levé %s : %s'
                  % (index, type(exc).__name__, exc))
        if resultat.get('ok'):
            reussites.extend(etape['outils'])
        elif resultat.get('refus') or resultat.get('arrete'):
            sautes.extend(etape['outils'])
        else:
            echecs.extend(etape['outils'])
        with tache['verrou']:
            tache['resultats'].append(
                {'etape': index, 'voie': etape['voie'],
                 'outils': list(etape['outils']),
                 'ok': bool(resultat.get('ok')),
                 'erreur': resultat.get('erreur', ''),
                 'notes': resultat.get('notes', []),
                 'commande': resultat.get('commande', '')})
    inventaire = etat(rafraichir=True)
    encore = sorted({i for i in reussites + echecs + sautes
                     if i in inventaire['groupes']
                     and not inventaire['groupes'][i]['present']})
    with tache['verrou']:
        tache['etat'] = ('arrêté' if tache['arret'].is_set()
                         else 'terminé' if not echecs and not encore
                         else 'échec partiel' if reussites
                         else 'échec')
        tache['fin'] = time.time()
    _dire(tache, 'resume',
          '%d installation(s) réussie(s), %d échec(s), %d sautée(s). '
          'Encore absent(s) : %s.'
          % (len(reussites), len(echecs), len(sautes),
             ', '.join(encore) if encore else 'rien'))
    return {'ok': not echecs and not encore and not tache['arret'].is_set(),
            'reussites': reussites, 'echecs': echecs, 'sautes': sautes,
            'encore': encore, 'etat': tache['etat'],
            'duree': round(tache['fin'] - tache['debut'], 1)}


def telecharger(identifiants=None, tout=False, racine_autorisee=False,
                resoudre=True, agent=None):
    """Installe, de façon SYNCHRONE. Rend le résultat complet.

    C'est la forme utilisée par les bancs et par la ligne de commande. Le
    panneau passe par `demarrer()`, qui rend la main immédiatement.
    """
    planification = plan(identifiants, tout, racine_autorisee, resoudre)
    if not planification['etapes']:
        return {'ok': True, 'sid': '', 'resultat': None,
                'plan': planification,
                'resume': planification['resume']}
    inventaire = etat(rafraichir=True)
    planification['groupes'] = inventaire['groupes']
    tache = _nouvelle_tache(planification['identifiants'], racine_autorisee,
                            agent)
    resultat = _executer(planification, tache)
    suivi = suivre(tache['sid'])
    return {'ok': resultat['ok'], 'sid': tache['sid'], 'resultat': resultat,
            'plan': {k: v for k, v in planification.items() if k != 'groupes'},
            'journal': suivi['lignes'][-LIMITE_PROBLEMES:],
            'resume': suivi['etat'] + ' — ' + resultat['etat']}


def demarrer(identifiants=None, tout=False, racine_autorisee=False,
             resoudre=True, agent=None):
    """Lance l'installation en arrière-plan et rend l'identifiant de tâche.

    Un téléchargement de 570 Mo dure plusieurs minutes : le serveur HTTP ne
    peut pas attendre, et le panneau ne doit pas être figé. Le suivi passe par
    `suivre(sid)`, l'arrêt par `arreter(sid)`.
    """
    planification = plan(identifiants, tout, racine_autorisee, resoudre)
    if not planification['etapes']:
        return {'ok': False, 'sid': '', 'plan': planification,
                'erreur': planification['resume']}
    inventaire = etat(rafraichir=True)
    planification['groupes'] = inventaire['groupes']
    tache = _nouvelle_tache(planification['identifiants'], racine_autorisee,
                            agent)
    fil = threading.Thread(target=_executer, args=(planification, tache),
                           name='outils-%s' % tache['sid'], daemon=True)
    with tache['verrou']:
        tache['fil'] = fil
    fil.start()
    return {'ok': True, 'sid': tache['sid'],
            'plan': {k: v for k, v in planification.items() if k != 'groupes'},
            'resume': 'Installation démarrée : %s' % planification['resume']}



# Une remarque destinée à l'utilisateur ne doit jamais montrer un trou : une
# parenthèse vide, une virgule suivie de rien, un point précédé d'un deux-points.
# L'autocontrôle les cherche dans TOUTES les remarques de TOUS les groupes.
TROUS_INTERDITS = (' : )', ': )', '()', '( ', ' ,', ' .)', ': .', '— .')

def verifier_outils(identifiants=None):
    """« Tout vérifier » : l'inventaire avec les versions, réellement lues.

    Séparé de `etat()` parce que lire une version LANCE chaque outil avec un
    délai : soixante outils peuvent prendre une minute. Ouvrir la fenêtre des
    paramètres ne doit pas coûter cela ; cliquer sur « Vérifier » le peut.
    """
    resultat = etat(avec_versions=True, rafraichir=True)
    if identifiants:
        voulu = set(identifiants)
        resultat['liste'] = [o for o in resultat['liste'] if o['id'] in voulu]
        resultat['total'] = len(resultat['liste'])
    return resultat


def _sans_lever(fonction, *arguments, **options):
    """Joue un contrôle sans qu'une exception masque un ÉCHEC nommé.

    Défaut connu du projet : une exception levée au milieu d'un autocontrôle
    arrête la boucle, et les messages d'échec qui suivaient ne sont jamais
    écrits. Le banc « passe » alors pour de mauvaises raisons.
    """
    try:
        return fonction(*arguments, **options), ''
    except Exception as exc:
        return None, '%s : %s' % (type(exc).__name__, exc)


# Un inventaire SYNTHÉTIQUE, pour que les contrôles du plan ne dépendent pas de
# la machine. Sur une machine où tout est installé, un banc qui ne planifie rien
# ne contrôle rien : il « passe » sans rien avoir joué. Les groupes ci-dessous
# couvrent les cinq voies et un outil déjà présent.
def _inventaire_faux():
    def groupe(identifiant, nom, famille, voie, binaires, paquets, present,
               racine, depot='', gestionnaire='', telechargeable=True,
               commande='', notes=()):
        return {'id': identifiant, 'nom': nom, 'famille': famille, 'voie': voie,
                'binaires': list(binaires), 'manquants': [] if present
                else list(binaires), 'present': present, 'paquets': list(paquets),
                'racine': racine, 'depot': depot, 'url': '',
                'gestionnaire': gestionnaire, 'telechargeable': telechargeable,
                'commande': commande, 'notes': list(notes), 'roles': [],
                'role': nom, 'langages': [], 'langage': '', 'refuses': [],
                'detection': [], 'amont': {}, 'amont_clef': nom}
    groupes = {
        'apt:gdb': groupe('apt:gdb', 'gdb', 'débogage', 'apt', ['gdb'],
                          ['gdb'], False, True, gestionnaire='apt-get'),
        'apt:binutils': groupe('apt:binutils', 'binutils', 'rétro-ingénierie',
                               'apt', ['objdump', 'readelf', 'nm'],
                               ['binutils'], False, True,
                               gestionnaire='apt-get'),
        'apt:npm': groupe('apt:npm', 'npm', 'gestionnaires', 'apt', ['npm'],
                          ['npm'], False, True, gestionnaire='apt-get'),
        'npm:bash-language-server': groupe(
            'npm:bash-language-server', 'bash-language-server',
            'serveurs de langage', 'npm', ['bash-language-server'],
            ['bash-language-server'], False, False, gestionnaire='npm'),
        'npm:vscode-langservers-extracted': groupe(
            'npm:vscode-langservers-extracted', 'vscode-langservers-extracted',
            'serveurs de langage', 'npm',
            ['vscode-html-language-server', 'vscode-css-language-server'],
            ['vscode-langservers-extracted'], False, False,
            gestionnaire='npm'),
        'pip:cmake-language-server': groupe(
            'pip:cmake-language-server', 'cmake-language-server',
            'serveurs de langage', 'pip', ['cmake-language-server'],
            ['cmake-language-server'], False, False, gestionnaire='python3'),
        'pip:capstone': groupe('pip:capstone', 'capstone',
                               'bibliothèques Python', 'pip', ['capstone'],
                               ['capstone'], False, False,
                               gestionnaire='python3'),
        'adoptium:jdk-temurin-21': groupe(
            'adoptium:jdk-temurin-21', 'jdk-temurin-21', 'analyse avancée',
            'adoptium', ['jdk-temurin'], ['21'], False, False,
            gestionnaire='python3'),
        'amont:marksman': groupe('amont:marksman', 'marksman',
                                 'serveurs de langage', 'amont', ['marksman'],
                                 [], False, False,
                                 depot='artempyanykh/marksman',
                                 gestionnaire='python3'),
        'apt:gcc': groupe('apt:gcc', 'build-essential', 'compilateurs', 'apt',
                          ['gcc'], ['build-essential'], True, True,
                          gestionnaire='apt-get'),
    }
    liste = [{'id': g['id'], 'nom': g['nom'], 'famille': g['famille'],
              'role': g['role'], 'langage': '', 'present': g['present'],
              'binaires': g['binaires'], 'manquants': g['manquants'],
              'voie': g['voie'], 'racine': g['racine'],
              'paquets': g['paquets'], 'commande': g['commande'],
              'telechargeable': g['telechargeable'],
              'gestionnaire': g['gestionnaire'], 'depot': g['depot'],
              'url': '', 'notes': g['notes'], 'detection': []}
             for g in groupes.values()]
    return {'ok': True, 'groupes': groupes, 'liste': liste,
            'total': len(liste), 'presents': 1, 'manquants': len(liste) - 1,
            'installables': len(liste) - 1, 'manuels': 0, 'notes': [],
            'avec_versions': False, 'resume': '', 'marqueur': MARQUEUR,
            'version': VERSION, 'chemins': chemin_outils(),
            'gestionnaires': etat_gestionnaires(),
            'familles': {f: {'total': 0, 'manquants': 0} for f in FAMILLES}}


def verifier():
    """Autocontrôle. Rend la liste des problèmes ; vide si tout est conforme.

    Il joue SANS réseau : `urllib.request.urlopen` est remplacé par une garde
    qui laisse passer `file://` (les contrôles de téléchargement lisent un
    fichier local) et qui LÈVE sur toute adresse http. Un banc dont le résultat
    dépend de la connexion de la machine n'est pas un banc — il échouerait chez
    l'utilisateur pour une raison qui n'a rien à voir avec le code.

    Il joue aussi SANS installer : `telecharger` est remplacé par une fonction
    qui lève.
    """
    problemes = []
    compte = [0]

    def verif(condition, message):
        compte[0] += 1
        if not condition:
            problemes.append(message)

    import glob
    import io
    import tempfile
    import urllib.request

    touches = []
    urlopen_reel = urllib.request.urlopen

    def _garde(adresse, *arguments, **options):
        texte = str(getattr(adresse, 'full_url', adresse))
        if texte.startswith('file://'):
            return urlopen_reel(adresse, *arguments, **options)
        touches.append(texte)
        raise AssertionError('verifier() ne doit pas toucher au réseau (%s)'
                             % texte)

    def _refuse(*arguments, **options):
        raise AssertionError('verifier() ne doit rien installer')

    urllib.request.urlopen = _garde
    telecharger_reel = globals()['telecharger']
    demarrer_reel = globals()['demarrer']
    etat_reel = globals()['etat']
    globals()['telecharger'] = _refuse
    globals()['demarrer'] = _refuse
    avant_sys = list(sys.path)
    try:
        # -- 1. les voies sont LUES dans les commandes déclarées -----------
        for commande, voie, paquets, racine in (
                ('sudo apt install gdb', 'apt', ['gdb'], True),
                ('sudo apt install php-cli php-xdebug', 'apt',
                 ['php-cli', 'php-xdebug'], True),
                ('sudo apt install kotlin default-jre-headless', 'apt',
                 ['kotlin', 'default-jre-headless'], True),
                ('sudo npm i -g bash-language-server', 'npm',
                 ['bash-language-server'], False),
                ('sudo npm i -g typescript typescript-language-server', 'npm',
                 ['typescript', 'typescript-language-server'], False),
                ('pipx install cmake-language-server', 'pip',
                 ['cmake-language-server'], False),
                ('pip install debugpy', 'pip', ['debugpy'], False),
                ('gem install solargraph', 'gem', ['solargraph'], False),
                ('opam install ocaml-lsp-server', 'opam',
                 ['ocaml-lsp-server'], False),
                ('dotnet tool install --global csharp-ls', 'dotnet',
                 ['csharp-ls'], False),
                ('cpan install Perl::LanguageServer', 'cpan', [], False),
                ('voir https://github.com/fwcd/kotlin-language-server',
                 'amont', [], False),
                ('voir amont', 'amont', [], False),
                ('', 'inconnue', [], False),
                ('installez le SDK de votre éditeur', 'manuel', [], False),
                ('adoptium jdk 21', 'adoptium', ['21'], False)):
            lu, erreur = _sans_lever(route, commande, 'x')
            verif(lu is not None, 'route(%r) a levé %s' % (commande, erreur))
            if lu is None:
                continue
            verif(lu['voie'] == voie,
                  'route(%r) doit rendre la voie %r, reçu %r'
                  % (commande, voie, lu['voie']))
            verif(lu['paquets'] == paquets,
                  'route(%r) doit rendre les paquets %r, reçu %r'
                  % (commande, paquets, lu['paquets']))
            verif(lu['racine'] is racine,
                  'route(%r) : racine doit valoir %r, reçu %r'
                  % (commande, racine, lu['racine']))
        lu = route('sudo npm i -g intelephense', 'intelephense')
        verif(any('sans droits root' in n for n in lu['notes']),
              'le détournement de `sudo npm i -g` vers le dossier d’outils '
              'doit être ANNONCÉ, pas silencieux')
        lu = route('pipx install cmake-language-server', 'cmake')
        verif(any('PEP 668' in n for n in lu['notes']),
              'le passage de pipx à un environnement dédié doit dire pourquoi')
        lu = route('voir https://github.com/genericptr/pasls', 'pasls')
        verif(lu['depot'] == 'genericptr/pasls',
              'le dépôt doit être lu dans l’URL déclarée, reçu %r' % lu['depot'])
        lu = route('voir https://luals.github.io (binaire amont, hors apt)',
                   'lua-language-server')
        verif(lu['voie'] == 'amont' and not lu['depot'] and lu['notes'],
              'une URL qui n’est pas GitHub doit être annoncée comme non '
              'résoluble, pas devinée : %r' % lu)
        lu = route('adoptium jdk 21', 'jdk-temurin')
        verif(lu['cible'] == 'jdk-temurin-21' and '{arch}' in lu['url'],
              'la voie adoptium doit rendre une cible nommée et une URL à '
              'résoudre : %r' % lu)

        # -- 2. rien ne peut devenir une commande --------------------------
        for brut, attendus, rejetes in (
                # Un méta-caractère fait TOUT refuser, y compris le nom de
                # paquet valable qui précède : trier mot à mot laissait
                # passer `rm`.
                ('binutils; rm -rf /', [], True),
                ('binutils && reboot', [], True),
                ('a$(reboot)', [], True),
                ('`reboot`', [], True),
                ('--purge binutils', ['binutils'], True),
                ('binutils.', ['binutils'], False),
                ('python3-pip vim-common', ['python3-pip', 'vim-common'],
                 False)):
            propres, rejetes_lus = _nettoyer_paquets(brut)
            verif(propres == attendus,
                  '_nettoyer_paquets(%r) doit rendre %r, reçu %r'
                  % (brut, attendus, propres))
            verif(bool(rejetes_lus) is rejetes,
                  '_nettoyer_paquets(%r) : des morceaux devaient être '
                  'rejetés=%r, reçu %r' % (brut, rejetes, rejetes_lus))
            verif(all(_MOTIF_PAQUET.match(p) for p in propres),
                  '_nettoyer_paquets(%r) a laissé passer un nom douteux : %r'
                  % (brut, propres))
        for commande in (['apt-get', 'install', '-y', 'binutils'],
                         ['pkexec', 'env', 'apt-get', 'install', '-y', 'gdb'],
                         ['npm', 'install', '--prefix', '/x', 'intelephense']):
            verif(_code_interdit(commande) == '',
                  'une commande d’installation normale ne doit pas être '
                  'refusée : %r' % commande)
        for interdit in ('remove', 'purge', 'autoremove', 'upgrade',
                         'dist-upgrade', 'full-upgrade'):
            verif(_code_interdit(['apt-get', interdit, '-y', 'x']) == interdit,
                  '_code_interdit doit refuser « %s »' % interdit)
        annonces = capacites()['commandes_interdites']
        verif(all(_code_interdit(['apt-get', i, 'x']) == i
                  for i in annonces),
              'chaque verbe annoncé par capacites() doit être réellement '
              'refusé : %r' % (annonces,))

        # -- 3. l'inventaire réel est cohérent -----------------------------
        lu = inventaire()
        verif(lu['ok'], 'l’inventaire doit être complet : %s' % lu['notes'])
        groupes = lu['outils']
        verif(len(groupes) >= 40,
              'l’inventaire est trop pauvre (%d groupes) : la moisson du '
              'registre a échoué' % len(groupes))
        identifiants = [g['id'] for g in groupes]
        verif(len(identifiants) == len(set(identifiants)),
              'deux groupes portent le même identifiant')
        for groupe in groupes:
            verif(groupe['voie'] in ('apt', 'npm', 'pip', 'gem', 'opam',
                                     'cpan', 'dotnet', 'amont', 'adoptium',
                                     'manuel', 'inconnue'),
                  '%s a une voie hors liste : %r' % (groupe['id'], groupe['voie']))
            verif(groupe['racine'] is (groupe['voie'] == 'apt'),
                  '%s : seul apt demande les droits root (racine=%r, voie=%r)'
                  % (groupe['id'], groupe['racine'], groupe['voie']))
            if groupe['telechargeable']:
                verif(bool(groupe['paquets']) or bool(groupe['depot'])
                      or groupe['voie'] == 'adoptium',
                      '%s est dit téléchargeable sans paquet ni dépôt'
                      % groupe['id'])
            if groupe['voie'] == 'apt':
                verif(all(_MOTIF_PAQUET.match(p) for p in groupe['paquets']),
                      '%s : un nom de paquet douteux a passé le filtre : %r'
                      % (groupe['id'], groupe['paquets']))
            verif(bool(groupe['binaires']) or bool(groupe['notes']),
                  '%s n’a ni binaire à vérifier ni remarque' % groupe['id'])
            for note in groupe['notes']:
                verif(not any(trou in note for trou in TROUS_INTERDITS),
                      '%s montre un trou dans une remarque : %r'
                      % (groupe['id'], note[:90]))
            verif(groupe['famille'] in FAMILLES,
                  '%s a une famille hors liste : %r'
                  % (groupe['id'], groupe['famille']))
            verif(bool(groupe['role']),
                  '%s n’explique pas à quoi sert l’outil' % groupe['id'])
        familles = {g['famille'] for g in groupes}
        verif(familles == set(FAMILLES),
              'les familles réellement peuplées doivent être exactement celles '
              'qui sont déclarées : peuplées %r, déclarées %r'
              % (sorted(familles), sorted(FAMILLES)))
        ghidra = [g for g in groupes if 'ghidra' in g['depot'].lower()
                  or 'ghidra' in g['nom'].lower()]
        verif(bool(ghidra), 'Ghidra doit être inventorié')
        if ghidra:
            fiche, clef = _fiche_amont(ghidra[0])
            verif(clef == 'ghidra' and bool(fiche.get('motif')),
                  'la fiche de Ghidra doit être retrouvée par son DÉPÔT : le '
                  'binaire s’appelle ghidraRun et la fiche ghidra (%r)' % clef)
            verif(ghidra[0]['telechargeable'],
                  'Ghidra doit être téléchargeable : c’est l’outil le plus '
                  'attendu du bouton « Tout installer »')
            verif(ghidra[0]['voie'] == 'amont' and not ghidra[0]['racine'],
                  'Ghidra s’obtient sans droits root')
        for nom in ('pasls', 'codelldb'):
            fiche = AMONT.get(nom) or {}
            verif(bool(fiche.get('sans_publication'))
                  and bool(fiche.get('note_depot')),
                  '%s ne publie rien d’exploitable : il doit porter '
                  'sans_publication ET la raison écrite' % nom)
            cible = [g for g in groupes if g['nom'] == nom]
            verif(bool(cible) and not cible[0]['telechargeable'],
                  '%s ne doit pas être annoncé téléchargeable' % nom)
        jdk = [g for g in groupes if g['voie'] == 'adoptium']
        verif(bool(jdk) and jdk[0]['telechargeable'] and not jdk[0]['racine'],
              'le JDK sans root doit être inventorié et téléchargeable')

        # -- 4. la moisson ne perd rien (synchronisation bidirectionnelle) --
        registre = _registre_langages()
        verif(registre is not None, 'langages.py doit être importable')
        if registre is not None:
            declares = set()
            for langage in getattr(registre, 'LANGAGES', {}).values():
                if getattr(langage, 'compilateur', ''):
                    declares.add(langage.compilateur)
                for serveur in getattr(langage, 'lsp', ()) or ():
                    declares.add(serveur.binaire)
                for adaptateur in getattr(langage, 'dap', ()) or ():
                    declares.add(adaptateur.binaire)
            inventories = {b for g in groupes for b in g['binaires']}
            perdus = sorted(declares - inventories)
            verif(not perdus,
                  'des binaires du registre ne sont pas inventoriés : %s. Un '
                  'langage ajouté au registre doit apparaître ici sans qu’on '
                  'touche ce module.' % ', '.join(perdus))
            verif(len(getattr(registre, 'LANGAGES', {})) >= 40,
                  'le registre des langages a rétréci : la moisson ne couvre '
                  'plus ce qu’elle couvrait')
        # Tout paquet que le PRODUIT déclare est couvert ici : sinon
        # l'utilisateur lirait une commande dans un panneau et un bouton
        # « Installer » qui ne fait pas la même chose.
        declares_apt = set()
        ici = Path(__file__).resolve().parent
        for fichier in sorted(glob.glob(str(ici / '*.py'))):
            if 'vendor' in fichier:
                continue
            try:
                texte = io.open(fichier, encoding='utf-8',
                                errors='replace').read()
            except OSError:
                continue
            for correspondance in re.finditer(
                    r'apt(?:-get)?\s+install\s+'
                    r'((?:[a-z0-9][a-z0-9.+-]*\s*)+)', texte):
                # Toute la liste de paquets, pas seulement le premier, et sans
                # le point final d'une phrase.
                for morceau in correspondance.group(1).split():
                    paquet = morceau.strip().strip('.')
                    # Un paquet réel ne se termine pas par un tiret :
                    # « openjdk- » est un fragment de chaîne de format
                    # écrit dans le produit, pas un nom de paquet.
                    if _MOTIF_PAQUET.match(paquet) \
                            and not paquet.endswith(('-', '+')) \
                            and len(paquet) > 1:
                        declares_apt.add(paquet)
        verif(len(declares_apt) >= 10,
              'la moisson des paquets déclarés n’a rien trouvé (%d) : le '
              'contrôle de synchronisation serait vide' % len(declares_apt))
        couverts = (set(PAQUETS_APT.values()) | set(PAQUETS_APT)
                    | set(PAQUETS_PREREQUIS))
        detection = _retro_detection()
        if detection is not None:
            couverts |= set(getattr(detection, 'PAQUETS', {}).values())
            verif(bool(getattr(detection, 'INSTALLATIONS', ())),
                  'retro_detection.INSTALLATIONS est vide : les voies de '
                  'Ghidra ne sont plus moissonnées')
        non_couverts = sorted(p for p in declares_apt if p not in couverts)
        verif(not non_couverts,
              'le produit déclare des paquets Debian que ce module ne couvre '
              'pas : %s' % ', '.join(non_couverts))
        verif(all(v == '' or _MOTIF_PAQUET.match(v)
                  for v in PAQUETS_APT.values()),
              'PAQUETS_APT contient un nom de paquet douteux')
        verif(all(_MOTIF_PAQUET.match(p) and bool(r)
                  for p, r in PAQUETS_PREREQUIS.items()),
              'chaque paquet de PAQUETS_PREREQUIS doit porter un nom valable '
              'ET la raison de sa présence')
        for moteur, binaire in MOTEURS.items():
            verif(binaire == '' or binaire in PAQUETS_APT,
                  'MOTEURS[%r] = %r n’est pas une clef de PAQUETS_APT : ce '
                  'binaire ne serait jamais résolu' % (moteur, binaire))
        debogueur = _debogueur()
        if debogueur is not None:
            moteurs = set(getattr(debogueur, 'INSTALLATIONS', {}))
            verif(moteurs <= set(MOTEURS),
                  'debogueur_universel.INSTALLATIONS a des moteurs que MOTEURS '
                  'ne traduit pas : %s' % ', '.join(sorted(moteurs - set(MOTEURS))))
        verif(MOTEURS.get('basic') == 'yabasic'
              and 'basic' not in MOTEURS.values(),
              'les clefs de INSTALLATIONS sont des noms de MOTEURS : « basic » '
              'n’est pas un exécutable et ne doit pas être vérifié comme tel')
        for binaire, commande, role in CONSTRUCTION:
            verif(bool(role) and bool(commande),
                  'CONSTRUCTION doit déclarer une commande et un rôle pour %s'
                  % binaire)
        verif(route(CONSTRUCTION[0][1], 'asar')['voie'] == 'npm',
              'asar vient de npm, pas d’apt')
        verif(route(CONSTRUCTION[1][1], 'mksquashfs')['paquets']
              == ['squashfs-tools'],
              'mksquashfs vient du paquet squashfs-tools')

        # -- 5. les chemins et PATH ---------------------------------------
        with tempfile.TemporaryDirectory() as temporaire:
            ancien = os.environ.get(DOSSIER_ENV)
            ancien_path = os.environ.get('PATH', '')
            os.environ[DOSSIER_ENV] = temporaire
            try:
                chemins = preparer_dossier()
                verif(all(Path(chemins[c]).is_dir()
                          for c in ('bin', 'telechargements', 'extraits',
                                    'venvs', 'node')),
                      'preparer_dossier doit créer toute l’arborescence')
                verif(not chemins['notes'],
                      'preparer_dossier signale : %s' % chemins['notes'])
                binaires = etendre_path()
                morceaux = os.environ['PATH'].split(os.pathsep)
                verif(morceaux[0] == binaires,
                      'le dossier d’outils doit être EN TÊTE de PATH, sinon un '
                      'outil du système masque celui qui vient d’être installé')
                avant_path = os.environ['PATH']
                etendre_path()
                verif(os.environ['PATH'] == avant_path,
                      'etendre_path doit être idempotent')
                # Un lien symbolique doit être résolu : nommer un chemin et en
                # lancer un autre rendrait un diagnostic faux.
                reel = Path(temporaire) / 'vrai-outil'
                reel.write_text('#!/bin/sh\necho ok\n', encoding='utf8')
                reel.chmod(0o755)
                dossier_liens = Path(temporaire) / 'liens'
                dossier_liens.mkdir()
                (dossier_liens / 'outil-lie').symlink_to(reel)
                os.environ['PATH'] = '%s%s%s' % (dossier_liens, os.pathsep,
                                                 ancien_path)
                verif(_localiser('outil-lie') == str(reel.resolve()),
                      '_localiser doit rendre le chemin RÉEL d’un lien '
                      'symbolique, reçu %r' % _localiser('outil-lie'))
                verif(_localiser('outil-qui-n-existe-pas') is None,
                      'un binaire absent doit rendre None, pas lever')
                # sys.path : la cible est ajoutée EN FIN, et vendor-python
                # n'y entre jamais.
                cible = etendre_syspath()
                verif(sys.path[-1] == cible,
                      'le dossier des bibliothèques doit être ajouté EN FIN de '
                      'sys.path, pour ne jamais masquer un paquet du système')
                etendre_syspath()
                verif(sys.path.count(cible) == 1,
                      'etendre_syspath doit être idempotent')
                verif(not any('vendor-python' in m for m in sys.path),
                      'vendor-python ne doit JAMAIS entrer dans sys.path : ces '
                      'pilotes sont chargés explicitement par leur module')
            finally:
                if ancien is None:
                    os.environ.pop(DOSSIER_ENV, None)
                else:
                    os.environ[DOSSIER_ENV] = ancien
                os.environ['PATH'] = ancien_path
                sys.path[:] = avant_sys

        # -- 6. les archives : rien ne sort du dossier ---------------------
        verif(_nom_sur('a/b/c.txt') and _nom_sur('serveur/bin/lua'),
              'un chemin relatif normal doit être accepté')
        for dangereux in ('../evil', '/etc/passwd', 'a/../../b', '\\..\\x',
                          'C:\\x', '..'):
            verif(not _nom_sur(dangereux),
                  '_nom_sur(%r) doit refuser : c’est la faille « zip slip »'
                  % dangereux)
        with tempfile.TemporaryDirectory() as temporaire:
            dossier = Path(temporaire)
            mechant = dossier / 'mechant.zip'
            with zipfile.ZipFile(mechant, 'w') as paquet:
                paquet.writestr('../../echappe.txt', 'hors du dossier')
                paquet.writestr('bon/outil.txt', 'dedans')
            cible = dossier / 'extrait'
            resultat, erreur = _sans_lever(_extraire, mechant, cible)
            verif(resultat is not None, '_extraire a levé %s' % erreur)
            if resultat:
                verif(resultat['ok'] and len(resultat['refuses']) == 1,
                      'le membre qui remonte doit être REFUSÉ et annoncé : %r'
                      % resultat)
                verif(not (dossier / 'echappe.txt').exists()
                      and not (dossier.parent / 'echappe.txt').exists(),
                      'un fichier a été écrit hors du dossier d’extraction')
                verif((cible / 'bon' / 'outil.txt').is_file(),
                      'le membre normal doit être extrait')
            mechant_tar = dossier / 'mechant.tar'
            with tarfile.open(mechant_tar, 'w') as paquet:
                # `tarfile.add(arcname='/etc/…')` SUPPRIME la barre oblique
                # initiale en avertissant : le membre construit ainsi est
                # inoffensif, et le contrôle passait pour rien. Les deux
                # membres dangereux sont donc écrits à la main.
                for nom in ('/etc/echappe-absolu.txt', '../echappe-relatif.txt'):
                    info = tarfile.TarInfo(name=nom)
                    donnees = b'x'
                    info.size = len(donnees)
                    paquet.addfile(info, io.BytesIO(donnees))
            resultat, erreur = _sans_lever(_extraire, mechant_tar,
                                           dossier / 'extrait-tar')
            verif(resultat is not None, '_extraire(tar) a levé %s' % erreur)
            if resultat:
                verif(sorted(resultat['refuses'])
                      == sorted(['/etc/echappe-absolu.txt',
                                 '../echappe-relatif.txt']),
                      'un membre absolu ET un membre qui remonte doivent être '
                      'refusés : %r' % resultat['refuses'])
                verif(not (dossier / 'echappe-relatif.txt').exists(),
                      'un membre tar qui remonte a été écrit hors du dossier')
            pas_archive = dossier / 'texte.zip'
            pas_archive.write_bytes('ceci n’est pas un zip'.encode('utf8'))
            resultat, erreur = _sans_lever(_extraire, pas_archive,
                                           dossier / 'extrait-faux')
            verif(resultat is not None and not resultat['ok']
                  and 'illisible' in resultat['erreur'],
                  'une archive illisible doit être nommée, pas levée : %r %s'
                  % (resultat, erreur))
            inconnu = dossier / 'paquet.rar'
            inconnu.write_bytes(b'RAR!')
            resultat, erreur = _sans_lever(_extraire, inconnu,
                                           dossier / 'extrait-rar')
            verif(resultat is not None and not resultat['ok']
                  and 'pas reconnu' in resultat['erreur'],
                  'un format non reconnu doit être annoncé comme tel : %r'
                  % resultat)
            # Un seul dossier à la racine : c'est lui qui est annoncé comme
            # racine, et c'est lui qui est fouillé pour trouver l'exécutable.
            racine_zip = dossier / 'racine.zip'
            with zipfile.ZipFile(racine_zip, 'w') as paquet:
                paquet.writestr('outil-1.2/bin/outil', '#!/bin/sh\n')
                paquet.writestr('outil-1.2/LISEZ-MOI', 'x')
            resultat = _extraire(racine_zip, dossier / 'extrait-racine')
            verif(resultat['ok'] and resultat['racine'].endswith('outil-1.2'),
                  'une archive à dossier unique doit rendre ce dossier comme '
                  'racine : %r' % resultat['racine'])
            voulus, binaires, borne = _chercher_executables(
                resultat['racine'], ['outil'])
            verif(voulus['outil'] and voulus['outil'].endswith('bin/outil'),
                  'l’exécutable demandé doit être trouvé dans l’arborescence '
                  'extraite : %r' % voulus)
            verif(not borne, 'la borne de recherche ne doit pas être atteinte '
                             'sur une petite arborescence')
            # _lier rend exécutable et place dans bin.
            sans_droit = dossier / 'outil-sans-droit'
            sans_droit.write_text('#!/bin/sh\necho x\n', encoding='utf8')
            sans_droit.chmod(0o644)
            ancien = os.environ.get(DOSSIER_ENV)
            os.environ[DOSSIER_ENV] = str(dossier / 'etat')
            ancien_path = os.environ.get('PATH', '')
            try:
                lien = _lier(sans_droit)
                etendre_path()
                verif(lien['ok'] and os.access(lien['lien'], os.X_OK),
                      '_lier doit rendre le binaire exécutable et le lier : %r'
                      % lien)
                verif(_localiser('outil-sans-droit') is not None,
                      'après _lier, l’outil doit être trouvable dans PATH')
                verif(not _lier(dossier / 'absent')['ok'],
                      '_lier sur un fichier absent doit échouer, pas lever')
                # Ce qui est lié depuis un venv ou depuis un paquet npm. Le
                # dossier d'outils est EN TÊTE de PATH : y lier un interpréteur
                # masquerait celui du système.
                source = dossier / 'paquet'
                source.mkdir()
                for nom in ('python3.13', 'python3', 'pip3.13', 'pip',
                            'activate', 'activate.fish', 'Activate.ps1',
                            'wheel', 'mon-outil', 'autre-outil'):
                    fichier = source / nom
                    fichier.write_text('#!/bin/sh\necho x\n', encoding='utf8')
                    fichier.chmod(0o755)
                etat_outils = os.environ[DOSSIER_ENV]
                lien = _lier_attendus(source, {'binaires': ['mon-outil']})
                lies = [Path(l).name for l in lien['lies']]
                verif(lies == ['mon-outil'],
                      'seul l’exécutable ATTENDU doit être lié depuis un '
                      'dossier de paquet : %r' % lies)
                verif(not lien['repli'],
                      'le repli ne doit pas servir quand le nom attendu est là')
                for dangereux in ('python3.13', 'pip3.13', 'activate',
                                  'wheel', 'Activate.ps1', 'autre-outil'):
                    trouve = _localiser(dangereux)
                    verif(not trouve or not trouve.startswith(etat_outils),
                          '%s ne doit JAMAIS être lié dans le dossier '
                          'd’outils : il est en tête de PATH et masquerait '
                          'l’outil du système (trouvé : %r)'
                          % (dangereux, trouve))
                # Le repli, borné et annoncé.
                seul = dossier / 'paquet-sans-nom'
                seul.mkdir()
                for nom in ('un-autre', 'encore-un-autre'):
                    fichier = seul / nom
                    fichier.write_text('#!/bin/sh\n', encoding='utf8')
                    fichier.chmod(0o755)
                lien = _lier_attendus(seul, {'binaires': ['mon-outil']})
                verif(lien['repli'] and len(lien['lies']) == 2,
                      'si aucun nom attendu n’est trouvé, le repli doit lier '
                      'les exécutables présents et le dire : %r' % lien)
                verif(not _lier_attendus(dossier / 'dossier-absent',
                                         {'binaires': ['x']})['lies'],
                      'un dossier illisible doit rendre vide, pas lever')
                # Une bibliothèque Python se détecte comme une bibliothèque.
                # Une distribution minimale, fabriquée ici : `json` n'a aucune
                # métadonnée (module standard), et prendre un paquet vraiment
                # installé rendrait le banc dépendant de la machine.
                bibliotheques = Path(etat_outils) / 'python'
                (bibliotheques / 'fauxpaquet').mkdir(parents=True,
                                                      exist_ok=True)
                (bibliotheques / 'fauxpaquet' / '__init__.py').write_text(
                    '', encoding='utf8')
                metadata = bibliotheques / 'fauxpaquet-1.2.3.dist-info'
                metadata.mkdir(exist_ok=True)
                (metadata / 'METADATA').write_text(
                    'Metadata-Version: 2.1\nName: fauxpaquet\n'
                    'Version: 1.2.3\n', encoding='utf8')
                biblio = {'famille': 'bibliothèques Python', 'nom': 'json',
                          'binaires': ['json']}
                etats = detecter_groupe(biblio, True)
                verif(etats[0]['present'],
                      'une bibliothèque du langage standard doit être dite '
                      'présente par find_spec, pas par which : %r' % etats)
                faux = {'famille': 'bibliothèques Python',
                        'nom': 'fauxpaquet', 'binaires': ['fauxpaquet']}
                etats = detecter_groupe(faux, True)
                verif(etats[0]['present'] and etats[0]['version'] == '1.2.3',
                      'la version d’une bibliothèque installée doit être lue '
                      'dans ses métadonnées, SANS l’importer : %r' % etats)
                verif('fauxpaquet' not in sys.modules,
                      'lire l’état d’une bibliothèque ne doit pas l’importer')
                absente = {'famille': 'bibliothèques Python',
                           'nom': 'module-inexistant-xyz',
                           'binaires': ['module_inexistant_xyz']}
                verif(not detecter_groupe(absente)[0]['present'],
                      'une bibliothèque absente doit être dite absente')
                verif(_localiser('json') is None,
                      'le contrôle ci-dessus ne vaut que si `json` n’a PAS '
                      'd’exécutable dans PATH : sinon il passerait par hasard')
            finally:
                if ancien is None:
                    os.environ.pop(DOSSIER_ENV, None)
                else:
                    os.environ[DOSSIER_ENV] = ancien
                os.environ['PATH'] = ancien_path

        # -- 7. télécharger : somme, reprise, place ------------------------
        with tempfile.TemporaryDirectory() as temporaire:
            dossier = Path(temporaire)
            source = dossier / 'source.bin'
            contenu = b'Pascal Studio' * 4096
            source.write_bytes(contenu)
            somme = hashlib.sha256(contenu).hexdigest()
            url = source.as_uri()
            ancien = os.environ.get(DOSSIER_ENV)
            os.environ[DOSSIER_ENV] = str(dossier / 'etat')
            try:
                bon = telecharger_fichier(url, dossier / 'etat' / 'a.bin',
                                          None, somme, len(contenu))
                verif(bon['ok'] and bon['somme'] == somme
                      and bon['somme_conforme'],
                      'un téléchargement complet et conforme doit réussir : %r'
                      % {k: v for k, v in bon.items() if k != 'chemin'})
                faux = telecharger_fichier(url, dossier / 'etat' / 'b.bin',
                                           None, '0' * 64, len(contenu))
                verif(not faux['ok'] and 'somme de contrôle' in faux['erreur'],
                      'une somme non conforme doit échouer ET nommer la '
                      'somme : %r' % faux.get('erreur'))
                verif(not (dossier / 'etat' / 'b.bin').exists(),
                      'un fichier dont la somme ne correspond pas doit être '
                      'SUPPRIMÉ, pas extrait')
                court = telecharger_fichier(url, dossier / 'etat' / 'c.bin',
                                            None, '', len(contenu) * 3)
                verif(not court['ok'] and 'incomplet' in court['erreur'],
                      'un téléchargement plus court qu’annoncé doit être dit '
                      'incomplet : %r' % court.get('erreur'))
                verif((dossier / 'etat' / 'c.bin.part').exists(),
                      'le fichier partiel doit être conservé pour une reprise')
                deja = telecharger_fichier(url, dossier / 'etat' / 'a.bin',
                                           None, somme, len(contenu))
                verif(deja['ok'] and deja['repris'] == 0,
                      'un fichier déjà complet ne doit pas être retéléchargé')
                place, raison = _place_necessaire(10 ** 18)
                verif(not place and 'Place insuffisante' in raison
                      and ('Go' in raison or 'To' in raison),
                      'un téléchargement plus grand que le disque doit être '
                      'refusé AVEC les chiffres : %r' % raison)
                verif(_place_necessaire(1024)[0],
                      'un petit téléchargement doit passer')
                verif(_place_necessaire(0)[0],
                      'une taille inconnue ne doit pas bloquer : elle est '
                      'annoncée plus tard')
                verif(_octets(0) == '0 o' and 'Mo' in _octets(570 * 1024 * 1024)
                      and 'Go' in _octets(2 * 1024 ** 3),
                      '_octets doit rendre des tailles lisibles : %r %r %r'
                      % (_octets(0), _octets(570 * 1024 * 1024),
                         _octets(2 * 1024 ** 3)))
            finally:
                if ancien is None:
                    os.environ.pop(DOSSIER_ENV, None)
                else:
                    os.environ[DOSSIER_ENV] = ancien

        # -- 8. l'exécution : arrêt réel, code fidèle, journal borné -------
        with tempfile.TemporaryDirectory() as temporaire:
            dossier = Path(temporaire)
            # Le seul endroit du banc où un interpréteur de commandes est
            # lancé : il sert à FABRIQUER un outil qui avertit puis répond avec
            # un code non nul. Le produit, lui, ne passe jamais par un shell.
            averti = dossier / 'averti.sh'
            averti.write_text('#!/bin/sh\necho reponse\n'
                              'echo avis >&2\nexit 1\n', encoding='utf8')
            averti.chmod(0o755)
            resultat = _flux([str(averti)])
            verif(not resultat['ok'] and resultat['code'] == 1
                  and 'reponse' in resultat['sortie']
                  and 'avis' in resultat['sortie'],
                  'un installeur qui rend 1 est un ÉCHEC, même s’il a écrit '
                  'quelque chose : le code doit rester fidèle et la sortie '
                  'visible (%r)' % {k: resultat[k] for k in ('ok', 'code')})
            sommeil = _localiser('sleep')
            if sommeil:
                tache = _nouvelle_tache(['test'])
                tache['arret'].set()
                debut = time.monotonic()
                resultat, erreur = _sans_lever(_flux, [sommeil, '60'], tache)
                duree = time.monotonic() - debut
                verif(resultat is not None, '_flux a levé %s' % erreur)
                if resultat:
                    verif(not resultat['ok'] and resultat['arrete'],
                          'un enfant lancé alors que l’arrêt est déjà demandé '
                          'doit être terminé : %r' % resultat)
                    verif(duree < 20,
                          '_flux a mis %.1f s à rendre la main sur un arrêt : '
                          'l’enfant n’a pas été tué' % duree)
                resultat = _flux([sommeil, '0'])
                verif(resultat['ok'] and resultat['code'] == 0,
                      'une commande qui réussit doit rendre ok : %r' % resultat)
            verif('introuvable' in _flux(['commande-inexistante-xyz'])['erreur'],
                  'une commande absente doit être nommée, pas lever')
            tache = _nouvelle_tache(['test'])
            for index in range(LIMITE_JOURNAL + 25):
                _dire(tache, 'sortie', 'ligne %d' % index)
            suivi = suivre(tache['sid'])
            verif(len(suivi['lignes']) <= LIMITE_JOURNAL,
                  'le journal doit être borné à %d entrées, reçu %d'
                  % (LIMITE_JOURNAL, len(suivi['lignes'])))
            verif(suivi['journal_tronque'] >= 25,
                  'le journal doit dire combien de lignes ont été jetées (%r)'
                  % suivi['journal_tronque'])
            verif(suivi['lignes'][-1]['texte'] == 'ligne %d'
                  % (LIMITE_JOURNAL + 24),
                  'ce sont les lignes les PLUS ANCIENNES qui doivent être '
                  'jetées, pas les dernières')
            verif(suivi['depuis'] == len(suivi['lignes']),
                  'suivre() doit rendre la position à reprendre')
            _dire(tache, 'sortie', 'x' * (LIMITE_LIGNE + 500))
            verif(len(suivre(tache['sid'])['lignes'][-1]['texte'])
                  <= LIMITE_LIGNE + 40,
                  'une ligne démesurée doit être tronquée')
            verif(not suivre('inexistant')['ok']
                  and 'inconnue' in suivre('inexistant')['erreur'],
                  'suivre() sur une tâche inconnue doit le dire')
            verif(not arreter('inexistant')['ok'],
                  'arreter() sur une tâche inconnue doit le dire')
            verif(arreter(tache['sid'])['ok'],
                  'arreter() sur une tâche connue doit réussir')
            with _VERROU:
                _TACHES.clear()

        # -- 9. le plan : joué sur un inventaire SYNTHÉTIQUE ---------------
        # Déterministe : il ne dépend pas de ce que la machine a déjà.
        faux = _inventaire_faux()
        globals()['etat'] = lambda *a, **k: faux
        try:
            tous = plan(tout=True, racine_autorisee=False)
            verif(tous['outils'] == 9,
                  'neuf outils manquent dans l’inventaire synthétique, le plan '
                  'en a retenu %d' % tous['outils'])
            verif('apt:gcc' not in tous['identifiants'],
                  'un outil déjà présent ne doit pas être planifié par '
                  '« Tout installer » : %r' % tous['identifiants'])
            verif(not tous['notes'],
                  '« Tout installer » ne doit pas noyer le plan sous les '
                  'remarques « déjà présent » : %r' % tous['notes'])
            apt = [e for e in tous['etapes'] if e['voie'] == 'apt']
            verif(len(apt) == 1,
                  'tous les paquets apt doivent tenir en UNE étape, donc une '
                  'seule demande de mot de passe (%d étapes)' % len(apt))
            if apt:
                verif(sorted(apt[0]['paquets'])
                      == sorted(['npm', 'gdb', 'binutils']),
                      'l’étape apt doit porter tous les paquets : %r'
                      % apt[0]['paquets'])
                verif(len(apt[0]['outils']) == 3,
                      'l’étape apt doit citer les trois outils qu’elle '
                      'installe : %r' % apt[0]['outils'])
                verif(apt[0]['commande'][1:7] == [
                          'env', 'DEBIAN_FRONTEND=noninteractive', 'apt-get',
                          'install', '-y', '--no-install-recommends'],
                      'la commande apt doit être exactement celle-là : %r'
                      % apt[0]['commande'])
                verif(apt[0]['racine'] and not apt[0]['executable'],
                      'sans droits root autorisés, une étape apt doit être '
                      'marquée non exécutable')
                verif(apt[0]['commande_manuelle'].startswith('sudo apt-get'),
                      'l’étape apt doit donner la commande à taper soi-même')
            npm = [e for e in tous['etapes'] if e['voie'] == 'npm']
            verif(len(npm) == 1 and len(npm[0]['paquets']) == 2,
                  'les deux paquets npm doivent tenir en une étape : %r'
                  % [e['paquets'] for e in npm])
            pip = [e for e in tous['etapes'] if e['voie'] == 'pip']
            verif(len(pip) == 2,
                  'pip ne se groupe pas : un venv par outil, un --target par '
                  'famille de bibliothèques (%d étapes)' % len(pip))
            biblio = [e for e in pip if 'pip:capstone' in e['outils']]
            verif(biblio and '--target' in biblio[0]['commande'],
                  'une bibliothèque Python doit être installée par --target, '
                  'pas dans un venv : %r' % biblio)
            voies = [e['voie'] for e in tous['etapes']]
            verif(voies == sorted(voies, key=ORDRE.index),
                  'les étapes doivent suivre l’ordre des voies, gestionnaires '
                  'et apt d’abord : %r' % voies)
            verif(tous['racine'] and not tous['racine_autorisee'],
                  'le plan doit dire qu’il contient une étape en root')
            for etape in tous['etapes']:
                verif(_code_interdit(etape['commande']) == '',
                      'une étape du plan contient un verbe interdit : %r'
                      % etape['commande'])
                verif(bool(etape['commande_texte'])
                      and bool(etape['commande_manuelle']),
                      'chaque étape doit porter sa commande exacte et son '
                      'équivalent manuel : %r' % etape['voie'])
                verif(all(isinstance(n, str) for n in etape['notes']),
                      'les remarques d’une étape doivent être du texte')
            avec_root = plan(tout=True, racine_autorisee=True)
            apt_root = [e for e in avec_root['etapes'] if e['voie'] == 'apt']
            verif(apt_root and apt_root[0]['executable']
                  is bool(_localiser('pkexec')),
                  'avec les droits root autorisés, l’étape apt n’est exécutable '
                  'que si pkexec est là : %r' % apt_root)
            un_seul = plan(['amont:marksman'])
            verif(len(un_seul['etapes']) == 1
                  and un_seul['etapes'][0]['voie'] == 'amont',
                  'un seul outil doit produire une seule étape : %r'
                  % un_seul['etapes'])
            verif(plan(['apt:gcc'])['notes']
                  and not plan(['apt:gcc'])['etapes'],
                  'un outil déjà présent doit être refusé avec la raison')
            verif(plan(['voix:inexistante'])['notes']
                  and not plan(['voix:inexistante'])['etapes'],
                  'un identifiant inconnu doit être nommé, pas planifié')
            verif(plan([])['resume'] and not plan([])['etapes'],
                  'un plan vide doit le dire')
            non_tele = dict(faux)
            non_tele['groupes'] = dict(faux['groupes'])
            non_tele['groupes']['amont:marksman'] = dict(
                faux['groupes']['amont:marksman'], telechargeable=False,
                notes=['Aucune archive publiée.'])
            globals()['etat'] = lambda *a, **k: non_tele
            verif(any('ne peut pas être installé' in n
                      for n in plan(['amont:marksman'])['notes']),
                  'un outil non téléchargeable doit dire pourquoi')
        finally:
            globals()['etat'] = etat_reel

        # -- 10. le plan réel ne dépend pas de la machine pour exister -----
        reel = etat(rafraichir=True)
        manquants = [o['id'] for o in reel['liste']
                     if not o['present'] and o['telechargeable']]
        planification = plan(manquants[:8], racine_autorisee=False)
        verif(planification['ok'], 'le plan réel doit se construire : %r'
              % planification.get('resume'))
        verif(len([e for e in planification['etapes'] if e['voie'] == 'apt'])
              <= 1, 'le plan réel ne doit pas multiplier les étapes apt')
        verif(plan(tout=True, racine_autorisee=False)['resume'],
              'plan(tout=True) doit rendre un résumé sur la machine réelle')

        # -- 11. l'état et les capacités s'accordent ----------------------
        verif(reel['total'] == len(reel['liste']),
              'le total annoncé doit être le nombre d’outils rendus')
        verif(reel['presents'] + reel['manquants'] == reel['total'],
              'présents + manquants doit faire le total')
        verif(reel['installables'] + reel['manuels'] == reel['manquants'],
              'installables + manuels doit faire les manquants')
        verif(sum(f['total'] for f in reel['familles'].values())
              == reel['total'],
              'la somme des familles doit faire le total')
        for nombre in re.findall(r'(\d+)', reel['resume']):
            verif(int(nombre) <= reel['total'],
                  'le résumé cite un nombre plus grand que l’inventaire : %r'
                  % reel['resume'])
        verif(len(reel['resume']) > 40 and 'outil' in reel['resume'],
              'le résumé doit être une phrase française : %r' % reel['resume'])
        capacite = capacites()
        verif(capacite['invente_des_urls'] is False
              and capacite['modifie_des_paquets_installes'] is False,
              'les capacités doivent annoncer ce que le module ne fait pas')
        verif(capacite['root_par_defaut'] is False
              and capacite['installe_en_root_apres_confirmation'] is True,
              'les droits root ne sont jamais accordés par défaut, et '
              'l’installation en root doit être annoncée comme confirmée')
        verif(capacite['dossier']['variable'] == DOSSIER_ENV,
              'capacites() doit nommer la variable qui déplace le dossier')
        for source in capacite['sources']:
            # Le découpage sur le premier point vient APRÈS ce test :
            # 'construire-appimage.py' n'est pas un module importable, c'est le
            # fichier hors image dont deux déclarations sont recopiées.
            if source.startswith('construire-appimage'):
                module, attribut = source, ''
            else:
                module, _, attribut = source.partition('.')
            if module == 'construire-appimage.py':
                verif(any(b == 'asar' for b, _c, _r in CONSTRUCTION)
                      and any(b == 'mksquashfs' for b, _c, _r in CONSTRUCTION),
                      'les deux déclarations recopiées de construire-appimage.py '
                      'doivent être là')
                continue
            charge = sys.modules.get(module) or _sans_lever(
                __import__, module)[0]
            verif(charge is not None,
                  'capacites() cite un module qui n’existe pas : %r' % source)
            if charge is not None and attribut:
                verif(hasattr(charge, attribut),
                      'capacites() cite %s, qui n’existe pas : l’annonce a '
                      'péri en silence' % source)
        verif(not touches,
              'verifier() a touché au réseau : %s' % ', '.join(touches))
    finally:
        urllib.request.urlopen = urlopen_reel
        globals()['telecharger'] = telecharger_reel
        globals()['demarrer'] = demarrer_reel
        globals()['etat'] = etat_reel
        sys.path[:] = avant_sys

    if problemes:
        print('outils_manquants : %d contrôle(s), %d ÉCHEC'
              % (compte[0], len(problemes)))
        for probleme in problemes:
            print('  ÉCHEC : ' + probleme)
    else:
        print('outils_manquants : %d contrôles, 0 échec ; %d outils '
              'inventoriés en moissonnant %d registres du produit, %d voies '
              'd’installation, aucune URL inventée, aucune commande '
              'destructrice possible, archives triées, sommes vérifiées, '
              'journal borné, arrêt réel.'
              % (compte[0], etat()['total'], len(capacites()['sources']),
                 len(INSTALLEURS)))
    return problemes


if __name__ == '__main__':
    etendre_path()
    etat_courant = etat()
    print(etat_courant['resume'])
    for famille, compte in etat_courant['familles'].items():
        if compte['total']:
            print('  %-24s %2d outil(s), %2d manquant(s)'
                  % (famille, compte['total'], compte['manquants']))
    print('  dossier  : %s' % etat_courant['chemins']['dossier'])
    print('  dans PATH : %s' % etat_courant['chemins']['dans_path'])
    manquants = [o for o in etat_courant['liste'] if not o['present']]
    for outil in manquants[:12]:
        print('  manque : %-34s %-9s %s'
              % (outil['id'], outil['voie'],
                 outil['commande'] or (outil['notes'] or [''])[0]))
    if len(manquants) > 12:
        print('  … et %d autres' % (len(manquants) - 12))
    sys.exit(1 if verifier() else 0)
