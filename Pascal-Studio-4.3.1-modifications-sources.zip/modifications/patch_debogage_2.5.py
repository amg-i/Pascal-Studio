"""Patch ciblé sur le bundle de la version 2.4.0."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(old,new,count=1):
 global s
 n=s.count(old)
 if n!=count:raise SystemExit(f'Bundle inattendu ({n}/{count} occurrences) : {old[:130]}')
 s=s.replace(old,new)
change('["pascal","c","cpp","python","javascript","php"].includes(vr(O))','["pascal","c","cpp","python","javascript","php","rust","go","ruby"].includes(vr(O))',2)
change('Débogage disponible pour Pascal, C, C++, Python, JavaScript Node et PHP CLI. Le débogage des pages web et de C# n’est pas intégré.', 'Débogage disponible pour Pascal, C, C++, Rust, Go, Ruby, Python, JavaScript Node et PHP CLI. Le débogage des pages web et de C# n’est pas intégré.')
change('["c","cpp","python","javascript","php","ruby"].includes(et)', '["c","cpp","python","javascript","php","ruby","rust","go"].includes(et)')
change('et==="javascript"?n.node:et==="ruby"?n.ruby:n.php)', 'et==="javascript"?n.node:et==="ruby"?n.ruby:et==="rust"?n.rust:et==="go"?n.go:n.php)')
change('et==="ruby"?"Installez Ruby pour l’analyse":"Installez GCC/G++ pour l’analyse"','et==="ruby"?"Installez Ruby pour l’analyse":et==="rust"?"Installez rustc pour l’analyse":et==="go"?"Installez gofmt pour l’analyse":"Installez GCC/G++ pour l’analyse"')
change('["pascal","c","cpp","python","javascript","php","ruby"].includes(vr(pa.path))','["pascal","c","cpp","python","javascript","php","ruby","rust","go"].includes(vr(pa.path))')
change('n==null?void 0:n.ruby,X,ys]','n==null?void 0:n.ruby,n==null?void 0:n.rust,n==null?void 0:n.go,X,ys]')
change('const vr=o=>{','const psMerge=(a,b)=>a.concat(b.filter(x=>!a.some(y=>y.file===x.file&&y.line===x.line&&y.column===x.column&&y.message===x.message)));const vr=o=>{')
change('[pyRuntime,setPyRuntime]=Ee.useState([]),pySeen=Ee.useRef(null)', '[pyRuntime,setPyRuntime]=Ee.useState([]),[buildDiag,setBuildDiag]=Ee.useState([]),pySeen=Ee.useRef(null)')
anchor='Ee.useEffect(()=>{setPyRuntime([])},[n==null?void 0:n.workspace]);'
change(anchor,anchor+'Ee.useEffect(()=>{setBuildDiag(ds=>{const next=ds.filter(d=>{const current=r.find(x=>x.path===d.file);return current&&current.content===d._snapshot});return next.length===ds.length?ds:next})},[r,n==null?void 0:n.workspace]);')
change('rb.setModelMarkers(O,"fpc",I.concat(pyRuntime)', 'rb.setModelMarkers(O,"fpc",psMerge(I,buildDiag).concat(pyRuntime)')
change('}},[I,pyRuntime,l,n==null?void 0:n.workspace])','}},[I,pyRuntime,buildDiag,l,n==null?void 0:n.workspace])')
change('t_=I.concat(pyRuntime).filter', 't_=psMerge(I,buildDiag).concat(pyRuntime).filter')
change('DS=I.concat(pyRuntime).filter', 'DS=psMerge(I,buildDiag).concat(pyRuntime).filter')
change('I.length+pyRuntime.length','psMerge(I,buildDiag).length+pyRuntime.length',2)
change('I.concat(pyRuntime).map((O,Q)=>T.createElement("button",{className:"diagnostic"','psMerge(I,buildDiag).concat(pyRuntime).map((O,Q)=>T.createElement("button",{className:"diagnostic"')
change('p(O?"run":"build"),R([]),setPyRuntime([]),D(', 'p(O?"run":"build"),R([]),setPyRuntime([]),setBuildDiag([]),D(')
change('D(pe.output||""),R(pe.diagnostics||[]),pe.ok?', 'D(pe.output||""),R(pe.diagnostics||[]),setBuildDiag(["go","rust"].includes(pe.kind)?(pe.diagnostics||[]).filter(x=>x.file===Q&&Qi.current.some(t=>t.path===Q)).map(x=>({...x,_snapshot:Qi.current.find(t=>t.path===Q).content})):[]),pe.ok?')
change('te(!0),setPyRuntime([]),$("Préparation du débogage…")','te(!0),setPyRuntime([]),setBuildDiag([]),$("Préparation du débogage…")')
change('D(Q.output||""),R(Q.diagnostics||[]),!Q.ok)', 'D(Q.output||""),R(Q.diagnostics||[]),setBuildDiag(["go","rust"].includes(Q.kind)?(Q.diagnostics||[]).filter(x=>x.file===O&&Qi.current.some(t=>t.path===O)).map(x=>({...x,_snapshot:Qi.current.find(t=>t.path===O).content})):[]),!Q.ok)')
# Fiches complémentaires pour toutes les familles documentées.
change('...(window.PS_LANG_HELP?.articles||[])]}', '...(window.PS_LANG_HELP?.articles||[]),...(window.PS_EXTRA_HELP?.articles||[])]}')
change('Ee.useEffect(()=>{setPyRuntime([])},[n==null?void 0:n.workspace]);', 'Ee.useEffect(()=>{setPyRuntime([]);setBuildDiag([])},[n==null?void 0:n.workspace]);')
change('P.kind==="python"?P.output.replace(', '["python","rust","go","ruby"].includes(P.kind)?P.output.replace(')
change('^Traceback |^\\s*File "|^\\s*[~^]+|^[\\w.]+(?:Error|Exception|Interrupt)(?::|$)', '^Traceback |^\\s*File "|^\\s*[~^]+|^[\\w.]+(?:Error|Exception|Interrupt)(?::|$)|^panic:|^thread .*panicked at |^.*\\.rb:\\d+:in |^\\s*.*\\.go:\\d+(?:\\s|$)')
p.write_text(s,encoding='utf8')
