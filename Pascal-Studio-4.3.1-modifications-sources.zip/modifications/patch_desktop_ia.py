from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
def rep(a,b):
 global s
 if s.count(a)!=1:raise SystemExit('Ancre desktop non unique: '+a[:100])
 s=s.replace(a,b)
rep('let server, window, allowWindowClose=false,', 'let server, aiServer, window, allowWindowClose=false,')
rep('  const port=await freePort();\n  server=spawn(', '''  const aiPort=await freePort();
  const aiData=path.join(app.getPath('userData'),'assistant-ia');fs.mkdirSync(aiData,{recursive:true,mode:0o700});fs.chmodSync(aiData,0o700);
  const aiEntry=path.join(resources,'assistant-ia','lanceur.py');
  aiServer=spawn('python3',[aiEntry],{env:{...process.env,PORT:String(aiPort),DB_PATH:path.join(aiData,'history.db'),AUDIT_LOG:path.join(aiData,'audit.log'),PS_AI_ENV:path.join(aiData,'cloud.env'),HUMAN_HOME:app.getPath('home'),OLLAMA_URL:'http://127.0.0.1:11434',AGENT_ALLOW_CLOUD:'0',MEMORY_CLOUD:'0',NO_BROWSER:'1'},stdio:['ignore','pipe','pipe']});
  aiServer.on('error',e=>console.error('Assistant IA :',e.message));aiServer.stderr.on('data',d=>console.error('Assistant IA :',String(d).slice(0,4000)));
  try {await waitUntilReady(aiPort,aiServer)} catch(e){console.error('Assistant IA indisponible :',e.message)}
  const port=await freePort();
  server=spawn(''')
rep("PASCAL_HOST:'127.0.0.1',PASCAL_PORT:String(port),PASCAL_WORKSPACE:project", "PASCAL_HOST:'127.0.0.1',PASCAL_PORT:String(port),PASCAL_AI_URL:`http://127.0.0.1:${aiPort}/`,PASCAL_WORKSPACE:project")
rep("if(server&&!server.killed)server.kill('SIGTERM')", "if(server&&!server.killed)server.kill('SIGTERM');if(aiServer&&!aiServer.killed)aiServer.kill('SIGTERM')")
p.write_text(s)
