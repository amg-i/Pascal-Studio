"""Pascal Studio 3.6.0 — Swift et Kotlin dans les filtres d'ouverture d'Electron.

Le dialogue « Ouvrir un fichier » de desktop/main.cjs filtre par extension. Sans
cet ajout, un fichier .swift ou .kt reste invisible tant que l'utilisateur ne
bascule pas sur « Tous les fichiers ».

Usage : python3 patch_desktop_langages.py CHEMIN/desktop/main.cjs

Idempotent. S'applique au main.cjs déjà corrigé par reconditionner-3.3.0.sh
(Fortran, Perl, Yabasic, OCaml, Lua).
"""
from pathlib import Path
import sys

ANCIEN = "'ml','mli','lua','js'"
NOUVEAU = "'ml','mli','lua','swift','kt','kts','js'"


def main(argv):
    if len(argv) != 1:
        sys.stderr.write(__doc__)
        return 2
    chemin = Path(argv[0])
    source = chemin.read_text(encoding='utf8')
    if NOUVEAU in source:
        print('desktop/main.cjs : extensions swift, kt et kts déjà présentes.')
        return 0
    if source.count(ANCIEN) != 1:
        sys.stderr.write(
            'Ancre desktop non unique ou absente : %s (trouvée %d fois).\n'
            'Le main.cjs doit d’abord porter les extensions ajoutées en 3.3.0.\n'
            % (ANCIEN, source.count(ANCIEN)))
        return 1
    chemin.write_text(source.replace(ANCIEN, NOUVEAU), encoding='utf8')
    print('desktop/main.cjs : swift, kt et kts ajoutés aux filtres d’ouverture.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
