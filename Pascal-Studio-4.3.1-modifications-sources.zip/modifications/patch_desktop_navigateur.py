"""Pascal Studio 4.0.0 — navigateur intégré : activer et encadrer <webview>.

Le panneau navigateur affiche de vraies pages web dans l'application. Il ne
s'agit PAS d'installer Firefox, Chrome ou Edge dans la fenêtre : Pascal Studio
est déjà une application Electron, donc le moteur de rendu Chromium est déjà là.
Ce qui manquait, c'est le droit de s'en servir comme d'un navigateur :

  1. `webviewTag:true` — sans lui, la balise <webview> est inerte et le panneau
     reste désespérément blanc, sans erreur nulle part. C'est le correctif
     central, et son absence est silencieuse : c'est précisément ce qui le rend
     dangereux à oublier.
  2. `session` dans les imports — nécessaire pour la partition et les
     téléchargements.
  3. Les GARDES sur l'invité. Electron laisse l'hôte décider ce qu'un <webview>
     a le droit d'être, et par défaut il ne décide rien : une page affichée dans
     le panneau pourrait demander un script de preload ou l'intégration Node, et
     exécuter du code avec nos droits. `will-attach-webview` est l'endroit où
     l'hôte impose ses conditions AVANT la création de l'invité.

Pourquoi les gardes existantes ne suffisent pas
-----------------------------------------------
    Le main.cjs pose déjà deux garde-fous :
        window.webContents.setWindowOpenHandler(...)   -> aucune fenêtre popup
        window.webContents.on('will-navigate', ...)    -> la fenêtre principale
                                                          ne quitte pas 127.0.0.1
    Elles portent sur `window.webContents`, c'est-à-dire sur la fenêtre
    PRINCIPALE. Un invité <webview> a ses PROPRES webContents : il n'est concerné
    par aucune des deux. Sans garde dédiée, un popup ouvert depuis une page
    affichée dans le panneau échapperait au panneau, et un invité pourrait
    naviguer vers file:// ou un schéma exotique. Les gardes de l'invité sont
    donc posées dans `did-attach-webview`, qui donne accès à ses webContents.

Usage :
    python3 patch_desktop_navigateur.py CHEMIN/desktop/main.cjs
    python3 patch_desktop_navigateur.py --verifier CHEMIN/desktop/main.cjs

Codes de retour : 0 = les trois signatures sont présentes (mode normal : rien à
faire ou correctif écrit ; --verifier : navigateur intégré en place),
1 = une ancre manque, une signature manque en mode --verifier, OU la chaîne de
correctifs 3.x est absente, 2 = usage invalide. --verifier n’écrit jamais.

Pourquoi --verifier exige les SIGNATURES et non les ancres : les trois ancres
existent déjà dans le main.cjs d'origine, donc un fichier vierge les contient
toutes. Un vérificateur qui se contenterait de « les ancres sont applicables »
rendrait 0 sur un fichier NON corrigé, et un script de construction qui s'appuie
sur ce code pour décider d'appliquer ou non le correctif ne l'appliquerait
jamais — le panneau navigateur resterait désespérément blanc, sans erreur nulle
part. Idempotent substitution par substitution : un main.cjs qui porte déjà
webviewTag mais pas les gardes continue de progresser au lieu d'être refusé
en bloc.
"""
from pathlib import Path
import sys

# --------------------------------------------------------------------------- A
ANCRE_IMPORT = ("const {app, BrowserWindow, dialog, shell, ipcMain, clipboard} "
                "= require('electron');")
NOUVEAU_IMPORT = ("const {app, BrowserWindow, dialog, shell, ipcMain, clipboard, "
                  "session} = require('electron');")
SIGNATURE_IMPORT = "clipboard, session} = require('electron')"

# --------------------------------------------------------------------------- B
ANCRE_PREFS = ("webPreferences:{contextIsolation:true,nodeIntegration:false,"
               "sandbox:true,preload:path.join(__dirname,'preload.cjs')}")
NOUVEAU_PREFS = ("webPreferences:{contextIsolation:true,nodeIntegration:false,"
                 "sandbox:true,webviewTag:true,"
                 "preload:path.join(__dirname,'preload.cjs')}")
SIGNATURE_PREFS = "webviewTag:true"

# --------------------------------------------------------------------------- C
ANCRE_GARDES = ("window.webContents.on('will-navigate',(e,url)=>{"
                "if(!url.startsWith(`http://127.0.0.1:${port}/`))e.preventDefault()});")

BLOC = ANCRE_GARDES + """
  /* ---- 4.0.0 : navigateur intégré --------------------------------------
   * Un invité <webview> a ses propres webContents : les deux gardes posées
   * ci-dessus sur la fenêtre principale ne le concernent pas. Les siennes sont
   * posées ici. La partition isole ses cookies et son stockage de ceux de
   * l'interface, qui est servie depuis 127.0.0.1 : sans elle, un site affiché
   * dans le panneau partagerait l'origine de l'application. */
  const PARTITION_NAVIGATEUR='persist:pascal-navigateur';
  window.webContents.on('will-attach-webview',(e,prefs,params)=>{
    /* Aucun script de preload : ce serait du code arbitraire avec nos droits. */
    delete prefs.preload;delete prefs.preloadURL;
    prefs.nodeIntegration=false;
    prefs.nodeIntegrationInSubFrames=false;
    prefs.contextIsolation=true;
    prefs.sandbox=true;
    prefs.webSecurity=true;
    prefs.allowRunningInsecureContent=false;
    prefs.experimentalFeatures=false;
    prefs.enableBlinkFeatures='';
    prefs.disableBlinkFeatures='';
    params.partition=PARTITION_NAVIGATEUR;
  });
  window.webContents.on('did-attach-webview',(e,invite)=>{
    invite.setWindowOpenHandler(({url})=>{
      /* Le panneau ouvre lui-même un onglet : une fenêtre du système
       * échapperait au panneau et à ses gardes. */
      if(window&&!window.isDestroyed())window.webContents.send('navigateur:popup',url);
      return {action:'deny'};
    });
    invite.on('will-navigate',(ev,url)=>{
      if(/^(https?:|about:blank)/i.test(url))return;
      ev.preventDefault();
      if(/^mailto:/i.test(url))shell.openExternal(url);
      else if(window&&!window.isDestroyed())window.webContents.send('navigateur:popup',url);
    });
  });
  /* Téléchargements : rien ne doit atterrir en silence dans un dossier. Le
   * dialogue est SYNCHRONE parce que setSavePath() doit être appelé avant que
   * Chromium n'ait choisi un chemin par défaut — un dialogue asynchrone
   * arriverait après, et le fichier serait déjà écrit ailleurs. */
  const sessionNavigateur=session.fromPartition(PARTITION_NAVIGATEUR);
  sessionNavigateur.on('will-download',(e,item)=>{
    const nom=item.getFilename()||'telechargement';
    const choix=dialog.showSaveDialogSync(window,{
      title:'Enregistrer le téléchargement',
      defaultPath:path.join(app.getPath('downloads'),nom)});
    if(!choix){item.cancel();return}
    item.setSavePath(choix);
    item.once('done',(ev,state)=>{
      if(window&&!window.isDestroyed())window.webContents.send('navigateur:telechargement',
        {nom:nom,state:state,chemin:choix});
    });
  });
  /* Permissions : refusées, sauf ce qui ne touche pas à la vie privée et sert
   * réellement à tester une page (plein écran, presse-papiers assaini). Un
   * refus silencieux serait incompréhensible : il est relayé au panneau. */
  sessionNavigateur.setPermissionRequestHandler((wc,permission,rappel)=>{
    const accordees=['fullscreen','clipboard-sanitized-write'];
    rappel(accordees.includes(permission));
    if(!accordees.includes(permission)&&window&&!window.isDestroyed())
      window.webContents.send('navigateur:permission',{permission:permission,accordee:false});
  });"""
SIGNATURE_BLOC = "will-attach-webview"

SUBSTITUTIONS = [
    ('import-session', ANCRE_IMPORT, NOUVEAU_IMPORT, SIGNATURE_IMPORT),
    ('webviewTag', ANCRE_PREFS, NOUVEAU_PREFS, SIGNATURE_PREFS),
    ('gardes-invite', ANCRE_GARDES, BLOC, SIGNATURE_BLOC),
]

# Les trois ancres ci-dessus existent déjà dans le main.cjs d'origine fourni
# avec les sources 1.6 : leur seule présence ne prouve donc PAS que la chaîne
# de correctifs a été appliquée. Un marqueur du dernier correctif de la chaîne
# (3.6.0, les extensions Swift et Kotlin) le prouve. Sans ce contrôle, le
# patcheur acceptait en silence un desktop/main.cjs venu d'ailleurs — et
# l'utilisateur lance parfois une copie périmée de ses scripts.
MARQUEUR_CHAINE = "'swift','kt','kts'"


def chaine_appliquee(source):
    return MARQUEUR_CHAINE in source


def appliquer(source, traces, verbe='appliquée'):
    """Rend (source, appliquees, manquantes).

    Chaque substitution porte sa propre SIGNATURE, c'est-à-dire la partie
    ajoutée et elle seule : tester la présence de l'ancre ne prouve rien, ces
    substitutions conservent leur ancre intacte après application.

    `verbe` distingue les deux modes dans les traces : en --verifier on ne
    modifie rien, donc annoncer « appliquée » décrirait un travail qui n'a pas
    eu lieu. « presente » dit ce qui est vrai dans les deux cas.
    """
    appliquees, manquantes = 0, []
    for nom, ancre, nouveau, signature in SUBSTITUTIONS:
        if signature in source:
            traces.append('%-16s déjà appliquée' % nom)
            appliquees += 1
            continue
        if source.count(ancre) != 1:
            traces.append('%-16s ANCRE INTROUVABLE (%d occurrences)'
                          % (nom, source.count(ancre)))
            manquantes.append(nom)
            continue
        source = source.replace(ancre, nouveau, 1)
        traces.append('%-16s %s' % (nom, verbe))
        appliquees += 1
    return source, appliquees, manquantes


def signatures(source):
    """Les substitutions dont la SIGNATURE est déjà dans `source`."""
    return [nom for nom, _a, _n, signature in SUBSTITUTIONS if signature in source]


def main(argv):
    verifier = '--verifier' in argv
    args = [a for a in argv if a != '--verifier']
    if len(args) != 1:
        sys.stderr.write(__doc__)
        return 2
    chemin = Path(args[0])
    if not chemin.is_file():
        sys.stderr.write('Fichier introuvable : %s\n' % chemin)
        return 1
    source = chemin.read_text(encoding='utf8')
    if not chaine_appliquee(source):
        sys.stderr.write(
            'desktop/main.cjs : la chaîne de correctifs 3.x est absente '
            '(marqueur %s introuvable).\n'
            '  Ce fichier n\u2019est pas un main.cjs de Pascal Studio corrigé : '
            'appliquez d\u2019abord\n'
            '  reconditionner-3.3.0.sh (extensions), patch_desktop_ia.py puis '
            'patch_desktop_langages.py,\n'
            '  ou partez du desktop-main.cjs livré dans modifications/.\n'
            % MARQUEUR_CHAINE)
        return 1
    traces = []
    deja = signatures(source)
    resultat, appliquees, manquantes = appliquer(
        source, traces, verbe='à appliquer' if verifier else 'appliquée')

    for trace in traces:
        sys.stderr.write('  ' + trace + '\n')

    if manquantes:
        sys.stderr.write(
            'desktop/main.cjs : ancre(s) manquante(s) : %s. Le fichier doit '
            'd’abord porter les correctifs 3.3.0 (extensions), '
            'patch_desktop_ia.py et patch_desktop_langages.py.\n'
            % ', '.join(manquantes))
        return 1
    if verifier:
        # Le verdict porte sur les SIGNATURES, jamais sur les ancres : celles-ci
        # sont présentes dans le main.cjs d'origine, donc un fichier vierge les
        # contient toutes et un vérificateur naïf rendrait 0 sur un fichier NON
        # corrigé. Un script de construction qui s'appuie sur ce code pour
        # décider d'appliquer le correctif ne l'appliquerait alors jamais.
        if len(deja) == len(SUBSTITUTIONS):
            sys.stderr.write('desktop/main.cjs : navigateur intégré en place '
                             '(%d/%d signatures).\n'
                             % (len(deja), len(SUBSTITUTIONS)))
            return 0
        absentes = [nom for nom, _ancre, _nouveau, signature in SUBSTITUTIONS
                    if signature not in source]
        sys.stderr.write(
            'desktop/main.cjs : navigateur intégré ABSENT — %d/%d signature(s) '
            'seulement ; manque : %s.\n'
            '  Les ancres sont applicables mais rien n’est en place : lancez ce '
            'script\n'
            '  sans --verifier pour écrire le correctif.\n'
            % (len(deja), len(SUBSTITUTIONS), ', '.join(absentes)))
        return 1
    if resultat == source:
        print('desktop/main.cjs : navigateur intégré déjà en place, rien à faire.')
        return 0
    chemin.write_text(resultat, encoding='utf8')
    print('desktop/main.cjs : <webview> activé et encadré (%d octets).'
          % len(resultat.encode('utf8')))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
