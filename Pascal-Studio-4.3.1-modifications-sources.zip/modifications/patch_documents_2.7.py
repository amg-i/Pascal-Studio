#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit('Ancre non unique '+str(n)+' : '+repr(a[:150]))
 s=s.replace(a,b,1)
change('vC=[{name:"Fichier",items:', 'psRegisterSave=(window.PSSaveAll=Ar),vC=[{name:"Fichier",items:')
change('qa=o=>(o==null?void 0:o.split("/").pop())||"";', 'qa=o=>o?.startsWith("@pdf-preview:")?((o.slice(13).split("/").pop()||"Document").replace(/\\.tex$/i,".pdf")):((o==null?void 0:o.split("/").pop())||"");')
change('try{const Q=await ki("file?path="+encodeURIComponent(O));a(pe=>[...pe,{path:O,content:Q.content,saved:Q.content}]),c(O)}', 'try{const Q=/\\.(pdf|psnote)$/i.test(O)?{content:""}:await ki("file?path="+encodeURIComponent(O));a(pe=>[...pe,{path:O,content:Q.content,saved:Q.content}]),c(O)}')
change('Fa=async O=>{var Fe;if(!O||', 'Fa=async O=>{var Fe;if(O&&/\\.psnote$/i.test(O)&&window.PSNoteFlush)return await window.PSNoteFlush(O);if(!O||')
change('const Ar=async()=>{for(const O of Qi.current)', 'const Ar=async()=>{if(window.PSNotesFlushAll&&!await window.PSNotesFlushAll()){$("Enregistrement du document manuscrit impossible ; utilisez Copie .psnote.");return!1}for(const O of Qi.current)')
change('Pr=O=>{var Fe;let Q=Qi.current.find', 'Pr=async O=>{var Fe;if(/\\.psnote$/i.test(O)&&window.PSNoteBeforeClose&&!await window.PSNoteBeforeClose(O))return;let Q=Qi.current.find')
change('Un?V&&vr(Un.path)==="markdown"?', 'Un?/\\.(pdf|psnote)$/i.test(Un.path)||Un.path.startsWith("@pdf-preview:")?T.createElement("div",{className:"ps-document-host",key:Un.path,"data-path":Un.path}):V&&vr(Un.path)==="markdown"?')
change('O&&pe.pdfId&&window.PSOpenLatexPdf?.(pe.pdfId,Q)', '''O&&pe.pdfId&&(()=>{const docPath="@pdf-preview:"+Q;window.PSRegisterGeneratedPdf?.(pe.pdfId,Q);if(!Qi.current.some(x=>x.path===docPath)){const tabs=[...Qi.current,{path:docPath,content:"",saved:""}];Qi.current=tabs;a(tabs);c(docPath)}})()''')
change('["Nouveau fichier…","",()=>Oc("file")]', '["Nouveau document manuscrit…","",async()=>{let name=await Mn("Nom du document dans le projet (extension .psnote) :","notes.psnote");if(!name)return;if(!/\\.psnote$/i.test(name))name+=".psnote";try{await ki("handwriting/create",{path:name});await ml();await Oa(name)}catch(e){$(e.message);alert(e.message)}}],["Nouveau fichier…","",()=>Oc("file")]')
change('a([]),Qi.current=[],c(""),ot(""),Fi(!0)', 'window.PSNotesReset?.(),a([]),Qi.current=[],c(""),ot(""),Fi(!0)')
change('await ki("rename",{path:O,target:Q}),a(pe=>', 'await ki("rename",{path:O,target:Q}),window.PSNoteRenamed?.(O,Q),a(pe=>')
change('await ki("delete",{path:O});let pe=Qi.current.filter', 'if(window.PSNotesFlushAll&&!await window.PSNotesFlushAll())throw Error("Enregistrement d’un document manuscrit impossible.");await ki("delete",{path:O});window.PSNoteDeleted?.(O);let pe=Qi.current.filter')
change('const Q=/\\.csproj$/i.test(O)?"csharp":/\\.txt$/i.test(O)', 'const Q=/\\.pdf$/i.test(O)||O.startsWith("@pdf-preview:")?"pdf":/\\.psnote$/i.test(O)?"note":/\\.csproj$/i.test(O)?"csharp":/\\.txt$/i.test(O)')
change('Fe={latex:["TₑX","LaTeX"],textfile:', 'Fe={pdf:["PDF","PDF"],note:["✎","Document manuscrit"],latex:["TₑX","LaTeX"],textfile:')
p.write_text(s,encoding='utf8')
