#!/usr/bin/env python3
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit('Ancre non unique : '+str(n)+' '+repr(a[:140]))
 s=s.replace(a,b,1)
change('let latexBuild=[];if(pe.kind==="latex")latexBuild=', '''let pdfPublication=null;if(pe.kind==="latex"&&pe.ok&&pe.pdfId){try{if(!window.PSPublishPdf)throw Error("Fonction d’enregistrement PDF indisponible.");pdfPublication=await window.PSPublishPdf({kind:"latex",path:Q,id:pe.pdfId})}catch(error){pdfPublication={status:"error",message:error.message};alert("Le PDF a été compilé, mais n’a pas pu être enregistré à côté du .tex : "+error.message)}}let latexBuild=[];if(pe.kind==="latex")latexBuild=''' )
change('D(pe.output||""),R(pe.diagnostics||[]),setBuildDiag(pe.kind==="latex"?latexBuild:', '''D((pe.output||"")+(pdfPublication?.status==="saved"?"\\nPDF enregistré : "+pdfPublication.destination+(pdfPublication.warning?"\\n"+pdfPublication.warning:"")+"\\n":pdfPublication?.status==="cancelled"?"\\nPDF non enregistré : remplacement annulé.\\n":pdfPublication?.status==="error"?"\\nPDF non enregistré : "+pdfPublication.message+"\\n":"")),R(pe.diagnostics||[]),setBuildDiag(pe.kind==="latex"?latexBuild:''')
change('p("build"),$("PDF LaTeX généré dans le cache"),O&&pe.pdfId', 'p("build"),$(pdfPublication?.status==="saved"?"PDF enregistré : "+pdfPublication.destination:pdfPublication?.status==="cancelled"?"PDF non enregistré : remplacement annulé":"PDF non enregistré : "+(pdfPublication?.message||"erreur inconnue")),O&&pe.pdfId')
p.write_text(s,encoding='utf8')
