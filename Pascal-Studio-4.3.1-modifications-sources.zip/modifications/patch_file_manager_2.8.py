#!/usr/bin/env python3
"""Guarded patch for compiled 2.7.2 interface: file manager tab bridge."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit('Ancre non unique '+str(n)+' : '+repr(a[:100]))
 s=s.replace(a,b,1)
change('qa=o=>o?.startsWith("@pdf-preview:")?', 'qa=o=>o==="@file-manager"?"Gestionnaire de fichiers":o?.startsWith("@pdf-preview:")?')
change('const Q=/\\.(pdf|psnote)$/i.test(O)?{content:""}:await ki("file?path="+encodeURIComponent(O));', 'const Q=O==="@file-manager"||/\\.(pdf|psnote)$/i.test(O)?{content:""}:await ki("file?path="+encodeURIComponent(O));')
change('Un?/\\.(pdf|psnote)$/i.test(Un.path)||Un.path.startsWith("@pdf-preview:")?', 'Un?Un.path==="@file-manager"?T.createElement("div",{className:"psfm-host",key:Un.path}):/\\.(pdf|psnote)$/i.test(Un.path)||Un.path.startsWith("@pdf-preview:")?')
change('psRegisterSave=(window.PSSaveAll=Ar),vC=', '''psRegisterSave=(window.PSSaveAll=Ar,window.PSFMOpenManager=()=>Oa("@file-manager"),window.PSFMOpenTabs=()=>Qi.current.map(x=>x.path),window.PSFMWorkspace=()=>n?.workspace||"",window.PSFMActivate=entry=>{let path=entry.path;if(Qi.current.some(x=>x.path===path)){As.current=!0;c(path);return}let tabs=[...Qi.current,{path,content:entry.content||"",saved:entry.content||""}];Qi.current=tabs;As.current=!0;a(tabs);c(path)}),vC=''' )
change('["Ouvrir un fichier…","",()=>Tf(!1)],', '["Ouvrir un fichier…","",()=>Tf(!1)],["Gestionnaire de fichiers","",()=>Oa("@file-manager")],')
p.write_text(s,encoding='utf8')
