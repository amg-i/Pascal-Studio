"""Patch 3.2 compiled React bundle; each exact anchor is checked."""
from pathlib import Path
import json,sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def replace(old,new,count=1):
 global s
 n=s.count(old)
 if n!=count:raise SystemExit(f'Ancre non unique ({n}, attendu {count}) : {old[:160]}')
 s=s.replace(old,new,count)
names=['fortran','perl','basic','ocaml','lua'];js=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':'))
registrations=''.join('Vh({id:'+js(k)+',extensions:'+js(ext)+',aliases:['+js(label)+'],loader:()=>Tc(()=>import('+js('./'+k+'-studio.js')+'),[])});' for k,label,ext in [('fortran','Fortran',['.f','.for','.ftn','.f77','.f90','.f95','.f03','.f08','.fpp']),('perl','Perl',['.pl','.pm']),('basic','Yabasic',['.bas','.yab']),('ocaml','OCaml',['.ml','.mli']),('lua','Lua',['.lua'])])
replace('Vh({id:"rust",extensions:',registrations+'Vh({id:"rust",extensions:')
replace('/\\.rs$/i.test(e)?"rust":', '/\\.(f|for|ftn|f77|f90|f95|f03|f08|fpp)$/i.test(e)?"fortran":/\\.(pl|pm)$/i.test(e)?"perl":/\\.(bas|yab)$/i.test(e)?"basic":/\\.(ml|mli)$/i.test(e)?"ocaml":/\\.lua$/i.test(e)?"lua":/\\.rs$/i.test(e)?"rust":')
replace('mk|md|tex|py|rs|go|rb|js|mjs|cjs|html|htm|css|php)$/i.test(e)', 'mk|md|tex|py|rs|go|rb|f|for|ftn|f77|f90|f95|f03|f08|fpp|pl|pm|bas|yab|ml|mli|lua|js|mjs|cjs|html|htm|css|php)$/i.test(e)')
replace('oUe={latex:"LaTeX",rust:', 'oUe={fortran:"Fortran",perl:"Perl",basic:"Yabasic",ocaml:"OCaml",lua:"Lua",latex:"LaTeX",rust:')
replace('rust:["Rs","Rust"],go:', 'fortran:["F","Fortran"],perl:["Pl","Perl"],basic:["Ba","Yabasic"],ocaml:["Ml","OCaml"],lua:["Lua","Lua"],rust:["Rs","Rust"],go:')
replace('"php","html","css","rust","go","ruby"];for(const t of e)o.languages.registerCompletionItemProvider', '"php","html","css","rust","go","ruby","fortran","perl","basic","ocaml","lua"];for(const t of e)o.languages.registerCompletionItemProvider')
words={
'fortran':'program end module subroutine function contains implicit none integer real logical complex character parameter dimension allocatable pointer type use only if then else select case do while cycle exit call return stop allocate deallocate open close read write print format',
'perl':'use strict warnings my our state sub return if elsif else unless while until for foreach last next given when package require no eval die warn print say scalar map grep sort split join chomp',
'basic':'print input if then else endif end for to step next while wend repeat until do loop break continue dim local sub return import open close read data rem',
'ocaml':'let rec and in fun function match with type module struct sig end open include if then else try raise exception for to downto do done while begin mutable ref',
'lua':'and break do else elseif end false for function goto if in local nil not or repeat return then true until while'}
funcs={'fortran':['abs','sqrt','sin','cos','exp','log','max','min','sum','size','allocated','trim'],'perl':['print','say','chomp','length','substr','split','join','push','pop','shift','unshift','keys','values','map','grep','open','close'],'basic':['print','input','len','left$','right$','mid$','instr','str$','val','sqrt','sin','cos','open','close'],'ocaml':['print_endline','print_string','print_int','string_of_int','int_of_string','List.map','List.fold_left','Array.length','Option.map'],'lua':['print','type','tonumber','tostring','pairs','ipairs','require','pcall','error','assert','setmetatable']}
snips={'fortran':[['program','program ${1:nom}\n  implicit none\n  ${2:print *, "Bonjour !"}\nend program ${1:nom}','Programme Fortran']], 'perl':[['main','use strict;\nuse warnings;\n${1:print "Bonjour !\\n";}','Programme Perl']], 'basic':[['for','for ${1:i} = ${2:1} to ${3:10}\n  ${4:print i}\nnext ${1:i}','Boucle Yabasic']], 'ocaml':[['let','let ${1:nom} ${2:x} =\n  ${3:x}\n','Fonction OCaml']], 'lua':[['function','local function ${1:nom}(${2:x})\n  ${3:return x}\nend','Fonction Lua']]}
libs={'lua':{'string':['len','sub','format','find','gsub','upper','lower'],'table':['insert','remove','sort','concat'],'math':['abs','sqrt','sin','cos','random']},'ocaml':{'List':['map','iter','fold_left','length'],'Array':['map','iter','length'],'String':['length','sub','concat']}}
assign='Object.assign(eUe,'+js({k:v.split() for k,v in words.items()})+');Object.assign(Zie,'+js(funcs)+');Object.assign(tUe,'+js(snips)+');Object.assign(Xie,'+js(libs)+');'
replace('iUe(Mk);const ki=',assign+'iUe(Mk);const ki=')
replace('["pascal","c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby"].includes(vr(pe.path))', '["pascal","c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby","fortran","perl","basic","ocaml","lua"].includes(vr(pe.path))')
replace('["c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby","latex"].includes(St.getLanguageId())','["c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby","latex","fortran","perl","basic","ocaml","lua"].includes(St.getLanguageId())')
replace('["pascal","c","cpp","python","javascript","php","rust","go","ruby"].includes(vr(O))','["pascal","c","cpp","python","javascript","php","rust","go","ruby","fortran"].includes(vr(O))',2)
replace('Débogage disponible pour Pascal, C, C++, Rust, Go, Ruby, Python, JavaScript Node et PHP CLI.', 'Débogage disponible pour Pascal, C, C++, Fortran, Rust, Go, Ruby, Python, JavaScript Node et PHP CLI.')
replace('["c","cpp","python","javascript","php","ruby","rust","go"].includes(et)', '["c","cpp","python","javascript","php","ruby","rust","go","fortran","perl","basic","ocaml","lua"].includes(et)')
replace('et==="latex"?!0:et==="pascal"?n.fpc:', 'et==="latex"?!0:["fortran","perl","basic","ocaml","lua"].includes(et)?!!n[et]:et==="pascal"?n.fpc:')
replace('Vi(et==="pascal"?"Installez Free Pascal pour l’analyse":', 'Vi(["fortran","perl","basic","ocaml","lua"].includes(et)?"Installez l’outil du langage : voir le guide":et==="pascal"?"Installez Free Pascal pour l’analyse":')
replace('r.filter(pa=>["pascal","c","cpp","python","javascript","php","ruby","rust","go","latex"].includes(vr(pa.path)))', 'r.filter(pa=>["pascal","c","cpp","python","javascript","php","ruby","rust","go","latex","fortran","perl","basic","ocaml","lua"].includes(vr(pa.path)))')
replace('n==null?void 0:n.go,X,ys]', 'n==null?void 0:n.go,n==null?void 0:n.fortran,n==null?void 0:n.perl,n==null?void 0:n.basic,n==null?void 0:n.ocaml,n==null?void 0:n.lua,X,ys]')
replace('["go","rust"].includes(pe.kind)', '["go","rust","fortran","ocaml"].includes(pe.kind)')
replace('["go","rust"].includes(Q.kind)', '["go","rust","fortran"].includes(Q.kind)')
p.write_text(s,encoding='utf8')
