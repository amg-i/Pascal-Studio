#!/usr/bin/env python3
"""Apply specific focus, tree refresh and stop fixes to the 2.1 UI bundle.
The original React sources for 2.0/2.1 were not available; matches are guarded.
"""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def replace(old,new):
 global s
 count=s.count(old)
 if count!=1:raise SystemExit('Correspondance inattendue : '+repr(old[:120])+' : '+str(count))
 s=s.replace(old,new,1)
# Stop applies to either execution or debugging, and refresh both snapshots.
replace('Pc=async()=>{try{await ki("stop")}catch(O){$(O.message)}}',
        'Pc=async()=>{try{await ki("stop",{});let O=await Promise.all([ki("process"),ki("debug")]);F(O[0]),Sd(O[1]),$("Programme arrêté")}catch(O){$(O.message)}}')
replace('title:"Arrêter",onClick:Pc,disabled:!P.running',
        'title:"Arrêter",onClick:Pc,disabled:!P.running&&!yt.active')
# Mutating debug stop must use POST: omitting data selects GET in the API client.
replace('await ki("debug/stop"),Sd(await ki("debug"))', 'await ki("debug/stop",{}),Sd(await ki("debug"))')
# Closing the web preview must stop the server, not send a GET.
replace('await ki("web/stop")', 'await ki("web/stop",{})')
# Keep the tree in sync with changes made outside the application without
# touching open editor buffers or stealing the keyboard focus.
anchor='Ee.useEffect(()=>{Lu.current&&(Lu.current.scrollTop=Lu.current.scrollHeight)},[P.output,L,f]);const Oa=async O=>'
replacement='''Ee.useEffect(()=>{Lu.current&&(Lu.current.scrollTop=Lu.current.scrollHeight)},[P.output,L,f]);Ee.useEffect(()=>{if(!(n!=null&&n.workspace))return;let O=!0,Q=!1;const pe=async()=>{if(Q)return;Q=!0;try{const Fe=await ki("tree");O&&i(et=>JSON.stringify(et)===JSON.stringify(Fe.tree)?et:Fe.tree)}catch{}finally{Q=!1}};const Fe=setInterval(pe,3e3);return()=>{O=!1;clearInterval(Fe)}},[n==null?void 0:n.workspace]),Ee.useEffect(()=>{if(!As.current||!l||!$s.current||!$s.current.getDomNode()?.isConnected)return;As.current=!1;let O=!0;requestAnimationFrame(()=>requestAnimationFrame(()=>{var Q;O&&Ms.current===l&&((Q=$s.current)==null||Q.focus())}));return()=>{O=!1}},[l]);const Oa=async O=>'''
replace(anchor,replacement)
# The file creation dialog loses focus as it unmounts; focus the new model
# only after it has been made active. For a folder keep the existing editor.
replace('await ml(),O==="file"&&Oa(Q)}catch(pe){$(pe.message)}},Ld=async O=>',
        'await ml(),O==="file"?(As.current=!0,await Oa(Q)):requestAnimationFrame(()=>{var Fe;(Fe=$s.current)==null||Fe.focus()})}catch(pe){$(pe.message)}},Ld=async O=>')
# Deleting an active file switches to the next tab; deleting another file must
# return focus to the current editor as well.
old='a(pe),(l===O||l.startsWith(O+"/"))&&c(((Q=pe.at(-1))==null?void 0:Q.path)||""),(Ye===O||Ye.startsWith(O+"/"))&&ot(""),ml()'
new='Qi.current=pe,a(pe),(l===O||l.startsWith(O+"/"))?(As.current=pe.length>0,c(((Q=pe.at(-1))==null?void 0:Q.path)||"")):requestAnimationFrame(()=>{var Fe;(Fe=$s.current)==null||Fe.focus()}),(Ye===O||Ye.startsWith(O+"/"))&&ot(""),ml()'
replace(old,new)
p.write_text(s,encoding='utf8');print('Correctifs appliqués :',p)
