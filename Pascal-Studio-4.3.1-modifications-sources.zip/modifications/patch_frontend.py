#!/usr/bin/env python3
"""Patch narrowly identified debug gating in the compiled 2.0.0 UI.

The original React source for 2.0 is not available. Verify every match and
abort on another bundle; this is not a reconstruction of that source.
"""
import hashlib,sys
from pathlib import Path
p=Path(sys.argv[1]);s=p.read_text(encoding='utf-8')
replacements={
 'if(!O||!Q||!["pascal","c","cpp"].includes(vr(O)))return;':'if(!O||!Q||!["pascal","c","cpp","python","javascript","php"].includes(vr(O)))return;',
 'if(!O||!["pascal","c","cpp"].includes(vr(O)))':'if(!O||!["pascal","c","cpp","python","javascript","php"].includes(vr(O)))',
 'Débogage intégré disponible pour Pascal, C et C++ isolés ; pas encore pour Python, JavaScript, PHP ni C#.':'Débogage disponible pour Pascal, C, C++, Python, JavaScript Node et PHP CLI. Le débogage des pages web et de C# n’est pas intégré.',
 'Compilation pour le débogage…':'Préparation du débogage…',
}
for old,new in replacements.items():
 n=s.count(old)
 if n!=1:raise SystemExit(f'Correspondance inattendue ({n}) : {old}')
 s=s.replace(old,new)
p.write_text(s,encoding='utf-8')
print('Interface 2.0 corrigée :',p)
