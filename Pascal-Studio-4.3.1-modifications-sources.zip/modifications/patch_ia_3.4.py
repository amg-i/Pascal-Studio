from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
def patch(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit(f'ancre introuvable ou ambiguë : {n} {a[:80]}')
 s=s.replace(a,b,1)
patch('qa=o=>o==="@file-manager"?', 'qa=o=>o==="@assistant"?"Assistant IA":o==="@file-manager"?')
patch('const Q=O==="@file-manager"||', 'const Q=O==="@assistant"||O==="@file-manager"||')
patch('Un?Un.path==="@file-manager"?', 'Un?Un.path==="@assistant"?T.createElement("div",{className:"ps-ai-host",key:Un.path}):Un.path==="@file-manager"?')
patch('title:"Gestionnaire de fichiers et serveurs", "aria-label"', 'title:"Gestionnaire de fichiers et serveurs", "aria-label"')
patch('T.createElement("nav",{className:"activitybar"},T.createElement("button",{title:"Gestionnaire de fichiers et serveurs"', 'T.createElement("nav",{className:"activitybar"},T.createElement("button",{title:"Assistant IA local", "aria-label":"Assistant IA local",onClick:()=>Oa("@assistant")},"✦"),T.createElement("button",{title:"Gestionnaire de fichiers et serveurs"')
patch('window.PSFMOpenManager=()=>Oa("@file-manager"),', 'window.PSAIOpen=()=>Oa("@assistant"),window.PSFMOpenManager=()=>Oa("@file-manager"),')
p.write_text(s)
