#!/usr/bin/env python3
"""Pascal Studio 3.6.0 — identité Git par dépôt et connexions persistantes.

Correctif du bundle React compilé pour deux fonctionnalités dont le backend est
déjà en place :

* D4 — identité de commit liée au compte associé au dépôt. Le panneau Git dit
  d'où vient l'identité (compte, saisie manuelle, configuration globale) et
  propose de la poser ou de la retirer. Par défaut, Pascal Studio n'en pose
  aucune : c'est le serveur (git_identity.py) qui décide.
* D5 — connexions GitHub/GitLab conservées entre deux sessions. Le texte qui
  annonçait un jeton « conservé en mémoire jusqu'à la fermeture » est faux
  depuis account_store.py ; il est remplacé, et un panneau explique où les
  jetons chiffrés sont stockés et comment tout effacer.

Usage :
    python3 patch_identite_git_3.6.py CHEMIN/index-BA4XgQVD.js
    python3 patch_identite_git_3.6.py --verifier CHEMIN/index-BA4XgQVD.js

Idempotent. Chaque ancrage est vérifié avant toute écriture.
"""
import io
import sys

# --------------------------------------------------------------------------
# D4 — ligne d'identité du panneau Git.
#
# Avant : un seul lien « Identité : … » ouvrant deux invites texte, et un
# libellé qui mélange identité locale et configuration globale de Git.
# Après : l'identité locale effective avec sa provenance, plus deux actions
# qui appellent /api/git/identity-auto et /api/git/identity-clear. Le serveur
# renvoie un champ « output » repris par le panneau, donc l'utilisateur voit
# pourquoi une identité a été posée, conservée ou retirée.
# --------------------------------------------------------------------------
ANCRE_IDENTITE = ('T.createElement("button",{className:"git-link",onClick:a},"Identité : ",'
                  'o.name&&o.email?o.name+" · "+o.email:"à configurer"),')

NOUVELLE_IDENTITE = (
    'T.createElement("div",{className:"git-identity-row"},'
    'T.createElement("button",{className:"git-link",onClick:a,'
    'title:"Saisir le nom et l’adresse e-mail utilisés pour les commits de ce dépôt"},'
    '"Identité : ",'
    'o.identity&&o.identity.localName&&o.identity.localEmail'
    '?o.identity.localName+" · "+o.identity.localEmail'
    '+(o.identity.source==="auto"'
    '?" (compte "+((o.identity.account||{}).login||"associé")+")"'
    ':" (saisie manuelle)")'
    ':o.name&&o.email?o.name+" · "+o.email+" (configuration globale de Git)":"aucune"),'
    'o.repo?T.createElement("button",{className:"git-link",'
    'onClick:()=>s("identity-auto",{account:w||null}),'
    'title:w'
    '?"Poser sur ce dépôt l’identité du compte sélectionné ci-dessus"'
    ':"Reprendre l’identité du compte GitHub ou GitLab associé à ce dépôt. '
    'Sans compte associé, aucune identité n’est posée."},'
    'w?"Identité de ce compte":"Identité du compte du dépôt"):null,'
    'o.identity&&o.identity.source!=="none"'
    '?T.createElement("button",{className:"git-link",'
    'onClick:()=>s("identity-clear",{}),'
    'title:"Retirer l’identité locale de ce dépôt. '
    'La configuration globale de Git n’est pas modifiée."},"Retirer"):null),'
)

# --------------------------------------------------------------------------
# D5 — persistance des connexions.
# --------------------------------------------------------------------------
ANCRE_JETON = 'T.createElement("p",null,"Le jeton est conservé en mémoire jusqu’à la fermeture."),'

NOUVEAU_JETON = (
    'T.createElement("p",null,"Le jeton est chiffré puis conservé sur ce PC : '
    'la connexion survive à la fermeture de Pascal Studio. '
    '« Déconnecter » le supprime définitivement."),'
)

ANCRE_COMPTE_ACTIF = 'T.createElement("label",null,"Compte actif",'

# Libellé de la liste déroulante : distingue un compte conservé d'un compte
# qui ne survivra pas à la fermeture (persistance désactivée par l'utilisateur).
ANCRE_OPTIONS = ('o.map(Ce=>T.createElement("option",{key:Ce.id,value:Ce.id},'
                 'Ce.provider," · ",Ce.login))')
NOUVELLES_OPTIONS = ('o.map(Ce=>T.createElement("option",{key:Ce.id,value:Ce.id},'
                     'Ce.provider," · ",Ce.login,Ce.persisted?"":" (session)"))')

PANNEAU_PERSISTANCE = (
    'T.createElement("details",{className:"ps-persist"},'
    'T.createElement("summary",null,"Connexions conservées sur ce PC"),'
    'T.createElement("p",null,"Chaque connexion GitHub ou GitLab est chiffrée puis '
    'enregistrée dans ",T.createElement("code",null,"~/.config/pascal-studio/"),'
    '", avec une clé propre à votre session utilisateur. Elle est rechargée au '
    'démarrage : inutile de se reconnecter après une fermeture. '
    '« Déconnecter » supprime un compte et son enregistrement."),'
    'T.createElement("button",{disabled:D,onClick:async()=>{'
    'if(!confirm("Effacer toutes les connexions conservées sur ce PC ? '
    'Les comptes seront aussi oubliés de cette session."))return;'
    'I(!0);try{await te({action:"persist-purge"}),t(""),await i(),L("")}'
    'catch(Ce){L(Ce.message)}finally{I(!1)}}},'
    '"Ne plus rien conserver sur ce PC")),'
)

EDITS = [
    ("panneau Git : identité et sa provenance", ANCRE_IDENTITE, NOUVELLE_IDENTITE, 1),
    ("comptes : texte sur le jeton personnel", ANCRE_JETON, NOUVEAU_JETON, 1),
    ("comptes : liste déroulante", ANCRE_OPTIONS, NOUVELLES_OPTIONS, 1),
    ("comptes : panneau de persistance", ANCRE_COMPTE_ACTIF,
     PANNEAU_PERSISTANCE + ANCRE_COMPTE_ACTIF, 1),
]

# Marque d'un bundle déjà corrigé : le script ne retouche alors rien.
GARDE = 'className:"git-identity-row"'


def corriger(source):
    if GARDE in source:
        return source, 0, True
    modifie = 0
    for titre, ancien, nouveau, attendu in EDITS:
        trouve = source.count(ancien)
        if trouve != attendu:
            raise ValueError(
                "Ancrage introuvable ou ambigu — %s : trouvé %d fois, attendu %d.\n"
                "Le bundle a probablement changé de version ; aucune modification "
                "n'a été écrite." % (titre, trouve, attendu))
        source = source.replace(ancien, nouveau)
        modifie += 1
    return source, modifie, False


def verifier(source):
    manquants = []
    for titre, texte in [
        ("ligne d'identité", 'className:"git-identity-row"'),
        ("provenance locale", 'o.identity.source==="auto"'),
        ("configuration globale annoncée", '" (configuration globale de Git)"'),
        ("action identity-auto", 's("identity-auto",{account:w||null})'),
        ("action identity-clear", 's("identity-clear",{})'),
        ("compte du dépôt", '"Identité du compte du dépôt"'),
        ("texte jeton mis à jour", 'survive à la fermeture'),
        ("panneau de persistance", 'className:"ps-persist"'),
        ("action persist-purge", 'action:"persist-purge"'),
        ("session marquée", 'Ce.persisted?"":" (session)"'),
    ]:
        if texte not in source:
            manquants.append(titre)
    if 'conservé en mémoire jusqu’à la fermeture' in source:
        manquants.append("ancien texte sur le jeton encore présent")
    return manquants


def main(argv):
    verifier_seul = False
    if argv and argv[0] == "--verifier":
        verifier_seul = True
        argv = argv[1:]
    if len(argv) != 1:
        sys.stderr.write(__doc__)
        return 2
    chemin = argv[0]
    with io.open(chemin, encoding="utf8") as f:
        source = f.read()
    taille_avant = len(source)

    if verifier_seul:
        manquants = verifier(source)
        if manquants:
            print("INCOMPLET : %s" % ", ".join(manquants))
            return 1
        print("Identité Git et persistance en place (%d caractères)." % taille_avant)
        return 0

    try:
        resultat, nb, deja = corriger(source)
    except ValueError as erreur:
        sys.stderr.write("ERREUR : %s\n" % erreur)
        return 1
    if deja:
        print("Bundle déjà corrigé, rien à faire (%d caractères)." % taille_avant)
        return 0
    manquants = verifier(resultat)
    if manquants:
        sys.stderr.write("ERREUR : contrôle final incomplet — %s\n" % ", ".join(manquants))
        return 1
    with io.open(chemin, "w", encoding="utf8") as f:
        f.write(resultat)
    print("%d ancrages appliqués : %d -> %d caractères (+%d)."
          % (nb, taille_avant, len(resultat), len(resultat) - taille_avant))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
