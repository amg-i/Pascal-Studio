#!/usr/bin/env python3
"""Patches du bundle pour la 3.8.0 : les dix langages ésotériques dans l'éditeur.

Le bundle (assets/index-*.js) est minifié : on ne le réécrit pas, on remplace des
chaînes repérées par leur contenu. Chaque remplacement est vérifié avant d'être
écrit, et l'écriture est atomique : si une seule ancre manque, rien n'est
modifié. Ce script suppose la 3.7.0 déjà appliquée (patch_interface_3.7.py) :
ses ancres sont les listes à 29 et 27 entrées que ce patcheur a produites.

Pourquoi huit changements et non deux.

Le bundle résout un langage de DEUX façons différentes, et les dix nouveaux
n'étaient reconnus par aucune :

  * `vr(chemin)` — une chaîne de ternaires qui déduit l'identifiant de langage
    du NOM DU FICHIER, avec "plaintext" en repli. C'est elle que lisent les deux
    listes d'autorisation du débogage, le filtre des points d'arrêt, l'icône de
    l'arbre, le libellé de la barre d'état, et — c'est le plus important — la
    propriété `language:` passée à Monaco. Tant qu'elle rend "plaintext" pour un
    .bf, rien de tout cela ne peut viser les langages ésotériques.
  * `St.getLanguageId()` — l'identifiant Monaco du modèle ouvert, qui ne vaut que
    ce que `vr()` a donné. D'où l'ordre des changements : élargir `vr()` d'abord,
    puis les listes qui comparent ses résultats.

Élargir `vr()` a une conséquence qu'il faut assumer : Monaco reçoit alors des
identifiants qu'il ne connaît pas ("brainfuck", "piet"…). Le changement E les
enregistre auprès de `monaco.languages`, dans une boucle gardée par try/catch,
au seul endroit du bundle où l'espace de noms Monaco est porté par un paramètre
(`iUe(o)`). Sans enregistrement, Monaco retombe sur une configuration par
défaut ; avec, les fournisseurs de complétion enregistrés pour ces identifiants
sont réellement consultés.

Les huit changements :

  A. `vr()`          les dix extensions sont reconnues, avant le repli
                     "plaintext". Aucune n'était revendiquée par une règle
                     antérieure (vérifié sur la chaîne complète).
  B. `MN()`          les dix extensions comptent comme fichiers SOURCE. Sans
                     cela, Exécuter et Compiler répondent « Choisissez un fichier
                     source ou un document pris en charge. »
  C. `oUe`           les dix libellés français de la barre d'état, avec les
                     libellés du registre (LOLCODE, ArnoldC, INTERCAL…).
  D. `Fe`            les dix badges d'icône de l'arbre des fichiers. La table
                     retombe déjà proprement sur un identifiant inconnu, ce
                     changement est donc cosmétique — mais un fichier sans badge
                     donne l'impression d'un langage non reconnu.
  E. enregistrement  les dix identifiants auprès de monaco.languages.
  F. complétion      la boucle qui enregistre un fournisseur adossé à
                     /api/completion passe de 29 à 39 identifiants. Le
                     fournisseur sait déjà convertir les CompletionItem du
                     protocole, et bibliotheques_completion.py contient les dix
                     bibliothèques (37 au total).
  G. préchauffage    la liste qui déclenche /api/completion sur frappe passe de
                     29 à 39 identifiants.
  H. débogage        les DEUX listes d'autorisation passent de 27 à 37 entrées.
                     Elles contiennent aussi les langages à rendu (latex, html,
                     css, svg, markdown, xml) : pour ceux-là le serveur répond
                     par un message qui oriente vers l'inspecteur visuel, ce qui
                     vaut mieux qu'un bouton absent sans explication. Piet fait
                     partie des langages à rendu ET possède un vrai moteur à pas
                     : le serveur le traite avant la garde « visuel ».

Deux listes voisines sont volontairement LAISSÉES À L'ÉCART :

  * le filtre des tampons envoyés à /api/analyze et /api/todos/live. Il ne
    concerne que les AUTRES fichiers ouverts pendant qu'un fichier est analysé.
    Un programme ésotérique est autonome, il ne référence aucun autre fichier ;
    et un « TODO » dans du Brainfuck n'est pas un commentaire mais du code
    exécutable — le langage n'a aucune syntaxe de commentaire. Les inclure
    produirait du bruit, pas de l'information.
  * la table de mots-clefs locale `iUe` (22 langages), qui est un repli sans
    serveur. Les dix langages passent par /api/completion, qui rend les
    bibliothèques complètes ; dupliquer ces tables dans le bundle les ferait
    diverger de bibliotheques_completion.py.

Conséquence à connaître : une image .png du projet est vue comme un programme
Piet, conformément au choix « le programme EST un PNG ». Le bundle n'a de toute
façon aucune branche d'aperçu image — les quatorze occurrences de « png » qu'il
contient sont toutes dans des textes d'aide — donc rien n'est retiré aux photos.
Côté serveur, les couleurs hors palette d'une photo produisent des AVIS et non
des erreurs, et seulement si le fichier est ouvert.

Usage, les deux ordres étant reconnus :
    python3 patch_interface_3.8.py --verifier CHEMIN_DU_BUNDLE
    python3 patch_interface_3.8.py CHEMIN_DU_BUNDLE --verifier
    python3 patch_interface_3.8.py CHEMIN_DU_BUNDLE
"""

import io
import os
import sys
import tempfile

# Les dix langages ésotériques, avec l'extension que le registre leur donne et le
# libellé affiché. L'ordre est celui de langages_esoteriques.ORDRE_ESOTERIQUES.
ESOTERIQUES = [
    ('brainfuck', ('bf', 'b'), 'Brainfuck', 'BF'),
    ('whitespace', ('ws',), 'Whitespace', 'WS'),
    ('piet', ('png',), 'Piet', 'Pi'),
    ('lolcode', ('lol',), 'LOLCODE', 'LOL'),
    ('arnoldc', ('arnoldc',), 'ArnoldC', 'AC'),
    ('chef', ('chef',), 'Chef', 'Ch'),
    ('shakespeare', ('spl',), 'Shakespeare', 'SPL'),
    ('intercal', ('i',), 'INTERCAL', 'INT'),
    ('fractran', ('fra',), 'FRACTRAN', 'FRA'),
    ('malbolge', ('mal',), 'Malbolge', 'MAL'),
]

IDENTIFIANTS = [e[0] for e in ESOTERIQUES]

# Listes héritées de la 3.7.0, conservées telles quelles et complétées des dix.
# « shell » et « shellscript » figurent tous les deux dans la liste d'origine :
# le premier est l'identifiant du registre, le second celui de Monaco. Les garder
# évite de retirer une reconnaissance qui fonctionne.
COMPLETION_37 = [
    'pascal', 'c', 'cpp', 'csharp', 'makefile', 'cmake', 'latex', 'rust', 'go',
    'ruby', 'python', 'javascript', 'php', 'html', 'css', 'svg', 'markdown',
    'shell', 'shellscript', 'swift', 'kotlin', 'perl', 'basic', 'fortran',
    'lua', 'ocaml', 'json', 'xml', 'plaintext',
]

DEBOGAGE_37 = [
    'pascal', 'c', 'cpp', 'csharp', 'makefile', 'cmake', 'latex', 'rust', 'go',
    'ruby', 'python', 'javascript', 'php', 'html', 'css', 'svg', 'markdown',
    'shell', 'shellscript', 'swift', 'kotlin', 'perl', 'basic', 'fortran',
    'lua', 'ocaml', 'xml',
]

LANGAGES_COMPLETION = COMPLETION_37 + IDENTIFIANTS
LANGAGES_DEBOGAGE = DEBOGAGE_37 + IDENTIFIANTS

# --- ancres, telles que la 3.7.0 les a laissées dans le bundle ----------------

ANCIENNE_CHAINE_VR = '/\\.md$/i.test(e)?"markdown":"plaintext"}'
ANCIENNES_EXTENSIONS_MN = '|css|php)$/i.test(e)'
ANCIENS_LIBELLES = 'markdown:"Markdown",xml:"XML",plaintext:"Texte"}'
ANCIENNES_ICONES = 'markdown:["M↓","Markdown"]}[Q]'
ANCIENNE_ENTETE_MONACO = 'function iUe(o){const e=["pascal"'

# L'aperçu web : la liste des langages dont le bouton ouvre la page servie par
# web_preview.py. Piet doit y figurer, sinon son programme — un PNG — partirait
# vers la compilation au lieu de s'afficher avec l'inspecteur visuel par-dessus.
# Ancre unique dans le bundle (une seule occurrence vérifiée).
ANCIEN_APERCU_WEB = '["html","css","php"]'
NOUVEL_APERCU_WEB = '["html","css","php","piet"]'

# Attention à la précédence : « '…%s…' % '[' + x + ']' » se lit
# (« '…%s…' % '[' ») + x + ']' , car % se lie plus fort que +. Les parenthèses
# sont obligatoires, et leur absence produisait des ancres tronquées.
ANCIENNE_BOUCLE_COMPLETION = (
    'for(const t of%s)o.languages.registerCompletionItemProvider'
    % ('[' + ','.join('"%s"' % n for n in COMPLETION_37) + ']'))
ANCIEN_PRECHAUFFAGE = (
    'St&&%s.includes(St.getLanguageId())&&fetch("/api/completion"'
    % ('[' + ','.join('"%s"' % n for n in COMPLETION_37) + ']'))
ANCIENNE_LISTE_DEBOGAGE = (
    '%s.includes(vr('
    % ('[' + ','.join('"%s"' % n for n in DEBOGAGE_37) + ']'))

MARQUEUR = 'ps-3.8.0-interface'


def liste(noms):
    return '[' + ','.join('"%s"' % n for n in noms) + ']'


def chaine_vr():
    """Les dix tests d'extension, dans l'ordre du registre, avant le repli.

    .bf est testé avant .b : la regex est ancrée par $, donc l'ordre n'est pas
    strictement nécessaire, mais il rend la chaîne lisible et évite qu'une
    modification ultérieure de l'ancrage ne change le résultat.
    """
    morceaux = []
    for identifiant, extensions, _libelle, _badge in ESOTERIQUES:
        morceaux.append('/\\.(%s)$/i.test(e)?"%s"'
                        % ('|'.join(extensions), identifiant))
    return ':'.join(morceaux) + ':"plaintext"}'


def extensions_mn():
    """Les dix extensions dans le groupe déjà présent, sans le réécrire."""
    return '|css|php|%s)$/i.test(e)' % '|'.join(
        ext for _i, extensions, _l, _b in ESOTERIQUES for ext in extensions)


def libelles():
    return ('markdown:"Markdown",xml:"XML",'
            + ','.join('%s:"%s"' % (i, l) for i, _e, l, _b in ESOTERIQUES)
            + ',plaintext:"Texte"}')


def icones():
    return ('markdown:["M↓","Markdown"],'
            + ','.join('%s:["%s","%s"]' % (i, b, l)
                       for i, _e, l, b in ESOTERIQUES)
            + '}[Q]')


def enregistrement_monaco():
    # Une seule instruction dans le corps du for, donc pas d'accolades : le
    # try/catch suffit, et il faut que l'échec d'un enregistrement (identifiant
    # déjà connu) n'empêche pas les suivants.
    return ('function iUe(o){for(const t of%s)try{o.languages.register({id:t})}'
            'catch(n){}const e=["pascal"' % liste(IDENTIFIANTS))


def substitutions():
    """Les remplacements à effectuer, avec le nombre attendu d'occurrences."""
    return [
        (ANCIENNE_CHAINE_VR,
         '/\\.md$/i.test(e)?"markdown":' + chaine_vr(), 1),
        (ANCIENNES_EXTENSIONS_MN, extensions_mn(), 1),
        (ANCIENS_LIBELLES, libelles(), 1),
        (ANCIENNES_ICONES, icones(), 1),
        (ANCIENNE_ENTETE_MONACO, enregistrement_monaco(), 1),
        (ANCIENNE_BOUCLE_COMPLETION,
         'for(const t of%s)o.languages.registerCompletionItemProvider'
         % liste(LANGAGES_COMPLETION), 1),
        (ANCIEN_PRECHAUFFAGE,
         'St&&%s.includes(St.getLanguageId())&&fetch("/api/completion"'
         % liste(LANGAGES_COMPLETION), 1),
        (ANCIENNE_LISTE_DEBOGAGE,
         '%s.includes(vr(' % liste(LANGAGES_DEBOGAGE), 2),
        (ANCIEN_APERCU_WEB, NOUVEL_APERCU_WEB, 1),
    ]


def deja_applique(texte):
    # Le marqueur est ajouté en fin de fichier ; le libellé de Malbolge est le
    # dernier des dix, donc s'il est là, la table des libellés a été étendue.
    return MARQUEUR in texte or 'malbolge:"Malbolge"' in texte


def verifier(chemin):
    """Contrôle le bundle sans rien écrire. Renvoie (ok, rapport)."""
    with io.open(chemin, encoding='utf8') as fichier:
        texte = fichier.read()
    lignes = []
    if deja_applique(texte):
        lignes.append('  déjà patché : %s' % chemin)
        manques = [a for a, _, _ in substitutions() if a in texte]
        if manques:
            lignes.append('  ATTENTION : %d ancienne(s) ancre(s) encore '
                          'présente(s)' % len(manques))
            return False, lignes
        # Chaque changement laisse une trace vérifiable dans le bundle.
        traces = (
            ('résolution des extensions (vr)',
             '/\\.(bf|b)$/i.test(e)?"brainfuck"'),
            ('fichiers source (MN)', '|css|php|bf|b|ws|png|'),
            ('libellés de la barre d’état', 'malbolge:"Malbolge"'),
            ('badges de l’arbre des fichiers', 'malbolge:["MAL","Malbolge"]'),
            ('enregistrement auprès de Monaco',
             'o.languages.register({id:t})'),
            ('aperçu web ouvert pour Piet', NOUVEL_APERCU_WEB),
        )
        for nom, trace in traces:
            lignes.append('  %-36s %s'
                          % (nom, 'présent' if trace in texte else 'ABSENT'))
            if trace not in texte:
                return False, lignes
        # Les listes sont reconnues par leur PRÉFIXE, sans le crochet fermant,
        # et les comptes sont MESURÉS dans le bundle au lieu d'être récités
        # depuis les constantes de ce script.
        #
        # Pourquoi : une version ultérieure qui ajoute un langage allonge ces
        # listes sans les réécrire. La 4.0.0 y a ajouté l'assembleur, et exiger
        # la liste exacte de la 3.8.0 faisait alors échouer ce vérificateur sur
        # un bundle CORRECTEMENT patché. Un contrôle qui échoue à tort apprend à
        # ignorer les contrôles — c'est le défaut qui avait déjà rendu muets les
        # deux bancs de l'installateur en 3.9.0.
        #
        # Le préfixe reste exigeant : il impose les 39 (puis 40) noms dans
        # l'ordre, donc un retrait, un renommage ou une permutation échouent.
        prefixe_completion = liste(LANGAGES_COMPLETION)[:-1]
        prefixe_debogage = liste(LANGAGES_DEBOGAGE)[:-1]
        completions = texte.count(prefixe_completion)
        lignes.append('  %-36s %d liste(s), préfixe de %d langages'
                      % ('complétion (/api/completion)', completions,
                         len(LANGAGES_COMPLETION)))
        if completions != 2:
            lignes.append('  ATTENTION : attendu 2 listes de complétion '
                          '(boucle d’enregistrement et préchauffage).')
            return False, lignes
        debogage = texte.count(prefixe_debogage)
        lignes.append('  %-36s %d liste(s), préfixe de %d langages'
                      % ('débogage', debogage, len(LANGAGES_DEBOGAGE)))
        if debogage != 2:
            lignes.append('  ATTENTION : attendu 2 listes de débogage.')
            return False, lignes
        return True, lignes
    manquantes = [(a, n) for a, _, n in substitutions() if texte.count(a) != n]
    if manquantes:
        for ancre, attendu in manquantes:
            lignes.append('  ANCRE INTROUVABLE (%d/%d) : %s'
                          % (texte.count(ancre), attendu, ancre[:70]))
        if 'ps-3.7.0-interface' not in texte:
            lignes.append('  Le bundle ne porte pas le marqueur de la 3.7.0 : '
                          'appliquez d’abord patch_interface_3.7.py.')
        return False, lignes
    lignes.append('  toutes les ancres sont présentes et non patchées')
    return False, lignes


def appliquer(chemin):
    with io.open(chemin, encoding='utf8') as fichier:
        texte = fichier.read()
    original = texte
    if deja_applique(texte):
        print('  déjà patché, rien à faire : %s' % chemin)
        return True
    # Tout est vérifié AVANT d'écrire : une ancre absente ne doit rien modifier.
    for ancre, remplacement, attendu in substitutions():
        trouve = texte.count(ancre)
        if trouve != attendu:
            raise SystemExit('Ancre %r trouvée %d fois, attendu %d. '
                             'Aucune modification écrite.'
                             % (ancre[:60], trouve, attendu))
    for ancre, remplacement, _ in substitutions():
        texte = texte.replace(ancre, remplacement)
    if texte == original:
        raise SystemExit('Aucun changement produit : abandon.')
    # Écriture atomique, à côté du fichier puis renommage. Le marqueur est ajouté
    # tout à la fin du fichier : un commentaire placé avant une accolade fermante
    # casserait le bundle minifié.
    dossier = os.path.dirname(os.path.abspath(chemin)) or '.'
    descripteur, temporaire = tempfile.mkstemp(dir=dossier, suffix='.tmp')
    # mkstemp crée en 0600 et os.replace conserve ce mode : sans cette
    # restitution, le bundle patché n'est plus lisible que par son propriétaire,
    # ce qui casse l'AppImage une fois reconditionnée.
    droits = os.stat(chemin).st_mode
    try:
        with io.open(descripteur, 'w', encoding='utf8') as fichier:
            fichier.write(texte)
            fichier.write('\n/* %s */\n' % MARQUEUR)
        os.replace(temporaire, chemin)
        os.chmod(chemin, droits)
    except BaseException:
        try:
            os.unlink(temporaire)
        except OSError:
            pass
        raise
    print('  %d remplacements appliqués à %s' % (len(substitutions()), chemin))
    print('    extensions reconnues : %d (%s)'
          % (sum(len(e) for _i, e, _l, _b in ESOTERIQUES),
             ' '.join('.' + x for _i, e, _l, _b in ESOTERIQUES for x in e)))
    print('    complétion  : %d langages' % len(LANGAGES_COMPLETION))
    print('    débogage    : %d langages (2 listes)' % len(LANGAGES_DEBOGAGE))
    print('    taille      : %d -> %d caractères' % (len(original), len(texte)))
    return True


def main(argv):
    # Les autres correctifs du projet s'appellent « patch_x.py --verifier BUNDLE ».
    # Les deux ordres sont reconnus, comme pour patch_interface_3.7.py.
    drapeaux = [a for a in argv[1:] if a.startswith('-')]
    chemins = [a for a in argv[1:] if not a.startswith('-')]
    if len(chemins) != 1:
        print(__doc__)
        return 2
    chemin = chemins[0]
    if not os.path.isfile(chemin):
        print('Fichier introuvable : %s' % chemin)
        return 2
    if '--verifier' in drapeaux:
        ok, rapport = verifier(chemin)
        for ligne in rapport:
            print(ligne)
        return 0 if ok else 1
    appliquer(chemin)
    ok, rapport = verifier(chemin)
    for ligne in rapport:
        print(ligne)
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv))
