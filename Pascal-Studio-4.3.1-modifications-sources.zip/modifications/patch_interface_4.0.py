#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
patch_interface_4.0.py — les changements d'interface de la 4.0.0.

Deux ensembles de substitutions, tous deux ancrés et vérifiés :

  * l'assembleur x86-64 comme langage de l'éditeur (A à H) ;
  * l'éditeur de données en ONGLET, à la place de la modale plein écran (I et J).

    python3 patch_interface_4.0.py CHEMIN/index-*.js      applique
    python3 patch_interface_4.0.py --verifier CHEMIN      contrôle sans écrire

Le frontend n'est livré que sous forme d'un bundle minifié : aucune source
React n'est recompilable. Les changements passent donc par des remplacements
ancrés, comme aux 3.6.0, 3.7.0 et 3.8.0. Chaque ancre doit être présente un
nombre de fois exactement prévu ; sinon le script s'arrête sans rien écrire et
nomme l'ancre en cause.

DIX remplacements, dans l'ordre où l'interface les emploie :

  A. la résolution d'extension `vr()` — sans elle, ouvrir un .asm donne
     « plaintext » : ni coloration, ni complétion, ni analyse ;
  B. le groupe d'extensions qui décide si un fichier est un source du projet —
     sans elle, les .asm et .s seraient traités comme des fichiers binaires ;
  C. la table des libellés affichés ;
  D. la table des badges de l'arborescence ;
  E. la liste des langages de complétion — sans elle, le moteur n'est jamais
     interrogé pour l'assembleur ;
  F. la liste du préchauffage de la complétion à l'ouverture d'un onglet ;
  G. les DEUX listes qui décident si le bouton de débogage est proposé ;
  H. l'enregistrement Monaco du langage avec son tokenizer, chargé depuis
     asm-studio.js — c'est ce qui donne la coloration syntaxique.

L'assembleur n'est PAS ajouté à la liste `iUe` des langages enregistrés sans
tokenizer (les dix langages ésotériques) : il a le sien, donc il passe par
`Vh(...)` avec un chargeur, comme Fortran, Lua ou Rust. L'ajouter aux deux
endroits ferait un double enregistrement, ignoré en silence par le try/catch,
mais dont l'ordre déciderait du tokenizer finalement retenu.

Les extensions .s et .S sont couvertes par un seul test : la regex porte le
drapeau `i`. Aucun conflit d'extension n'existe avec les vingt langages déjà
enregistrés par `Vh`, ce qui a été vérifié avant d'écrire ce correctif.
"""

import io
import sys

MARQUEUR = 'ps-4.0.0-interface'

IDENTIFIANT = 'asm'
LIBELLE = 'Assembleur'
BADGE = 'ASM'
EXTENSIONS = ('asm', 's', 'nasm')          # « S » couvert par le drapeau i
ALIASES = ('Assembleur', 'Assembly', 'x86-64', 'asm')

# Listes héritées de la 3.8.0 : les trente de la 3.7.0 plus les dix langages
# ésotériques. Elles sont recopiées ici et non importées du correctif précédent,
# parce que ce script doit pouvoir s'appliquer seul, sur une base 3.8.0, sans
# que patch_interface_3.8.py soit exécutable.
COMPLETION_38 = [
    'pascal', 'c', 'cpp', 'csharp', 'makefile', 'cmake', 'latex', 'rust', 'go',
    'ruby', 'python', 'javascript', 'php', 'html', 'css', 'svg', 'markdown',
    'shell', 'shellscript', 'swift', 'kotlin', 'perl', 'basic', 'fortran',
    'lua', 'ocaml', 'json', 'xml', 'plaintext',
    'brainfuck', 'whitespace', 'piet', 'lolcode', 'arnoldc', 'chef',
    'shakespeare', 'intercal', 'fractran', 'malbolge',
]

DEBOGAGE_38 = [
    'pascal', 'c', 'cpp', 'csharp', 'makefile', 'cmake', 'latex', 'rust', 'go',
    'ruby', 'python', 'javascript', 'php', 'html', 'css', 'svg', 'markdown',
    'shell', 'shellscript', 'swift', 'kotlin', 'perl', 'basic', 'fortran',
    'lua', 'ocaml', 'xml',
    'brainfuck', 'whitespace', 'piet', 'lolcode', 'arnoldc', 'chef',
    'shakespeare', 'intercal', 'fractran', 'malbolge',
]

COMPLETION_40 = COMPLETION_38 + [IDENTIFIANT]
DEBOGAGE_40 = DEBOGAGE_38 + [IDENTIFIANT]


def liste(noms):
    return '[' + ','.join('"%s"' % n for n in noms) + ']'


# --- ancres, telles que la 3.8.0 les a laissées dans le bundle ---------------

ANCIENNE_FIN_VR = 'malbolge":"plaintext"}'
ANCIEN_GROUPE_EXTENSIONS = '|fra|mal)$/i.test(e)'
ANCIENS_LIBELLES = 'malbolge:"Malbolge",plaintext:"Texte"}'
ANCIENNES_ICONES = 'malbolge:["MAL","Malbolge"]}[Q]'
ANCIENNE_BOUCLE_COMPLETION = (
    'for(const t of%s)o.languages.registerCompletionItemProvider'
    % liste(COMPLETION_38))
ANCIEN_PRECHAUFFAGE = (
    'St&&%s.includes(St.getLanguageId())&&fetch("/api/completion"'
    % liste(COMPLETION_38))
ANCIENNE_LISTE_DEBOGAGE = '%s.includes(vr(' % liste(DEBOGAGE_38)
ANCIEN_ENREGISTREMENT = (
    'Vh({id:"ruby",extensions:[".rb"],aliases:["Ruby","ruby"],'
    'loader:()=>Tc(()=>import("./ruby-studio.js"),[])});')

# --- éditeur de données en onglet -------------------------------------------
#
# Le bundle délègue déjà trois vues à des scripts hôtes : l'assistant
# (.ps-ai-host), le gestionnaire de fichiers (.psfm-host) et les documents
# (.ps-document-host, porteur de data-path). Dans les trois cas il crée un
# élément VIDE, et le script hôte l'observe puis y rend son interface. C'est le
# mécanisme repris ici avec .ps-data-host : aucune réinvention, et un précédent
# qui prouve que l'architecture le prévoit.
#
# Deux substitutions sont nécessaires et suffisent :
#   I. l'ouverture du fichier ne doit PAS charger son contenu comme du texte —
#      un .sqlite de 500 Mo deviendrait une chaîne dans Monaco ;
#   J. la zone d'édition doit rendre l'hôte au lieu de Monaco.
#
# Formats délégués : ceux que Monaco rend mal ou pas du tout — bases SQLite,
# CSV et TSV tabulaires, scripts SQL, et classeurs XLSX et ODS binaires.
# JSON et XML NE SONT PAS délégués : ce sont des formats texte pour lesquels
# Monaco apporte coloration, repli et recherche, et les remplacer ferait perdre
# tout cela. Leur éditeur de données reste accessible d'un clic par la barre
# d'activités, et s'ouvre alors dans un onglet lui aussi. Ce choix est assumé et
# documenté plutôt que silencieux.
EXTENSIONS_DONNEES = ('sqlite3?', 'db3?', 'csv', 'tsv', 'sql', 'xlsx', 'ods')
REGEX_DONNEES = r'/\.(?:%s)$/i' % '|'.join(EXTENSIONS_DONNEES)

ANCIENNE_OUVERTURE_VIDE = (
    '/\\.(pdf|psnote)$/i.test(O)?{content:""}:await ki("file?path="')
ANCIEN_HOTE_DOCUMENT = (
    '/\\.(pdf|psnote)$/i.test(Un.path)||Un.path.startsWith("@pdf-preview:")'
    '?T.createElement("div",{className:"ps-document-host",key:Un.path,'
    '"data-path":Un.path}):')


# --- panneau dev web dans la barre latérale ---------------------------------
#
# La barre latérale est construite en TROIS endroits distincts du bundle : la
# liste des boutons de la barre d'activités, le libellé d'en-tête (un ternaire)
# et le corps de la barre (une chaîne de ternaires). Les trois doivent être
# étendus ensemble :
#   * un bouton sans corps ouvre une barre latérale vide ;
#   * un corps sans bouton est inaccessible ;
#   * sans libellé, l'en-tête retombe sur le dernier membre du ternaire et
#     affiche « RECHERCHE » au-dessus du panneau dev web — plus trompeur qu'un
#     titre absent.
#
# Le corps est un élément VIDE (.ps-devweb-host), exactement comme .ps-ai-host,
# .psfm-host, .ps-document-host et .ps-data-host : devweb-studio.js l'observe et
# y rend l'interface. Aucun composant du bundle n'est référencé depuis le texte
# ajouté : les noms minifiés (qw, mie, u7…) changent d'une compilation à
# l'autre, et le glyphe est donc du texte mis en forme par devweb-studio.css.
ANCIEN_BOUTON_PROBLEMES = (
    'T.createElement("button",{onClick:()=>{C(!0),p("problems")},'
    'title:"Probl\u00e8mes"},T.createElement(qw,{size:20}))')
ANCIEN_LIBELLE_TETE = (
    'T.createElement("b",null,y==="project"?"PROJET":'
    'y==="git"?"GESTION DE VERSION"')
ANCIEN_CORPS_RECHERCHE = (
    'column:O.column})}):T.createElement(T.Fragment,null,'
    'T.createElement("div",{className:"search-box"}')


def nouveau_bouton_devweb():
    # Insertion AVANT le bouton « Problèmes » : l'ancre est conservée, donc la
    # substitution n'est pas rejouée sur un bundle déjà patché.
    return ('T.createElement("button",{className:y==="devweb"?"active":"",'
            'onClick:()=>S(y==="devweb"?"":"devweb"),'
            'title:"Dev web : aper\u00e7u, journal, audits et g\u00e9n\u00e9rateurs",'
            '"aria-label":"Dev web"},'
            'T.createElement("span",{className:"ps-ab-glyph"},"</>")),'
            + ANCIEN_BOUTON_PROBLEMES)


def nouveau_libelle_tete():
    return ('T.createElement("b",null,y==="devweb"?"DEV WEB":'
            'y==="project"?"PROJET":y==="git"?"GESTION DE VERSION"')


def nouveau_corps_devweb():
    return ('column:O.column})}):y==="devweb"?T.createElement("div",'
            '{className:"ps-devweb-host"}):T.createElement(T.Fragment,null,'
            'T.createElement("div",{className:"search-box"}')


# ---------------------------------------------------------------------------
# N, O et P : le panneau de rétro-ingénierie dans la barre latérale.
#
# K, L et M (dev web) sont déjà consommés : leurs ancres d'origine ont disparu
# du bundle. N, O et P s'appuient donc sur le texte PRODUIT par K, L et M, qui
# est lui aussi unique et stable — c'est la seule ancre disponible, et elle est
# légitime : un panneau ajouté après un autre panneau s'accroche à celui-ci.
#
# Les trois doivent être étendues ensemble, pour les mêmes raisons qu'au dev
# web : un bouton sans corps ouvre une barre latérale vide, un corps sans bouton
# est inaccessible, et sans libellé l'en-tête retombe sur « DEV WEB » au-dessus
# du panneau de rétro-ingénierie — plus trompeur qu'un titre absent.
#
# Le corps est un élément VIDE (.ps-re-host) : re-studio.js l'observe et y rend
# l'interface. Aucun composant minifié du bundle n'est référencé.
# ---------------------------------------------------------------------------

# L'ancre de N est le bouton dev web tel que K l'a produit. Elle est DÉDUITE de
# nouveau_bouton_devweb() plutôt que recopiée : recopier un texte de 240
# caractères à la main est exactement ce qui fait diverger une ancre du bundle,
# et la divergence ne se voit qu'au moment d'appliquer — sur la machine de
# l'utilisateur, pas ici.
ANCIEN_BOUTON_DEVWEB = nouveau_bouton_devweb()[:-len(ANCIEN_BOUTON_PROBLEMES)]

ANCIEN_LIBELLE_DEVWEB = 'T.createElement("b",null,y==="devweb"?"DEV WEB":'

ANCIEN_CORPS_DEVWEB = (
    'y==="devweb"?T.createElement("div",{className:"ps-devweb-host"})')

BOUTON_RE = (
    'T.createElement("button",{className:y==="re"?"active":"",'
    'onClick:()=>S(y==="re"?"":"re"),'
    'title:"R\u00e9tro-ing\u00e9nierie : analyse binaire, Ghidra, '
    'fiches et widgets","aria-label":"R\u00e9tro-ing\u00e9nierie"},'
    'T.createElement("span",{className:"ps-ab-glyph"},"0x")),')


def nouveau_bouton_re():
    # Insertion AVANT le bouton dev web : l'ancre est conservée, donc la
    # substitution n'est pas rejouée sur un bundle déjà patché. Le bouton se
    # retrouve au-dessus de « </> » et en dessous des boutons d'origine.
    return BOUTON_RE + ANCIEN_BOUTON_DEVWEB


def nouveau_libelle_re():
    # « RÉTRO-INGÉNIERIE » tient dans l'en-tête : « GESTION DE VERSION » y est
    # déjà, et le libellé est tronqué par re-studio.css si besoin.
    return ('T.createElement("b",null,y==="re"?"R\u00c9TRO-ING\u00c9NIERIE":'
            'y==="devweb"?"DEV WEB":')


def nouveau_corps_re():
    # Insertion d'un membre de ternaire AVANT celui du dev web : l'ancre est
    # conservée en suffixe, donc la substitution n'est pas rejouée.
    return ('y==="re"?T.createElement("div",{className:"ps-re-host"}):'
            + ANCIEN_CORPS_DEVWEB)


def nouvelle_fin_vr():
    return ('malbolge":/\\.(%s)$/i.test(e)?"%s":"plaintext"}'
            % ('|'.join(EXTENSIONS), IDENTIFIANT))


def nouveau_groupe_extensions():
    return '|fra|mal|%s)$/i.test(e)' % '|'.join(EXTENSIONS)


def nouveaux_libelles():
    return ('malbolge:"Malbolge",%s:"%s",plaintext:"Texte"}'
            % (IDENTIFIANT, LIBELLE))


def nouvelles_icones():
    return ('malbolge:["MAL","Malbolge"],%s:["%s","%s"]}[Q]'
            % (IDENTIFIANT, BADGE, LIBELLE))


def nouvel_enregistrement():
    """L'enregistrement Monaco avec son chargeur de tokenizer.

    Placé juste après celui de Ruby, une ancre vérifiée unique. Le tokenizer
    vient d'asm-studio.js, engendré depuis les tables d'assembleur.py : la
    coloration connaît donc exactement les mêmes mnémoniques et registres que
    l'analyseur, au lieu d'une seconde liste qui divergerait.
    """
    return ANCIEN_ENREGISTREMENT + (
        'Vh({id:"%s",extensions:[%s],aliases:[%s],'
        'loader:()=>Tc(()=>import("./asm-studio.js"),[])});'
        % (IDENTIFIANT,
           ','.join('".%s"' % e for e in ('asm', 's', 'S', 'nasm')),
           ','.join('"%s"' % a for a in ALIASES)))


def nouvelle_ouverture_vide():
    """Les fichiers de données s'ouvrent sans charger leur contenu.

    Sans cette substitution, ouvrir un .sqlite ferait lire tout le fichier par
    /api/file et le placerait comme texte dans un onglet Monaco : des mégaoctets
    de binaire illisible, et un éditeur devenu inutilisable.
    """
    return ('/\\.(pdf|psnote|' + '|'.join(EXTENSIONS_DONNEES)
            + ')$/i.test(O)?{content:""}:await ki("file?path="')


def signature_ouverture_vide():
    """La signature d'idempotence de cette substitution, 4.3.0.

    Le groupe d'extensions est un point de passage : la 4.3.0 y insère les
    images et les sources Piet (« pdf|psnote|piett|png|…|ods »). La signature
    déduite — le texte complet produit ici, préfixe « /\\.(pdf|psnote| » compris
    — n'y survit pas, et le vérificateur retombait alors sur le chemin des
    ancres pour annoncer « ANCRE HS » sur un bundle PARFAITEMENT patché, avec un
    code 2 (« problème »). C'est le cas exact prévu par le cinquième élément de
    substitutions() : une signature qui chevauche une zone modifiée plus tard.

    Le fragment retenu est la QUEUE du groupe, celle que rien ne réécrit : elle
    prouve que l'extension a bien été faite, elle est absente d'un bundle vierge
    (« pdf|psnote » seul), et elle reste vraie quelle que soit la liste insérée
    devant elle.
    """
    return ('|' + '|'.join(EXTENSIONS_DONNEES)
            + ')$/i.test(O)?{content:""}:await ki("file?path="')


def nouveau_hote_donnees():
    """L'hôte rendu à la place de Monaco, sur le modèle de ps-document-host.

    Le littéral d'expression rationnelle doit garder SON SLASH FERMANT et son
    drapeau : la première version supprimait « /i » par un replace(), ce qui
    retirait aussi le slash final et produisait « /\\.(?:csv|…)$.test(… », un
    littéral non terminé. Le bundle entier devenait du JavaScript invalide, et
    l'application ne démarrait plus du tout.
    """
    return (ANCIEN_HOTE_DOCUMENT
            + '/\\.(?:' + '|'.join(EXTENSIONS_DONNEES) + ')$/i.test(Un.path)'
            + '?T.createElement("div",{className:"ps-data-host",key:Un.path,'
              '"data-path":Un.path}):')


def substitutions():
    """Les remplacements, leur nombre attendu, et si l'ancre est conservée.

    Le quatrième élément distingue un REMPLACEMENT d'une INSERTION : la plupart
    des substitutions font disparaître leur ancre, mais celles qui AJOUTENT un
    élément après un existant (l'enregistrement Monaco de l'assembleur après
    celui de Ruby, le bouton dev web avant le bouton « Problèmes ») la
    conservent, volontairement. Sans cette distinction, le contrôle
    d'idempotence « aucune ancienne ancre ne subsiste » échouait sur un bundle
    correctement patché — et un contrôle qui échoue à tort apprend à ignorer les
    contrôles.
    """
    # Le cinquième élément est la signature d'idempotence EXPLICITE, ou None
    # pour laisser `signature()` la déduire. Il n'est renseigné que là où la
    # signature déduite chevauche la zone modifiée par une substitution
    # ultérieure — voir la docstring de `signature()`.
    return [
        (ANCIENNE_FIN_VR, nouvelle_fin_vr(), 1, False, None),
        (ANCIEN_GROUPE_EXTENSIONS, nouveau_groupe_extensions(), 1, False, None),
        (ANCIENS_LIBELLES, nouveaux_libelles(), 1, False, None),
        (ANCIENNES_ICONES, nouvelles_icones(), 1, False, None),
        (ANCIENNE_BOUCLE_COMPLETION,
         'for(const t of%s)o.languages.registerCompletionItemProvider'
         % liste(COMPLETION_40), 1, False, None),
        (ANCIEN_PRECHAUFFAGE,
         'St&&%s.includes(St.getLanguageId())&&fetch("/api/completion"'
         % liste(COMPLETION_40), 1, False, None),
        # DEUX occurrences : l'une pour afficher le bouton de débogage, l'autre
        # pour choisir le mode. N'en corriger qu'une laisserait un bouton visible
        # mais inopérant, ou l'inverse.
        (ANCIENNE_LISTE_DEBOGAGE, '%s.includes(vr(' % liste(DEBOGAGE_40), 2,
         False, None),
        (ANCIEN_ENREGISTREMENT, nouvel_enregistrement(), 1, True, None),
        # I et J : l'éditeur de données en onglet. Les deux sont des insertions
        # partielles — I réécrit le test d'extension, J ajoute une branche après
        # celle des documents — donc l'ancre de J est conservée.
        # Signature EXPLICITE : la 4.3.0 réécrit le début du groupe pour y
        # insérer les images et les .piett. Voir signature_ouverture_vide().
        (ANCIENNE_OUVERTURE_VIDE, nouvelle_ouverture_vide(), 1, False,
         signature_ouverture_vide()),
        (ANCIEN_HOTE_DOCUMENT, nouveau_hote_donnees(), 1, True, None),
        # K, L et M : le panneau dev web dans la barre latérale. K est une
        # insertion qui conserve son ancre ; L et M réécrivent leur ancre en y
        # ajoutant un membre de ternaire, donc l'ancre disparaît.
        # L et M portent une signature EXPLICITE : O et P insèrent un membre de
        # ternaire juste après le préfixe `T.createElement("b",null,` (L) et
        # `column:O.column})}):` (M). Sans elle, un bundle correctement patché
        # par N, O et P serait annoncé comme ayant perdu L et M.
        (ANCIEN_BOUTON_PROBLEMES, nouveau_bouton_devweb(), 1, True, None),
        (ANCIEN_LIBELLE_TETE, nouveau_libelle_tete(), 1, False,
         'y==="devweb"?"DEV WEB":y==="project"?"PROJET":'
         'y==="git"?"GESTION DE VERSION"'),
        (ANCIEN_CORPS_RECHERCHE, nouveau_corps_devweb(), 1, False,
         'y==="devweb"?T.createElement("div",{className:"ps-devweb-host"}):'
         'T.createElement(T.Fragment,null,'
         'T.createElement("div",{className:"search-box"'),
        # N, O et P : le panneau de rétro-ingénierie, accroché au texte produit
        # par K, L et M — leurs ancres d'origine ont disparu du bundle. N et P
        # sont des insertions qui conservent leur ancre ; O réécrit la sienne en
        # y ajoutant un membre de ternaire, donc l'ancre disparaît.
        (ANCIEN_BOUTON_DEVWEB, nouveau_bouton_re(), 1, True, None),
        (ANCIEN_LIBELLE_DEVWEB, nouveau_libelle_re(), 1, False, None),
        (ANCIEN_CORPS_DEVWEB, nouveau_corps_re(), 1, True, None),
    ]


# Chaque changement doit laisser une trace vérifiable, et pas seulement
# « l'ancre a disparu » : une ancre absente peut aussi signifier que le bundle
# n'est pas celui qu'on croit.
TRACES = (
    ('résolution des extensions',
     '/\\.(asm|s|nasm)$/i.test(e)?"asm"'),
    ('groupe d’extensions du projet', '|fra|mal|asm|s|nasm)$/i.test(e)'),
    ('libellé', 'asm:"Assembleur"'),
    ('badge de l’arborescence', 'asm:["ASM","Assembleur"]'),
    ('liste de complétion', '"ocaml","json","xml","plaintext","brainfuck"'),
    ('complétion étendue à l’assembleur', '"malbolge","asm"]'
     ')o.languages.registerCompletionItemProvider'),
    ('débogage étendu à l’assembleur', '"malbolge","asm"].includes(vr('),
    ('enregistrement Monaco et tokenizer',
     'Vh({id:"asm",extensions:[".asm",".s",".S",".nasm"]'),
    ('chargeur du tokenizer', 'import("./asm-studio.js")'),
    # La trace suit le texte RÉELLEMENT produit : la substitution étend le
    # groupe existant « (pdf|psnote|…) », elle n'en crée pas un non capturant.
    # Écrite d'abord avec « (?:… », elle ne correspondait à rien et le contrôle
    # échouait sur un bundle correctement patché.
    ('ouverture sans charger le texte des bases',
     '|sqlite3?|db3?|csv|tsv|sql|xlsx|ods)$/i.test(O)?{content:""}'),
    ('hôte de l’éditeur de données', 'className:"ps-data-host"'),
    ('le chemin de l’hôte est transmis',
     '{className:"ps-data-host",key:Un.path,"data-path":Un.path}'),
    ('bouton dev web de la barre d’activités', 'className:"ps-ab-glyph"'),
    ('le bouton dev web bascule la barre latérale',
     'onClick:()=>S(y==="devweb"?"":"devweb")'),
    ('libellé de l’en-tête dev web', 'y==="devweb"?"DEV WEB"'),
    ('hôte du panneau dev web', 'className:"ps-devweb-host"'),
    # Le panneau de rétro-ingénierie : les trois traces correspondent aux trois
    # substitutions N, O et P. Contrôler seulement « l’hôte existe » laisserait
    # passer un panneau inaccessible (pas de bouton) ou mal titré.
    ('bouton rétro-ingénierie de la barre d’activités',
     'onClick:()=>S(y==="re"?"":"re")'),
    ('libellé de l’en-tête rétro-ingénierie',
     'y==="re"?"R\u00c9TRO-ING\u00c9NIERIE"'),
    ('hôte du panneau rétro-ingénierie', 'className:"ps-re-host"'),
)


def signature(ancre, nouveau, conserve, explicite=None):
    """Ce qui prouve qu'une substitution a déjà été appliquée.

    Pour un remplacement, c'est le texte nouveau. Pour une INSERTION — qui
    conserve son ancre — c'est la partie ajoutée seulement, l'ancre étant
    toujours présente par construction.

    Sans cette distinction, deux défauts apparaissent ensemble : un bundle
    patché partiellement est refusé en bloc parce que l'ancre d'une
    substitution déjà faite a disparu, et une substitution par insertion est
    rejouée, ce qui dupliquerait l'enregistrement Monaco de l'assembleur et la
    branche de l'hôte de données.

    `explicite` couvre un troisième cas, apparu avec le panneau de
    rétro-ingénierie : une substitution dont la signature CHEVAUCHE la zone
    qu'une substitution LATERALE modifie. L (le libellé de l'en-tête) et M (le
    corps de la barre) produisent un texte qui commence par
    `T.createElement("b",null,` et `column:O.column})}):` ; O et P insèrent un
    membre de ternaire juste après ces préfixes. La signature « le texte nouveau
    entier » devient alors introuvable sur un bundle CORRECTEMENT patché, et le
    contrôle annonce deux substitutions manquantes qui sont en fait présentes.
    La signature explicite est le fragment qui subsiste — celui qui ne contient
    pas le préfixe partagé.
    """
    if explicite:
        return explicite
    if conserve and nouveau.startswith(ancre):
        return nouveau[len(ancre):]
    return nouveau


def deja_applique(texte):
    """Vrai seulement si TOUTES les substitutions sont déjà en place."""
    if MARQUEUR not in texte:
        return False
    return all(signature(a, n, c, g) in texte
               for a, n, _attendu, c, g in substitutions())


def verifier_texte(texte, chemin):
    """Contrôle un TEXTE de bundle. Renvoie (code, rapport).

    `verifier()` lit le fichier puis délègue ici ; `appliquer()` contrôle le
    texte EN MÉMOIRE avant de l'écrire. Sans cette séparation, un échec de
    contrôle laissait sur le disque un bundle écrit mais non vérifié — et le
    diagnostic suivant portait alors sur un fichier déjà modifié, ce qui rend la
    cause illisible. Écrire seulement ce qu'on a validé est la règle.

    Le code rend compte de TROIS états, et non de deux :
      0  conforme    — les substitutions sont en place et les traces présentes ;
      1  patchable   — rien n'est en place (ou partiellement) mais toutes les
                       ancres sont bonnes : appliquer() réussira ;
      2  problème    — une ancre manque ou une trace est absente.
    Confondre 0 et 1 serait grave pour le reconditionneur : il teste l'état du
    bundle de l'image pour décider s'il doit patcher, et un « tout va bien »
    rendu sur un bundle vierge lui ferait sauter l'application — l'application
    partirait sans l'interface 4.0.0, sans aucune erreur nulle part.
    """
    lignes = []
    faites = [(a, n, c) for a, n, _at, c, _g in substitutions()
              if signature(a, n, c, _g) in texte]
    if deja_applique(texte):
        lignes.append('  déjà patché : %s' % chemin)
        manques = [a for a, _n, _at, c, _g in substitutions()
                   if a in texte and not c]
        if manques:
            lignes.append('  ATTENTION : %d ancienne(s) ancre(s) encore '
                          'présente(s)' % len(manques))
            for ancre in manques:
                lignes.append('    %s' % ancre[:80])
            return 2, lignes
        manquants = [libelle for libelle, trace in TRACES if trace not in texte]
        if manquants:
            for libelle in manquants:
                lignes.append('  TRACE ABSENTE : %s' % libelle)
            return 2, lignes
        lignes.append('  les %d traces sont présentes' % len(TRACES))
        return 0, lignes

    if faites:
        lignes.append('  partiellement patché : %d substitution(s) sur %d déjà '
                      'en place — les manquantes seront appliquées'
                      % (len(faites), len(substitutions())))
    else:
        lignes.append('  pas encore patché : %s' % chemin)
    # Une ancre peut être PRODUITE par une substitution ANTÉRIEURE : N, O et P
    # s'accrochent au texte que K, L et M écrivent (leurs ancres d'origine ont
    # disparu du bundle). Contrôler les ancres sur le texte tel quel annoncerait
    # « ANCRE HS » pour trois substitutions qui vont très bien s'appliquer — et
    # un contrôle qui échoue à tort apprend à ignorer les contrôles. La séquence
    # est donc SIMULÉE : `progres` part du texte et s'enrichit de chaque
    # substitution applicable, exactement comme le fait appliquer().
    progres = texte
    for ancre, nouveau, attendu, conserve, groupe in substitutions():
        if signature(ancre, nouveau, conserve, groupe) in texte:
            lignes.append('  DÉJÀ FAIT : %s' % ancre[:64])
            continue
        trouve = progres.count(ancre)
        if trouve != attendu:
            lignes.append('  ANCRE HS : trouvée %d fois, attendue %d — %s'
                          % (trouve, attendu, ancre[:64]))
        else:
            lignes.append('  ANCRE OK : %d occurrence(s) — %s'
                          % (trouve, ancre[:64]))
            progres = progres.replace(ancre, nouveau)
    if [l for l in lignes if l.startswith('  ANCRE HS')]:
        return 2, lignes
    return 1, lignes


def verifier(chemin):
    """Contrôle le bundle sur disque sans rien écrire. Renvoie (code, rapport).

    code : 0 conforme, 1 patchable, 2 problème — voir verifier_texte().
    """
    with io.open(chemin, encoding='utf8') as fichier:
        texte = fichier.read()
    return verifier_texte(texte, chemin)


def appliquer(chemin):
    with io.open(chemin, encoding='utf8') as fichier:
        texte = fichier.read()
    if deja_applique(texte):
        code, rapport = verifier(chemin)
        for ligne in rapport:
            print(ligne)
        return code
    faites = 0
    for ancre, nouveau, attendu, conserve, groupe in substitutions():
        if signature(ancre, nouveau, conserve, groupe) in texte:
            continue                      # déjà appliquée, ne pas rejouer
        trouve = texte.count(ancre)
        if trouve != attendu:
            sys.stderr.write(
                'Ancre trouvée %d fois au lieu de %d : %s\n'
                'Le bundle n’est pas celui de la 3.8.0, ou un correctif '
                'antérieur manque. Rien n’a été écrit.\n'
                % (trouve, attendu, ancre[:120]))
            return 1
        texte = texte.replace(ancre, nouveau)
        faites += 1
    if MARQUEUR not in texte:
        texte += '\n/* %s */\n' % MARQUEUR
    # Contrôle EN MÉMOIRE, avant toute écriture : si le résultat n'est pas
    # conforme, le bundle sur disque reste intact et le diagnostic porte sur le
    # fichier que l'utilisateur a fourni, pas sur un fichier déjà modifié.
    code, rapport = verifier_texte(texte, chemin)
    if code != 0:
        for ligne in rapport:
            print(ligne)
        sys.stderr.write(
            'Le bundle patché ne passe pas le contrôle : RIEN n’a été écrit.\n')
        return 1
    with io.open(chemin, 'w', encoding='utf8') as fichier:
        fichier.write(texte)
    for ligne in rapport:
        print(ligne)
    print('  patch_interface_4.0 : %d substitution(s) appliquée(s) sur %d'
          % (faites, len(substitutions())))
    return 0


def main(argv):
    if not argv or argv[0] in ('-h', '--aide'):
        sys.stderr.write(__doc__)
        return 2
    if argv[0] == '--verifier':
        if len(argv) != 2:
            sys.stderr.write('emploi : patch_interface_4.0.py --verifier '
                             'CHEMIN\n')
            return 2
        code, rapport = verifier(argv[1])
        for ligne in rapport:
            print(ligne)
        # Le code est propagé tel quel : 0 conforme, 1 patchable, 2 problème.
        # C'est ce qui permet au reconditionneur de décider s'il doit appliquer,
        # au lieu de déduire « pas encore patché » d'un échec quelconque.
        return code
    if len(argv) != 1:
        sys.stderr.write('emploi : patch_interface_4.0.py CHEMIN\n')
        return 2
    return appliquer(argv[0])


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
