#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Patcher l'interface compilée pour la 4.3.0 : trois ancrages, pas un de plus.

LES TROIS CHANGEMENTS
  A. `hote-onglets` — un élément vide DANS la barre d'onglets du bundle.
     `vues-studio.js` y rend les vignettes des panneaux (navigateur,
     rétro-ingénierie, dev web, images, Piet) : elles portent la classe `tab` du
     bundle, donc elles héritent de son thème et vivent à côté des onglets de
     fichiers. Sans cet ancrage, les panneaux n'auraient aucune place visible
     dans la barre et redeviendraient des fenêtres flottantes.

  B. `hôtes image et piet` — deux membres ajoutés à la chaîne qui choisit quoi
     afficher pour l'onglet actif. Le bundle routait déjà les PDF vers
     `.ps-document-host` et les bases vers `.ps-data-host` ; les images vont
     vers `.ps-image-host` et les sources Piet texte vers `.ps-piet-host`, avec
     le chemin en `data-path`. C'est ce qui fait qu'une image s'ouvre dans un
     VRAI onglet, avec sa croix et son raccourci, et non dans une fenêtre posée
     par-dessus.
     Le SVG n'est PAS routé ici : c'est du texte, il reste éditable dans Monaco.
     Le lui voler serait une régression.

  C. `ouverture sans lire les octets` — la liste des chemins que l'ouverture
     d'onglet ne lit PAS comme du texte. Sans ce changement, ouvrir un PNG
     ferait lire des octets binaires par `file?path=` : au mieux un éditeur
     plein de caractères de remplacement, au pire une erreur qui empêche
     l'onglet de s'ouvrir. C'est le même acquis que pour les PDF et les bases en
     4.0.0, étendu.

CE QUI N'EST PAS PATCHÉ, ET POURQUOI
  La zone d'affichage des vues pleines n'est PAS créée ici : `vues-studio.js`
  l'ajoute lui-même dans `main.studio-main`, dont la classe est stable et
  unique. Chaque substitution est un risque sur un fichier de 4,4 Mo ; n'en
  poser que trois, toutes vérifiables, est le choix sûr.

  Le SPLITTING de deux fichiers de code n'est pas patché non plus : il faudrait
  une seconde instance de Monaco, que seul le bundle sait créer. Ce qui est
  livré, c'est le splittage des PANNEAUX entre eux et avec l'éditeur — et le
  guide dit la limite au lieu de la cacher.

CONTRAT
  `--verifier CIBLE` rend 0 conforme, 1 patchable, 2 problème. L'application
  est idempotente : la signature est le TEXTE AJOUTÉ, jamais l'ancre.

Usage :
    python3 patch_interface_4.3.py --verifier CHEMIN/index-*.js
    python3 patch_interface_4.3.py CHEMIN/index-*.js
"""

import io
import os
import sys

MARQUEUR = 'ps-4.3.0-interface'
HOTE = 'ps-onglets-host'

# ---------------------------------------------------------------------------
# A. la barre d'onglets
# ---------------------------------------------------------------------------
ANCRE_ONGLETS = 'T.createElement("div",{className:"tabbar-fill"})'
NOUVEAU_ONGLETS = ('T.createElement("div",{className:"' + HOTE + '",'
                   '"data-marqueur":"' + MARQUEUR + '",'
                   '"data-role":"onglets-delegues"}),'
                   'T.createElement("div",{className:"tabbar-fill"})')

# ---------------------------------------------------------------------------
# B. la chaîne de choix du contenu d'un onglet
# ---------------------------------------------------------------------------
ANCRE_CONTENU = ('/\\.(pdf|psnote)$/i.test(Un.path)||Un.path.startsWith("@pdf-preview:")'
                 '?T.createElement("div",{className:"ps-document-host",'
                 'key:Un.path,"data-path":Un.path}):')
NOUVEAU_CONTENU = ANCRE_CONTENU + (
    '/\\.(piett)$/i.test(Un.path)?T.createElement("div",'
    '{className:"ps-piet-host",key:Un.path,"data-path":Un.path}):'
    '/\\.(png|jpe?g|gif|bmp|webp|ico|tif?f)$/i.test(Un.path)'
    '?T.createElement("div",{className:"ps-image-host",key:Un.path,'
    '"data-path":Un.path}):')

# ---------------------------------------------------------------------------
# C. l'ouverture d'onglet sans lecture du texte
# ---------------------------------------------------------------------------
ANCRE_OUVERTURE = ('O==="@assistant"||O==="@file-manager"||'
                   '/\\.(pdf|psnote|sqlite3?|db3?|csv|tsv|sql|xlsx|ods)$/i.test(O)'
                   '?{content:""}')
NOUVEAU_OUVERTURE = ('O==="@assistant"||O==="@file-manager"||'
                     '/\\.(pdf|psnote|piett|png|jpe?g|gif|bmp|webp|ico|tif?f|'
                     'sqlite3?|db3?|csv|tsv|sql|xlsx|ods)$/i.test(O)'
                     '?{content:""}')

SUBSTITUTIONS = (
    ('hote-onglets', ANCRE_ONGLETS, NOUVEAU_ONGLETS, 'className:"' + HOTE + '"'),
    ('hôtes image et piet', ANCRE_CONTENU, NOUVEAU_CONTENU,
     'className:"ps-image-host"'),
    ('ouverture sans lire', ANCRE_OUVERTURE, NOUVEAU_OUVERTURE,
     'piett|png|jpe?g|gif|bmp|webp|ico|tif?f'),
)

# Chaque changement doit laisser une trace vérifiable, et pas seulement « l'ancre
# a disparu » : une ancre absente peut aussi signifier que le bundle n'est pas
# celui qu'on croit.
# Contrôlé à la définition plutôt qu'au lancement : si un jour une substitution
# ajoute « svg », ce script refuse de s'écrire au lieu de produire un bundle qui
# vole le SVG à Monaco.
assert 'svg' not in NOUVEAU_CONTENU.lower(), 'le SVG doit rester à Monaco'
assert 'svg' not in NOUVEAU_OUVERTURE.lower(), 'le SVG doit rester à Monaco'

TRACES = (
    ('hôte dans la barre d’onglets',
     '{className:"' + HOTE + '","data-marqueur":"' + MARQUEUR + '",'
     '"data-role":"onglets-delegues"}'),
    ('l’hôte est posé AVANT le remplissage',
     'className:"' + HOTE + '","data-marqueur":"' + MARQUEUR + '",'
     '"data-role":"onglets-delegues"}),T.createElement("div",'
     '{className:"tabbar-fill"})'),
    ('hôte de l’éditeur Piet',
     '{className:"ps-piet-host",key:Un.path,"data-path":Un.path}'),
    ('hôte de la visionneuse',
     '{className:"ps-image-host",key:Un.path,"data-path":Un.path}'),
    ('le SVG reste à Monaco', None),      # contrôle négatif, voir verifier_texte
    ('les images ne sont pas lues en texte',
     'piett|png|jpe?g|gif|bmp|webp|ico|tif?f|sqlite3?'),
)


def verifier_texte(texte, chemin):
    """0 conforme, 1 patchable, 2 problème."""
    lignes = ['%s : %d octets' % (os.path.basename(chemin),
                                  len(texte.encode('utf8')))]
    if not texte:
        lignes.append('%s : fichier vide.' % chemin)
        return 2, lignes
    appliquees = 0
    for nom, ancre, _nouveau, signature in SUBSTITUTIONS:
        if signature in texte:
            lignes.append('  %-22s appliquée' % nom)
            appliquees += 1
            continue
        compte = texte.count(ancre)
        if compte == 1:
            lignes.append('  %-22s patchable' % nom)
        elif compte == 0:
            lignes.append('  %-22s ANCRE INTROUVABLE : le bundle n’a plus cette '
                          'forme.' % nom)
            return 2, lignes
        else:
            lignes.append('  %-22s ANCRE %d fois : remplacement ambigu.'
                          % (nom, compte))
            return 2, lignes
    if appliquees == len(SUBSTITUTIONS):
        if MARQUEUR not in texte:
            lignes.append('  les hôtes sont posés mais le marqueur %s est absent.'
                          % MARQUEUR)
            return 2, lignes
        # Le SVG doit rester du texte : un membre de ternaire qui le routerait
        # vers la visionneuse supprimerait l'édition du SVG, sans qu'aucune
        # erreur n'apparaisse nulle part. Le contrôle porte sur NOTRE texte
        # ajouté, jamais sur le bundle entier — qui contient « svg » ailleurs
        # (liste de complétion, en-têtes de base) et ferait un faux positif.
        if 'svg' in NOUVEAU_CONTENU.lower() or 'svg' in NOUVEAU_OUVERTURE.lower():
            lignes.append('  LE SVG EST ROUTÉ VERS UNE VISIONNEUSE : il doit '
                          'rester éditable dans Monaco.')
            return 2, lignes
        for branche in (NOUVEAU_CONTENU[len(ANCRE_CONTENU):],):
            if 'ps-image-host' not in branche or 'ps-piet-host' not in branche:
                lignes.append('  les deux nouveaux hôtes ne sont pas tous posés.')
                return 2, lignes
        for titre, trace in TRACES:
            if trace is None:
                continue
            if trace not in texte:
                lignes.append('  TRACE MANQUANTE : %s' % titre)
                return 2, lignes
        lignes.append('  conforme (4.3.0 en place)')
        return 0, lignes
    lignes.append('  patchable (%d/%d appliquées)'
                  % (appliquees, len(SUBSTITUTIONS)))
    return 1, lignes


def verifier(chemin):
    if not os.path.isfile(chemin):
        return 2, ['%s : introuvable.' % chemin]
    try:
        texte = io.open(chemin, encoding='utf-8').read()
    except (OSError, UnicodeDecodeError) as exc:
        return 2, ['%s : illisible (%s).' % (chemin, exc)]
    return verifier_texte(texte, chemin)


def appliquer(chemin):
    if not os.path.isfile(chemin):
        sys.stderr.write('ERREUR : %s est introuvable.\n' % chemin)
        return 2
    texte = io.open(chemin, encoding='utf-8').read()
    depart = len(texte)
    deja = sum(1 for _n, _a, _x, signature in SUBSTITUTIONS if signature in texte)
    if deja == len(SUBSTITUTIONS):
        sys.stderr.write('%s : déjà patché, rien à faire.\n' % chemin)
        return 0
    for nom, ancre, nouveau, signature in SUBSTITUTIONS:
        if signature in texte:
            continue
        if texte.count(ancre) != 1:
            sys.stderr.write('ERREUR : l’ancre de %s apparaît %d fois, rien '
                             'n’est écrit.\n' % (nom, texte.count(ancre)))
            return 2
        texte = texte.replace(ancre, nouveau, 1)
    if MARQUEUR not in texte:
        texte += '\n/* %s */\n' % MARQUEUR
    for titre, trace in TRACES:
        if trace is None:
            continue
        if trace not in texte:
            sys.stderr.write('ERREUR : après application, « %s » est absente ; '
                             'rien n’est écrit.\n' % titre)
            return 2
    io.open(chemin, 'w', encoding='utf-8').write(texte)
    sys.stderr.write('%s : %d -> %d caractères ; hôte .%s dans la barre '
                     'd’onglets, hôtes .ps-image-host et .ps-piet-host, images '
                     'et .piett ouverts sans lecture texte.\n'
                     % (chemin, depart, len(texte), HOTE))
    return 0


def main(argv):
    if not argv or argv[0] in ('-h', '--aide'):
        sys.stderr.write(__doc__)
        return 2
    if argv[0] == '--verifier':
        if len(argv) != 2:
            sys.stderr.write('Usage : patch_interface_4.3.py --verifier CHEMIN\n')
            return 2
        code, rapport = verifier(argv[1])
        for ligne in rapport:
            sys.stderr.write(ligne + '\n')
        return code
    if len(argv) != 1:
        sys.stderr.write('Usage : patch_interface_4.3.py CHEMIN\n')
        return 2
    return appliquer(argv[0])


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
