#!/usr/bin/env python3
"""Pascal Studio 3.6.0 — Swift, Kotlin, logos réels et dialogue « Nouveau fichier ».

Correctif du bundle React compilé (interface-compilee/assets/index-BA4XgQVD.js).
Le code source React n'est pas disponible : on modifie donc le bundle par
ancrages exacts, comme patch_five_languages.py et patch_ia_3.4.py avant lui.

Usage :
    python3 patch_langages_3.6.py CHEMIN/index-BA4XgQVD.js
    python3 patch_langages_3.6.py --verifier CHEMIN/index-BA4XgQVD.js

Chaque ancrage est vérifié : si l'un d'eux manque ou apparaît un nombre
inattendu de fois, le script s'arrête sans rien écrire. Il est idempotent
(un bundle déjà corrigé n'est pas retouché).
"""
import io
import json
import sys

# --------------------------------------------------------------------------
# 1. Enregistrement Monaco de Swift et Kotlin.
#    Les chunks swift-studio.js / kotlin-studio.js sont convertis depuis
#    monaco-editor v0.52.2 (MIT), même version que le reste du bundle.
# --------------------------------------------------------------------------
ANCRE_MONACO = ('Vh({id:"css",extensions:[".css"],aliases:["CSS","css"],'
                'mimetypes:["text/css"],loader:()=>Tc(()=>import("./css-D3h14YRZ.js"),[])});')

NOUVEAU_MONACO = (
    'Vh({id:"swift",extensions:[".swift"],aliases:["Swift","swift"],'
    'loader:()=>Tc(()=>import("./swift-studio.js"),[])});'
    'Vh({id:"kotlin",extensions:[".kt",".kts"],aliases:["Kotlin","kotlin"],'
    'loader:()=>Tc(()=>import("./kotlin-studio.js"),[])});'
)

# --------------------------------------------------------------------------
# 2. Vocabulaire d'auto-complétion. Les quatre tables existantes sont toutes
#    protégées par « ||[] », donc un langage absent ne provoque aucune erreur.
# --------------------------------------------------------------------------
MOTS_CLES = {
    "swift": (
        "associatedtype break case catch class continue default defer deinit do else enum extension "
        "fallthrough false fileprivate final for func guard if import in init inout internal is lazy "
        "let mutating nil operator private protocol public repeat required rethrows return self static "
        "struct subscript super switch throw throws true try typealias var weak where while any some "
        "async await Task actor isolated nonisolated"
    ).split(),
    "kotlin": (
        "abstract actual annotation as break by catch class companion const constructor continue "
        "crossinline data do dynamic else enum expect external false final finally for fun get if "
        "import in infix init inline interface internal is lateinit noinline null object open operator "
        "out override package private protected public reified return sealed set super suspend this "
        "throw true try typealias val var vararg when where while coroutine"
    ).split(),
}

BIBLIOTHEQUES = {
    "swift": (
        "print debugPrint fatalError assert precondition exit Array Dictionary Set String Int UInt "
        "Double Float Bool Character Optional Result Range ClosedRange stride zip map flatMap filter "
        "reduce sorted compactMap firstIndex lastIndex min max abs swap sleep Task await"
    ).split(),
    "kotlin": (
        "println print arrayOf listOf mutableListOf mapOf mutableMapOf setOf mutableSetOf require "
        "check error TODO emptyList emptyMap emptySet readLine run let apply also with repeat "
        "sequenceOf lazy buildList buildString minOf maxOf abs sortedBy groupBy"
    ).split(),
}

EXTRAITS = {
    "swift": [
        ["func", "func ${1:nom}(${2:}) ${3:-> Void} {\n\t${4}\n}", "Fonction"],
        ["struct", "struct ${1:Nom} {\n\t${2}\n}", "Structure"],
        ["class", "class ${1:Nom} {\n\tinit() {\n\t\t${2}\n\t}\n}", "Classe"],
        ["protocol", "protocol ${1:Nom} {\n\t${2}\n}", "Protocole"],
        ["extension", "extension ${1:Type} {\n\t${2}\n}", "Extension"],
        ["enum", "enum ${1:Nom} {\n\tcase ${2:valeur}\n}", "Énumération"],
        ["forin", "for ${1:element} in ${2:collection} {\n\t${3}\n}", "Boucle for-in"],
        ["iflet", "if let ${1:valeur} = ${2:optionnel} {\n\t${3}\n}", "Déballage optionnel"],
        ["guard", "guard ${1:condition} else {\n\treturn${2}\n}\n${3}", "Guard"],
        ["docatch", "do {\n\ttry ${1}\n} catch {\n\t${2}\n}", "Gestion d'erreur"],
    ],
    "kotlin": [
        ["main", "fun main() {\n\t${1:println(\"Bonjour\")}\n}", "Point d'entrée"],
        ["fun", "fun ${1:nom}(${2:}): ${3:Unit} {\n\t${4}\n}", "Fonction"],
        ["class", "class ${1:Nom}(${2:}) {\n\t${3}\n}", "Classe"],
        ["dataclass", "data class ${1:Nom}(\n\tval ${2:champ}: ${3:String}\n)", "Data class"],
        ["object", "object ${1:Nom} {\n\t${2}\n}", "Objet (singleton)"],
        ["companion", "companion object {\n\t${1}\n}", "Companion object"],
        ["when", "when (${1:valeur}) {\n\t${2:cas} -> ${3}\n\telse -> ${4}\n}", "When"],
        ["forin", "for (${1:element} in ${2:collection}) {\n\t${3}\n}", "Boucle for"],
        ["trycatch", "try {\n\t${1}\n} catch (e: Exception) {\n\t${2}\n}", "Gestion d'erreur"],
        ["letscope", "${1:valeur}.let {\n\t${2}\n}", "let (portée)"],
    ],
}

MEMBRES = {
    "swift": {
        "Array": "append insert removeFirst removeLast count isEmpty first last sorted reversed contains filter map reduce joined",
        "String": "count isEmpty uppercased lowercased split joined hasPrefix hasSuffix trimmingCharacters components replacingOccurrences",
        "Dictionary": "keys values removeValue updateValue count isEmpty sorted",
        "Optional": "map flatMap unwrap nil",
        "Result": "success failure get",
        "Task": "sleep yield detached",
        "FileManager": "default contentsOfDirectory createFile removeItem fileExists",
        "print": "separator terminator",
    },
    "kotlin": {
        "System": "out err exit gc currentTimeMillis",
        "String": "length uppercase lowercase trim split replace toInt toDouble toBoolean contains startsWith",
        "Collections": "sort reverse shuffle binarySearch max min sum",
        "List": "size get contains first last sorted reversed filter map forEach indexOf",
        "Map": "keys values get put remove containsKey size entries",
        "File": "readText writeText exists length walkText",
    },
}


def js(obj):
    """Sérialise en littéral JavaScript : une chaîne JSON est une chaîne JS valide."""
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def tables_completion():
    parts = [
        "Object.assign(eUe,%s);" % js(MOTS_CLES),
        "Object.assign(Zie,%s);" % js(BIBLIOTHEQUES),
        "Object.assign(tUe,%s);" % js(EXTRAITS),
        "Object.assign(Xie,%s);" % js(
            {lang: {cle: membres.split() for cle, membres in table.items()}
             for lang, table in MEMBRES.items()}),
    ]
    return "".join(parts)


# --------------------------------------------------------------------------
# 3. Dialogue « Nouveau fichier » : la liste des types remplace l'invite texte.
#    window.PSNewFileDialog est fourni par nouveau-fichier.js (chargé depuis
#    index.html) ; s'il est absent, on retombe sur l'invite d'origine.
# --------------------------------------------------------------------------
OC_DEBUT = "Oc=async O=>{"
OC_FIN = "},Ld=async O=>"

NOUVEL_OC = (
    'Oc=async O=>{let Q="",et="";'
    'if(O==="file"&&window.PSNewFileDialog){'
    'let Fe=await window.PSNewFileDialog({defaultType:"pascal"});'
    'if(!Fe)return;Q=Fe.path;et=Fe.content||""}'
    'else{let Fe=await Mn(O==="folder"?"Nom du dossier (chemin relatif au projet) :"'
    ':"Nom du fichier (ex. calcul.pas) :");if(!Fe)return;Q=Fe;'
    'et=window.PSNewFileTemplate?window.PSNewFileTemplate(Q):""}'
    'try{await ki("create",{path:Q,type:O,content:et}),await ml(),'
    'O==="file"?(As.current=!0,await Oa(Q))'
    ':requestAnimationFrame(()=>{var Fe;(Fe=$s.current)==null||Fe.focus()})}'
    'catch(pe){$(pe.message)}}'
)

# --------------------------------------------------------------------------
# 4. Tableau des remplacements par ancrage exact : (ancien, nouveau, nb attendu)
# --------------------------------------------------------------------------
def edits():
    return [
        # --- Monaco -------------------------------------------------------
        ("Enregistrement Monaco swift/kotlin",
         ANCRE_MONACO, ANCRE_MONACO + NOUVEAU_MONACO, 1),

        # --- détection du langage ----------------------------------------
        ("vr : extension .swift/.kt vers le langage",
         r'/\.lua$/i.test(e)?"lua":/\.rs$/i.test(e)?"rust":',
         r'/\.lua$/i.test(e)?"lua":/\.swift$/i.test(e)?"swift":'
         r'/\.kts?$/i.test(e)?"kotlin":/\.rs$/i.test(e)?"rust":', 1),

        ("MN : sources prises en charge",
         "|ml|mli|lua|js|mjs|cjs|html|htm|css|php)$/i.test(e)",
         "|ml|mli|lua|swift|kt|kts|js|mjs|cjs|html|htm|css|php)$/i.test(e)", 1),

        # --- libellés et badges -------------------------------------------
        ("oUe : libellés affichés",
         'ocaml:"OCaml",lua:"Lua",latex:"LaTeX",',
         'ocaml:"OCaml",lua:"Lua",swift:"Swift",kotlin:"Kotlin",latex:"LaTeX",', 1),

        ("Fe : badges de l'arborescence (puis logo CSS)",
         'lua:["Lua","Lua"],rust:["Rs","Rust"],',
         'lua:["Lua","Lua"],swift:["Sw","Swift"],kotlin:["Kt","Kotlin"],rust:["Rs","Rust"],', 1),

        # --- auto-complétion ----------------------------------------------
        ("Langages servis par l'auto-complétion",
         '"perl","basic","ocaml","lua"];for(const t of e)o.languages.registerCompletionItemProvider',
         '"perl","basic","ocaml","lua","swift","kotlin"];'
         'for(const t of e)o.languages.registerCompletionItemProvider', 1),

        ("Tables de complétion swift/kotlin",
         "iUe(Mk);const ki=", tables_completion() + "iUe(Mk);const ki=", 1),

        # --- analyse en direct et compilation ------------------------------
        ("Contenus envoyés à l'analyse",
         '"fortran","perl","basic","ocaml","lua"].includes(vr(pe.path))',
         '"fortran","perl","basic","ocaml","lua","swift","kotlin"].includes(vr(pe.path))', 1),

        ("Analyse en direct activée",
         '["c","cpp","python","javascript","php","ruby","rust","go","fortran","perl",'
         '"basic","ocaml","lua"].includes(et)',
         '["c","cpp","python","javascript","php","ruby","rust","go","fortran","perl",'
         '"basic","ocaml","lua","swift","kotlin"].includes(et)', 1),

        # Présent deux fois : disponibilité de l'outil + message d'installation.
        ("Disponibilité de l'outil du langage",
         '["fortran","perl","basic","ocaml","lua"].includes(et)',
         '["fortran","perl","basic","ocaml","lua","swift","kotlin"].includes(et)', 2),

        ("Fichiers envoyés à l'analyse par lot",
         '"fortran","perl","basic","ocaml","lua"].includes(vr(pa.path))',
         '"fortran","perl","basic","ocaml","lua","swift","kotlin"].includes(vr(pa.path))', 1),

        ("Décorations de l'éditeur",
         '"fortran","perl","basic","ocaml","lua"].includes(St.getLanguageId())',
         '"fortran","perl","basic","ocaml","lua","swift","kotlin"].includes(St.getLanguageId())', 1),

        ("Diagnostics de compilation filtrés",
         '["go","rust","fortran","ocaml"].includes(pe.kind)',
         '["go","rust","fortran","ocaml","swift","kotlin"].includes(pe.kind)', 1),

        ("Diagnostics de recompilation filtrés",
         '["go","rust","fortran"].includes(Q.kind)',
         '["go","rust","fortran","swift","kotlin"].includes(Q.kind)', 1),

        ("Dépendances d'état de /api/status",
         "n==null?void 0:n.lua,X,ys]",
         "n==null?void 0:n.lua,n==null?void 0:n.swift,n==null?void 0:n.kotlin,X,ys]", 1),

        # Volontairement absent : la liste du débogueur. Swift et Kotlin ne sont
        # pas pris en charge par /api/debug (voir server.py), les points d'arrêt
        # resteraient inactifs et le message d'aide deviendrait faux.
    ]


GARDE = 'Vh({id:"swift"'


def corriger(source):
    """Applique tous les ancrages. Lève ValueError si l'un d'eux dérive."""
    if GARDE in source:
        return source, 0, True
    modifie = 0
    for titre, ancien, nouveau, attendu in edits():
        trouve = source.count(ancien)
        if trouve != attendu:
            raise ValueError(
                "Ancrage introuvable ou ambigu — %s : trouvé %d fois, attendu %d.\n"
                "Le bundle a probablement changé de version ; aucune modification "
                "n'a été écrite." % (titre, trouve, attendu))
        source = source.replace(ancien, nouveau)
        modifie += 1

    # Dialogue « Nouveau fichier » : remplacement par bornes, car le corps
    # contient des sauts de ligne réels dans un gabarit JS.
    debut = source.find(OC_DEBUT)
    if debut < 0:
        raise ValueError("Ancrage introuvable — dialogue Nouveau fichier : début.")
    fin = source.find(OC_FIN, debut)
    if fin < 0:
        raise ValueError("Ancrage introuvable — dialogue Nouveau fichier : fin.")
    ancien_oc = source[debut:fin + 1]
    if ancien_oc.count("ki(\"create\"") != 1 or "Mn(" not in ancien_oc:
        raise ValueError(
            "Le corps de la fonction « nouveau fichier » n'a pas la forme attendue ; "
            "aucune modification n'a été écrite.")
    source = source[:debut] + NOUVEL_OC + source[fin + 1:]
    return source, modifie + 1, False


def verifier(source):
    """Contrôle qu'un bundle déjà corrigé contient bien tous les ajouts."""
    manquants = []
    controles = [
        ("Monaco swift", 'Vh({id:"swift",extensions:[".swift"]'),
        ("Monaco kotlin", 'Vh({id:"kotlin",extensions:[".kt",".kts"]'),
        ("vr swift", r'/\.swift$/i.test(e)?"swift"'),
        ("vr kotlin", r'/\.kts?$/i.test(e)?"kotlin"'),
        ("MN", "|lua|swift|kt|kts|js|"),
        ("libellé Swift", 'swift:"Swift"'),
        ("libellé Kotlin", 'kotlin:"Kotlin"'),
        ("badge Swift", 'swift:["Sw","Swift"]'),
        ("badge Kotlin", 'kotlin:["Kt","Kotlin"]'),
        ("complétion", '"ocaml","lua","swift","kotlin"]'),
        ("mots-clés", '"swift":["associatedtype"'),
        ("dialogue", "window.PSNewFileDialog("),
        ("status", "n==null?void 0:n.swift"),
    ]
    for titre, texte in controles:
        if texte not in source:
            manquants.append(titre)
    # La 3.6.0 laissait la liste du débogueur inchangée (10 langages). La 3.7.0
    # l'élargit volontairement à 27 langages : ce contrôle accepte donc l'une ou
    # l'autre, sans quoi reconditionner-3.6.0.sh échouerait sur un bundle déjà
    # passé en 3.7.0.
    liste_36 = '["pascal","c","cpp","python","javascript","php","rust","go","ruby","fortran"].includes(vr(O))'
    liste_37 = '"csharp","makefile","cmake","latex"'
    if liste_36 not in source and liste_37 not in source:
        manquants.append("liste du débogueur (3.6.0 ou 3.7.0 attendue)")
    return manquants


def main(argv):
    verifier_seul = False
    if argv and argv[0] == "--verifier":
        verifier_seul = True
        argv = argv[1:]
    if len(argv) != 1:
        sys.stderr.write(__doc__)
        return 2
    chemin = argv[0]
    with io.open(chemin, encoding="utf8") as f:
        source = f.read()
    taille_avant = len(source)

    if verifier_seul:
        manquants = verifier(source)
        if manquants:
            print("INCOMPLET : %s" % ", ".join(manquants))
            return 1
        print("Bundle 3.6.0 complet (%d caractères)." % taille_avant)
        return 0

    try:
        resultat, nb, deja = corriger(source)
    except ValueError as erreur:
        sys.stderr.write("ERREUR : %s\n" % erreur)
        return 1

    if deja:
        print("Bundle déjà corrigé, rien à faire (%d caractères)." % taille_avant)
        return 0

    manquants = verifier(resultat)
    if manquants:
        sys.stderr.write("ERREUR : contrôle final incomplet — %s\n" % ", ".join(manquants))
        return 1

    with io.open(chemin, "w", encoding="utf8") as f:
        f.write(resultat)
    print("%d ancrages appliqués : %d -> %d caractères (+%d)."
          % (nb, taille_avant, len(resultat), len(resultat) - taille_avant))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
