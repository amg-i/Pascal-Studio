#!/usr/bin/env python3
"""Diagnostics LaTeX en direct et persistance des erreurs de compilation."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(a,b):
 global s
 n=s.count(a)
 if n!=1:raise SystemExit(f'Ancre non unique : {n} {a[:130]}')
 s=s.replace(a,b,1)
change('St=Fe&&MN(Fe.path)&&(["c","cpp","python","javascript","php","ruby","rust","go"].includes(et)||et==="pascal")', 'St=Fe&&(et==="latex"||MN(Fe.path)&&(["c","cpp","python","javascript","php","ruby","rust","go"].includes(et)||et==="pascal"))')
change('if(!(et==="pascal"?n.fpc:', 'if(!(et==="latex"?!0:et==="pascal"?n.fpc:')
change('r.filter(pa=>["pascal","c","cpp","python","javascript","php","ruby","rust","go"].includes(vr(pa.path)))', 'r.filter(pa=>["pascal","c","cpp","python","javascript","php","ruby","rust","go","latex"].includes(vr(pa.path)))')
change('return current&&current.content===d._snapshot});return next.length===ds.length?ds:next})},[r,n==null?void 0:n.workspace])', 'return (!d._latexDeps||d._latexDeps.every(dep=>{const now=r.find(x=>x.path===dep.path);return !now||now.content===dep.content}))&&(current?current.content===d._snapshot:d._keepClosed===!0)});return next.length===ds.length?ds:next})},[r,n==null?void 0:n.workspace])')
change('const pe=await ki(O?"run":"compile",{path:Q});D(pe.output||""),R(pe.diagnostics||[]),setBuildDiag(["go","rust"].includes(pe.kind)?(pe.diagnostics||[]).filter(x=>x.file===Q&&Qi.current.some(t=>t.path===Q)).map(x=>({...x,_snapshot:Qi.current.find(t=>t.path===Q).content})):[])', '''const latexDeps=Qi.current.filter(x=>vr(x.path)==="latex").map(x=>({path:x.path,content:x.content})),pe=await ki(O?"run":"compile",{path:Q});let latexBuild=[];if(pe.kind==="latex")latexBuild=(await Promise.all((pe.diagnostics||[]).map(async d=>{try{if(!d.sourceHash)return null;const open=Qi.current.find(x=>x.path===d.file);const content=open?open.content:(await ki("file?path="+encodeURIComponent(d.file))).content;const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(content));const hash=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("");if(hash!==d.sourceHash)return null;return {...d,_snapshot:content,_keepClosed:!0,_latexDeps:latexDeps}}catch{return null}}))).filter(Boolean);D(pe.output||""),R(pe.diagnostics||[]),setBuildDiag(pe.kind==="latex"?latexBuild:["go","rust"].includes(pe.kind)?(pe.diagnostics||[]).filter(x=>x.file===Q&&Qi.current.some(t=>t.path===Q)).map(x=>({...x,_snapshot:Qi.current.find(t=>t.path===Q).content})):[])''')
change(':(p("build"),$("La compilation a échoué"))}catch(pe)', ':(p("build"),$(pe.noPages?"Aucune page PDF produite":"La compilation a échoué"))}catch(pe)')
p.write_text(s,encoding='utf8')
