"""Patch ciblé du bundle PC 2.2.2 : diagnostics Python non bloquants et tracebacks."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(old,new):
 global s
 n=s.count(old)
 if n!=1:raise SystemExit(f'Bundle inattendu ({n} occurrences) : {old[:100]}')
 s=s.replace(old,new,1)
change('[I,R]=Ee.useState([]),[P,F]=Ee.useState({running:!1,output:"",exitCode:null})', '[I,R]=Ee.useState([]),[pyRuntime,setPyRuntime]=Ee.useState([]),pySeen=Ee.useRef(null),[P,F]=Ee.useState({running:!1,output:"",exitCode:null})')
anchor='Ee.useEffect(()=>{Lu.current&&(Lu.current.scrollTop=Lu.current.scrollHeight)},[P.output,L,f]);'
effect='''Ee.useEffect(()=>{let cancelled=!1;if(!P.running&&P.exitCode!==null&&P.runId&&pySeen.current!==P.runId){pySeen.current=P.runId;const rows=P.diagnostics||[];if(rows.length)(async()=>{const result=await Promise.all(rows.map(async d=>{try{if(!d.sourceHash||!globalThis.crypto?.subtle)return null;const open=Qi.current.find(x=>x.path===d.file),text=open?open.content:(await ki("file?path="+encodeURIComponent(d.file))).content;const bytes=await crypto.subtle.digest("SHA-256",new TextEncoder().encode(text)),hash=Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,"0")).join("");const now=Qi.current.find(x=>x.path===d.file);if(hash!==d.sourceHash||now&&now.content!==text)return null;return {...d,_snapshot:text}}catch{return null}}));if(!cancelled)setPyRuntime(result.filter(Boolean))})();else setPyRuntime([])}return()=>{cancelled=!0}},[P.runId,P.running,P.exitCode]);Ee.useEffect(()=>{setPyRuntime(ds=>{const next=ds.filter(d=>{const current=r.find(x=>x.path===d.file);return !current||current.content===d._snapshot});return next.length===ds.length?ds:next})},[r]);Ee.useEffect(()=>{setPyRuntime([])},[n==null?void 0:n.workspace]);'''
change(anchor,anchor+effect)
change('rb.setModelMarkers(O,"fpc",I.filter(et=>et.file===Fe).map(et=>({startLineNumber:et.line,startColumn:et.column,endLineNumber:et.line,endColumn:et.column+1,message:et.message,severity:/fatal|error/i.test(et.severity)?cI.Error:/warning/i.test(et.severity)?cI.Warning:cI.Info})))', 'rb.setModelMarkers(O,"fpc",I.concat(pyRuntime).filter(et=>et.file===Fe).map(et=>({startLineNumber:et.line,startColumn:et.column,endLineNumber:et.endLine||et.line,endColumn:et.endColumn||et.column+1,message:et.message,severity:/fatal|error/i.test(et.severity)?cI.Error:/warning/i.test(et.severity)?cI.Warning:cI.Info})))')
change('}},[I,l,n==null?void 0:n.workspace]),Ee.useEffect(()=>{var Q,pe;if(!$s.current)return;', '}},[I,pyRuntime,l,n==null?void 0:n.workspace]),Ee.useEffect(()=>{var Q,pe;if(!$s.current)return;')
change('t_=I.filter(O=>/error|fatal/i.test(O.severity)).length,DS=I.filter(O=>/warning/i.test(O.severity)).length', 't_=I.concat(pyRuntime).filter(O=>/error|fatal/i.test(O.severity)).length,DS=I.concat(pyRuntime).filter(O=>/warning/i.test(O.severity)).length')
change('" Problèmes ",T.createElement("span",{className:"count"},I.length)', '" Problèmes ",T.createElement("span",{className:"count"},I.length+pyRuntime.length)')
change('I.length?I.map((O,Q)=>T.createElement("button",{className:"diagnostic",key:Q,onClick:()=>e_(O)}', 'I.length+pyRuntime.length?I.concat(pyRuntime).map((O,Q)=>T.createElement("button",{className:"diagnostic",key:Q,onClick:()=>e_(O)}')
change('te(!0),C(!0),p(O?"run":"build"),R([]),D("Construction de "+Q+', 'te(!0),C(!0),p(O?"run":"build"),R([]),setPyRuntime([]),D("Construction de "+Q+')
change('C(!0),p("debug"),te(!0),$("Préparation du débogage…")', 'C(!0),p("debug"),te(!0),setPyRuntime([]),$("Préparation du débogage…")')
change('" Diagnostics du compilateur"','" Diagnostics et exécution"')
change('P.output?T.createElement("pre",{className:"console-output"},P.output)','P.output?T.createElement("pre",{className:"console-output"},P.kind==="python"?P.output.replace(/\\x1b\\[[0-?]*[ -/]*[@-~]/g,"").replace(/\\r\\n/g,"\\n").split("\\n").map((line,index,lines)=>T.createElement("span",{key:index,style:{color:/^Traceback |^\\s*File "|^\\s*[~^]+|^[\\w.]+(?:Error|Exception|Interrupt)(?::|$)/.test(line)?"#ff777f":/\\b[A-Za-z]+Warning:/.test(line)?"#f1c969":void 0}},line,index<lines.length-1?"\\n":"")):P.output)')
p.write_text(s,encoding='utf8')
