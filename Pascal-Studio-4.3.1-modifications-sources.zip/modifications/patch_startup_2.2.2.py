"""Patch ciblé du bundle 2.2.1, avec vérification des occurrences."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
changes = [('ml=Ee.useCallback(async()=>{try{i((await ki("tree")).tree),s(await ki("status"))}catch(O){$("Serveur indisponible : "+O.message)}},[])', 'ml=Ee.useCallback(async()=>{try{await Promise.all([ki("tree").then(O=>i(O.tree)),ki("status").then(s)])}catch(O){$("Serveur indisponible : "+O.message)}},[])'), ('Ee.useEffect(()=>{ml(),(async()=>{try{const O=(await ki("tree")).tree,Q=et=>et.flatMap(St=>St.type==="folder"?Q(St.children||[]):[St]),pe=Q(O),Fe=pe.find(et=>et.path==="main.pas")||pe.find(et=>/\\.(pas|pp|p|lpr)$/i.test(et.path));if(Fe){const et=await ki("file?path="+encodeURIComponent(Fe.path));a([{path:Fe.path,content:et.content,saved:et.content}]),c(Fe.path)}}catch{}})()},[])', 'Ee.useEffect(()=>{ml(),(async()=>{try{const et=await ki("file?path=main.pas");a([{path:"main.pas",content:et.content,saved:et.content}]),c("main.pas");return}catch{}try{const O=(await ki("tree")).tree,Q=et=>et.flatMap(St=>St.type==="folder"?Q(St.children||[]):[St]),pe=Q(O),Fe=pe.find(et=>/\\.(pas|pp|p|lpr)$/i.test(et.path));if(Fe){const et=await ki("file?path="+encodeURIComponent(Fe.path));a([{path:Fe.path,content:et.content,saved:et.content}]),c(Fe.path)}}catch{}})()},[])'), ('kS=O=>O.flatMap(Q=>Q.type==="file"?[Q]:kS(Q.children||[])),If=kS(t),', 'kS=O=>O.flatMap(Q=>Q.type==="file"?[Q]:kS(Q.children||[])),If=Ee.useMemo(()=>kS(t),[t]),')]
for old,new in changes:
 if s.count(old)!=1:raise SystemExit('Bundle inattendu : patch non appliqué.')
 s=s.replace(old,new,1)
p.write_text(s,encoding='utf8')
