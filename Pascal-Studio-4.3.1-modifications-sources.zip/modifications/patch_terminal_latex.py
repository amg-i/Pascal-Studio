#!/usr/bin/env python3
"""Patch contrôlé du bundle React 2.5 : terminal, types de fichiers et LaTeX."""
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text(encoding='utf8')
def change(a,b):
 global s
 count=s.count(a)
 if count!=1:raise SystemExit(f'Ancre non unique ({count}): {a[:180]!r}')
 s=s.replace(a,b,1)
change('oUe={rust:"Rust"','oUe={latex:"LaTeX",rust:"Rust"')
change('/\\.rb$/i.test(e)?"ruby":/\\.py$/i.test(e)?"python"','/\\.rb$/i.test(e)?"ruby":/\\.(tex|sty)$/i.test(e)?"latex":/\\.py$/i.test(e)?"python"')
change('csproj|mk|md|py|rs|go|rb|js', 'csproj|mk|md|tex|py|rs|go|rb|js')
change('const Q=/\\.csproj$/i.test(O)?"csharp":vr(O),Fe={pascal:', 'const Q=/\\.csproj$/i.test(O)?"csharp":/\\.txt$/i.test(O)&&O.split("/").pop()!=="CMakeLists.txt"?"textfile":vr(O),Fe={latex:["TₑX","LaTeX"],textfile:["TXT","Texte"],pascal:')
# Enregistrer une grammaire locale légère : commandes, mathématiques, commentaires.
tokenizer=r'''Mk.languages.register({id:"latex",extensions:[".tex",".sty"],aliases:["LaTeX"]});Mk.languages.setMonarchTokensProvider("latex",{tokenizer:{root:[[/\\[%$#&_{}]/,"string.escape"],[/%.*$/,"comment"],[/\\[a-zA-Z@]+\*?/,"keyword"],[/\\./,"keyword"],[/\$\$/, {token:"string",next:"@displaymath"}],[/\$/, {token:"string",next:"@math"}],[/[{}\[\]]/,"delimiter.bracket"]],math:[[/\\./,"keyword"],[/\$/, {token:"string",next:"@pop"}],[/[^\\$]+/,"string"]],displaymath:[[/\$\$/, {token:"string",next:"@pop"}],[/\\./,"keyword"],[/[^\\$]+/,"string"],[/\$/, "string"]]}});Mk.languages.setLanguageConfiguration("latex",{comments:{lineComment:"%"},brackets:[["{","}"],["[","]"]],autoClosingPairs:[{open:"{",close:"}"},{open:"[",close:"]"}]});Mk.languages.registerCompletionItemProvider("latex",{triggerCharacters:["\\"],provideCompletionItems:(m,pos)=>{const w=m.getWordUntilPosition(pos),before=m.getLineContent(pos.lineNumber).slice(0,w.startColumn-1),slash=before.endsWith("\\"),r={startLineNumber:pos.lineNumber,endLineNumber:pos.lineNumber,startColumn:w.startColumn,endColumn:pos.column};return{suggestions:["documentclass","usepackage","begin","end","section","subsection","textbf","emph","item","includegraphics","label","ref","cite","frac","sqrt"].map(x=>({label:"\\"+x,kind:Mk.languages.CompletionItemKind.Function,insertText:(slash?"":"\\")+x,range:r,detail:"Commande LaTeX"}))}}});'''
change('iUe(Mk);const ki=',tokenizer+'iUe(Mk);const ki=')
change('...(window.PS_LANG_HELP?.languages||[])],articles:', '...(window.PS_LANG_HELP?.languages||[]),...(window.PS_LATEX_HELP?.languages||[])],articles:')
change('...(window.PS_EXTRA_HELP?.articles||[])]},wie=', '...(window.PS_EXTRA_HELP?.articles||[]),...(window.PS_LATEX_HELP?.articles||[])]},wie=')
change('["c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby"].includes(St.getLanguageId())','["c","cpp","csharp","python","javascript","html","css","php","rust","go","ruby","latex"].includes(St.getLanguageId())')
change('className:"bottom-panel "+(f==="debug"?"debug-bottom":"")', 'className:"bottom-panel "+(f==="debug"?"debug-bottom":f==="terminal"?"terminal-bottom":"")')
change('T.createElement("div",{className:"panel-spacer"}),T.createElement("button",{title:"Effacer la sortie de compilation"', 'T.createElement("button",{className:f==="terminal"?"active":"",onClick:()=>p("terminal"),title:"Terminal intégré"},"❯_ Terminal"),T.createElement("div",{className:"panel-spacer"}),T.createElement("button",{title:"Effacer la sortie de compilation"')
change('className:"panel-content",ref:Lu},f==="run"?', 'className:"panel-content",ref:Lu},f==="terminal"?T.createElement("div",{className:"ps-terminal-host"}):f==="run"?')
# A shortcut entry makes the terminal accessible even when the bottom panel is closed.
change('{name:"Aide",items:[["Aide des langages"', '{name:"Outils",items:[["Terminal intégré","",()=>{C(!0),p("terminal")}]]},{name:"Aide",items:[["Aide des langages"')
change('className:"run-button",onClick:()=>fa(!0),disabled:X||P.running},T.createElement(DN,{size:15,fill:"currentColor"})," ",T.createElement("span",null,"Exécuter"),T.createElement("kbd",null,"F9")', 'className:"run-button",onClick:()=>fa(!0),disabled:X||P.running},T.createElement(DN,{size:15,fill:"currentColor"})," ",T.createElement("span",null,/\\.tex$/i.test(Ye||l||"")?"PDF LaTeX":vr(Ye||l)==="markdown"?"Aperçu":"Exécuter"),T.createElement("kbd",null,"F9")')
# Run creates a cached PDF; compile without running leaves the log visible.
change('pe.ok?O&&Array.isArray(pe.candidates)?', 'pe.ok?pe.kind==="latex"?(p("build"),$("PDF LaTeX généré dans le cache"),O&&pe.pdfId&&window.PSOpenLatexPdf?.(pe.pdfId,Q)):O&&Array.isArray(pe.candidates)?')
change('if(["rust","go"].includes(et)&&Fe){if(!nativeBuildSeen', 'if(["rust","go","latex"].includes(et)&&Fe){if(!nativeBuildSeen')
change('Vi(et==="csharp"?"Analyse C# disponible à la compilation":["rust","go"].includes(et)?', 'Vi(et==="latex"?"Diagnostics LaTeX à la compilation":et==="csharp"?"Analyse C# disponible à la compilation":["rust","go"].includes(et)?')
change('["rust","go"].includes(et)||R([]);return}nativeBuildSeen.current=null;', '["rust","go","latex"].includes(et)||R([]);return}nativeBuildSeen.current=null;')
p.write_text(s,encoding='utf8')
