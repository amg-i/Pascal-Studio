import * as pdfjs from 'pdfjs-dist/build/pdf.mjs';
pdfjs.GlobalWorkerOptions.workerSrc='/assets/pdf.worker.mjs';
window.PSOpenLatexPdf=async function(id,filename){
 let old=document.getElementById('ps-pdf-overlay');if(old)old.remove();
 const el=(tag,cl,text)=>{let n=document.createElement(tag);if(cl)n.className=cl;if(text!==undefined)n.textContent=text;return n};
 const overlay=el('section','ps-pdf-overlay');overlay.id='ps-pdf-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-label','Aperçu PDF LaTeX');
 let head=el('header','ps-pdf-head'),title=el('strong','',`Aperçu PDF · ${filename.split('/').pop()}`),prev=el('button','','← Page'),next=el('button','','Page →'),count=el('span','','Chargement…'),minus=el('button','','−'),plus=el('button','','+'),save=el('button','','Enregistrer le PDF sous…'),close=el('button','','Fermer');
 for(const b of [prev,next,minus,plus,save,close])b.type='button';head.append(title,prev,next,count,minus,plus,save,close);const area=el('div','ps-pdf-area'),canvas=el('canvas','ps-pdf-canvas'),msg=el('div','ps-pdf-message','Chargement du PDF…');area.append(canvas,msg);overlay.append(head,area);document.body.append(overlay);
 let doc=null,page=1,scale=1.25,renderTask=null,generation=0;
 const cancel=()=>{generation++;if(renderTask){try{renderTask.cancel()}catch{}}};
 const dismiss=()=>{cancel();overlay.remove();if(doc)doc.destroy()};close.onclick=dismiss;
 overlay.addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();dismiss()}});
 async function render(){
  if(!doc)return;cancel();const n=generation;msg.textContent='Chargement…';try{let p=await doc.getPage(page);if(n!==generation)return;let vp=p.getViewport({scale});let pixel=Math.min(window.devicePixelRatio||1,2);canvas.width=Math.ceil(vp.width*pixel);canvas.height=Math.ceil(vp.height*pixel);canvas.style.width=vp.width+'px';canvas.style.height=vp.height+'px';renderTask=p.render({canvasContext:canvas.getContext('2d'),viewport:vp,transform:pixel===1?null:[pixel,0,0,pixel,0,0]});await renderTask.promise;if(n!==generation)return;msg.textContent='';count.textContent=`${page} / ${doc.numPages} · ${Math.round(scale*100)} %`;prev.disabled=page<=1;next.disabled=page>=doc.numPages}catch(e){if(e.name!=='RenderingCancelledException')msg.textContent='Aperçu impossible : '+e.message}
 }
 prev.onclick=()=>{if(page>1){page--;render()}};next.onclick=()=>{if(doc&&page<doc.numPages){page++;render()}};minus.onclick=()=>{scale=Math.max(.5,scale-.2);render()};plus.onclick=()=>{scale=Math.min(3,scale+.2);render()};
 save.onclick=async()=>{try{if(!window.pascalDesktop?.saveLatexPdf)throw Error('Enregistrement disponible dans l’AppImage.');let result=await window.pascalDesktop.saveLatexPdf(id,filename.split('/').pop().replace(/\.tex$/i,'.pdf'));if(result)msg.textContent='PDF enregistré : '+result}catch(e){msg.textContent='Enregistrement impossible : '+e.message}};
 try{doc=await pdfjs.getDocument('/api/latex/pdf?id='+encodeURIComponent(id)).promise;if(!overlay.isConnected){doc.destroy();return}await render();close.focus()}catch(e){msg.textContent='Aperçu impossible : '+e.message}
};
