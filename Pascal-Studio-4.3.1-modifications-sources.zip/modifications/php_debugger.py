"""Xdebug/DBGp adapter for locally executed PHP CLI files (not web requests)."""
import base64, os, pty, queue, secrets, shutil, signal, socket, subprocess, termios, threading, time, urllib.parse, xml.etree.ElementTree as ET
from pathlib import Path
NS={'d':'urn:debugger_protocol_v1'}

def tag(e):return e.tag.rsplit('}',1)[-1]
def value(prop):
 t=prop.get('type','');s=prop.text or ''
 if prop.get('encoding')=='base64':
  try:s=base64.b64decode(s).decode('utf8','replace')
  except Exception:s='?'
 if prop.get('children')=='1':return f'{t} ({prop.get("numchildren","?")} éléments)'
 return s[:500] if t!='null' else 'null'

class PhpDebugger:
 def __init__(self,root,external_files=None):
  self.root=Path(root).resolve();self.external_files=external_files if external_files is not None else {};self.lock=threading.RLock();self.sendlock=threading.Lock();self.stoplock=threading.Lock();self.proc=None;self.conn=None;self.server=None;self.master=None;self.pending={};self.seq=0;self.bpmap={};self.continuations=set()
  self.data={'active':False,'state':'idle','reason':'','frame':None,'frames':[],'variables':[],'output':'','message':'','breakpoints':[]}
 def snapshot(self):
  with self.lock:return dict(self.data)
 def file(self,key):
  if not isinstance(key,str):raise ValueError('Fichier invalide.')
  p=self.external_files.get(key) if key.startswith('@external:') else (self.root/key).resolve()
  if p is None or (not key.startswith('@external:') and not p.is_relative_to(self.root)) or not p.is_file():raise ValueError('Fichier de point d’arrêt invalide.')
  return Path(p).resolve()
 def key(self,url):
  if not url.startswith('file://'):return ''
  p=Path(urllib.parse.unquote(urllib.parse.urlparse(url).path)).resolve()
  try:return p.relative_to(self.root).as_posix()
  except ValueError:return next((k for k,v in self.external_files.items() if Path(v).resolve()==p),'')
 def _output(self,text):
  with self.lock:self.data['output']=(self.data['output']+text)[-2_000_000:]
 def send(self,cmd,args='',payload=None,continuation=False):
  with self.lock:
   if not self.conn:raise ValueError('Session PHP inactive.')
   self.seq+=1;n=self.seq;q=queue.Queue(1);self.pending[str(n)]=q
   if continuation:self.continuations.add(str(n))
  command=f'{cmd} -i {n}'+(' '+args if args else '')+(' -- '+base64.b64encode(payload.encode()).decode() if payload is not None else '')+'\0'
  with self.sendlock:self.conn.sendall(command.encode())
  return str(n),q
 def request(self,cmd,args='',payload=None):
  n,q=self.send(cmd,args,payload)
  try:
   try:r=q.get(timeout=8)
   except queue.Empty:raise ValueError('Xdebug ne répond pas.')
   err=next((x for x in r if tag(x)=='error'),None)
   if err is not None:
    msg=next((x.text for x in err if tag(x)=='message'),'Erreur Xdebug');raise ValueError(msg)
   return r
  finally:
   with self.lock:self.pending.pop(n,None)
 def listen(self,conn,proc):
  buf=b''
  try:
   while True:
    part=conn.recv(65536)
    if not part:break
    buf+=part
    while b'\0' in buf:
     header,_,tail=buf.partition(b'\0')
     try:length=int(header)
     except ValueError:raise ValueError('Trame DBGp invalide.')
     if length>8_000_000:raise ValueError('Trame DBGp trop volumineuse.')
     if len(tail)<length+1:break
     if tail[length:length+1]!=b'\0':raise ValueError('Trame DBGp invalide.')
     packet=tail[:length];buf=tail[length+1:];elem=ET.fromstring(packet);ident=elem.get('transaction_id')
     if not ident:continue
     with self.lock:
      q=self.pending.get(ident);is_cont=ident in self.continuations
      if is_cont:self.continuations.discard(ident);self.pending.pop(ident,None)
     if is_cont:
      if elem.get('status')=='break':threading.Thread(target=self.inspect,args=(proc,),daemon=True).start()
      elif elem.get('status') in ('stopped','stopping'):threading.Thread(target=self._finish,args=(proc,),daemon=True).start()
     elif q:q.put(elem)
  except (OSError,ValueError,ET.ParseError):pass
 def inspect(self,proc):
  try:
   resp=self.request('stack_get');frames=[]
   for f in resp:
    if tag(f)=='stack':frames.append({'file':self.key(f.get('filename','')),'line':int(f.get('lineno','0')),'function':f.get('where','?'),'level':f.get('level','0')})
   variables=[];r=self.request('context_get','-d 0 -c 0')
   for prop in r:
    if tag(prop)=='property':variables.append({'name':prop.get('name','?'),'value':value(prop)})
   with self.lock:
    if self.proc is proc:self.data.update(state='paused',reason='point d’arrêt ou pas à pas',frame=frames[0] if frames else None,frames=frames,variables=variables)
  except Exception as e:
   with self.lock:self.data['message']=str(e)
 def _finish(self,proc):time.sleep(.2);self.stop(finished=True,expected=proc)
 def start(self,target,breakpoints):
  if self.snapshot()['active']:raise ValueError('Une session est déjà active.')
  php=shutil.which('php')
  if not php:raise ValueError('Installez PHP CLI et Xdebug : sudo apt install php-cli php-xdebug')
  check=subprocess.run([php,'-r','exit(extension_loaded("xdebug") ? 0 : 1);'],capture_output=True,timeout=8)
  if check.returncode:raise ValueError('Xdebug est introuvable ou désactivé. Installez php-xdebug et vérifiez php --ri xdebug.')
  target=self.file(target);token=secrets.token_hex(24);self.bpmap={}
  self.server=socket.socket();self.server.bind(('127.0.0.1',0));self.server.listen(1);self.server.settimeout(10);port=self.server.getsockname()[1]
  self.master,slave=pty.openpty();attrs=termios.tcgetattr(slave);attrs[3]&=~termios.ECHO;termios.tcsetattr(slave,termios.TCSANOW,attrs)
  cmd=[php,'-d','xdebug.mode=debug','-d','xdebug.start_with_request=yes','-d','xdebug.client_host=127.0.0.1','-d',f'xdebug.client_port={port}','-d',f'xdebug.idekey={token}','-d','xdebug.connect_timeout_ms=5000',str(target)]
  try:
   env=dict(os.environ)
   for name in ('XDEBUG_CONFIG','XDEBUG_MODE','XDEBUG_TRIGGER','XDEBUG_SESSION'):env.pop(name,None)
   proc=subprocess.Popen(cmd,cwd=target.parent,stdin=slave,stdout=slave,stderr=slave,env=env,start_new_session=True);self.proc=proc
   with self.lock:self.data.update(active=True,state='starting',reason='',frame=None,frames=[],variables=[],output='',message='',breakpoints=[])
   master=self.master
   def console():
    try:
     while True:
      try:chunk=os.read(master,4096)
      except OSError:break
      if not chunk:break
      if self.proc is proc:self._output(chunk.decode('utf8','replace').replace('\r\n','\n'))
    finally:
     try:os.close(master)
     except OSError:pass
   threading.Thread(target=console,daemon=True).start()
   # Authenticate the first DBGp init by its random idekey. The port is local
   # and ephemeral; a mismatch aborts without accepting commands from it.
   conn,_=self.server.accept();conn.settimeout(8);header=b''
   while not header.endswith(b'\0'):
    b=conn.recv(1)
    if not b:raise ValueError('Connexion Xdebug interrompue.')
    header+=b
    if len(header)>20:raise ValueError('Connexion Xdebug invalide.')
   size=int(header[:-1]);body=b''
   if size>1_000_000:raise ValueError('Connexion Xdebug invalide.')
   while len(body)<size+1:
    b=conn.recv(size+1-len(body))
    if not b:raise ValueError('Connexion Xdebug interrompue.')
    body+=b
   init=ET.fromstring(body[:-1])
   if tag(init)!='init' or init.get('idekey')!=token:conn.close();raise ValueError('Connexion Xdebug non autorisée.')
   conn.settimeout(None);self.conn=conn;threading.Thread(target=self.listen,args=(conn,proc),daemon=True).start()
   self.request('feature_set','-n max_children -v 100');self.request('feature_set','-n max_data -v 500')
   for b in breakpoints:self.add_breakpoint(b['path'],b['line'])
   with self.lock:self.data['state']='running'
   self.send('run',continuation=True)
   def reap():
    proc.wait()
    if self.proc is proc:threading.Thread(target=self.stop,kwargs={'finished':True,'expected':proc},daemon=True).start()
   threading.Thread(target=reap,daemon=True).start()
  except Exception:self.stop();raise
  finally:os.close(slave)
 def add_breakpoint(self,key,line):
  if self.snapshot()['state']=='running':raise ValueError('Pour modifier les points d’arrêt PHP, mettez le programme en pause ou arrêtez-le.')
  p=self.file(key);line=int(line)
  if line<1:raise ValueError('Ligne invalide.')
  if (key,line) in self.bpmap:return
  r=self.request('breakpoint_set',f'-t line -f {p.as_uri()} -n {line}');self.bpmap[(key,line)]=r.get('id')
  with self.lock:self.data['breakpoints']=[{'path':k[0],'line':k[1],'resolvedLine':k[1]} for k in self.bpmap]
 def remove_breakpoint(self,key,line):
  if self.snapshot()['state']=='running':raise ValueError('Pour modifier les points d’arrêt PHP, mettez le programme en pause ou arrêtez-le.')
  k=(key,int(line))
  if k not in self.bpmap:return
  self.request('breakpoint_remove',f'-d {self.bpmap[k]}');self.bpmap.pop(k,None)
  with self.lock:self.data['breakpoints']=[{'path':x[0],'line':x[1],'resolvedLine':x[1]} for x in self.bpmap]
 def action(self,action):
  if action=='pause':raise ValueError('La pause à distance n’est pas disponible pour PHP ; utilisez un point d’arrêt.')
  names={'continue':'run','next':'step_over','step':'step_into','finish':'step_out'}
  if action not in names:raise ValueError('Commande invalide.')
  if self.snapshot()['state']!='paused':raise ValueError('Le programme doit être en pause.')
  with self.lock:self.data.update(state='running',frame=None,frames=[],variables=[])
  self.send(names[action],continuation=True)
 def evaluate(self,expression):
  if self.snapshot()['state']!='paused':raise ValueError('Le programme doit être en pause.')
  if not expression.strip() or '\n' in expression:raise ValueError('Expression invalide.')
  r=self.request('eval',payload=expression);prop=next((x for x in r if tag(x)=='property'),None)
  if prop is None:raise ValueError('Évaluation impossible.')
  return value(prop)
 def input(self,text):
  if self.snapshot()['state']!='running':raise ValueError('Le programme n’est pas en cours d’exécution.')
  os.write(self.master,(text+'\n').encode());self._output(text+'\n')
 def stop(self,finished=False,expected=None):
  with self.stoplock:
   proc=self.proc
   if expected is not None and proc is not expected:return
   conn=self.conn;self.conn=None
   if conn:
    try:conn.shutdown(socket.SHUT_RDWR)
    except OSError:pass
    conn.close()
   if self.server:
    try:self.server.close()
    except OSError:pass
    self.server=None
   if proc and proc.poll() is None:
    try:os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     proc.wait(timeout=2)
   with self.lock:
    if self.proc is proc:self.data.update(active=False,state='finished' if finished else 'idle',frame=None,frames=[],variables=[])
