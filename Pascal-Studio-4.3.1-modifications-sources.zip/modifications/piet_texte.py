#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Le format TEXTE de Piet, son encodeur PNG et son exécution (4.3.0).

POURQUOI UN FORMAT TEXTE
  Piet est défini comme une IMAGE : un programme est un PNG. Le moteur de
  Pascal Studio le décodait déjà à la main (`langages_esoteriques.decoder_png`,
  sans aucune bibliothèque d'images), donc un PNG s'exécutait. Mais on ne
  pouvait pas l'ÉCRIRE : peindre un PNG à la main n'est pas éditer un programme,
  et un PNG ne se diff pas, ne se fusionne pas, ne se corrige pas d'une ligne.

  Ce module définit un format texte, `.piett`, qui est la SOURCE, et le PNG
  comme la FORME COMPILÉE que le moteur existant sait exécuter. L'exécution ne
  réécrit donc pas l'interpréteur : elle le réutilise, avec ses bornes, ses
  diagnostics et son pas à pas déjà validés. C'est le choix le plus sûr — un
  second interpréteur Piet serait un second endroit où se tromper.

LE FORMAT
    # commentaire
    piet 1              version du format
    codel 4             taille d'un codel en pixels (1 à 64)
    grille 3 1          largeur et hauteur en CODELS (facultatif : déduit)
    rc rn ms            une ligne par rangée, une cellule par codel

  Une cellule est une couleur, en deux lettres minuscules :
    bl = blanc, no = noir,
    <teinte><luminosité> avec teinte r j v c b m (rouge, jaune, vert, cyan,
    bleu, magenta) et luminosité c n s (claire, normale, sombre).
  Les formes longues sont acceptées et équivalentes : `blanc`, `noir`,
  `rouge-claire`, et la paire numérique `0.0` à `5.2`. Les majuscules aussi.

  Ce choix de lettres vient du français, pas de l'anglais : `b` y est le BLEU,
  et le blanc est `bl`. En anglais, `b` serait ambiguous entre blue et black —
  le genre d'ambiguïté qui fait écrire un programme pour un autre.

GARANTIES
  - Aller-retour exact : decoder(encoder(grille)) == grille, et
    depuis_png(vers_png(texte)) redonne la même grille.
  - Aucune dépendance externe : struct et zlib seulement, comme le décodeur.
  - Un texte invalide produit des diagnostics LIGNE/COLONNE, jamais une
    exception nue : l'éditeur graphique doit pouvoir souligner la case.
  - Les dimensions sont bornées (128 x 128 codels, codel 1 à 64) : un fichier
    hostile ne peut pas faire allouer une image géante.
"""

import base64
import io
import os
import struct
import sys
import zlib

# Le moteur existant. Importé ici et non recopié : c'est lui qui exécute.
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import langages_esoteriques as esot  # noqa: E402

VERSION_FORMAT = 1
EXTENSION = '.piett'
CODELS_MAX = 128
CODEL_MIN = 1
CODEL_MAX = 64
PIXELS_MAX = CODELS_MAX * CODEL_MAX * CODEL_MAX * CODEL_MAX  # garde théorique

SEVERITE_ERREUR = esot.SEVERITE_ERREUR
SEVERITE_AVERTISSEMENT = getattr(esot, 'SEVERITE_AVERTISSEMENT', 'warning')
SEVERITE_INFO = getattr(esot, 'SEVERITE_INFO', 'info')

TEINTES = ('rouge', 'jaune', 'vert', 'cyan', 'bleu', 'magenta')
LETTRES_TEINTE = ('r', 'j', 'v', 'c', 'b', 'm')
LUMINOSITES = ('claire', 'normale', 'sombre')
LETTRES_LUMINOSITE = ('c', 'n', 's')
BLANC = 'bl'
NOIR = 'no'

# Les 20 couleurs, dans l'ordre de la palette affichée par l'éditeur graphique.
COULEURS = []
for _lum in range(3):
    for _tei in range(6):
        COULEURS.append({
            'code': LETTRES_TEINTE[_tei] + LETTRES_LUMINOSITE[_lum],
            'teinte': _tei, 'luminosite': _lum,
            'nom': '%s %s' % (TEINTES[_tei], LUMINOSITES[_lum]),
            'rvb': esot.COULEURS_PIET[(_tei, _lum)],
        })
COULEURS.append({'code': BLANC, 'teinte': None, 'luminosite': None,
                 'nom': 'blanc', 'rvb': esot.BLANC_PIET})
COULEURS.append({'code': NOIR, 'teinte': None, 'luminosite': None,
                 'nom': 'noir', 'rvb': esot.NOIR_PIET})

PAR_CODE = {}
for _c in COULEURS:
    PAR_CODE[_c['code']] = _c
    # Les formes longues, pour qu'un fichier écrit à la main reste lisible.
    if _c['teinte'] is not None:
        PAR_CODE['%s-%s' % (TEINTES[_c['teinte']], LUMINOSITES[_c['luminosite']])] = _c
        PAR_CODE['%s%d' % (LETTRES_TEINTE[_c['teinte']], _c['luminosite'])] = _c
    else:
        PAR_CODE['blanc' if _c['code'] == BLANC else 'noir'] = _c

# La paire numérique « teinte.luminosité », acceptée en entrée.
for _tei in range(6):
    for _lum in range(3):
        PAR_CODE['%d.%d' % (_tei, _lum)] = PAR_CODE[
            LETTRES_TEINTE[_tei] + LETTRES_LUMINOSITE[_lum]]

# Les majuscules sont acceptées. Une lettre unique, elle, ne l'est PAS : « b »
# serait ambigu entre le bleu et le blanc, et deviner coûterait un programme.
for _cle in list(PAR_CODE):
    PAR_CODE.setdefault(_cle.upper(), PAR_CODE[_cle])


def rvb_hex(rvb):
    return '#%02x%02x%02x' % tuple(rvb)


def palette():
    """Les 20 couleurs, pour la palette de l'éditeur graphique."""
    return [{'code': c['code'], 'nom': c['nom'], 'teinte': c['teinte'],
             'luminosite': c['luminosite'], 'rvb': list(c['rvb']),
             'hexa': rvb_hex(c['rvb'])} for c in COULEURS]


def transitions():
    """La table des 17 commandes, présentée comme l'éditeur doit la montrer.

    En Piet, la commande dépend du CHANGEMENT de teinte et de luminosité entre
    le bloc quitté et le bloc rejoint. Un éditeur graphique qui ne montre pas
    cette table oblige l'utilisateur à la connaître par cœur — c'est la première
    difficulté du langage, donc c'est la première chose à afficher.
    """
    table = []
    for cle, commande in sorted(esot.COMMANDES_PIET.items()):
        table.append({'delta_teinte': cle[0], 'delta_luminosite': cle[1],
                      'commande': commande,
                      'libelle': esot.LIBELLES_PIET.get(commande, commande)})
    # La case (0, 0) ne fait rien : elle est absente de COMMANDES_PIET, et
    # l'éditeur doit pourtant dire ce qui se passe entre deux blocs identiques.
    table.append({'delta_teinte': 0, 'delta_luminosite': 0, 'commande': 'rien',
                  'libelle': esot.LIBELLES_PIET.get('rien', 'aucune')})
    return table


def commande_entre(depuis, vers):
    """La commande exécutée en passant d'une couleur à l'autre, ou None."""
    a = PAR_CODE.get(str(depuis).strip().lower())
    b = PAR_CODE.get(str(vers).strip().lower())
    if not a or not b or a['teinte'] is None or b['teinte'] is None:
        return None
    dt = (b['teinte'] - a['teinte']) % 6
    dl = (b['luminosite'] - a['luminosite']) % 3
    commande = esot.COMMANDES_PIET.get((dt, dl), 'rien')
    return {'delta_teinte': dt, 'delta_luminosite': dl, 'commande': commande,
            'libelle': esot.LIBELLES_PIET.get(commande, commande)}


# ---------------------------------------------------------------------------
# décodage
# ---------------------------------------------------------------------------

def _diagnostic(severite, message, ligne=0, colonne=0):
    return {'severity': severite, 'message': message, 'line': ligne,
            'column': colonne, 'ligne': ligne, 'colonne': colonne}


def _nettoyer(ligne):
    """Enlève le commentaire et rend (texte, décalage du premier jeton)."""
    coupe = ligne.split('#', 1)[0]
    return coupe.strip()


def decoder(texte):
    """Transforme le texte en grille. Ne lève JAMAIS : rend des diagnostics.

    Renvoie {'ok', 'version', 'codel', 'largeur', 'hauteur', 'cellules',
    'diagnostics'} où `cellules` est une liste de lignes de codes à deux
    lettres — la forme canonique, celle que réécrit encoder().
    """
    resultat = {'ok': False, 'version': VERSION_FORMAT, 'codel': 1,
                'largeur': 0, 'hauteur': 0, 'cellules': [], 'diagnostics': [],
                'texte': texte if isinstance(texte, str) else ''}
    if not isinstance(texte, str):
        resultat['diagnostics'].append(
            _diagnostic(SEVERITE_ERREUR, 'Le programme Piet texte doit être une '
                                         'chaîne, pas %s.' % type(texte).__name__))
        return resultat
    if not texte.strip():
        resultat['diagnostics'].append(
            _diagnostic(SEVERITE_ERREUR, 'Programme vide : il faut au moins une '
                                         'ligne de grille.'))
        return resultat

    version = None
    codel = None
    declare = None            # (largeur, hauteur) annoncés par « grille w h »
    lignes = []               # [(numéro, [cellules])]
    for numero, brut in enumerate(texte.splitlines(), start=1):
        propre = _nettoyer(brut)
        if not propre:
            continue
        bas = propre.lower()
        if bas.startswith('piet'):
            jetons = bas.split()
            if len(jetons) < 2:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, '« piet » doit être suivi du numéro de '
                                     'version.', numero, 1))
                continue
            try:
                version = int(jetons[1])
            except ValueError:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, 'Version « %s » : ce n’est pas un entier.'
                    % jetons[1], numero, 1))
                continue
            if version != VERSION_FORMAT:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_AVERTISSEMENT,
                    'Format Piet texte version %d, ce module écrit la version '
                    '%d.' % (version, VERSION_FORMAT), numero, 1))
            continue
        if bas.startswith('codel'):
            jetons = bas.split()
            if len(jetons) < 2:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, '« codel » doit être suivi d’une taille en '
                                     'pixels.', numero, 1))
                continue
            try:
                codel = int(jetons[1])
            except ValueError:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, 'Taille de codel « %s » : ce n’est pas un '
                                     'entier.' % jetons[1], numero, 1))
                continue
            if not (CODEL_MIN <= codel <= CODEL_MAX):
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, 'Taille de codel %d hors bornes (%d à %d).'
                    % (codel, CODEL_MIN, CODEL_MAX), numero, 1))
                codel = None
            continue
        if bas.startswith('grille') or bas.startswith('dimensions'):
            jetons = bas.split()
            if len(jetons) < 3:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, '« grille » attend une largeur et une '
                                     'hauteur en codels.', numero, 1))
                continue
            try:
                declare = (int(jetons[1]), int(jetons[2]))
            except ValueError:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR, 'Dimensions « %s %s » : ce ne sont pas des '
                                     'entiers.' % (jetons[1], jetons[2]),
                    numero, 1))
            continue
        # Une ligne de grille.
        jetons = propre.split()
        cellules = []
        valide = True
        for index, jeton in enumerate(jetons):
            cle = jeton.lower().replace('_', '-')
            couleur = PAR_CODE.get(cle)
            if couleur is None:
                resultat['diagnostics'].append(_diagnostic(
                    SEVERITE_ERREUR,
                    'Couleur « %s » inconnue. Les 20 codes sont : %s, bl, no.'
                    % (jeton, ' '.join(
                        LETTRES_TEINTE[t] + LETTRES_LUMINOSITE[l]
                        for l in range(3) for t in range(6))[:35] + '…'),
                    numero, index + 1))
                valide = False
                break
            cellules.append(couleur['code'])
        if valide:
            lignes.append((numero, cellules))

    if not lignes:
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_ERREUR, 'Aucune ligne de grille trouvée.'))
        return resultat

    largeur = max(len(cellules) for _n, cellules in lignes)
    if largeur > CODELS_MAX or len(lignes) > CODELS_MAX:
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_ERREUR, 'Grille de %d x %d codels : la borne est de %d x '
                             '%d.' % (largeur, len(lignes), CODELS_MAX,
                                      CODELS_MAX)))
        return resultat

    # Une grille en escalier est presque toujours une faute de frappe. On la
    # complète plutôt que de la refuser — mais on le DIT, parce qu'une case
    # blanche ajoutée change le programme : le blanc se traverse.
    irregulieres = []
    for numero, cellules in lignes:
        if len(cellules) != largeur:
            irregulieres.append((numero, len(cellules)))
    if irregulieres:
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_AVERTISSEMENT,
            '%d ligne(s) plus courte(s) que la plus large (%d codels) : les '
            'cases manquantes sont complétées en BLANC, qui se traverse sans '
            'commande. Lignes %s.'
            % (len(irregulieres), largeur,
               ', '.join(str(n) for n, _l in irregulieres[:8])),
            irregulieres[0][0], 1))

    grille = []
    for numero, cellules in lignes:
        rangee = list(cellules) + [BLANC] * (largeur - len(cellules))
        grille.append(rangee)

    if declare and declare != (largeur, len(grille)):
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_AVERTISSEMENT,
            '« grille %d %d » annoncé, mais %d x %d trouvé : c’est la grille '
            'trouvée qui est utilisée.' % (declare[0], declare[1], largeur,
                                           len(grille))))

    if codel is None:
        codel = 1
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_AVERTISSEMENT,
            'Aucune taille de codel indiquée : 1 pixel par codel est supposé. '
            'Ajoutez une ligne « codel 4 ».'))

    blanc_partout = all(c == BLANC for rangee in grille for c in rangee)
    if blanc_partout:
        resultat['diagnostics'].append(_diagnostic(
            SEVERITE_AVERTISSEMENT,
            'Programme entièrement blanc : il se termine immédiatement sans '
            'rien faire. Le blanc se traverse, il n’exécute aucune commande.'))

    resultat.update({'ok': not any(
        d['severity'] == SEVERITE_ERREUR for d in resultat['diagnostics']),
        'version': version if version is not None else VERSION_FORMAT,
        'codel': codel, 'largeur': largeur, 'hauteur': len(grille),
        'cellules': grille})
    return resultat


# ---------------------------------------------------------------------------
# encodage
# ---------------------------------------------------------------------------

EN_TETE = """# Programme Piet — format texte de Pascal Studio.
# Une cellule = un codel. Codes : bl (blanc), no (noir), et <teinte><luminosité>
# avec teinte r j v c b m (rouge jaune vert cyan bleu magenta) et luminosité
# c n s (claire normale sombre). Exemple : rn = rouge normale, ms = magenta sombre.
# La commande exécutée dépend du CHANGEMENT de teinte et de luminosité entre le
# bloc quitté et le bloc rejoint — jamais de la couleur elle-même.
"""


def encoder(cellules, codel=1, commentaire=None):
    """Écrit le texte canonique d'une grille de codes couleur."""
    if not cellules or not cellules[0]:
        raise ValueError('encoder() attend une grille non vide.')
    largeur = max(len(rangee) for rangee in cellules)
    if largeur > CODELS_MAX or len(cellules) > CODELS_MAX:
        raise ValueError('Grille hors bornes (%d x %d, maximum %d x %d).'
                         % (largeur, len(cellules), CODELS_MAX, CODELS_MAX))
    codel = int(codel or 1)
    if not (CODEL_MIN <= codel <= CODEL_MAX):
        raise ValueError('Taille de codel %d hors bornes (%d à %d).'
                         % (codel, CODEL_MIN, CODEL_MAX))
    sortie = io.StringIO()
    sortie.write(EN_TETE)
    if commentaire:
        for ligne in str(commentaire).splitlines():
            sortie.write('# %s\n' % ligne.rstrip())
    sortie.write('piet %d\n' % VERSION_FORMAT)
    sortie.write('codel %d\n' % codel)
    sortie.write('grille %d %d\n' % (largeur, len(cellules)))
    for rangee in cellules:
        codees = []
        for cellule in rangee:
            cle = str(cellule).strip().lower()
            couleur = PAR_CODE.get(cle)
            if couleur is None:
                raise ValueError('Couleur « %s » inconnue.' % cellule)
            codees.append(couleur['code'])
        codees.extend([BLANC] * (largeur - len(codees)))
        sortie.write(' '.join(codees) + '\n')
    return sortie.getvalue()


def exemple():
    """Un programme qui s'exécute et écrit quelque chose.

    Trois codels : rouge claire -> rouge normale (push de la taille du bloc, 1)
    -> magenta sombre (delta teinte 5, delta luminosité 1 = out(number)).
    C'est le plus petit programme qui produit une sortie vérifiable, donc c'est
    celui que l'éditeur propose au démarrage et que les bancs exécutent.
    """
    return encoder([['rc', 'rn', 'ms']], codel=4,
                   commentaire='Exemple : empile 1 puis l’écrit (sortie « 1 »).')


# ---------------------------------------------------------------------------
# PNG : la forme compilée
# ---------------------------------------------------------------------------

def vers_png(texte):
    """Compile le texte en octets PNG, la forme que le moteur sait lire."""
    decode = decoder(texte)
    if not decode['ok']:
        erreurs = [d['message'] for d in decode['diagnostics']
                   if d['severity'] == SEVERITE_ERREUR]
        raise ValueError('Programme Piet texte invalide : %s'
                         % (erreurs[0] if erreurs else 'voir les diagnostics'))
    codel = decode['codel']
    largeur = decode['largeur'] * codel
    hauteur = decode['hauteur'] * codel
    if largeur * hauteur > 4_000_000:
        raise ValueError('Image de %d x %d pixels : trop grande (borne 4 Mpx).'
                         % (largeur, hauteur))
    par_code = {c['code']: c['rvb'] for c in COULEURS}
    brutes = bytearray()
    for rangee in decode['cellules']:
        ligne_pixels = bytearray()
        for cellule in rangee:
            ligne_pixels.extend(par_code[cellule] * codel)
        # Filtre 0 (aucun) : le plus simple, et le décodeur du moteur gère les
        # cinq filtres, donc ce choix ne ferme aucune porte.
        for _ in range(codel):
            brutes.append(0)
            brutes.extend(ligne_pixels)
    compresse = zlib.compress(bytes(brutes), 9)

    def bloc(nom, donnees):
        corps = nom + donnees
        return (struct.pack('>I', len(donnees)) + corps
                + struct.pack('>I', zlib.crc32(corps) & 0xffffffff))

    png = bytearray(b'\x89PNG\r\n\x1a\n')
    png += bloc(b'IHDR', struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0))
    png += bloc(b'IDAT', compresse)
    png += bloc(b'IEND', b'')
    return bytes(png)


def vers_uri_png(texte):
    """Le PNG en data URI : ce que l'aperçu de l'éditeur affiche."""
    return 'data:image/png;base64,' + base64.b64encode(vers_png(texte)).decode('ascii')


def detecter_codel(largeur, hauteur, pixels):
    """La plus grande taille de codel qui explique l'image.

    Un PNG Piet est fait de carrés uniformes. On cherche la plus grande taille
    qui divise les dimensions ET dont tous les blocs sont d'une seule couleur :
    c'est la taille avec laquelle le programme a été peint. Deviner trop petit
    multiplierait les blocs et changerait le programme ; trop grand écraserait
    des blocs distincts.
    """
    if not largeur or not hauteur or not pixels:
        return 1
    borne = min(largeur, hauteur, CODEL_MAX)
    meilleur = 1
    for codel in range(1, borne + 1):
        if largeur % codel or hauteur % codel:
            continue
        uniforme = True
        for by in range(0, hauteur, codel):
            for bx in range(0, largeur, codel):
                reference = pixels[by][bx]
                for y in range(by, by + codel):
                    ligne = pixels[y]
                    for x in range(bx, bx + codel):
                        if ligne[x] != reference:
                            uniforme = False
                            break
                    if not uniforme:
                        break
                if not uniforme:
                    break
            if not uniforme:
                break
        if uniforme:
            meilleur = codel
    return meilleur


def depuis_png(donnees, codel=None):
    """Retraduit un PNG Piet en texte : la migration des programmes existants.

    Sans cette fonction, un utilisateur qui a déjà un .png Piet ne pourrait pas
    profiter de l'éditeur texte. Le blanc et le noir ne font pas partie des 18
    couleurs vives : ils ont leurs propres codes.
    """
    if isinstance(donnees, str):
        donnees = base64.b64decode(donnees.split(',', 1)[-1])
    largeur, hauteur, pixels = esot.decoder_png(donnees)
    if not largeur or not hauteur:
        raise ValueError('Image vide.')
    if largeur > CODELS_MAX * CODEL_MAX or hauteur > CODELS_MAX * CODEL_MAX:
        raise ValueError('Image de %d x %d pixels : trop grande pour une '
                         'conversion en codels.' % (largeur, hauteur))
    taille = int(codel) if codel else detecter_codel(largeur, hauteur, pixels)
    if taille < 1:
        taille = 1
    # L'inverse est construit depuis NOS couleurs, pas depuis la table du
    # moteur : `PIET_PAR_RVB` va du RVB vers le couple (teinte, luminosité), et
    # l'écrire dans l'autre sens produisait un IndexError sur la première
    # conversion. La confrontation avec la table du moteur est contrôlée dans
    # l'autocontrôle, donc la divergence ne peut pas passer inaperçue.
    inverse = {tuple(c['rvb']): c['code'] for c in COULEURS}
    inverse[tuple(esot.BLANC_PIET)] = BLANC
    inverse[tuple(esot.NOIR_PIET)] = NOIR
    grille = []
    inconnus = 0
    for by in range(0, hauteur, taille):
        rangee = []
        for bx in range(0, largeur, taille):
            rvb = tuple(pixels[min(by, hauteur - 1)][min(bx, largeur - 1)])
            code = inverse.get(rvb)
            if code is None:
                # Une couleur hors palette : le moteur Piet la traite comme un
                # obstacle. On la rend en BLANC et on le dit, plutôt que de
                # produire un fichier illisible.
                inconnus += 1
                code = BLANC
            rangee.append(code)
        grille.append(rangee)
    texte = encoder(grille, codel=taille,
                    commentaire='Converti depuis un PNG (%d x %d pixels, codel '
                                '%d).' % (largeur, hauteur, taille))
    return {'texte': texte, 'largeur': len(grille[0]), 'hauteur': len(grille),
            'codel': taille, 'couleurs_hors_palette': inconnus,
            'pixels': [largeur, hauteur]}


# ---------------------------------------------------------------------------
# analyse et exécution
# ---------------------------------------------------------------------------

def analyser(texte):
    """Ce que l'éditeur affiche avant même d'exécuter : la structure.

    Les blocs sont calculés ici, sans le moteur, pour rester rapide : une
    inondation par couleur sur la grille de codes. Le moteur refait le même
    travail sur les pixels quand il exécute ; cette fonction sert à l'affichage
    et au surlignage, pas à l'exécution.
    """
    decode = decoder(texte)
    if not decode['ok']:
        return {'ok': False, 'diagnostics': decode['diagnostics'], 'blocs': [],
                'nombre_blocs': 0, 'largeur': 0, 'hauteur': 0, 'codel': 1}
    grille = decode['cellules']
    hauteur = len(grille)
    largeur = decode['largeur']
    vus = [[False] * largeur for _ in range(hauteur)]
    blocs = []
    for y in range(hauteur):
        for x in range(largeur):
            if vus[y][x]:
                continue
            code = grille[y][x]
            file = [(x, y)]
            cases = []
            vus[y][x] = True
            while file:
                cx, cy = file.pop()
                cases.append([cx, cy])
                for vx, vy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = cx + vx, cy + vy
                    if 0 <= nx < largeur and 0 <= ny < hauteur \
                            and not vus[ny][nx] and grille[ny][nx] == code:
                        vus[ny][nx] = True
                        file.append((nx, ny))
            cases.sort()
            couleur = PAR_CODE[code]
            blocs.append({'index': len(blocs), 'code': code,
                          'nom': couleur['nom'], 'hexa': rvb_hex(couleur['rvb']),
                          'taille': len(cases), 'cases': cases,
                          'blanc': code == BLANC, 'noir': code == NOIR,
                          'depart': code == grille[0][0] and cases[0] == [0, 0]})
    depart = [b for b in blocs if b['cases'][0] == [0, 0]]
    return {'ok': True, 'diagnostics': decode['diagnostics'], 'blocs': blocs,
            'nombre_blocs': len(blocs), 'largeur': largeur, 'hauteur': hauteur,
            'codel': decode['codel'],
            'bloc_depart': depart[0] if depart else None,
            'commandes': transitions()}


def executer(texte, entree='', limite=None, chemin=None):
    """Exécute un programme Piet texte, via le moteur déjà validé.

    Le texte est compilé en PNG puis donné au moteur Piet existant : mêmes
    bornes, mêmes diagnostics, même pas à pas. Réécrire un second interpréteur
    aurait donné un second endroit où se tromper.
    """
    decode = decoder(texte)
    if not decode['ok']:
        return {'ok': False, 'state': 'error', 'output': '', 'sortie': '',
                'diagnostics': decode['diagnostics'], 'pas': 0, 'termine': True,
                'langage': 'piet', 'message': 'Programme Piet texte invalide.',
                'erreur': '; '.join(d['message'] for d in decode['diagnostics']
                                    if d['severity'] == SEVERITE_ERREUR)}
    try:
        png = vers_png(texte)
    except ValueError as exc:
        return {'ok': False, 'state': 'error', 'output': '', 'sortie': '',
                'diagnostics': [_diagnostic(SEVERITE_ERREUR, str(exc))],
                'pas': 0, 'termine': True, 'langage': 'piet',
                'message': str(exc), 'erreur': str(exc)}
    instance = esot.Piet(png, entree=entree or '',
                         chemin=chemin or ('programme' + EXTENSION),
                         taille_codel=decode['codel'])
    compte = instance.executer(limite=limite) if limite \
        else instance.executer()
    if isinstance(compte, dict):
        compte['piet_texte'] = {'largeur': decode['largeur'],
                                'hauteur': decode['hauteur'],
                                'codel': decode['codel']}
        compte.setdefault('diagnostics', [])
        compte['diagnostics'] = list(decode['diagnostics']) + \
            list(compte['diagnostics'])
    return compte


def pas_a_pas(texte, entree='', chemin=None):
    """Un moteur arrêté avant la première commande, pour le débogueur."""
    decode = decoder(texte)
    if not decode['ok']:
        return None
    png = vers_png(texte)
    instance = esot.Piet(png, entree=entree or '',
                         chemin=chemin or ('programme' + EXTENSION),
                         taille_codel=decode['codel'])
    instance.charger()
    return instance


def capacites():
    """Ce que ce module sait faire, dit par lui-même et non recopié à la main."""
    return {'ok': True, 'format': 'piet-texte', 'version': VERSION_FORMAT,
            'extension': EXTENSION, 'couleurs': len(COULEURS),
            'commandes': len(esot.COMMANDES_PIET),
            'bornes': {'codels_max': CODELS_MAX, 'codel_min': CODEL_MIN,
                       'codel_max': CODEL_MAX},
            'ecriture_png': True, 'lecture_png': True,
            'execution': True, 'pas_a_pas': True,
            'moteur': 'langages_esoteriques.Piet (inchangé)'}


# ---------------------------------------------------------------------------
# autocontrôle
# ---------------------------------------------------------------------------

COMPTEUR = {'verifs': 0}


def verif(condition, message):
    COMPTEUR['verifs'] += 1
    if not condition:
        raise AssertionError(message)


def verifier():
    """Autocontrôle : rendu par `python3 piet_texte.py`, comme les autres modules."""
    problemes = []
    depart = COMPTEUR['verifs']

    def sans_lever(titre, fonction):
        # Une exception levée ici MASQUERAIT un échec nommé : les bancs
        # compteraient une erreur au lieu de lire le diagnostic.
        try:
            fonction()
        except AssertionError as exc:
            problemes.append('%s : %s' % (titre, exc))
        except Exception as exc:                       # noqa: BLE001
            problemes.append('%s : exception %s (%s)'
                             % (titre, type(exc).__name__, exc))

    def tout():
        # --- la palette -------------------------------------------------
        verif(len(COULEURS) == 20, 'il doit y avoir 20 couleurs (%d)'
              % len(COULEURS))
        verif(len(PAR_CODE) >= 20 + 18 + 18 + 2, 'les formes longues manquent')
        verif(PAR_CODE['rc']['rvb'] == esot.COULEURS_PIET[(0, 0)],
              'rc doit être le rouge clair de la spécification')
        verif(PAR_CODE['ms']['rvb'] == esot.COULEURS_PIET[(5, 2)],
              'ms doit être le magenta sombre')
        verif(PAR_CODE['blanc'] is PAR_CODE['bl'], 'blanc et bl doivent coïncider')
        verif(PAR_CODE['noir'] is PAR_CODE['no'], 'noir et no doivent coïncider')
        verif(PAR_CODE['bn']['nom'] == 'bleu normale',
              'bn doit être le BLEU, pas le blanc ou le noir : %r'
              % PAR_CODE['bn']['nom'])
        verif(PAR_CODE['RC'] is PAR_CODE['rc'], 'les majuscules doivent passer')
        verif(PAR_CODE['0.0'] is PAR_CODE['rc'], 'la paire numérique 0.0 = rc')
        verif(PAR_CODE['5.2'] is PAR_CODE['ms'], 'la paire numérique 5.2 = ms')
        verif(PAR_CODE['rouge-claire'] is PAR_CODE['rc'], 'le nom long passe')
        verif(len(palette()) == 20, 'palette() doit rendre les 20 couleurs')
        verif(all('hexa' in c and c['hexa'].startswith('#') for c in palette()),
              'chaque couleur doit porter son hexadécimal')
        verif(rvb_hex((0xff, 0xc0, 0xc0)) == '#ffc0c0', 'rvb_hex se trompe')

        # --- la table des commandes -------------------------------------
        table = transitions()
        verif(len(table) == 18, 'il faut les 17 commandes + la case (0,0) (%d)'
              % len(table))
        verif(len(esot.COMMANDES_PIET) == 17,
              'la spécification compte 17 commandes (%d)'
              % len(esot.COMMANDES_PIET))
        entre = commande_entre('rc', 'rn')
        verif(entre and entre['commande'] == 'push',
              'rouge claire -> rouge normale doit être push (%r)' % (entre,))
        entre = commande_entre('rn', 'ms')
        verif(entre and entre['commande'] == 'out_nombre',
              'rouge normale -> magenta sombre doit être out(number) (%r)'
              % (entre,))
        verif(commande_entre('rc', 'rc')['commande'] == 'rien',
              'deux blocs identiques ne font rien')
        verif(commande_entre('bl', 'rc') is None,
              'depuis le blanc il n’y a pas de commande : il se traverse')
        verif(commande_entre('no', 'rc') is None,
              'depuis le noir il n’y a pas de commande : il bloque')
        # Le cycle est cyclique : magenta -> rouge est un pas de teinte, pas cinq.
        verif(commande_entre('mc', 'rc')['delta_teinte'] == 1,
              'magenta -> rouge doit être un pas de teinte')
        verif(commande_entre('rs', 'rc')['delta_luminosite'] == 1,
              'sombre -> claire doit être un pas de luminosité')

        # --- décodage ----------------------------------------------------
        bon = decoder(exemple())
        verif(bon['ok'], 'l’exemple doit décoder : %r' % bon['diagnostics'])
        verif(bon['largeur'] == 3 and bon['hauteur'] == 1,
              'l’exemple fait 3 x 1 (%d x %d)' % (bon['largeur'], bon['hauteur']))
        verif(bon['codel'] == 4, 'l’exemple déclare un codel de 4')
        verif(bon['cellules'] == [['rc', 'rn', 'ms']], 'grille inattendue')

        commentaire = decoder('# seulement un commentaire\nrc no\n')
        verif(not commentaire['ok'] is False or True, 'garde')
        verif(commentaire['ok'], 'les commentaires seuls ne cassent rien')
        verif(commentaire['largeur'] == 2, 'la ligne de grille est lue')
        verif(any(d['severity'] == SEVERITE_AVERTISSEMENT
                  for d in commentaire['diagnostics']),
              'l’absence de « codel » doit être signalée')

        vide = decoder('')
        verif(not vide['ok'], 'un texte vide doit être refusé')
        verif(vide['diagnostics'], 'un texte vide doit produire un diagnostic')
        verif(not decoder('   \n\n# rien\n')['ok'], 'un commentaire seul ne fait '
                                                    'pas un programme')

        inconnue = decoder('rc zz ms\n')
        verif(not inconnue['ok'], 'une couleur inconnue doit être refusée')
        verif(inconnue['diagnostics'][0]['ligne'] == 1,
              'le diagnostic doit porter la ligne (%r)' % inconnue['diagnostics'][0])
        verif('zz' in inconnue['diagnostics'][0]['message'],
              'le diagnostic doit nommer la couleur fautive')

        escalier = decoder('rc rn ms\nrc no\n')
        verif(escalier['ok'], 'une grille en escalier reste lisible')
        verif(escalier['largeur'] == 3 and len(escalier['cellules'][1]) == 3,
              'les cases manquantes sont complétées')
        verif(escalier['cellules'][1][2] == BLANC,
              'le complément doit être blanc')
        verif(any('BLANC' in d['message'] for d in escalier['diagnostics']),
              'le complément en blanc doit être ANNONCÉ : il change le programme')

        grand = decoder('rc ' * (CODELS_MAX + 1) + '\n')
        verif(not grand['ok'], 'une grille trop large doit être refusée')

        verif(not decoder(None)['ok'], 'None doit être refusé sans lever')
        verif(not decoder(12)['ok'], 'un entier doit être refusé sans lever')

        codel_fou = decoder('codel 999\nrc rn\n')
        verif(not codel_fou['ok'], 'un codel de 999 doit être refusé')
        codel_zero = decoder('codel 0\nrc rn\n')
        verif(not codel_zero['ok'], 'un codel de 0 doit être refusé')
        verif(decoder('codel abc\nrc rn\n')['diagnostics'],
              'un codel non numérique doit être diagnostiqué')
        verif(decoder('piet\nrc rn\n')['diagnostics'],
              '« piet » sans version doit être diagnostiqué')
        verif(decoder('piet 99\nrc rn\n')['ok'],
              'une version inconnue avertit mais ne bloque pas')
        verif(decoder('grille 5 5\nrc rn\n')['ok'],
              'une « grille » incohérente avertit mais ne bloque pas')

        tout_blanc = decoder('bl bl\nbl bl\n')
        verif(tout_blanc['ok'], 'un programme tout blanc est lisible')
        verif(any('entièrement blanc' in d['message']
                  for d in tout_blanc['diagnostics']),
              'un programme tout blanc doit être signalé : il ne fait rien')

        # --- aller-retour texte -----------------------------------------
        grille = [['rc', 'jn', 'vs'], ['cc', 'bl', 'no'], ['bn', 'ms', 'vc']]
        texte = encoder(grille, codel=3)
        relu = decoder(texte)
        verif(relu['ok'] and relu['cellules'] == grille,
              'aller-retour texte perdu : %r' % relu['cellules'])
        verif(relu['codel'] == 3, 'le codel ne survit pas à l’aller-retour')
        verif(texte.startswith('#'), 'le texte canonique commence par un commentaire')
        verif('piet %d' % VERSION_FORMAT in texte, 'la version est écrite')
        verif('grille 3 3' in texte, 'les dimensions sont écrites')
        verif(encoder([['rc', 'rn']], codel=1).count('\n') >= 4,
              'l’en-tête doit tenir sur plusieurs lignes')

        irregulier = encoder([['rc', 'rn'], ['ms']], codel=2)
        verif(decoder(irregulier)['cellules'] == [['rc', 'rn'], ['ms', 'bl']],
              'encoder() doit compléter une ligne courte')

        try:
            encoder([], 1)
            verif(False, 'encoder([]) doit lever')
        except ValueError:
            verif(True, '')
        try:
            encoder([['zz']], 1)
            verif(False, 'encoder() doit refuser une couleur inconnue')
        except ValueError:
            verif(True, '')
        try:
            encoder([['rc']], 999)
            verif(False, 'encoder() doit refuser un codel hors bornes')
        except ValueError:
            verif(True, '')
        try:
            encoder([['rc'] * (CODELS_MAX + 1)], 1)
            verif(False, 'encoder() doit refuser une grille hors bornes')
        except ValueError:
            verif(True, '')

        # --- PNG ---------------------------------------------------------
        png = vers_png(exemple())
        verif(png[:8] == b'\x89PNG\r\n\x1a\n', 'la signature PNG manque')
        verif(png[-8:-4] == b'IEND' or b'IEND' in png[-12:], 'le bloc IEND manque')
        largeur, hauteur, pixels = esot.decoder_png(png)
        verif((largeur, hauteur) == (12, 4),
              '3 codels x 4 pixels = 12 x 4 (%d x %d)' % (largeur, hauteur))
        verif(pixels[0][0] == esot.COULEURS_PIET[(0, 0)],
              'le premier pixel doit être le rouge clair')
        verif(pixels[0][4] == esot.COULEURS_PIET[(0, 1)],
              'le deuxième codel doit être le rouge normal')
        verif(pixels[0][8] == esot.COULEURS_PIET[(5, 2)],
              'le troisième codel doit être le magenta sombre')
        verif(detecter_codel(largeur, hauteur, pixels) == 4,
              'la taille de codel doit être retrouvée (%d)'
              % detecter_codel(largeur, hauteur, pixels))

        # Les 18 couleurs du moteur doivent toutes être reconnues par la
        # conversion : sans ce contrôle, une divergence entre nos deux tables
        # transformerait silencieusement un programme en blanc.
        _inverse = {tuple(c['rvb']): c['code'] for c in COULEURS}
        verif(all(tuple(rvb) in _inverse for rvb in esot.PIET_PAR_RVB),
              'une couleur du moteur n’est pas dans notre palette')
        verif(len(_inverse) == 20, 'la palette doit couvrir 20 RVB distincts (%d)'
              % len(_inverse))
        verif(tuple(esot.BLANC_PIET) in _inverse
              and tuple(esot.NOIR_PIET) in _inverse,
              'le blanc et le noir doivent être reconnus')

        conversion = depuis_png(png)
        verif(conversion['texte'] and decoder(conversion['texte'])['cellules']
              == [['rc', 'rn', 'ms']],
              'l’aller-retour PNG doit rendre la même grille (%r)'
              % decoder(conversion['texte'])['cellules'])
        verif(conversion['codel'] == 4, 'le codel doit être retrouvé')
        verif(conversion['couleurs_hors_palette'] == 0,
              'aucune couleur ne doit être hors palette ici')
        verif(conversion['pixels'] == [12, 4], 'les dimensions en pixels sont rendues')

        # Une image dont le codel n'est pas un diviseur exact : la conversion
        # doit rester possible, en prenant la plus grande taille cohérente.
        png2 = vers_png(encoder([['rc', 'jn'], ['vs', 'cc']], codel=3))
        verif(depuis_png(png2)['codel'] == 3, 'codel 3 non retrouvé')
        verif(decoder(depuis_png(png2)['texte'])['cellules']
              == [['rc', 'jn'], ['vs', 'cc']], 'grille 2x2 perdue')

        # Une couleur hors palette doit être rendue en blanc ET comptée.
        brut = bytearray()
        for _y in range(2):
            brut.append(0)
            brut.extend(bytes((0x12, 0x34, 0x56) * 2))
        idat = zlib.compress(bytes(brut), 9)

        def bloc(nom, donnees):
            corps = nom + donnees
            return (struct.pack('>I', len(donnees)) + corps
                    + struct.pack('>I', zlib.crc32(corps) & 0xffffffff))
        hors = (b'\x89PNG\r\n\x1a\n'
                + bloc(b'IHDR', struct.pack('>IIBBBBB', 2, 2, 8, 2, 0, 0, 0))
                + bloc(b'IDAT', idat) + bloc(b'IEND', b''))
        converti = depuis_png(hors, codel=1)
        verif(converti['couleurs_hors_palette'] == 4,
              'les 4 codels hors palette doivent être comptés (%d)'
              % converti['couleurs_hors_palette'])
        verif(all(c == BLANC for c in decoder(converti['texte'])['cellules'][0]),
              'une couleur hors palette devient blanche')
        # Sur la même image, la détection choisit la PLUS GRANDE taille dont
        # tous les blocs sont uniformes — ici 2, donc un seul codel. Le dire
        # par un contrôle évite de prendre ce comportement pour un défaut.
        detecte = depuis_png(hors)
        verif(detecte['codel'] == 2 and detecte['couleurs_hors_palette'] == 1,
              'la détection doit choisir le codel 2 (%d codel, %d hors palette)'
              % (detecte['codel'], detecte['couleurs_hors_palette']))

        uri = vers_uri_png(exemple())
        verif(uri.startswith('data:image/png;base64,'), 'l’URI de données est mal formé')
        verif(base64.b64decode(uri.split(',', 1)[1]) == png,
              'l’URI doit porter exactement le PNG')
        verif(depuis_png(uri)['codel'] == 4,
              'depuis_png doit accepter une data URI')

        try:
            vers_png('zz zz\n')
            verif(False, 'vers_png doit refuser un texte invalide')
        except ValueError:
            verif(True, '')

        # --- analyse -----------------------------------------------------
        analyse = analyser(exemple())
        verif(analyse['ok'], 'l’analyse de l’exemple échoue')
        verif(analyse['nombre_blocs'] == 3,
              'trois codels de couleurs différentes = trois blocs (%d)'
              % analyse['nombre_blocs'])
        verif(analyse['bloc_depart'] and analyse['bloc_depart']['code'] == 'rc',
              'le bloc de départ est en haut à gauche')
        verif(all(b['taille'] == 1 for b in analyse['blocs']),
              'chaque bloc de l’exemple fait un codel')
        verif(len(analyse['commandes']) == 18, 'la table des commandes suit')
        fusion = analyser(encoder([['rc', 'rc', 'rn']], codel=2))
        verif(fusion['nombre_blocs'] == 2,
              'deux codels contigus de même couleur font UN bloc (%d)'
              % fusion['nombre_blocs'])
        verif(fusion['blocs'][0]['taille'] == 2, 'la taille du bloc est fausse')
        verif(not analyser('zz zz\n')['ok'], 'une analyse invalide le dit')

        # --- exécution ---------------------------------------------------
        resultat = executer(exemple())
        verif(isinstance(resultat, dict), 'executer doit rendre un dictionnaire')
        sortie = resultat.get('sortie') or resultat.get('output') or ''
        verif('1' in sortie,
              'l’exemple doit écrire 1 (push 1 puis out(number)) ; sortie %r, '
              'message %r, pas %r' % (sortie, resultat.get('message'),
                                      resultat.get('pas')))
        verif(resultat.get('termine') is True, 'l’exemple doit se terminer')
        verif(resultat.get('langage') == 'piet', 'le langage rendu doit être piet')
        verif(resultat.get('piet_texte', {}).get('codel') == 4,
              'le compte rendu doit rappeler la taille de codel')

        invalide = executer('zz zz\n')
        verif(invalide['ok'] is False, 'un texte invalide ne s’exécute pas')
        verif(invalide['diagnostics'], 'un texte invalide rend ses diagnostics')
        verif(invalide['erreur'], 'un texte invalide nomme l’erreur')

        verif(executer(None)['ok'] is False, 'executer(None) ne lève pas')
        verif(executer('')['ok'] is False, 'executer('') ne lève pas')

        # Un programme tout blanc se termine sans rien faire.
        blanc = executer(encoder([['bl', 'bl'], ['bl', 'bl']], codel=2))
        verif(blanc.get('termine') is True, 'un programme blanc doit se terminer')
        verif(not (blanc.get('sortie') or blanc.get('output')),
              'un programme blanc ne doit rien écrire')

        # Le pas à pas : le moteur est arrêté AVANT la première commande.
        moteur = pas_a_pas(exemple())
        verif(moteur is not None, 'pas_a_pas doit rendre un moteur')
        verif(moteur.pas_fait == 0, 'le moteur doit être à l’arrêt')
        verif(moteur.largeur == 12 and moteur.hauteur == 4,
              'le moteur voit l’image compilée (%d x %d)'
              % (moteur.largeur, moteur.hauteur))
        verif(pas_a_pas('zz zz') is None, 'pas_a_pas rend None sur un texte invalide')

        # --- capacités ---------------------------------------------------
        caps = capacites()
        verif(caps['ok'] is True, 'capacites doit être ok')
        verif(caps['couleurs'] == 20, 'capacites doit annoncer 20 couleurs')
        verif(caps['commandes'] == 17, 'capacites doit annoncer 17 commandes')
        verif(caps['extension'] == EXTENSION, 'l’extension annoncée est fausse')
        verif(caps['execution'] and caps['ecriture_png'] and caps['lecture_png'],
              'les trois capacités essentielles doivent être vraies')
        verif(caps['moteur'].startswith('langages_esoteriques'),
              'le compte rendu doit dire QUEL moteur exécute')

    sans_lever('autocontrôle piet_texte', tout)
    if COMPTEUR['verifs'] == depart:
        problemes.append('aucun contrôle n’a été compté : l’autocontrôle est vide')
    return problemes


if __name__ == '__main__':
    soucis = verifier()
    if soucis:
        for souci in soucis:
            print('ÉCHEC :', souci)
        sys.exit(1)
    print('piet_texte : %d contrôles ; format %s version %d, 20 couleurs, 17 '
          'commandes, aller-retour texte et PNG vérifié, exécution par le '
          'moteur Piet existant.'
          % (COMPTEUR['verifs'], EXTENSION, VERSION_FORMAT))
