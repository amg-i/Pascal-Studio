"""Compilation locale explicite pour C, C++, C#, Make et CMake.

Les scripts de construction et programmes ne sont PAS isolés : ils utilisent les
mêmes droits que l'utilisateur. Aucune commande n'est construite via un shell.
"""
import hashlib, json, os, re, shutil, subprocess, time, uuid
from pathlib import Path
import additional_languages
import swift_kotlin
import langages

C_EXT={'.c'}; CPP_EXT={'.cc','.cpp','.cxx','.c++'}
PASS_EXT={'.pas','.pp','.p','.lpr'}
GCC_RE=re.compile(r'^(.*?):(\d+):(\d+):\s*(fatal error|error|warning|note):\s*(.*)$',re.I)
CS_RE=re.compile(r'^(.*?)\((\d+),(\d+)(?:,\d+,\d+)?\):\s*(error|warning)\s+([A-Za-z]+\d+):\s*(.*?)(?:\s+\[.*\])?$',re.I)
candidates={}

def kind(path):
    p=Path(path); n=p.name
    added=additional_languages.kind(p)
    if added:return added
    # Swift et Kotlin sont reconnus avant les règles générales.
    jvm=swift_kotlin.kind(p)
    if jvm:return jvm
    # Les dix langages ésotériques n'ont ni compilateur ni règle de nom propre :
    # leur extension est leur seule identité. On la lit dans le registre au lieu
    # d'ajouter un second tableau d'extensions, qui finirait par diverger. Sans
    # cette branche kind() rendait None : un .bf ouvert dans l'éditeur n'avait ni
    # analyse en direct ni débogage, alors que capacites() annonce les deux, et
    # Piet était refusé au titre de langage « visuel ».
    esot=langages.resoudre(p.suffix.lower())
    if esot and langages.debogueur(esot)=='esoterique':return esot
    # L'assembleur (4.0.0). Aucune des règles ci-dessous ne connaît ses
    # extensions, donc kind() rendait None : un .asm ouvert dans l'éditeur
    # n'aurait eu ni analyse en direct ni débogage, alors que le registre les
    # annonce tous les deux. C'est exactement le défaut que la branche
    # ésotérique a corrigé en 3.8.0, et la correction est la même — lire le
    # registre plutôt que de recopier ici un second tableau d'extensions, qui
    # finirait par diverger. Placée avant les règles générales pour que .s ne
    # soit jamais pris pour autre chose.
    # La source texte Piet (4.3.0). Elle n'a pas le débogueur « esoterique » —
    # sa machine à pas est piet_texte.pas_a_pas(), appelée par l'éditeur Piet —
    # donc la branche ésotérique ci-dessus ne la rend pas. Sans celle-ci kind()
    # rendrait None : un .piett n'aurait ni analyse en direct ni libellé, alors
    # que le registre annonce les deux. Même correction, même raison qu'en 3.8.0.
    piet_texte=langages.resoudre(p.suffix.lower())
    if piet_texte=='piet_texte':return piet_texte
    assembleur=langages.resoudre(p.suffix.lower())
    if assembleur=='asm':return assembleur
    if n in ('Makefile','makefile','GNUmakefile') or p.suffix.lower()=='.mk':return 'make'
    if n.lower()=='cmakelists.txt':return 'cmake'
    if p.suffix=='.C' or p.suffix.lower() in CPP_EXT:return 'cpp'
    if p.suffix.lower() in C_EXT:return 'c'
    if p.suffix.lower()=='.tex':return 'latex'
    if p.suffix.lower()=='.rs':return 'rust'
    if p.suffix.lower()=='.go':return 'go'
    if p.suffix.lower()=='.rb':return 'ruby'
    if p.suffix.lower()=='.py':return 'python'
    if p.suffix.lower() in ('.js','.mjs','.cjs'):return 'javascript'
    if p.suffix.lower()=='.php':return 'php'
    if p.suffix.lower() in ('.html','.htm'):return 'html'
    if p.suffix.lower()=='.css':return 'css'
    if p.suffix.lower()=='.cs':return 'cs'
    if p.suffix.lower()=='.csproj':return 'csproj'
    if p.suffix.lower() in PASS_EXT:return 'pascal'
    return None

def required(name):
    value=shutil.which(name)
    if not value:raise ValueError({'gcc':'Installez GCC : sudo apt install build-essential','g++':'Installez G++ : sudo apt install build-essential','make':'Installez Make : sudo apt install build-essential','cmake':'Installez CMake : sudo apt install cmake','dotnet':'Installez le SDK .NET 10 ou plus récent (dotnet).','rustc':'Installez Rust : sudo apt install rustc','go':'Installez Go : sudo apt install golang-go','ruby':'Installez Ruby : sudo apt install ruby'}[name])
    return value

def run_cmd(cmd,cwd,timeout=180):
    env={**os.environ,'DOTNET_CLI_TELEMETRY_OPTOUT':'1','DOTNET_NOLOGO':'1','DOTNET_SKIP_FIRST_TIME_EXPERIENCE':'1','LC_ALL':'C.UTF-8','TERM':'dumb'}
    try:r=subprocess.run(cmd,cwd=cwd,capture_output=True,text=True,errors='replace',timeout=timeout,env=env)
    except subprocess.TimeoutExpired: return 124,'Construction interrompue après %s secondes.\n'%timeout
    return r.returncode,(r.stdout+r.stderr)[-2_000_000:]

def diagnostics(text,root,original, external_files):
    rows=[]
    for line in text.splitlines():
        m=GCC_RE.match(line) or CS_RE.match(line)
        if not m:continue
        if len(m.groups())==5: filename,row,col,severity,message=m.groups()
        else:filename,row,col,severity,code,message=m.groups();message=code+': '+message
        candidate=Path(filename); candidate=(candidate if candidate.is_absolute() else original.parent/candidate).resolve()
        try:rel=candidate.relative_to(root).as_posix()
        except ValueError:
            if not candidate.is_file():continue
            rel='@external:'+str(candidate);external_files[rel]=candidate
        rows.append(dict(file=rel,line=int(row),column=int(col),severity=severity,message=message))
    return rows

def source_key(filename, root, original, external_files):
    f=Path(filename);f=(f if f.is_absolute() else original.parent/f).resolve()
    try: return f.relative_to(root).as_posix()
    except ValueError:
        if f.is_file():
            key='@external:'+str(f);external_files[key]=f;return key
        return None

def utf16_column(path,row,column):
    try:
        line=Path(path).read_text(encoding='utf8').splitlines()[row-1]
        return len(line[:max(0,column-1)].encode('utf-16-le'))//2+1
    except (OSError,UnicodeError,IndexError):return max(1,column)

def rust_diagnostics(raw,root,original,external_files):
    found=[];render=[]
    for line in raw.splitlines():
        try: obj=json.loads(line)
        except ValueError:
            render.append(line);continue
        if not isinstance(obj,dict):continue
        rendered=obj.get('rendered')
        if rendered:render.append(rendered.rstrip())
        severity=obj.get('level')
        if severity not in ('error','warning'):continue
        for span in obj.get('spans',[]):
            if not span.get('is_primary'):continue
            filename=span.get('file_name','');key=source_key(filename,root,original,external_files)
            if not key:continue
            f=Path(filename);f=f if f.is_absolute() else original.parent/f
            row=int(span.get('line_start',1));column=utf16_column(f,row,int(span.get('column_start',1)))
            found.append(dict(file=key,line=row,column=column,severity=severity,message=obj.get('message','Erreur Rust')))
    return ('\n'.join(render)+'\n' if render else ''),found

def go_diagnostics(raw,root,original,external_files):
    found=[]
    for line in raw.splitlines():
        m=re.match(r'^(.*?\.go):(\d+)(?::(\d+))?:\s*(.*)$',line)
        if not m:continue
        filename,row,col,message=m.groups();key=source_key(filename,root,original,external_files)
        if not key:continue
        # Go compiler columns count UTF-8 bytes, not UTF-16 or Unicode scalars.
        f=Path(filename);f=f if f.is_absolute() else original.parent/f
        try:
            text=f.read_text(encoding='utf8').splitlines()[int(row)-1];prefix=text.encode('utf8')[:max(0,int(col or 1)-1)].decode('utf8','ignore');column=len(prefix.encode('utf-16-le'))//2+1
        except (OSError,UnicodeError,IndexError):column=int(col or 1)
        found.append(dict(file=key,line=int(row),column=column,severity='error',message=message))
    return found

def _executables(folder):
    """Only discover regular ELF executables in the selected project subtree."""
    folder=folder.resolve();found=[];visited=0
    for base,dirs,files in os.walk(folder,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ('.git','node_modules','.cache','.pascal-studio') and not (Path(base)/d).is_symlink()]
        for name in files:
            visited+=1
            if visited>20000:return found
            f=Path(base)/name
            try:
                if f.is_symlink() or not f.is_file() or not os.access(f,os.X_OK) or not f.resolve().is_relative_to(folder):continue
                with f.open('rb') as h:
                    if h.read(4)!=b'\x7fELF':continue
                found.append(f.resolve())
                if len(found)>=100:return found
            except OSError:continue
    return found

def _cmake_artifacts(build):
    reply=build/'.cmake/api/v1/reply';found=[]
    indices=sorted(reply.glob('index-*.json'),key=lambda f:f.stat().st_mtime,reverse=True)
    if not indices:return found
    try:
        idx=json.loads(indices[0].read_text()); entry=idx['reply']['codemodel-v2']['jsonFile']; model=json.loads((reply/entry).read_text())
        for conf in model.get('configurations',[]):
            for t in conf.get('targets',[]):
                obj=json.loads((reply/t['jsonFile']).read_text())
                if obj.get('type')!='EXECUTABLE':continue
                for artifact in obj.get('artifacts',[]):
                    p=Path(artifact['path']);p=(p if p.is_absolute() else build/p).resolve()
                    if p.is_relative_to(build.resolve()) and p.is_file() and os.access(p,os.X_OK):found.append(p)
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError):return []
    return list(dict.fromkeys(found))[:100]

def _register(paths,root):
    now=time.monotonic();candidates.clear();out=[]
    for p in paths:
        key=uuid.uuid4().hex;candidates[key]=(p,now+900)
        try:label=p.relative_to(root).as_posix()
        except ValueError:label=str(p)
        out.append({'id':key,'label':label})
    return out

def take_candidate(key):
    if not isinstance(key,str):raise ValueError('Exécutable invalide.')
    pair=candidates.pop(key,None)
    if not pair or time.monotonic()>pair[1]:raise ValueError('Choix expiré : reconstruisez le projet.')
    p=pair[0]
    if not p.is_file() or not os.access(p,os.X_OK):raise ValueError('Exécutable introuvable.')
    return p

def build(root,build_dir,path,external_files,debug=False):
    root=Path(root).resolve();build_dir=Path(build_dir).resolve();p=Path(path).resolve(); k=kind(p)
    if not p.is_file() or not k or k=='pascal':raise ValueError('Type de fichier non pris en charge pour cette construction.')
    digest=hashlib.sha256(str(p).encode()).hexdigest()[:20];binary=build_dir/('native-'+digest)
    base={'kind':k,'binary':None,'diagnostics':[]};out=''
    if k in ('rust','go'):
        binary.unlink(missing_ok=True)
        if k=='rust':
            cmd=[required('rustc'),'--edition=2021','--crate-name','studio_program','--error-format=json','-g',str(p),'-o',str(binary)]
        else:
            cmd=[required('go'),'build']+(['-gcflags=all=-N -l'] if debug else [])+['-o',str(binary),str(p)]
        code,raw=run_cmd(cmd,p.parent)
        if k=='rust':
            out,found=rust_diagnostics(raw,root,p,external_files)
        else:
            out=raw;found=go_diagnostics(raw,root,p,external_files)
        return {**base,'ok':code==0 and binary.is_file(),'output':out,'diagnostics':found,'binary':str(binary) if binary.is_file() and code==0 else None}
    if k in ('c','cpp'):
        binary.unlink(missing_ok=True);cc=required('gcc' if k=='c' else 'g++')
        code,out=run_cmd([cc,'-g','-O0','-Wall','-Wextra','-fdiagnostics-color=never',str(p),'-o',str(binary),'-lm'],p.parent)
        return {**base,'ok':code==0 and binary.is_file(),'output':out,'diagnostics':diagnostics(out,root,p,external_files),'binary':str(binary) if binary.is_file() and code==0 else None}
    if k in ('cs','csproj'):
        exe=required('dotnet');vcode,version=run_cmd([exe,'--version'],p.parent,timeout=15)
        try: major=int(version.strip().split('.')[0])
        except ValueError:major=0
        if k=='cs' and (vcode or major<10):raise ValueError('Un fichier C# seul nécessite le SDK .NET 10 ou plus récent.')
        code,out=run_cmd([exe,'build',str(p),'--nologo'],p.parent)
        command=[exe,'run','--file' if k=='cs' else '--project',str(p),'--no-build']
        return {**base,'ok':code==0,'output':out,'diagnostics':diagnostics(out,root,p,external_files),'command':command if code==0 else None,'cwd':str(p.parent)}
    if k=='asm':
        # L'assembleur a sa propre chaîne : assemblage puis édition de liens, avec
        # le choix de l'assembleur dicté par la SYNTAXE reconnue (AT&T -> as,
        # Intel -> nasm) et non par la seule extension. Sans cette branche, un
        # .asm tombait dans le cas cmake par défaut et échouait avec un message
        # qui ne parlait ni d'assembleur ni d'outil manquant. Chaque outil absent
        # est nommé avec sa commande d'installation.
        binary.unlink(missing_ok=True)
        try:
            import assembleur
        except ImportError:
            raise ValueError('Module assembleur introuvable : '
                             'l’assembleur ne peut pas être construit.')
        construction=assembleur.construire(p,build_dir,debug=debug)
        cle=source_key(str(p),root,p,external_files) or p.name
        rows=[dict(file=cle,line=d['line'],column=d['column'],
                   severity=d['severity'],message=d['message'])
              for d in construction.get('diagnostics',[])]
        # Les messages de l'assembleur lui-même (as, nasm, ld) sont ajoutés :
        # ils citent des lignes que l'analyse statique n'a pas nécessairement
        # prévues, et c'est l'assembleur qui fait foi.
        rows+=diagnostics(construction.get('output',''),root,p,external_files)
        return {**base,'ok':construction['ok'],'output':construction['output'],
                'diagnostics':rows,
                'binary':construction['binary'] if construction['ok'] else None}
    if k=='make':
        code,out=run_cmd([required('make'),'-f',str(p)],p.parent)
        matches=_executables(p.parent) if code==0 else []
    else:
        cmake=required('cmake');directory=build_dir/('cmake-'+digest);directory.mkdir(parents=True,exist_ok=True)
        query=directory/'.cmake/api/v1/query';query.mkdir(parents=True,exist_ok=True);(query/'codemodel-v2').touch()
        code,out=run_cmd([cmake,'-S',str(p.parent),'-B',str(directory)],p.parent)
        if code==0:
            code,part=run_cmd([cmake,'--build',str(directory)],p.parent);out+='\n'+part
        matches=_cmake_artifacts(directory) if code==0 else []
    return {**base,'ok':code==0,'output':out,'candidates':_register(matches,root),'cwd':str(p.parent)}

def analyze_native(root, path, key, content, external_files):
    """Analyse du seul tampon actif, sans édition de liens ni exécution."""
    root=Path(root).resolve();p=Path(path).resolve();k=kind(p)
    if k not in ('c','cpp'):return {'state':'unsupported','message':'Analyse en direct disponible pour Pascal, C et C++.'}
    compiler=shutil.which('gcc' if k=='c' else 'g++')
    if not compiler:return {'state':'unavailable','message':'Analyse indisponible : installez build-essential.'}
    if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
    cmd=[compiler,'-x','c' if k=='c' else 'c++','-fsyntax-only','-fdiagnostics-color=never','-fmax-errors=30','-Wall','-Wextra','-iquote',str(p.parent),'-']
    try:r=subprocess.run(cmd,cwd=p.parent,input=content,capture_output=True,text=True,errors='replace',timeout=15)
    except subprocess.TimeoutExpired:return {'state':'timeout','message':'Analyse interrompue après 15 secondes.'}
    found=[]
    for line in (r.stdout+'\n'+r.stderr).splitlines():
        m=GCC_RE.match(line)
        if not m:continue
        filename,row,col,severity,message=m.groups()
        if filename in ('<stdin>','-'):file=key
        else:
            f=Path(filename);f=(f if f.is_absolute() else p.parent/f).resolve()
            try:file=f.relative_to(root).as_posix()
            except ValueError:continue
        found.append(dict(file=file,line=int(row),column=int(col),severity=severity,message=message))
    return {'state':'ready','diagnostics':found,'ok':r.returncode==0,'message':None if r.returncode==0 or found else 'Analyse interrompue : '+(r.stderr or r.stdout)[-400:]}
