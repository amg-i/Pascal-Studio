"""Project TODO scan and opt-in, reviewable rename plans.

Only the current file's simple variable/parameter bindings use the conservative
scope analyser. Extra occurrences and file/directory names are textual candidates,
not a Pascal cross-file semantic analysis; clients must explicitly opt in.
"""
import hashlib, os, re, tempfile, threading, uuid, difflib, io, tokenize
from pathlib import Path
from refactor import TOKEN, KEYWORDS, RefactorError, rename_preview

CODE={'.pas','.pp','.p','.lpr','.inc'}
C_CODE={'.rs','.go','.c','.h','.cc','.cpp','.cxx','.hpp','.hh','.hxx','.cs'}
TEX_CODE={'.tex','.sty'}
NEW_CODE={'.f','.for','.ftn','.f77','.f90','.f95','.f03','.f08','.fpp','.pl','.pm','.bas','.yab','.ml','.mli','.lua'}
WEB_CODE={'.rb','.py','.js','.mjs','.cjs','.php','.html','.htm','.css'}
METADATA={'.lpi','.lpk','.cfg','.xml','.json','.md','.txt'}
IGNORED={'node_modules','build','dist','target','__pycache__'}
plans={}; plan_lock=threading.RLock()

def hash_text(text): return hashlib.sha256(text.encode('utf-8')).hexdigest()

def walk(root):
    root=Path(root).resolve(); files=[]; dirs=[]
    def onerror(error): raise ValueError('Dossier inaccessible : '+str(error))
    for parent, names, filenames in os.walk(root,followlinks=False,onerror=onerror):
        p=Path(parent)
        names[:]=sorted(n for n in names if not n.startswith('.') and n not in IGNORED and not (p/n).is_symlink())
        for name in names: dirs.append((p/name).relative_to(root).as_posix())
        for name in sorted(filenames):
            f=p/name
            if name.startswith('.') or f.is_symlink(): continue
            files.append(f.relative_to(root).as_posix())
            if len(files)>4000: raise ValueError('Projet trop volumineux : limite de 4 000 fichiers visibles.')
    return files,dirs

def read_text(root,path):
    file=(root/path).resolve()
    if not file.is_relative_to(root) or not file.is_file(): raise ValueError('Fichier hors projet ou introuvable : '+path)
    if file.stat().st_size>2_000_000:raise ValueError('Fichier trop volumineux : '+path)
    with file.open('r',encoding='utf-8',newline='') as stream: return stream.read()

COMMENT_OR_STRING=re.compile(r"'(?:''|[^'\r\n])*(?:'|(?=\r?$))|//[^\r\n]*|\{[^}]*\}?|\(\*.*?(?:\*\)|$)",re.S|re.M)

# Ignore string/character literals (including C++ raw and C# verbatim strings)
# before looking for line and block comments. Interpolated expression comments
# and preprocessor corner cases remain conservative.
C_TOKENS=re.compile(r'(?P<raw>(?:u8|u|U|L)?R"(?P<delimiter>[^ ()\\\t\r\n]{0,16})\(.*?\)(?P=delimiter)")|(?P<triple>""".*?""")|(?P<verbatim>@"(?:""|[^"])*")|(?P<string>"(?:\\.|[^"\\])*")|(?P<char>\'(?:\\.|[^\'\\])*\')|(?P<line>//[^\r\n]*)|(?P<block>/\*.*?(?:\*/|$))',re.S)

WEB_TOKENS=re.compile(r"(?P<raw>`(?:\\.|[^`\\])*`)|(?P<triple>\"\"\".*?\"\"\")|(?P<double>\"(?:\\.|[^\"\\])*\")|(?P<single>'(?:\\.|[^'\\])*')|(?P<html><!--.*?(?:-->|$))|(?P<line>//[^\r\n]*)|(?P<hash>\#[^\r\n]*)|(?P<block>/\*.*?(?:\*/|$))",re.S)

def additional_comments(path,src):
    suffix=Path(path).suffix.lower();i=0;n=len(src);fixed=suffix in ('.f','.for','.ftn','.f77')
    while i<n:
        start=i;c=src[i]
        if fixed and (i==0 or src[i-1]=='\n') and c in 'cC*!':
            end=src.find('\n',i);end=n if end<0 else end;yield i,src[i:end];i=end;continue
        if suffix in ('.ml','.mli') and src.startswith('(*',i):
            depth=1;i+=2
            while i<n and depth:
                if src.startswith('(*',i):depth+=1;i+=2
                elif src.startswith('*)',i):depth-=1;i+=2
                elif src[i] in '\"\'':
                    q=src[i];i+=1
                    while i<n and src[i]!=q:
                        if src[i]=='\\' and i+1<n:i+=1
                        i+=1
                    i+=i<n
                else:i+=1
            yield start,src[start:i];continue
        if suffix=='.lua' and src.startswith('--',i):
            m=re.match(r'--\[(=*)\[',src[i:])
            if m:
                endmark=']'+m.group(1)+']';end=src.find(endmark,i+len(m.group(0)));i=n if end<0 else end+len(endmark)
            else:
                end=src.find('\n',i);i=n if end<0 else end
            yield start,src[start:i];continue
        if suffix=='.lua' and c=='[':
            m=re.match(r'\[(=*)\[',src[i:])
            if m:
                endmark=']'+m.group(1)+']';end=src.find(endmark,i+len(m.group(0)));i=n if end<0 else end+len(endmark);continue
        if (suffix in ('.pl','.pm') and c=='#') or (suffix in ('.bas','.yab') and (src.startswith("//",i) or (c in "#\'" and not src[src.rfind("\n",0,i)+1:i].strip()) or re.match(r'(?i:rem)\b',src[i:]) and (i==0 or src[i-1] in ' \t:'))) or (suffix in NEW_CODE- {'.pl','.pm','.bas','.yab','.ml','.mli','.lua'} and c=='!'):
            end=src.find('\n',i);i=n if end<0 else end;yield start,src[start:i];continue
        if c in '\"\'':
            if suffix in ('.ml','.mli') and c=="'" and not re.match(r"'(?:\\.|[^'\\])'",src[i:]):i+=1;continue
            q=c;i+=1
            while i<n:
                if src[i]==q:
                    if suffix in NEW_CODE- {'.pl','.pm','.ml','.mli','.lua'} and i+1<n and src[i+1]==q:i+=2;continue
                    i+=1;break
                if src[i]=='\\' and i+1<n:i+=2
                else:i+=1
            continue
        i+=1

def comments_for(path,src):
    suffix=Path(path).suffix.lower()
    if suffix in NEW_CODE:
        yield from additional_comments(path,src)
    elif suffix=='.py':
        # tokenize distinguishes strings (including multiline literals) and comments.
        try:
            for tok in tokenize.generate_tokens(io.StringIO(src).readline):
                if tok.type==tokenize.COMMENT:
                    line,col=tok.start;pos=sum(len(x) for x in src.splitlines(keepends=True)[:line-1])+col
                    yield pos,tok.string
        except (tokenize.TokenError,IndentationError,SyntaxError):pass
    elif suffix in TEX_CODE:
        pos=0
        for line in src.splitlines(keepends=True):
            for match in re.finditer(r'%[^\r\n]*',line):
                j=match.start()-1
                while j>=0 and line[j]=='\\':j-=1
                if (match.start()-1-j)%2==0:
                    yield pos+match.start(),match.group();break
            pos+=len(line)
    elif suffix in WEB_CODE:
        for tok in WEB_TOKENS.finditer(src):
            k=tok.lastgroup
            if k=='block' or (k=='line' and suffix in ('.js','.mjs','.cjs','.php')) or (k=='hash' and suffix in ('.php','.rb')) or (k=='html' and suffix in ('.html','.htm','.php')):
                yield tok.start(),tok.group()
    else:
        for tok in (C_TOKENS if suffix in C_CODE else COMMENT_OR_STRING).finditer(src):
            comment=tok.group()
            if comment.startswith(('{','(*','//','/*')):yield tok.start(),comment

def todos(root, overlays=None):
    root=Path(root).resolve(); files,_=walk(root); found=[]; skipped=[]
    overlays=overlays or {}
    if not isinstance(overlays,dict):raise ValueError('Tampons invalides.')
    for path in files:
        if Path(path).suffix.lower() not in CODE|C_CODE|WEB_CODE|TEX_CODE|NEW_CODE: continue
        try:
            src=overlays[path] if path in overlays else read_text(root,path)
            if not isinstance(src,str) or len(src.encode('utf-8'))>2_000_000:raise ValueError('Fichier trop volumineux')
        except (UnicodeError,OSError,ValueError):skipped.append(path);continue
        for start,comment in comments_for(path,src):
            if re.match(r'^(?:\{\s*\$|\(\*\s*\$)',comment): continue
            for m in re.finditer(r'\b(TODO|FIXME)\b[ \t]*[:\-]?[ \t]*([^\r\n}]*?)(?=\b(?:TODO|FIXME)\b|\*/|-->|\*\)|$)',comment,re.I|re.M):
                pos=start+m.start();line=src.count('\n',0,pos)+1;line_start=src.rfind('\n',0,pos)+1;col=len(src[line_start:pos].encode('utf-16-le'))//2+1
                found.append({'path':path,'line':line,'column':col,'kind':m.group(1).upper(),'message':m.group(2).strip()})
                if len(found)>=2000:return {'items':found,'skipped':skipped,'truncated':True}
    return {'items':found,'skipped':skipped,'truncated':False}

def candidates(source,old,include_comments=False,include_literals=False):
    """Return positions from tokens; never inspect quoted text unless requested."""
    out=[]; ident=re.compile(r'(?<![A-Za-z0-9_])'+re.escape(old)+r'(?![A-Za-z0-9_])',re.I)
    for t in TOKEN.finditer(source):
        v=t.group(); comment=v.startswith(('{','(*','//')); string=v.startswith("'")
        if comment:
            if not include_comments or re.match(r'^(?:\{\s*\$|\(\*\s*\$)',v):continue
            out.extend((t.start()+m.start(),t.start()+m.end(),'comment') for m in ident.finditer(v))
        elif string:
            if include_literals: out.extend((t.start()+m.start(),t.start()+m.end(),'literal') for m in ident.finditer(v))
        elif v.lower()==old.lower():out.append((t.start(),t.end(),'code'))
    return out

def make_plan(root,path,source,prefix,new_name,options):
    root=Path(root).resolve()
    if not isinstance(path,str) or path.startswith('@external:'):raise ValueError('Ouvrez le dossier du fichier comme projet avant de refactoriser plusieurs fichiers.')
    if not isinstance(source,str) or not isinstance(prefix,str) or not source.startswith(prefix):raise ValueError('Position ou source invalide.')
    file=(root/path).resolve()
    if not file.is_relative_to(root) or not file.is_file():raise ValueError('Fichier hors projet ou introuvable.')
    if Path(path).suffix.lower() not in CODE:raise ValueError('La refactorisation concerne les fichiers Pascal.')
    if not isinstance(new_name,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',new_name) or new_name.lower() in KEYWORDS:raise ValueError('Nouveau nom Pascal invalide.')
    if read_text(root,path)!=source:raise ValueError('Le fichier a changé sur le disque. Rechargez-le avant de refactoriser.')
    position=len(prefix); selected=next((m for m in TOKEN.finditer(source) if m.start()<=position<m.end()),None)
    if selected is None and position: selected=next((m for m in TOKEN.finditer(source) if m.end()==position),None)
    if not selected or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',selected.group()):raise ValueError('Placez le curseur sur un identifiant.')
    old=selected.group()
    if old.lower() in KEYWORDS: raise ValueError('Un mot réservé Pascal ne peut pas être renommé.')
    if old.lower()==new_name.lower():raise ValueError('Le nouveau nom doit être différent.')
    semantic_error=None; semantic=[]; scope='indéterminée'
    try:
        result=rename_preview(source,position,new_name);scope=result['scope'];semantic=[(e['start'],e['end'],'semantic') for e in result['edits']]
    except RefactorError as e: semantic_error=str(e)
    if semantic_error and not options.get('other'):
        # No safe edits can be offered unless the user explicitly chooses textual matches.
        return {'error':semantic_error,'needsTextual':True,'symbol':old,'files':[],'moves':[]}
    files,dirs=walk(root)
    other=bool(options.get('other')); comments=bool(options.get('comments')); names=bool(options.get('names')); literals=bool(options.get('literals'))
    to_check=files if other or (comments and other) or literals else [path]
    changes={}; summary=[]; skipped=[]; total_unresolved=0
    for rel in to_check:
        ext=Path(rel).suffix.lower()
        if rel!=path and ext not in CODE and not (literals and ext in METADATA):continue
        try: text=source if rel==path else read_text(root,rel)
        except (ValueError,UnicodeError,OSError): skipped.append(rel);continue
        selected_edits=[]
        if rel==path:selected_edits.extend(semantic)
        if ext in CODE:
            for start,end,kind in candidates(text,old,include_comments=comments,include_literals=literals):
                if kind=='code' and not other: continue
                if kind=='comment' and not comments:continue
                if kind=='literal' and not literals:continue
                if not any(start==e[0] and end==e[1] for e in selected_edits):selected_edits.append((start,end,kind))
        elif literals:
            for m in re.finditer(r'(?<![A-Za-z0-9_])'+re.escape(old)+r'(?![A-Za-z0-9_])',text,re.I):selected_edits.append((m.start(),m.end(),'literal'))
        if not selected_edits: continue
        selected_edits.sort();out=text
        for a,b,_ in reversed(selected_edits):out=out[:a]+new_name+out[b:]
        counts={k:sum(1 for _,_,typ in selected_edits if typ==k) for k in ('semantic','code','comment','literal')}
        total_unresolved+=counts['code']+counts['literal']
        changes[rel]={'before':text,'after':out,'hash':hash_text(text)}
        diff=list(difflib.unified_diff(text.splitlines(),out.splitlines(),fromfile=rel,tofile=rel,lineterm='',n=1)); summary.append({'path':rel,'count':len(selected_edits),'counts':counts,'diff':'\n'.join(diff[:120]),'diffTruncated':len(diff)>120})
    moves=[]
    if names:
        for rel in files:
            p=Path(rel)
            if p.stem.lower()==old.lower():moves.append({'from':rel,'to':(p.parent/(new_name+p.suffix)).as_posix(),'type':'file'})
        for rel in dirs:
            p=Path(rel)
            if p.name.lower()==old.lower():moves.append({'from':rel,'to':(p.parent/new_name).as_posix(),'type':'folder'})
        moves.sort(key=lambda x:(-len(Path(x['from']).parts),x['type']=='folder'))
        for move in moves:
            dest=root/move['to']
            if dest.exists():raise ValueError('Renommage impossible : la destination existe déjà : '+move['to'])
    if not changes and not moves:raise ValueError('Aucune occurrence à modifier.')
    key=uuid.uuid4().hex
    with plan_lock:
        plans.clear() # one pending transaction per server
        affected=[f for f in files if any((m['type']=='file' and f==m['from']) or (m['type']=='folder' and f.startswith(m['from']+'/')) for m in moves)]
        def fingerprint(rel):
            st=(root/rel).stat(); return (st.st_ino,st.st_size,st.st_mtime_ns)
        plans[key]={'root':root,'changes':changes,'moves':moves,'affected':{f:fingerprint(f) for f in affected}}
    return {'id':key,'symbol':old,'newName':new_name,'scope':scope,'semanticError':semantic_error,'files':summary,'moves':moves,'unresolved':total_unresolved,'skipped':skipped}

def write_atomic(path,text):
    mode=path.stat().st_mode
    fd,tmp=tempfile.mkstemp(prefix='.pascal-refactor-',dir=path.parent)
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as out:out.write(text);out.flush();os.fsync(out.fileno())
        os.chmod(tmp,mode);os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def apply_plan(root,key):
    root=Path(root).resolve()
    with plan_lock:
        plan=plans.pop(key,None)
        if not plan or plan['root']!=root:raise ValueError('Aperçu expiré. Recommencez la refactorisation.')
        changes=plan['changes']; moves=plan['moves']
        for rel,change in changes.items():
            if hash_text(read_text(root,rel))!=change['hash']:raise ValueError('Fichier modifié depuis l’aperçu : '+rel)
        if moves:
            current_files,_=walk(root)
            affected_now={f for f in current_files if any((m['type']=='file' and f==m['from']) or (m['type']=='folder' and f.startswith(m['from']+'/')) for m in moves)}
            if affected_now!=set(plan['affected']): raise ValueError('Le contenu des dossiers à renommer a changé depuis l’aperçu.')
            for rel,old_stat in plan['affected'].items():
                st=(root/rel).stat()
                if (st.st_ino,st.st_size,st.st_mtime_ns)!=old_stat: raise ValueError('Fichier modifié depuis l’aperçu : '+rel)
        for move in moves:
            src=(root/move['from']);dest=(root/move['to'])
            if src.is_symlink() or not src.exists() or not src.resolve().is_relative_to(root) or not dest.parent.resolve().is_relative_to(root):raise ValueError('Élément déplacé ou hors projet depuis l’aperçu : '+move['from'])
            if dest.exists():raise ValueError('Destination déjà existante : '+move['to'])
        done=[];written=[]
        try:
            for rel,change in changes.items():write_atomic(root/rel,change['after']);written.append(rel)
            for move in moves:
                src=root/move['from'];dst=root/move['to'];src.rename(dst);done.append(move)
        except Exception as e:
            rollback_errors=[]
            for move in reversed(done):
                try:(root/move['to']).rename(root/move['from'])
                except Exception as err:rollback_errors.append(str(err))
            for rel in written:
                try:write_atomic(root/rel,changes[rel]['before'])
                except Exception as err:rollback_errors.append(str(err))
            raise ValueError('Refactorisation interrompue. '+('Restauration incomplète : '+ '; '.join(rollback_errors) if rollback_errors else 'Les modifications ont été annulées.')+' Cause : '+str(e))
        mapping={}
        # Compute the eventual location of every affected file, including nested moves.
        for rel in set(changes)|{m['from'] for m in moves if m['type']=='file'}:
            current=rel
            for m in moves:
                if current==m['from'] or (m['type']=='folder' and current.startswith(m['from']+'/')):current=m['to']+current[len(m['from']):]
            mapping[rel]=current
        return {'ok':True,'mapping':mapping,'moves':moves,'files':len(changes)}
