"""Publish PDFs beside their sources; protect unrelated or modified files.

A private cache ledger records source and hash of files published by this app.
Replacement uses atomic rename after a last hash check, not interprocess CAS.
"""
import errno,fcntl,hashlib,json,os,stat,tempfile,threading
from pathlib import Path

MAX_PDF=75_000_000
class Publisher:
 def __init__(self,cache=None):
  self.directory=Path(cache or ((os.environ.get('XDG_CACHE_HOME') or str(Path.home()/'.cache'))+'/pascal-studio/publications'))
  self.lock=threading.RLock()
 def _hash(self,p):
  h=hashlib.sha256()
  with p.open('rb') as stream:
   while True:
    chunk=stream.read(1024*1024)
    if not chunk:break
    h.update(chunk)
  return h.hexdigest()
 def publish(self,source,data,expected_hash=None):
  source=Path(source).resolve()
  if not source.is_file() or source.suffix.lower() not in ('.tex','.psnote'):raise ValueError('Document source introuvable ou incompatible.')
  if not isinstance(data,bytes) or len(data)>MAX_PDF or not data.startswith(b'%PDF-'):raise ValueError('PDF invalide ou trop volumineux (limite 75 Mo).')
  target=source.with_suffix('.pdf')
  if target==source:raise ValueError('Destination invalide.')
  try:self.directory.mkdir(parents=True,exist_ok=True)
  except OSError as e:raise ValueError('Impossible d’accéder au cache des exports : '+str(e)) from e
  ledger=self.directory/'productions.json';lockfile=self.directory/'productions.lock'
  with self.lock,lockfile.open('a+b') as lock:
   fcntl.flock(lock,fcntl.LOCK_EX)
   try:
    try:records=json.loads(ledger.read_text(encoding='utf-8'))
    except (OSError,UnicodeError,ValueError):records={}
    if not isinstance(records,dict):records={}
    key=str(target);owner=str(source);existing=None;oldmode=0o600
    if target.is_symlink():raise ValueError('Le PDF de destination est un lien symbolique ; export annulé pour éviter un écrasement inattendu.')
    if target.exists():
     if not target.is_file():raise ValueError('La destination PDF existe mais n’est pas un fichier ordinaire.')
     if target.stat().st_size>MAX_PDF:raise ValueError('Le PDF existant dépasse 75 Mo : renommez-le ou déplacez-le avant de réessayer.')
     existing=self._hash(target);oldmode=stat.S_IMODE(target.stat().st_mode)
     tracked=records.get(key,{})
     trusted=isinstance(tracked,dict) and tracked.get('source')==owner and tracked.get('sha256')==existing
     if not trusted and expected_hash!=existing:
      return {'status':'conflict','destination':str(target),'existingHash':existing,'message':'Un PDF existe déjà et ne correspond pas à la dernière version produite pour ce document.'}
    fd,tmp=tempfile.mkstemp(prefix='.pascal-studio-pdf-',suffix='.tmp',dir=target.parent)
    try:
     with os.fdopen(fd,'wb') as out:out.write(data);out.flush();os.fsync(out.fileno())
     os.chmod(tmp,oldmode)
     if existing is None:
      try:os.link(tmp,target)
      except OSError as e:
       if e.errno==errno.EEXIST:
        if target.is_symlink() or not target.is_file() or target.stat().st_size>MAX_PDF:raise ValueError('La destination a changé pendant l’export ; aucun remplacement effectué.')
        return {'status':'conflict','destination':str(target),'existingHash':self._hash(target),'message':'Un PDF est apparu pendant l’export.'}
       if e.errno not in (errno.EPERM,errno.EOPNOTSUPP,errno.ENOSYS,errno.EXDEV,errno.EMLINK):raise
       # Some removable/FUSE filesystems do not support hard links. Exclusive
       # create still prevents overwriting an existing file; a crash can leave
       # an incomplete newly created file on those filesystems.
       try:outfd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,oldmode)
       except FileExistsError:
        if target.is_symlink() or not target.is_file() or target.stat().st_size>MAX_PDF:raise ValueError('La destination a changé pendant l’export ; aucun remplacement effectué.')
        return {'status':'conflict','destination':str(target),'existingHash':self._hash(target),'message':'Un PDF est apparu pendant l’export.'}
       identity=os.fstat(outfd)
       try:
        with os.fdopen(outfd,'wb') as out:out.write(data);out.flush();os.fsync(out.fileno())
       except BaseException:
        try:
         current=os.lstat(target)
         if (current.st_dev,current.st_ino)==(identity.st_dev,identity.st_ino):target.unlink()
        except OSError:pass
        raise
      os.unlink(tmp);tmp=None
     else:
      if target.is_symlink() or not target.is_file():raise ValueError('La destination a changé pendant l’export ; aucun remplacement effectué.')
      now=self._hash(target)
      if now!=existing:return {'status':'conflict','destination':str(target),'existingHash':now,'message':'Le PDF a changé pendant l’export ; aucun remplacement effectué.'}
      os.replace(tmp,target);tmp=None
    finally:
     if tmp:
      try:os.unlink(tmp)
      except OSError:pass
    output_hash=hashlib.sha256(data).hexdigest();records[key]={'source':owner,'sha256':output_hash}
    warning=None;name=None
    try:
     fd,name=tempfile.mkstemp(prefix='.productions-',dir=self.directory)
     with os.fdopen(fd,'w',encoding='utf-8') as f:json.dump(records,f,ensure_ascii=False);f.flush();os.fsync(f.fileno())
     os.replace(name,ledger);name=None
    except OSError as e:warning='PDF enregistré ; historique de remplacement indisponible : '+str(e)
    finally:
     if name:
      try:os.unlink(name)
      except OSError:pass
    return {'status':'saved','destination':str(target),'sha256':output_hash,'warning':warning}
   finally:fcntl.flock(lock,fcntl.LOCK_UN)
