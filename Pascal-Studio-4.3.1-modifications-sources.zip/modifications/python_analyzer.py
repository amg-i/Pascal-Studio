#!/usr/bin/env python3
"""Non-executing Python buffer diagnostics; invoked in an isolated subprocess."""
import ast, json, re, sys, warnings
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor-python'))
from pyflakes.checker import Checker

ERRORS={'UndefinedName','UndefinedLocal','UndefinedExport','DuplicateArgument','ImportStarNotPermitted','FutureFeatureNotDefined','LateFutureImport','ReturnOutsideFunction','YieldOutsideFunction','ContinueOutsideLoop','BreakOutsideLoop','DefaultExceptNotLast','TwoStarredExpressions','TooManyExpressionsInStarredAssignment','ForwardAnnotationSyntaxError','InvalidPrintSyntax'}
TRANSLATIONS={
 'UndefinedName':lambda x:f"Nom non défini : {x[0]}. Il peut provoquer une NameError si cette ligne est exécutée.",
 'UndefinedLocal':lambda x:f"Variable locale {x[0]} utilisée avant son affectation."+(f" Définition ligne {x[1]}." if len(x)>1 else ''),
 'UndefinedExport':lambda x:f"Nom exporté dans __all__ mais non défini : {x[0]}.",
 'UnusedImport':lambda x:f"Import inutilisé : {x[0]}.",
 'UnusedVariable':lambda x:f"Variable locale affectée mais inutilisée : {x[0]}.",
 'UnusedAnnotation':lambda x:f"Annotation locale inutilisée : {x[0]}.",
 'RedefinedWhileUnused':lambda x:f"{x[0]} est redéfini avant utilisation (définition ligne {x[1]}).",
 'ImportShadowedByLoopVar':lambda x:f"La variable de boucle masque l’import {x[0]} de la ligne {x[1]}.",
 'ImportStarUsed':lambda x:f"Import * de {x[0]} : les noms disponibles ne peuvent pas tous être vérifiés.",
 'ImportStarUsage':lambda x:f"{x[0]} peut être indéfini ou provenir d’un import * : {x[1]}.",
 'FStringMissingPlaceholders':lambda x:"Chaîne f sans expression entre accolades.",
 'IsLiteral':lambda x:'Comparaison « is » avec un littéral ; utilisez généralement ==.',
 'IfTuple':lambda x:'Un tuple non vide dans une condition est toujours vrai.',
 'AssertTuple':lambda x:'Un tuple non vide dans assert est toujours vrai.',
 'RaiseNotImplemented':lambda x:'Utilisez NotImplementedError pour lever une exception.',
 'MultiValueRepeatedKeyLiteral':lambda x:f"Clé de dictionnaire répétée : {x[0]}.",
}

def utf16_col(text,character_index):
 return len(text[:max(0,character_index)].encode('utf-16-le',errors='surrogatepass'))//2+1

def ast_byte_to_char(text,n):
 return len(text.encode('utf8')[:max(0,n)].decode('utf8',errors='ignore'))

def position(lines,row,character_index,length=1):
 row=max(1,min(row,max(1,len(lines))));line=lines[row-1] if lines else ''
 character_index=max(0,min(character_index,len(line)))
 start=utf16_col(line,character_index);end=utf16_col(line,min(len(line),character_index+max(1,length)))
 return row,start,max(start+1,end)

def add(diags,key,row,col,end,severity,message,code):
 diags.append({'file':key,'line':row,'column':col,'endColumn':end,'severity':severity,'message':message,'code':code})

def analyze(content,path,key):
 lines=content.splitlines(); diags=[];syntax_ok=True
 # compile validates constructs such as return/break outside a function/loop;
 # it produces bytecode but never imports or runs the user's program.
 with warnings.catch_warnings(record=True) as caught:
  warnings.simplefilter('always',SyntaxWarning)
  try:compile(content,path,'exec',dont_inherit=True)
  except (SyntaxError,ValueError,OverflowError,RecursionError) as e:
   syntax_ok=False
   if isinstance(e,SyntaxError):
    row=e.lineno or 1;idx=max(0,(e.offset or 1)-1);row,col,end=position(lines,row,idx)
    kind='Indentation' if isinstance(e,IndentationError) else 'Syntaxe'
    add(diags,key,row,col,end,'error',f'{kind} Python : {e.msg}',type(e).__name__)
   else:add(diags,key,1,1,2,'error','Analyse Python : '+str(e),type(e).__name__)
  for w in caught:
   row,col,end=position(lines,w.lineno or 1,0)
   add(diags,key,row,col,end,'warning',f'{w.category.__name__} : {w.message}',w.category.__name__)
 if syntax_ok:
  tree=ast.parse(content,filename=path)
  checker=Checker(tree,filename=key)
  for m in checker.messages[:500]:
   typ=type(m).__name__;args=m.message_args;args=(args,) if isinstance(args,str) else args;row=m.lineno or 1;line=lines[row-1] if 0<row<=len(lines) else ''
   idx=ast_byte_to_char(line,m.col or 0);length=1
   # Point at the relevant name instead of the start of an import statement.
   if args and isinstance(args[0],str) and typ in ('UndefinedName','UndefinedLocal','UnusedImport','UnusedVariable','UnusedAnnotation','UndefinedExport','RedefinedWhileUnused','ImportShadowedByLoopVar'):
    name=args[0].split('.')[-1];found=line.find(name,idx)
    if found>=0:idx=found;length=len(name)
   row,col,end=position(lines,row,idx,length)
   try:message=TRANSLATIONS[typ](args) if typ in TRANSLATIONS else 'Python : '+(m.message % args)
   except Exception:message='Python : '+str(m)
   add(diags,key,row,col,end,'error' if typ in ERRORS else 'warning',message,typ)
  # Literal zero is a certain failure only if the expression is reached.
  for node in ast.walk(tree):
   if not isinstance(node,ast.BinOp) or not isinstance(node.op,(ast.Div,ast.FloorDiv,ast.Mod)):continue
   rhs=node.right
   if isinstance(rhs,ast.UnaryOp) and isinstance(rhs.op,(ast.UAdd,ast.USub)):rhs=rhs.operand
   if isinstance(rhs,ast.Constant) and type(rhs.value) in (int,float,complex) and rhs.value==0:
    left=node.left
    if isinstance(left,ast.UnaryOp) and isinstance(left.op,(ast.UAdd,ast.USub)):left=left.operand
    known_number=isinstance(left,ast.Constant) and type(left.value) in (int,float,complex)
    if isinstance(node.op,ast.Mod) and isinstance(left,ast.Constant) and isinstance(left.value,(str,bytes)):continue
    row=node.right.lineno;line=lines[row-1] if 0<row<=len(lines) else '';idx=ast_byte_to_char(line,node.right.col_offset)
    row,col,end=position(lines,row,idx)
    msg=('Division ou modulo par zéro si cette expression est exécutée.' if known_number else 'Risque de division ou modulo par zéro si les opérandes sont numériques et l’expression exécutée.')
    add(diags,key,row,col,end,'error' if known_number else 'warning',msg,'ZeroDivisionLiteral')
 # Deterministic output, with duplicates removed (CPython may warn twice).
 unique=[];seen=set()
 for d in sorted(diags,key=lambda d:(d['line'],d['column'],d['severity'],d['message'])):
  fingerprint=(d['line'],d['column'],d['severity'],d['message'])
  if fingerprint not in seen:seen.add(fingerprint);unique.append(d)
 return {'state':'ready','ok':syntax_ok,'syntax_ok':syntax_ok,'diagnostics':unique[:500], 'message':f"Analyse Python : {sum(d['severity']=='error' for d in unique)} erreur(s), {sum(d['severity']=='warning' for d in unique)} avertissement(s)"}

if __name__=='__main__':
 try:
  content=sys.stdin.read();result=analyze(content,sys.argv[1],sys.argv[2]);print(json.dumps(result,ensure_ascii=True))
 except BaseException as e:
  print(json.dumps({'state':'unavailable','ok':False,'diagnostics':[],'message':'Analyse Python indisponible : '+str(e)},ensure_ascii=True))
