#!/usr/bin/env python3
"""Private Python debugger worker: bdb executes the user's script with its real stdio.

The control channel is an inherited Unix socket, not a TCP listener. Only the
main Python thread is traced; child threads/processes do not inherit tracing.
"""
import bdb, json, os, reprlib, socket, sys, threading, tokenize, traceback

fd=int(os.environ.pop('PS_DEBUG_FD'))
sock=socket.socket(fileno=fd)
writer_lock=threading.Lock()

def send(obj):
    data=(json.dumps(obj,ensure_ascii=True,default=str)+'\n').encode()
    with writer_lock: sock.sendall(data)

def short(value):
    try:
        r=reprlib.Repr(); r.maxstring=500; r.maxother=500; r.maxlist=20; r.maxdict=20
        return r.repr(value)
    except BaseException as exc: return '<repr impossible: '+type(exc).__name__+'>'

class Runtime(bdb.Bdb):
    def __init__(self):
        super().__init__();self.lock=threading.Condition();self.frame=None;self.config=None;self.ready=threading.Event();self.start_error=None
    def breakpoint(self,path,line,enabled):
        path=self.canonic(path);line=int(line)
        if line<1: raise ValueError('Ligne invalide.')
        err=self.set_break(path,line) if enabled else self.clear_break(path,line)
        if err and not (not enabled and 'There is no breakpoint' in err):raise ValueError(err)
    def emit_pause(self,frame,reason):
        frames=[]; f=frame
        while f and len(frames)<80:
            frames.append({'file':f.f_code.co_filename,'line':f.f_lineno,'function':f.f_code.co_name,'level':str(len(frames))});f=f.f_back
        # Drop the helper's own outer frames, but retain imported/project callers.
        frames=[f for f in frames if f['file']!=__file__]
        variables=[{'name':str(k),'value':short(v)} for k,v in list(frame.f_locals.items())[:300] if not str(k).startswith('__')]
        with self.lock:
            self.frame=frame
            send({'event':'paused','reason':reason,'frames':frames,'variables':variables})
            while self.frame is frame:self.lock.wait()
    def user_line(self,frame):self.emit_pause(frame,'breakpoint ou pas à pas')
    def user_return(self,frame,value):self.emit_pause(frame,'retour de fonction')
    def user_exception(self,frame,info):self.emit_pause(frame,'exception '+getattr(info[0],'__name__',''))
    def request(self,cmd,args):
        if cmd=='setup':
            self.config=args
            try:
                for bp in args['breakpoints']:self.breakpoint(bp['path'],bp['line'],True)
            except Exception as e:self.start_error=str(e)
            self.ready.set()
            if self.start_error:raise ValueError(self.start_error)
            return {}
        if cmd=='breakpoint':self.breakpoint(args['path'],args['line'],args['enabled']);return {}
        if cmd=='pause':self.set_step();return {}
        with self.lock:
            f=self.frame
            if f is None:raise ValueError('Le programme doit être en pause.')
            if cmd=='evaluate':
                value=eval(args['expression'],f.f_globals,f.f_locals)
                return {'value':short(value)}
            if cmd=='continue':self.set_continue()
            elif cmd=='next':self.set_next(f)
            elif cmd=='step':self.set_step()
            elif cmd=='finish':self.set_return(f)
            else:raise ValueError('Commande inconnue.')
            self.frame=None;send({'event':'running'});self.lock.notify_all();return {}
    def reader(self):
        try:
            with sock.makefile('r',encoding='utf-8') as f:
                for line in f:
                    try:
                        req=json.loads(line);result=self.request(req['command'],req.get('args',{}));send({'id':req['id'],'result':result})
                    except BaseException as exc:send({'id':req.get('id'),'error':str(exc) or type(exc).__name__})
        except (OSError,EOFError):pass
        finally:os._exit(0)

rt=Runtime();threading.Thread(target=rt.reader,daemon=True).start();rt.ready.wait()
if rt.start_error:sys.exit(1)
target=rt.config['target'];sys.argv=[target];sys.path[0]=os.path.dirname(target)
namespace={'__name__':'__main__','__file__':target,'__package__':None,'__cached__':None,'__builtins__':__builtins__}
try:
    with tokenize.open(target) as f:code=compile(f.read(),target,'exec')
    # runcall initially steps into exec; continue directly to the first breakpoint.
    rt.reset();rt.botframe=sys._getframe();rt.set_continue();sys.settrace(rt.trace_dispatch)
    exec(code,namespace,namespace)
except bdb.BdbQuit:pass
except SystemExit as e:
    if e.code not in (None,0):print('SystemExit:',e.code,file=sys.stderr)
except BaseException:traceback.print_exc()
finally:
    sys.settrace(None)
    try:send({'event':'finished'})
    except OSError:pass
    sock.close()
