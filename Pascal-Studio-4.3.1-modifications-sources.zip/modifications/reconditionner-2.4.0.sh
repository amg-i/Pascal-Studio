#!/bin/sh
# Reconditionnement depuis l’AppImage 2.4.0 fournie et les fichiers fournis.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=31952d01e836168ffdbb436d871d773027396253ef1a4de1aad972670f691632
[ "$BASE" != "$OUT" ] || { echo 'Choisissez un fichier de sortie différent.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.4.0 de base inattendue.' >&2; exit 1; }
command -v mksquashfs >/dev/null; command -v asar >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
cp "$SRC/polyglot.py" "$SRC/scripting.py" "$SRC/server.py" "$SRC/project_tools.py" "$SRC/python_analyzer.py" "$SRC/python_runtime_diagnostics.py" "$R/"
rm -rf "$R/vendor-python"; cp -R "$SRC/vendor-python" "$R/vendor-python"
find "$R/vendor-python" -type d -name __pycache__ -prune -exec rm -rf {} +
cp "$SRC/../interface-compilee/index-BA4XgQVD.js" "$A/index-BA4XgQVD.js"
cp "$SRC/nouveaux-langages-aide.js" "$A/"; cp "$SRC/monaco-basic/"*.js "$A/"; cp "$SRC/MONACO-LICENSE.txt" "$A/monaco-license.txt"
asar extract "$R/app.asar" "$TMP/asar"; cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"; asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
