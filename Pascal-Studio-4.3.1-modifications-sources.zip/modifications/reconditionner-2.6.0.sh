#!/bin/sh
# Reconstruction de la 2.6.0 à partir de l’AppImage 2.6.0 exacte.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=ea74af23af28f0f0cdc76a8fe84a2c8c016135974ef15428fa838abaef1da7e0
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.6.0 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
for file in server.py polyglot.py project_tools.py integrated_terminal.py latex_tools.py; do cp "$SRC/$file" "$R/"; done
cp "$SRC/../interface-compilee/index-BA4XgQVD.js" "$A/index-BA4XgQVD.js"
for file in aide-latex.js terminal-bundle.js terminal-bundle.css terminal-latex.css pdf-viewer-bundle.js pdf.worker.mjs; do cp "$SRC/$file" "$A/"; done
mkdir -p "$R/licenses"; cp "$SRC/LICENSE-xterm.txt" "$SRC/LICENSE-xterm-addon-fit.txt" "$SRC/LICENSE-pdfjs.txt" "$R/licenses/"
asar extract "$R/app.asar" "$TMP/asar"; cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"; cp "$SRC/desktop-preload.cjs" "$TMP/asar/desktop/preload.cjs"
python3 - "$TMP/asar/package.json" <<'PY'
import json,sys
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.6.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
