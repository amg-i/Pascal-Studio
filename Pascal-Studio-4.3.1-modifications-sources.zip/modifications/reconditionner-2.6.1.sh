#!/bin/sh
# Reconditionnement depuis l’AppImage 2.6.1 exacte ; l’interface reste compilée.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=c9b9ca6dd3ad0ca7675e78095d7b68c5333e369611f367cf1cb477cf6b43c018
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.6.1 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
for file in server.py latex_tools.py latex_live.py polyglot.py project_tools.py integrated_terminal.py; do cp "$SRC/$file" "$R/"; done
cp "$SRC/../interface-compilee/index-BA4XgQVD.js" "$A/"
for file in aide-latex.js terminal-bundle.js terminal-bundle.css terminal-latex.css pdf-viewer-bundle.js pdf.worker.mjs; do cp "$SRC/$file" "$A/"; done
asar extract "$R/app.asar" "$TMP/asar"; cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"; cp "$SRC/desktop-preload.cjs" "$TMP/asar/desktop/preload.cjs"; asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
