#!/bin/sh
# Reconditionne 2.7.1 depuis l’AppImage 2.7.0 d’origine ou une AppImage 2.7.1.
# Exige python3, asar (@electron/asar) et mksquashfs. Sortie distincte de la base.
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-2.7.1.sh BASE.AppImage SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
command -v python3 >/dev/null; command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$BASE" <<'PY'
import json,sys,hashlib
p,base=sys.argv[1:];d=json.load(open(p));v=d.get('version')
if v=='2.7.0':
 with open(base,'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 if h!='7888f77e8a1e5735f0d343c301324341437de91f2ced86d2866d26d91b533898':raise SystemExit('AppImage 2.7.0 de base inattendue.')
elif v!='2.7.1':raise SystemExit('Base attendue : AppImage Pascal Studio 2.7.0 exacte ou 2.7.1.')
open(p+'.base-version','w').write(v)
d['version']='2.7.1';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
for f in server.py latex_tools.py publication.py; do cp "$SRC/$f" "$R/"; done
for f in document-bundle.js document-ui.css aide-latex.js; do cp "$SRC/$f" "$A/"; done
if [ "$(cat "$TMP/asar/package.json.base-version")" = '2.7.0' ]; then
 python3 "$SRC/patch_export_2.7.1.py" "$A/index-BA4XgQVD.js"
fi
rm "$TMP/asar/package.json.base-version"
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
