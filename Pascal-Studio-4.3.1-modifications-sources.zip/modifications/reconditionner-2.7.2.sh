#!/bin/sh
# 2.7.2 : correction expérimentale du focus seulement, gestionnaire non inclus.
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-2.7.2.sh BASE.AppImage SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
command -v python3 >/dev/null; command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$BASE" <<'PY'
import json,sys,hashlib
p,base=sys.argv[1:];d=json.load(open(p));v=d.get('version')
if v=='2.7.1':
 with open(base,'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 if h!='bc6520c44be5cf53955d9484d6ddcf323564c73b74eeea25788359b6c6d2893a':raise SystemExit('AppImage 2.7.1 de base inattendue.')
elif v!='2.7.2':raise SystemExit('Base attendue : AppImage 2.7.1 exacte ou 2.7.2.')
open(p+'.base-version','w').write(v)
d['version']='2.7.2';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
if [ "$(cat "$TMP/asar/package.json.base-version")" = '2.7.1' ]; then python3 "$SRC/patch_focus_2.7.2.py" "$A/index-BA4XgQVD.js"; fi
rm "$TMP/asar/package.json.base-version"
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
