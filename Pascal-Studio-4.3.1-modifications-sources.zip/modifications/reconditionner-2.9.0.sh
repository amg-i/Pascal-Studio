#!/bin/sh
# Reconstitue la version PC 2.9.0 depuis l’AppImage 2.8.1 ou 2.9.0 exacte.
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-2.9.0.sh BASE-2.8.1.AppImage SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || exit 1
python3 - "$BASE" <<'PY'
import sys,hashlib
with open(sys.argv[1],'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
if h not in ('09b8dc186d5497bfe8161e7444340534e88c4c8be25d555175076abb19707bcd','8c10a18fd1b1adf2a0cf427984965ff17c2bef481667676a0f35acf47ac4199d'):raise SystemExit('AppImage de base inattendue : utilisez la 2.8.1 ou la 2.9.0 exacte.')
PY
command -v python3 >/dev/null; command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$A/index-BA4XgQVD.js" "$A/document-bundle.js" "$R/static/index.html" <<'PY'
import json,sys
p,js,doc,html=sys.argv[1:];d=json.load(open(p));assert d['version'] in ('2.8.1','2.9.0');d['version']='2.9.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def patch(p,old,new):
 s=open(p,encoding='utf8').read()
 if s.count(new)==1:return
 if s.count(old)!=1:raise SystemExit('Patch non applicable : '+p)
 open(p,'w',encoding='utf8').write(s.replace(old,new))
patch(js,'window.PSFMOpenManager=()=>Oa("@file-manager"),','window.PSFMOpenManager=()=>Oa("@file-manager"),window.PSFMSetProject=path=>hs("open",path),')
old='e||(e=confirm("Un enregistrement a \\xE9chou\\xE9. Fermer et perdre les modifications non enregistr\\xE9es ?"))'
patch(doc,old,old+',e&&window.PSRemoteBeforeClose&&(e=await window.PSRemoteBeforeClose())')
patch(html,'<script defer src="/assets/file-manager.js"></script>','<script defer src="/assets/file-manager.js"></script><script defer src="/assets/remote-project-ui.js"></script>')
PY
cp "$SRC/server.py" "$SRC/file_manager.py" "$SRC/remote_projects.py" "$R/"
cp "$SRC/aide-latex.js" "$SRC/file-manager.js" "$SRC/file-manager.css" "$SRC/remote-project-ui.js" "$A/"
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
