#!/bin/sh
# Pascal Studio 3.0.0 depuis la base 2.9.0 exacte, ou depuis la 3.0.0 exacte.
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-3.0.0.sh BASE.AppImage SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || exit 1
python3 - "$BASE" <<'PY'
import hashlib,sys
with open(sys.argv[1],'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
if h not in ('8c10a18fd1b1adf2a0cf427984965ff17c2bef481667676a0f35acf47ac4199d','84a826a3205e584d1e188fd1279959f778a6266f8bb3427ffc8720fc62e9e86d'):raise SystemExit('AppImage de base inattendue.')
PY
command -v python3 >/dev/null; command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$A/index-BA4XgQVD.js" <<'PY'
import json,sys
p,js=sys.argv[1:];d=json.load(open(p));assert d['version'] in ('2.9.0','3.0.0');d['version']='3.0.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(js,encoding='utf8').read()
old='T.createElement("nav",{className:"activitybar"},T.createElement("button",{className:y==="project"'
new='T.createElement("nav",{className:"activitybar"},T.createElement("button",{title:"Gestionnaire de fichiers et serveurs", "aria-label":"Gestionnaire de fichiers et serveurs",onClick:()=>Oa("@file-manager")},T.createElement(pie,{size:20})),T.createElement("button",{className:y==="project"'
if s.count(new)!=1:
 if s.count(old)!=1:raise SystemExit('Patch du bandeau latéral non applicable.')
 s=s.replace(old,new)
open(js,'w',encoding='utf8').write(s)
PY
cp "$SRC/server.py" "$SRC/file_manager.py" "$SRC/remote_projects.py" "$SRC/remote_vault.py" "$R/"
cp "$SRC/aide-latex.js" "$SRC/file-manager.js" "$SRC/file-manager.css" "$A/"
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
