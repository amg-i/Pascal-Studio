#!/bin/sh
# Reconditionne uniquement l'AppImage officielle locale 3.2.0, sans sources React manquantes.
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-3.3.0.sh BASE-3.2.0.AppImage SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || exit 1
python3 - "$BASE" <<'PY'
import hashlib,sys
with open(sys.argv[1],'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
if h not in ('b606d70f6ae24cc4c3bf5a34284a0524070d9d9fb572669bfa338628c6629302','4d6550b32aef20a6d393f5693143227e1a90bc3980f55018d6aee15920a9204a'):raise SystemExit('AppImage de base 3.2.0 ou 3.3.0 inattendue.')
PY
command -v python3 >/dev/null; command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$R/static/index.html" "$TMP/asar/desktop/main.cjs" <<'PY'
import json,sys
p,html,main=sys.argv[1:];d=json.load(open(p));assert d['version'] in ('3.2.0','3.3.0');base_version=d['version'];d['version']='3.3.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(main,encoding='utf8').read();old="'py','rs','go','rb','js'";new="'py','rs','go','rb','f','for','ftn','f77','f90','f95','f03','f08','fpp','pl','pm','bas','yab','ml','mli','lua','js'";assert s.count(old)==1 if base_version=='3.2.0' else s.count(new)==1
if base_version=='3.2.0':s=s.replace(old,new)
open(main,'w',encoding='utf8').write(s)
s=open(html,encoding='utf8').read();a='<script src="/assets/aide-complementaire.js"></script>';assert s.count(a)==1
if base_version=='3.2.0':s=s.replace(a,a+'<script src="/assets/aide-cinq-langages.js"></script>')
else:assert s.count('/assets/aide-cinq-langages.js')==1
open(html,'w',encoding='utf8').write(s)
PY
cp "$SRC/server.py" "$SRC/polyglot.py" "$SRC/project_tools.py" "$SRC/additional_languages.py" "$SRC/perl_static_check.py" "$R/"
rm -rf "$R/vendor-perl"
cp -a "$SRC/vendor-perl" "$R/vendor-perl"
find "$R/vendor-perl" -type d -name __pycache__ -prune -exec rm -rf {} +
cp "$SRC"/monaco-additions/*-studio.js "$A/"
python3 "$SRC/aide_cinq_langages.py" "$A/aide-cinq-langages.js"
if ! grep -q 'id:"fortran",extensions:' "$A/index-BA4XgQVD.js"; then
 python3 "$SRC/patch_five_languages.py" "$A/index-BA4XgQVD.js"
fi
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
