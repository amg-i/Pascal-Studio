#!/bin/sh
set -eu
[ "$#" = 2 ] || { echo 'Usage : reconditionner-3.5.0.sh AppImage-3.4.0 SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || exit 1
python3 - "$BASE" <<'PY'
import hashlib,sys
with open(sys.argv[1],'rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
if h not in ('6d84737b8701a34e2e01952876e775385a132762262db54e28072ec8a772b56d','229f8cbdfcba206681dbde9477426c04e71c2a93e694ad69993ac1832359c3bd'):raise SystemExit('AppImage de base 3.4.0 ou 3.5.0 inattendue.')
PY
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" "$R/static/index.html" <<'PY'
import json,sys
p,h=sys.argv[1:];d=json.load(open(p));assert d['version'] in ('3.4.0','3.5.0');old=d['version'];d['version']='3.5.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(h).read();a='</head>';assert s.count(a)==1
if old=='3.3.0':s=s.replace(a,'<link rel="stylesheet" href="/assets/assistant-ia-host.css"><script defer src="/assets/assistant-ia-host.js"></script>'+a)
else:assert s.count('assistant-ia-host.js')==1
open(h,'w').write(s)
PY
if ! grep -q 'className:"ps-ai-host"' "$A/index-BA4XgQVD.js"; then python3 "$SRC/patch_ia_3.4.py" "$A/index-BA4XgQVD.js"; fi
if ! grep -q 'assistant-ia.*lanceur.py' "$TMP/asar/desktop/main.cjs"; then python3 "$SRC/patch_desktop_ia.py" "$TMP/asar/desktop/main.cjs"; fi
cp "$SRC/server.py" "$R/server.py"
cp "$SRC/assistant-ia-host.js" "$SRC/assistant-ia-host.css" "$A/"
rm -rf "$R/assistant-ia"
cp -a "$SRC/assistant-ia" "$R/assistant-ia"
find "$R/assistant-ia" -type d -name __pycache__ -prune -exec rm -rf {} +
find "$R/assistant-ia" -type f -name '*.pyc' -delete
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp xz -b 128K -processors 2 >/dev/null
head -c 188392 "$BASE" > "$OUT";cat "$TMP/image.squashfs" >> "$OUT";chmod +x "$OUT";sha256sum "$OUT"
