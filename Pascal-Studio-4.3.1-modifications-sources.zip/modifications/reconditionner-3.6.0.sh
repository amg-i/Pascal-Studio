#!/bin/sh
# Pascal Studio 3.6.0 — construit l'AppImage 3.6.0 à partir de l'AppImage 3.5.0
# et des sources de modifications.
#
#   sh reconditionner-3.6.0.sh Pascal-Studio-3.5.0-x86_64.AppImage Pascal-Studio-3.6.0-x86_64.AppImage
#
# Prérequis : Python 3.11+, asar (@electron/asar), mksquashfs (squashfs-tools),
# et de la place disque (environ 1,5 Go libre pour l'extraction).
# Aucun accès réseau pendant la construction.
#
# Le script s'arrête sans rien écrire si un ancrage du bundle a dérivé, si
# l'empreinte de la base diffère, ou si un fichier à recopier manque. Il termine
# en ré-extrayant l'AppImage produite pour vérifier le résultat.
set -eu
[ "$#" = 2 ] || { echo 'Usage : sh reconditionner-3.6.0.sh AppImage-3.5.0 SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'La sortie ne peut pas écraser la base.' >&2; exit 1; }
[ -f "$BASE" ] || { echo "Base introuvable : $BASE" >&2; exit 1; }

echo "== Contrôle des prérequis =="
command -v asar >/dev/null || { echo 'asar manquant : npm i -g @electron/asar' >&2; exit 1; }
command -v mksquashfs >/dev/null || { echo 'mksquashfs manquant : sudo apt install squashfs-tools' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'python3 manquant.' >&2; exit 1; }

# Tout ce que ce script recopie doit exister : on échoue avant de démonter l'AppImage.
for f in patch_langages_3.6.py patch_identite_git_3.6.py patch_desktop_langages.py \
         patch_ia_3.4.py patch_desktop_ia.py \
         server.py polyglot.py swift_kotlin.py account_store.py oauth_accounts.py \
         git_identity.py git_manager.py remote_vault.py \
         assistant-ia-host.js assistant-ia-host.css \
         logos-langages.css nouveau-fichier.css nouveau-fichier.js identite-git.css \
         monaco-basic/swift-studio.js monaco-basic/kotlin-studio.js \
         logos-langages/swift.svg logos-langages/kotlin.svg logos-langages/LICENSE-devicon.txt \
         aide-swift-kotlin.py aide-swift-kotlin.js; do
  [ -e "$SRC/$f" ] || { echo "Fichier manquant dans modifications/ : $f" >&2; exit 1; }
done
[ -d "$SRC/assistant-ia" ] || { echo 'Dossier manquant : assistant-ia/' >&2; exit 1; }
echo "   sources complètes ($(ls "$SRC"/logos-langages/*.svg | wc -l) logos)"

echo "== Contrôle de la base =="
# Empreinte de l'AppImage 3.5.0 fournie avec le projet, et détection de la taille
# de l'en-tête AppImage : le système de fichiers commence au superbloc squashfs.
DECALAGE=$(python3 - "$BASE" <<'PY'
import hashlib, struct, sys
chemin = sys.argv[1]
with open(chemin, 'rb') as f:
    donnees = f.read()
empreinte = hashlib.sha256(donnees).hexdigest()
if empreinte != '229f8cbdfcba206681dbde9477426c04e71c2a93e694ad69993ac1832359c3bd':
    raise SystemExit("Empreinte inattendue : " + empreinte + "\n"
                     "Base 3.5.0 exacte requise : "
                     "229f8cbdfcba206681dbde9477426c04e71c2a93e694ad69993ac1832359c3bd")
# Un superbloc squashfs valide : magic « hsqs », version 4.0, taille de bloc
# puissance de deux, compresseur connu.
COMPRESSEURS = {1: 'gzip', 2: 'lzma', 3: 'lzo', 4: 'xz', 5: 'lz4', 6: 'zstd'}
trouves = []
i = donnees.find(b'hsqs')
while i >= 0 and len(trouves) < 4:
    if i + 96 <= len(donnees):
        inodes, _mtime, bloc, _frag = struct.unpack_from('<IIII', donnees, i + 4)
        comp, = struct.unpack_from('<H', donnees, i + 20)
        majeur, mineur = struct.unpack_from('<HH', donnees, i + 28)
        if (majeur == 4 and comp in COMPRESSEURS and inodes > 0
                and bloc >= 4096 and (bloc & (bloc - 1)) == 0):
            trouves.append((i, COMPRESSEURS[comp], bloc))
    i = donnees.find(b'hsqs', i + 1)
if not trouves:
    raise SystemExit('Aucun superbloc squashfs valide trouvé dans la base.')
# La première occurrence valide est celle embarquée par l'AppImage.
decalage, comp, bloc = trouves[0]
if decalage != 188392:
    sys.stderr.write('Note : en-tête de %d octets (188392 attendu) ; %d retenu.\n'
                     % (decalage, decalage))
sys.stderr.write('Base 3.5.0 vérifiée : en-tête %d octets, %s, blocs %d KiB.\n'
                 % (decalage, comp, bloc // 1024))
print(decalage)
PY
) || exit 1
echo "   en-tête AppImage : $DECALAGE octets"

echo "== Extraction =="
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT HUP INT TERM
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
[ -f "$R/app.asar" ] || { echo 'resources/app.asar absent de la base.' >&2; exit 1; }
[ -f "$A/index-BA4XgQVD.js" ] || { echo 'Bundle frontend introuvable dans la base.' >&2; exit 1; }
asar extract "$R/app.asar" "$TMP/asar"
echo "   extrait dans $TMP"

echo "== Version et index.html =="
python3 - "$TMP/asar/package.json" "$R/static/index.html" <<'PY'
import json,sys
p,h=sys.argv[1:]
d=json.load(open(p,encoding='utf8'))
assert d['version']=='3.5.0', 'version de base inattendue : '+str(d['version'])
d['version']='3.6.0'
open(p,'w',encoding='utf8').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(h,encoding='utf8').read()
a='</head>'; assert s.count(a)==1, 'balise </head> ambiguë'
assert s.count('assistant-ia-host.js')==1, 'index.html d’une base 3.5.0 attendu'
aide='<script src="/assets/aide-cinq-langages.js"></script>'
assert s.count(aide)==1, 'catalogue d’aide 3.3.0 introuvable'
if 'aide-swift-kotlin.js' not in s:
    s=s.replace(aide,aide+'<script src="/assets/aide-swift-kotlin.js"></script>')
ajout=('<link rel="stylesheet" href="/assets/logos-langages.css">'
       '<link rel="stylesheet" href="/assets/nouveau-fichier.css">'
       '<script defer src="/assets/nouveau-fichier.js"></script>'
       '<link rel="stylesheet" href="/assets/identite-git.css">')
if 'nouveau-fichier.js' not in s: s=s.replace(a,ajout+a)
open(h,'w',encoding='utf8').write(s)
print('   version 3.6.0, 5 entrées injectées')
PY

echo "== Correctifs du bundle compilé =="
# Le correctif IA de la 3.4.0 d'abord : les ancrages 3.6.0 ont été relevés sur un
# bundle qui le porte déjà.
if ! grep -q 'className:"ps-ai-host"' "$A/index-BA4XgQVD.js"; then
  python3 "$SRC/patch_ia_3.4.py" "$A/index-BA4XgQVD.js"; echo "   patch_ia_3.4 appliqué"
fi
python3 "$SRC/patch_langages_3.6.py" "$A/index-BA4XgQVD.js"
python3 "$SRC/patch_identite_git_3.6.py" "$A/index-BA4XgQVD.js"
python3 "$SRC/patch_langages_3.6.py" --verifier "$A/index-BA4XgQVD.js"
python3 "$SRC/patch_identite_git_3.6.py" --verifier "$A/index-BA4XgQVD.js"

echo "== Correctifs Electron =="
if ! grep -q 'assistant-ia.*lanceur.py' "$TMP/asar/desktop/main.cjs"; then
  python3 "$SRC/patch_desktop_ia.py" "$TMP/asar/desktop/main.cjs"; echo "   patch_desktop_ia appliqué"
fi
python3 "$SRC/patch_desktop_langages.py" "$TMP/asar/desktop/main.cjs"

echo "== Copie des fichiers =="
cp "$SRC/server.py" "$SRC/polyglot.py" "$SRC/swift_kotlin.py" "$SRC/account_store.py" \
   "$SRC/oauth_accounts.py" "$SRC/git_identity.py" "$SRC/git_manager.py" \
   "$SRC/remote_vault.py" "$R/"
cp "$SRC/monaco-basic/swift-studio.js" "$SRC/monaco-basic/kotlin-studio.js" "$A/"
mkdir -p "$A/logos-langages"
cp "$SRC"/logos-langages/*.svg "$SRC/logos-langages/LICENSE-devicon.txt" "$A/logos-langages/"
cp "$SRC/aide-swift-kotlin.js" "$A/"
cp "$SRC/logos-langages.css" "$SRC/nouveau-fichier.css" "$SRC/nouveau-fichier.js" \
   "$SRC/identite-git.css" "$SRC/assistant-ia-host.js" "$SRC/assistant-ia-host.css" "$A/"
echo "   backend (8 modules) et interface (32 fichiers) copiés"

# L'archive source ne duplique PAS assistant-ia/vendor-ddgs (recherche web) :
# celle de la base est mise de côté puis remise, pour ne jamais la perdre.
if [ ! -e "$SRC/assistant-ia/vendor-ddgs" ] && [ -e "$R/assistant-ia/vendor-ddgs" ]; then
  mv "$R/assistant-ia/vendor-ddgs" "$TMP/vendor-ddgs-conserve"
  echo "   vendor-ddgs absent des sources : celui de la base est conservé"
  DDGS_CONSERVE=1
else
  DDGS_CONSERVE=0
fi
rm -rf "$R/assistant-ia"
cp -a "$SRC/assistant-ia" "$R/assistant-ia"
if [ "$DDGS_CONSERVE" = 1 ]; then
  mv "$TMP/vendor-ddgs-conserve" "$R/assistant-ia/vendor-ddgs"
fi

find "$TMP/squashfs-root" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$TMP/squashfs-root" -type f -name '*.pyc' -delete 2>/dev/null || true

echo "== Reconditionnement =="
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp xz -b 128K -processors 2 >/dev/null
head -c "$DECALAGE" "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
echo "   écrit : $OUT"

echo "== Vérification de l'AppImage produite =="
VERIF="$TMP/verif"; mkdir -p "$VERIF"
(cd "$VERIF" && "$OUT" --appimage-extract >/dev/null)
# package.json est dans l'asar refermé : on l'extrait pour lire la version.
(cd "$VERIF" && asar extract-file "$VERIF/squashfs-root/resources/app.asar" package.json)
python3 - "$VERIF/squashfs-root" "$VERIF/package.json" <<'PY'
import json, sys
from pathlib import Path
r = Path(sys.argv[1]); paquet = Path(sys.argv[2])
a = r / 'resources' / 'static' / 'assets'
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.6.0':
    problemes.append('package.json en version %s au lieu de 3.6.0' % version)
s = (r / 'resources' / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ['logos-langages.css', 'nouveau-fichier.js', 'identite-git.css',
                'aide-swift-kotlin.js']:
    if attendu not in s:
        problemes.append('index.html sans ' + attendu)
bundle = (a / 'index-BA4XgQVD.js').read_text(encoding='utf8')
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'window.PSNewFileDialog(',
                'className:"git-identity-row"', 'swift:["Sw","Swift"]']:
    if attendu not in bundle:
        problemes.append('bundle sans ' + attendu)
if 'conservé en mémoire jusqu’à la fermeture' in bundle:
    problemes.append('ancien texte sur le jeton encore présent')
serveur = (r / 'resources' / 'server.py').read_text(encoding='utf8')
for attendu in ['import swift_kotlin', 'import git_identity', "'swift':shutil.which('swiftc')"]:
    if attendu not in serveur:
        problemes.append('server.py sans ' + attendu)
for f in ['swift_kotlin.py', 'account_store.py', 'git_identity.py']:
    if not (r / 'resources' / f).is_file():
        problemes.append('module manquant : ' + f)
for f in ['swift-studio.js', 'kotlin-studio.js', 'nouveau-fichier.js',
          'logos-langages.css', 'nouveau-fichier.css', 'identite-git.css',
          'aide-swift-kotlin.js', 'logos-langages/swift.svg',
          'logos-langages/kotlin.svg', 'logos-langages/LICENSE-devicon.txt']:
    if not (a / f).is_file():
        problemes.append('asset manquant : ' + f)
nb_logos = len(list((a / 'logos-langages').glob('*.svg')))
if nb_logos != 22:
    problemes.append('%d logos au lieu de 22' % nb_logos)
if problemes:
    print('   ECHEC :')
    for p in problemes: print('     - ' + p)
    sys.exit(1)
print('   contenu vérifié : bundle, index.html, 8 modules, %d logos' % nb_logos)
PY
echo
echo "Pascal Studio 3.6.0 prêt : $OUT"
sha256sum "$OUT"
echo "Notez cette empreinte : elle identifie votre construction."
