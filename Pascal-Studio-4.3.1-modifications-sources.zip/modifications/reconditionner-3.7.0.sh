#!/bin/sh
# Pascal Studio 3.7.0 — construit l'AppImage 3.7.0 à partir de l'AppImage 3.6.0
# et des sources de modifications.
#
#   sh reconditionner-3.7.0.sh Pascal-Studio-3.6.0-x86_64.AppImage Pascal-Studio-3.7.0-x86_64.AppImage
#
# Prérequis : Python 3.11+, asar (@electron/asar), mksquashfs (squashfs-tools),
# et de la place disque (environ 1,5 Go libre pour l'extraction).
# Aucun accès réseau pendant la construction.
#
# IDENTITÉ DE LA BASE — à lire avant de lancer.
# Les scripts précédents comparaient l'empreinte SHA-256 de la base à une valeur
# figée. C'est impossible ici : votre AppImage 3.6.0 est produite par
# reconditionner-3.6.0.sh sur votre machine, et mksquashfs n'est pas
# bit-à-bit reproductible (horodatages). Une empreinte figée refuserait donc
# systématiquement une base légitime. Ce script vérifie l'identité de la base
# par son CONTENU : version 3.6.0 dans package.json, présence des marqueurs
# 3.6.0 dans le bundle, et absence des marqueurs 3.7.0. C'est conforme au choix
# que vous avez fait pour construire-appimage.py (« assouplir » le contrôle de
# la base). La contrepartie est assumée : une base modifiée à la main mais
# portant les bons marqueurs serait acceptée.
#
# Le script s'arrête sans rien écrire si la base n'est pas une 3.6.0, si un
# ancrage du bundle a dérivé, ou si un fichier à recopier manque. Il termine en
# ré-extrayant l'AppImage produite pour vérifier le résultat.
set -eu
[ "$#" = 2 ] || { echo 'Usage : sh reconditionner-3.7.0.sh AppImage-3.6.0 SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'La sortie ne peut pas écraser la base.' >&2; exit 1; }
[ -f "$BASE" ] || { echo "Base introuvable : $BASE" >&2; exit 1; }

echo "== Contrôle des prérequis =="
command -v asar >/dev/null || { echo 'asar manquant : npm i -g @electron/asar' >&2; exit 1; }
command -v mksquashfs >/dev/null || { echo 'mksquashfs manquant : sudo apt install squashfs-tools' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'python3 manquant.' >&2; exit 1; }

# Tout ce que ce script recopie doit exister : on échoue avant de démonter l'AppImage.
MODULES_37="langages.py verificateurs_statiques.py lsp_client.py \
            bibliotheques_completion.py moteur_completion.py \
            debogueur_universel.py inspecteur_visuel.py bac_a_sable.py \
            debug_mux.py web_preview.py server.py"
for f in patch_interface_3.7.py patch_langages_3.6.py patch_identite_git_3.6.py \
         patch_desktop_langages.py patch_ia_3.4.py patch_desktop_ia.py \
         $MODULES_37 \
         polyglot.py swift_kotlin.py account_store.py oauth_accounts.py \
         git_identity.py git_manager.py remote_vault.py \
         assistant-ia-host.js assistant-ia-host.css \
         logos-langages.css nouveau-fichier.css nouveau-fichier.js identite-git.css \
         aide-exemples.js aide-exemples.css \
         monaco-basic/swift-studio.js monaco-basic/kotlin-studio.js \
         logos-langages/swift.svg logos-langages/kotlin.svg logos-langages/LICENSE-devicon.txt \
         aide-swift-kotlin.py aide-swift-kotlin.js; do
  [ -e "$SRC/$f" ] || { echo "Fichier manquant dans modifications/ : $f" >&2; exit 1; }
done
[ -d "$SRC/assistant-ia" ] || { echo 'Dossier manquant : assistant-ia/' >&2; exit 1; }
[ -f "$SRC/assistant-ia/static/brand/logo-ia.svg" ] || { echo 'Logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg' >&2; exit 1; }
echo "   sources complètes ($(ls "$SRC"/logos-langages/*.svg | wc -l) logos)"

# Les nouveaux modules doivent être importables et cohérents avant toute écriture.
echo "== Contrôle des modules 3.7.0 =="
python3 - "$SRC" <<'PY' || exit 1
import sys, importlib.util
from pathlib import Path
src = Path(sys.argv[1])
sys.path.insert(0, str(src))
attendus = ['langages', 'verificateurs_statiques', 'lsp_client',
            'bibliotheques_completion', 'moteur_completion',
            'debogueur_universel', 'inspecteur_visuel', 'bac_a_sable']
for nom in attendus:
    chemin = src / (nom + '.py')
    if not chemin.is_file():
        raise SystemExit('module manquant : ' + nom + '.py')
    spec = importlib.util.spec_from_file_location(nom, chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
import langages, debogueur_universel, moteur_completion, inspecteur_visuel, bac_a_sable
tous = list(langages.tous())
if len(tous) < 29:
    raise SystemExit('registre incomplet : %d langages au lieu de 29' % len(tous))
modes = debogueur_universel.tous_les_modes()
debogables = sum(1 for v in modes.values() if v != debogueur_universel.MODE_AUCUN)
if debogables != 26:
    raise SystemExit('%d langages débogables au lieu de 26' % debogables)
graphiques = [k for k in tous if langages.est_graphique(k)]
if len(graphiques) != 6:
    raise SystemExit('%d langages graphiques au lieu de 6 : %s'
                     % (len(graphiques), graphiques))
for cle in ('html', 'css', 'svg', 'markdown'):
    if cle not in ('html', 'css', 'svg', 'markdown'):
        raise SystemExit('langage graphique absent : ' + cle)
if not inspecteur_visuel.STYLE or not inspecteur_visuel.SCRIPT:
    raise SystemExit('inspecteur visuel sans feuille de style ni script')
if not moteur_completion.CompletionUniverselle:
    raise SystemExit('façade de complétion absente')
if not bac_a_sable.nom_de_fichier('fortran').endswith('.f90'):
    raise SystemExit('Fortran : prog.f imposerait le format fixe')
print('   %d langages, %d débogables, %d graphiques, moteurs importables'
      % (len(tous), debogables, len(graphiques)))
PY

echo "== Contrôle de la base =="
# Détection de la taille de l'en-tête AppImage : le système de fichiers commence
# au superbloc squashfs. Pas de comparaison d'empreinte : voir l'en-tête.
DECALAGE=$(python3 - "$BASE" <<'PY'
import struct, sys
chemin = sys.argv[1]
with open(chemin, 'rb') as f:
    donnees = f.read()
# Un superbloc squashfs valide : magic « hsqs », version 4.0, taille de bloc
# puissance de deux, compresseur connu.
COMPRESSEURS = {1: 'gzip', 2: 'lzma', 3: 'lzo', 4: 'xz', 5: 'lz4', 6: 'zstd'}
trouves = []
i = donnees.find(b'hsqs')
while i >= 0 and len(trouves) < 4:
    if i + 96 <= len(donnees):
        inodes, _mtime, bloc, _frag = struct.unpack_from('<IIII', donnees, i + 4)
        comp, = struct.unpack_from('<H', donnees, i + 20)
        majeur, mineur = struct.unpack_from('<HH', donnees, i + 28)
        if (majeur == 4 and comp in COMPRESSEURS and inodes > 0
                and bloc >= 4096 and (bloc & (bloc - 1)) == 0):
            trouves.append((i, COMPRESSEURS[comp], bloc))
    i = donnees.find(b'hsqs', i + 1)
if not trouves:
    raise SystemExit('Aucun superbloc squashfs valide trouvé dans la base.')
# La première occurrence valide est celle embarquée par l'AppImage.
decalage, comp, bloc = trouves[0]
if decalage != 188392:
    sys.stderr.write('Note : en-tête de %d octets (188392 attendu) ; %d retenu.\n'
                     % (decalage, decalage))
sys.stderr.write('En-tête %d octets, %s, blocs %d KiB.\n'
                 % (decalage, comp, bloc // 1024))
print(decalage)
PY
) || exit 1
echo "   en-tête AppImage : $DECALAGE octets"

echo "== Extraction =="
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT HUP INT TERM
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
BUNDLE="$A/index-BA4XgQVD.js"
[ -f "$R/app.asar" ] || { echo 'resources/app.asar absent de la base.' >&2; exit 1; }
[ -f "$BUNDLE" ] || { echo 'Bundle frontend introuvable dans la base.' >&2; exit 1; }
asar extract "$R/app.asar" "$TMP/asar"
echo "   extrait dans $TMP"

echo "== Vérification de l'identité de la base (3.6.0) =="
python3 - "$TMP/asar/package.json" "$BUNDLE" "$R" <<'PY' || exit 1
import json, sys
from pathlib import Path
paquet, bundle, ressources = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.6.0':
    problemes.append('package.json en version %s : une base 3.6.0 est requise'
                     % version)
texte = bundle.read_text(encoding='utf8')
# Marqueurs 3.6.0 : ils prouvent que les correctifs précédents sont appliqués.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'className:"git-identity-row"']:
    if attendu not in texte:
        problemes.append('bundle sans le marqueur 3.6.0 %s' % attendu)
# Marqueurs 3.7.0 : leur présence signifierait une base déjà convertie.
for interdit in ['ps-3.7.0-interface', '"csharp","makefile","cmake","latex"']:
    if interdit in texte:
        problemes.append('bundle portant déjà le marqueur 3.7.0 %s' % interdit)
serveur = ressources / 'server.py'
if not serveur.is_file():
    problemes.append('resources/server.py absent de la base')
else:
    contenu = serveur.read_text(encoding='utf8')
    if 'import swift_kotlin' not in contenu:
        problemes.append('server.py sans import swift_kotlin : base antérieure à 3.6.0')
    if 'import bac_a_sable' in contenu:
        problemes.append('server.py portant déjà les routes 3.7.0')
if problemes:
    print('   ECHEC — la base n’est pas une Pascal Studio 3.6.0 :')
    for p in problemes:
        print('     - ' + p)
    print('   Construisez d’abord la 3.6.0 : sh reconditionner-3.6.0.sh '
          'AppImage-3.5.0 Pascal-Studio-3.6.0-x86_64.AppImage')
    sys.exit(1)
print('   base 3.6.0 reconnue par son contenu (version, marqueurs, server.py)')
PY

echo "== Version et index.html =="
python3 - "$TMP/asar/package.json" "$R/static/index.html" <<'PY'
import json,sys
p,h=sys.argv[1:]
d=json.load(open(p,encoding='utf8'))
assert d['version']=='3.6.0', 'version de base inattendue : '+str(d['version'])
d['version']='3.7.0'
open(p,'w',encoding='utf8').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(h,encoding='utf8').read()
a='</head>'; assert s.count(a)==1, 'balise </head> ambiguë'
# Les injections 3.6.0 doivent déjà être là : on ne les refait pas.
for attendu in ['nouveau-fichier.js','logos-langages.css','aide-swift-kotlin.js']:
    assert attendu in s, 'index.html d’une base 3.6.0 attendu, %s manquant' % attendu
ajout=('<link rel="stylesheet" href="/assets/aide-exemples.css">'
       '<script defer src="/assets/aide-exemples.js"></script>')
if 'aide-exemples.js' not in s: s=s.replace(a,ajout+a)
open(h,'w',encoding='utf8').write(s)
print('   version 3.7.0, 2 entrées injectées (aide-exemples.css/.js)')
PY

echo "== Correctifs du bundle compilé =="
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
# Le correctif IA de la 3.4.0 d'abord : les ancrages 3.6.0 ont été relevés sur
# un bundle qui le porte déjà.
if ! grep -q 'className:"ps-ai-host"' "$BUNDLE"; then
  python3 "$SRC/patch_ia_3.4.py" "$BUNDLE"; echo "   patch_ia_3.4 appliqué"
fi
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
for nom in patch_langages_3.6 patch_identite_git_3.6; do
  if ! python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null 2>&1; then
    python3 "$SRC/$nom.py" "$BUNDLE"; echo "   $nom appliqué"
  else
    echo "   $nom déjà présent"
  fi
  python3 "$SRC/$nom.py" --verifier "$BUNDLE"
done
# Correctif 3.7.0 : complétion pour 29 langages, débogage pour 27.
python3 "$SRC/patch_interface_3.7.py" "$BUNDLE"
python3 "$SRC/patch_interface_3.7.py" --verifier "$BUNDLE"

echo "== Correctifs Electron =="
if ! grep -q 'assistant-ia.*lanceur.py' "$TMP/asar/desktop/main.cjs"; then
  python3 "$SRC/patch_desktop_ia.py" "$TMP/asar/desktop/main.cjs"; echo "   patch_desktop_ia appliqué"
fi
python3 "$SRC/patch_desktop_langages.py" "$TMP/asar/desktop/main.cjs"

echo "== Copie des fichiers =="
for m in $MODULES_37; do cp "$SRC/$m" "$R/"; done
cp "$SRC/polyglot.py" "$SRC/swift_kotlin.py" "$SRC/account_store.py" \
   "$SRC/oauth_accounts.py" "$SRC/git_identity.py" "$SRC/git_manager.py" \
   "$SRC/remote_vault.py" "$R/"
cp "$SRC/monaco-basic/swift-studio.js" "$SRC/monaco-basic/kotlin-studio.js" "$A/"
mkdir -p "$A/logos-langages"
cp "$SRC"/logos-langages/*.svg "$SRC/logos-langages/LICENSE-devicon.txt" "$A/logos-langages/"
cp "$SRC/aide-swift-kotlin.js" "$A/"
cp "$SRC/logos-langages.css" "$SRC/nouveau-fichier.css" "$SRC/nouveau-fichier.js" \
   "$SRC/identite-git.css" "$SRC/assistant-ia-host.js" "$SRC/assistant-ia-host.css" \
   "$SRC/aide-exemples.js" "$SRC/aide-exemples.css" "$A/"
echo "   backend (11 nouveaux modules + 7 reconduits) et interface (34 fichiers) copiés"

# L'archive source ne duplique PAS assistant-ia/vendor-ddgs (recherche web) :
# celle de la base est mise de côté puis remise, pour ne jamais la perdre.
if [ ! -e "$SRC/assistant-ia/vendor-ddgs" ] && [ -e "$R/assistant-ia/vendor-ddgs" ]; then
  mv "$R/assistant-ia/vendor-ddgs" "$TMP/vendor-ddgs-conserve"
  echo "   vendor-ddgs absent des sources : celui de la base est conservé"
  DDGS_CONSERVE=1
else
  DDGS_CONSERVE=0
fi
rm -rf "$R/assistant-ia"
cp -a "$SRC/assistant-ia" "$R/assistant-ia"
if [ "$DDGS_CONSERVE" = 1 ]; then
  mv "$TMP/vendor-ddgs-conserve" "$R/assistant-ia/vendor-ddgs"
fi

find "$TMP/squashfs-root" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$TMP/squashfs-root" -type f -name '*.pyc' -delete 2>/dev/null || true

echo "== Reconditionnement =="
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp xz -b 128K -processors 2 >/dev/null
head -c "$DECALAGE" "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
echo "   écrit : $OUT"

echo "== Vérification de l'AppImage produite =="
VERIF="$TMP/verif"; mkdir -p "$VERIF"
(cd "$VERIF" && "$OUT" --appimage-extract >/dev/null)
# package.json est dans l'asar refermé : on l'extrait pour lire la version.
(cd "$VERIF" && asar extract-file "$VERIF/squashfs-root/resources/app.asar" package.json)
python3 - "$VERIF/squashfs-root" "$VERIF/package.json" <<'PY'
import json, sys
from pathlib import Path
r = Path(sys.argv[1]); paquet = Path(sys.argv[2])
a = r / 'resources' / 'static' / 'assets'
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.7.0':
    problemes.append('package.json en version %s au lieu de 3.7.0' % version)
s = (r / 'resources' / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ['logos-langages.css', 'nouveau-fichier.js', 'identite-git.css',
                'aide-swift-kotlin.js', 'aide-exemples.css', 'aide-exemples.js']:
    if attendu not in s:
        problemes.append('index.html sans ' + attendu)
bundle = (a / 'index-BA4XgQVD.js').read_text(encoding='utf8')
# Marqueurs 3.6.0 reconduits.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'window.PSNewFileDialog(',
                'className:"git-identity-row"', 'swift:["Sw","Swift"]']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.6.0 ' + attendu)
# Marqueurs 3.7.0.
for attendu in ['ps-3.7.0-interface', 'for(const t of["pascal","c","cpp","csharp"',
                '"moteur local"']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.7.0 ' + attendu)
# L'ancienne liste de débogage à 10 langages doit avoir disparu.
if '["pascal","c","cpp","python","javascript","php","rust","go","ruby","fortran"]' in bundle:
    problemes.append('bundle portant encore la liste de débogage 3.6.0 (10 langages)')
serveur = (r / 'resources' / 'server.py').read_text(encoding='utf8')
# server.py importe les moteurs 3.7.0 sur UNE seule ligne groupée : on cherche
# donc les noms de modules, pas la forme « import X » prise isolément.
for attendu in ['import bac_a_sable', 'debogueur_universel', 'inspecteur_visuel',
                'moteur_completion', 'analyser_en_direct',
                '/api/aide/essayer', '/api/debug/capacites', '/api/completion/etat',
                '/api/inspecteur']:
    if attendu not in serveur:
        problemes.append('server.py sans ' + attendu)
if 'Analyse en direct disponible pour Pascal, C et C++.' in serveur:
    problemes.append('server.py portant encore l’ancien message d’analyse limitée')
for f in ['langages.py', 'verificateurs_statiques.py', 'lsp_client.py',
          'bibliotheques_completion.py', 'moteur_completion.py',
          'debogueur_universel.py', 'inspecteur_visuel.py', 'bac_a_sable.py',
          'debug_mux.py', 'web_preview.py', 'swift_kotlin.py',
          'account_store.py', 'git_identity.py']:
    if not (r / 'resources' / f).is_file():
        problemes.append('module manquant : ' + f)
for f in ['swift-studio.js', 'kotlin-studio.js', 'nouveau-fichier.js',
          'logos-langages.css', 'nouveau-fichier.css', 'identite-git.css',
          'aide-swift-kotlin.js', 'aide-exemples.js', 'aide-exemples.css',
          'logos-langages/swift.svg', 'logos-langages/kotlin.svg',
          'logos-langages/LICENSE-devicon.txt']:
    if not (a / f).is_file():
        problemes.append('asset manquant : ' + f)
logo = r / 'resources' / 'assistant-ia' / 'static' / 'brand' / 'logo-ia.svg'
if not logo.is_file():
    problemes.append('logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg')
else:
    contenu = logo.read_text(encoding='utf8')
    if 'viewBox' not in contenu:
        problemes.append('logo-ia.svg sans viewBox')
index_ia = r / 'resources' / 'assistant-ia' / 'static' / 'index.html'
if not index_ia.is_file():
    problemes.append('assistant-ia/static/index.html manquant')
else:
    contenu = index_ia.read_text(encoding='utf8')
    if '.msg.assistant::before' not in contenu or 'logo-ia.svg' not in contenu:
        problemes.append('interface de l’assistant sans l’avatar du logo IA')
nb_logos = len(list((a / 'logos-langages').glob('*.svg')))
if nb_logos != 22:
    problemes.append('%d logos au lieu de 22' % nb_logos)
if problemes:
    print('   ECHEC :')
    for p in problemes: print('     - ' + p)
    sys.exit(1)
print('   contenu vérifié : bundle, index.html, 18 modules, %d logos, logo IA' % nb_logos)
PY
echo
echo "Pascal Studio 3.7.0 prêt : $OUT"
sha256sum "$OUT"
echo "Notez cette empreinte : elle identifie votre construction."
