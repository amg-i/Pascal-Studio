#!/bin/sh
# Pascal Studio 3.9.0 — construit l'AppImage 3.9.0 à partir de l'AppImage 3.8.0
# et des sources de modifications.
#
#   sh reconditionner-3.9.0.sh Pascal-Studio-3.8.0-x86_64.AppImage Pascal-Studio-3.9.0-x86_64.AppImage
#
# Prérequis : Python 3.11+, asar (@electron/asar), mksquashfs (squashfs-tools),
# et de la place disque (environ 1,5 Go libre pour l'extraction).
# Aucun accès réseau pendant la construction.
#
# IDENTITÉ DE LA BASE — à lire avant de lancer.
# Les scripts précédents comparaient l'empreinte SHA-256 de la base à une valeur
# figée. C'est impossible ici : votre AppImage 3.8.0 est produite par
# reconditionner-3.8.0.sh sur votre machine, et mksquashfs n'est pas
# bit-à-bit reproductible (horodatages). Une empreinte figée refuserait donc
# systématiquement une base légitime. Ce script vérifie l'identité de la base
# par son CONTENU : version 3.8.0 dans package.json, présence des marqueurs
# 3.6.0, 3.7.0 et 3.8.0 dans le bundle, dans server.py et dans index.html, et
# absence des nouveautés 3.9.0 dans resources/assistant-ia/. C'est
# conforme au choix que vous avez fait pour construire-appimage.py
# (« assouplir » le contrôle de la base). La contrepartie est assumée : une base
# modifiée à la main mais portant les bons marqueurs serait acceptée.
#
# CETTE VERSION NE TOUCHE PAS AU BUNDLE. Les deux nouveautés de la 3.9.0 — le
# filtre qui fait réécrire la demande par un modèle séparé avant l'IA agentique,
# et l'espace de travail par projet — vivent entièrement dans
# resources/assistant-ia/, que ce script remplace en bloc. Le bundle minifié est
# donc seulement VÉRIFIÉ (marqueurs 3.6.0, 3.7.0 et 3.8.0 intacts), jamais
# réécrit : c'est ce qui rend cette construction bien moins fragile que les
# précédentes, où chaque ancrage du bundle pouvait dériver.
#
# ORDRE DE CHARGEMENT DE L'AIDE — acquis en 3.8.0, revérifié ici.
# Le bundle construit sa base d'aide au moment de son évaluation, à partir de
# window.PS_LANG_HELP et de ses voisins. aide-esoteriques.js doit donc être
# chargé AVANT le bundle, et comme script CLASSIQUE : un attribut « defer » le
# ferait s'exécuter après, et les dix langages n'auraient alors aucune aide,
# sans qu'aucune erreur n'apparaisse nulle part. La base 3.8.0 porte déjà ces
# deux injections : ce script les exige et revérifie l'ordre à la fin, sans rien
# réécrire. Une régression là ne produirait aucune erreur visible.
#
# Le script s'arrête sans rien écrire si la base n'est pas une 3.8.0, si un
# module 3.9.0 ne s'importe pas ou se comporte mal, ou si un fichier à recopier
# manque. Il termine en ré-extrayant l'AppImage produite pour vérifier le
# résultat, y compris les huit routes de l'espace de travail.
set -eu
[ "$#" = 2 ] || { echo 'Usage : sh reconditionner-3.9.0.sh AppImage-3.8.0 SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'La sortie ne peut pas écraser la base.' >&2; exit 1; }
[ -f "$BASE" ] || { echo "Base introuvable : $BASE" >&2; exit 1; }

echo "== Contrôle des prérequis =="
command -v asar >/dev/null || { echo 'asar manquant : npm i -g @electron/asar' >&2; exit 1; }
command -v mksquashfs >/dev/null || { echo 'mksquashfs manquant : sudo apt install squashfs-tools' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'python3 manquant.' >&2; exit 1; }

# Tout ce que ce script recopie doit exister : on échoue avant de démonter l'AppImage.
MODULES_38="langages.py verificateurs_statiques.py lsp_client.py \
            bibliotheques_completion.py moteur_completion.py \
            debogueur_universel.py inspecteur_visuel.py bac_a_sable.py \
            debug_mux.py web_preview.py server.py \
            langages_esoteriques.py capacites_aide.py"
for f in patch_interface_3.7.py patch_interface_3.8.py \
         patch_langages_3.6.py patch_identite_git_3.6.py \
         patch_desktop_langages.py patch_ia_3.4.py patch_desktop_ia.py \
         $MODULES_38 \
         polyglot.py swift_kotlin.py account_store.py oauth_accounts.py \
         git_identity.py git_manager.py remote_vault.py \
         assistant-ia-host.js assistant-ia-host.css \
         logos-langages.css nouveau-fichier.css nouveau-fichier.js identite-git.css \
         aide-exemples.js aide-exemples.css \
         aide-esoteriques.py aide-esoteriques.js aide-index.js aide-index.css \
         monaco-basic/swift-studio.js monaco-basic/kotlin-studio.js \
         logos-langages/swift.svg logos-langages/kotlin.svg logos-langages/LICENSE-devicon.txt \
         aide-swift-kotlin.py aide-swift-kotlin.js; do
  [ -e "$SRC/$f" ] || { echo "Fichier manquant dans modifications/ : $f" >&2; exit 1; }
done
[ -d "$SRC/assistant-ia" ] || { echo 'Dossier manquant : assistant-ia/' >&2; exit 1; }
[ -f "$SRC/assistant-ia/static/brand/logo-ia.svg" ] || { echo 'Logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg' >&2; exit 1; }
# Nouveautés 3.9.0 : sans l'un de ces trois fichiers, l'assistant démarrerait
# avec une route morte ou un filtre incapable de recevoir sa consigne.
for f in assistant-ia/optimiseur_prompt.py assistant-ia/espace_travail.py \
         assistant-ia/prompts/optimiseur.md; do
  [ -f "$SRC/$f" ] || { echo "Fichier 3.9.0 manquant : $f" >&2; exit 1; }
done
echo "   sources complètes ($(ls "$SRC"/logos-langages/*.svg | wc -l) logos)"

# Les nouveaux modules doivent être importables et cohérents avant toute écriture.
echo "== Contrôle des modules 3.9.0 =="
python3 - "$SRC" <<'PY' || exit 1
import sys, importlib.util
from pathlib import Path
src = Path(sys.argv[1])
sys.path.insert(0, str(src))
attendus = ['langages', 'verificateurs_statiques', 'lsp_client',
            'bibliotheques_completion', 'moteur_completion',
            'debogueur_universel', 'inspecteur_visuel', 'bac_a_sable',
            'langages_esoteriques', 'capacites_aide', 'debug_mux', 'polyglot']
for nom in attendus:
    chemin = src / (nom + '.py')
    if not chemin.is_file():
        raise SystemExit('module manquant : ' + nom + '.py')
    spec = importlib.util.spec_from_file_location(nom, chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
import langages, debogueur_universel, moteur_completion, inspecteur_visuel
import bac_a_sable, langages_esoteriques, capacites_aide, debug_mux, polyglot
tous = list(langages.tous())
if len(tous) != 39:
    raise SystemExit('registre incomplet : %d langages au lieu de 39' % len(tous))
modes = debogueur_universel.tous_les_modes()
debogables = sum(1 for v in modes.values() if v != debogueur_universel.MODE_AUCUN)
if debogables != 36:
    raise SystemExit('%d langages débogables au lieu de 36' % debogables)
graphiques = sorted(k for k in tous if langages.est_graphique(k))
if len(graphiques) != 7:
    raise SystemExit('%d langages graphiques au lieu de 7 : %s'
                     % (len(graphiques), graphiques))
if 'piet' not in graphiques:
    raise SystemExit('Piet absent des langages graphiques : %s' % graphiques)
# Les dix langages ésotériques : chacun doit avoir son moteur, son débogueur,
# son aperçu et ses quatre facettes d'aide minimales.
esoteriques = list(langages_esoteriques.ORDRE_ESOTERIQUES)
if len(esoteriques) != 10:
    raise SystemExit('%d langages ésotériques au lieu de 10' % len(esoteriques))
for cle in esoteriques:
    if cle not in tous:
        raise SystemExit('langage ésotérique absent du registre : ' + cle)
    if langages.debogueur(cle) != 'esoterique':
        raise SystemExit('%s : débogueur=%r au lieu de « esoterique »'
                         % (cle, langages.debogueur(cle)))
    if not langages_esoteriques.est_esoterique(cle):
        raise SystemExit('est_esoterique() faux pour ' + cle)
    fac = capacites_aide.capacites(cle)['facettes']
    for attendu in ('debogage', 'variables', 'completions', 'analyse'):
        if attendu not in fac:
            raise SystemExit('%s : facette d’aide %s manquante (%s)'
                             % (cle, attendu, fac))
if 'apercu' not in capacites_aide.capacites('piet')['facettes']:
    raise SystemExit('Piet sans facette « apercu » dans le catalogue d’aide')
if not callable(debug_mux.esoterique):
    raise SystemExit('debug_mux.esoterique() absent : la route de débogage ne '
                     'verrait pas les langages ésotériques')
if polyglot.kind('programme.bf') != 'brainfuck':
    raise SystemExit('polyglot.kind() ne reconnaît pas .bf : %r'
                     % polyglot.kind('programme.bf'))
if not inspecteur_visuel.STYLE or not inspecteur_visuel.SCRIPT:
    raise SystemExit('inspecteur visuel sans feuille de style ni script')
if not callable(inspecteur_visuel.carte_piet):
    raise SystemExit('inspecteur_visuel.carte_piet() absent')
if not moteur_completion.CompletionUniverselle:
    raise SystemExit('façade de complétion absente')
if not bac_a_sable.nom_de_fichier('fortran').endswith('.f90'):
    raise SystemExit('Fortran : prog.f imposerait le format fixe')
cat = capacites_aide.catalogue()
if cat['total'] != 39 or len(cat['fonctionnalites']) != 8:
    raise SystemExit('catalogue d’aide incohérent : %r' % (cat['total'],))
print('   %d langages, %d débogables, %d graphiques, %d ésotériques, '
      '%d fonctionnalités d’aide'
      % (len(tous), debogables, len(graphiques), len(esoteriques),
         len(cat['fonctionnalites'])))

# --- Nouveautés 3.9.0 -------------------------------------------------
# Les deux modules sont importés puis EXERCÉS : un module qui s'importe mais
# dont une fonction casse au premier appel ne doit pas atteindre l'AppImage.
# Trois défauts de ce genre ont été trouvés pendant le développement
# (str.normalize() inexistant, .format() sur une consigne à accolades,
# core.BASE inexistant) : aucun n'était visible à la lecture.
import ast, tempfile
ia = src / 'assistant-ia'
# append et non insert : assistant-ia contient server.py, core.py et agent.py,
# qui masqueraient les modules homonymes de modifications/.
sys.path.append(str(ia))
marqueurs = {'optimiseur_prompt': 'ps-3.9.0-optimiseur',
             'espace_travail': 'ps-3.9.0-espace'}
for nom, attendu in marqueurs.items():
    chemin = ia / (nom + '.py')
    if not chemin.is_file():
        raise SystemExit('module 3.9.0 manquant : assistant-ia/' + nom + '.py')
    spec = importlib.util.spec_from_file_location(nom, chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.MARQUEUR != attendu:
        raise SystemExit('%s : marqueur %r au lieu de %r'
                         % (nom, module.MARQUEUR, attendu))
import optimiseur_prompt, espace_travail
if 'core' in sys.modules:
    raise SystemExit('un module 3.9.0 importe core : il casserait hors de '
                     'l’assistant')
# La consigne modifiable : si ses marques disparaissent, le modèle séparé ne
# recevrait plus ni le contexte ni la demande de l'utilisateur.
chemin_consigne = ia / 'prompts' / 'optimiseur.md'
consigne = chemin_consigne.read_text(encoding='utf8')
for marque in ('{contexte}', '{demande}', '"prompt"'):
    if marque not in consigne:
        raise SystemExit('prompts/optimiseur.md sans %s : le filtre ne '
                         'pourrait pas transmettre la demande' % marque)
demande = 'Écris un script qui renomme mes photos de vacances'
meta = optimiseur_prompt.construire_meta_prompt(
    demande, {'projet_nom': 'Test', 'categorie': 'code'}, consigne=consigne)
if demande not in meta:
    raise SystemExit('la consigne du filtre ne transmet pas la demande')
# Le contrat réel : le bloc construit par bloc_contexte() doit se retrouver
# tel quel dans la consigne envoyée au modèle séparé. Vérifier un libellé figé
# (« Catégorie : … ») a produit un faux échec lors de la première exécution :
# c'est le libellé du module qui fait foi, pas celui du script.
contexte_attendu = optimiseur_prompt.bloc_contexte(
    {'projet_nom': 'Test', 'categorie': 'code'})
if not contexte_attendu:
    raise SystemExit('bloc_contexte() renvoie un bloc vide pour un contexte réel')
if 'Projet ouvert : Test' not in contexte_attendu:
    raise SystemExit('bloc_contexte() sans le nom du projet ouvert')
if contexte_attendu not in meta:
    raise SystemExit('la consigne du filtre ne transmet pas le contexte')
if '{contexte}' in meta or '{demande}' in meta:
    raise SystemExit('la consigne du filtre laisse une marque non remplacée')
ok, raison = optimiseur_prompt.valider(
    demande, demande + ', avec les critères de réussite et le format de sortie.')
if not ok:
    raise SystemExit('le filtre refuse un produit valide : ' + raison)
if optimiseur_prompt.valider(demande, '')[0]:
    raise SystemExit('le filtre accepte un produit vide')
if optimiseur_prompt.valider(demande, 'X' * 40000)[0]:
    raise SystemExit('le filtre accepte un produit démesuré')
if optimiseur_prompt.est_utile('ok')[0]:
    raise SystemExit('le filtre juge utile une demande trop courte')
# L'espace de travail, sur un vrai dossier temporaire : écriture, lecture,
# index, collision de noms, et confinement contre trois chemins hostiles.
with tempfile.TemporaryDirectory() as essai:
    espace = espace_travail.Espace(essai)
    espace.ecrire('projet1', 'note.txt', 'contenu')
    if espace.lire('projet1', 'note.txt') != b'contenu':
        raise SystemExit('espace de travail : aller-retour en échec')
    if len(espace.lister('projet1')['fichiers']) != 1:
        raise SystemExit('espace de travail : listage incohérent')
    if espace.nom_libre('projet1', 'note.txt') != 'note (2).txt':
        raise SystemExit('espace de travail : collision non renommée : %r'
                         % espace.nom_libre('projet1', 'note.txt'))
    for hostile in ('../dehors.txt', 'a/../../b.txt', 'é' * 300):
        try:
            espace.resoudre('projet1', hostile)
            raise SystemExit('espace de travail : chemin hostile accepté : %r'
                             % hostile[:24])
        except espace_travail.CheminRefusé:
            pass
# Le serveur de l'assistant doit compiler et porter les deux nouveautés :
# une erreur de syntaxe ici rendrait l'assistant muet sans message clair.
serveur_ia = (ia / 'server.py').read_text(encoding='utf8')
try:
    ast.parse(serveur_ia)
except SyntaxError as erreur:
    raise SystemExit('assistant-ia/server.py invalide : %s' % erreur)
routes = ['Route("/api/espace"', 'Route("/api/espace/depot"',
          'Route("/api/espace/fichier"', 'Route("/api/espace/apercu"',
          'Route("/api/espace/renommer"', 'Route("/api/espace/supprimer"',
          'Route("/api/espace/dossier"', 'Route("/api/espace/enregistrer"']
for attendu in (['import optimiseur_prompt', 'import espace_travail',
                 'optimiser_en_arriere_plan', '"type": "optimise"',
                 'espace_capturer', 'prompt_model', 'X-PS-Espace'] + routes):
    if attendu not in serveur_ia:
        raise SystemExit('assistant-ia/server.py sans %s' % attendu)
# La page : bouton, boîte de dialogue, réglages, événement du filtre, et le
# marqueur du prompt optimisé qui doit figurer DEUX fois (flux et rechargement).
page_ia = (ia / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ('id="espbtn"', 'id="espdlg"', 'id="espproj"', 'id="espfile"',
                'id="prompt"', 'id="prompt_model"',
                "ev.type === 'optimise'", 'function voirPrompt',
                'function espaceCapturer', "'prompt', 'prompt_model'",
                'demande optimisée · voir'):
    if attendu not in page_ia:
        raise SystemExit('assistant-ia/static/index.html sans %s' % attendu)
# Le compte porte sur le BALISAGE du bouton, pas sur le libellé : celui-ci
# figure aussi dans la phrase d'explication des réglages, donc trois fois.
# Un compte sur le libellé a produit un faux échec à la première exécution.
bouton_prompt = '<div class="promptopt"><button data-a="prompt"'
if page_ia.count(bouton_prompt) != 2:
    raise SystemExit('le bouton du prompt optimisé figure %d fois au lieu de 2 '
                     '(flux et rechargement)'
                     % page_ia.count(bouton_prompt))
if 'demande optimisée · voir' not in page_ia:
    raise SystemExit('la page n’explique pas le filtre à l’utilisateur')
if 'UI_IDS = [\'mode\', \'cat\', \'web\', \'tools\', \'team\', \'prompt\', \'prompt_model\']' not in page_ia:
    raise SystemExit('UI_IDS de la page incomplet : les deux réglages du '
                     'filtre ne seraient pas enregistrés')
print('   3.9.0 : filtre et espace importés et exercés, 8 routes, page câblée')
PY

echo "== Contrôle de la base =="
# Détection de la taille de l'en-tête AppImage : le système de fichiers commence
# au superbloc squashfs. Pas de comparaison d'empreinte : voir l'en-tête.
DECALAGE=$(python3 - "$BASE" <<'PY'
import struct, sys
chemin = sys.argv[1]
with open(chemin, 'rb') as f:
    donnees = f.read()
# Un superbloc squashfs valide : magic « hsqs », version 4.0, taille de bloc
# puissance de deux, compresseur connu.
COMPRESSEURS = {1: 'gzip', 2: 'lzma', 3: 'lzo', 4: 'xz', 5: 'lz4', 6: 'zstd'}
trouves = []
i = donnees.find(b'hsqs')
while i >= 0 and len(trouves) < 4:
    if i + 96 <= len(donnees):
        inodes, _mtime, bloc, _frag = struct.unpack_from('<IIII', donnees, i + 4)
        comp, = struct.unpack_from('<H', donnees, i + 20)
        majeur, mineur = struct.unpack_from('<HH', donnees, i + 28)
        if (majeur == 4 and comp in COMPRESSEURS and inodes > 0
                and bloc >= 4096 and (bloc & (bloc - 1)) == 0):
            trouves.append((i, COMPRESSEURS[comp], bloc))
    i = donnees.find(b'hsqs', i + 1)
if not trouves:
    raise SystemExit('Aucun superbloc squashfs valide trouvé dans la base.')
# La première occurrence valide est celle embarquée par l'AppImage.
decalage, comp, bloc = trouves[0]
if decalage != 188392:
    sys.stderr.write('Note : en-tête de %d octets (188392 attendu) ; %d retenu.\n'
                     % (decalage, decalage))
sys.stderr.write('En-tête %d octets, %s, blocs %d KiB.\n'
                 % (decalage, comp, bloc // 1024))
print(decalage)
PY
) || exit 1
echo "   en-tête AppImage : $DECALAGE octets"

echo "== Extraction =="
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT HUP INT TERM
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
BUNDLE="$A/index-BA4XgQVD.js"
[ -f "$R/app.asar" ] || { echo 'resources/app.asar absent de la base.' >&2; exit 1; }
[ -f "$BUNDLE" ] || { echo 'Bundle frontend introuvable dans la base.' >&2; exit 1; }
asar extract "$R/app.asar" "$TMP/asar"
echo "   extrait dans $TMP"

echo "== Vérification de l'identité de la base (3.8.0) =="
python3 - "$TMP/asar/package.json" "$BUNDLE" "$R" <<'PY' || exit 1
import json, sys
from pathlib import Path
paquet, bundle, ressources = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.8.0':
    problemes.append('package.json en version %s : une base 3.8.0 est requise'
                     % version)
texte = bundle.read_text(encoding='utf8')
# Marqueurs 3.6.0, 3.7.0 et 3.8.0 : cette version ne réécrit pas le bundle,
# donc tous les correctifs précédents doivent déjà s'y trouver.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'className:"git-identity-row"',
                'ps-3.7.0-interface', '"moteur local"',
                'ps-3.8.0-interface', 'malbolge:"Malbolge"']:
    if attendu not in texte:
        problemes.append('bundle sans le marqueur %s' % attendu)
serveur = ressources / 'server.py'
if not serveur.is_file():
    problemes.append('resources/server.py absent de la base')
else:
    contenu = serveur.read_text(encoding='utf8')
    if 'import bac_a_sable' not in contenu:
        problemes.append('server.py sans les routes 3.7.0 : base antérieure à 3.7.0')
    if 'capacites_aide' not in contenu:
        problemes.append('server.py sans la route d’aide 3.8.0 : '
                         'base antérieure à 3.8.0')
# L'assistant de la base doit être un 3.8.0 : ni filtre de demande, ni espace
# de travail. Leur présence signifierait une base déjà convertie.
ia_base = ressources / 'assistant-ia'
if not ia_base.is_dir():
    problemes.append('resources/assistant-ia absent de la base')
else:
    for deja in ('optimiseur_prompt.py', 'espace_travail.py'):
        if (ia_base / deja).exists():
            problemes.append('assistant-ia portant déjà %s : base déjà '
                             'convertie en 3.9.0' % deja)
    serveur_ia = ia_base / 'server.py'
    if not serveur_ia.is_file():
        problemes.append('assistant-ia/server.py absent de la base')
    elif '/api/espace' in serveur_ia.read_text(encoding='utf8'):
        problemes.append('assistant-ia/server.py portant déjà les routes 3.9.0')
index = ressources / 'static' / 'index.html'
if not index.is_file():
    problemes.append('resources/static/index.html absent de la base')
else:
    contenu = index.read_text(encoding='utf8')
    if 'aide-exemples.js' not in contenu:
        problemes.append('index.html sans aide-exemples.js : base antérieure à 3.7.0')
    if 'aide-esoteriques.js' not in contenu:
        problemes.append('index.html sans aide-esoteriques.js : '
                         'base antérieure à 3.8.0')
    if 'aide-index.js' not in contenu:
        problemes.append('index.html sans aide-index.js : '
                         'base antérieure à 3.8.0')
if problemes:
    deja = any('déjà' in p for p in problemes)
    print('   ECHEC — la base n’est pas une Pascal Studio 3.8.0 :')
    for p in problemes:
        print('     - ' + p)
    if deja:
        print('   Cette base porte DÉJÀ les nouveautés 3.9.0 : c’est sans doute le '
              'résultat')
        print('   d’un passage précédent de ce script. Relancez-le sur votre '
              'AppImage 3.8.0')
        print('   d’origine, ou utilisez directement l’AppImage déjà produite.')
    else:
        print('   Construisez d’abord la 3.8.0 : sh reconditionner-3.8.0.sh '
              'AppImage-3.7.0 Pascal-Studio-3.8.0-x86_64.AppImage')
    sys.exit(1)
print('   base 3.8.0 reconnue par son contenu (version, bundle, server.py, '
      'assistant-ia)')
PY

echo "== Version et index.html =="
python3 - "$TMP/asar/package.json" "$R/static/index.html" <<'PY'
import json,re,sys
p,h=sys.argv[1:]
d=json.load(open(p,encoding='utf8'))
assert d['version']=='3.8.0', 'version de base inattendue : '+str(d['version'])
d['version']='3.9.0'
open(p,'w',encoding='utf8').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(h,encoding='utf8').read()
# Les injections 3.6.0, 3.7.0 et 3.8.0 doivent déjà être là : la 3.9.0 n'en
# ajoute aucune à l'index.html de l'application, elle les revérifie.
for attendu in ['nouveau-fichier.js','logos-langages.css','aide-swift-kotlin.js',
                'aide-exemples.js','aide-exemples.css','aide-esoteriques.js',
                'aide-index.css','aide-index.js']:
    assert attendu in s, 'index.html d’une base 3.8.0 attendu, %s manquant' % attendu
# 1. Le catalogue d’aide des dix langages ésotériques DOIT être chargé AVANT le
#    bundle, et comme script CLASSIQUE : le bundle lit window.PS_LANG_HELP au
#    moment de son évaluation. Un « defer » ici ferait disparaître les dix
#    langages de l’aide sans aucune erreur nulle part.
ancre='<script src="/assets/aide-latex.js"></script>'
assert s.count(ancre)==1, 'ancre aide-latex.js introuvable ou ambiguë'
if 'aide-esoteriques.js' not in s:
    s=s.replace(ancre,ancre+'<script src="/assets/aide-esoteriques.js"></script>',1)
# 2. L’index d’aide et sa feuille de style décorent un DOM déjà monté : fin de
#    <head>, donc après le bundle, en « defer ».
fin='</head>'; assert s.count(fin)==1, 'balise </head> ambiguë'
ajout=('<link rel="stylesheet" href="/assets/aide-index.css">'
       '<script defer src="/assets/aide-index.js"></script>')
if 'aide-index.js' not in s: s=s.replace(fin,ajout+fin)
# 3. Contrôle d’ordre : catalogue avant le bundle, index après.
m=re.search(r'/assets/index-[A-Za-z0-9_-]+\.js',s)
assert m, 'script du bundle introuvable dans index.html'
assert s.index('aide-esoteriques.js')<m.start()<s.index('aide-index.js'), \
    'ordre de chargement de l’aide incorrect'
assert 'defer src="/assets/aide-esoteriques.js"' not in s, \
    'aide-esoteriques.js ne doit pas être chargé en « defer »'
open(h,'w',encoding='utf8').write(s)
print('   version 3.9.0 ; les 8 entrées d’aide de la base sont présentes et '
      'leur ordre est intact')
PY

echo "== Correctifs du bundle compilé =="
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
# Le correctif IA de la 3.4.0 d'abord : les ancrages 3.6.0 ont été relevés sur
# un bundle qui le porte déjà.
if ! grep -q 'className:"ps-ai-host"' "$BUNDLE"; then
  python3 "$SRC/patch_ia_3.4.py" "$BUNDLE"; echo "   patch_ia_3.4 appliqué"
fi
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
for nom in patch_langages_3.6 patch_identite_git_3.6; do
  if ! python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null 2>&1; then
    python3 "$SRC/$nom.py" "$BUNDLE"; echo "   $nom appliqué"
  else
    echo "   $nom déjà présent"
  fi
  python3 "$SRC/$nom.py" --verifier "$BUNDLE"
done
# Correctifs 3.7.0 (déjà appliqués dans la base) puis 3.8.0 : complétion pour 39
# langages, débogage pour 37, libellés et badges des dix langages ésotériques.
for nom in patch_interface_3.7 patch_interface_3.8; do
  if ! python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null 2>&1; then
    python3 "$SRC/$nom.py" "$BUNDLE"; echo "   $nom appliqué"
  else
    echo "   $nom déjà présent"
  fi
  python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null || exit 1
done

echo "== Correctifs Electron =="
if ! grep -q 'assistant-ia.*lanceur.py' "$TMP/asar/desktop/main.cjs"; then
  python3 "$SRC/patch_desktop_ia.py" "$TMP/asar/desktop/main.cjs"; echo "   patch_desktop_ia appliqué"
fi
python3 "$SRC/patch_desktop_langages.py" "$TMP/asar/desktop/main.cjs"

echo "== Copie des fichiers =="
for m in $MODULES_38; do cp "$SRC/$m" "$R/"; done
cp "$SRC/polyglot.py" "$SRC/swift_kotlin.py" "$SRC/account_store.py" \
   "$SRC/oauth_accounts.py" "$SRC/git_identity.py" "$SRC/git_manager.py" \
   "$SRC/remote_vault.py" "$R/"
cp "$SRC/monaco-basic/swift-studio.js" "$SRC/monaco-basic/kotlin-studio.js" "$A/"
mkdir -p "$A/logos-langages"
cp "$SRC"/logos-langages/*.svg "$SRC/logos-langages/LICENSE-devicon.txt" "$A/logos-langages/"
cp "$SRC/aide-swift-kotlin.js" "$A/"
cp "$SRC/logos-langages.css" "$SRC/nouveau-fichier.css" "$SRC/nouveau-fichier.js" \
   "$SRC/identite-git.css" "$SRC/assistant-ia-host.js" "$SRC/assistant-ia-host.css" \
   "$SRC/aide-exemples.js" "$SRC/aide-exemples.css" "$A/"
cp "$SRC/aide-esoteriques.js" "$SRC/aide-index.js" "$SRC/aide-index.css" "$A/"
echo "   backend (13 modules) et interface (37 fichiers) copiés"

# L'archive source ne duplique PAS assistant-ia/vendor-ddgs (recherche web) :
# celle de la base est mise de côté puis remise, pour ne jamais la perdre.
if [ ! -e "$SRC/assistant-ia/vendor-ddgs" ] && [ -e "$R/assistant-ia/vendor-ddgs" ]; then
  mv "$R/assistant-ia/vendor-ddgs" "$TMP/vendor-ddgs-conserve"
  echo "   vendor-ddgs absent des sources : celui de la base est conservé"
  DDGS_CONSERVE=1
else
  DDGS_CONSERVE=0
fi
rm -rf "$R/assistant-ia"
cp -a "$SRC/assistant-ia" "$R/assistant-ia"
if [ "$DDGS_CONSERVE" = 1 ]; then
  mv "$TMP/vendor-ddgs-conserve" "$R/assistant-ia/vendor-ddgs"
fi

find "$TMP/squashfs-root" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$TMP/squashfs-root" -type f -name '*.pyc' -delete 2>/dev/null || true

echo "== Reconditionnement =="
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp xz -b 128K -processors 2 >/dev/null
head -c "$DECALAGE" "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
echo "   écrit : $OUT"

echo "== Vérification de l'AppImage produite =="
VERIF="$TMP/verif"; mkdir -p "$VERIF"
(cd "$VERIF" && "$OUT" --appimage-extract >/dev/null)
# package.json est dans l'asar refermé : on l'extrait pour lire la version.
(cd "$VERIF" && asar extract-file "$VERIF/squashfs-root/resources/app.asar" package.json)
python3 - "$VERIF/squashfs-root" "$VERIF/package.json" <<'PY'
import ast, json, re, sys
from pathlib import Path
r = Path(sys.argv[1]); paquet = Path(sys.argv[2])
a = r / 'resources' / 'static' / 'assets'
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.9.0':
    problemes.append('package.json en version %s au lieu de 3.9.0' % version)
s = (r / 'resources' / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ['logos-langages.css', 'nouveau-fichier.js', 'identite-git.css',
                'aide-swift-kotlin.js', 'aide-exemples.css', 'aide-exemples.js',
                'aide-esoteriques.js', 'aide-index.css', 'aide-index.js']:
    if attendu not in s:
        problemes.append('index.html sans ' + attendu)
# Ordre de chargement : le catalogue d’aide ésotérique doit précéder le bundle,
# qui construit sa base d’aide au moment de son évaluation.
m = re.search(r'/assets/index-[A-Za-z0-9_-]+\.js', s)
if not m:
    problemes.append('index.html sans le script du bundle')
elif not (s.index('aide-esoteriques.js') < m.start() < s.index('aide-index.js')):
    problemes.append('ordre de chargement de l’aide incorrect : les dix langages '
                     'n’auraient aucune aide')
if 'defer src="/assets/aide-esoteriques.js"' in s:
    problemes.append('aide-esoteriques.js chargé en « defer » : il serait évalué '
                     'après le bundle')
bundle = (a / 'index-BA4XgQVD.js').read_text(encoding='utf8')
# Marqueurs 3.6.0 reconduits.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'window.PSNewFileDialog(',
                'className:"git-identity-row"', 'swift:["Sw","Swift"]']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.6.0 ' + attendu)
# Marqueurs 3.7.0 reconduits.
for attendu in ['ps-3.7.0-interface', 'for(const t of["pascal","c","cpp","csharp"',
                '"moteur local"']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.7.0 ' + attendu)
# Marqueurs 3.8.0 : libellés, badge, résolveur d’extension et listes allongées.
QUEUE_39 = ('"plaintext","brainfuck","whitespace","piet","lolcode","arnoldc",'
            '"chef","shakespeare","intercal","fractran","malbolge"]')
# La liste de l'aperçu web est vérifiée dans son contexte : sans « piet », le
# bouton d'aperçu enverrait un programme Piet vers la compilation.
APERCUS_WEB = '["html","css","php","piet"].includes(vr('
for attendu in ['ps-3.8.0-interface', 'malbolge:"Malbolge"',
                'malbolge:["MAL","Malbolge"]', '/\\.(bf|b)$/i', QUEUE_39,
                APERCUS_WEB]:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.8.0 ' + attendu)
# Les dix langages doivent apparaître au moins une fois chacun dans le bundle.
for cle, libelle in [('brainfuck', 'Brainfuck'), ('whitespace', 'Whitespace'),
                     ('piet', 'Piet'), ('lolcode', 'LOLCODE'),
                     ('arnoldc', 'ArnoldC'), ('chef', 'Chef'),
                     ('shakespeare', 'Shakespeare'), ('intercal', 'INTERCAL'),
                     ('fractran', 'FRACTRAN'), ('malbolge', 'Malbolge')]:
    if '"%s"' % cle not in bundle:
        problemes.append('bundle sans l’identifiant ' + cle)
    if '%s:"%s"' % (cle, libelle) not in bundle:
        problemes.append('bundle sans le libellé %s:%s' % (cle, libelle))
# Les listes de la 3.7.0 (29 langages en complétion, 27 en débogage) doivent
# avoir été remplacées, pas seulement complétées ailleurs.
for ancienne, nature in [('"ocaml","json","xml","plaintext"]',
                          'liste de complétion 3.7.0 (29 langages)'),
                         ('"basic","fortran","lua","ocaml","xml"]',
                          'liste de débogage 3.7.0 (27 langages)'),
                         ('["html","css","php"].includes(vr(',
                          'liste de l’aperçu web 3.7.0 (sans Piet)')]:
    if ancienne in bundle:
        problemes.append('bundle portant encore la ' + nature)
# L'ancienne liste de débogage à 10 langages doit avoir disparu.
if '["pascal","c","cpp","python","javascript","php","rust","go","ruby","fortran"]' in bundle:
    problemes.append('bundle portant encore la liste de débogage 3.6.0 (10 langages)')
serveur = (r / 'resources' / 'server.py').read_text(encoding='utf8')
# server.py importe les moteurs 3.7.0 sur UNE seule ligne groupée : on cherche
# donc les noms de modules, pas la forme « import X » prise isolément.
for attendu in ['import bac_a_sable', 'debogueur_universel', 'inspecteur_visuel',
                'moteur_completion', 'analyser_en_direct',
                '/api/aide/essayer', '/api/debug/capacites', '/api/completion/etat',
                '/api/inspecteur',
                'capacites_aide', '/api/aide/capacites', 'contenu_binaire',
                'from debug_mux import DebuggerMux, esoterique']:
    if attendu not in serveur:
        problemes.append('server.py sans ' + attendu)
if 'Analyse en direct disponible pour Pascal, C et C++.' in serveur:
    problemes.append('server.py portant encore l’ancien message d’analyse limitée')
for f in ['langages.py', 'verificateurs_statiques.py', 'lsp_client.py',
          'bibliotheques_completion.py', 'moteur_completion.py',
          'debogueur_universel.py', 'inspecteur_visuel.py', 'bac_a_sable.py',
          'debug_mux.py', 'web_preview.py', 'swift_kotlin.py',
          'account_store.py', 'git_identity.py',
          'langages_esoteriques.py', 'capacites_aide.py', 'polyglot.py']:
    if not (r / 'resources' / f).is_file():
        problemes.append('module manquant : ' + f)
for f in ['swift-studio.js', 'kotlin-studio.js', 'nouveau-fichier.js',
          'logos-langages.css', 'nouveau-fichier.css', 'identite-git.css',
          'aide-swift-kotlin.js', 'aide-exemples.js', 'aide-exemples.css',
          'aide-esoteriques.js', 'aide-index.js', 'aide-index.css',
          'logos-langages/swift.svg', 'logos-langages/kotlin.svg',
          'logos-langages/LICENSE-devicon.txt']:
    if not (a / f).is_file():
        problemes.append('asset manquant : ' + f)
# Garde-fous anti-cascade de l’index d’aide. Sans eux, ouvrir l’aide reconstruit
# l’index sans fin : l’observateur de mutations voit nos propres écritures et
# relance un balayage, le rendu s’emballe et l’application tombe. Ils sont
# vérifiés ici pour qu’un aide-index.js antérieur au correctif ne puisse plus
# jamais être livré.
index_aide = a / 'aide-index.js'
if index_aide.is_file():
    texte_index = index_aide.read_text(encoding='utf8')
    for attendu in ['signatureDe', 'observateur.takeRecords()',
                    'if(enCours) return', 'DELAI_REESSAI', 'maj(true)']:
        if attendu not in texte_index:
            problemes.append('aide-index.js sans le garde-fou ' + attendu
                             + ' : l’ouverture de l’aide ferait planter '
                               'l’application')
logo = r / 'resources' / 'assistant-ia' / 'static' / 'brand' / 'logo-ia.svg'
if not logo.is_file():
    problemes.append('logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg')
else:
    contenu = logo.read_text(encoding='utf8')
    if 'viewBox' not in contenu:
        problemes.append('logo-ia.svg sans viewBox')
ia_inst = r / 'resources' / 'assistant-ia'
index_ia = ia_inst / 'static' / 'index.html'
if not index_ia.is_file():
    problemes.append('assistant-ia/static/index.html manquant')
else:
    contenu = index_ia.read_text(encoding='utf8')
    if '.msg.assistant::before' not in contenu or 'logo-ia.svg' not in contenu:
        problemes.append('interface de l’assistant sans l’avatar du logo IA')
    # Câblage 3.9.0 de la page : bouton et boîte de dialogue de l'espace,
    # réglages du filtre, événement « optimise », comparateur, capture.
    for attendu in ('id="espbtn"', 'id="espdlg"', 'id="espproj"', 'id="espfile"',
                    'id="prompt"', 'id="prompt_model"',
                    "ev.type === 'optimise'", 'function voirPrompt',
                    'function espaceCapturer', "'prompt', 'prompt_model'",
                    'demande optimisée · voir'):
        if attendu not in contenu:
            problemes.append('interface de l’assistant sans %s' % attendu)
    bouton_prompt = '<div class="promptopt"><button data-a="prompt"'
    if contenu.count(bouton_prompt) != 2:
        problemes.append('bouton du prompt optimisé présent %d fois au lieu de 2 '
                         ': il manquerait au flux ou au rechargement'
                         % contenu.count(bouton_prompt))
    if 'demande optimisée · voir' not in contenu:
        problemes.append('interface de l’assistant sans l’explication du filtre')
for nom in ('optimiseur_prompt.py', 'espace_travail.py'):
    if not (ia_inst / nom).is_file():
        problemes.append('assistant-ia/%s manquant dans l’AppImage' % nom)
if not (ia_inst / 'prompts' / 'optimiseur.md').is_file():
    problemes.append('assistant-ia/prompts/optimiseur.md manquant : la consigne '
                     'du filtre ne serait plus modifiable')
srv_inst = ia_inst / 'server.py'
if not srv_inst.is_file():
    problemes.append('assistant-ia/server.py manquant dans l’AppImage')
else:
    texte_srv = srv_inst.read_text(encoding='utf8')
    try:
        ast.parse(texte_srv)
    except SyntaxError as erreur:
        problemes.append('assistant-ia/server.py installé invalide : %s' % erreur)
    for attendu in ('import optimiseur_prompt', 'import espace_travail',
                    'Route("/api/espace"', 'Route("/api/espace/depot"',
                    'Route("/api/espace/fichier"', 'Route("/api/espace/apercu"',
                    'Route("/api/espace/renommer"', 'Route("/api/espace/supprimer"',
                    'Route("/api/espace/dossier"', 'Route("/api/espace/enregistrer"',
                    'optimiser_en_arriere_plan', '"type": "optimise"',
                    'espace_capturer', 'prompt_model', 'X-PS-Espace'):
        if attendu not in texte_srv:
            problemes.append('assistant-ia/server.py installé sans %s' % attendu)
nb_logos = len(list((a / 'logos-langages').glob('*.svg')))
if nb_logos != 22:
    problemes.append('%d logos au lieu de 22' % nb_logos)
if problemes:
    print('   ECHEC :')
    for p in problemes: print('     - ' + p)
    sys.exit(1)
print('   contenu vérifié : bundle intact, index.html, 21 modules, %d logos, '
      'logo IA, assistant 3.9.0 (filtre + espace, 8 routes)'
      % nb_logos)
PY
echo
echo "Pascal Studio 3.9.0 prêt : $OUT"
echo "Nouveautés, toutes dans l'assistant IA :"
echo "  - Un filtre fait réécrire votre demande par un modèle séparé avant de"
echo "    l'envoyer à l'IA agentique. Votre demande reste affichée telle quelle ;"
echo "    le bouton « ⚙ demande optimisée · voir » montre le prompt réellement"
echo "    envoyé, permet de le copier, de le réutiliser ou de le comparer au vôtre."
echo "    Réglable dans ⚙️ Paramètres : Optimiser la demande (oui/non) et le"
echo "    modèle qui réécrit (par défaut : un modèle léger différent)."
echo "  - Le bouton « 🗂 Espace » conserve, projet par projet, les documents"
echo "    produits (exports Word et Excel, blocs de code téléchargés) et ceux que"
echo "    vous déposez, avec dossier, aperçu, renommage et suppression."
echo "Les dix langages ésotériques, l'index d'aide et la recherche par"
echo "fonctionnalité de la 3.8.0 restent en place."
sha256sum "$OUT"
echo "Notez cette empreinte : elle identifie votre construction."
