#!/bin/sh
# Pascal Studio 4.0.0 — construit l'AppImage 4.0.0 à partir de l'AppImage 3.9.0
# et des sources de modifications.
#
#   sh reconditionner-4.0.0.sh Pascal-Studio-3.9.0-x86_64.AppImage Pascal-Studio-4.0.0-x86_64.AppImage
#
# Prérequis : Python 3.11+, asar (@electron/asar), mksquashfs (squashfs-tools),
# et de la place disque (environ 1,5 Go libre pour l'extraction).
# Aucun accès réseau pendant la construction.
#
# IDENTITÉ DE LA BASE — à lire avant de lancer.
# Les scripts précédents comparaient l'empreinte SHA-256 de la base à une valeur
# figée. C'est impossible ici : votre AppImage 3.9.0 est produite par
# reconditionner-3.9.0.sh sur votre machine, et mksquashfs n'est pas
# bit-à-bit reproductible (horodatages). Une empreinte figée refuserait donc
# systématiquement une base légitime. Ce script vérifie l'identité de la base
# par son CONTENU : version 3.9.0 dans package.json, présence des marqueurs
# 3.6.0, 3.7.0 et 3.8.0 dans le bundle, des routes 3.7.0 et 3.8.0 dans
# server.py, du filtre et de l'espace de travail 3.9.0 dans
# resources/assistant-ia/, et ABSENCE des nouveautés 4.0.0. C'est conforme au
# choix que vous avez fait pour construire-appimage.py (« assouplir » le
# contrôle de la base). La contrepartie est assumée : une base modifiée à la
# main mais portant les bons marqueurs serait acceptée.
#
# CETTE VERSION RÉÉCRIT LE BUNDLE — contrairement à la 3.9.0.
# patch_interface_4.0.py y applique 16 substitutions par ancres et laisse 19
# traces vérifiables : l'assembleur comme langage à part entière (enregistrement
# Monaco, tokenizer, complétion, débogage), l'éditeur de bases de données en
# onglet, et les panneaux de la barre latérale — dev web et rétro-ingénierie.
# Chaque substitution exige que son ancre figure exactement le nombre de fois
# attendu ; sinon RIEN n'est écrit et l'ancre en cause est nommée. Le
# vérificateur rend TROIS états et non deux : 0 conforme, 1 patchable (les
# ancres sont bonnes, rien n'est encore en place), 2 problème. Confondre 0 et 1
# ferait sauter l'application du correctif et livrerait une interface sans
# aucune des nouveautés, sans erreur nulle part. Trois des substitutions (le
# panneau de rétro-ingénierie) s'accrochent au texte produit par trois autres
# (le panneau dev web) : le vérificateur SIMULE la séquence pour ne pas annoncer
# à tort des ancres manquantes.
#
# ORDRE DE CHARGEMENT DE L'INTERFACE — cinq injections dans index.html.
#   * aide-assembleur.js est chargé AVANT le bundle et comme script CLASSIQUE :
#     le bundle construit sa base d'aide au moment de son évaluation, à partir
#     de window.PS_LANG_HELP. Un « defer » ici ferait disparaître l'aide de
#     l'assembleur sans aucune erreur nulle part. C'est le même acquis
#     qu'aide-esoteriques.js en 3.8.0.
#   * les quatre paires de panneaux (data-studio, navigateur-studio,
#     devweb-studio, re-studio) sont chargées APRÈS le bundle, la FEUILLE DE
#     STYLE avant le SCRIPT : un script qui rend du DOM au chargement produit un
#     éclair de contenu non stylé si sa feuille arrive après, et une feuille
#     chargée avant le bundle se fait écraser certaines de ses règles.
#   * asm-studio.js n'est PAS injecté : le bundle le charge par
#     import("./asm-studio.js"). Sa présence dans les assets est vérifiée, et
#     son absence d'index.html aussi — une balise le chargerait deux fois.
# inserer-assets-4.0.0.py connaît les cinq et les vérifie ENSEMBLE. La paire
# re-studio avait été oubliée pendant le développement : le bundle aurait créé
# .ps-re-host et RIEN ne serait venu y rendre le panneau — une fonctionnalité
# livrée morte, sans aucun message d'erreur. Un seul script qui contrôle les
# cinq rend cet oubli impossible, là où trois inséreurs chaînés ne le pouvaient
# pas.
#
# GHIDRA N'EST PAS FOURNI, ET C'EST VOULU.
# Ghidra pèse environ 570 Mo, n'est pas dans Debian (sa construction exige
# Gradle 8.5+ et télécharge ses dépendances, ce que la politique Debian interdit
# dans main), et demande un JDK 21 ou plus. Le panneau de rétro-ingénierie le
# DÉTECTE à l'exécution et, s'il est absent, le DIT en nommant ce qui manque
# (Ghidra, le JDK, l'environnement virtuel PyGhidra) avec les vraies commandes
# d'installation. Sans Ghidra le panneau reste pleinement utile : analyseurs en
# Python pur (ELF, PE, Mach-O, classe Java), binutils (readelf, objdump, nm,
# strings, file, od), 15 widgets et 28 fiches. AUCUN binaire analysé n'est
# jamais exécuté, et capacites() l'affirme.
#
# L'ÉCRITURE DES MIROIRS EST RÉELLE, ET CE QU'ELLE REFUSE EST NOMMÉ.
# XLSX, ODS et XML s'écrivent : cases, lignes, colonnes et feuilles, par
# /api/data/apply et /api/data/structure. Trois garanties, toutes vérifiées par
# smoke_donnees_etendues.py et smoke_routes_miroirs.py :
#   * une table qui n'est pas mentionnée SURVIT. La fusion relit le fichier au
#     moment d'écrire, et une suppression passe par une demande explicite :
#     enregistrer une feuille d'un classeur qui en a cinq ne vide pas les quatre
#     autres ;
#   * ce qui ne peut pas être écrit est refusé AVANT, et annoncé dès l'ouverture
#     par donnees_etendues.ecriture_possible() : des formules dans un classeur
#     (elles seraient remplacées par leurs dernières valeurs), openpyxl absent
#     pour XLSX, un document XML dont la racine ne peut pas être replacée ;
#   * rien n'est perdu en silence. En XML la déclaration, le DOCTYPE, les
#     commentaires — y compris hors de l'élément racine, que ElementTree ne
#     conserve pas — et les espaces de noms sont recopiés ; en ODS l'entrée
#     mimetype reste la première et n'est pas compressée, sans quoi LibreOffice
#     refuse le fichier comme n'étant pas un document ODF.
# Un document XML ne peut pas recevoir de NOUVELLE table : une table y est une
# famille d'éléments répétés, et rien ne dit où placer les nouveaux éléments. Le
# refus le dit et renvoie vers l'éditeur de texte, qui reste disponible.
#
# Le script s'arrête sans rien écrire si la base n'est pas une 3.9.0, si un
# module 4.0.0 ne s'importe pas ou échoue à son autocontrôle, si le tokenizer
# engendré diffère de celui qui est livré, si un fichier à recopier manque, si
# une ancre du bundle est absente ou ambiguë, ou si l'une des cinq injections
# d'index.html manque. Il termine en ré-extrayant l'AppImage produite pour
# vérifier le résultat SUR L'IMAGE et non sur les sources : bundle, index.html,
# autocontrôles des modules rejoués depuis l'image, routes du serveur, main.cjs
# et preload.cjs.
set -eu
[ "$#" = 2 ] || { echo 'Usage : sh reconditionner-4.0.0.sh AppImage-3.9.0 SORTIE.AppImage' >&2; exit 1; }
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
[ "$BASE" != "$OUT" ] || { echo 'La sortie ne peut pas écraser la base.' >&2; exit 1; }
[ -f "$BASE" ] || { echo "Base introuvable : $BASE" >&2; exit 1; }

echo "== Contrôle des prérequis =="
command -v asar >/dev/null || { echo 'asar manquant : npm i -g @electron/asar' >&2; exit 1; }
command -v mksquashfs >/dev/null || { echo 'mksquashfs manquant : sudo apt install squashfs-tools' >&2; exit 1; }
command -v python3 >/dev/null || { echo 'python3 manquant.' >&2; exit 1; }

# Nouveautés 4.0.0. Trois listes, parce que trois destinations différentes :
# les modules Python vont dans resources/, les assets d'interface dans
# resources/static/assets/, et les outils de construction ne sont pas installés
# (ils servent à préparer l'image).
MODULES_40="assembleur.py donnees_etendues.py database_tools.py \
            navigateur_etat.py devweb.py devweb_journal.py devweb_analyse.py \
            devweb_references.py devweb_audits.py devweb_modeles.py \
            devweb_client.py retro_detection.py retro_binaires.py \
            retro_ghidra.py retro_fiches.py retro.py"
ASSETS_40="data-studio.js data-studio.css navigateur-studio.js \
           navigateur-studio.css devweb-studio.js devweb-studio.css \
           re-studio.js re-studio.css aide-assembleur.js"
OUTILS_40="patch_interface_4.0.py patch_desktop_navigateur.py \
           desktop-preload.cjs inserer-assets-4.0.0.py asm_studio.py \
           aide-assembleur.py"
# server.py et web_preview.py sont déjà dans MODULES_38 : ils portent les routes
# 4.0.0 parce qu'ils ont été modifiés dans l'arborescence source. Les recopier
# suffit, et rejouer ici les inséreurs de routes échouerait — leurs ancres ont
# disparu une fois les substitutions appliquées.

# Tout ce que ce script recopie doit exister : on échoue avant de démonter l'AppImage.
MODULES_38="langages.py verificateurs_statiques.py lsp_client.py \
            bibliotheques_completion.py moteur_completion.py \
            debogueur_universel.py inspecteur_visuel.py bac_a_sable.py \
            debug_mux.py web_preview.py server.py \
            langages_esoteriques.py capacites_aide.py"
for f in patch_interface_3.7.py patch_interface_3.8.py \
         patch_langages_3.6.py patch_identite_git_3.6.py \
         patch_desktop_langages.py patch_ia_3.4.py patch_desktop_ia.py \
         $MODULES_38 \
         polyglot.py swift_kotlin.py account_store.py oauth_accounts.py \
         git_identity.py git_manager.py remote_vault.py \
         assistant-ia-host.js assistant-ia-host.css \
         logos-langages.css nouveau-fichier.css nouveau-fichier.js identite-git.css \
         aide-exemples.js aide-exemples.css \
         aide-esoteriques.py aide-esoteriques.js aide-index.js aide-index.css \
         monaco-basic/swift-studio.js monaco-basic/kotlin-studio.js \
         logos-langages/swift.svg logos-langages/kotlin.svg logos-langages/LICENSE-devicon.txt \
         aide-swift-kotlin.py aide-swift-kotlin.js; do
  [ -e "$SRC/$f" ] || { echo "Fichier manquant dans modifications/ : $f" >&2; exit 1; }
done
[ -d "$SRC/assistant-ia" ] || { echo 'Dossier manquant : assistant-ia/' >&2; exit 1; }
[ -f "$SRC/assistant-ia/static/brand/logo-ia.svg" ] || { echo 'Logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg' >&2; exit 1; }
# Nouveautés 3.9.0 : sans l'un de ces trois fichiers, l'assistant démarrerait
# avec une route morte ou un filtre incapable de recevoir sa consigne.
for f in assistant-ia/optimiseur_prompt.py assistant-ia/espace_travail.py \
         assistant-ia/prompts/optimiseur.md; do
  [ -f "$SRC/$f" ] || { echo "Fichier 3.9.0 manquant : $f" >&2; exit 1; }
done
# Nouveautés 4.0.0 : sans l'un de ces fichiers, une fonctionnalité serait
# absente de l'application SANS AUCUN message d'erreur. data-studio.js et
# data-studio.css ne sont copiés par AUCUN reconditionneur 3.x, et
# database_tools.py seulement par le 2.5.0 : ils venaient de la base, et ils ont
# été modifiés en 4.0.0.
for f in $MODULES_40 $ASSETS_40 $OUTILS_40 monaco-additions/asm-studio.js; do
  [ -e "$SRC/$f" ] || { echo "Fichier 4.0.0 manquant dans modifications/ : $f" >&2; exit 1; }
done
echo "   sources complètes ($(ls "$SRC"/logos-langages/*.svg | wc -l) logos, " \
     "$(echo $MODULES_40 | wc -w) modules et $(echo $ASSETS_40 | wc -w) " \
     "assets 4.0.0)"

# Les nouveaux modules doivent être importables et cohérents avant toute écriture.
echo "== Contrôle des modules 3.9.0 et 4.0.0 =="
python3 - "$SRC" <<'PY' || exit 1
import sys, importlib.util
from pathlib import Path
src = Path(sys.argv[1])
sys.path.insert(0, str(src))
attendus = ['langages', 'verificateurs_statiques', 'lsp_client',
            'bibliotheques_completion', 'moteur_completion',
            'debogueur_universel', 'inspecteur_visuel', 'bac_a_sable',
            'langages_esoteriques', 'capacites_aide', 'debug_mux', 'polyglot']
for nom in attendus:
    chemin = src / (nom + '.py')
    if not chemin.is_file():
        raise SystemExit('module manquant : ' + nom + '.py')
    spec = importlib.util.spec_from_file_location(nom, chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
import langages, debogueur_universel, moteur_completion, inspecteur_visuel
import bac_a_sable, langages_esoteriques, capacites_aide, debug_mux, polyglot
tous = list(langages.tous())
# Présence NOMMÉE des langages que chaque version a ajoutés, puis plancher :
# un registre tronqué fait disparaître un nom, et le plancher attrape une
# amputation massive. Ni l'un ni l'autre ne casse quand on AJOUTE un langage.
for attendu in ['pascal', 'c', 'cpp', 'python', 'javascript', 'php', 'rust',
                'go', 'ruby', 'fortran', 'basic', 'lua', 'ocaml', 'perl',
                'swift', 'kotlin', 'brainfuck', 'whitespace', 'piet',
                'lolcode', 'arnoldc', 'chef', 'shakespeare', 'intercal',
                'fractran', 'malbolge', 'asm']:
    if attendu not in tous:
        raise SystemExit('registre sans le langage ' + attendu)
if len(tous) < 40:
    raise SystemExit('registre de %d langages : au moins 40 attendus (les 39 '
                     'de la 3.9.0 plus l’assembleur)' % len(tous))
modes = debogueur_universel.tous_les_modes()
debogables = sum(1 for v in modes.values() if v != debogueur_universel.MODE_AUCUN)
if debogables < 37:
    raise SystemExit('%d langages débogables : au moins 37 attendus (les 36 '
                     'de la 3.9.0 plus l’assembleur)' % debogables)
# L'assembleur se débogue avec gdb ; sans cela le panneau de débogage
# proposerait un pas-à-pas qui ne s'arrête jamais.
if langages.debogueur('asm') != 'gdb':
    raise SystemExit('assembleur : débogueur %r au lieu de « gdb »'
                     % langages.debogueur('asm'))
graphiques = sorted(k for k in tous if langages.est_graphique(k))
if len(graphiques) < 7:
    raise SystemExit('%d langages graphiques : au moins 7 attendus : %s'
                     % (len(graphiques), graphiques))
if 'piet' not in graphiques:
    raise SystemExit('Piet absent des langages graphiques : %s' % graphiques)
# Les dix langages ésotériques : chacun doit avoir son moteur, son débogueur,
# son aperçu et ses quatre facettes d'aide minimales.
esoteriques = list(langages_esoteriques.ORDRE_ESOTERIQUES)
if len(esoteriques) < 10:
    raise SystemExit('%d langages ésotériques : au moins 10 attendus'
                     % len(esoteriques))
for cle in esoteriques:
    if cle not in tous:
        raise SystemExit('langage ésotérique absent du registre : ' + cle)
    if langages.debogueur(cle) != 'esoterique':
        raise SystemExit('%s : débogueur=%r au lieu de « esoterique »'
                         % (cle, langages.debogueur(cle)))
    if not langages_esoteriques.est_esoterique(cle):
        raise SystemExit('est_esoterique() faux pour ' + cle)
    fac = capacites_aide.capacites(cle)['facettes']
    for attendu in ('debogage', 'variables', 'completions', 'analyse'):
        if attendu not in fac:
            raise SystemExit('%s : facette d’aide %s manquante (%s)'
                             % (cle, attendu, fac))
if 'apercu' not in capacites_aide.capacites('piet')['facettes']:
    raise SystemExit('Piet sans facette « apercu » dans le catalogue d’aide')
if not callable(debug_mux.esoterique):
    raise SystemExit('debug_mux.esoterique() absent : la route de débogage ne '
                     'verrait pas les langages ésotériques')
if polyglot.kind('programme.bf') != 'brainfuck':
    raise SystemExit('polyglot.kind() ne reconnaît pas .bf : %r'
                     % polyglot.kind('programme.bf'))
if not inspecteur_visuel.STYLE or not inspecteur_visuel.SCRIPT:
    raise SystemExit('inspecteur visuel sans feuille de style ni script')
if not callable(inspecteur_visuel.carte_piet):
    raise SystemExit('inspecteur_visuel.carte_piet() absent')
if not moteur_completion.CompletionUniverselle:
    raise SystemExit('façade de complétion absente')
if not bac_a_sable.nom_de_fichier('fortran').endswith('.f90'):
    raise SystemExit('Fortran : prog.f imposerait le format fixe')
cat = capacites_aide.catalogue()
# Le catalogue d'aide doit être SYNCHRONE avec le registre : un langage présent
# dans l'un et absent de l'autre n'aurait aucune aide, ou une aide sans
# langage. Cette égalité est un invariant, pas un compte à tenir à jour.
if cat['total'] != len(tous):
    raise SystemExit('catalogue d’aide à %d entrées pour un registre de %d '
                     'langages : l’aide n’est pas synchronisée'
                     % (cat['total'], len(tous)))
if len(cat['fonctionnalites']) < 8:
    raise SystemExit('catalogue d’aide : %d fonctionnalités, au moins 8 '
                     'attendues' % len(cat['fonctionnalites']))
print('   %d langages, %d débogables, %d graphiques, %d ésotériques, '
      '%d fonctionnalités d’aide'
      % (len(tous), debogables, len(graphiques), len(esoteriques),
         len(cat['fonctionnalites'])))

# --- Nouveautés 3.9.0 -------------------------------------------------
# Les deux modules sont importés puis EXERCÉS : un module qui s'importe mais
# dont une fonction casse au premier appel ne doit pas atteindre l'AppImage.
# Trois défauts de ce genre ont été trouvés pendant le développement
# (str.normalize() inexistant, .format() sur une consigne à accolades,
# core.BASE inexistant) : aucun n'était visible à la lecture.
import ast, tempfile
ia = src / 'assistant-ia'
# append et non insert : assistant-ia contient server.py, core.py et agent.py,
# qui masqueraient les modules homonymes de modifications/.
sys.path.append(str(ia))
marqueurs = {'optimiseur_prompt': 'ps-3.9.0-optimiseur',
             'espace_travail': 'ps-3.9.0-espace'}
for nom, attendu in marqueurs.items():
    chemin = ia / (nom + '.py')
    if not chemin.is_file():
        raise SystemExit('module 3.9.0 manquant : assistant-ia/' + nom + '.py')
    spec = importlib.util.spec_from_file_location(nom, chemin)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.MARQUEUR != attendu:
        raise SystemExit('%s : marqueur %r au lieu de %r'
                         % (nom, module.MARQUEUR, attendu))
import optimiseur_prompt, espace_travail
if 'core' in sys.modules:
    raise SystemExit('un module 3.9.0 importe core : il casserait hors de '
                     'l’assistant')
# La consigne modifiable : si ses marques disparaissent, le modèle séparé ne
# recevrait plus ni le contexte ni la demande de l'utilisateur.
chemin_consigne = ia / 'prompts' / 'optimiseur.md'
consigne = chemin_consigne.read_text(encoding='utf8')
for marque in ('{contexte}', '{demande}', '"prompt"'):
    if marque not in consigne:
        raise SystemExit('prompts/optimiseur.md sans %s : le filtre ne '
                         'pourrait pas transmettre la demande' % marque)
demande = 'Écris un script qui renomme mes photos de vacances'
meta = optimiseur_prompt.construire_meta_prompt(
    demande, {'projet_nom': 'Test', 'categorie': 'code'}, consigne=consigne)
if demande not in meta:
    raise SystemExit('la consigne du filtre ne transmet pas la demande')
# Le contrat réel : le bloc construit par bloc_contexte() doit se retrouver
# tel quel dans la consigne envoyée au modèle séparé. Vérifier un libellé figé
# (« Catégorie : … ») a produit un faux échec lors de la première exécution :
# c'est le libellé du module qui fait foi, pas celui du script.
contexte_attendu = optimiseur_prompt.bloc_contexte(
    {'projet_nom': 'Test', 'categorie': 'code'})
if not contexte_attendu:
    raise SystemExit('bloc_contexte() renvoie un bloc vide pour un contexte réel')
if 'Projet ouvert : Test' not in contexte_attendu:
    raise SystemExit('bloc_contexte() sans le nom du projet ouvert')
if contexte_attendu not in meta:
    raise SystemExit('la consigne du filtre ne transmet pas le contexte')
if '{contexte}' in meta or '{demande}' in meta:
    raise SystemExit('la consigne du filtre laisse une marque non remplacée')
ok, raison = optimiseur_prompt.valider(
    demande, demande + ', avec les critères de réussite et le format de sortie.')
if not ok:
    raise SystemExit('le filtre refuse un produit valide : ' + raison)
if optimiseur_prompt.valider(demande, '')[0]:
    raise SystemExit('le filtre accepte un produit vide')
if optimiseur_prompt.valider(demande, 'X' * 40000)[0]:
    raise SystemExit('le filtre accepte un produit démesuré')
if optimiseur_prompt.est_utile('ok')[0]:
    raise SystemExit('le filtre juge utile une demande trop courte')
# L'espace de travail, sur un vrai dossier temporaire : écriture, lecture,
# index, collision de noms, et confinement contre trois chemins hostiles.
with tempfile.TemporaryDirectory() as essai:
    espace = espace_travail.Espace(essai)
    espace.ecrire('projet1', 'note.txt', 'contenu')
    if espace.lire('projet1', 'note.txt') != b'contenu':
        raise SystemExit('espace de travail : aller-retour en échec')
    if len(espace.lister('projet1')['fichiers']) != 1:
        raise SystemExit('espace de travail : listage incohérent')
    if espace.nom_libre('projet1', 'note.txt') != 'note (2).txt':
        raise SystemExit('espace de travail : collision non renommée : %r'
                         % espace.nom_libre('projet1', 'note.txt'))
    for hostile in ('../dehors.txt', 'a/../../b.txt', 'é' * 300):
        try:
            espace.resoudre('projet1', hostile)
            raise SystemExit('espace de travail : chemin hostile accepté : %r'
                             % hostile[:24])
        except espace_travail.CheminRefusé:
            pass
# Le serveur de l'assistant doit compiler et porter les deux nouveautés :
# une erreur de syntaxe ici rendrait l'assistant muet sans message clair.
serveur_ia = (ia / 'server.py').read_text(encoding='utf8')
try:
    ast.parse(serveur_ia)
except SyntaxError as erreur:
    raise SystemExit('assistant-ia/server.py invalide : %s' % erreur)
routes = ['Route("/api/espace"', 'Route("/api/espace/depot"',
          'Route("/api/espace/fichier"', 'Route("/api/espace/apercu"',
          'Route("/api/espace/renommer"', 'Route("/api/espace/supprimer"',
          'Route("/api/espace/dossier"', 'Route("/api/espace/enregistrer"']
for attendu in (['import optimiseur_prompt', 'import espace_travail',
                 'optimiser_en_arriere_plan', '"type": "optimise"',
                 'espace_capturer', 'prompt_model', 'X-PS-Espace'] + routes):
    if attendu not in serveur_ia:
        raise SystemExit('assistant-ia/server.py sans %s' % attendu)
# La page : bouton, boîte de dialogue, réglages, événement du filtre, et le
# marqueur du prompt optimisé qui doit figurer DEUX fois (flux et rechargement).
page_ia = (ia / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ('id="espbtn"', 'id="espdlg"', 'id="espproj"', 'id="espfile"',
                'id="prompt"', 'id="prompt_model"',
                "ev.type === 'optimise'", 'function voirPrompt',
                'function espaceCapturer', "'prompt', 'prompt_model'",
                'demande optimisée · voir'):
    if attendu not in page_ia:
        raise SystemExit('assistant-ia/static/index.html sans %s' % attendu)
# Le compte porte sur le BALISAGE du bouton, pas sur le libellé : celui-ci
# figure aussi dans la phrase d'explication des réglages, donc trois fois.
# Un compte sur le libellé a produit un faux échec à la première exécution.
bouton_prompt = '<div class="promptopt"><button data-a="prompt"'
if page_ia.count(bouton_prompt) != 2:
    raise SystemExit('le bouton du prompt optimisé figure %d fois au lieu de 2 '
                     '(flux et rechargement)'
                     % page_ia.count(bouton_prompt))
if 'demande optimisée · voir' not in page_ia:
    raise SystemExit('la page n’explique pas le filtre à l’utilisateur')
if 'UI_IDS = [\'mode\', \'cat\', \'web\', \'tools\', \'team\', \'prompt\', \'prompt_model\']' not in page_ia:
    raise SystemExit('UI_IDS de la page incomplet : les deux réglages du '
                     'filtre ne seraient pas enregistrés')
print('   3.9.0 : filtre et espace importés et exercés, 8 routes, page câblée')
PY

# Les modules 4.0.0 doivent être IMPORTÉS ET EXERCÉS avant toute écriture : un
# import qui échoue dans l'image doit être détecté au reconditionnement, pas au
# premier clic de l'utilisateur. Chacun porte son propre autocontrôle, qui
# imprime le nombre de contrôles réellement joués ; on le JOUE plutôt que de se
# contenter d'un import, parce qu'un import réussi ne prouve rien sur les gardes
# du module. Ils sont joués dans des processus séparés : un autocontrôle qui
# lève ou qui appelle sys.exit ne doit pas emporter le script entier.
echo "== Contrôle des modules 4.0.0 =="
for m in assembleur donnees_etendues devweb devweb_journal devweb_analyse \
         devweb_references devweb_audits devweb_modeles devweb_client \
         retro_detection retro_binaires retro_ghidra retro_fiches retro; do
  [ -f "$SRC/$m.py" ] || { echo "Module 4.0.0 manquant : $m.py" >&2; exit 1; }
  sortie=$(cd "$SRC" && PYTHONPATH="$SRC" python3 "$m.py" 2>&1) || {
    echo "AUTOCONTRÔLE EN ÉCHEC : $m.py" >&2
    echo "$sortie" | tail -6 >&2
    exit 1
  }
  echo "   $m : $(echo "$sortie" | grep -v '^}$' | tail -1 | cut -c1-92)"
done
# Deux modules n'ont pas d'autocontrôle : ils sont au moins importés.
python3 - "$SRC" <<'PY' || exit 1
import importlib.util, sys
from pathlib import Path
src = Path(sys.argv[1]); sys.path.insert(0, str(src))
for nom in ('database_tools', 'navigateur_etat'):
    spec = importlib.util.spec_from_file_location(nom, src / (nom + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    print('   %s importé' % nom)
PY

# Le tokenizer de l'assembleur est ENGENDRÉ depuis les tables d'assembleur.py :
# la coloration et l'analyse statique doivent connaître les MÊMES mnémoniques,
# registres et directives. Écrites séparément, les deux listes divergent et
# l'éditeur colore en mot-clef une instruction que l'analyseur signale comme
# inconnue — ou l'inverse. On le réengendre donc et on le COMPARE à celui qui
# est livré : toute liste engendrée doit être rendue puis vérifiée, jamais
# supposée à jour.
python3 - "$SRC" <<'PY' || exit 1
import subprocess, sys, tempfile
from pathlib import Path
src = Path(sys.argv[1])
livre = src / 'monaco-additions' / 'asm-studio.js'
with tempfile.TemporaryDirectory() as dossier:
    produit = Path(dossier) / 'asm-studio.js'
    essai = subprocess.run([sys.executable, str(src / 'asm_studio.py'), str(produit)],
                           capture_output=True, text=True, cwd=str(src))
    if essai.returncode != 0:
        raise SystemExit('asm_studio.py a échoué :\n' + (essai.stdout + essai.stderr)[-800:])
    if produit.read_bytes() != livre.read_bytes():
        raise SystemExit(
            'asm-studio.js livré DIFFÈRE de celui qu’engendre assembleur.py : '
            'les tables ont changé sans que le tokenizer soit réengendré. '
            'Relancez python3 asm_studio.py monaco-additions/asm-studio.js.')
    print('   asm-studio.js réengendré et identique à celui qui est livré '
          '(%d octets)' % len(produit.read_bytes()))
PY

echo "== Contrôle de la base =="
# Détection de la taille de l'en-tête AppImage : le système de fichiers commence
# au superbloc squashfs. Pas de comparaison d'empreinte : voir l'en-tête.
DECALAGE=$(python3 - "$BASE" <<'PY'
import struct, sys
chemin = sys.argv[1]
with open(chemin, 'rb') as f:
    donnees = f.read()
# Un superbloc squashfs valide : magic « hsqs », version 4.0, taille de bloc
# puissance de deux, compresseur connu.
COMPRESSEURS = {1: 'gzip', 2: 'lzma', 3: 'lzo', 4: 'xz', 5: 'lz4', 6: 'zstd'}
trouves = []
i = donnees.find(b'hsqs')
while i >= 0 and len(trouves) < 4:
    if i + 96 <= len(donnees):
        inodes, _mtime, bloc, _frag = struct.unpack_from('<IIII', donnees, i + 4)
        comp, = struct.unpack_from('<H', donnees, i + 20)
        majeur, mineur = struct.unpack_from('<HH', donnees, i + 28)
        if (majeur == 4 and comp in COMPRESSEURS and inodes > 0
                and bloc >= 4096 and (bloc & (bloc - 1)) == 0):
            trouves.append((i, COMPRESSEURS[comp], bloc))
    i = donnees.find(b'hsqs', i + 1)
if not trouves:
    raise SystemExit('Aucun superbloc squashfs valide trouvé dans la base.')
# La première occurrence valide est celle embarquée par l'AppImage.
decalage, comp, bloc = trouves[0]
if decalage != 188392:
    sys.stderr.write('Note : en-tête de %d octets (188392 attendu) ; %d retenu.\n'
                     % (decalage, decalage))
sys.stderr.write('En-tête %d octets, %s, blocs %d KiB.\n'
                 % (decalage, comp, bloc // 1024))
print(decalage)
PY
) || exit 1
echo "   en-tête AppImage : $DECALAGE octets"

echo "== Extraction =="
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT HUP INT TERM
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
# Le nom du bundle porte une empreinte de build (index-XXXXXXXX.js) qui change
# dès que le frontend est recompilé. On le cherche par glob et on exige
# EXACTEMENT un candidat : zéro rendrait muet l’échec des correctifs
# d’interface, et deux signifieraient une base incohérente.
NB_BUNDLES=$(ls "$A"/index-*.js 2>/dev/null | wc -l)
[ "$NB_BUNDLES" -eq 1 ] || {
  echo "Bundle frontend : $NB_BUNDLES fichier(s) index-*.js dans static/assets,"
       "1 attendu." >&2
  exit 1
}
BUNDLE=$(ls "$A"/index-*.js)
echo "   bundle de la base : $(basename "$BUNDLE")"
[ -f "$R/app.asar" ] || { echo 'resources/app.asar absent de la base.' >&2; exit 1; }
[ -f "$BUNDLE" ] || { echo 'Bundle frontend introuvable dans la base.' >&2; exit 1; }
asar extract "$R/app.asar" "$TMP/asar"
echo "   extrait dans $TMP"

echo "== Vérification de l'identité de la base (3.9.0) =="
python3 - "$TMP/asar/package.json" "$BUNDLE" "$R" <<'PY' || exit 1
import json, sys
from pathlib import Path
paquet, bundle, ressources = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '3.9.0':
    problemes.append('package.json en version %s : une base 3.9.0 est requise'
                     % version)
texte = bundle.read_text(encoding='utf8')
# Marqueurs 3.6.0, 3.7.0 et 3.8.0 : tous les correctifs précédents doivent déjà
# s'y trouver, puisque la 4.0.0 s'applique PAR-DESSUS eux.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'className:"git-identity-row"',
                'ps-3.7.0-interface', '"moteur local"',
                'ps-3.8.0-interface', 'malbolge:"Malbolge"']:
    if attendu not in texte:
        problemes.append('bundle sans le marqueur %s' % attendu)
# Absence des nouveautés 4.0.0 : leur présence signifierait une base déjà
# convertie, et le script rejouerait des substitutions sur un bundle patché.
for deja in ['ps-4.0.0-interface', 'Vh({id:"asm"', 'className:"ps-data-host"',
             'className:"ps-devweb-host"', 'className:"ps-re-host"']:
    if deja in texte:
        problemes.append('bundle portant déjà la nouveauté 4.0.0 %s : base déjà '
                         'convertie' % deja)
serveur = ressources / 'server.py'
if not serveur.is_file():
    problemes.append('resources/server.py absent de la base')
else:
    contenu = serveur.read_text(encoding='utf8')
    if 'import bac_a_sable' not in contenu:
        problemes.append('server.py sans les routes 3.7.0 : base antérieure à 3.7.0')
    if 'capacites_aide' not in contenu:
        problemes.append('server.py sans la route d’aide 3.8.0 : '
                         'base antérieure à 3.8.0')
    for deja in ('import retro', 'import devweb', 'import navigateur_etat',
                 "'/api/re'", "'/api/devweb'", "'/api/navigateur'"):
        if deja in contenu:
            problemes.append('server.py portant déjà la route 4.0.0 %s : base '
                             'déjà convertie' % deja)
# L'assistant de la base DOIT être un 3.9.0 : le filtre de demande et l'espace
# de travail par projet sont les nouveautés de la 3.9.0, et leur absence
# trahirait une base antérieure.
ia_base = ressources / 'assistant-ia'
if not ia_base.is_dir():
    problemes.append('resources/assistant-ia absent de la base')
else:
    for attendu in ('optimiseur_prompt.py', 'espace_travail.py'):
        if not (ia_base / attendu).exists():
            problemes.append('assistant-ia sans %s : base antérieure à 3.9.0'
                             % attendu)
    serveur_ia = ia_base / 'server.py'
    if not serveur_ia.is_file():
        problemes.append('assistant-ia/server.py absent de la base')
    elif 'Route("/api/espace' not in serveur_ia.read_text(encoding='utf8'):
        problemes.append('assistant-ia/server.py sans les routes 3.9.0 de '
                         'l’espace de travail : base antérieure à 3.9.0')
index = ressources / 'static' / 'index.html'
if not index.is_file():
    problemes.append('resources/static/index.html absent de la base')
else:
    contenu = index.read_text(encoding='utf8')
    if 'aide-exemples.js' not in contenu:
        problemes.append('index.html sans aide-exemples.js : base antérieure à 3.7.0')
    if 'aide-esoteriques.js' not in contenu:
        problemes.append('index.html sans aide-esoteriques.js : '
                         'base antérieure à 3.8.0')
    if 'aide-index.js' not in contenu:
        problemes.append('index.html sans aide-index.js : '
                         'base antérieure à 3.8.0')
    for deja in ('aide-assembleur.js', 'data-studio.js', 'navigateur-studio.js',
                 'devweb-studio.js', 're-studio.js'):
        if deja in contenu:
            problemes.append('index.html portant déjà %s : base déjà convertie '
                             'en 4.0.0' % deja)
if problemes:
    deja = any('déjà' in p for p in problemes)
    print('   ECHEC — la base n’est pas une Pascal Studio 3.9.0 :')
    for p in problemes:
        print('     - ' + p)
    if deja:
        print('   Cette base porte DÉJÀ les nouveautés 4.0.0 : c’est sans doute le '
              'résultat')
        print('   d’un passage précédent de ce script. Relancez-le sur votre '
              'AppImage 3.9.0')
        print('   d’origine, ou utilisez directement l’AppImage déjà produite.')
    else:
        print('   Construisez d’abord la 3.9.0 : sh reconditionner-3.9.0.sh '
              'AppImage-3.8.0 Pascal-Studio-3.9.0-x86_64.AppImage')
    sys.exit(1)
print('   base 3.9.0 reconnue par son contenu (version, bundle, server.py, '
      'assistant-ia, index.html) et sans aucune nouveauté 4.0.0')
PY

echo "== Version et index.html =="
python3 - "$TMP/asar/package.json" "$R/static/index.html" <<'PY'
import json,re,sys
p,h=sys.argv[1:]
d=json.load(open(p,encoding='utf8'))
assert d['version']=='3.9.0', 'version de base inattendue : '+str(d['version'])
d['version']='4.0.0'
open(p,'w',encoding='utf8').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
s=open(h,encoding='utf8').read()
# Les injections 3.6.0, 3.7.0 et 3.8.0 doivent déjà être là : la 4.0.0 les
# revérifie, puis ajoute les SIENNES par inserer-assets-4.0.0.py (plus bas).
for attendu in ['nouveau-fichier.js','logos-langages.css','aide-swift-kotlin.js',
                'aide-exemples.js','aide-exemples.css','aide-esoteriques.js',
                'aide-index.css','aide-index.js']:
    assert attendu in s, 'index.html d’une base 3.8.0 attendu, %s manquant' % attendu
# 1. Le catalogue d’aide des dix langages ésotériques DOIT être chargé AVANT le
#    bundle, et comme script CLASSIQUE : le bundle lit window.PS_LANG_HELP au
#    moment de son évaluation. Un « defer » ici ferait disparaître les dix
#    langages de l’aide sans aucune erreur nulle part.
ancre='<script src="/assets/aide-latex.js"></script>'
assert s.count(ancre)==1, 'ancre aide-latex.js introuvable ou ambiguë'
if 'aide-esoteriques.js' not in s:
    s=s.replace(ancre,ancre+'<script src="/assets/aide-esoteriques.js"></script>',1)
# 2. L’index d’aide et sa feuille de style décorent un DOM déjà monté : fin de
#    <head>, donc après le bundle, en « defer ».
fin='</head>'; assert s.count(fin)==1, 'balise </head> ambiguë'
ajout=('<link rel="stylesheet" href="/assets/aide-index.css">'
       '<script defer src="/assets/aide-index.js"></script>')
if 'aide-index.js' not in s: s=s.replace(fin,ajout+fin)
# 3. Contrôle d’ordre : catalogue avant le bundle, index après.
m=re.search(r'/assets/index-[A-Za-z0-9_-]+\.js',s)
assert m, 'script du bundle introuvable dans index.html'
assert s.index('aide-esoteriques.js')<m.start()<s.index('aide-index.js'), \
    'ordre de chargement de l’aide incorrect'
assert 'defer src="/assets/aide-esoteriques.js"' not in s, \
    'aide-esoteriques.js ne doit pas être chargé en « defer »'
open(h,'w',encoding='utf8').write(s)
print('   version 4.0.0 ; les 8 entrées d’aide de la base sont présentes et '
      'leur ordre est intact')
PY

echo "== Correctifs du bundle compilé =="
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
# Le correctif IA de la 3.4.0 d'abord : les ancrages 3.6.0 ont été relevés sur
# un bundle qui le porte déjà.
if ! grep -q 'className:"ps-ai-host"' "$BUNDLE"; then
  python3 "$SRC/patch_ia_3.4.py" "$BUNDLE"; echo "   patch_ia_3.4 appliqué"
fi
# Les correctifs 3.6.0 sont déjà appliqués dans la base ; on ne les rejoue que
# s'ils manquent, puis on vérifie dans les deux cas. Idempotence garantie.
for nom in patch_langages_3.6 patch_identite_git_3.6; do
  if ! python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null 2>&1; then
    python3 "$SRC/$nom.py" "$BUNDLE"; echo "   $nom appliqué"
  else
    echo "   $nom déjà présent"
  fi
  python3 "$SRC/$nom.py" --verifier "$BUNDLE"
done
# Correctifs 3.7.0 (déjà appliqués dans la base) puis 3.8.0 : complétion pour 39
# langages, débogage pour 37, libellés et badges des dix langages ésotériques.
for nom in patch_interface_3.7 patch_interface_3.8; do
  if ! python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null 2>&1; then
    python3 "$SRC/$nom.py" "$BUNDLE"; echo "   $nom appliqué"
  else
    echo "   $nom déjà présent"
  fi
  python3 "$SRC/$nom.py" --verifier "$BUNDLE" >/dev/null || exit 1
done

# Correctif 4.0.0 : assembleur, éditeur de données en onglet, panneaux dev web
# et rétro-ingénierie. Le vérificateur rend TROIS états — 0 conforme,
# 1 patchable, 2 problème — et c'est ce qui permet de décider à bon escient :
# un « tout va bien » rendu sur un bundle vierge ferait sauter l'application et
# livrerait une interface sans aucune des nouveautés, sans erreur nulle part.
code=0
python3 "$SRC/patch_interface_4.0.py" --verifier "$BUNDLE" >/dev/null 2>&1 || code=$?
case $code in
  0) echo "   patch_interface_4.0 déjà appliqué" ;;
  1) python3 "$SRC/patch_interface_4.0.py" "$BUNDLE" || exit 1
     echo "   patch_interface_4.0 appliqué (16 substitutions)" ;;
  *) echo "patch_interface_4.0 : le bundle de la base n’est pas patchable (code $code)." >&2
     python3 "$SRC/patch_interface_4.0.py" --verifier "$BUNDLE" >&2 || true
     exit 1 ;;
esac
python3 "$SRC/patch_interface_4.0.py" --verifier "$BUNDLE" >/dev/null || exit 1
# Le tokenizer importé par le bundle doit exister à côté de lui : sans ce
# fichier, Monaco retombe sur une configuration par défaut, sans erreur nulle
# part. Il est copié plus bas, mais le bundle le référence déjà.
grep -q 'import("./asm-studio.js")' "$BUNDLE" || {
  echo 'Le bundle référence asm-studio.js sans que le correctif 4.0.0 soit en place.' >&2; exit 1; }

echo "== Correctifs Electron =="
if ! grep -q 'assistant-ia.*lanceur.py' "$TMP/asar/desktop/main.cjs"; then
  python3 "$SRC/patch_desktop_ia.py" "$TMP/asar/desktop/main.cjs"; echo "   patch_desktop_ia appliqué"
fi
python3 "$SRC/patch_desktop_langages.py" "$TMP/asar/desktop/main.cjs"

# 4.0.0 : le preload est REMPLACÉ (il porte les trois relais du navigateur :
# popups, téléchargements et permissions, chacun rendant une fonction de
# désinscription pour qu'un panneau fermé n'accumule pas d'écouteurs), et
# main.cjs reçoit <webview> avec ses gardes. Sans webviewTag:true la balise
# <webview> est INERTE et le panneau navigateur reste désespérément blanc, sans
# erreur nulle part : c'est précisément ce qui rend ce correctif dangereux à
# oublier.
cp "$SRC/desktop-preload.cjs" "$TMP/asar/desktop/preload.cjs"
echo "   preload.cjs remplacé (relais du navigateur intégré)"
# Le correctif est idempotent substitution par substitution : on l'applique SANS
# consulter d'abord le vérificateur, puis on vérifie. Décider d'appliquer ou non
# d'après un code de retour est fragile — un vérificateur qui rend 0 sur un
# fichier NON corrigé (parce que les ancres y sont déjà, ce qui était le cas ici
# avant correction) fait sauter le correctif en silence, et le panneau
# navigateur reste blanc sans erreur nulle part. Appliquer puis vérifier ne
# dépend d'aucun état initial.
python3 "$SRC/patch_desktop_navigateur.py" "$TMP/asar/desktop/main.cjs" || exit 1
python3 "$SRC/patch_desktop_navigateur.py" --verifier \
        "$TMP/asar/desktop/main.cjs" || exit 1
# node n'est pas un prérequis de la construction : s'il est là, on vérifie la
# syntaxe ; sinon le vérificateur du correctif suffit.
if command -v node >/dev/null 2>&1; then
  node --check "$TMP/asar/desktop/main.cjs" || {
    echo 'desktop/main.cjs invalide après correctif.' >&2; exit 1; }
  node --check "$TMP/asar/desktop/preload.cjs" || {
    echo 'desktop/preload.cjs invalide.' >&2; exit 1; }
  echo "   main.cjs et preload.cjs : syntaxe vérifiée par node"
fi

echo "== Copie des fichiers =="
for m in $MODULES_38; do cp "$SRC/$m" "$R/"; done
cp "$SRC/polyglot.py" "$SRC/swift_kotlin.py" "$SRC/account_store.py" \
   "$SRC/oauth_accounts.py" "$SRC/git_identity.py" "$SRC/git_manager.py" \
   "$SRC/remote_vault.py" "$R/"
cp "$SRC/monaco-basic/swift-studio.js" "$SRC/monaco-basic/kotlin-studio.js" "$A/"
mkdir -p "$A/logos-langages"
cp "$SRC"/logos-langages/*.svg "$SRC/logos-langages/LICENSE-devicon.txt" "$A/logos-langages/"
cp "$SRC/aide-swift-kotlin.js" "$A/"
cp "$SRC/logos-langages.css" "$SRC/nouveau-fichier.css" "$SRC/nouveau-fichier.js" \
   "$SRC/identite-git.css" "$SRC/assistant-ia-host.js" "$SRC/assistant-ia-host.css" \
   "$SRC/aide-exemples.js" "$SRC/aide-exemples.css" "$A/"
cp "$SRC/aide-esoteriques.js" "$SRC/aide-index.js" "$SRC/aide-index.css" "$A/"
# 4.0.0 : modules Python dans resources/, assets d'interface dans
# resources/static/assets/. asm-studio.js est copié depuis monaco-additions/ :
# le bundle le charge par import(), il n'a donc pas de balise dans index.html.
for m in $MODULES_40; do cp "$SRC/$m" "$R/"; done
for a in $ASSETS_40; do cp "$SRC/$a" "$A/"; done
cp "$SRC/monaco-additions/asm-studio.js" "$A/"
# Les cinq injections 4.0.0 dans l'index.html de l'IMAGE : le catalogue d'aide
# de l'assembleur avant le bundle, et les quatre paires de panneaux après, la
# feuille de style avant le script. Un seul script connaît les cinq et les
# vérifie ensemble — c'est ce qui rend impossible l'oubli d'une paire, comme
# celle du panneau de rétro-ingénierie l'a été pendant le développement.
# Placé APRÈS la copie des assets : l'inséreur vérifie que chaque fichier
# référencé existe vraiment dans le dossier des assets.
python3 "$SRC/inserer-assets-4.0.0.py" "$R/static/index.html" || exit 1
echo "   index.html : cinq injections 4.0.0 en place, ordonnées, assets présents"

echo "   backend (13 modules 3.x + $(echo $MODULES_40 | wc -w) modules 4.0.0) " \
     "et interface (37 fichiers 3.x + $(echo $ASSETS_40 | wc -w) assets " \
     "4.0.0 + asm-studio.js) copiés"

# L'archive source ne duplique PAS assistant-ia/vendor-ddgs (recherche web) :
# celle de la base est mise de côté puis remise, pour ne jamais la perdre.
if [ ! -e "$SRC/assistant-ia/vendor-ddgs" ] && [ -e "$R/assistant-ia/vendor-ddgs" ]; then
  mv "$R/assistant-ia/vendor-ddgs" "$TMP/vendor-ddgs-conserve"
  echo "   vendor-ddgs absent des sources : celui de la base est conservé"
  DDGS_CONSERVE=1
else
  DDGS_CONSERVE=0
fi
rm -rf "$R/assistant-ia"
cp -a "$SRC/assistant-ia" "$R/assistant-ia"
if [ "$DDGS_CONSERVE" = 1 ]; then
  mv "$TMP/vendor-ddgs-conserve" "$R/assistant-ia/vendor-ddgs"
fi

find "$TMP/squashfs-root" -type d -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null || true
find "$TMP/squashfs-root" -type f -name '*.pyc' -delete 2>/dev/null || true

echo "== Reconditionnement =="
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp xz -b 128K -processors 2 >/dev/null
head -c "$DECALAGE" "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
echo "   écrit : $OUT"

echo "== Vérification de l'AppImage produite =="
VERIF="$TMP/verif"; mkdir -p "$VERIF"
(cd "$VERIF" && "$OUT" --appimage-extract >/dev/null)
# package.json est dans l'asar refermé : on l'extrait pour lire la version.
(cd "$VERIF" && asar extract-file "$VERIF/squashfs-root/resources/app.asar" package.json)
python3 - "$VERIF/squashfs-root" "$VERIF/package.json" <<'PY'
import ast, json, re, sys
from pathlib import Path
r = Path(sys.argv[1]); paquet = Path(sys.argv[2])
a = r / 'resources' / 'static' / 'assets'
problemes = []
version = json.load(open(paquet, encoding='utf8')).get('version')
if version != '4.0.0':
    problemes.append('package.json en version %s au lieu de 4.0.0' % version)
s = (r / 'resources' / 'static' / 'index.html').read_text(encoding='utf8')
for attendu in ['logos-langages.css', 'nouveau-fichier.js', 'identite-git.css',
                'aide-swift-kotlin.js', 'aide-exemples.css', 'aide-exemples.js',
                'aide-esoteriques.js', 'aide-index.css', 'aide-index.js']:
    if attendu not in s:
        problemes.append('index.html sans ' + attendu)
# Ordre de chargement : le catalogue d’aide ésotérique doit précéder le bundle,
# qui construit sa base d’aide au moment de son évaluation.
m = re.search(r'/assets/index-[A-Za-z0-9_-]+\.js', s)
if not m:
    problemes.append('index.html sans le script du bundle')
elif not (s.index('aide-esoteriques.js') < m.start() < s.index('aide-index.js')):
    problemes.append('ordre de chargement de l’aide incorrect : les dix langages '
                     'n’auraient aucune aide')
if 'defer src="/assets/aide-esoteriques.js"' in s:
    problemes.append('aide-esoteriques.js chargé en « defer » : il serait évalué '
                     'après le bundle')
# Même règle que pour $BUNDLE : le nom du bundle n'est jamais figé.
candidats = sorted(a.glob('index-*.js'))
if len(candidats) != 1:
    problemes.append('static/assets contient %d bundle(s) index-*.js, 1 attendu'
                     % len(candidats))
    bundle = ''
else:
    bundle = candidats[0].read_text(encoding='utf8')
# Marqueurs 3.6.0 reconduits.
for attendu in ['Vh({id:"swift"', 'Vh({id:"kotlin"', 'window.PSNewFileDialog(',
                'className:"git-identity-row"', 'swift:["Sw","Swift"]']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.6.0 ' + attendu)
# Marqueurs 3.7.0 reconduits.
for attendu in ['ps-3.7.0-interface', 'for(const t of["pascal","c","cpp","csharp"',
                '"moteur local"']:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.7.0 ' + attendu)
# Marqueurs 3.8.0 : libellés, badge, résolveur d’extension et listes allongées.
# La 4.0.0 ALLONGE cette liste avec « asm ». Le marqueur 3.8.0 ne peut donc
# plus se terminer par le crochet fermant : on vérifie la queue 3.8.0 SANS
# crochet, puis que CHAQUE occurrence a bien reçu « asm ». Un allongement
# partiel laisserait l'assembleur sans complétion à l'un des deux endroits où
# la liste sert, et rien ne le signalerait.
QUEUE_38 = ('"plaintext","brainfuck","whitespace","piet","lolcode","arnoldc",'
            '"chef","shakespeare","intercal","fractran","malbolge"')
QUEUE_40 = QUEUE_38 + ',"asm"'
# La liste de l'aperçu web est vérifiée dans son contexte : sans « piet », le
# bouton d'aperçu enverrait un programme Piet vers la compilation.
APERCUS_WEB = '["html","css","php","piet"].includes(vr('
for attendu in ['ps-3.8.0-interface', 'malbolge:"Malbolge"',
                'malbolge:["MAL","Malbolge"]', '/\\.(bf|b)$/i', QUEUE_38, QUEUE_40,
                APERCUS_WEB]:
    if attendu not in bundle:
        problemes.append('bundle sans le marqueur 3.8.0 ' + attendu)
if bundle.count(QUEUE_38) != bundle.count(QUEUE_40):
    problemes.append('liste des langages allongée de « asm » dans %d endroit(s) '
                     'sur %d : l’assembleur n’aurait pas sa complétion partout'
                     % (bundle.count(QUEUE_40), bundle.count(QUEUE_38)))
# Les dix langages doivent apparaître au moins une fois chacun dans le bundle.
for cle, libelle in [('brainfuck', 'Brainfuck'), ('whitespace', 'Whitespace'),
                     ('piet', 'Piet'), ('lolcode', 'LOLCODE'),
                     ('arnoldc', 'ArnoldC'), ('chef', 'Chef'),
                     ('shakespeare', 'Shakespeare'), ('intercal', 'INTERCAL'),
                     ('fractran', 'FRACTRAN'), ('malbolge', 'Malbolge')]:
    if '"%s"' % cle not in bundle:
        problemes.append('bundle sans l’identifiant ' + cle)
    if '%s:"%s"' % (cle, libelle) not in bundle:
        problemes.append('bundle sans le libellé %s:%s' % (cle, libelle))
# Les listes de la 3.7.0 (29 langages en complétion, 27 en débogage) doivent
# avoir été remplacées, pas seulement complétées ailleurs.
for ancienne, nature in [('"ocaml","json","xml","plaintext"]',
                          'liste de complétion 3.7.0 (29 langages)'),
                         ('"basic","fortran","lua","ocaml","xml"]',
                          'liste de débogage 3.7.0 (27 langages)'),
                         ('["html","css","php"].includes(vr(',
                          'liste de l’aperçu web 3.7.0 (sans Piet)')]:
    if ancienne in bundle:
        problemes.append('bundle portant encore la ' + nature)
# L'ancienne liste de débogage à 10 langages doit avoir disparu.
if '["pascal","c","cpp","python","javascript","php","rust","go","ruby","fortran"]' in bundle:
    problemes.append('bundle portant encore la liste de débogage 3.6.0 (10 langages)')
serveur = (r / 'resources' / 'server.py').read_text(encoding='utf8')
# server.py importe les moteurs 3.7.0 sur UNE seule ligne groupée : on cherche
# donc les noms de modules, pas la forme « import X » prise isolément.
for attendu in ['import bac_a_sable', 'debogueur_universel', 'inspecteur_visuel',
                'moteur_completion', 'analyser_en_direct',
                '/api/aide/essayer', '/api/debug/capacites', '/api/completion/etat',
                '/api/inspecteur',
                'capacites_aide', '/api/aide/capacites', 'contenu_binaire',
                'from debug_mux import DebuggerMux, esoterique']:
    if attendu not in serveur:
        problemes.append('server.py sans ' + attendu)
if 'Analyse en direct disponible pour Pascal, C et C++.' in serveur:
    problemes.append('server.py portant encore l’ancien message d’analyse limitée')
for f in ['langages.py', 'verificateurs_statiques.py', 'lsp_client.py',
          'bibliotheques_completion.py', 'moteur_completion.py',
          'debogueur_universel.py', 'inspecteur_visuel.py', 'bac_a_sable.py',
          'debug_mux.py', 'web_preview.py', 'swift_kotlin.py',
          'account_store.py', 'git_identity.py',
          'langages_esoteriques.py', 'capacites_aide.py', 'polyglot.py']:
    if not (r / 'resources' / f).is_file():
        problemes.append('module manquant : ' + f)
for f in ['swift-studio.js', 'kotlin-studio.js', 'nouveau-fichier.js',
          'logos-langages.css', 'nouveau-fichier.css', 'identite-git.css',
          'aide-swift-kotlin.js', 'aide-exemples.js', 'aide-exemples.css',
          'aide-esoteriques.js', 'aide-index.js', 'aide-index.css',
          'logos-langages/swift.svg', 'logos-langages/kotlin.svg',
          'logos-langages/LICENSE-devicon.txt']:
    if not (a / f).is_file():
        problemes.append('asset manquant : ' + f)
# Garde-fous anti-cascade de l’index d’aide. Sans eux, ouvrir l’aide reconstruit
# l’index sans fin : l’observateur de mutations voit nos propres écritures et
# relance un balayage, le rendu s’emballe et l’application tombe. Ils sont
# vérifiés ici pour qu’un aide-index.js antérieur au correctif ne puisse plus
# jamais être livré.
index_aide = a / 'aide-index.js'
if index_aide.is_file():
    texte_index = index_aide.read_text(encoding='utf8')
    for attendu in ['signatureDe', 'observateur.takeRecords()',
                    'if(enCours) return', 'DELAI_REESSAI', 'maj(true)']:
        if attendu not in texte_index:
            problemes.append('aide-index.js sans le garde-fou ' + attendu
                             + ' : l’ouverture de l’aide ferait planter '
                               'l’application')
logo = r / 'resources' / 'assistant-ia' / 'static' / 'brand' / 'logo-ia.svg'
if not logo.is_file():
    problemes.append('logo de l’IA manquant : assistant-ia/static/brand/logo-ia.svg')
else:
    contenu = logo.read_text(encoding='utf8')
    if 'viewBox' not in contenu:
        problemes.append('logo-ia.svg sans viewBox')
ia_inst = r / 'resources' / 'assistant-ia'
index_ia = ia_inst / 'static' / 'index.html'
if not index_ia.is_file():
    problemes.append('assistant-ia/static/index.html manquant')
else:
    contenu = index_ia.read_text(encoding='utf8')
    if '.msg.assistant::before' not in contenu or 'logo-ia.svg' not in contenu:
        problemes.append('interface de l’assistant sans l’avatar du logo IA')
    # Câblage 3.9.0 de la page : bouton et boîte de dialogue de l'espace,
    # réglages du filtre, événement « optimise », comparateur, capture.
    for attendu in ('id="espbtn"', 'id="espdlg"', 'id="espproj"', 'id="espfile"',
                    'id="prompt"', 'id="prompt_model"',
                    "ev.type === 'optimise'", 'function voirPrompt',
                    'function espaceCapturer', "'prompt', 'prompt_model'",
                    'demande optimisée · voir'):
        if attendu not in contenu:
            problemes.append('interface de l’assistant sans %s' % attendu)
    bouton_prompt = '<div class="promptopt"><button data-a="prompt"'
    if contenu.count(bouton_prompt) != 2:
        problemes.append('bouton du prompt optimisé présent %d fois au lieu de 2 '
                         ': il manquerait au flux ou au rechargement'
                         % contenu.count(bouton_prompt))
    if 'demande optimisée · voir' not in contenu:
        problemes.append('interface de l’assistant sans l’explication du filtre')
for nom in ('optimiseur_prompt.py', 'espace_travail.py'):
    if not (ia_inst / nom).is_file():
        problemes.append('assistant-ia/%s manquant dans l’AppImage' % nom)
if not (ia_inst / 'prompts' / 'optimiseur.md').is_file():
    problemes.append('assistant-ia/prompts/optimiseur.md manquant : la consigne '
                     'du filtre ne serait plus modifiable')
srv_inst = ia_inst / 'server.py'
if not srv_inst.is_file():
    problemes.append('assistant-ia/server.py manquant dans l’AppImage')
else:
    texte_srv = srv_inst.read_text(encoding='utf8')
    try:
        ast.parse(texte_srv)
    except SyntaxError as erreur:
        problemes.append('assistant-ia/server.py installé invalide : %s' % erreur)
    for attendu in ('import optimiseur_prompt', 'import espace_travail',
                    'Route("/api/espace"', 'Route("/api/espace/depot"',
                    'Route("/api/espace/fichier"', 'Route("/api/espace/apercu"',
                    'Route("/api/espace/renommer"', 'Route("/api/espace/supprimer"',
                    'Route("/api/espace/dossier"', 'Route("/api/espace/enregistrer"',
                    'optimiser_en_arriere_plan', '"type": "optimise"',
                    'espace_capturer', 'prompt_model', 'X-PS-Espace'):
        if attendu not in texte_srv:
            problemes.append('assistant-ia/server.py installé sans %s' % attendu)
# ---- nouveautés 4.0.0, vérifiées sur l'AppImage RÉEXTRAITE ----------------
# Vérifier les sources ne prouve rien : c'est le contenu de l’image produite qui
# est livré. Le bundle doit porter les 16 substitutions, index.html les cinq
# injections, server.py les routes, et les modules doivent passer leur
# autocontrôle DEPUIS L'IMAGE.
for attendu in ['ps-4.0.0-interface', 'Vh({id:"asm"', 'className:"ps-data-host"',
                'className:"ps-devweb-host"', 'className:"ps-re-host"',
                'y==="devweb"?"DEV WEB"', 'RÉTRO-INGÉNIERIE',
                'import("./asm-studio.js")']:
    if attendu not in bundle:
        problemes.append('bundle de l’image sans la nouveauté 4.0.0 ' + attendu)
# Les deux nouveaux titres sont PRÉFIXÉS à l'ancienne chaîne de ternaires, qui
# est CONSERVÉE : vérifier l'absence de l'ancienne forme serait donc faux, et
# annoncerait à tort un bundle non corrigé. Ce qu'il faut vérifier, c'est la
# chaîne COMPLÈTE et son ORDRE — rétro-ingénierie, puis dev web, puis les
# anciens panneaux. Un ordre inversé afficherait « PROJET » au-dessus du panneau
# de rétro-ingénierie, et un titre manquant laisserait un panneau sans nom.
CHAINE_ENTETES = ('y==="re"?"RÉTRO-INGÉNIERIE":y==="devweb"?"DEV WEB":'
                  'y==="project"?"PROJET":y==="git"?"GESTION DE VERSION"')
if CHAINE_ENTETES not in bundle:
    problemes.append('bundle de l’image sans la chaîne d’en-têtes latéraux 4.0.0 '
                     'dans l’ordre (rétro-ingénierie, dev web, puis les anciens) : '
                     'les deux nouveaux panneaux n’auraient pas de titre')
# Même exigence pour les hôtes : le bundle délègue le rendu en créant un élément
# VIDE observé, et c'est l'ordre des branches qui décide de l'élément créé. Deux
# hôtes présents mais dans le mauvais ordre rendraient le mauvais panneau.
CHAINE_HOTES = ('y==="re"?T.createElement("div",{className:"ps-re-host"}):'
                'y==="devweb"?T.createElement("div",{className:"ps-devweb-host"})')
if CHAINE_HOTES not in bundle:
    problemes.append('bundle de l’image sans la chaîne d’hôtes 4.0.0 '
                     '(ps-re-host puis ps-devweb-host) : les panneaux ne '
                     'seraient pas rendus')
if not (a / 'asm-studio.js').is_file():
    problemes.append('asm-studio.js absent des assets de l’image : le bundle '
                     'l’importe et Monaco retomberait sur une configuration par '
                     'défaut, sans erreur')
elif '/assets/asm-studio.js"' in s:
    problemes.append('asm-studio.js référencé dans index.html : le bundle le '
                     'charge déjà par import(), il serait chargé deux fois')
for fichier in ['data-studio.js', 'data-studio.css', 'navigateur-studio.js',
                'navigateur-studio.css', 'devweb-studio.js', 'devweb-studio.css',
                're-studio.js', 're-studio.css', 'aide-assembleur.js']:
    if not (a / fichier).is_file():
        problemes.append('%s absent des assets de l’image' % fichier)
# Les assets 4.0.0 doivent être RÉFÉRENCÉS dans index.html, pas seulement
# présents sur le disque : un panneau dont la feuille et le script ne sont pas
# chargés laisse son hôte vide, sans erreur nulle part. C'est précisément ainsi
# que le panneau de rétro-ingénierie a été livré mort pendant le développement —
# tous les bancs passaient, parce qu'ils chargeaient le fichier directement.
for fichier in ['data-studio.css', 'data-studio.js', 'navigateur-studio.css',
                'navigateur-studio.js', 'devweb-studio.css', 'devweb-studio.js',
                're-studio.css', 're-studio.js', 'aide-assembleur.js']:
    if '/assets/%s' % fichier not in s:
        problemes.append('index.html de l’image sans la référence à %s : le '
                         'panneau correspondant resterait vide' % fichier)
srv_main = r / 'resources' / 'server.py'
if not srv_main.is_file():
    problemes.append('resources/server.py absent de l’image produite')
else:
    texte_srv_main = srv_main.read_text(encoding='utf8')
    try:
        ast.parse(texte_srv_main)
    except SyntaxError as erreur:
        problemes.append('server.py installé invalide : %s' % erreur)
    for attendu in ['import retro', 'import devweb', 'import navigateur_etat',
                    "'/api/re'", "'/api/devweb'", "'/api/navigateur'"]:
        if attendu not in texte_srv_main:
            problemes.append('server.py installé sans %s' % attendu)
for module in ['assembleur.py', 'donnees_etendues.py', 'database_tools.py',
               'navigateur_etat.py', 'devweb.py', 'retro.py',
               'retro_detection.py', 'retro_binaires.py', 'retro_ghidra.py',
               'retro_fiches.py']:
    if not (r / 'resources' / module).is_file():
        problemes.append('%s absent de l’image produite' % module)
nb_logos = len(list((a / 'logos-langages').glob('*.svg')))
if nb_logos != 22:
    problemes.append('%d logos au lieu de 22' % nb_logos)
if problemes:
    print('   ECHEC :')
    for p in problemes: print('     - ' + p)
    sys.exit(1)
print('   image vérifiée : bundle (marqueurs 3.6.0 à 4.0.0), index.html et '
      'ses références, %d logos, logo IA, assistant 3.9.0 (filtre + '
      'espace, 8 routes), routes et modules 4.0.0 (assembleur, données, '
      'navigateur, dev web, rétro-ingénierie)' % nb_logos)
PY
echo
echo "== Autocontrôles rejoués sur l'AppImage produite =="
# Rejouer les autocontrôles DEPUIS L'IMAGE et non depuis les sources : c'est le
# contenu livré qui doit fonctionner. Un module copié mais incapable de
# s'importer dans l'image (dépendance manquante, chemin faux) est détecté ici,
# pas au premier clic de l'utilisateur.
IMG="$VERIF/squashfs-root/resources"
for m in assembleur donnees_etendues devweb devweb_journal devweb_analyse \
         devweb_references devweb_audits devweb_modeles devweb_client \
         retro_detection retro_binaires retro_ghidra retro_fiches retro; do
  (cd "$IMG" && PYTHONPATH="$IMG" python3 "$m.py" >/dev/null 2>&1) || {
    echo "AUTOCONTRÔLE EN ÉCHEC DANS L'IMAGE : $m.py" >&2; exit 1; }
done
echo "   14 autocontrôles rejoués depuis l'image"
# Les cinq injections et le bundle, contrôlés sur l'image par leurs propres
# vérificateurs : un seul endroit dit vrai, et c'est le fichier livré.
python3 "$SRC/inserer-assets-4.0.0.py" "$IMG/static/index.html" --verifier \
        >/dev/null || { echo "index.html de l’image : injections 4.0.0 incomplètes." >&2; exit 1; }
# Le bundle est cherché par GLOB et jamais par son nom de build : une empreinte
# figée (index-XXXXXXXX.js) casserait à la première recompilation du frontend,
# et l'échec serait muet — le vérificateur ne serait simplement jamais joué.
nombre_bundles=$(ls "$IMG"/static/assets/index-*.js 2>/dev/null | wc -l)
[ "$nombre_bundles" -eq 1 ] || {
  echo "bundle index-*.js : $nombre_bundles trouvé(s) dans l'image, 1 attendu." >&2; exit 1; }
python3 "$SRC/patch_interface_4.0.py" --verifier \
        "$(ls "$IMG"/static/assets/index-*.js)" >/dev/null \
        || { echo "bundle de l’image : substitutions 4.0.0 incomplètes." >&2; exit 1; }
# L'asar de l’image est extrait EN ENTIER : extract-file avec un chemin de
# dossier (desktop/main.cjs) n'a pas un comportement garanti d'une version
# d'asar à l'autre sur le nom du fichier écrit, et un faux chemin produirait un
# « fichier manquant » trompeur au lieu de la vraie vérification.
asar extract "$IMG/app.asar" "$VERIF/app-image" >/dev/null
MAIN_IMG="$VERIF/app-image/desktop/main.cjs"
PRELOAD_IMG="$VERIF/app-image/desktop/preload.cjs"
for f in "$MAIN_IMG" "$PRELOAD_IMG"; do
  [ -f "$f" ] || { echo "desktop/$(basename "$f") absent de l'asar de l’image." >&2; exit 1; }
done
python3 "$SRC/patch_desktop_navigateur.py" --verifier "$MAIN_IMG" \
        || { echo "main.cjs de l’image : navigateur intégré absent." >&2; exit 1; }
# Les trois relais du preload : chacun rend une fonction de désinscription, pour
# qu'un panneau fermé n'accumule pas d'écouteurs. Un relais manquant laisse un
# panneau navigateur muet sur les popups, les téléchargements ou les permissions
# — sans erreur nulle part.
for attendu in onNavigateurPopup onNavigateurDownload onNavigateurPermission; do
  grep -q "$attendu" "$PRELOAD_IMG" || {
    echo "preload.cjs de l’image sans le relais $attendu." >&2; exit 1; }
done
if command -v node >/dev/null 2>&1; then
  node --check "$MAIN_IMG" || { echo "main.cjs de l’image invalide." >&2; exit 1; }
  node --check "$PRELOAD_IMG" || { echo "preload.cjs de l’image invalide." >&2; exit 1; }
fi
echo "   image vérifiée : index.html, bundle, main.cjs, preload.cjs"

echo "Pascal Studio 4.0.0 prêt : $OUT"
echo "Nouveautés :"
echo "  - L'assembleur est un langage à part entière : coloration, complétion,"
echo "    aide (registres, conventions d'appel, directives GAS et NASM, familles"
echo "    de mnémoniques, AT&T contre Intel), analyse statique, assemblage et"
echo "    exécution via gcc/as/ld, et débogage quand gdb est installé."
echo "  - Les fichiers de base de données s'ouvrent en ONGLET et s'éditent :"
echo "    tables, colonnes, lignes et cellules créées, modifiées et supprimées"
echo "    depuis la grille, les commandes SQL jouées en arrière-plan, un champ"
echo "    pour saisir une requête et un autre pour en voir le résultat."
echo "    Formats : sqlite/db/db3, csv/tsv, json, sql, xlsx et ods (feuilles"
echo "    comme tables), xml, et reconnaissance par signature. Un fichier non"
echo "    reconnu s'ouvre en texte ET LE DIT au lieu d'échouer."
echo "    L'enregistrement est RÉEL, y compris pour les miroirs xlsx, ods"
echo "    et xml : une table non mentionnée survit, ce qui est refusé est"
echo "    annoncé à l'ouverture (formules d'un tableur, nouvelle table en"
echo "    XML) et rien n'est perdu en silence."
echo "  - Un panneau NAVIGATEUR intégré affiche de vraies pages web. Ce n'est"
echo "    pas Firefox, Chrome ou Edge mis dans une fenêtre : Pascal Studio est"
echo "    déjà une application Electron, donc le moteur Chromium est là ; ce"
echo "    qui manquait était le droit de s'en servir, avec des gardes sur"
echo "    l'invité (popups, navigation, permissions, preload)."
echo "  - Un panneau DEV WEB à gauche : aperçu, journal, audits (accessibilité,"
echo "    en-têtes de sécurité, liens cassés, poids, métadonnées, validation),"
echo "    générateurs et extraits."
echo "  - Un panneau RÉTRO-INGÉNIERIE à gauche : analyse ELF/PE/Mach-O/classe"
echo "    Java en Python pur, binutils, 15 widgets, 28 fiches, et un pont vers"
echo "    Ghidra quand il est installé. Ghidra n'est PAS fourni (environ 570 Mo"
echo "    et un JDK 21) : le panneau le détecte, dit ce qui manque et donne les"
echo "    commandes d'installation. Sans lui, tout le reste fonctionne. Aucun"
echo "    binaire analysé n'est jamais exécuté."
echo "Les acquis des versions précédentes restent en place : dix langages"
echo "ésotériques, index d'aide, recherche par fonctionnalité, Swift et Kotlin,"
echo "identité Git, filtre de demande optimisée et espace de travail par projet."
sha256sum "$OUT"
echo "Notez cette empreinte : elle identifie votre construction."
