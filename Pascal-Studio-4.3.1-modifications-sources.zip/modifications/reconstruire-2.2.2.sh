#!/bin/sh
# Reconstruction depuis l’AppImage 2.2.1 vérifiée ; outils externes requis.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=7e336d6f2fbeeb88ff19953e7dd7171de5e4f3a60f71d9d7836eb6b41b64bc50
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.2.1 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"
cp "$SRC/server.py" "$R/server.py"
python3 "$SRC/patch_startup_2.2.2.py" "$R/static/assets/index-BA4XgQVD.js"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" <<'PY'
import sys,json
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.2.1';d['version']='2.2.2';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
sha256sum "$OUT"
