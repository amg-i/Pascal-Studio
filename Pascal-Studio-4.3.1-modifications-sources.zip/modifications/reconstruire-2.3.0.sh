#!/bin/sh
# Reconstruction de la 2.3.0 à partir de l’AppImage 2.2.2 exacte.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=30c027d38804d6b748d32d13458593f29db22b717ed7fa6c262485792e8a7bac
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.2.2 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"
cp "$SRC/server.py" "$SRC/scripting.py" "$SRC/python_analyzer.py" "$SRC/python_runtime_diagnostics.py" "$R/"
cp -R "$SRC/vendor-python" "$R/vendor-python"
find "$R/vendor-python" -type d -name __pycache__ -prune -exec rm -rf {} +
python3 "$SRC/patch_python_diagnostics_2.3.py" "$R/static/assets/index-BA4XgQVD.js"
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" <<'PY'
import sys,json
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.2.2', d['version'];d['version']='2.3.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"
cat "$TMP/image.squashfs" >> "$OUT"
chmod +x "$OUT"
sha256sum "$OUT"
