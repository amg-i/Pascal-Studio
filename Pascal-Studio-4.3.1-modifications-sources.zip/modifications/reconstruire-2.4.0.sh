#!/bin/sh
# Reconstruit l’AppImage 2.4.0 depuis la 2.3.0 exacte et ces modifications.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=bb993d641126ea0da28a3975edc5f13d25b53c3a6c4f722a513aafe5e61b08be
[ "$BASE" != "$OUT" ] || { echo 'Choisissez un fichier de sortie différent.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.3.0 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
cp "$SRC/polyglot.py" "$SRC/scripting.py" "$SRC/server.py" "$SRC/project_tools.py" "$R/"
python3 "$SRC/patch_langages_2.4.py" "$A/index-BA4XgQVD.js"
cp "$SRC/nouveaux-langages-aide.js" "$A/"
cp "$SRC/monaco-basic/"*.js "$A/"
cp "$SRC/MONACO-LICENSE.txt" "$A/monaco-license.txt"
python3 - "$R/static/index.html" "$A/index-BCuLwkpg.css" <<'PY'
import sys
p=sys.argv[1];s=open(p,encoding='utf8').read();old='<script src="/assets/database-help.js"></script>';assert s.count(old)==1;s=s.replace(old,old+'<script src="/assets/nouveaux-langages-aide.js"></script>');open(p,'w',encoding='utf8').write(s)
p=sys.argv[2];s=open(p,encoding='utf8').read();s+='\n.lang-icon-rust{color:#f5a47a;background:#523326}.lang-icon-go{color:#76d8ee;background:#20515b}.lang-icon-ruby{color:#ff8792;background:#552b34}\n';open(p,'w',encoding='utf8').write(s)
PY
asar extract "$R/app.asar" "$TMP/asar"
cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"
python3 - "$TMP/asar/package.json" <<'PY'
import json,sys
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.3.0';d['version']='2.4.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
