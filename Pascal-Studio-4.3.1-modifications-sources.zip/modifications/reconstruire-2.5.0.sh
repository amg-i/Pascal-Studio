#!/bin/sh
# Reconstruction à partir de l’AppImage 2.4.0 exacte et des modifications fournies.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=31952d01e836168ffdbb436d871d773027396253ef1a4de1aad972670f691632
[ "$BASE" != "$OUT" ] || { echo 'Choisissez un fichier de sortie différent.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.4.0 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
cp "$SRC/server.py" "$SRC/polyglot.py" "$SRC/debug_mux.py" "$SRC/debugger.py" "$SRC/dap_debugger.py" "$SRC/live_new_languages.py" "$SRC/runtime_new_languages.py" "$R/"
cp "$SRC/aide-complementaire.js" "$SRC/database-help-ui.js" "$A/"
python3 "$SRC/patch_debogage_2.5.py" "$A/index-BA4XgQVD.js"
python3 - "$R/static/index.html" <<'PY'
import sys
p=sys.argv[1];s=open(p,encoding='utf8').read();a='<script src="/assets/nouveaux-langages-aide.js"></script>';assert s.count(a)==1;s=s.replace(a,a+'<script src="/assets/aide-complementaire.js"></script>');open(p,'w',encoding='utf8').write(s)
PY
asar extract "$R/app.asar" "$TMP/asar"
python3 - "$TMP/asar/package.json" <<'PY'
import json,sys
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.4.0';d['version']='2.5.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
