#!/bin/sh
# Reconstruction de la 2.6.0 à partir de l’AppImage 2.5.0 exacte.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=d45cd2adafba9df3650393ce12f125e9da2be0ead1f74b8c27d5f9821ac61c76
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.5.0 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
for file in server.py polyglot.py project_tools.py integrated_terminal.py latex_tools.py; do cp "$SRC/$file" "$R/"; done
cp "$SRC/../interface-compilee/index-BA4XgQVD.js" "$A/index-BA4XgQVD.js"
for file in aide-latex.js terminal-bundle.js terminal-bundle.css terminal-latex.css pdf-viewer-bundle.js pdf.worker.mjs; do cp "$SRC/$file" "$A/"; done
mkdir -p "$R/licenses"; cp "$SRC/LICENSE-xterm.txt" "$SRC/LICENSE-xterm-addon-fit.txt" "$SRC/LICENSE-pdfjs.txt" "$R/licenses/"
python3 - "$R/static/index.html" <<'PY'
import sys
p=sys.argv[1];s=open(p,encoding='utf8').read();a='<script src="/assets/aide-complementaire.js"></script>';assert s.count(a)==1;s=s.replace(a,a+'<script src="/assets/aide-latex.js"></script>');assert s.count('</head>')==1;s=s.replace('</head>','<link rel="stylesheet" href="/assets/terminal-bundle.css"><link rel="stylesheet" href="/assets/terminal-latex.css"><script defer src="/assets/terminal-bundle.js"></script><script defer src="/assets/pdf-viewer-bundle.js"></script></head>');open(p,'w',encoding='utf8').write(s)
PY
asar extract "$R/app.asar" "$TMP/asar"; cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"; cp "$SRC/desktop-preload.cjs" "$TMP/asar/desktop/preload.cjs"
python3 - "$TMP/asar/package.json" <<'PY'
import json,sys
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.5.0';d['version']='2.6.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
