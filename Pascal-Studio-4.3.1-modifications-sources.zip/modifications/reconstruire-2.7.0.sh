#!/bin/sh
# Reconstruit la 2.7.0 à partir de l’AppImage 2.6.1 exacte.
set -eu
BASE=$(realpath "$1"); OUT=$(realpath -m "$2"); SRC=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
EXPECTED=c9b9ca6dd3ad0ca7675e78095d7b68c5333e369611f367cf1cb477cf6b43c018
[ "$BASE" != "$OUT" ] || { echo 'Choisissez une sortie différente.' >&2; exit 1; }
[ "$(sha256sum "$BASE" | cut -d' ' -f1)" = "$EXPECTED" ] || { echo 'AppImage 2.6.1 de base inattendue.' >&2; exit 1; }
command -v asar >/dev/null; command -v mksquashfs >/dev/null
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
(cd "$TMP" && "$BASE" --appimage-extract >/dev/null)
R="$TMP/squashfs-root/resources"; A="$R/static/assets"
cp "$SRC/server.py" "$SRC/handwriting.py" "$R/"
cp "$SRC/document-bundle.js" "$SRC/document-ui.css" "$SRC/DejaVuSans.ttf" "$SRC/aide-latex.js" "$A/"
python3 "$SRC/patch_documents_2.7.py" "$A/index-BA4XgQVD.js"
python3 - "$R/static/index.html" <<'PY'
import sys
p=sys.argv[1];s=open(p,encoding='utf8').read();assert s.count('</head>')==1;s=s.replace('</head>','<link rel="stylesheet" href="/assets/document-ui.css"><script defer src="/assets/document-bundle.js"></script></head>');open(p,'w',encoding='utf8').write(s)
PY
mkdir -p "$R/licenses"
cp "$SRC/LICENSE-DejaVu.txt" "$SRC/LICENSE-pdf-lib.txt" "$SRC/LICENSE-fontkit.txt" "$SRC/LICENSE-pako.txt" "$SRC/LICENSE-tslib.txt" "$SRC/LICENSE-upng.txt" "$SRC/LICENSE-standard-fonts.txt" "$R/licenses/"
asar extract "$R/app.asar" "$TMP/asar"; cp "$SRC/desktop-main.cjs" "$TMP/asar/desktop/main.cjs"; cp "$SRC/desktop-preload.cjs" "$TMP/asar/desktop/preload.cjs"
python3 - "$TMP/asar/package.json" <<'PY'
import json,sys
p=sys.argv[1];d=json.load(open(p));assert d['version']=='2.6.1';d['version']='2.7.0';open(p,'w').write(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
PY
asar pack "$TMP/asar" "$R/app.asar"
mksquashfs "$TMP/squashfs-root" "$TMP/image.squashfs" -noappend -comp gzip -b 128K -processors 2
head -c 188392 "$BASE" > "$OUT"; cat "$TMP/image.squashfs" >> "$OUT"; chmod +x "$OUT"; sha256sum "$OUT"
