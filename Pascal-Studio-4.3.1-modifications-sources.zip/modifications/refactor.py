"""Conservative rename for Pascal variables in a single program/module.

This is deliberately NOT a full Pascal compiler or a whole-project rename.
Unsupported and ambiguous language constructs are rejected instead of guessed.
"""
import re
from dataclasses import dataclass, field

KEYWORDS=set('and array as asm begin case class const constructor destructor div do downto else end except exports file finalization finally for forward function goto if implementation in inherited initialization inline interface is label library mod nil not object of or out packed procedure program property raise record repeat resourcestring set shl shr string then threadvar to try type unit until uses var while with xor'.split())
TOKEN=re.compile(r"\{[^}]*\}|\(\*.*?\*\)|//[^\n]*|'(?:''|[^'])*'|[A-Za-z_][A-Za-z_0-9]*|\d+|:=|\.\.|<=|>=|<>|\S",re.S)
@dataclass
class Token:
    text:str; start:int; end:int
    @property
    def word(self): return self.text.lower()
@dataclass
class Scope:
    start:int; end:int; name:str; parent:object=None; decls:dict=field(default_factory=dict); children:list=field(default_factory=list)

class RefactorError(ValueError): pass

def rename_preview(source, position, new_name):
    if not isinstance(source,str) or len(source)>2_000_000: raise RefactorError('Fichier trop volumineux pour cette analyse.')
    if not isinstance(position,int) or position<0 or position>len(source): raise RefactorError('Position invalide.')
    if not isinstance(new_name,str) or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',new_name) or new_name.lower() in KEYWORDS: raise RefactorError('Le nouveau nom doit être un identifiant Pascal valide, autre qu’un mot réservé.')
    tokens=[]
    for m in TOKEN.finditer(source):
        text=m.group()
        if text in ("'",'{','}') or (text=='(' and source.startswith('(*',m.start())): raise RefactorError('Chaîne ou commentaire Pascal incomplet.')
        if text.startswith(('//','{','(*')):
            if text.startswith(('{' , '(*')):
                inner=text[1:-1] if text.startswith('{') else text[2:-2]
                if '{' in inner or '(*' in inner: raise RefactorError('Commentaires imbriqués non pris en charge.')
                if inner.lstrip().startswith('$') and not re.fullmatch(r'\s*\$\s*(?:mode\s+[A-Za-z_]+|h[+-]|codepage\s+[A-Za-z0-9_-]+)\s*',inner,re.I):
                    raise RefactorError('Renommage refusé : directive de compilation non analysée.')
            continue
        if text.startswith("'"): continue
        tokens.append(Token(text,m.start(),m.end()))
    if not tokens: raise RefactorError('Aucun symbole trouvé.')
    words=[t.word for t in tokens]
    for unsupported in ('with','asm','class','record','object','threadvar','forward','external'):
        if unsupported in words: raise RefactorError('Renommage refusé : construction Pascal non prise en charge (« '+unsupported+' »).')
    if 'unit' in words[:3] or 'library' in words[:3]: raise RefactorError('Les unités et bibliothèques peuvent exposer des symboles à d’autres fichiers : renommage refusé.')
    selected=next((i for i,t in enumerate(tokens) if t.start<=position<t.end),None)
    if selected is None and position: selected=next((i for i,t in enumerate(tokens) if t.end==position),None)
    if selected is None or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',tokens[selected].text) or words[selected] in KEYWORDS: raise RefactorError('Placez le curseur sur une variable ou un paramètre.')
    old=words[selected]
    if old==new_name.lower(): raise RefactorError('Le nouveau nom doit être différent de l’ancien.')
    if new_name.lower() in words: raise RefactorError('Ce nom apparaît déjà dans le fichier : risque de conflit.')
    root=Scope(0,len(tokens),'programme')
    type_positions=set()
    n=len(tokens)
    def add(scope, name, i):
        if name in scope.decls: raise RefactorError('Déclaration ambiguë : '+name)
        scope.decls[name]=i
    def parse_var(i,scope):
        i+=1
        while i<n:
            if words[i] in ('begin','const','type','label','procedure','function','resourcestring','end','var'): break
            start=i
            if not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',tokens[i].text): raise RefactorError('Déclaration de variable non prise en charge.')
            names=[i];i+=1
            while i<n and words[i]==',':
                i+=1
                if i>=n or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',tokens[i].text): raise RefactorError('Déclaration de variable invalide.')
                names.append(i);i+=1
            if i>=n or words[i]!=':': raise RefactorError('Déclaration de variable non prise en charge.')
            for j in names:add(scope,words[j],j)
            type_start=i+1
            depth=0
            while i<n:
                if words[i] in ('(', '['):depth+=1
                elif words[i] in (')',']'):depth-=1
                if words[i]==';' and depth==0:break
                i+=1
            if i>=n:raise RefactorError('Déclaration de variable incomplète.')
            type_positions.update(range(type_start,i))
            i+=1
        return i
    def routine(i,parent):
        if i+1>=n or not re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',tokens[i+1].text): raise RefactorError('Déclaration de routine non prise en charge.')
        name=words[i+1]
        if i+2<n and words[i+2]=='.': raise RefactorError('Méthodes qualifiées non prises en charge.')
        scope=Scope(i,n,name,parent);parent.children.append(scope)
        if name==old: raise RefactorError('Ce nom correspond aussi à une routine ; analyse ambiguë.')
        j=i+2; depth=0; params=[]; param_depth=0
        while j<n:
            w=words[j]
            if w=='(':
                depth+=1
                if depth==1:param_depth=j
            elif w==')':
                if depth==1: params=(param_depth+1,j)
                depth-=1
            if w==';' and depth==0: break
            j+=1
        if j>=n or depth!=0:raise RefactorError('En-tête de routine incomplet.')
        if params:
            a,b=params; k=a
            while k<b:
                if words[k] in ('const','var','out','constref'):k+=1
                names=[]
                while k<b and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*',tokens[k].text):
                    names.append(k);k+=1
                    if k<b and words[k]==',':k+=1;continue
                    break
                if not names or k>=b or words[k]!=':':raise RefactorError('Paramètre de routine non pris en charge.')
                for x in names:add(scope,words[x],x)
                type_start=k+1
                while k<b and words[k]!=';':k+=1
                type_positions.update(range(type_start,k))
                if k<b:k+=1
        j+=1
        while j<n:
            w=words[j]
            if w=='var': j=parse_var(j,scope);continue
            if w in ('const','type','label','resourcestring'): raise RefactorError('Sections const/type locales non prises en charge.')
            if w in ('procedure','function'): j=routine(j,scope);continue
            if w=='begin': break
            if w in ('end','implementation','interface'): raise RefactorError('Routine sans corps analysable.')
            j+=1
        if j>=n: raise RefactorError('Corps de routine introuvable.')
        stack=[];k=j
        while k<n:
            w=words[k]
            if w in ('begin','case','try'): stack.append('end')
            elif w=='repeat':stack.append('until')
            elif w in ('end','until'):
                if not stack or stack[-1]!=w:raise RefactorError('Structure Pascal ambiguë ou incomplète.')
                stack.pop()
                if not stack:
                    scope.end=k+1
                    if k+1>=n or words[k+1]!=';':raise RefactorError('Fin de routine incomplète.')
                    return k+2
            elif w in ('procedure','function'): raise RefactorError('Routine interne dans un bloc non prise en charge.')
            k+=1
        raise RefactorError('Routine incomplète.')
    i=0
    while i<n:
        w=words[i]
        if w in ('procedure','function'):
            if i>0 and words[i-1] in ('=',':','of'): raise RefactorError('Types procéduraux non pris en charge.')
            i=routine(i,root);continue
        if w=='var': i=parse_var(i,root);continue
        if w in ('const','type','label','resourcestring'): raise RefactorError('Sections const/type non prises en charge.')
        i+=1
    def scope_at(scope,index):
        for c in scope.children:
            if c.start<=index<c.end:return scope_at(c,index)
        return scope
    def lookup(scope,name):
        while scope:
            if name in scope.decls:return scope
            scope=scope.parent
        return None
    selected_scope=scope_at(root,selected); binding=lookup(selected_scope,old)
    if binding is None:raise RefactorError('Ce symbole n’est pas une variable ou un paramètre reconnu dans ce fichier.')
    def all_scopes(scope):
        yield scope
        for child in scope.children: yield from all_scopes(child)
    # Avoid creating captures in any lexical scope, even where a compiler could allow shadowing.
    if any(new_name.lower() in sc.decls for sc in all_scopes(root)):raise RefactorError('Ce nom est déjà déclaré dans le fichier : risque de conflit de portée.')
    edits=[]
    for i,t in enumerate(tokens):
        if words[i]!=old:continue
        if i in type_positions: raise RefactorError('Nom ambigu dans un type ou paramètre ; renommage refusé.')
        scope=scope_at(root,i)
        if lookup(scope,old) is not binding:continue
        if (i>0 and words[i-1] in ('.','^')) or (i+1<n and words[i+1]=='.'):
            raise RefactorError('Référence qualifiée ou champ ambigu : renommage refusé.')
        edits.append({'start':t.start,'end':t.end,'old':t.text,'new':new_name})
    if not edits:raise RefactorError('Aucune référence sûre trouvée.')
    result=source
    for e in reversed(edits):result=result[:e['start']]+new_name+result[e['end']:]
    return {'symbol':tokens[selected].text,'scope':binding.name,'count':len(edits),'edits':edits,'content':result,'warning':'Analyse limitée au fichier courant ; vérifiez le résultat avant compilation.'}
