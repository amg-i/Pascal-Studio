"""Encrypted connection secrets, independent of the desktop keyring.

OpenSSL EVP provides AES-256-GCM; hashlib provides scrypt. The encryption key
exists only while this process is unlocked. The file contains no plaintext
credentials. Avoid logging API requests and responses containing secrets.
"""
import base64,contextlib,ctypes,ctypes.util,fcntl,hashlib,json,os,stat,threading,time,uuid
from pathlib import Path

AADS=b'pascal-studio-remote-vault-v1'

def b64(b):return base64.b64encode(b).decode('ascii')
def un64(s,n=None):
 try:
  if not isinstance(s,str) or len(s)>4_000_000:raise ValueError()
  b=base64.b64decode(s,validate=True)
  if n is not None and len(b)!=n:raise ValueError()
  return b
 except Exception:raise ValueError('Coffre chiffré invalide ou corrompu.')

class OpenSSL:
 def __init__(self):
  path=ctypes.util.find_library('crypto')
  if not path:raise ValueError('Bibliothèque OpenSSL libcrypto introuvable.')
  self.lib=ctypes.CDLL(path);l=self.lib;P=ctypes.c_void_p;I=ctypes.c_int
  for name,args,ret in [
   ('EVP_CIPHER_CTX_new',[],P),('EVP_CIPHER_CTX_free',[P],None),('EVP_aes_256_gcm',[],P),
   ('EVP_EncryptInit_ex',[P,P,P,P,P],I),('EVP_EncryptUpdate',[P,P,ctypes.POINTER(I),P,I],I),('EVP_EncryptFinal_ex',[P,P,ctypes.POINTER(I)],I),
   ('EVP_DecryptInit_ex',[P,P,P,P,P],I),('EVP_DecryptUpdate',[P,P,ctypes.POINTER(I),P,I],I),('EVP_DecryptFinal_ex',[P,P,ctypes.POINTER(I)],I),
   ('EVP_CIPHER_CTX_ctrl',[P,I,I,P],I)]:
   f=getattr(l,name);f.argtypes=args;f.restype=ret
 @staticmethod
 def buf(data):return ctypes.create_string_buffer(data,max(len(data),1))
 def crypt(self,key,nonce,data,tag=None):
  if len(key)!=32 or len(nonce)!=12 or (tag is not None and len(tag)!=16):raise ValueError('Paramètres de chiffrement invalides.')
  l=self.lib;ctx=l.EVP_CIPHER_CTX_new()
  if not ctx:raise ValueError('Chiffrement indisponible.')
  enc=tag is None;init=l.EVP_EncryptInit_ex if enc else l.EVP_DecryptInit_ex;update=l.EVP_EncryptUpdate if enc else l.EVP_DecryptUpdate;final=l.EVP_EncryptFinal_ex if enc else l.EVP_DecryptFinal_ex
  keybuf=self.buf(key);ivbuf=self.buf(nonce);aad=self.buf(AADS);src=self.buf(data);out=ctypes.create_string_buffer(len(data)+16);n=ctypes.c_int();n2=ctypes.c_int()
  try:
   if init(ctx,l.EVP_aes_256_gcm(),None,keybuf,ivbuf)!=1:raise ValueError('Initialisation du coffre impossible.')
   if update(ctx,None,ctypes.byref(n),aad,len(AADS))!=1 or update(ctx,out,ctypes.byref(n),src,len(data))!=1:raise ValueError('Traitement du coffre impossible.')
   written=n.value
   if not enc:
    tagbuf=self.buf(tag)
    if l.EVP_CIPHER_CTX_ctrl(ctx,0x11,16,tagbuf)!=1:raise ValueError('Coffre invalide.')
   if final(ctx,ctypes.byref(out,written),ctypes.byref(n2))!=1:raise ValueError('Mot de passe maître incorrect ou coffre corrompu.')
   result=out.raw[:written+n2.value]
   if enc:
    tagbuf=ctypes.create_string_buffer(16)
    if l.EVP_CIPHER_CTX_ctrl(ctx,0x10,16,tagbuf)!=1:raise ValueError('Authentification du coffre impossible.')
    return result,tagbuf.raw
   return result
  finally:l.EVP_CIPHER_CTX_free(ctx)

def derive(master,salt):
 if not isinstance(master,str) or not 12<=len(master)<=1024:raise ValueError('Le mot de passe maître doit contenir au moins 12 caractères.')
 return hashlib.scrypt(master.encode('utf8'),salt=salt,n=32768,r=8,p=1,dklen=32,maxmem=96_000_000)

def identity(uri,user,domain):return json.dumps([uri,user,domain],ensure_ascii=False,separators=(',',':'))

class Vault:
 def __init__(self):
  self.path=Path(os.environ.get('XDG_CONFIG_HOME') or Path.home()/'.config')/'pascal-studio'/'remote-vault.json';self.lock=threading.RLock();self.key=None;self.salt=None;self.secrets={};self.last_failure=0;self.auto_path=self.path.with_name('remote-vault-auto.key')
 def status(self):
  with self.lock:
   exists=self.path.exists();auto=self.auto_path.exists()
   if exists and auto and self.key is None:self.auto_unlock()
   return {'exists':exists,'unlocked':self.key is not None,'mode':'auto' if auto and exists else 'master' if exists else 'none'}
 def _read_auto(self):
  try:
   fd=os.open(self.auto_path,os.O_RDONLY|getattr(os,'O_NOFOLLOW',0))
   try:
    st=os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or (st.st_mode&0o077) or st.st_size>2048:raise ValueError('Permissions de la clé automatique invalides ; attendu : fichier privé 0600.')
    obj=json.loads(os.read(fd,2049).decode('utf8'))
   finally:os.close(fd)
   if obj.get('version')!=1:raise ValueError('Clé automatique invalide.')
   return un64(obj.get('salt'),16),un64(obj.get('key'),32)
  except (OSError,ValueError,TypeError,KeyError,UnicodeError,json.JSONDecodeError) as e:raise ValueError('Impossible de lire la clé automatique du coffre : '+str(e)) from e
 def _save_auto(self,salt,key):
  if self.auto_path.exists() or self.auto_path.is_symlink():
   existing_salt,existing_key=self._read_auto()
   if existing_salt!=salt or existing_key!=key:raise ValueError('Une autre clé automatique existe déjà ; aucune modification effectuée.')
   return False
  tmp=self.auto_path.parent/('.remote-auto-key-'+uuid.uuid4().hex)
  try:
   fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
   with os.fdopen(fd,'w',encoding='utf8') as f:json.dump({'version':1,'salt':b64(salt),'key':b64(key)},f,separators=(',',':'));f.flush();os.fsync(f.fileno())
   os.link(tmp,self.auto_path)  # exclusive, complete file or no key
  finally:tmp.unlink(missing_ok=True)
  return True
 def auto_unlock(self):
  with self.lock:
   if self.key is not None:return {'ok':True}
   with self._file_lock():
    salt,key=self._read_auto();obj=self._read()
    if un64(obj.get('salt'),16)!=salt:raise ValueError('La clé automatique ne correspond pas au coffre ; aucune donnée modifiée.')
    plain=OpenSSL().crypt(key,un64(obj.get('nonce'),12),un64(obj.get('ciphertext')),un64(obj.get('tag'),16))
    value=json.loads(plain.decode('utf8'))
    if not isinstance(value,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in value.items()):raise ValueError('Coffre invalide.')
    self.salt=salt;self.key=key;self.secrets=value
   return {'ok':True}
 def enable_auto(self,master=None):
  # The derived encryption key is stored separately, unencrypted, with 0600.
  # A process with access to the user's Linux account can read this key.
  with self.lock:
   with self._file_lock():
    if self.path.exists():
     if self.key is None:
      if self.auto_path.exists():
       salt,key=self._read_auto();o=self._read()
       if un64(o.get('salt'),16)!=salt:raise ValueError('La clé automatique ne correspond pas au coffre.')
       plain=OpenSSL().crypt(key,un64(o.get('nonce'),12),un64(o.get('ciphertext')),un64(o.get('tag'),16));value=json.loads(plain.decode('utf8'))
       if not isinstance(value,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in value.items()):raise ValueError('Coffre invalide.')
       self.salt=salt;self.key=key;self.secrets=value
      else:self.unlock(master)
     self._reload();self._save_auto(self.salt,self.key)
    else:
     if self.auto_path.exists():salt,key=self._read_auto();created=False
     else:
      salt=os.urandom(16);key=derive(b64(os.urandom(32)),salt);created=self._save_auto(salt,key)
     self.salt=salt;self.key=key;self.secrets={}
     try:self._write(new=True)
     except Exception:
      self.key=None;self.salt=None
      if created:self.auto_path.unlink(missing_ok=True)
      raise
   return {'ok':True}
 def _read(self):
  if self.path.is_symlink() or not self.path.is_file() or self.path.stat().st_size>4_000_000:raise ValueError('Coffre chiffré invalide ou corrompu.')
  try:obj=json.loads(self.path.read_text('utf8'))
  except Exception:raise ValueError('Coffre chiffré invalide ou corrompu.')
  if obj.get('version')!=1 or obj.get('kdf')!='scrypt-32768-8-1' or obj.get('cipher')!='aes-256-gcm':raise ValueError('Format de coffre inconnu.')
  return obj
 def unlock(self,master):
  with self.lock:
   if self.key is not None:return {'ok':True}
   now=time.monotonic()
   if now-self.last_failure<0.6:raise ValueError('Patientez avant un nouvel essai.')
   try:
    if self.path.exists():
     o=self._read();salt=un64(o.get('salt'),16);key=derive(master,salt);plaintext=OpenSSL().crypt(key,un64(o.get('nonce'),12),un64(o.get('ciphertext')),un64(o.get('tag'),16))
     value=json.loads(plaintext.decode('utf8'))
     if not isinstance(value,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in value.items()):raise ValueError('Coffre invalide.')
     self.key=key;self.salt=salt;self.secrets=value
    else:
     self.salt=os.urandom(16);self.key=derive(master,self.salt);self.secrets={}
     try:self._write(new=True)
     except Exception:self.key=None;self.salt=None;raise
    return {'ok':True}
   except Exception:
    self.last_failure=time.monotonic();raise
 def _write(self,new=False):
  if self.key is None:raise ValueError('Déverrouillez le coffre avec le mot de passe maître.')
  nonce=os.urandom(12);data=json.dumps(self.secrets,ensure_ascii=False,separators=(',',':')).encode();ciphertext,tag=OpenSSL().crypt(self.key,nonce,data)
  obj={'version':1,'kdf':'scrypt-32768-8-1','cipher':'aes-256-gcm','salt':b64(self.salt),'nonce':b64(nonce),'ciphertext':b64(ciphertext),'tag':b64(tag)}
  self.path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  if self.path.parent.is_symlink():raise ValueError('Dossier du coffre invalide.')
  tmp=self.path.parent/('.remote-vault-'+uuid.uuid4().hex)
  try:
   fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(obj,f,separators=(',',':'));f.flush();os.fsync(f.fileno())
   if new:
    # Exclusive creation prevents replacing a vault made by another process.
    os.link(tmp,self.path)
   else:
    if not self.path.is_file() or self.path.is_symlink():raise ValueError('Coffre supprimé ou remplacé ; aucune écriture effectuée.')
    os.replace(tmp,self.path)
  finally:tmp.unlink(missing_ok=True)
 @contextlib.contextmanager
 def _file_lock(self):
  self.path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  fd=os.open(self.path.parent/'remote-vault.lock',os.O_CREAT|os.O_RDWR|getattr(os,'O_NOFOLLOW',0),0o600)
  try:
   fcntl.flock(fd,fcntl.LOCK_EX);yield
  finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)
 def _reload(self):
  o=self._read()
  if un64(o.get('salt'),16)!=self.salt:raise ValueError('Le coffre a été modifié dans une autre instance ; redémarrez Pascal Studio.')
  data=OpenSSL().crypt(self.key,un64(o.get('nonce'),12),un64(o.get('ciphertext')),un64(o.get('tag'),16))
  value=json.loads(data.decode('utf8'))
  if not isinstance(value,dict) or any(not isinstance(k,str) or not isinstance(v,str) for k,v in value.items()):raise ValueError('Coffre invalide.')
  self.secrets=value
 def get(self,uri,user,domain):
  with self.lock:
   if self.key is None:raise ValueError('Déverrouillez le coffre avec le mot de passe maître.')
   with self._file_lock():
    self._reload();return self.secrets.get(identity(uri,user,domain),'')
 def put(self,uri,user,domain,password):
  if not password:return
  with self.lock:
   if self.key is None:raise ValueError('Déverrouillez le coffre avec le mot de passe maître.')
   with self._file_lock():
    self._reload();old=dict(self.secrets);self.secrets[identity(uri,user,domain)]=password
    try:self._write()
    except Exception:self.secrets=old;raise
 def remove_uri(self,uri):
  with self.lock:
   if self.key is None:raise ValueError('Déverrouillez le coffre pour effacer son mot de passe.')
   with self._file_lock():
    self._reload();old=dict(self.secrets)
    for k in list(self.secrets):
     try:match=json.loads(k)[0]==uri
     except Exception:match=False
     if match:self.secrets.pop(k,None)
    if old!=self.secrets:
     try:self._write()
     except Exception:self.secrets=old;raise
