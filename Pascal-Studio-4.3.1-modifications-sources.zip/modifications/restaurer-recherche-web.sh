#!/bin/sh
# Récupère la dépendance tierce ddgs fournie dans l'AppImage, sans téléchargement.
set -eu
[ "$#" = 1 ] || { echo 'Usage : sh restaurer-recherche-web.sh Pascal-Studio-3.5.0-x86_64.AppImage' >&2; exit 1; }
APP=$(realpath "$1");DEST=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/assistant-ia/vendor-ddgs
[ ! -e "$DEST" ] || { echo 'vendor-ddgs existe déjà : rien écrasé.' >&2; exit 1; }
[ "$(sha256sum "$APP" | cut -d ' ' -f1)" = 229f8cbdfcba206681dbde9477426c04e71c2a93e694ad69993ac1832359c3bd ] || { echo 'AppImage inattendue.' >&2; exit 1; }
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT HUP INT TERM
(cd "$TMP" && "$APP" --appimage-extract >/dev/null)
cp -a "$TMP/squashfs-root/resources/assistant-ia/vendor-ddgs" "$DEST"
echo 'Dépendance web restaurée dans assistant-ia/vendor-ddgs.'
