"""Façade du panneau rétro-ingénierie.

Un seul point d'entrée pour la route `/api/re` : `import retro`. Les quatre
modules qui font le travail restent séparés et testables seuls :

    retro_detection   ce qui est installé (Ghidra, le JDK, binutils, les
                      bibliothèques Python) et comment l'installer
    retro_binaires    lecture des ELF, PE, Mach-O et classes Java sans aucune
                      bibliothèque tierce, plus l'appel à binutils
    retro_ghidra      le pont vers Ghidra : tâches en arrière-plan, cache de
                      projet, postScript, extraction du JSON
    retro_fiches      les widgets de calcul et les fiches documentaires

Cette façade ne contient PAS de logique d'analyse. Elle fait quatre choses :
router, confiner les chemins, borner les tailles, et garantir qu'aucune
fonction ne lève vers le serveur.

Trois règles, les mêmes que pour devweb :

  * AUCUNE fonction ne lève vers l'appelant. `server.py` transforme une
    exception en `{'error': str(e)}` avec le code 400 : le panneau afficherait
    une trace de pile au lieu d'un refus compréhensible. Chaque entrée rend un
    dict avec `ok`, et en cas d'échec `erreur` en français plus `remede` quand
    un remède existe.
  * Les chemins sont CONFINÉS. Un panneau de rétro-ingénierie lit des binaires
    qui peuvent être n'importe où sur le disque — c'est son métier — mais il ne
    doit pas être utilisable pour ÉCRIRE hors du projet, ni pour lire un fichier
    dont la route ne veut pas. La lecture d'un binaire est donc explicitement
    hors-projet et assumée ; l'écriture (cache, tâches, journal) est confinée
    dans le dossier d'état du module.
  * Un échec est dit avec sa cause et son remède. « Ghidra introuvable » ne
    suffit pas : le panneau doit pouvoir afficher ce qui manque exactement
    (Ghidra, le JDK, le venv PyGhidra) et la commande qui l'installe.

Une quatrième règle est propre à ce panneau, et elle vient de la nature de ce
qu'il manipule : AUCUN BINAIRE ANALYSÉ N'EST EXÉCUTÉ. `analyser` lit des octets
et appelle des outils de lecture (objdump, readelf, nm, strings, file). La seule
exécution qui existe est celle de Ghidra lui-même, dans un processus séparé, sur
une copie du projet, et elle est annoncée comme telle.
"""

import os
import re
import sys
from pathlib import Path

import retro_binaires
import retro_detection
import retro_fiches
import retro_ghidra

VERSION = '4.0.0'

# Un binaire analysé peut être énorme (un noyau, un jeu, une image disque).
# Tout lire en mémoire n'est pas possible : les modules lisent par fenêtres.
# Cette borne protège le serveur contre un chemin qui pointe vers /dev/zero ou
# vers une image de 40 Go, et elle est DITE quand elle s'applique.
TAILLE_MAXIMALE = 512 * 1024 * 1024

# Les fiches et les widgets sont du contenu statique : aucune raison de les
# recalculer à chaque requête, et le panneau les redemande à chaque ouverture.
_CACHE_CONTENU = {}


# ================================================================== UTILITAIRES ==

def _refus(message, remede='', **supplements):
    """Un échec nommé, avec son remède quand il en existe un."""
    reponse = {'ok': False, 'erreur': str(message)}
    if remede:
        reponse['remede'] = remede
    reponse.update(supplements)
    return reponse


def _racine():
    """La racine du projet ouvert, c'est-à-dire celle du serveur.

    `server.py` calcule `ROOT` depuis `PASCAL_WORKSPACE` et le panneau envoie des
    chemins RELATIFS à ce projet. Sans cette racine, `Path('app.elf').resolve()`
    s'appuierait sur le répertoire de travail du SERVEUR, qui est le dossier des
    modules — et chaque fichier du projet serait « introuvable ». C'est exactement
    ce que font `resolve()` et `_confine()` de server.py et devweb.py ; le refaire
    ici n'est pas une duplication inutile, c'est la seule façon pour la façade
    d'être juste quand elle est appelée hors du serveur (bancs, autre outil).
    """
    variable = os.environ.get('PASCAL_WORKSPACE')
    if variable:
        try:
            return Path(variable).resolve()
        except (OSError, ValueError):
            return None
    return None


def _chemin(valeur):
    """Un chemin rendu absolu, sans traversée de répertoire non résolue.

    `resolve()` suit les liens symboliques et normalise `..` : sans lui, un
    chemin comme `projet/../../etc/shadow` serait accepté par un contrôle de
    préfixe écrit sur le chemin brut.

    Un chemin RELATIF est résolu depuis la racine du projet, pas depuis le
    répertoire de travail du processus : voir `_racine()`.

    Ces routes ne sont PAS confinées au projet, et c'est voulu : un binaire à
    analyser n'y est presque jamais. Un chemin absolu est donc accepté tel quel.
    """
    if valeur is None:
        return None
    texte = str(valeur).strip()
    if not texte:
        return None
    chemin = Path(os.path.expanduser(texte))
    if not chemin.is_absolute():
        racine = _racine()
        if racine is not None:
            chemin = racine / chemin
    return chemin.resolve()


def _verifier_chemin(valeur, nom='chemin'):
    """Vérifie qu'un chemin est utilisable, et dit pourquoi il ne l'est pas.

    Rend (chemin, None) ou (None, réponse_d_échec). Ne lève jamais : un panneau
    qui reçoit une trace de pile n'affiche rien.
    """
    chemin = _chemin(valeur)
    if chemin is None:
        return None, _refus('Le champ « %s » est vide : un fichier est demandé.'
                            % nom)
    if not chemin.exists():
        racine = _racine()
        detail = (' Chemin demandé : « %s »%s.' % (valeur,
                  ' résolu depuis le projet « %s ».' % racine if racine
                  else ''))
        return None, _refus('« %s » n’existe pas.' % chemin + detail,
                            'Vérifiez le chemin ; le panneau n’ouvre que des '
                            'fichiers déjà présents sur le disque, et un chemin '
                            'relatif est résolu depuis la racine du projet.')
    if chemin.is_dir():
        return None, _refus('« %s » est un répertoire, pas un fichier.' % chemin,
                            'Un binaire, un objet ou une archive est demandé.')
    if not os.access(chemin, os.R_OK):
        return None, _refus('« %s » n’est pas lisible par cet utilisateur.'
                            % chemin,
                            'ls -l "%s" montre les droits ; sudo n’est pas une '
                            'solution acceptable ici.' % chemin)
    try:
        taille = chemin.stat().st_size
    except OSError as exc:
        return None, _refus('La taille de « %s » n’a pas pu être lue : %s'
                            % (chemin, exc))
    if taille == 0:
        return None, _refus('« %s » est vide : il n’y a rien à analyser.'
                            % chemin)
    if taille > TAILLE_MAXIMALE:
        return None, _refus(
            '« %s » fait %.1f Mo, au-delà de la borne de %d Mo du panneau.'
            % (chemin, taille / 1048576.0, TAILLE_MAXIMALE // 1048576),
            'Découpez le fichier, ou analysez-le en ligne de commande avec '
            'readelf et objdump : le panneau n’apporterait rien de plus sur '
            'un fichier de cette taille.')
    return chemin, None


def _borne(nombre, defaut, minimum, maximum, nom):
    """Borne un entier venu de la requête, et dit quand il a été borné.

    Une requête HTTP transporte des chaînes et des flottants : `int()` lève sur
    « abc », et une borne non vérifiée fait lire 500 Mo à un module qui en
    attendait 512. Rendre (valeur, note) plutôt que lever.
    """
    if nombre is None or nombre == '':
        return defaut, ''
    try:
        valeur = int(nombre)
    except (TypeError, ValueError):
        return defaut, ('« %s » = %r n’est pas un entier : %d utilisé.'
                        % (nom, nombre, defaut))
    if valeur < minimum:
        return minimum, ('« %s » = %d est sous le minimum %d : %d utilisé.'
                         % (nom, valeur, minimum, minimum))
    if valeur > maximum:
        return maximum, ('« %s » = %d dépasse le maximum %d : %d utilisé.'
                         % (nom, valeur, maximum, maximum))
    return valeur, ''


def _ajouter_notes(reponse, notes):
    """Ajoute des notes à une réponse sans écraser celles du module."""
    if not notes:
        return reponse
    if not isinstance(reponse, dict):
        return reponse
    existantes = reponse.get('notes')
    if isinstance(existantes, list):
        existantes.extend(n for n in notes if n not in existantes)
    else:
        reponse['notes'] = list(notes)
    return reponse


# =================================================================== CAPACITÉS ==

def capacites():
    """Ce que le panneau peut faire ICI, sur cette machine, maintenant.

    Le panneau construit son interface depuis cette réponse. La distinction qui
    compte est `avec_ghidra` contre `sans_ghidra` : sans Ghidra, la plus grande
    partie du travail reste possible (en-têtes, sections, symboles,
    désassemblage, chaînes, entropie) et il faut le dire, parce qu'un panneau
    qui affiche « Ghidra introuvable » sans rien d'autre laisse croire que la
    rétro-ingénierie est impossible ici.
    """
    try:
        detection = retro_detection.capacites()
    except Exception as exc:                              # pragma: no cover
        detection = {'ok': False, 'erreur': '%s : %s' % (type(exc).__name__, exc)}
    try:
        ghidra = retro_ghidra.capacites()
    except Exception as exc:                              # pragma: no cover
        ghidra = {'ok': False, 'erreur': '%s : %s' % (type(exc).__name__, exc)}
    try:
        fiches = retro_fiches.capacites()
    except Exception as exc:                              # pragma: no cover
        fiches = {'ok': False, 'erreur': '%s : %s' % (type(exc).__name__, exc)}

    ghidra_info = detection.get('ghidra') or {}
    pret = bool(ghidra.get('pret')) and bool(ghidra_info.get('present'))

    return {
        'ok': True,
        'version': VERSION,
        'modules': {
            'detection': bool(detection.get('ok')),
            'binaires': True,
            'ghidra': bool(ghidra.get('ok')),
            'fiches': bool(fiches.get('ok')),
        },
        'ghidra': ghidra_info,
        'pont': ghidra,
        'pret_pour_ghidra': pret,
        # Sans Ghidra, le panneau reste utile : ces capacités sont locales.
        'sans_ghidra': list(detection.get('sans_ghidra') or []),
        'avec_ghidra': list(detection.get('avec_ghidra') or []),
        'outils': detection.get('outils') or {},
        'outils_disponibles': list(detection.get('outils_disponibles') or []),
        'outils_absents': list(detection.get('outils_absents') or []),
        'manquants': list(detection.get('manquants') or []),
        'operations': sorted(retro_ghidra.OPERATIONS),
        'operations_detail': retro_ghidra.OPERATIONS,
        'widgets': fiches.get('widgets') or [],
        'nombre_widgets': fiches.get('nombre_widgets', 0),
        'fiches': fiches.get('fiches', 0),
        'categories': fiches.get('categories') or [],
        'assembleur': fiches.get('assembleur') or {},
        'taille_maximale': TAILLE_MAXIMALE,
        'dossier_etat': str(retro_ghidra.dossier_etat())
        if hasattr(retro_ghidra, 'dossier_etat') else '',
        'dossier_cache': str(retro_ghidra.dossier_cache())
        if hasattr(retro_ghidra, 'dossier_cache') else '',
        'execute_des_binaires': False,
    }


def etat():
    """L'état courant : tâches en cours, cache de projets, dossier d'état."""
    try:
        liste = retro_ghidra.taches(limite=50)
    except Exception as exc:                              # pragma: no cover
        liste = []
        erreur = '%s : %s' % (type(exc).__name__, exc)
    else:
        erreur = ''
    try:
        projets = retro_ghidra.cache_etat()
    except AttributeError:
        projets = []
    except Exception as exc:                              # pragma: no cover
        projets = []
        erreur = erreur or '%s : %s' % (type(exc).__name__, exc)
    reponse = {'ok': not erreur, 'taches': liste, 'projets': projets}
    if erreur:
        reponse['erreur'] = erreur
    return reponse


# ==================================================================== ANALYSE ==

def analyser(chemin=None, avec_chaines=True, entropie_sections=True,
             minimum_chaine=5, longueur_chaines=524288, desassembler=False,
             syntaxe='att', lignes=200, symbole=None):
    """L'analyse complète d'un binaire, sans Ghidra.

    C'est la fonction que le panneau appelle en premier : elle rend la famille,
    les en-têtes, les sections, les segments, les symboles, les chaînes,
    l'entropie, les imports et les heuristiques d'empaquetage. Tout est lu, rien
    n'est exécuté.

    `desassembler=True` ajoute un désassemblage limité à `lignes` instructions :
    sans borne, objdump sur un binaire de 200 Mo rendrait des dizaines de
    mégaoctets de texte que le panneau ne peut pas afficher.
    """
    notes = []
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec

    minimum_chaine, note = _borne(minimum_chaine, 5, 2, 64, 'minimum_chaine')
    notes.extend([note] if note else [])
    longueur_chaines, note = _borne(longueur_chaines, 524288, 1024,
                                    16 * 1024 * 1024, 'longueur_chaines')
    notes.extend([note] if note else [])
    lignes, note = _borne(lignes, 200, 1, 20000, 'lignes')
    notes.extend([note] if note else [])

    try:
        resultat = retro_binaires.analyser(
            chemin_resolu, avec_chaines=bool(avec_chaines),
            longueur_chaines=longueur_chaines,
            entropie_sections=bool(entropie_sections),
            minimum_chaine=minimum_chaine)
    except Exception as exc:
        return _refus('L’analyse de « %s » a échoué : %s (%s)'
                      % (chemin_resolu, type(exc).__name__, exc),
                      'Le fichier n’est peut-être pas un binaire lisible ; '
                      '« file "%s" » le dit en une commande.' % chemin_resolu)
    if not isinstance(resultat, dict):                    # pragma: no cover
        return _refus('L’analyse a rendu %s au lieu d’un dict.'
                      % type(resultat).__name__)

    resultat['ok'] = bool(resultat.get('ok'))
    resultat['chemin'] = str(chemin_resolu)

    # retro_binaires.analyser() rend `famille` comme un DICT complet (famille,
    # nom, ambiguite, raison, avis_independant) et la structure du format sous
    # `structure`. Le panneau, lui, lit `resultat.famille` comme une CHAÎNE et
    # `resultat.sections` comme une liste : sans cet aplatissement, la zone
    # d'état afficherait « Famille : [object Object] » et la liste des sections
    # serait vide alors que le fichier en a. Les deux formes sont conservées :
    # `famille` pour l'affichage, `famille_detail` pour la raison et
    # l'ambiguïté, qui sont justement ce qu'il ne faut pas perdre.
    famille_brute = resultat.get('famille')
    if isinstance(famille_brute, dict):
        resultat['famille_detail'] = famille_brute
        resultat['famille'] = famille_brute.get('famille')
        resultat.setdefault('nom', famille_brute.get('nom'))
        resultat['ambiguite'] = bool(famille_brute.get('ambiguite'))
        if famille_brute.get('raison'):
            resultat['raison_famille'] = famille_brute['raison']
        if famille_brute.get('avis_independant'):
            resultat['avis_file'] = famille_brute['avis_independant']
    structure = resultat.get('structure')
    if isinstance(structure, dict):
        for cle in ('sections', 'segments', 'symboles', 'imports', 'exports',
                    'entree', 'entree_hex', 'machine', 'boutisme', 'classe',
                    'type', 'interprete', 'depouille', 'statique', 'pie'):
            if cle in structure and cle not in resultat:
                resultat[cle] = structure[cle]
        # Les ELF, PE et Mach-O portent leurs champs sous des clefs différentes ;
        # le panneau ne doit pas avoir à connaître le format pour afficher la
        # machine et le boutisme.
        resultat['machine'] = structure.get('machine') or ''
        resultat['boutisme'] = structure.get('boutisme') or ''
        if structure.get('note_depouille') or structure.get('note_statique'):
            notes.extend(n for n in (structure.get('note_depouille'),
                                     structure.get('note_statique')) if n)
        notes.extend(n for n in (structure.get('notes_lecture') or [])
                     if n and n not in notes)
    if desassembler:
        resultat['desassemblage'] = _desassembler(
            chemin_resolu, syntaxe=syntaxe, lignes=lignes, symbole=symbole)
    # Un binaire qu'aucune famille ne reconnaît n'est pas une erreur : c'est un
    # résultat, et il faut le dire avec la raison.
    if not resultat.get('famille'):
        notes.append('Aucune famille reconnue : le fichier est analysé comme '
                     'un contenu générique. Les outils binutils peuvent encore '
                     'en dire quelque chose.')
    # Une analyse sans section n'est pas une analyse vide : un binaire dépouillé
    # ou sans table de sections n'en a genuinely pas. Le dire évite que le
    # panneau affiche une liste vide qui ressemble à un échec.
    if not (resultat.get('sections') or []):
        notes.append('Aucune section lue : la table des sections est absente ou '
                     'illisible. Les segments et les symboles dynamiques peuvent '
                     'quand même être présents.')
    return _ajouter_notes(resultat, notes)


def famille(chemin=None, donnees=None):
    """La famille d'un fichier, par sa signature.

    Accepte un chemin OU des octets : le panneau a parfois déjà les premiers
    octets (ouverts par l'éditeur) et les relire serait une seconde lecture.
    """
    if donnees is None:
        chemin_resolu, echec = _verifier_chemin(chemin)
        if echec:
            return echec
        try:
            with open(chemin_resolu, 'rb') as fichier:
                donnees = fichier.read(4096)
        except OSError as exc:
            return _refus('La lecture de « %s » a échoué : %s'
                          % (chemin_resolu, exc))
        chemin = str(chemin_resolu)
    else:
        if isinstance(donnees, str):
            donnees = donnees.encode('utf8', 'replace')
        donnees = bytes(donnees)[:4096]
        chemin = chemin or ''
    try:
        resultat = retro_binaires.famille(donnees, str(chemin or ''))
    except Exception as exc:
        return _refus('La reconnaissance de signature a échoué : %s (%s)'
                      % (type(exc).__name__, exc))
    if not isinstance(resultat, dict):
        resultat = {'ok': False, 'famille': None, 'raison': 'résultat inattendu'}
    resultat.setdefault('ok', True)
    return resultat


def vidage(chemin=None, debut=0, longueur=512, colonnes=16, ascii_=True):
    """Un vidage hexadécimal borné, jamais inventé au-delà de la fin."""
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec
    debut, note_debut = _borne(debut, 0, 0, TAILLE_MAXIMALE, 'debut')
    longueur, note_longueur = _borne(longueur, 512, 16, 65536, 'longueur')
    colonnes, note_colonnes = _borne(colonnes, 16, 4, 64, 'colonnes')
    notes = [n for n in (note_debut, note_longueur, note_colonnes) if n]
    try:
        resultat = retro_binaires.vidage(chemin_resolu, debut=debut,
                                         longueur=longueur, colonnes=colonnes,
                                         ascii_=bool(ascii_))
    except Exception as exc:
        return _refus('Le vidage de « %s » a échoué : %s (%s)'
                      % (chemin_resolu, type(exc).__name__, exc))
    return _ajouter_notes(resultat if isinstance(resultat, dict)
                          else {'ok': False, 'erreur': 'résultat inattendu'},
                          notes)


def chaines(chemin=None, minimum=5, debut=0, longueur=None, limite=20000):
    """Les chaînes imprimables, avec leur décalage."""
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec
    minimum, note1 = _borne(minimum, 5, 2, 64, 'minimum')
    debut, note2 = _borne(debut, 0, 0, TAILLE_MAXIMALE, 'debut')
    limite, note3 = _borne(limite, 20000, 1, 200000, 'limite')
    if longueur is not None:
        longueur, note4 = _borne(longueur, 524288, 1, 64 * 1024 * 1024,
                                 'longueur')
    else:
        note4 = ''
    notes = [n for n in (note1, note2, note3, note4) if n]
    try:
        resultat = retro_binaires.chaines(chemin_resolu, minimum=minimum,
                                          debut=debut, longueur=longueur,
                                          limite=limite)
    except Exception as exc:
        return _refus('La recherche de chaînes dans « %s » a échoué : %s (%s)'
                      % (chemin_resolu, type(exc).__name__, exc))
    if isinstance(resultat, dict) and not resultat.get('chaines') \
            and resultat.get('ok'):
        notes.append('Aucune chaîne d’au moins %d caractères trouvée. Ce n’est '
                     'pas une erreur de lecture : %d octets ont été parcourus.'
                     % (minimum, resultat.get('octets_lus', 0)))
    return _ajouter_notes(resultat if isinstance(resultat, dict)
                          else {'ok': False, 'erreur': 'résultat inattendu'},
                          notes)


def symboles(chemin=None, seulement_definis=False, demangler=True,
             taille=True):
    """Les symboles, par nm ou par la table du fichier."""
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec
    try:
        resultat = retro_binaires.symboles_nm(
            chemin_resolu, seulement_definis=bool(seulement_definis),
            demangler=bool(demangler), taille=bool(taille))
    except Exception as exc:
        return _refus('La lecture des symboles de « %s » a échoué : %s (%s)'
                      % (chemin_resolu, type(exc).__name__, exc))
    if isinstance(resultat, dict) and resultat.get('ok') \
            and not resultat.get('symboles'):
        resultat.setdefault('notes', []).append(
            'Aucun symbole : le binaire est probablement dépouillé (strip). '
            'Les symboles dynamiques restent peut-être lisibles avec '
            '« nm -D » ou « readelf --dyn-syms », et Ghidra peut encore '
            'reconnaître des fonctions par signature.')
    return resultat if isinstance(resultat, dict) else \
        _refus('La lecture des symboles a rendu %s.' % type(resultat).__name__)


def _desassembler(chemin, syntaxe='att', lignes=200, symbole=None, debut=None,
                  fin=None):
    """Le désassemblage, avec l'annonce des échecs et des substitutions.

    `-M intel` n'existe que sur x86 : sur un ARM, objdump échoue. Le module
    réessaie sans l'option et LE DIT — un désassemblage en AT&T présenté comme
    de l'Intel serait une information fausse.
    """
    if syntaxe not in ('att', 'intel'):
        return _refus('La syntaxe « %s » n’est pas proposée : « att » ou '
                      '« intel ». « intel » n’existe que sur x86.' % syntaxe)
    try:
        return retro_binaires.desassembler(chemin, debut=debut, fin=fin,
                                           symbole=symbole, syntaxe=syntaxe,
                                           lignes=lignes)
    except Exception as exc:
        return _refus('Le désassemblage de « %s » a échoué : %s (%s)'
                      % (chemin, type(exc).__name__, exc),
                      'objdump -d "%s" en ligne de commande donne la même '
                      'chose avec le message d’erreur complet.' % chemin)


def desassembler(chemin=None, syntaxe='att', lignes=200, symbole=None,
                 debut=None, fin=None):
    """Le désassemblage borné d'un fichier."""
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec
    lignes, note = _borne(lignes, 200, 1, 20000, 'lignes')
    resultat = _desassembler(chemin_resolu, syntaxe=syntaxe, lignes=lignes,
                             symbole=symbole, debut=debut, fin=fin)
    return _ajouter_notes(resultat, [note] if note else [])


def outils(chemin=None):
    """Ce qui est installé, et comment installer ce qui manque."""
    try:
        detection = retro_detection.capacites(rafraichir=True)
    except Exception as exc:
        return _refus('La détection des outils a échoué : %s (%s)'
                      % (type(exc).__name__, exc))
    if chemin:
        chemin_resolu, echec = _verifier_chemin(chemin)
        if echec:
            return echec
        detection['chemin'] = str(chemin_resolu)
    return detection


# ===================================================================== GHIDRA ==

def ghidra_capacites(installation=None):
    """Ce que le pont Ghidra peut faire, avec ce qui manque nommément."""
    try:
        return retro_ghidra.capacites(installation=installation)
    except Exception as exc:
        return _refus('L’état du pont Ghidra n’a pas pu être établi : %s (%s)'
                      % (type(exc).__name__, exc),
                      'Voir la fiche « ghidra-installation » du panneau.')


def ghidra_lancer(operation, chemin=None, arguments=(), installation=None,
                  delai=None):
    """Lance une opération Ghidra en arrière-plan et rend son identifiant.

    L'analyse est lente (des minutes sur un gros binaire) : la rendre
    synchrone bloquerait le serveur HTTP, qui est mono-thread. Le panneau
    interroge ensuite `ghidra_resultat`.

    Le binaire n'est PAS exécuté : Ghidra l'ouvre en lecture, dans un projet
    copié, et le postScript n'écrit que du JSON.
    """
    chemin_resolu, echec = _verifier_chemin(chemin)
    if echec:
        return echec
    operation = str(operation or '').strip()
    if operation not in retro_ghidra.OPERATIONS:
        return _refus('L’opération « %s » n’existe pas. Opérations : %s.'
                      % (operation, ', '.join(sorted(retro_ghidra.OPERATIONS))),
                      'La fiche « ghidra-operations » les décrit une par une.')
    if isinstance(arguments, str):
        arguments = [arguments] if arguments.strip() else []
    if not isinstance(arguments, (list, tuple)):
        return _refus('Les arguments doivent être une liste, pas %s.'
                      % type(arguments).__name__)
    arguments = tuple(str(a) for a in arguments)
    if delai is not None:
        delai, _ = _borne(delai, 900, 30, 7200, 'delai')
    try:
        return retro_ghidra.lancer(operation, chemin_resolu,
                                   arguments=arguments,
                                   installation=installation, delai=delai)
    except Exception as exc:
        return _refus('Le lancement de « %s » sur « %s » a échoué : %s (%s)'
                      % (operation, chemin_resolu, type(exc).__name__, exc),
                      'La fiche « ghidra-installation » donne les voies '
                      'd’installation ; « ghidra-headless » explique la '
                      'commande.')


def ghidra_resultat(identifiant=None, longueur_queue=4000):
    """Le résultat d'une tâche, ou son état si elle tourne encore."""
    identifiant = str(identifiant or '').strip()
    if not identifiant:
        return _refus('Un identifiant de tâche est demandé.')
    if not re.fullmatch(r'[A-Za-z0-9_.\-]{1,128}', identifiant):
        # L'identifiant sert à construire un chemin : sans ce contrôle, « ../.. »
        # ferait lire un journal hors du dossier d'état.
        return _refus('L’identifiant « %s » contient des caractères interdits. '
                      'Lettres, chiffres, point, tiret et souligné seulement.'
                      % identifiant[:64])
    longueur_queue, _ = _borne(longueur_queue, 4000, 200, 200000,
                               'longueur_queue')
    try:
        return retro_ghidra.resultat(identifiant, longueur_queue=longueur_queue)
    except Exception as exc:
        return _refus('La lecture du résultat « %s » a échoué : %s (%s)'
                      % (identifiant, type(exc).__name__, exc))


def ghidra_arreter(identifiant=None):
    """Arrête une tâche. Le groupe de processus entier est tué.

    Ghidra lance une machine virtuelle Java : tuer le seul processus Python
    laisserait le JVM tourner et continuer à écrire dans le projet. C'est
    pourquoi les tâches sont lancées avec `start_new_session=True` et arrêtées
    par `killpg`.
    """
    identifiant = str(identifiant or '').strip()
    if not identifiant:
        return _refus('Un identifiant de tâche est demandé.')
    try:
        return retro_ghidra.arreter(identifiant)
    except Exception as exc:
        return _refus('L’arrêt de « %s » a échoué : %s (%s)'
                      % (identifiant, type(exc).__name__, exc),
                      'pkill -f AnalyzeHeadless termine le travail à la main.')


def ghidra_taches(limite=50):
    """Les tâches connues, les plus récentes d'abord."""
    limite, _ = _borne(limite, 50, 1, 500, 'limite')
    try:
        resultat = retro_ghidra.taches(limite=limite)
    except Exception as exc:
        return _refus('La liste des tâches a échoué : %s (%s)'
                      % (type(exc).__name__, exc))
    return {'ok': True, 'taches': resultat}


def postscript():
    """Le postScript généré, pour que l'utilisateur puisse le lire.

    Un script envoyé à Ghidra sans être montré serait du code exécuté à l'insu
    de l'utilisateur. Le panneau l'affiche donc, et l'autocontrôle du module le
    compile.
    """
    try:
        texte = retro_ghidra.generer_postscript()
    except Exception as exc:
        return _refus('Le postScript n’a pas pu être généré : %s (%s)'
                      % (type(exc).__name__, exc))
    return {'ok': True, 'postscript': texte, 'octets': len(texte.encode('utf8')),
            'marqueur_debut': getattr(retro_ghidra, 'MARQUEUR_DEBUT', ''),
            'marqueur_fin': getattr(retro_ghidra, 'MARQUEUR_FIN', '')}


# ==================================================================== FICHES ==

def fiches(categorie=None):
    """La liste des fiches, éventuellement filtrée par catégorie."""
    try:
        resultat = retro_fiches.fiches(categorie)
    except Exception as exc:
        return _refus('La liste des fiches a échoué : %s (%s)'
                      % (type(exc).__name__, exc))
    return resultat


def fiche(identifiant=None):
    """Une fiche complète, avec ses faits vérifiés à l'autocontrôle."""
    identifiant = str(identifiant or '').strip()
    if not identifiant:
        return _refus('Un identifiant de fiche est demandé.')
    try:
        resultat = retro_fiches.fiche(identifiant)
    except Exception as exc:
        return _refus('La lecture de la fiche « %s » a échoué : %s (%s)'
                      % (identifiant, type(exc).__name__, exc))
    return resultat


def chercher(motif=None, limite=25):
    """La recherche plein texte dans les fiches, les titres et les mots-clés."""
    limite, _ = _borne(limite, 25, 1, 200, 'limite')
    try:
        return retro_fiches.chercher_fiche(motif, limite=limite)
    except Exception as exc:
        return _refus('La recherche « %s » a échoué : %s (%s)'
                      % (motif, type(exc).__name__, exc))


def categories():
    """Les catégories de fiches, avec leur nombre de fiches."""
    try:
        return retro_fiches.categories()
    except Exception as exc:
        return _refus('La liste des catégories a échoué : %s (%s)'
                      % (type(exc).__name__, exc))


def widgets():
    """La description des widgets : entrées, défauts, exemple vérifié."""
    try:
        resultat = retro_fiches.widgets()
    except Exception as exc:
        return _refus('La liste des widgets a échoué : %s (%s)'
                      % (type(exc).__name__, exc))
    return {'ok': True, 'widgets': resultat}


def widget(identifiant=None, entrees=None):
    """Exécute un widget.

    Les widgets ne touchent PAS au disque : ce sont des convertisseurs et des
    tables. Celui qui veut analyser un fichier passe par `analyser`, et celui
    qui veut coller un vidage hexadécimal passe par le widget « hexdump », qui
    le relit et dit quel format il a reconnu.
    """
    identifiant = str(identifiant or '').strip()
    if not identifiant:
        return _refus('Un identifiant de widget est demandé.')
    if entrees is not None and not isinstance(entrees, dict):
        return _refus('Les entrées d’un widget doivent être un objet, pas %s.'
                      % type(entrees).__name__)
    try:
        return retro_fiches.executer_widget(identifiant, entrees or {})
    except Exception as exc:                              # pragma: no cover
        # executer_widget ne lève déjà pas ; ce filet existe parce qu'une façade
        # qui promet de ne jamais lever doit tenir sa promesse même si le module
        # en dessous change.
        return _refus('Le widget « %s » a échoué : %s (%s)'
                      % (identifiant, type(exc).__name__, exc))


# =================================================================== AUTOCÔNTRÔLE ==

def verifier():
    """Autocontrôle de la façade : rend (nombre_de_contrôles, échecs).

    La façade ne contient pas de logique d'analyse, mais elle contient des
    GARDES : confinement des chemins, bornage des tailles, refus nommés. Ces
    gardes sont exactement ce qu'un test unitaire des modules ne couvre pas, et
    ce qu'une mutation ferait sauter en premier.

    Chaque contrôle ci-dessous correspond à une garde réelle. Ils s'exécutent
    sur des fichiers temporaires et ne touchent jamais au projet.
    """
    echecs = []
    controles = [0]

    def controler(condition, message):
        controles[0] += 1
        if not condition:
            echecs.append(message)
        return bool(condition)

    def sans_lever(appel, message):
        """Exécute `appel()` et rend (résultat, True) ou (None, False).

        Une levée devient un ÉCHEC NOMMÉ au lieu d'interrompre l'autocontrôle.
        La façade promet de ne jamais lever ; un mutant qui la fait lever doit
        être tué par un échec nommé, pas par un plantage — sinon le banc
        s'arrête et ne vérifie plus rien après, et le balayage de mutations ne
        distingue pas « tué » de « planté ».
        """
        controles[0] += 1
        try:
            return appel(), True
        except Exception as exc:
            echecs.append('%s : %s (%s)' % (message, type(exc).__name__, exc))
            return None, False

    # --- les gardes de chemin, sur un fichier réel --------------------------
    import tempfile
    with tempfile.TemporaryDirectory() as dossier:
        racine = Path(dossier)
        binaire = racine / 'test.bin'
        binaire.write_bytes(b'\x7fELF' + b'\x00' * 200)
        vide = racine / 'vide.bin'
        vide.write_bytes(b'')
        repertoire = racine / 'sous'
        repertoire.mkdir()
        # Le nom de la fixture ne doit PAS contenir le mot que l'assertion
        # cherche : appelée « illisible.bin », elle satisfaisait
        # « 'lisible' in erreur » par son seul NOM, et le contrôle passait même
        # avec la garde `os.access` supprimée. Le balayage de mutations l'a
        # montré : un mutant survivant est presque toujours une assertion
        # satisfaite par autre chose que ce qu'elle croit vérifier.
        illisible = racine / 'prive.bin'
        illisible.write_bytes(b'\x7fELF' + b'\x00' * 64)
        try:
            os.chmod(illisible, 0o000)
        except OSError:                                  # pragma: no cover
            illisible = None

        controle = analyser(chemin=str(binaire))
        controler(controle.get('ok') is not False,
                  'analyser() sur un ELF minimal a échoué : %s'
                  % controle.get('erreur'))
        controler(controle.get('chemin') == str(binaire.resolve()),
                  'analyser() ne rend pas le chemin résolu')
        # retro_binaires.analyser() rend `famille` comme un DICT ; le panneau le
        # lit comme une CHAÎNE. Sans aplatissement, la zone d'état afficherait
        # « Famille : [object Object] » — un défaut invisible côté Python et
        # évident côté interface. Les deux formes doivent être présentes.
        controler(isinstance(controle.get('famille'), str),
                  'analyser() rend famille=%s au lieu d’une chaîne : le panneau '
                  'afficherait [object Object]' % type(controle.get('famille')).__name__)
        controler(controle.get('famille') == 'elf',
                  'analyser() ne reconnaît pas un ELF minimal (%r)'
                  % controle.get('famille'))
        controler(isinstance(controle.get('famille_detail'), dict)
                  and controle['famille_detail'].get('raison'),
                  'analyser() perd le détail de la famille : la raison et '
                  'l’ambiguïté disparaîtraient de l’affichage')
        controler('machine' in controle and 'boutisme' in controle,
                  'analyser() ne remonte pas la machine et le boutisme depuis la '
                  'structure : le panneau devrait connaître chaque format')
        # Une analyse sans section doit le dire : une liste vide ressemble à un
        # échec, et ce n'en est pas un.
        if not (controle.get('sections') or []):
            controler(any('section' in str(n).lower()
                          for n in controle.get('notes') or []),
                      'analyser() rend zéro section sans le dire')

        for appel, attendu in (
                (lambda: analyser(chemin=None), 'vide'),
                (lambda: analyser(chemin=''), 'vide'),
                (lambda: analyser(chemin=str(racine / 'absent.bin')),
                 'n’existe pas'),
                (lambda: analyser(chemin=str(repertoire)), 'répertoire'),
                (lambda: analyser(chemin=str(vide)), 'vide'),
        ):
            resultat = appel()
            controler(resultat.get('ok') is False,
                      'analyser() n’a pas refusé un chemin invalide (%s)'
                      % attendu)
            controler(attendu in str(resultat.get('erreur', '')),
                      'le refus « %s » ne nomme pas sa cause : %r'
                      % (attendu, resultat.get('erreur')))

        if illisible is not None and os.geteuid() != 0:
            resultat, _ok = sans_lever(lambda: analyser(chemin=str(illisible)),
                                       'analyser() sur un fichier illisible a levé')
            # La formulation EXACTE de la garde, pas un mot qui pourrait venir
            # du chemin : sans la garde, retro_binaires lève PermissionError et
            # la façade rend « a échoué : PermissionError », qui ne contient pas
            # cette formulation. C'est ce qui distingue les deux refus.
            controler(resultat is not None and resultat.get('ok') is False
                      and 'pas lisible par cet utilisateur'
                      in str(resultat.get('erreur', '')),
                      'analyser() n’a pas refusé un fichier illisible par la '
                      'garde de droits : %r' % (resultat or {}).get('erreur'))
            controler(resultat is not None
                      and 'ls -l' in str(resultat.get('remede', '')),
                      'le refus d’un fichier illisible ne donne pas le remède '
                      'qui montre les droits')

        # --- le bornage : une valeur hors limite est bornée ET DITE ---------
        resultat = chaines(chemin=str(binaire), minimum=9999)
        controler(resultat.get('ok') is not False,
                  'chaines() a échoué sur un minimum trop grand')
        controler(any('minimum' in str(n) for n in resultat.get('notes', [])),
                  'chaines() a borné « minimum » sans le dire')

        resultat = vidage(chemin=str(binaire), longueur=10 ** 9)
        controler(any('longueur' in str(n) for n in resultat.get('notes', [])),
                  'vidage() a borné « longueur » sans le dire')

        resultat, _ok = sans_lever(
            lambda: vidage(chemin=str(binaire), longueur='pas-un-nombre'),
            'vidage() a LEVÉ sur une longueur non entière au lieu de la '
            'remplacer par le défaut en le disant')
        controler(resultat is not None and
                  any('entier' in str(n) for n in resultat.get('notes', [])),
                  'vidage() a remplacé une longueur invalide sans le dire')

        # --- la borne de taille est APPLIQUÉE, pas seulement annoncée -------
        # `capacites()['taille_maximale']` ne prouve rien : c'est la constante
        # recopiée. Ce qui doit être vérifié, c'est que _verifier_chemin()
        # REFUSE au-delà. La constante est ABAISSÉE le temps du contrôle plutôt
        # que de créer un fichier de 512 Mo : le contrôle porte sur la
        # COMPARAISON, qui est la garde, et il ne coûte ni disque ni mémoire.
        # (Un fichier sparse de 512 Mo ferait LIRE 512 Mo au mutant, qui est
        # justement censé ne pas refuser : le balayage deviendrait lent pour
        # rien, et pourrait manquer de mémoire avant de conclure.)
        borne_originale = globals()['TAILLE_MAXIMALE']
        globals()['TAILLE_MAXIMALE'] = 32
        try:
            resultat, _ok = sans_lever(
                lambda: analyser(chemin=str(binaire)),
                'analyser() a levé sur un fichier au-delà de la borne')
            controler(resultat is not None and resultat.get('ok') is False,
                      'analyser() n’a pas refusé un fichier au-delà de la borne '
                      'de taille : %r' % (resultat or {}).get('erreur'))
            controler(resultat is not None
                      and 'borne' in str(resultat.get('erreur', '')),
                      'le refus d’un fichier trop volumineux ne nomme pas la '
                      'borne : %r' % (resultat or {}).get('erreur'))
            controler(resultat is not None
                      and bool(str(resultat.get('remede') or '').strip()),
                      'le refus d’un fichier trop volumineux ne donne aucun '
                      'remède : l’utilisateur reste sans issue')
        finally:
            globals()['TAILLE_MAXIMALE'] = borne_originale
        # La constante doit être revenue : un contrôle qui laisse le module dans
        # un état muté fausse tous les contrôles suivants.
        controler(globals()['TAILLE_MAXIMALE'] == borne_originale,
                  'le contrôle de la borne n’a pas restauré TAILLE_MAXIMALE')

        # --- _ajouter_notes FUSIONNE au lieu d'écraser ---------------------
        # Les notes du module disent ce qui n'a PAS pu être lu ; celles de la
        # façade disent ce qui a été borné. Écraser les premières ferait
        # disparaître « la section .bss est absente du fichier » dès que la
        # façade ajoute « longueur bornée » — et un rapport partiel qui ne se
        # dit pas est un rapport faux.
        fusion = {'ok': True, 'notes': ['note du module']}
        _ajouter_notes(fusion, ['note de la façade', 'note du module'])
        controler(fusion['notes'] == ['note du module', 'note de la façade'],
                  '_ajouter_notes() n’a pas fusionné sans dupliquer : %r'
                  % fusion['notes'])
        sans_notes = {'ok': True}
        _ajouter_notes(sans_notes, ['première'])
        controler(sans_notes['notes'] == ['première'],
                  '_ajouter_notes() ne crée pas la liste quand elle est absente')
        _ajouter_notes(sans_notes, [])
        controler(sans_notes['notes'] == ['première'],
                  '_ajouter_notes() modifie la réponse sur une liste de notes '
                  'vide')

        # --- la traverse de répertoire est résolue --------------------------
        traverse = str(racine / 'sous' / '..' / 'test.bin')
        resultat = famille(chemin=traverse)
        controler(resultat.get('ok') is not False and
                  resultat.get('famille') == 'elf',
                  'famille() n’a pas résolu une traverse de répertoire : %r'
                  % resultat)

        # --- famille accepte des octets et ne relit pas le disque -----------
        resultat = famille(donnees=b'\x7fELF\x02\x01\x01\x00')
        controler(resultat.get('famille') == 'elf',
                  'famille(donnees=…) n’a pas reconnu un ELF')
        resultat = famille(donnees=b'\xca\xfe\xba\xbe\x00\x00\x00\x34')
        controler(resultat.get('famille') == 'class-java',
                  'famille() n’a pas résolu 0xCAFEBABE en classe Java : %r'
                  % resultat)
        resultat = famille(donnees=b'\xca\xfe\xba\xbe\x00\x00\x00\x02')
        controler(resultat.get('ambiguite') is True or
                  'macho' in str(resultat.get('famille', '')).lower(),
                  'famille() n’a pas signalé l’ambiguïté 0xCAFEBABE : %r'
                  % resultat)

    # --- la racine du projet : un chemin relatif doit y être résolu ---------
    # C'est le défaut qui faisait échouer le banc de bout en bout : le panneau
    # envoie des chemins RELATIFS au projet, et `Path('app.elf').resolve()`
    # s'appuyait sur le répertoire de travail du serveur (le dossier des
    # modules). Chaque fichier du projet était alors « introuvable ».
    import tempfile as _tempfile
    with _tempfile.TemporaryDirectory() as _projet:
        _ancien = os.environ.get('PASCAL_WORKSPACE')
        os.environ['PASCAL_WORKSPACE'] = _projet
        try:
            (_projet_path := Path(_projet))
            cible = _projet_path / 'app.elf'
            cible.write_bytes(b'\x7fELF' + b'\x00' * 120)
            resolu = _chemin('app.elf')
            controler(resolu == cible.resolve(),
                      'un chemin relatif n’est pas résolu depuis PASCAL_WORKSPACE '
                      '(%r au lieu de %r)' % (resolu, cible))
            resultat = analyser(chemin='app.elf')
            controler(resultat.get('ok') is not False,
                      'analyser() sur un chemin RELATIF du projet a échoué : %s'
                      % resultat.get('erreur'))
            controler(resultat.get('chemin') == str(cible.resolve()),
                      'analyser() ne rend pas le chemin résolu depuis le projet')
            # Un chemin ABSOLU hors du projet reste accepté : ces routes ne sont
            # pas confinées, un binaire à analyser n'est presque jamais dans le
            # projet. Le confinement serait ici une régression, pas une sécurité.
            resultat = famille(chemin=sys.executable)
            controler(resultat.get('ok') is not False,
                      'un chemin absolu hors du projet est refusé à tort : %s'
                      % resultat.get('erreur'))
            # Le refus d'un fichier absent nomme la racine utilisée : sans elle,
            # un « n'existe pas » sur un fichier du projet est incompréhensible.
            resultat = analyser(chemin='absent.bin')
            controler(resultat.get('ok') is False and _projet
                      in str(resultat.get('erreur', '')),
                      'le refus d’un fichier absent ne nomme pas la racine du '
                      'projet : %r' % resultat.get('erreur'))
        finally:
            if _ancien is None:
                os.environ.pop('PASCAL_WORKSPACE', None)
            else:
                os.environ['PASCAL_WORKSPACE'] = _ancien

    # --- les gardes qui ne dépendent pas du disque --------------------------
    resultat = ghidra_lancer('opération-qui-n-existe-pas', chemin=__file__)
    controler(resultat.get('ok') is False and 'n’existe pas'
              in str(resultat.get('erreur', '')),
              'ghidra_lancer() n’a pas refusé une opération inconnue')
    controler(bool(resultat.get('remede')),
              'le refus d’une opération inconnue ne donne pas de remède')

    resultat = ghidra_lancer('info', chemin=None)
    controler(resultat.get('ok') is False,
              'ghidra_lancer() sans chemin n’a pas refusé')

    resultat = ghidra_resultat('../../etc/passwd')
    controler(resultat.get('ok') is False and 'interdits'
              in str(resultat.get('erreur', '')),
              'ghidra_resultat() n’a pas refusé un identifiant contenant « .. »')

    resultat = ghidra_resultat('')
    controler(resultat.get('ok') is False,
              'ghidra_resultat() sans identifiant n’a pas refusé')

    resultat = ghidra_arreter('')
    controler(resultat.get('ok') is False,
              'ghidra_arreter() sans identifiant n’a pas refusé')

    resultat = desassembler(chemin=None, syntaxe='mips')
    controler(resultat.get('ok') is False,
              'desassembler() n’a pas refusé une syntaxe inconnue')

    resultat = widget(identifiant='', entrees={})
    controler(resultat.get('ok') is False,
              'widget() sans identifiant n’a pas refusé')
    resultat = widget(identifiant='convertisseur', entrees='pas-un-objet')
    controler(resultat.get('ok') is False,
              'widget() avec des entrées non-objet n’a pas refusé')
    resultat = widget(identifiant='inexistant', entrees={})
    controler(resultat.get('ok') is False and 'n’existe pas'
              in str(resultat.get('erreur', '')),
              'widget() n’a pas nommé un widget inexistant')

    # Un widget réel doit rendre quelque chose d'utilisable.
    resultat = widget('convertisseur', {'valeur': '0x41424344',
                                        'largeur': 4, 'boutisme': 'inverse'})
    controler(resultat.get('ok') is not False,
              'le widget convertisseur a échoué : %s' % resultat.get('erreur'))

    # --- le contenu est cohérent --------------------------------------------
    capacite = capacites()
    controler(capacite.get('ok') is True, 'capacites() n’est pas ok')
    controler(capacite.get('execute_des_binaires') is False,
              'capacites() doit déclarer qu’aucun binaire n’est exécuté')
    controler(len(capacite.get('operations') or []) >= 10,
              'capacites() annonce moins de dix opérations Ghidra')
    controler(capacite.get('nombre_widgets', 0) >= 15,
              'capacites() annonce moins de quinze widgets')
    controler(capacite.get('taille_maximale') == TAILLE_MAXIMALE,
              'capacites() n’annonce pas la borne de taille réelle')
    controler(isinstance(capacite.get('sans_ghidra'), list),
              'capacites() ne liste pas ce qui reste possible sans Ghidra')
    # Sans Ghidra installé, le panneau doit quand même savoir quoi faire.
    if not capacite.get('pret_pour_ghidra'):
        controler(bool(capacite.get('sans_ghidra')),
                  'Ghidra est absent mais aucune capacité de repli n’est '
                  'annoncée : le panneau semblerait inutilisable')
        controler(bool(capacite.get('manquants')),
                  'Ghidra est absent mais rien ne nomme ce qui manque')

    resultat = widgets()
    controler(resultat.get('ok') is True and
              len(resultat.get('widgets') or []) >= 15,
              'widgets() ne rend pas les quinze widgets')

    resultat = categories()
    controler(resultat.get('ok') is not False,
              'categories() a échoué : %s' % resultat.get('erreur'))

    resultat = fiches()
    controler(isinstance(resultat, (dict, list)),
              'fiches() rend %s' % type(resultat).__name__)

    resultat = fiche('elf-en-tete')
    controler(resultat.get('ok') is True,
              'fiche("elf-en-tete") a échoué : %s' % resultat.get('erreur'))
    resultat = fiche('fiche-inexistante')
    controler(resultat.get('ok') is False and 'n’existe pas'
              in str(resultat.get('erreur', '')),
              'fiche() n’a pas nommé une fiche inexistante')

    resultat = chercher('ghidra')
    controler(isinstance(resultat, (dict, list)),
              'chercher() rend %s' % type(resultat).__name__)

    resultat = postscript()
    controler(resultat.get('ok') is True and
              resultat.get('octets', 0) > 1000,
              'postscript() n’a pas rendu un script complet')
    controler(resultat.get('marqueur_debut') and resultat.get('marqueur_fin'),
              'postscript() ne rend pas les marqueurs : le lecteur ne pourrait '
              'pas isoler le JSON du bruit de Ghidra')

    # --- aucun appel de la façade ne lève -----------------------------------
    for nom, fonction in (
            ('capacites', capacites),
            ('etat', etat),
            ('fiches', fiches),
            ('categories', categories),
            ('widgets', widgets),
            ('postscript', postscript),
            ('outils', outils),
            ('ghidra_capacites', ghidra_capacites),
            ('ghidra_taches', ghidra_taches),
    ):
        controles[0] += 1
        try:
            resultat = fonction()
        except Exception as exc:
            echecs.append('%s() a levé %s : %s' % (nom, type(exc).__name__, exc))
            continue
        controler(isinstance(resultat, dict),
                  '%s() rend %s au lieu d’un dict'
                  % (nom, type(resultat).__name__))

    # Les modules sous-jacents ont leur propre autocontrôle : le signaler ici
    # sans le rejouer, pour que le banc de la façade reste rapide.
    for nom, module in (('retro_fiches', retro_fiches),
                        ('retro_detection', retro_detection)):
        controler(hasattr(module, 'verifier'),
                  '%s n’expose pas verifier() : son autocontrôle ne peut pas '
                  'être rejoué' % nom)

    return controles[0], echecs


if __name__ == '__main__':
    nombre, echecs = verifier()
    capacite = capacites()
    if capacite['pret_pour_ghidra']:
        pont = 'pont Ghidra prêt (%s)' % (
            (capacite['ghidra'].get('version') or {}).get('chaine', '?'))
    else:
        pont = 'pont Ghidra non prêt (%s)' % (
            capacite['ghidra'].get('raison') or 'raison inconnue')
    print('retro %s : %d contrôle(s) ; %d opération(s) ; %d widget(s) ; '
          '%d fiche(s) ; %s ; %d outil(s) présent(s) ; autocontrôle %s'
          % (VERSION, nombre, len(capacite['operations']),
             capacite['nombre_widgets'], capacite['fiches'], pont,
             len(capacite['outils_disponibles']),
             'OK' if not echecs else 'ÉCHEC (%d)' % len(echecs)))
    for echec in echecs:
        print('ÉCHEC : %s' % echec)
    sys.exit(1 if echecs else 0)
