"""Lecteur de binaires en Python pur : ELF, PE, Mach-O, et formats dérivés.

Ce module existe pour une raison précise : Ghidra ne peut pas être livré avec
Pascal Studio (570 Mo, un JDK 21). Le panneau de rétro-ingénierie doit donc
rester utile quand Ghidra est absent, et pour cela il lui faut lire les binaires
lui-même, sans capstone ni pyelftools ni pefile — aucune de ces bibliothèques
n'est installable hors ligne.

Trois règles de conception, chacune issue d'une panne réelle ou d'une contrainte
du projet :

  1. AUCUNE LEVÉE. Un binaire du terrain est tronqué, chiffré, délibérément
     malformé, ou d'un format que nous ne connaissons pas. Chaque lecture passe
     par un `Lecteur` borné qui rend des zéros au-delà de la fin du fichier et
     note la troncature. Un analyseur qui lève rend le panneau vide et
     silencieux ; un analyseur qui rend « illisible à l'octet 4096, voici ce qui
     a pu être lu » reste utile.
  2. LAISSER DIRE PLUTÔT QUE DEVINER. Quand un champ est ambigu, les deux
     lectures possibles sont rendues avec l'ambiguïté nommée : 0xCAFEBABE est
     BOTH un binaire gras Mach-O et un .class Java, et trancher au hasard ferait
     afficher une certitude fausse.
  3. RIEN NE S'EXÉCUTE. Ce module lit des octets et lance des outils d'analyse
     (objdump, readelf, nm, strings) sur demande explicite, avec des listes
     d'arguments et jamais un interpréteur de commandes. Un binaire analysé
     n'est jamais exécuté : `file` et `objdump` ne le lancent pas non plus.
"""

import binascii
import hashlib
import math
import os
import re
import shutil
import struct
import subprocess
from pathlib import Path

VERSION = '4.0.0'

OCTETS_MAX = 512 * 1024 * 1024          # au-delà, on lit les en-têtes seulement
LECTURE_MAX = 64 * 1024 * 1024           # garde-fou par lecture unique
CHAINE_MIN = 5
CHAINE_MAX = 4096
LIGNES_MAX = 4000                        # borne d'un désassemblage rendu

TYPES_ELF = {0: 'AUCUN', 1: 'REL (repositionnable)', 2: 'EXEC (exécutable)',
             3: 'DYN (objet partagé ou PIE)', 4: 'CORE (vidage mémoire)'}

MACHINES_ELF = {
    0: 'aucune', 1: 'AT&T WE 32100', 2: 'SPARC', 3: 'x86', 4: 'Motorola 68000',
    7: 'Intel 80860', 8: 'MIPS', 9: 'IBM S/390', 10: 'MIPS RS4000 BE',
    15: 'HP PA-RISC', 18: 'SPARC v9 64 bits', 20: 'PowerPC',
    21: 'PowerPC 64 bits', 22: 'IBM S/390 64 bits', 36: 'NEC V800',
    40: 'ARM 32 bits', 41: 'Alpha', 42: 'Hitachi SH', 43: 'SPARC v9',
    45: 'Philips TriMedia', 46: 'Motorola ColdFire', 47: 'Hitachi H8/300H',
    50: 'IA-64 (Itanium)', 53: 'AVR Atmel', 62: 'x86-64',
    71: 'DSPIC30F', 75: 'TMS320C6000', 83: 'AVR 8 bits',
    88: 'IBM S/390 zSeries', 93: 'Xilinx MicroBlaze', 94: 'Altera Nios II',
    140: 'MCST Elbrus e2k', 183: 'ARM 64 bits (AArch64)',
    220: 'Zilog Z80', 243: 'RISC-V', 246: 'Berkeley Packet Filter',
    247: 'eBPF étendu', 252: 'C-SKY', 257: 'LoongArch',
}

TYPES_SECTION_ELF = {
    0: 'NULL', 1: 'PROGBITS', 2: 'SYMTAB', 3: 'STRTAB', 4: 'RELA', 5: 'HASH',
    6: 'DYNAMIC', 7: 'NOTE', 8: 'NOBITS', 9: 'REL', 11: 'DYNSYM',
    14: 'INIT_ARRAY', 15: 'FINI_ARRAY', 16: 'PREINIT_ARRAY', 17: 'GROUP',
    18: 'SYMTAB_SHNDX', 0x6ffffff5: 'GNU_ATTRIBUTES', 0x6ffffff6: 'GNU_HASH',
    0x6ffffffd: 'GNU_verdef', 0x6ffffffe: 'GNU_verneed', 0x6fffffff: 'GNU_versym',
}

FLAGS_SECTION_ELF = ((0x1, 'WRITE'), (0x2, 'ALLOC'), (0x4, 'EXECINSTR'),
                     (0x10, 'MERGE'), (0x20, 'STRINGS'), (0x40, 'INFO_LINK'),
                     (0x200, 'OS_NONCONFORMING'), (0x400, 'GROUP'),
                     (0x800, 'TLS'))

TYPES_SEGMENT_ELF = {
    0: 'NULL', 1: 'LOAD', 2: 'DYNAMIC', 3: 'INTERP', 4: 'NOTE', 5: 'SHLIB',
    6: 'PHDR', 7: 'TLS', 0x6474e550: 'GNU_EH_FRAME', 0x6474e551: 'GNU_STACK',
    0x6474e552: 'GNU_RELRO', 0x6474e553: 'GNU_PROPERTY',
    0x70000001: 'AARCH64_MEM_ATTRIBUTES',
}

MACHINES_PE = {
    0x0: 'inconnue', 0x14c: 'i386', 0x162: 'MIPS R3000', 0x166: 'MIPS R4000',
    0x168: 'MIPS R10000', 0x169: 'MIPS little-endian WCI v2',
    0x184: 'Alpha AXP', 0x1a2: 'Hitachi SH3', 0x1a3: 'SH3 DSP',
    0x1a6: 'SH4', 0x1a8: 'SH5', 0x1c0: 'ARM little-endian',
    0x1c2: 'ARM Thumb', 0x1c4: 'ARM Thumb-2', 0x1d3: 'AM33',
    0x1f0: 'PowerPC little-endian', 0x1f1: 'PowerPC avec FPU',
    0x200: 'Intel Itanium', 0x284: 'Alpha AXP 64 bits',
    0x366: 'Mitsubishi M32R little-endian', 0x400: 'MIPS16',
    0x666: 'MIPS avec FPU', 0x866: 'MIPS16 avec FPU', 0xaa64: 'ARM64',
    0xebc: 'EFI Byte Code', 0x8664: 'x64 (AMD64/Intel EM64T)',
    0x9041: 'Mitsubishi M32R little-endian',
    0xc0ee: 'RISC-V 32 bits', 0xc1ee: 'RISC-V 64 bits', 0xc2ee: 'RISC-V 128 bits',
    0x5032: 'RISC-V 32 (variante)', 0x5064: 'RISC-V 64 (variante)',
    0x5128: 'RISC-V 128 (variante)',
}

SOUS_SYSTEMES_PE = {
    0: 'inconnu', 1: 'natif', 2: 'GUI Windows', 3: 'console Windows',
    5: 'OS/2 console', 7: 'POSIX console', 8: 'natif Win9x',
    9: 'Windows CE GUI', 10: 'EFI application', 11: 'EFI boot service driver',
    12: 'EFI runtime driver', 13: 'EFI ROM', 14: 'Xbox',
    16: 'Windows bootloader',
}

NOMS_REPERTOIRES_PE = (
    'Export', 'Import', 'Ressources', 'Exceptions', 'Sécurité',
    'Relocalisations de base', 'Debug', 'Architecture', 'Adresse globale',
    'TLS', 'Load Config', 'Bound Import', 'IAT', 'Delay Import',
    'Descripteur COM (.NET)', 'Réservé',
)

TYPES_SEGMENT_MACHO = {
    0x1: 'SEGMENT (32 bits)', 0x2: 'SYMTAB', 0x4: 'THREAD', 0xb: 'DYSYMTAB',
    0xc: 'LOAD_DYLIB', 0xd: 'ID_DYLIB', 0xe: 'LOAD_DYLINKER',
    0x15: 'VERSION_MIN_MACOSX', 0x19: 'SEGMENT_64', 0x1b: 'UUID',
    0x1c: 'RPATH', 0x1d: 'CODE_SIGNATURE', 0x1e: 'SEGMENT_SPLIT_INFO',
    0x21: 'ENCRYPTION_INFO', 0x22: 'DYLD_INFO', 0x24: 'LINKER_OPTION',
    0x25: 'LINKER_OPTIMIZATION_HINT', 0x26: 'VERSION_MIN_TVOS',
    0x27: 'VERSION_MIN_WATCHOS', 0x28: 'NOTE', 0x29: 'BUILD_VERSION',
    0x30: 'SOURCE_VERSION', 0x32: 'LC_MAIN', 0x8000001c: 'REEXPORT_DYLIB',
    0x80000022: 'DYLD_INFO_ONLY', 0x80000024: 'LAZY_LOAD_DYLIB',
    0x80000028: 'MAIN',
}

ARCHITECTURES_MACHO = {
    0x01000000: 'ABI 64 bits', 0x1: 'VAX', 0x6: 'MC680x0', 0x7: 'x86',
    0x8: 'MIPS', 0xa: 'MC98000', 0xb: 'HPPA', 0xc: 'ARM', 0xd: 'MC88000',
    0xe: 'SPARC', 0xf: 'i860', 0x10: 'Alpha', 0x12: 'PowerPC',
}

TYPES_FICHIER_MACHO = {
    1: 'MH_OBJECT', 2: 'MH_EXECUTE', 3: 'MH_FVMLIB', 4: 'MH_CORE',
    5: 'MH_PRELOAD', 6: 'MH_DYLIB', 7: 'MH_DYLINKER', 8: 'MH_BUNDLE',
    9: 'MH_DYLIB_STUB', 10: 'MH_DSYM', 11: 'MH_KEXT_BUNDLE',
}

TYPES_BIND_PE = {
    0x0: 'IMAGE_REL_BASED_ABSOLUTE', 0x1: 'HIGH', 0x2: 'LOW', 0x3: 'HIGHLOW',
    0x4: 'HIGHADJ', 0x5: 'MIPS_JMPADDR', 0x9: 'MIPS_JMPADDR16',
    0xa: 'DIR64',
}

TYPES_RELOCATIONS_ELF = {
    'x86-64': {0: 'R_X86_64_NONE', 1: 'R_X86_64_64', 2: 'R_X86_64_PC32',
               4: 'R_X86_64_PLT32', 5: 'R_X86_64_COPY',
               6: 'R_X86_64_GLOB_DAT', 7: 'R_X86_64_JUMP_SLOT',
               8: 'R_X86_64_RELATIVE', 9: 'R_X86_64_GOTPCREL',
               10: 'R_X86_64_32', 11: 'R_X86_64_32S'},
    'x86': {0: 'R_386_NONE', 1: 'R_386_32', 2: 'R_386_PC32',
            3: 'R_386_GOT32', 4: 'R_386_PLT32', 5: 'R_386_COPY',
            6: 'R_386_GLOB_DAT', 7: 'R_386_JMP_SLOT', 8: 'R_386_RELATIVE'},
    'ARM 64 bits (AArch64)': {0x101: 'R_AARCH64_ABS64', 0x102: 'R_AARCH64_ABS32',
                              0x117: 'R_AARCH64_GLOB_DAT',
                              0x118: 'R_AARCH64_JUMP_SLOT',
                              0x119: 'R_AARCH64_RELATIVE'},
}

BINDAGES_ELF = {0: 'LOCAL', 1: 'GLOBAL', 2: 'WEAK', 10: 'GNU_UNIQUE',
                12: 'LOOS', 14: 'HIOS'}
TYPES_SYMBOLE_ELF = {0: 'NOTYPE', 1: 'OBJECT', 2: 'FUNC', 3: 'SECTION',
                     4: 'FILE', 5: 'COMMON', 6: 'TLS', 10: 'GNU_IFUNC'}
VISIBILITES_ELF = {0: 'DEFAULT', 1: 'INTERNAL', 2: 'HIDDEN', 3: 'PROTECTED'}

# Le type d'un symbole Mach-O est n_type masqué par N_STAB (0xe0) puis N_TYPE
# (0xe). N_EXT (0x1) n'est PAS un type : c'est un bit de portée qui se superpose
# aux autres. Le traiter comme un type ferait d'un symbole externe un « N_UNDF »,
# donc d'une fonction exportée un import.
TYPES_NLS_MACHO = {0x0: 'N_UNDF (non défini)', 0x2: 'N_ABS (absolu)',
                   0xc: 'N_PBUD (pré-lié)', 0xe: 'N_SECT (défini dans une section)'}

FAMILLES = (
    # (nom, famille, test) — ordre significatif : le premier qui correspond gagne
    ('elf', lambda d: d[:4] == b'\x7fELF'),
    ('pe', lambda d: d[:2] == b'MZ' and len(d) > 0x40),
    ('macho', lambda d: d[:4] in (b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe',
                                  b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
                                  b'\xce\xed\xfe\xfa', b'\xcf\xed\xfe\xfa')),
    ('wasm', lambda d: d[:4] == b'\x00asm'),
    ('dex', lambda d: d[:4] == b'dex\n'),
    ('class-java', lambda d: d[:4] == b'\xca\xfe\xba\xbe'),
    ('llvm-bitcode', lambda d: d[:4] == b'BC\xc0\xde'),
    ('archive-ar', lambda d: d[:8] == b'!<arch>\n'),
    ('archive-a-ar', lambda d: d[:8] == b'!<thin>\n'),
    ('zip', lambda d: d[:4] == b'PK\x03\x04' or d[:4] == b'PK\x05\x06'),
    ('gzip', lambda d: d[:2] == b'\x1f\x8b'),
    ('xz', lambda d: d[:6] == b'\xfd7zXZ\x00'),
    ('bzip2', lambda d: d[:3] == b'BZh'),
    ('zstd', lambda d: d[:4] == b'(\xb5/\xfd'),
    ('lz4', lambda d: d[:4] == b'\x04\x22\x4d\x18'),
    ('7z', lambda d: d[:6] == b'7z\xbc\xaf\x27\x1c'),
    ('rar', lambda d: d[:7] == b'Rar!\x1a\x07\x00' or d[:8] == b'Rar!\x1a\x07\x01\x00'),
    ('cab', lambda d: d[:4] == b'MSCF'),
    ('sqlite', lambda d: d[:16] == b'SQLite format 3\x00'),
    ('pyc', lambda d: d[1:4] == b'\r\n\x1a\n' and len(d) >= 16),
    ('pdf', lambda d: d[:5] == b'%PDF-'),
)

EMPAQUETEURS = (
    ('UPX', rb'UPX!'), ('UPX', b'$Info: UPX'),
    ('ASPack', rb'ASPack'), ('Themida', rb'Themida'),
    ('VMProtect', rb'VMProtect'), ('Enigma', rb'Enigma Protector'),
    ('MPRESS', rb'MPRESS'), ('PECompact', rb'PEC2'),
    ('Armadillo', rb'Armadillo'), ('FSG', rb'FSG!'),
)


class Lecteur:
    """Lecture bornée d'un fichier : jamais de levée, toujours une troncature notée.

    Un parseur de binaire écrit avec `struct.unpack_from(fmt, donnees, pos)`
    lève `struct.error` dès que le fichier est plus court que l'en-tête. Sur un
    échantillon tronqué — le cas le plus courant en rétro-ingénierie, puisqu'un
    téléchargement interrompu ou un binaire volontairement amputé donnent cela —
    toute l'analyse disparaît. Ici chaque lecture hors limites rend des zéros et
    inscrit un reproche ; le reste de l'analyse continue.
    """

    def __init__(self, chemin, taille=None):
        self.chemin = Path(chemin)
        self.troncatures = []
        self._memoire = {}
        try:
            self._handle = self.chemin.open('rb')
            self._handle.seek(0, os.SEEK_END)
            self.taille = self._handle.tell()
        except OSError as exc:
            self._handle = None
            self.taille = 0
            self.troncatures.append('Ouverture impossible : %s'
                                    % (exc.strerror or exc))
        if taille is not None:
            self.taille = taille

    def fermer(self):
        if self._handle is not None:
            try:
                self._handle.close()
            except OSError:
                pass
            self._handle = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.fermer()
        return False

    def lire(self, position, nombre):
        """Les octets demandés, complétés par des zéros au-delà de la fin."""
        if nombre <= 0:
            return b''
        if nombre > LECTURE_MAX:
            self._noter('Lecture de %d octets refusée (limite %d) à %d'
                        % (nombre, LECTURE_MAX, position))
            nombre = LECTURE_MAX
        cle = (position, nombre)
        if cle in self._memoire:
            return self._memoire[cle]
        if position < 0:
            self._noter('Position négative %d ramenée à 0' % position)
            position = 0
        if self._handle is None:
            return b'\x00' * nombre
        if position >= self.taille:
            self._noter('Lecture au-delà de la fin du fichier : %d demandé à '
                        'l’octet %d, le fichier fait %d octets'
                        % (nombre, position, self.taille))
            return b'\x00' * nombre
        try:
            self._handle.seek(position)
            donnees = self._handle.read(nombre)
        except OSError as exc:
            self._noter('Lecture impossible à l’octet %d : %s'
                        % (position, exc.strerror or exc))
            return b'\x00' * nombre
        if len(donnees) < nombre:
            self._noter('Fichier tronqué : %d octets demandés à %d, %d obtenus '
                        '(taille %d)' % (nombre, position, len(donnees),
                                         self.taille))
            donnees = donnees + b'\x00' * (nombre - len(donnees))
        # Mémoriser sans plafond de taille ferait tenir jusqu'à 512 lectures de
        # 64 Mo dans un dictionnaire : un en-tête corrompu annoncerait alors une
        # section géante et le processus mourrait de mémoire au lieu de rendre un
        # rapport dégradé.
        if nombre <= 256 * 1024 and len(self._memoire) < 512:
            self._memoire[cle] = donnees
        return donnees

    def lire_reel(self, position, nombre):
        """Les octets RÉELLEMENT présents, sans complément.

        `lire()` complète par des zéros parce que `struct.unpack` exige une
        largeur fixe : un en-tête tronqué doit encore se décoder. Mais un zéro de
        complément et un zéro du fichier sont indiscernables une fois rendus. Sur
        un contenu — vidage hexadécimal, entropie, chaînes — cela fabrique des
        données qui ont l’air vraies : seize zéros affichés à l’offset 0x40000000
        ressemblent à une page de BSS. Tout ce qui se lit comme du contenu passe
        donc par ici, qui rend moins d’octets que demandé plutôt que des octets
        inventés.
        """
        if nombre <= 0:
            return b''
        if position < 0:
            self._noter('Position négative %d ramenée à 0' % position)
            position = 0
        disponible = self.taille - position
        if disponible <= 0:
            self._noter('Rien à lire à l’octet %d : le fichier fait %d octets'
                        % (position, self.taille))
            return b''
        if nombre > disponible:
            self._noter('%d octets demandés à %d, %d seulement présents dans le '
                        'fichier' % (nombre, position, disponible))
            nombre = disponible
        return self.lire(position, nombre)

    def _noter(self, message):
        if message not in self.troncatures and len(self.troncatures) < 40:
            self.troncatures.append(message)

    def entier(self, position, format_):
        """struct.unpack sans jamais lever : les octets manquants valent zéro."""
        donnees = self.lire(position, struct.calcsize(format_))
        try:
            valeurs = struct.unpack(format_, donnees)
        except struct.error as exc:
            self._noter('Décodage impossible à %d (%s) : %s'
                        % (position, format_, exc))
            return (0,)
        return valeurs

    def u8(self, p, boutisme='<'):
        return self.entier(p, boutisme + 'B')[0]

    def u16(self, p, boutisme='<'):
        return self.entier(p, boutisme + 'H')[0]

    def u32(self, p, boutisme='<'):
        return self.entier(p, boutisme + 'I')[0]

    def u64(self, p, boutisme='<'):
        return self.entier(p, boutisme + 'Q')[0]

    def i32(self, p, boutisme='<'):
        return self.entier(p, boutisme + 'i')[0]

    def entier_selon(self, p, largeur, boutisme='<'):
        return (self.u32(p, boutisme) if largeur == 32
                else self.u64(p, boutisme))

    def octets(self, position, nombre):
        return self.lire(position, nombre)

    def chaine(self, position, maximum=CHAINE_MAX):
        """Une chaîne terminée par NUL, bornée pour ne pas lire tout le fichier."""
        donnees = self.lire(position, maximum)
        fin = donnees.find(b'\x00')
        if fin < 0:
            self._noter('Chaîne non terminée à l’octet %d (tronquée à %d)'
                        % (position, maximum))
            return donnees.decode('utf8', 'replace')
        return donnees[:fin].decode('utf8', 'replace')

    def chaine_dans(self, donnees, position, maximum=CHAINE_MAX):
        if position < 0 or position >= len(donnees):
            return ''
        fin = donnees.find(b'\x00', position)
        if fin < 0:
            fin = min(len(donnees), position + maximum)
        return donnees[position:fin].decode('utf8', 'replace')


def entropie(donnees):
    """Entropie de Shannon en bits par octet : 0 pour du constant, 8 pour du bruit.

    C'est le premier indice utile sur un binaire du terrain : une section `.text`
    normale vaut 5,5 à 6,5 ; au-delà de 7,2 elle est compressée ou chiffrée, et
    aucun désassembleur n'en tirera rien tant qu'elle n'est pas décompressée en
    mémoire. Dire « entropie 7,9 » évite à l'utilisateur d'attendre une analyse
    qui ne peut rien donner.
    """
    if not donnees:
        return 0.0
    compte = [0] * 256
    for octet in donnees:
        compte[octet] += 1
    total = len(donnees)
    somme = 0.0
    for nombre in compte:
        if nombre:
            frequence = nombre / total
            somme -= frequence * math.log2(frequence)
    return round(somme, 4)


def empreintes(donnees, echantillon=None):
    """MD5, SHA-1 et SHA-256, avec un avertissement si ce n'est qu'un extrait."""
    sortie = {'octets': len(donnees)}
    for nom, algorithme in (('md5', hashlib.md5), ('sha1', hashlib.sha1),
                            ('sha256', hashlib.sha256)):
        sortie[nom] = algorithme(donnees).hexdigest()
    if echantillon is not None and echantillon < len(donnees):
        sortie['avertissement'] = (
            'Empreintes calculées sur les %d premiers octets seulement : le '
            'fichier en fait %d. Ces empreintes ne correspondent à aucune '
            'référence publique.' % (echantillon, len(donnees)))
    return sortie


def empreintes_fichier(chemin, limite=OCTETS_MAX):
    """Les empreintes d'un fichier lu par morceaux (jamais chargé en entier)."""
    chemin = Path(chemin)
    try:
        taille = chemin.stat().st_size
    except OSError as exc:
        return {'ok': False,
                'erreur': 'Stat impossible : %s' % (exc.strerror or exc)}
    if taille > limite:
        with chemin.open('rb') as flux:
            donnees = flux.read(limite)
        sortie = empreintes(donnees, echantillon=limite)
        sortie['ok'] = True
        sortie['taille_fichier'] = taille
        return sortie
    sortie = empreintes(chemin.read_bytes())
    sortie['ok'] = True
    sortie['taille_fichier'] = taille
    return sortie


def famille(donnees, chemin=''):
    """La famille du fichier, d'après ses octets — et les cas ambigus nommés.

    L'extension n'est PAS une signature : un binaire renommé `.txt` pour passer
    un filtre de messagerie reste un ELF. L'extension n'est utilisée qu'en
    dernier recours, et quand elle contredit les octets, la contradiction est
    rendue plutôt que tranchée en silence.
    """
    sortie = {'ok': True, 'famille': 'inconnue', 'nom': '', 'ambiguite': False,
              'raison': ''}
    if not donnees:
        sortie['raison'] = 'Le fichier est vide : aucune signature à lire.'
        return sortie
    # 0xCAFEBABE sert à la fois aux binaires gras Mach-O et aux .class Java.
    # Trancher au hasard ferait afficher une certitude fausse : les deux lectures
    # sont rendues, et le départage se fait sur les octets qui suivent.
    if donnees[:4] == b'\xca\xfe\xba\xbe':
        if len(donnees) >= 8:
            suivant = struct.unpack('>I', donnees[4:8])[0]
            if 40 <= suivant <= 70:
                mineur = struct.unpack('>H', donnees[4:6])[0]
                if 0 <= mineur <= 3:
                    sortie.update({'famille': 'class-java',
                                   'nom': 'classe Java (bytecode)',
                                   'raison': '0xCAFEBABE suivi d’un numéro de '
                                             'version %d : c’est un .class, pas '
                                             'un binaire gras Mach-O.' % suivant})
                    return sortie
            if 0 < suivant <= 64:
                sortie.update({'famille': 'macho', 'nom': 'Mach-O gras (universel)',
                               'raison': '0xCAFEBABE suivi d’un nombre '
                                         'd’architectures (%d) plausible.' % suivant})
                return sortie
        sortie.update({'famille': 'ambigue', 'nom': '0xCAFEBABE',
                       'ambiguite': True,
                       'raison': '0xCAFEBABE est à la fois la signature d’un '
                                 'binaire gras Mach-O et celle d’une classe '
                                 'Java, et les octets suivants ne permettent pas '
                                 'de trancher. Les deux lectures sont possibles.'})
        return sortie
    if donnees[:4] == b'\x7fELF':
        if len(donnees) < 16:
            sortie.update({'famille': 'elf', 'nom': 'ELF (en-tête tronqué)',
                           'raison': 'La signature ELF est là mais l’en-tête '
                                     'd’identification s’arrête avant l’octet 16.'})
            return sortie
        classe = {1: '32 bits', 2: '64 bits'}.get(donnees[4], 'inconnue')
        boutisme = {1: 'little-endian', 2: 'big-endian'}.get(donnees[5], 'inconnu')
        sortie.update({'famille': 'elf',
                       'nom': 'ELF %s %s' % (classe, boutisme),
                       'raison': 'Signature \\x7fELF, classe %d, boutisme %d, '
                                 'version d’en-tête %d.'
                                 % (donnees[4], donnees[5], donnees[6])})
        return sortie
    if donnees[:2] == b'MZ':
        sortie.update({'famille': 'pe', 'nom': 'PE (MZ/DOS + PE)',
                       'raison': 'Signature MZ ; l’en-tête PE réel se lit à '
                                 'l’adresse indiquée par le champ e_lfanew '
                                 '(octet 0x3C).'})
        return sortie
    for nom, test in FAMILLES:
        if nom in ('elf', 'pe', 'macho', 'class-java'):
            continue
        try:
            if test(donnees):
                sortie.update({'famille': nom, 'nom': nom,
                               'raison': 'Signature reconnue en tête de fichier.'})
                return sortie
        except Exception:
            continue
    if donnees[:4] in (b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe'):
        largeur = 64 if donnees[1] == 0xfa else 32
        sortie.update({'famille': 'macho',
                       'nom': 'Mach-O %d bits' % largeur,
                       'raison': 'Signature MH_MAGIC%s inversée en tête.'
                                 % ('_64' if largeur == 64 else '')})
        return sortie
    if donnees[:4] in (b'\xbe\xba\xfe\xca', b'\xce\xed\xfe\xfa', b'\xcf\xed\xfe\xfa'):
        sortie.update({'famille': 'macho', 'nom': 'Mach-O (autre boutisme)',
                       'raison': 'Signature Mach-O lue dans l’autre boutisme.'})
        return sortie
    if donnees[:4] == b'BC\xc0\xde':
        sortie.update({'famille': 'llvm-bitcode', 'nom': 'bitcode LLVM',
                       'raison': 'Signature BC\\xc0\\xde (0xDEADC0DE en '
                                 'little-endian).'})
        return sortie
    if donnees[:4] == b'\x00asm':
        version = struct.unpack('<I', donnees[4:8])[0] if len(donnees) >= 8 else 0
        sortie.update({'famille': 'wasm', 'nom': 'WebAssembly binaire',
                       'raison': 'Signature \\0asm, version de format %d.' % version})
        return sortie
    if donnees[1:4] == b'\r\n\x1a\n' and len(donnees) >= 16:
        sortie.update({'famille': 'pyc', 'nom': 'bytecode Python compilé',
                       'raison': 'Le second groupe d’octets d’un .pyc est '
                                 'toujours \\r\\n\\x1a\\n ; le premier est le '
                                 'numéro magique de la version de Python.'})
        return sortie
    extension = Path(str(chemin)).suffix.lower().lstrip('.')
    if extension:
        sortie.update({'famille': 'inconnue', 'ambiguite': True,
                       'raison': 'Aucune signature connue en tête de fichier. '
                                 'L’extension « .%s » n’est pas une preuve : un '
                                 'binaire renommé reste un binaire. Le contenu '
                                 'est affiché tel quel.' % extension})
    else:
        sortie['raison'] = ('Aucune signature connue. Les premiers octets sont '
                            '%s.' % binascii.hexlify(donnees[:16]).decode())
    return sortie


# --------------------------------------------------------------------------
# ELF
# --------------------------------------------------------------------------

def lire_elf(lecteur):
    """En-tête, sections, segments, symboles et dynamique d'un ELF.

    La structure est lue deux fois : d'abord les champs d'en-tête pour connaître
    la largeur (32 ou 64) et le boutisme, puis le reste avec le bon format. Un
    parseur qui supposerait du 64 bits little-endian lirait des tailles absurdes
    sur un MIPS big-endian et rendrait un rapport faux sans le dire.
    """
    resultat = {'format': 'ELF', 'sections': [], 'segments': [], 'symboles': [],
                'dynamique': [], 'imports': [], 'exports': [], 'notes': [],
                'relocations': [], 'notes_lecture': []}
    identification = lecteur.octets(0, 16)
    if identification[:4] != b'\x7fELF':
        resultat['erreur'] = 'Ce fichier n’est pas un ELF (signature absente).'
        return resultat
    classe = identification[4]
    bout = identification[5]
    if classe not in (1, 2):
        resultat['erreur'] = ('La classe ELF %d n’existe pas (1 = 32 bits, '
                              '2 = 64 bits) : l’en-tête est corrompu.' % classe)
        return resultat
    if bout not in (1, 2):
        resultat['erreur'] = ('Le boutisme ELF %d n’existe pas (1 = petit, '
                              '2 = grand) : l’en-tête est corrompu.' % bout)
        return resultat
    boutisme = '<' if bout == 1 else '>'
    largeur = 32 if classe == 1 else 64
    resultat['classe'] = '%d bits' % largeur
    resultat['boutisme'] = 'little-endian' if bout == 1 else 'big-endian'
    resultat['version_identification'] = identification[6]
    resultat['abi'] = identification[7]
    abis = {0: 'System V', 1: 'HP-UX', 2: 'NetBSD', 3: 'Linux', 6: 'Solaris',
            7: 'AIX', 8: 'IRIX', 9: 'FreeBSD', 10: 'Tru64', 11: 'Novell Modesto',
            12: 'OpenBSD', 13: 'OpenVMS', 14: 'HP NonStop', 15: 'AROS',
            16: 'FenixOS', 17: 'CloudABI', 97: 'ARM', 255: 'standalone'}
    resultat['abi_nom'] = abis.get(identification[7], 'inconnue (%d)'
                                   % identification[7])

    if largeur == 64:
        (type_, machine, version, entree, phoff, shoff, drapeaux, taille_en_tete,
         phentsize, phnum, shentsize, shnum, shstrndx) = lecteur.entier(
            16, boutisme + 'HHIQQQIHHHHHH')
    else:
        (type_, machine, version, entree, phoff, shoff, drapeaux, taille_en_tete,
         phentsize, phnum, shentsize, shnum, shstrndx) = lecteur.entier(
            16, boutisme + 'HHIIIIIHHHHHH')
    resultat.update({
        'type': TYPES_ELF.get(type_, 'inconnu (%d)' % type_),
        'type_brut': type_,
        'machine': MACHINES_ELF.get(machine, 'inconnue (%d)' % machine),
        'machine_brute': machine,
        'version': version,
        'entree': entree,
        'entree_hex': '0x%x' % entree,
        'phoff': phoff, 'shoff': shoff, 'drapeaux': drapeaux,
        'taille_en_tete': taille_en_tete,
        'phentsize': phentsize, 'phnum': phnum,
        'shentsize': shentsize, 'shnum': shnum, 'shstrndx': shstrndx,
        'pie': type_ == 3,
        'executable': type_ == 2,
        'objet_partage': type_ == 3,
        'core': type_ == 4,
    })
    resultat['notes_lecture'] = list(lecteur.troncatures)

    # --- sections ------------------------------------------------------------
    noms_sections = b''
    entrees = []
    for index in range(shnum):
        base = shoff + index * shentsize
        if largeur == 64:
            (nom, type_s, drapeaux_s, adresse, decalage, taille, lien, info,
             alignement, entsize) = lecteur.entier(base, boutisme + 'IIQQQQIIQQ')
        else:
            (nom, type_s, drapeaux_s, adresse, decalage, taille, lien, info,
             alignement, entsize) = lecteur.entier(base, boutisme + 'IIIIIIIIII')
        entrees.append({'index': index, 'nom_brut': nom, 'type_brut': type_s,
                        'type': TYPES_SECTION_ELF.get(type_s, '0x%x' % type_s),
                        'drapeaux_bruts': drapeaux_s,
                        'drapeaux': ','.join(n for v, n in FLAGS_SECTION_ELF
                                             if drapeaux_s & v) or '-',
                        'adresse': adresse, 'decalage': decalage,
                        'taille': taille, 'lien': lien, 'info': info,
                        'alignement': alignement, 'entsize': entsize})
    if shstrndx < len(entrees):
        table = entrees[shstrndx]
        noms_sections = lecteur.octets(table['decalage'], table['taille'])
    else:
        if shnum:
            resultat['avertissement'] = (
                'shstrndx = %d mais il n’y a que %d sections : la table des noms '
                'de sections est introuvable, les noms sont rendus vides.'
                % (shstrndx, shnum))
    for entree in entrees:
        entree['nom'] = lecteur.chaine_dans(noms_sections, entree['nom_brut'])
        if entree['type'] == 'NOBITS':
            entree['presente_dans_le_fichier'] = False
            entree['entropie'] = None
        else:
            entree['presente_dans_le_fichier'] = True
        resultat['sections'].append(entree)

    # --- segments ------------------------------------------------------------
    for index in range(phnum):
        base = phoff + index * phentsize
        if largeur == 64:
            (type_p, drapeaux_p, decalage, vaddr, paddr, filesz, memsz,
             alignement) = lecteur.entier(base, boutisme + 'IIQQQQQQ')
        else:
            (type_p, decalage, vaddr, paddr, filesz, memsz, drapeaux_p,
             alignement) = lecteur.entier(base, boutisme + 'IIIIIIII')
        resultat['segments'].append({
            'index': index,
            'type': TYPES_SEGMENT_ELF.get(type_p, '0x%x' % type_p),
            'type_brut': type_p, 'drapeaux_bruts': drapeaux_p,
            'drapeaux': ('%s%s%s' % ('R' if drapeaux_p & 4 else '-',
                                     'W' if drapeaux_p & 2 else '-',
                                     'E' if drapeaux_p & 1 else '-')),
            'decalage': decalage, 'vaddr': vaddr, 'paddr': paddr,
            'vaddr_hex': '0x%x' % vaddr,
            'taille_fichier': filesz, 'taille_memoire': memsz,
            'alignement': alignement,
            'ecart_memoire': memsz - filesz,
        })

    # --- table dynamique -----------------------------------------------------
    taille_entree = 16 if largeur == 64 else 8
    format_entree = boutisme + ('QQ' if largeur == 64 else 'II')
    dynamique_brute = None
    for segment in resultat['segments']:
        if segment['type'] == 'DYNAMIC' and segment['taille_fichier']:
            dynamique_brute = lecteur.octets(segment['decalage'],
                                             segment['taille_fichier'])
            break
    if dynamique_brute is None:
        for section in resultat['sections']:
            if section['type'] == 'DYNAMIC' and section['taille']:
                dynamique_brute = lecteur.octets(section['decalage'],
                                                 section['taille'])
                break
    entrees_dyn = []
    if dynamique_brute:
        position = 0
        while position + taille_entree <= len(dynamique_brute):
            etiquette, valeur = struct.unpack_from(format_entree, dynamique_brute,
                                                   position)
            position += taille_entree
            if etiquette == 0:
                break
            entrees_dyn.append({'etiquette': etiquette, 'valeur': valeur,
                                'valeur_hex': '0x%x' % valeur})
            if len(entrees_dyn) > 512:
                resultat['avertissement_dyn'] = (
                    'Plus de 512 entrées dynamiques : la liste est coupée, la '
                    'table est probablement corrompue.')
                break
    NOMS_ETIQUETTES = {
        1: 'NEEDED', 2: 'PLTRELSZ', 3: 'PLTGOT', 4: 'HASH', 5: 'STRTAB',
        6: 'SYMTAB', 7: 'RELA', 8: 'RELASZ', 9: 'RELAENT', 10: 'STRSZ',
        11: 'SYMENT', 12: 'INIT', 13: 'FINI', 14: 'SONAME', 15: 'RPATH',
        16: 'SYMBOLIC', 17: 'REL', 18: 'RELSZ', 19: 'RELENT', 20: 'PLTREL',
        21: 'DEBUG', 22: 'TEXTREL', 23: 'JMPREL', 24: 'BIND_NOW',
        25: 'INIT_ARRAY', 26: 'FINI_ARRAY', 27: 'INIT_ARRAYSZ',
        28: 'FINI_ARRAYSZ', 29: 'RUNPATH', 30: 'FLAGS', 32: 'PREINIT_ARRAY',
        0x6ffffef5: 'GNU_HASH', 0x6ffffff0: 'VERSYM', 0x6ffffffc: 'VERDEF',
        0x6ffffffe: 'VERNEED', 0x6fffffff: 'VERNEEDNUM',
    }
    for entree in entrees_dyn:
        entree['nom'] = NOMS_ETIQUETTES.get(entree['etiquette'],
                                            '0x%x' % entree['etiquette'])
    resultat['dynamique'] = entrees_dyn

    # La table des chaînes dynamique est nécessaire pour donner un NOM aux
    # bibliothèques et aux symboles ; sans elle, la liste serait une suite de
    # nombres, ce qui ne sert à rien.
    table_chaines = _table_depuis_etiquette(lecteur, entrees_dyn, 5,
                                            resultat['sections'])
    for entree in entrees_dyn:
        if entree['nom'] in ('NEEDED', 'SONAME', 'RPATH', 'RUNPATH'):
            entree['texte'] = lecteur.chaine_dans(table_chaines, entree['valeur'])
            if entree['nom'] == 'NEEDED' and entree['texte']:
                resultat['imports'].append(entree['texte'])
        elif entree['nom'] == 'FLAGS':
            drapeaux = []
            for valeur, nom in ((0x1, 'ORIGIN'), (0x2, 'SYMBOLIC'),
                                (0x4, 'TEXTREL'), (0x8, 'BIND_NOW'),
                                (0x10, 'STATIC_TLS')):
                if entree['valeur'] & valeur:
                    drapeaux.append(nom)
            entree['texte'] = ','.join(drapeaux) or '-'
    resultat['soname'] = next(
        (e['texte'] for e in entrees_dyn if e['nom'] == 'SONAME'
         and e.get('texte')), '')
    resultat['rpath'] = [e.get('texte', '') for e in entrees_dyn
                         if e['nom'] in ('RPATH', 'RUNPATH') and e.get('texte')]
    resultat['interprete'] = _interprete(lecteur, resultat['segments'])
    resultat['statique'] = bool(resultat['type_brut'] == 2
                                and not resultat['imports']
                                and not resultat['interprete'])
    if resultat['statique']:
        resultat['note_statique'] = (
            'Aucune bibliothèque dynamique et aucun interpréteur : la liaison '
            'est statique. Les imports ne révèlent donc presque rien ; il faut '
            'passer par les fonctions et les chaînes.')

    # --- symboles ------------------------------------------------------------
    for type_attendu, cle in ((2, 'symboles'), (11, 'symboles_dynamiques')):
        table = _table_symboles(lecteur, resultat['sections'], entrees_dyn,
                                type_attendu, boutisme, largeur, resultat)
        resultat[cle] = table
    if resultat.get('symboles_dynamiques'):
        for symbole in resultat['symboles_dynamiques']:
            if symbole['importe']:
                resultat.setdefault('imports_fonctions', []).append(symbole['nom'])
            elif symbole['exporte']:
                resultat['exports'].append(symbole['nom'])
    resultat['depouille'] = bool(
        not resultat.get('symboles') and resultat['type_brut'] in (2, 3))
    if resultat['depouille']:
        resultat['note_depouille'] = (
            'Aucune table .symtab : le binaire est dépouillé (strip). Les noms '
            'de fonctions visibles viennent alors de .dynsym, qui ne contient '
            'que les symboles liés dynamiquement. C’est le cas normal d’un '
            'binaire distribué.')

    # Le nom du compilateur est écrit par GCC et clang dans .comment, pas dans
    # une note : le chercher ailleurs ne rendrait jamais rien sur un vrai
    # binaire, et le panneau afficherait « compilateur inconnu » pour tout.
    for section in resultat['sections']:
        if section['nom'] == '.comment' and section['taille']:
            brut = lecteur.octets(section['decalage'],
                                  min(section['taille'], 512))
            morceaux = [m.decode('utf8', 'replace') for m in brut.split(b'\x00')
                        if m]
            if morceaux:
                resultat['commentaire'] = morceaux[0]
                resultat['commentaires'] = morceaux
            break

    # --- notes ---------------------------------------------------------------
    for section in resultat['sections']:
        if section['type'] == 'NOTE' and section['taille']:
            resultat['notes'].extend(_lire_notes(lecteur, section['decalage'],
                                                 section['taille'], boutisme,
                                                 section.get('nom', '')))

    # --- relocations ---------------------------------------------------------
    resultat['relocations'] = _lire_relocations(lecteur, resultat, boutisme,
                                                largeur, entrees_dyn)
    resultat['notes_lecture'] = list(lecteur.troncatures)
    resultat['resume'] = resume_elf(resultat)
    return resultat


def _table_depuis_etiquette(lecteur, entrees_dyn, etiquette, sections):
    """Le contenu d'une table désignée par une étiquette dynamique, ou b''."""
    adresse = None
    taille = 0
    for entree in entrees_dyn:
        if entree['etiquette'] == etiquette:
            adresse = entree['valeur']
        elif entree['etiquette'] == etiquette + 5:      # STRSZ suit STRTAB
            taille = entree['valeur']
    if adresse is None:
        return b''
    # Une adresse VIRTUELLE doit être convertie en décalage fichier : la lire
    # telle quelle donnerait une table de chaînes prise au mauvais endroit, donc
    # des noms de bibliothèques absurdes mais plausibles.
    decalage = _virtuel_vers_fichier(sections, adresse)
    if decalage is None:
        return b''
    if not taille:
        taille = CHAINE_MAX * 64
    return lecteur.octets(decalage, min(taille, LECTURE_MAX))


def _virtuel_vers_fichier(sections, adresse):
    for section in sections:
        if not section['adresse']:
            continue
        if section['type'] == 'NOBITS':
            continue
        if section['adresse'] <= adresse < section['adresse'] + section['taille']:
            return section['decalage'] + (adresse - section['adresse'])
    return None


def _interprete(lecteur, segments):
    for segment in segments:
        if segment['type'] == 'INTERP' and segment['taille_fichier']:
            brut = lecteur.octets(segment['decalage'],
                                  min(segment['taille_fichier'], 512))
            return brut.split(b'\x00')[0].decode('utf8', 'replace')
    return ''


def _table_symboles(lecteur, sections, entrees_dyn, type_attendu, boutisme,
                    largeur, resultat):
    """Les symboles d'une table (.symtab ou .dynsym), avec leurs noms résolus."""
    section = None
    for candidate in sections:
        if candidate['type_brut'] == type_attendu:
            section = candidate
            break
    if section is None:
        etiquette = 6 if type_attendu == 2 else 11
        for entree in entrees_dyn:
            if entree['etiquette'] == etiquette:
                section = {'decalage': None, 'adresse': entree['valeur'],
                           'taille': 0, 'entsize': 24 if largeur == 64 else 16,
                           'lien': -1, 'nom': '.dynsym'}
                break
        if section is None:
            return []
    entsize = section.get('entsize') or (24 if largeur == 64 else 16)
    if entsize not in (16, 24):
        resultat.setdefault('avertissements_symboles', []).append(
            'La taille d’entrée de la table de symboles « %s » est %d, ni 16 ni '
            '24 : la table n’est pas lisible.'
            % (section.get('nom', '?'), entsize))
        return []
    nombre = section['taille'] // entsize if section['taille'] else 0
    if not nombre:
        return []
    if nombre > 400000:
        resultat.setdefault('avertissements_symboles', []).append(
            'La table « %s » annoncerait %d symboles : c’est invraisemblable, '
            'la lecture s’arrête à 400 000.'
            % (section.get('nom', '?'), nombre))
        nombre = 400000
    # Les noms viennent de la section pointée par sh_link. Se rabattre sur la
    # première STRTAB trouvée produirait des noms décalés, donc faux.
    chaines = b''
    lien = section.get('lien', -1)
    if isinstance(lien, int) and 0 <= lien < len(sections):
        cible = sections[lien]
        if cible['type_brut'] == 3 and cible['taille']:
            chaines = lecteur.octets(cible['decalage'],
                                     min(cible['taille'], LECTURE_MAX))
    if not chaines:
        for candidate in sections:
            if candidate['type_brut'] == 3 and candidate['taille']:
                chaines = lecteur.octets(candidate['decalage'],
                                         min(candidate['taille'], LECTURE_MAX))
                resultat.setdefault('avertissements_symboles', []).append(
                    'sh_link de « %s » ne pointe pas vers une table de chaînes : '
                    'les noms ont été cherchés dans la première STRTAB trouvée, '
                    'ils peuvent être décalés.' % section.get('nom', '?'))
                break
    if not chaines:
        resultat.setdefault('avertissements_symboles', []).append(
            'Aucune table de chaînes associée à « %s » : les symboles sont '
            'rendus sans nom.' % section.get('nom', '?'))
    sortie = []
    base = section['decalage'] if section.get('decalage') is not None else 0
    if section.get('decalage') is None:
        base = _virtuel_vers_fichier(sections, section['adresse']) or 0
    for index in range(nombre):
        position = base + index * entsize
        if largeur == 64:
            nom_brut, info, autre, shndx, valeur, taille = lecteur.entier(
                position, boutisme + 'IBBHQQ')
        else:
            nom_brut, valeur, taille, info, autre, shndx = lecteur.entier(
                position, boutisme + 'IIIBBH')
        liaison = BINDAGES_ELF.get(info >> 4, 'inconnue (%d)' % (info >> 4))
        type_s = TYPES_SYMBOLE_ELF.get(info & 0xf, 'inconnu (%d)' % (info & 0xf))
        visibilite = VISIBILITES_ELF.get(autre & 3, 'inconnue (%d)' % (autre & 3))
        nom = lecteur.chaine_dans(chaines, nom_brut)
        if shndx == 0:
            section_nom = 'UNDEF (importé)'
        elif shndx == 0xfff1:
            section_nom = 'ABS'
        elif shndx == 0xfff2:
            section_nom = 'COMMON'
        elif shndx < len(sections):
            section_nom = sections[shndx].get('nom', '?')
        else:
            section_nom = 'index hors limites (%d)' % shndx
        sortie.append({
            'index': index, 'nom': nom, 'valeur': valeur,
            'valeur_hex': '0x%x' % valeur, 'taille': taille,
            'liaison': liaison, 'type': type_s, 'visibilite': visibilite,
            'shndx': shndx, 'section': section_nom,
            'importe': shndx == 0 and liaison in ('GLOBAL', 'WEAK'),
            'exporte': (shndx not in (0, 0xfff1, 0xfff2)
                        and liaison in ('GLOBAL', 'WEAK')
                        and type_s in ('FUNC', 'OBJECT')),
        })
    return sortie


def _lire_notes(lecteur, decalage, taille, boutisme, nom_section):
    """Les notes ELF : build-id, nom du compilateur, ABI, propriétés GNU."""
    brut = lecteur.octets(decalage, min(taille, 1 << 20))
    notes = []
    position = 0
    while position + 12 <= len(brut) and len(notes) < 64:
        taille_nom, taille_desc, type_ = struct.unpack_from(boutisme + 'III',
                                                            brut, position)
        position += 12
        if taille_nom > 4096 or taille_desc > (1 << 20):
            break
        nom = brut[position:position + taille_nom].rstrip(b'\x00')
        position += (taille_nom + 3) & ~3
        description = brut[position:position + taille_desc]
        position += (taille_desc + 3) & ~3
        entree = {'section': nom_section, 'nom': nom.decode('utf8', 'replace'),
                  'type': type_, 'type_hex': '0x%x' % type_,
                  'description_octets': len(description)}
        noms_types = {1: 'NT_ABI_TAG', 2: 'NT_HWCAP', 3: 'NT_BUILD_ID',
                      4: 'NT_GNU_GOLD_VERSION', 5: 'NT_GNU_PROGRAM_HEADERS',
                      6: 'NT_GNU_PROPERTY_TYPE_0', 7: 'NT_FDOFILENAME',
                      0x100: 'NT_GNU_BUILD_ATTRIBUTE_OPEN'}
        entree['type_nom'] = noms_types.get(type_, '')
        if type_ == 3 and description:
            entree['build_id'] = binascii.hexlify(description).decode()
        elif nom == b'GNU' and description and len(description) >= 4:
            entree['texte'] = description[:64].decode('utf8', 'replace').strip()
        elif description and len(description) < 256:
            try:
                entree['texte'] = description.split(b'\x00')[0].decode('utf8')
            except UnicodeDecodeError:
                entree['hexadecimal'] = binascii.hexlify(description[:64]).decode()
        notes.append(entree)
    return notes


def _lire_relocations(lecteur, resultat, boutisme, largeur, entrees_dyn):
    """Les relocations RELA et REL, limitées pour rester lisible.

    Un binaire lié dynamiquement peut porter des centaines de milliers de
    relocations : tout rendre saturerait le panneau sans rien apprendre. La
    borne est annoncée plutôt que silencieuse.
    """
    LIMITE = 2000
    sortie = []
    tronque = False
    compte_total = 0
    tables = []
    for entree in entrees_dyn:
        if entree['nom'] == 'RELA' or entree['nom'] == 'JMPREL':
            tables.append((entree['nom'], entree['valeur']))
    for section in resultat['sections']:
        if section['type'] in ('RELA', 'REL') and section['taille']:
            tables.append((section.get('nom', '.rela'), section['decalage']))
    vues = set()
    for nom, adresse in tables:
        if adresse in vues:
            continue
        vues.add(adresse)
        section = next((s for s in resultat['sections']
                        if s['decalage'] == adresse and s['type'] in ('RELA', 'REL')),
                       None)
        if section is None:
            continue
        entsize = section.get('entsize') or (24 if largeur == 64 else 12)
        rela = section['type'] == 'RELA'
        nombre = section['taille'] // entsize if entsize else 0
        compte_total += nombre
        symboles = resultat.get('symboles_dynamiques') or resultat.get('symboles') or []
        noms_relocations = TYPES_RELOCATIONS_ELF.get(resultat.get('machine', ''), {})
        for index in range(nombre):
            if len(sortie) >= LIMITE:
                tronque = True
                break
            position = section['decalage'] + index * entsize
            if largeur == 64:
                if rela:
                    offset, info, addend = lecteur.entier(position,
                                                          boutisme + 'QQq')
                else:
                    offset, info = lecteur.entier(position, boutisme + 'QQ')
                    addend = 0
            else:
                if rela:
                    offset, info, addend = lecteur.entier(position,
                                                          boutisme + 'IIi')
                else:
                    offset, info = lecteur.entier(position, boutisme + 'II')
                    addend = 0
            indice = info >> 32 if largeur == 64 else info >> 8
            type_r = info & 0xffffffff if largeur == 64 else info & 0xff
            symbole = (symboles[indice]['nom'] if 0 <= indice < len(symboles)
                       else '')
            sortie.append({
                'table': section.get('nom', nom), 'decalage': offset,
                'decalage_hex': '0x%x' % offset,
                'type': noms_relocations.get(type_r, '0x%x' % type_r),
                'symbole': symbole, 'addend': addend,
                'addend_hex': '0x%x' % (addend & ((1 << 64) - 1)),
            })
        if tronque:
            break
    resultat['relocations_total'] = compte_total
    if tronque:
        resultat['relocations_tronquees'] = (
            '%d relocations au total, les %d premières sont rendues.'
            % (compte_total, LIMITE))
    return sortie


def resume_elf(elf):
    """Un résumé lisible : architecture, type, ce qui manque, ce qui est notable."""
    notes = []
    notes.append('%s %s, %s' % (elf.get('machine', '?'), elf.get('classe', '?'),
                                elf.get('boutisme', '?')))
    notes.append('Type %s%s' % (elf.get('type', '?'),
                                ' (position indépendant)' if elf.get('pie')
                                else ''))
    if elf.get('interprete'):
        notes.append('Interpréteur %s' % elf['interprete'])
    if elf.get('imports'):
        notes.append('%d bibliothèque(s) requise(s) : %s'
                     % (len(elf['imports']), ', '.join(elf['imports'][:8])))
    build = next((n.get('build_id') for n in elf.get('notes', [])
                  if n.get('build_id')), '')
    if build:
        notes.append('Build ID %s' % build[:40])
    if elf.get('commentaire'):
        notes.append('Compilateur %s' % elf['commentaire'][:90])
    for section in elf.get('sections', []):
        if section.get('entropie') is not None and section['entropie'] > 7.2 \
                and section['taille'] > 512:
            notes.append('Section « %s » d’entropie %.2f : compressée ou '
                         'chiffrée' % (section.get('nom'), section['entropie']))
    for avertissement in elf.get('avertissements_symboles', ()):
        notes.append(avertissement)
    if elf.get('note_depouille'):
        notes.append(elf['note_depouille'])
    if elf.get('note_statique'):
        notes.append(elf['note_statique'])
    if elf.get('relocations_tronquees'):
        notes.append(elf['relocations_tronquees'])
    return notes


# --------------------------------------------------------------------------
# PE
# --------------------------------------------------------------------------

def lire_pe(lecteur):
    """En-têtes, sections, imports, exports et ressources d'un PE (Windows)."""
    resultat = {'format': 'PE', 'sections': [], 'imports': [], 'exports': [],
                'repertoires': [], 'ressources': [], 'notes_lecture': [],
                'relocations': []}
    if lecteur.octets(0, 2) != b'MZ':
        resultat['erreur'] = ('Ce fichier ne commence pas par MZ : ce n’est pas '
                              'un exécutable Windows.')
        return resultat
    e_lfanew = lecteur.u32(0x3c)
    if e_lfanew == 0 or e_lfanew >= lecteur.taille:
        resultat['erreur'] = (
            'e_lfanew (octet 0x3C) vaut %d, hors du fichier (%d octets) : '
            'l’en-tête PE est introuvable ou le fichier est tronqué.'
            % (e_lfanew, lecteur.taille))
        return resultat
    if lecteur.octets(e_lfanew, 4) != b'PE\x00\x00':
        resultat['erreur'] = (
            'À l’octet %d indiqué par e_lfanew, la signature PE\\0\\0 est '
            'absente (lu %r) : en-tête corrompu.'
            % (e_lfanew, lecteur.octets(e_lfanew, 4)))
        return resultat
    coff = e_lfanew + 4
    (machine, nombre_sections, horodatage, pointeur_symboles, nombre_symboles,
     taille_optionnel, caracteristiques) = lecteur.entier(coff, '<HHIIIHH')
    resultat.update({
        'machine': MACHINES_PE.get(machine, 'inconnue (0x%x)' % machine),
        'machine_brute': machine,
        'nombre_sections': nombre_sections,
        'horodatage': horodatage,
        'horodatage_texte': _heure(horodatage),
        'symboles_coff': nombre_symboles,
        'caracteristiques_brutes': caracteristiques,
        'caracteristiques': _drapeaux(caracteristiques, (
            (0x1, 'RELOCS_STRIPPED'), (0x2, 'EXECUTABLE_IMAGE'),
            (0x4, 'LINE_NUMS_STRIPPED'), (0x8, 'LOCAL_SYMS_STRIPPED'),
            (0x20, 'LARGE_ADDRESS_AWARE'), (0x100, '32BIT_MACHINE'),
            (0x200, 'DEBUG_STRIPPED'), (0x2000, 'DLL'),
            (0x8000, 'SYSTEM'), (0x1000, 'NET_RUN_FROM_SWAP'),
        )),
        'est_une_dll': bool(caracteristiques & 0x2000),
    })
    optionnel = coff + 20
    magique = lecteur.u16(optionnel)
    if magique not in (0x10b, 0x20b):
        resultat['erreur'] = (
            'Le numéro magique de l’en-tête optionnel est 0x%x : ni 0x10b '
            '(PE32) ni 0x20b (PE32+). L’en-tête est corrompu, ou ce n’est pas '
            'un PE standard.' % magique)
        return resultat
    resultat['magique'] = 'PE32+ (64 bits)' if magique == 0x20b else 'PE32 (32 bits)'
    resultat['largeur'] = 64 if magique == 0x20b else 32
    resultat['lieur'] = '%d.%d' % (lecteur.u8(optionnel + 2),
                                    lecteur.u8(optionnel + 3))
    # Champs standard : identiques en PE32 et PE32+ (la différence vient après).
    (taille_code, taille_donnees_init, taille_donnees_non_init, adresse_entree,
     base_code) = lecteur.entier(optionnel + 4, '<IIIII')
    resultat.update({'taille_code': taille_code,
                     'taille_donnees_initialisees': taille_donnees_init,
                     'taille_donnees_non_initialisees': taille_donnees_non_init,
                     'adresse_entree': adresse_entree,
                     'entree_hex': '0x%x' % adresse_entree,
                     'base_code': base_code})
    # PE32 porte un champ BaseOfData que PE32+ n\u2019a pas, et ImageBase y est
    # sur 4 octets au lieu de 8 : les deux différences se compensent exactement
    # à partir de MajorOperatingSystemVersion, qui tombe dans les deux cas à
    # optionnel + 40. Les quatre champs de taille de pile et de tas qui suivent
    # sont en revanche sur 4 octets en PE32 et 8 en PE32+, donc les répertoires
    # de données commencent à +96 en PE32 et +112 en PE32+. Se tromper d\u2019un
    # seul de ces décalages ferait lire des RVA absurdes, et une RVA absurde
    # convertie en décalage donne des noms de DLL inventés : des chaînes
    # plausibles mais fausses, le pire résultat possible.
    if resultat['largeur'] == 32:
        base_donnees, base_image = lecteur.entier(optionnel + 24, '<II')
        resultat['base_donnees'] = base_donnees
        taille_champ = 4
        format_tailles = '<IIII'
        debut_repertoires = optionnel + 96
        attendu_optionnel = 224
    else:
        base_image = lecteur.u64(optionnel + 24)
        taille_champ = 8
        format_tailles = '<QQQQ'
        debut_repertoires = optionnel + 112
        attendu_optionnel = 240
    alignement_section, alignement_fichier = lecteur.entier(optionnel + 32, '<II')
    apres = optionnel + 40
    resultat.update({
        'base_image': base_image, 'base_image_hex': '0x%x' % base_image,
        'alignement_section': alignement_section,
        'alignement_fichier': alignement_fichier,
    })
    (systeme_majeur, systeme_mineur, image_majeur, image_mineur,
     sous_systeme_majeur, sous_systeme_mineur) = lecteur.entier(apres, '<HHHHHH')
    resultat.update({
        'version_systeme': '%d.%d' % (systeme_majeur, systeme_mineur),
        'version_image': '%d.%d' % (image_majeur, image_mineur),
        'version_sous_systeme': '%d.%d' % (sous_systeme_majeur,
                                           sous_systeme_mineur)})
    (valeur_win32, taille_image, taille_en_tetes, somme_controle,
     sous_systeme, dll_caracteristiques) = lecteur.entier(apres + 12, '<IIIIHH')
    reserve_pile, valide_pile, reserve_tas, valide_tas = lecteur.entier(
        apres + 32, format_tailles)
    drapeaux_chargeur, nombre_repertoires = lecteur.entier(
        apres + 32 + 4 * taille_champ, '<II')
    if taille_optionnel != attendu_optionnel:
        resultat['avertissement_en_tete'] = (
            'SizeOfOptionalHeader vaut %d alors qu\u2019un %s standard fait %d : '
            'les répertoires de données sont cherchés à l\u2019emplacement '
            'standard, ce qui peut être faux. C\u2019est le genre d\u2019écart '
            'que produit un empaqueteur.'
            % (taille_optionnel, 'PE32+' if resultat['largeur'] == 64 else 'PE32',
               attendu_optionnel))
    resultat.update({
        'sous_systeme': SOUS_SYSTEMES_PE.get(sous_systeme,
                                             'inconnu (%d)' % sous_systeme),
        'sous_systeme_brut': sous_systeme,
        'taille_image': taille_image, 'taille_en_tetes': taille_en_tetes,
        'somme_de_controle': somme_controle,
        'reserve_pile': reserve_pile, 'reserve_tas': reserve_tas,
        'valide_pile': valide_pile, 'valide_tas': valide_tas,
        'caracteristiques_dll_brutes': dll_caracteristiques,
        'caracteristiques_dll': _drapeaux(dll_caracteristiques, (
            (0x20, 'HIGH_ENTROPY_VA'), (0x40, 'DYNAMIC_BASE (ASLR)'),
            (0x80, 'FORCE_INTEGRITY'), (0x100, 'NX_COMPAT (DEP)'),
            (0x200, 'NO_ISOLATION'), (0x400, 'NO_SEH'),
            (0x800, 'NO_BIND'), (0x1000, 'APPCONTAINER'),
            (0x2000, 'WDM_DRIVER'), (0x4000, 'GUARD_CF'),
            (0x8000, 'TERMINAL_SERVER_AWARE'))),
    })
    if not 0 < nombre_repertoires <= 32:
        resultat['avertissement'] = (
            'NumberOfRvaAndSizes vaut %d, hors de la plage 1..32 : les '
            'répertoires de données sont lus en supposant 16 entrées.'
            % nombre_repertoires)
        nombre_repertoires = 16
    for index in range(min(nombre_repertoires, 16)):
        adresse, taille = lecteur.entier(debut_repertoires + index * 8, '<II')
        nom = (NOMS_REPERTOIRES_PE[index] if index < len(NOMS_REPERTOIRES_PE)
               else 'répertoire %d' % index)
        resultat['repertoires'].append({'index': index, 'nom': nom,
                                        'adresse': adresse,
                                        'adresse_hex': '0x%x' % adresse,
                                        'taille': taille, 'present': bool(adresse)})
    repertoires = {r['nom']: r for r in resultat['repertoires']}

    # --- sections ------------------------------------------------------------
    debut_sections = optionnel + taille_optionnel
    if not taille_optionnel:
        debut_sections = debut_repertoires
        resultat['avertissement_sections'] = (
            'SizeOfOptionalHeader vaut 0 : les sections sont cherchées juste '
            'après les répertoires de données, ce qui peut être faux.')
    for index in range(min(nombre_sections, 96)):
        base = debut_sections + index * 40
        nom_brut = lecteur.octets(base, 8)
        (taille_virtuelle, adresse_virtuelle, taille_brute, pointeur_brut,
         pointeur_reloc, pointeur_lignes, nombre_reloc, nombre_lignes,
         caracteristiques) = lecteur.entier(base + 8, '<IIIIIIHHI')
        nom = nom_brut.rstrip(b'\x00').decode('utf8', 'replace')
        section = {
            'index': index, 'nom': nom,
            'taille_virtuelle': taille_virtuelle,
            'adresse_virtuelle': adresse_virtuelle,
            'adresse_hex': '0x%x' % adresse_virtuelle,
            'taille': taille_brute, 'decalage': pointeur_brut,
            'relocations': nombre_reloc, 'lignes': nombre_lignes,
            'caracteristiques_brutes': caracteristiques,
            'caracteristiques': _drapeaux(caracteristiques, (
                (0x20, 'CODE'), (0x40, 'INITIALIZED_DATA'),
                (0x80, 'UNINITIALIZED_DATA'), (0x20000000, 'EXECUTE'),
                (0x40000000, 'READ'), (0x80000000, 'WRITE'),
                (0x10000000, 'SHARED'), (0x4000000, 'NO_PAD'))),
            'executable': bool(caracteristiques & 0x20000000),
            'ecrire_et_executer': bool(caracteristiques & 0x20000000
                                       and caracteristiques & 0x80000000),
        }
        if section['ecrire_et_executer']:
            section['alerte'] = (
                'Cette section est à la fois inscriptible et exécutable : '
                'c’est ce que fait un empaqueteur pour se décompresser en '
                'mémoire, et c’est interdit par DEP sur un binaire normal.')
        if taille_brute:
            brut = lecteur.lire_reel(pointeur_brut, min(taille_brute, 1 << 22))
            if brut:
                section['entropie'] = entropie(brut)
                if len(brut) < taille_brute:
                    section['entropie_note'] = (
                        'Calculée sur %d des %d octets : le fichier est tronqué.'
                        % (len(brut), taille_brute))
        resultat['sections'].append(section)
    if nombre_sections > 96:
        resultat['avertissement_sections'] = (
            '%d sections annoncées : seules les 96 premières sont lues.'
            % nombre_sections)

    # --- imports -------------------------------------------------------------
    importation = repertoires.get('Import')
    if importation and importation['present']:
        resultat['imports'] = _lire_imports_pe(lecteur, resultat, importation)
    # --- exports -------------------------------------------------------------
    exportation = repertoires.get('Export')
    if exportation and exportation['present']:
        resultat['exports'], resultat['export_details'] = _lire_exports_pe(
            lecteur, resultat, exportation)
    # --- .NET ----------------------------------------------------------------
    com = repertoires.get('Descripteur COM (.NET)')
    if com and com['present']:
        resultat['manage'] = True
        resultat['note_manage'] = (
            'Un répertoire COM/.NET est présent : cet exécutable est managé '
            '(.NET). Le code natif y est minimal ; pour le lire il faut un '
            'décompilateur .NET, pas un désassembleur. Ghidra n’apporte rien '
            'ici.')
    else:
        resultat['manage'] = False
    resultat['notes_lecture'] = list(lecteur.troncatures)
    resultat['resume'] = resume_pe(resultat)
    return resultat


def _heure(secondes):
    import time
    if not secondes:
        return ''
    try:
        return time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime(secondes))
    except (OverflowError, OSError, ValueError):
        return 'horodatage hors de plage (%d)' % secondes


def _drapeaux(valeur, table):
    noms = [nom for masque, nom in table if valeur & masque]
    return ', '.join(noms) if noms else '-'


def _rva_vers_decalage(sections, rva):
    """Convertit une RVA en décalage fichier. Sans cela, rien n'est lisible.

    Les tables d'un PE sont désignées par des adresses virtuelles relatives à la
    base de l'image, jamais par des décalages dans le fichier. Les confondre
    donnerait des noms de DLL pris au mauvais endroit — des chaînes plausibles
    mais fausses, le pire genre d'erreur.
    """
    for section in sections:
        debut = section['adresse_virtuelle']
        fin = debut + max(section['taille_virtuelle'], section['taille'])
        if debut <= rva < fin:
            return section['decalage'] + (rva - debut)
    return None


def _lire_imports_pe(lecteur, resultat, repertoire):
    """Les DLL importées et, pour chacune, les fonctions importées."""
    decalage = _rva_vers_decalage(resultat['sections'], repertoire['adresse'])
    if decalage is None:
        resultat['avertissement_imports'] = (
            'La table d’import est à la RVA 0x%x, qui ne tombe dans aucune '
            'section : elle n’est pas lisible depuis le fichier (elle peut '
            'n’exister qu’en mémoire après décompression).'
            % repertoire['adresse'])
        return []
    sortie = []
    for index in range(256):
        base = decalage + index * 20
        (first_thunk_brut, horodatage, chaine_avant, rva_nom,
         first_thunk) = lecteur.entier(base, '<IIIII')
        if not (first_thunk_brut or horodatage or chaine_avant or rva_nom
                or first_thunk):
            # Une liste vide n'est pas une information : « aucune DLL importée »
            # et « table illisible » se ressemblent à l'affichage, et le second
            # est de loin le plus fréquent. Si le répertoire annonce une taille
            # non nulle mais que le premier descripteur est nul, la table n'a pas
            # pu être lue et il faut le dire.
            if index == 0 and repertoire['taille'] >= 20:
                resultat['avertissement_imports'] = (
                    'Le répertoire d’import annonce %d octets, mais le premier '
                    'descripteur à l’offset %d est entièrement nul : la table '
                    'n’est pas lisible depuis le fichier. Aucune DLL importée '
                    'n’est rendue, ce qui ne veut PAS dire que le binaire n’en '
                    'importe aucune — un empaqueteur construit cette table en '
                    'mémoire au démarrage.'
                    % (repertoire['taille'], base))
            break
        nom_dll = ''
        decalage_nom = _rva_vers_decalage(resultat['sections'], rva_nom)
        if decalage_nom is not None:
            brut = lecteur.octets(decalage_nom, 512)
            nom_dll = brut.split(b'\x00')[0].decode('utf8', 'replace')
        fonctions = _lire_thunks(lecteur, resultat, first_thunk_brut or first_thunk,
                                 bool(first_thunk_brut))
        sortie.append({'index': index, 'dll': nom_dll, 'horodatage': horodatage,
                       'chaine_avant': chaine_avant,
                       'fonctions': fonctions,
                       'nombre': len(fonctions),
                       'par_ordre': [f['nom'] for f in fonctions
                                     if not f.get('par_ordinal')]})
        if index == 255:
            resultat['avertissement_imports'] = (
                'Plus de 256 DLL importées : la liste est coupée.')
    return sortie


def _lire_thunks(lecteur, resultat, rva, par_nom):
    """Les entrées d'une table de thunks : ordinaux ou noms de fonctions."""
    if not rva:
        return []
    decalage = _rva_vers_decalage(resultat['sections'], rva)
    if decalage is None:
        return []
    largeur = resultat.get('largeur', 32)
    format_ = '<Q' if largeur == 64 else '<I'
    taille = 8 if largeur == 64 else 4
    masque_ordinal = 1 << (63 if largeur == 64 else 31)
    sortie = []
    for index in range(4096):
        valeur = lecteur.entier(decalage + index * taille, format_)[0]
        if valeur == 0:
            break
        if valeur & masque_ordinal:
            sortie.append({'ordinal': valeur & 0xffff, 'nom': '',
                           'par_ordinal': True,
                           'brut': '0x%x' % valeur})
        else:
            hint = _rva_vers_decalage(resultat['sections'], valeur & 0x7fffffff)
            if hint is None:
                sortie.append({'nom': '', 'par_ordinal': False,
                               'brut': '0x%x' % valeur,
                               'erreur': 'RVA hors de toute section'})
                continue
            ordinal = lecteur.u16(hint)
            brut = lecteur.octets(hint + 2, 1024)
            sortie.append({'nom': brut.split(b'\x00')[0].decode('utf8', 'replace'),
                           'ordinal_suggere': ordinal, 'par_ordinal': False,
                           'brut': '0x%x' % valeur})
        if index == 4095:
            break
    return sortie


def _lire_exports_pe(lecteur, resultat, repertoire):
    decalage = _rva_vers_decalage(resultat['sections'], repertoire['adresse'])
    if decalage is None:
        return [], []
    # IMAGE_EXPORT_DIRECTORY : 40 octets, 11 champs.
    (caracteristiques, horodatage, majeur, mineur, rva_nom, base,
     nombre_fonctions, nombre_noms, rva_fonctions, rva_noms,
     rva_ordinaux) = lecteur.entier(decalage, '<IIHHIIIIIII')
    nom_dll = ''
    decalage_nom = _rva_vers_decalage(resultat['sections'], rva_nom)
    if decalage_nom is not None:
        nom_dll = lecteur.octets(decalage_nom, 512).split(b'\x00')[0].decode(
            'utf8', 'replace')
    decalage_fonctions = _rva_vers_decalage(resultat['sections'], rva_fonctions)
    decalage_noms = _rva_vers_decalage(resultat['sections'], rva_noms)
    decalage_ordinaux = _rva_vers_decalage(resultat['sections'], rva_ordinaux)
    details = []
    if decalage_fonctions is not None:
        nombre_fonctions = min(nombre_fonctions, 20000)
        for index in range(nombre_fonctions):
            adresse = lecteur.u32(decalage_fonctions + index * 4)
            if not adresse:
                continue
            details.append({'ordinal': base + index, 'adresse': adresse,
                            'adresse_hex': '0x%x' % adresse, 'nom': ''})
    if decalage_noms is not None and decalage_ordinaux is not None:
        nombre_noms = min(nombre_noms, 20000)
        for index in range(nombre_noms):
            rva = lecteur.u32(decalage_noms + index * 4)
            ordinal = lecteur.u16(decalage_ordinaux + index * 2)
            decalage_chaine = _rva_vers_decalage(resultat['sections'], rva)
            if decalage_chaine is None:
                continue
            nom = lecteur.octets(decalage_chaine, 1024).split(b'\x00')[0].decode(
                'utf8', 'replace')
            for entree in details:
                if entree['ordinal'] == base + ordinal:
                    entree['nom'] = nom
                    break
            else:
                details.append({'ordinal': base + ordinal, 'nom': nom,
                                'adresse': 0, 'adresse_hex': ''})
    resultat['export_dll'] = nom_dll
    resultat['export_horodatage'] = _heure(horodatage)
    resultat['export_version'] = '%d.%d' % (majeur, mineur)
    resultat['export_base_ordinaux'] = base
    if not details and nombre_fonctions:
        resultat['avertissement_exports'] = (
            'La table d’export annonce %d fonction(s) mais aucune n’a pu être '
            'lue : l’adresse des fonctions ne tombe dans aucune section.'
            % nombre_fonctions)
    noms = [d['nom'] for d in details if d['nom']]
    if details and not noms:
        resultat['avertissement_exports'] = (
            'La table d’export contient %d entrées mais aucun nom : la table des '
            'noms est illisible ou les fonctions ne sont exportées que par '
            'ordinal.' % len(details))
    return noms, details


def resume_pe(pe):
    notes = []
    notes.append('%s, %s%s' % (pe.get('machine', '?'), pe.get('magique', '?'),
                               ', DLL' if pe.get('est_une_dll') else ''))
    notes.append('Sous-système %s, point d’entrée %s, base 0x%x'
                 % (pe.get('sous_systeme', '?'), pe.get('entree_hex', '?'),
                    pe.get('base_image', 0)))
    if pe.get('horodatage_texte'):
        notes.append('Horodatage de compilation : %s' % pe['horodatage_texte'])
    if pe.get('imports'):
        total = sum(len(d.get('fonctions', ())) for d in pe['imports'])
        notes.append('%d DLL importée(s), %d fonction(s) importée(s)'
                     % (len(pe['imports']), total))
    if pe.get('exports'):
        notes.append('%d fonction(s) exportée(s)' % len(pe['exports']))
    if pe.get('note_manage'):
        notes.append(pe['note_manage'])
    if pe.get('caracteristiques_dll') and pe['caracteristiques_dll'] != '-':
        notes.append('Mitigations : %s' % pe['caracteristiques_dll'])
    else:
        notes.append('Aucune mitigation déclarée (ni ASLR ni DEP) : les '
                     'débordements de tampon y sont plus faciles à exploiter.')
    for section in pe.get('sections', []):
        if section.get('alerte'):
            notes.append('Section « %s » : %s' % (section['nom'], section['alerte']))
        elif section.get('entropie') is not None and section['entropie'] > 7.2 \
                and section['taille'] > 512:
            notes.append('Section « %s » d’entropie %.2f : compressée ou chiffrée'
                         % (section['nom'], section['entropie']))
    for cle in ('avertissement', 'avertissement_en_tete',
                'avertissement_imports', 'avertissement_exports',
                'avertissement_sections'):
        if pe.get(cle):
            notes.append(pe[cle])
    return notes


# --------------------------------------------------------------------------
# Mach-O
# --------------------------------------------------------------------------

def lire_macho(lecteur):
    """En-tête, commandes de chargement, segments et symboles d'un Mach-O."""
    resultat = {'format': 'Mach-O', 'segments': [], 'sections': [],
                'commandes': [], 'symboles': [], 'bibliotheques': [],
                'notes_lecture': []}
    magique = lecteur.octets(0, 4)
    if magique in (b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca'):
        return _lire_macho_gras(lecteur, magique)
    if magique in (b'\xcf\xfa\xed\xfe', b'\xce\xfa\xed\xfe'):
        boutisme, largeur = '<', (64 if magique[1:3] == b'\xfa\xed' else 32)
    elif magique in (b'\xfe\xed\xfa\xcf', b'\xfe\xed\xfa\xce'):
        boutisme, largeur = '>', (64 if magique[3] == 0xcf else 32)
    else:
        resultat['erreur'] = ('La signature %r n’est pas celle d’un Mach-O.'
                              % magique)
        return resultat
    resultat['largeur'] = largeur
    resultat['boutisme'] = 'little-endian' if boutisme == '<' else 'big-endian'
    taille_en_tete = 32 if largeur == 64 else 28
    (magique_lu, cputype, cpusubtype, filetype, ncmds, sizeofcmds,
     drapeaux) = lecteur.entier(0, boutisme + 'IIIIIII')
    resultat.update({
        'cputype_brut': cputype,
        'cputype': _architecture_macho(cputype),
        'cpusubtype': cpusubtype,
        'filetype_brut': filetype,
        'filetype': TYPES_FICHIER_MACHO.get(filetype, 'inconnu (%d)' % filetype),
        'nombre_commandes': ncmds, 'taille_commandes': sizeofcmds,
        'drapeaux_bruts': drapeaux,
        'drapeaux': _drapeaux(drapeaux, (
            (0x1, 'NOUNDEFS'), (0x2, 'INCRLINK'), (0x4, 'DYLDLINK'),
            (0x8, 'BINDATLOAD'), (0x10, 'PREBOUND'), (0x80, 'TWOLEVEL'),
            (0x100, 'PIE (position indépendant)'), (0x20000, 'NO_HEAP_EXECUTION'),
            (0x100000, 'APP_EXTENSION_SAFE'))),
        'pie': bool(drapeaux & 0x200000),
    })
    position = taille_en_tete
    fin = min(position + sizeofcmds, lecteur.taille)
    nlist_taille = 16 if largeur == 64 else 12
    symtab = None
    compteur = 0
    while position + 8 <= fin and compteur < min(ncmds, 2048):
        commande, taille = lecteur.entier(position, boutisme + 'II')
        compteur += 1
        if taille < 8 or position + taille > lecteur.taille:
            resultat['commandes_tronquees'] = (
                'La commande %d annonce %d octets à l’offset %d, ce qui déborde '
                'du fichier (%d octets) : les commandes suivantes ne sont pas '
                'lues.' % (compteur, taille, position, lecteur.taille))
            break
        entree = {'index': compteur, 'commande': commande, 'taille': taille,
                  'nom': TYPES_SEGMENT_MACHO.get(commande, '0x%x' % commande),
                  'decalage': position}
        if commande == 0x19 or commande == 0x1:
            _lire_segment_macho(lecteur, resultat, entree, position, boutisme,
                                largeur == 64)
        elif commande == 0x2:
            symoff, nsyms, stroff, strsize = lecteur.entier(
                position + 8, boutisme + 'IIII')
            symtab = {'symoff': symoff, 'nsyms': nsyms, 'stroff': stroff,
                      'strsize': strsize}
            entree.update({'symoff': symoff, 'nsyms': nsyms, 'stroff': stroff,
                           'strsize': strsize})
        elif commande in (0xc, 0xd, 0x8000001c, 0x80000018, 0x1f, 0x20):
            rva_nom = lecteur.u32(position + 8, boutisme)
            chemin = lecteur.chaine(position + rva_nom)
            entree['bibliotheque'] = chemin
            if chemin:
                resultat['bibliotheques'].append(
                    {'commande': entree['nom'], 'chemin': chemin})
        elif commande == 0x1b:
            uuid = lecteur.octets(position + 8, 16)
            entree['uuid'] = '-'.join((
                binascii.hexlify(uuid[0:4]).decode(),
                binascii.hexlify(uuid[4:6]).decode(),
                binascii.hexlify(uuid[6:8]).decode(),
                binascii.hexlify(uuid[8:10]).decode(),
                binascii.hexlify(uuid[10:16]).decode())).upper()
            resultat['uuid'] = entree['uuid']
        elif commande == 0x28 or commande == 0x80000028:
            entree['point_entree'] = lecteur.u64(position + 8, boutisme) \
                if largeur == 64 else lecteur.u32(position + 8, boutisme)
            entree['point_entree_hex'] = '0x%x' % entree['point_entree']
            resultat['entree'] = entree['point_entree']
        elif commande == 0x29:
            plateforme, minimum, sdk = lecteur.entier(position + 8,
                                                      boutisme + 'III')
            entree['plateforme'] = plateforme
            entree['version_minimale'] = _version_macho(minimum)
            entree['version_sdk'] = _version_macho(sdk)
            resultat['version_minimale'] = entree['version_minimale']
        elif commande == 0x1d:
            offset, taille = lecteur.entier(position + 8, boutisme + 'II')
            entree.update({'offset': offset, 'taille': taille})
            resultat['signature_code'] = {'offset': offset, 'taille': taille}
        elif commande == 0x21 or commande == 0x2c:
            offset, taille, ident = lecteur.entier(position + 8,
                                                   boutisme + 'III')
            entree.update({'offset': offset, 'taille': taille,
                           'identifiant': ident})
            resultat['chiffre'] = {'offset': offset, 'taille': taille,
                                   'identifiant': ident}
        resultat['commandes'].append(entree)
        position += taille
    if compteur >= 2048:
        resultat['commandes_tronquees'] = (
            'Plus de 2048 commandes de chargement : la lecture s’est arrêtée, '
            'le fichier est probablement corrompu.')
    if symtab:
        resultat['symboles'] = _lire_symboles_macho(lecteur, symtab, boutisme,
                                                    nlist_taille, resultat)
    resultat['notes_lecture'] = list(lecteur.troncatures)
    resultat['resume'] = resume_macho(resultat)
    return resultat


def _version_macho(valeur):
    return '%d.%d.%d' % ((valeur >> 16) & 0xffff, (valeur >> 8) & 0xff,
                         valeur & 0xff)


def _architecture_macho(cputype):
    base = cputype & ~0x01000000
    noms = {0x7: 'x86', 0xc: 'ARM', 0x12: 'PowerPC', 0x1: 'VAX',
            0x6: 'MC680x0', 0x8: 'MIPS', 0xa: 'MC98000', 0xb: 'HPPA',
            0xd: 'MC88000', 0xe: 'SPARC', 0xf: 'i860', 0x10: 'Alpha'}
    nom = noms.get(base, 'inconnue (0x%x)' % cputype)
    if cputype & 0x01000000:
        nom += ' 64 bits'
    return nom


def _lire_segment_macho(lecteur, resultat, entree, position, boutisme, soixante):
    nom = lecteur.octets(position + 8, 16).rstrip(b'\x00').decode('utf8', 'replace')
    if soixante:
        (vmaddr, vmsize, fileoff, filesize, maxprot, initprot, nsects,
         drapeaux) = lecteur.entier(position + 24, boutisme + 'QQQQIIII')
        debut_sections = position + 72
        taille_section = 80
    else:
        (vmaddr, vmsize, fileoff, filesize, maxprot, initprot, nsects,
         drapeaux) = lecteur.entier(position + 24, boutisme + 'IIIIIIII')
        debut_sections = position + 56
        taille_section = 68
    entree.update({'segment': nom, 'vmaddr': vmaddr, 'vmaddr_hex': '0x%x' % vmaddr,
                   'vmsize': vmsize, 'fileoff': fileoff, 'filesize': filesize,
                   'maxprot': maxprot, 'initprot': initprot,
                   'nombre_sections': nsects, 'drapeaux': drapeaux})
    resultat['segments'].append({k: v for k, v in entree.items()})
    if nsects > 256:
        resultat['avertissement'] = (
            'Le segment « %s » annonce %d sections : seule une borne de 256 est '
            'lue.' % (nom, nsects))
        nsects = 256
    for index in range(nsects):
        base = debut_sections + index * taille_section
        nom_s = lecteur.octets(base, 16).rstrip(b'\x00').decode('utf8', 'replace')
        segment_s = lecteur.octets(base + 16, 16).rstrip(b'\x00').decode(
            'utf8', 'replace')
        if soixante:
            (adresse, taille, offset, alignement, reloff, nreloc, drapeaux_s,
             reserve1, reserve2, reserve3) = lecteur.entier(
                base + 32, boutisme + 'QQIIIIIIII')
        else:
            (adresse, taille, offset, alignement, reloff, nreloc, drapeaux_s,
             reserve1, reserve2) = lecteur.entier(base + 32,
                                                  boutisme + 'IIIIIIIII')
        section = {'index': index, 'nom': nom_s, 'segment': segment_s,
                   'adresse': adresse, 'adresse_hex': '0x%x' % adresse,
                   'taille': taille, 'decalage': offset,
                   'alignement': 1 << alignement if alignement < 32 else alignement,
                   'reloff': reloff, 'nreloc': nreloc,
                   'drapeaux_bruts': drapeaux_s,
                   'type': _type_section_macho(drapeaux_s),
                   'attributs': _attributs_section_macho(drapeaux_s),
                   'executable': bool(drapeaux_s & 0x4000000)
                   or bool(drapeaux_s & 0x80000000)}
        if taille and taille < (1 << 22) and (drapeaux_s & 0xff) not in (0x1, 0xf):
            brut = lecteur.lire_reel(offset, taille)
            if brut:
                section['entropie'] = entropie(brut)
        resultat['sections'].append(section)


def _type_section_macho(drapeaux):
    types = {0x0: 'S_REGULAR', 0x1: 'S_ZEROFILL', 0x2: 'S_CSTRING_LITERALS',
             0x3: 'S_4BYTE_LITERALS', 0x4: 'S_8BYTE_LITERALS',
             0x5: 'S_LITERAL_POINTERS', 0x8: 'S_MOD_INIT_FUNC_POINTERS',
             0x9: 'S_MOD_TERM_FUNC_POINTERS', 0xa: 'S_SYMBOL_STUBS',
             0xb: 'S_LAZY_SYMBOL_POINTERS', 0xc: 'S_NON_LAZY_SYMBOL_POINTERS',
             0xd: 'S_DYLIB_SYMBOL_POINTERS', 0xe: 'S_THREAD_LOCAL_REGULAR',
             0xf: 'S_THREAD_LOCAL_ZEROFILL', 0x10: 'S_THREAD_LOCAL_VARIABLES'}
    return types.get(drapeaux & 0xff, 'inconnu (0x%x)' % (drapeaux & 0xff))


def _attributs_section_macho(drapeaux):
    attributs = []
    for masque, nom in ((0x4000000, 'S_ATTR_PURE_INSTRUCTIONS'),
                        (0x8000000, 'S_ATTR_NO_TOC'),
                        (0x10000000, 'S_ATTR_SELF_MODIFYING_CODE'),
                        (0x20000000, 'S_ATTR_LIVE_SUPPORT'),
                        (0x40000000, 'S_ATTR_NO_DEAD_STRIP'),
                        (0x80000000, 'S_ATTR_SOME_INSTRUCTIONS')):
        if drapeaux & masque:
            attributs.append(nom)
    return attributs


def _lire_symboles_macho(lecteur, symtab, boutisme, taille, resultat):
    nsyms = min(symtab['nsyms'], 200000)
    if symtab['nsyms'] > nsyms:
        resultat['symboles_tronques'] = (
            '%d symboles annoncés, les %d premiers sont lus.'
            % (symtab['nsyms'], nsyms))
    chaines = lecteur.octets(symtab['stroff'], min(symtab['strsize'], LECTURE_MAX))
    sortie = []
    for index in range(nsyms):
        position = symtab['symoff'] + index * taille
        if taille == 16:
            strx, type_, sect, desc, valeur = lecteur.entier(position,
                                                             boutisme + 'IBBHQ')
        else:
            strx, type_, sect, desc, valeur = lecteur.entier(position,
                                                             boutisme + 'IBBHI')
        nom = lecteur.chaine_dans(chaines, strx)
        stable = type_ & 0xe
        sortie.append({
            'index': index, 'nom': nom, 'valeur': valeur,
            'valeur_hex': '0x%x' % valeur,
            'type_brut': type_,
            'type': TYPES_NLS_MACHO.get(stable, '0x%x' % stable),
            'externe': bool(type_ & 0x1),
            'section': sect, 'desc': desc,
            'importe': stable == 0x0 or stable == 0xc,
            'exporte': stable == 0xe and bool(type_ & 0x1),
        })
    return sortie


def _lire_macho_gras(lecteur, magique):
    """Un binaire gras : plusieurs Mach-O dans un seul fichier (macOS/iOS)."""
    boutisme = '>' if magique == b'\xca\xfe\xba\xbe' else '<'
    nombre = lecteur.u32(4, boutisme)
    resultat = {'format': 'Mach-O gras', 'architectures': [], 'resume': [],
                'notes_lecture': []}
    if nombre > 32:
        resultat['avertissement'] = (
            '%d architectures annoncées dans un binaire gras : c’est '
            'invraisemblable. S’il s’agit d’un .class Java, la signature '
            '0xCAFEBABE est la même ; la lecture s’arrête.' % nombre)
        resultat['ambigu'] = True
        return resultat
    for index in range(nombre):
        base = 8 + index * 20
        cputype, cpusubtype, offset, taille, alignement = lecteur.entier(
            base, boutisme + 'IIIII')
        resultat['architectures'].append({
            'index': index, 'cputype': _architecture_macho(cputype),
            'cpusubtype': cpusubtype, 'decalage': offset, 'taille': taille,
            'alignement': 1 << alignement if alignement < 32 else alignement})
    resultat['resume'] = ['Binaire gras : %d architecture(s) (%s).'
                          % (nombre, ', '.join(a['cputype']
                                               for a in resultat['architectures'])),
                          'Chaque tranche se lit séparément ; le panneau analyse '
                          'la première.']
    resultat['notes_lecture'] = list(lecteur.troncatures)
    return resultat


def resume_macho(macho):
    notes = []
    notes.append('%s %s bits, %s' % (macho.get('cputype', '?'),
                                     macho.get('largeur', '?'),
                                     macho.get('boutisme', '?')))
    notes.append('Type %s%s' % (macho.get('filetype', '?'),
                                ', PIE' if macho.get('pie') else ''))
    if macho.get('bibliotheques'):
        notes.append('%d bibliothèque(s) liée(s) : %s'
                     % (len(macho['bibliotheques']),
                        ', '.join(b['chemin'] for b in macho['bibliotheques'][:6])))
    if macho.get('version_minimale'):
        notes.append('Version minimale d’OS %s' % macho['version_minimale'])
    if macho.get('uuid'):
        notes.append('UUID %s' % macho['uuid'])
    if macho.get('signature_code'):
        notes.append('Signature de code présente (%d octets à %d)'
                     % (macho['signature_code']['taille'],
                        macho['signature_code']['offset']))
    if macho.get('chiffre'):
        notes.append('Segment chiffré déclaré (LC_ENCRYPTION_INFO) : une partie '
                     'du binaire n’est pas lisible en l’état.')
    exportes = [s['nom'] for s in macho.get('symboles', ()) if s.get('exporte')]
    if exportes:
        notes.append('%d symbole(s) exporté(s)' % len(exportes))
    if macho.get('symboles_tronques'):
        notes.append(macho['symboles_tronques'])
    if macho.get('commandes_tronquees'):
        notes.append(macho['commandes_tronquees'])
    return notes


# --------------------------------------------------------------------------
# Chaînes, entropie par section, heuristiques
# --------------------------------------------------------------------------

PRINTABLES = bytes(range(0x20, 0x7f))


def chaines(chemin, minimum=CHAINE_MIN, debut=0, longueur=None,
            encodages=('ascii',), limite=20000):
    """Les chaînes imprimables, avec leur position et la section qui les contient.

    `strings` de binutils ne dit pas où se trouve une chaîne ni dans quelle
    section : pour savoir si un chemin, une URL ou un mot de passe est dans du
    code, dans des données en lecture seule ou dans une table de relocation, il
    faut la position. Elle est rendue ici, et l'attribution à une section est
    faite par `attribuer_chaines`.

    La lecture se fait par blocs, et une chaîne qui touche la fin d'un bloc est
    reportée au bloc suivant : la couper produirait deux moitiés, chacune
    plausible et chacune fausse.
    """
    chemin = Path(chemin)
    resultat = {'ok': True, 'chaines': [], 'compte': 0, 'tronque': False,
                'octets_lus': 0}
    try:
        taille = chemin.stat().st_size
    except OSError as exc:
        return {'ok': False, 'chaines': [], 'compte': 0,
                'erreur': 'Stat impossible : %s' % (exc.strerror or exc)}
    if minimum < 1:
        return {'ok': False, 'chaines': [], 'compte': 0,
                'erreur': 'Une longueur minimale de %d caractère(s) n’existe '
                          'pas : il faut au moins 1.' % minimum}
    if debut >= taille:
        resultat['note'] = ('La plage demandée commence à %d, au-delà de la fin '
                            'du fichier (%d octets).' % (debut, taille))
        return resultat
    if longueur is None:
        longueur = taille - max(0, debut)
    longueur = max(0, min(longueur, OCTETS_MAX))
    motif = re.compile(rb'[\x20-\x7e\x09]{%d,}' % minimum)
    bloc = 64 * 1024
    position = max(0, debut)
    fin = position + longueur
    reliquat = b''
    reliquat_position = position
    with Lecteur(chemin) as lecteur:
        while position < fin:
            donnees = lecteur.lire_reel(position, min(bloc, fin - position))
            if not donnees:
                break
            resultat['octets_lus'] += len(donnees)
            tampon = reliquat + donnees
            tampon_position = reliquat_position
            reporte = None
            pour_le_bloc_suivant = position + len(donnees) < fin
            for correspondance in motif.finditer(tampon):
                if (reporte is None and pour_le_bloc_suivant
                        and correspondance.end() == len(tampon)):
                    reporte = correspondance
                    break
                resultat['chaines'].append({
                    'position': tampon_position + correspondance.start(),
                    'position_hex': '0x%x'
                                    % (tampon_position + correspondance.start()),
                    'longueur': correspondance.end() - correspondance.start(),
                    'texte': tampon[correspondance.start():correspondance.end()
                                    ].decode('utf8', 'replace'),
                    'encodage': 'ascii'})
                if len(resultat['chaines']) >= limite:
                    break
            if reporte is not None:
                reliquat = tampon[reporte.start():]
                reliquat_position = tampon_position + reporte.start()
            else:
                reliquat = b''
                reliquat_position = position + len(donnees)
            position += len(donnees)
            if len(resultat['chaines']) >= limite:
                resultat['tronque'] = True
                resultat['note'] = (
                    'Plus de %d chaînes trouvées : la liste est coupée à '
                    'l’octet %d. Réduisez la plage ou augmentez la longueur '
                    'minimale.' % (limite, position))
                break
        if reliquat and len(resultat['chaines']) < limite:
            resultat['chaines'].append({
                'position': reliquat_position,
                'position_hex': '0x%x' % reliquat_position,
                'longueur': len(reliquat),
                'texte': reliquat.decode('utf8', 'replace'),
                'encodage': 'ascii'})
    if 'utf16' in encodages:
        resultat['chaines'].extend(
            _chaines_utf16(chemin, minimum, debut, longueur,
                           max(0, limite - len(resultat['chaines']))))
    resultat['compte'] = len(resultat['chaines'])
    resultat['chaines'].sort(key=lambda c: c['position'])
    return resultat


def _chaines_utf16(chemin, minimum, debut, longueur, limite):
    """Les chaînes UTF-16LE : c'est ainsi que Windows stocke ses chemins.

    Un exécutable Windows porte la plupart de ses messages en UTF-16. Ne chercher
    que de l'ASCII ferait conclure à un binaire sans chaîne lisible — un faux
    négatif exactement du genre que ce module doit éviter.
    """
    if limite <= 0:
        return []
    sortie = []
    with Lecteur(chemin) as lecteur:
        bloc = 64 * 1024
        position = max(0, debut)
        fin = position + longueur
        while position < fin and len(sortie) < limite:
            donnees = lecteur.lire_reel(position, min(bloc, fin - position))
            if not donnees:
                break
            index = 0
            while index + 1 < len(donnees) and len(sortie) < limite:
                if donnees[index] in PRINTABLES and donnees[index + 1] == 0:
                    debut_chaine = index
                    while (index + 1 < len(donnees)
                           and donnees[index] in PRINTABLES
                           and donnees[index + 1] == 0):
                        index += 2
                    nombre = (index - debut_chaine) // 2
                    if nombre >= minimum:
                        sortie.append({
                            'position': position + debut_chaine,
                            'position_hex': '0x%x' % (position + debut_chaine),
                            'longueur': nombre,
                            'texte': donnees[debut_chaine:index].decode(
                                'utf-16-le', 'replace'),
                            'encodage': 'utf-16le'})
                    index += 2
                else:
                    index += 1
            position += len(donnees)
    return sortie


def attribuer_chaines(analysis, entrees):
    """Donne à chaque chaîne la section qui la contient, quand on la connaît.

    Une chaîne dans `.rodata` est une donnée ; dans `.text` elle est
    probablement une instruction interprétée à tort ; dans `.comment` c'est la
    signature du compilateur. Cette distinction change ce qu'on en conclut, et
    `strings` seul ne la donne pas.
    """
    sections = []
    for section in analysis.get('sections', ()):
        if section.get('taille') and section.get('decalage') is not None \
                and section.get('presente_dans_le_fichier', True):
            sections.append(section)
    sections.sort(key=lambda s: s['decalage'])
    for entree in entrees:
        entree['section'] = ''
        for section in sections:
            debut = section['decalage']
            if debut <= entree['position'] < debut + section['taille']:
                entree['section'] = section.get('nom', '')
                break
    return entrees


def entropie_par_section(chemin, analyse):
    """L'entropie de chaque section présente dans le fichier."""
    sortie = []
    with Lecteur(chemin) as lecteur:
        for section in analyse.get('sections', ()):
            if not section.get('presente_dans_le_fichier', True):
                section['entropie'] = None
                continue
            taille = section.get('taille') or 0
            if not taille:
                section['entropie'] = 0.0
                continue
            donnees = lecteur.lire_reel(section['decalage'],
                                        min(taille, 1 << 22))
            if not donnees:
                section['entropie'] = None
                section['entropie_note'] = (
                    'Aucun octet présent dans le fichier pour cette section : '
                    'l’entropie n’est pas calculable.')
                continue
            section['entropie'] = entropie(donnees)
            if len(donnees) < taille:
                section['entropie_note'] = (
                    'Calculée sur %d des %d octets : le fichier est tronqué, '
                    'cette valeur ne décrit qu’un début de section.'
                    % (len(donnees), taille))
            sortie.append({'nom': section.get('nom', '?'),
                           'taille': taille,
                           'entropie': section['entropie'],
                           'suspecte': section['entropie'] > 7.2 and taille > 512})
    return sortie


def heuristiques(chemin, analyse, donnees_tete):
    """Les indices d'empaquetage, de chiffrement et de protection.

    Ce sont des HEURISTIQUES, et elles sont rendues comme telles : chacune porte
    son indice de confiance et sa raison. Annoncer « ce binaire est packé avec
    UPX » sans dire sur quoi repose l'affirmation ferait prendre une hypothèse
    pour un fait — et une hypothèse fausse envoie l'utilisateur désassembler du
    bruit.
    """
    indices = []
    sections = analyse.get('sections', ())
    noms = [str(s.get('nom', '')).upper() for s in sections]
    if any(n in ('UPX0', 'UPX1', 'UPX2', '.UPX0', '.UPX1') for n in noms):
        indices.append({'quoi': 'Empaqueté par UPX', 'confiance': 'forte',
                        'raison': 'Les sections nommées UPX0 et UPX1 sont la '
                                  'signature d’un binaire compressé par UPX. '
                                  'Tant qu’il n’est pas décompressé, aucun '
                                  'désassembleur ni Ghidra n’y lit le vrai code.',
                        'commande': 'upx -d %s' % Path(chemin).name,
                        'installation': 'sudo apt install upx-ucl'})
    for nom, motif in EMPAQUETEURS:
        if motif in donnees_tete[:65536] or (
                len(donnees_tete) > 65536 and motif in donnees_tete[-65536:]):
            if nom == 'UPX' and any(n in ('UPX0', 'UPX1') for n in noms):
                continue
            indices.append({'quoi': 'Signature de %s' % nom, 'confiance': 'moyenne',
                            'raison': 'La chaîne « %s » apparaît dans le fichier. '
                                      'C’est un indice, pas une preuve : la '
                                      'chaîne peut aussi venir d’une table de '
                                      'détection d’empaqueteur embarquée.'
                                      % motif.decode('latin1')})
            break
    elevees = [s for s in sections if s.get('entropie') is not None
               and s['entropie'] > 7.2 and (s.get('taille') or 0) > 512]
    if elevees:
        indices.append({
            'quoi': 'Section(s) à forte entropie', 'confiance': 'forte',
            'raison': '%s. Une entropie proche de 8 bits/octet signifie des '
                      'octets sans structure : compression, chiffrement, ou '
                      'données aléatoires. Un désassembleur n’y lit rien '
                      'd’utile tant que le code n’est pas décompressé en '
                      'mémoire.'
                      % ', '.join('« %s » à %.2f' % (s.get('nom'), s['entropie'])
                                  for s in elevees[:5])})
    executables_et_inscriptibles = [s for s in sections
                                    if s.get('ecrire_et_executer')]
    if executables_et_inscriptibles:
        indices.append({
            'quoi': 'Section inscriptible et exécutable', 'confiance': 'forte',
            'raison': '%s. C’est ce dont un empaqueteur a besoin pour se '
                      'décompresser en mémoire ; sur un binaire ordinaire '
                      'c’est un facteur d’exploitabilité.'
                      % ', '.join('« %s »' % s.get('nom')
                                  for s in executables_et_inscriptibles)})
    if analyse.get('depouille'):
        indices.append({'quoi': 'Symboles retirés (strip)', 'confiance': 'forte',
                        'raison': analyse.get('note_depouille', '')})
    if analyse.get('statique'):
        indices.append({'quoi': 'Liaison statique', 'confiance': 'forte',
                        'raison': analyse.get('note_statique', '')})
    if analyse.get('chiffre'):
        indices.append({'quoi': 'Segment chiffré (FairPlay/App Store)',
                        'confiance': 'forte',
                        'raison': 'LC_ENCRYPTION_INFO est présent : le segment '
                                  '__TEXT est chiffré sur le disque. Il faut un '
                                  'vidage mémoire d’un processus en cours '
                                  'd’exécution, pas le fichier.'})
    if analyse.get('manage'):
        indices.append({'quoi': 'Exécutable managé (.NET)', 'confiance': 'forte',
                        'raison': analyse.get('note_manage', '')})
    # Un point d’entrée qui ne tombe dans aucune section est un indice classique
    # d’empaqueteur : le code réel est écrit en mémoire avant d’y sauter. Mais la
    # comparaison n’a de sens que si l’entrée et les sections sont exprimées dans
    # le MÊME repère. En ELF e_entry est une adresse virtuelle ; en PE
    # AddressOfEntryPoint est une RVA ; en Mach-O LC_MAIN.entryoff est un DÉCALAGE
    # FICHIER relatif à __TEXT. Comparer ce dernier aux adresses virtuelles des
    # sections signalerait à tort un empaquetage sur tous les binaires macOS.
    if analyse.get('format') == 'ELF':
        entree, cle = analyse.get('entree'), 'adresse'
    elif analyse.get('format') == 'PE':
        entree, cle = analyse.get('adresse_entree'), 'adresse_virtuelle'
    else:
        entree, cle = None, ''
    if entree and sections:
        dans_une_section = False
        for section in sections:
            debut = section.get(cle, 0)
            if debut and debut <= entree < debut + max(
                    section.get('taille', 0), section.get('taille_virtuelle', 0)):
                dans_une_section = True
                break
        if not dans_une_section:
            indices.append({
                'quoi': 'Point d’entrée hors de toute section',
                'confiance': 'moyenne',
                'raison': 'Le point d’entrée 0x%x ne tombe dans aucune section '
                          'déclarée. Soit le fichier est tronqué, soit le code '
                          'est construit en mémoire au démarrage — c’est le '
                          'comportement d’un empaqueteur.' % entree})
    if analyse.get('format') == 'PE':
        mitigations = analyse.get('caracteristiques_dll', '-')
        if mitigations == '-':
            indices.append({'quoi': 'Aucune mitigation déclarée',
                            'confiance': 'forte',
                            'raison': 'Ni ASLR (DYNAMIC_BASE) ni DEP '
                                      '(NX_COMPAT) dans DllCharacteristics.'})
    return indices


# --------------------------------------------------------------------------
# Outils externes
# --------------------------------------------------------------------------

def _outil(nom):
    return shutil.which(nom)


def _lancer(commande, entree=None, delai=120, taille_max=32 * 1024 * 1024):
    """Lance un outil d'analyse. Jamais d'interpréteur de commandes.

    Les arguments sont une liste : un nom de fichier contenant une espace ou un
    point-virgule ne peut pas être interprété comme une commande. Un binaire
    analysé n'est jamais exécuté — objdump, readelf et nm ne le lancent pas.
    """
    # La locale est IMPOSÉE, et ce n'est pas un détail de propreté. readelf,
    # objdump, nm, file et gcc sont traduits : sur une machine française ils
    # répondent « En-tête ELF : », « Nombre d'en-têtes de section : », « Adresse
    # du point d'entrée : ». Toutes les expressions régulières de ce module
    # cherchent les formes anglaises, donc elles ne trouvent plus rien et le
    # croisement avec readelf rend « ? » partout — sur une analyse pourtant
    # exacte. C'est la panne qui a arrêté une construction en Debian 13.
    # assembleur.py et verificateurs_statiques.py imposent déjà cette locale.
    environnement = dict(os.environ)
    environnement['LC_ALL'] = 'C.UTF-8'
    environnement['LC_MESSAGES'] = 'C'
    environnement['LANGUAGE'] = 'C'
    environnement['TERM'] = 'dumb'
    try:
        termine = subprocess.run(commande, capture_output=True, timeout=delai,
                                 stdin=subprocess.DEVNULL, env=environnement)
    except FileNotFoundError:
        return {'ok': False, 'erreur': 'La commande « %s » n’est pas installée.'
                % commande[0], 'code': None}
    except subprocess.TimeoutExpired:
        return {'ok': False, 'erreur': 'La commande « %s » a dépassé le délai '
                                       'de %d s.' % (commande[0], delai),
                'code': None, 'delai': delai}
    except OSError as exc:
        return {'ok': False, 'erreur': 'Lancement impossible : %s'
                % (exc.strerror or exc), 'code': None}
    sortie = termine.stdout or b''
    erreur = termine.stderr or b''
    tronquee = False
    if len(sortie) > taille_max:
        sortie = sortie[:taille_max]
        tronquee = True
    texte_erreur = erreur.decode('utf8', 'replace')[:20000]
    return {'ok': termine.returncode == 0, 'code': termine.returncode,
            'sortie': sortie.decode('utf8', 'replace'),
            'erreur': texte_erreur,
            'avertissements': [l.strip() for l in texte_erreur.split('\n')
                               if l.strip()][:20],
            'octets': len(sortie), 'tronquee': tronquee}


def _normaliser_outil(resultat):
    """Un outil qui avertit n'a pas échoué : la sortie prime, l'avis est annoncé.

    readelf signale sur stderr les anomalies du fichier analysé — « le segment
    PHDR n'est pas couvert par un segment LOAD », classique sur un binaire lié à
    la main — puis CONTINUE et rend ce qu'on lui a demandé, avec un code de
    retour non nul. Traiter ce code comme un échec jette une analyse parfaitement
    exploitable, et c'est ce qui faisait rendre « ? » à tous les croisements.

    La règle : si l'outil a écrit quelque chose sur sa sortie normale, le
    résultat est exploitable ; le code de retour reste fidèle dans `code`, et un
    drapeau `averti` dit qu'il y a eu un avis, lequel remonte dans
    `avertissements` pour être annoncé. Un outil qui n'a RIEN écrit reste un
    échec — sinon un fichier absent passerait pour une analyse vide.
    """
    if not resultat.get('ok') and (resultat.get('sortie') or '').strip():
        resultat = dict(resultat)
        resultat['ok'] = True
        resultat['averti'] = True
    return resultat


def desassembler(chemin, debut=None, fin=None, symbole=None, syntaxe='att',
                 lignes=2000, arguments_supplementaires=()):
    """Le désassemblage via objdump, borné et rendu en texte.

    `objdump -d` sur un binaire de 200 Mo rend des centaines de Mo de texte : le
    panneau s'effondrerait. La borne est donc posée AVANT de lancer, par une
    plage d'adresses ou un symbole, et la troncature est annoncée plutôt que
    silencieuse.
    """
    outil = _outil('objdump')
    if not outil:
        return {'ok': False, 'texte': '',
                'erreur': 'objdump n’est pas installé : le désassemblage n’est '
                          'pas possible. Commande : sudo apt install binutils. '
                          'Sans lui, ce module lit quand même les en-têtes, les '
                          'sections, les symboles et les chaînes, en Python pur.'}
    commande = [outil, '-d']
    if syntaxe == 'intel':
        commande += ['-M', 'intel']
    if symbole:
        commande += ['--disassemble=%s' % symbole]
    elif debut is not None:
        commande += ['--start-address=%s' % _adresse(debut)]
        if fin is not None:
            commande += ['--stop-address=%s' % _adresse(fin)]
    commande += list(arguments_supplementaires)
    commande += ['--', str(chemin)]
    resultat = _lancer(commande, delai=180)
    if (syntaxe == 'intel' and not resultat['ok']
            and 'intel' in (resultat.get('erreur') or '').lower()):
        # -M intel n’existe que pour les architectures x86. Sur ARM ou RISC-V,
        # objdump refuse toute l’analyse : retomber sur la syntaxe par défaut et
        # LE DIRE vaut mieux que rendre un échec ou, pire, un désassemblage
        # présenté comme étant en syntaxe Intel alors qu’il ne l’est pas.
        sans = [a for a in commande if a not in ('-M', 'intel')]
        seconde = _lancer(sans, delai=180)
        if seconde['ok']:
            seconde['note_syntaxe'] = (
                'La syntaxe Intel n’est pas prise en charge pour cette '
                'architecture : le désassemblage est rendu en syntaxe AT&T, '
                'celle par défaut d’objdump.')
            seconde['commande'] = ' '.join(sans)
            resultat = seconde
    # La normalisation passe APRÈS le repli « -M intel » : si elle passait
    # avant, `ok` deviendrait vrai dès qu'objdump a écrit quelque chose, et le
    # repli qui annonce une syntaxe Intel indisponible ne se déclencherait plus.
    resultat = _normaliser_outil(resultat)
    if not resultat['ok'] and resultat.get('code') is not None:
        resultat['erreur'] = (resultat.get('erreur') or '').strip() or (
            'objdump a rendu le code %d.' % resultat['code'])
    texte = resultat.get('sortie', '')
    if texte:
        lignes_texte = texte.split('\n')
        if len(lignes_texte) > lignes:
            texte = '\n'.join(lignes_texte[:lignes])
            resultat['tronquee'] = True
            resultat['note'] = (
                '%d lignes produites, les %d premières sont rendues. Précisez une '
                'plage d’adresses ou un symbole pour cibler.'
                % (len(lignes_texte), lignes))
    resultat['texte'] = texte
    resultat['commande'] = ' '.join(commande)
    return resultat


def _adresse(valeur):
    """Une adresse en hexadécimal, acceptée en entier ou en texte 0x…"""
    if isinstance(valeur, int):
        return '0x%x' % valeur
    texte = str(valeur).strip()
    if re.fullmatch(r'0[xX][0-9a-fA-F]+|\d+', texte):
        return '0x%x' % int(texte, 0)
    raise ValueError


def demarrer_adresse(chemin, adresse_debut, adresse_fin=None, syntaxe='att'):
    """Alias lisible : désassemble une plage. Lève si l'adresse est invalide.

    Lever ici est voulu : une adresse inventée produirait un désassemblage vide
    ou décalé que rien ne distinguerait d'un vrai. Le panneau affiche l'erreur.
    """
    try:
        debut = _adresse(adresse_debut)
        fin = _adresse(adresse_fin) if adresse_fin is not None else None
    except ValueError:
        return {'ok': False, 'texte': '',
                'erreur': 'L’adresse « %s » n’est ni un entier ni un '
                          'hexadécimal 0x…' % adresse_debut}
    return desassembler(chemin, debut=debut, fin=fin, syntaxe=syntaxe)


def readelf(chemin, options=('-a',)):
    """readelf avec des options validées sur une liste blanche.

    Une liste blanche est nécessaire : passer les options de l'utilisateur telles
    quelles à readelf permettrait `--output` ou des arguments de fichier
    supplémentaires, et l'outil écrirait où il ne devrait pas.
    """
    AUTORISEES = {'-h', '-l', '-S', '-s', '-r', '-d', '-V', '-a', '-A', '-D',
                  '-n', '-u', '-x', '-p', '--headers', '--segments',
                  '--sections', '--symbols', '--relocs', '--dynamic',
                  '--version-info', '--all', '--arch-specific', '--use-dynamic',
                  '--notes', '--unwind', '--hex-dump', '--string-dump',
                  '--wide', '-W', '--demangle', '-C'}
    outil = _outil('readelf')
    if not outil:
        return {'ok': False, 'sortie': '',
                'erreur': 'readelf n’est pas installé (sudo apt install '
                          'binutils). Les en-têtes sont de toute façon lus en '
                          'Python pur par ce module.'}
    commande = [outil]
    for option in options:
        if option not in AUTORISEES:
            return {'ok': False, 'sortie': '',
                    'erreur': 'L’option « %s » n’est pas dans la liste '
                              'autorisée : %s.' % (option,
                                                   ', '.join(sorted(AUTORISEES)))}
        commande.append(option)
    commande += ['--', str(chemin)]
    resultat = _normaliser_outil(_lancer(commande, delai=120))
    resultat['sortie'] = resultat.get('sortie', '')
    resultat['commande'] = ' '.join(commande)
    return resultat


def symboles_nm(chemin, seulement_definis=False, demangler=True, taille=True):
    """Les symboles via nm, dé-manglés si c++filt est là.

    Les noms C++ sont illisibles manglés (`_ZN5Classe6MethodeEv`). Sans
    c++filt, nm rend ces noms bruts : ils sont alors rendus TELS QUELS, avec la
    raison, plutôt que passés à un démangleur maison approximatif qui produirait
    des signatures fausses.
    """
    outil = _outil('nm')
    if not outil:
        return {'ok': False, 'symboles': [],
                'erreur': 'nm n’est pas installé (sudo apt install binutils).'}
    commande = [outil, '-p']
    if seulement_definis:
        commande.append('--defined-only')
    if taille:
        commande.append('-S')
    if demangler and _outil('c++filt'):
        commande.append('-C')
    commande += ['--', str(chemin)]
    resultat = _lancer(commande, delai=120)
    resultat['commande'] = ' '.join(commande)
    symboles = []
    for ligne in resultat.get('sortie', '').split('\n'):
        if not ligne.strip():
            continue
        morceaux = ligne.split()
        if len(morceaux) >= 3 and re.fullmatch(r'[0-9a-fA-F]+', morceaux[0]):
            symboles.append({'adresse': int(morceaux[0], 16),
                             'adresse_hex': morceaux[0],
                             'type': morceaux[1],
                             'taille': int(morceaux[2], 16)
                             if re.fullmatch(r'[0-9a-fA-F]+', morceaux[2]) else 0,
                             'nom': ' '.join(morceaux[3:]) if len(morceaux) > 3
                             else '',
                             'type_lecture': _type_symbole_nm(morceaux[1])})
        elif len(morceaux) >= 2:
            premier = morceaux[0]
            if re.fullmatch(r'[0-9a-fA-F]+', premier):
                symboles.append({'adresse': int(premier, 16),
                                 'adresse_hex': premier, 'type': morceaux[1],
                                 'taille': 0,
                                 'nom': ' '.join(morceaux[2:])
                                 if len(morceaux) > 2 else '',
                                 'type_lecture': _type_symbole_nm(morceaux[1])})
            else:
                symboles.append({'adresse': None, 'adresse_hex': '',
                                 'type': premier, 'taille': 0,
                                 'nom': ' '.join(morceaux[1:]),
                                 'type_lecture': _type_symbole_nm(premier)})
    resultat['symboles'] = symboles
    resultat['nombre'] = len(symboles)
    resultat = _normaliser_outil(resultat)
    if not resultat['ok'] and not symboles:
        resultat['erreur'] = (resultat.get('erreur') or '').strip() or (
            'nm n’a rendu aucun symbole : le binaire est dépouillé, ou ce '
            'format n’a pas de table de symboles que nm sache lire.')
    if demangler and not _outil('c++filt') and any(
            s['nom'].startswith('_Z') for s in symboles):
        resultat['note_demangling'] = (
            'c++filt n’est pas installé : les noms C++ sont rendus manglés '
            '(_Z…). Commande : sudo apt install binutils (il fournit c++filt). '
            'Les démangler à la main produirait des signatures fausses, donc '
            'Pascal Studio ne le fait pas.')
    return resultat


TYPES_NM = {
    'T': 'Code, global, défini', 't': 'Code, local, défini',
    'D': 'Données initialisées, global', 'd': 'Données initialisées, local',
    'B': 'Données non initialisées (BSS), global',
    'b': 'Données non initialisées (BSS), local',
    'R': 'Données en lecture seule, global', 'r': 'Données en lecture seule, local',
    'U': 'Non défini : importé d’une autre unité',
    'W': 'Faible (weak), peut être redéfini', 'w': 'Faible, non défini',
    'V': 'Objet faible', 'v': 'Objet faible non défini',
    'A': 'Absolu : ne sera pas relocalisé', 'C': 'Symbole commun (BSS partagé)',
    'N': 'Symbole de débogage', 'i': 'Section spécifique (GNU indirect)',
    'I': 'Référence indirecte à un autre symbole',
    'G': 'Données initialisées pour un petit objet',
    'S': 'Données non initialisées pour un petit objet',
    'n': 'Symbole indirect (définition dans une autre unité)',
    '?': 'Type inconnu ou non documenté pour ce format',
}


def _type_symbole_nm(lettre):
    return TYPES_NM.get(lettre, 'type « %s » non documenté' % lettre)


def vidage(chemin, debut=0, longueur=512, colonnes=16, ascii_=True):
    """Vidage hexadécimal en Python pur, identique en forme à `od -A x -t x1z`.

    Fait maison plutôt que via `od` parce que `od` n'est pas toujours là et
    qu'un vidage est la toute première chose qu'on regarde sur un fichier
    inconnu. La forme est volontairement celle de od/xxd : l'utilisateur la
    reconnaît.
    """
    longueur = max(0, min(int(longueur), 1 << 20))
    colonnes = max(1, min(int(colonnes), 64))
    with Lecteur(chemin) as lecteur:
        if debut >= lecteur.taille:
            return {'ok': True, 'debut': debut, 'longueur_demandee': longueur,
                    'longueur_rendue': 0, 'colonnes': colonnes, 'texte': '',
                    'lignes': 0,
                    'note': 'La plage demandée commence à %d, au-delà de la fin '
                            'du fichier (%d octets) : il n’y a rien à afficher.'
                            % (debut, lecteur.taille)}
        donnees = lecteur.lire_reel(debut, longueur)
        troncatures = list(lecteur.troncatures)
    lignes = []
    for position in range(0, len(donnees), colonnes):
        morceau = donnees[position:position + colonnes]
        hexadecimal = ' '.join('%02x' % octet for octet in morceau)
        hexadecimal = hexadecimal.ljust(colonnes * 3 - 1)
        if colonnes == 16 and len(morceau) > 8:
            hexadecimal = hexadecimal[:8 * 3 - 1] + '  ' + hexadecimal[8 * 3:]
        if ascii_:
            texte = ''.join(chr(octet) if 0x20 <= octet < 0x7f else '.'
                            for octet in morceau)
            lignes.append('%08x  %s  |%s|' % (debut + position, hexadecimal, texte))
        else:
            lignes.append('%08x  %s' % (debut + position, hexadecimal))
    sortie = {'ok': True, 'debut': debut, 'longueur_demandee': longueur,
              'longueur_rendue': len(donnees), 'colonnes': colonnes,
              'texte': '\n'.join(lignes), 'lignes': len(lignes)}
    if troncatures:
        sortie['troncatures'] = troncatures
        sortie['note'] = ('Le fichier est plus court que demandé : %s'
                          % troncatures[0])
    if len(donnees) < longueur:
        sortie['note'] = ('%d octets rendus sur %d demandés : le fichier '
                          's’arrête avant.' % (len(donnees), longueur))
    return sortie


def identifer(chemin):
    """L'avis de `file`, quand il est là — une signature indépendante des nôtres.

    Croiser notre lecture avec `file` est un contrôle réel : si `file` dit
    « data » là où nous disons « ELF », l'un des deux se trompe et l'utilisateur
    doit le voir.
    """
    outil = _outil('file')
    if not outil:
        return {'ok': False, 'avis': '',
                'raison': 'file n’est pas installé : aucune identification '
                          'indépendante n’est possible (sudo apt install file).'}
    resultat = _lancer([outil, '-b', '--', str(chemin)], delai=20)
    avis = resultat.get('sortie', '').strip()
    return {'ok': bool(avis), 'avis': avis,
            'erreur': resultat.get('erreur', '') if not avis else '',
            'commande': '%s -b -- %s' % (outil, chemin)}


def analyser(chemin, avec_chaines=True, longueur_chaines=512 * 1024,
             entropie_sections=True, minimum_chaine=CHAINE_MIN):
    """Le rapport complet d'un fichier : famille, structure, indices, empreintes.

    C'est ce que le panneau affiche à l'ouverture d'un binaire. Tout est rendu
    dans une seule réponse parce qu'un rapport dont les parties arrivent
    séparément laisse croire, quand l'une manque, qu'elle est vide alors qu'elle
    a échoué.
    """
    chemin = Path(chemin)
    rapport = {'ok': True, 'chemin': str(chemin), 'nom': chemin.name,
               'version': VERSION, 'notes': [], 'erreurs': []}
    try:
        taille = chemin.stat().st_size
    except OSError as exc:
        return {'ok': False, 'chemin': str(chemin),
                'erreur': 'Fichier illisible : %s' % (exc.strerror or exc),
                'notes': [], 'erreurs': [str(exc)]}
    rapport['taille'] = taille
    rapport['taille_texte'] = _taille_texte(taille)
    if taille == 0:
        rapport.update({'famille': {'famille': 'vide', 'nom': 'fichier vide',
                                    'raison': 'Un fichier de 0 octet n’a pas de '
                                              'signature à lire.'},
                        'structure': {}, 'indices': [], 'empreintes': {},
                        'chaines': []})
        rapport['notes'].append('Le fichier est vide.')
        return rapport
    with Lecteur(chemin) as lecteur:
        tete = lecteur.lire(0, min(taille, 65536))
    rapport['empreintes'] = empreintes_fichier(chemin)
    if not rapport['empreintes'].get('ok'):
        rapport['notes'].append(rapport['empreintes'].get('erreur', ''))
    identification = famille(tete, chemin)
    rapport['famille'] = identification
    rapport['avis_file'] = identifer(chemin)
    if rapport['avis_file'].get('ok'):
        rapport['famille']['avis_independant'] = rapport['avis_file']['avis']
    famille_lue = identification['famille']
    structure = {}
    with Lecteur(chemin) as lecteur:
        if famille_lue == 'elf':
            structure = lire_elf(lecteur)
        elif famille_lue == 'pe':
            structure = lire_pe(lecteur)
        elif famille_lue in ('macho', 'ambigue'):
            structure = lire_macho(lecteur)
            if structure.get('ambigu'):
                rapport['notes'].append(
                    'Signature 0xCAFEBABE ambiguë : binaire gras Mach-O ou '
                    'classe Java. La lecture Mach-O a été tentée et '
                    'n’a rien donné de cohérent, ce qui penche vers Java.')
        elif famille_lue == 'class-java':
            structure = lire_class_java(lecteur)
        elif famille_lue == 'wasm':
            structure = lire_wasm(lecteur)
        else:
            rapport['notes'].append(
                'La famille « %s » n’a pas de lecteur structurel dans Pascal '
                'Studio : seuls le vidage hexadécimal, les chaînes, les '
                'empreintes et l’entropie sont disponibles. %s'
                % (famille_lue, identification.get('raison', '')))
    if structure.get('erreur'):
        rapport['erreurs'].append(structure['erreur'])
        rapport['notes'].append(structure['erreur'])
    rapport['structure'] = structure
    if structure.get('notes_lecture'):
        rapport['notes'].extend(structure['notes_lecture'][:10])
    if entropie_sections and structure.get('sections'):
        rapport['entropie_sections'] = entropie_par_section(chemin, structure)
    rapport['indices'] = heuristiques(chemin, structure, tete)
    if avec_chaines:
        extrait = chaines(chemin, minimum=minimum_chaine, debut=0,
                          longueur=min(taille, longueur_chaines),
                          encodages=('ascii', 'utf16'))
        if not extrait['ok']:
            rapport['notes'].append('Chaînes illisibles : %s'
                                    % extrait.get('erreur', ''))
            extrait = {'chaines': [], 'compte': 0}
        else:
            attribuer_chaines(structure, extrait['chaines'])
        rapport['chaines'] = extrait.get('chaines', [])[:2000]
        rapport['chaines_compte'] = extrait.get('compte', 0)
        if extrait.get('tronque'):
            rapport['notes'].append(extrait.get('note', ''))
        if taille > longueur_chaines:
            rapport['notes'].append(
                'Les chaînes n’ont été cherchées que dans les %s premiers '
                'octets du fichier (%s au total). Demandez une plage précise '
                'pour aller plus loin.'
                % (_taille_texte(longueur_chaines), _taille_texte(taille)))
    rapport['resume'] = structure.get('resume', [])
    rapport['notes'] = [n for n in rapport['notes'] if n]
    return rapport


def _taille_texte(octets):
    for unite, seuil in (('To', 1 << 40), ('Go', 1 << 30), ('Mo', 1 << 20),
                         ('Ko', 1 << 10)):
        if octets >= seuil:
            return '%.1f %s' % (octets / seuil, unite)
    return '%d o' % octets


def lire_class_java(lecteur):
    """Une classe Java : version, constantes, méthodes. Suffisant pour trier."""
    resultat = {'format': 'classe Java', 'resume': [], 'notes_lecture': [],
                'constantes': [], 'methodes': [], 'champs': []}
    magique, mineur, majeur = lecteur.entier(0, '>IHH')
    if magique != 0xCAFEBABE:
        resultat['erreur'] = 'Signature 0xCAFEBABE absente.'
        return resultat
    versions = {45: '1.1', 46: '1.2', 47: '1.3', 48: '1.4', 49: '5',
                50: '6', 51: '7', 52: '8', 53: '9', 54: '10', 55: '11',
                56: '12', 57: '13', 58: '14', 59: '15', 60: '16', 61: '17',
                62: '18', 63: '19', 64: '20', 65: '21', 66: '22', 67: '23',
                68: '24'}
    resultat['version_majeure'] = majeur
    resultat['version'] = versions.get(majeur, 'inconnue (%d)' % majeur)
    resultat['version_mineure'] = mineur
    nombre = lecteur.u16(8, '>')
    resultat['constantes_total'] = nombre
    if nombre > 65535:
        resultat['erreur'] = '%d constantes annoncées : invraisemblable.' % nombre
        return resultat
    position = 10
    index = 1
    while index < nombre and position < lecteur.taille:
        etiquette = lecteur.u8(position, '>')
        position += 1
        if etiquette == 1:
            longueur = lecteur.u16(position, '>')
            position += 2
            texte = lecteur.octets(position, longueur).decode('utf8', 'replace')
            position += longueur
            resultat['constantes'].append({'index': index, 'type': 'Utf8',
                                           'texte': texte})
        elif etiquette in (7, 8, 16, 19, 20):
            position += 2
            resultat['constantes'].append({'index': index, 'type': etiquette})
        elif etiquette == 15:
            position += 3
        elif etiquette in (3, 4, 9, 10, 11, 12, 17, 18):
            position += 4
        elif etiquette in (5, 6):
            # Long et Double font 8 octets et occupent DEUX cases du pool : la
            # case suivante est inutilisable. Ne pas les rendre ferait croire que
            # le pool est plus court qu’il n’est.
            position += 8
            resultat['constantes'].append(
                {'index': index,
                 'type': 'Long' if etiquette == 5 else 'Double',
                 'occupe_deux_cases': True})
            index += 1
        else:
            resultat['erreur'] = ('Étiquette de constante %d inconnue à '
                                  'l’entrée %d : le fichier n’est pas une '
                                  'classe Java valide.' % (etiquette, index))
            break
        index += 1
    resultat['resume'] = ['Classe Java, format %s (majeur %d, mineur %d).'
                          % (resultat['version'], majeur, mineur),
                          '%d constante(s) dans le pool ; %d chaîne(s) lue(s).'
                          % (nombre, len(resultat['constantes'])),
                          'Le bytecode Java n’est pas du code machine : il se '
                          'lit avec un décompilateur Java, pas avec objdump ni '
                          'avec Ghidra.']
    resultat['notes_lecture'] = list(lecteur.troncatures)
    return resultat


def lire_wasm(lecteur):
    """Un module WebAssembly : version et sections. Le bytecode n'est pas décodé.

    Décoder le bytecode WASM demanderait un interpréteur complet ; annoncer une
    analyse qui n'est pas faite serait pire que dire clairement ce qui est lu.
    """
    resultat = {'format': 'WebAssembly', 'sections': [], 'resume': [],
                'notes_lecture': []}
    magique = lecteur.octets(0, 4)
    if magique != b'\x00asm':
        resultat['erreur'] = 'Signature \\0asm absente.'
        return resultat
    version = lecteur.u32(4)
    resultat['version'] = version
    NOMS = {0: 'personnalisée', 1: 'types', 2: 'imports', 3: 'fonctions',
            4: 'tables', 5: 'mémoires', 6: 'globales', 7: 'exports',
            8: 'start', 9: 'éléments', 10: 'code', 11: 'données',
            12: 'compteur de données'}
    position = 8
    while position + 2 <= lecteur.taille and len(resultat['sections']) < 256:
        identifiant = lecteur.u8(position)
        position += 1
        taille = 0
        decalage = 0
        while True:
            octet = lecteur.u8(position + decalage)
            taille |= (octet & 0x7f) << (7 * decalage)
            decalage += 1
            if not octet & 0x80 or decalage > 5:
                break
        position += decalage
        entree = {'identifiant': identifiant,
                  'nom': NOMS.get(identifiant, 'inconnue (%d)' % identifiant),
                  'taille': taille, 'decalage': position}
        if identifiant == 0:
            nom_taille = 0
            decalage = 0
            while True:
                octet = lecteur.u8(position + decalage)
                nom_taille |= (octet & 0x7f) << (7 * decalage)
                decalage += 1
                if not octet & 0x80 or decalage > 5:
                    break
            if 0 < nom_taille < 256:
                entree['nom_personnalise'] = lecteur.octets(
                    position + decalage, nom_taille).decode('utf8', 'replace')
        resultat['sections'].append(entree)
        position += taille
        if taille == 0:
            break
    resultat['resume'] = ['Module WebAssembly version %d, %d section(s).'
                          % (version, len(resultat['sections'])),
                          'Le bytecode n’est pas décodé ici : il faut '
                          'wat2wasm/wasm2wat ou un décompilateur WASM.']
    resultat['notes_lecture'] = list(lecteur.troncatures)
    return resultat


# --------------------------------------------------------------------------
# Autocontrôle
# --------------------------------------------------------------------------

def _synthese_elf64(dossier):
    """Construit un ELF64 little-endian complet, octet par octet.

    Aucun banc ne doit dépendre de gcc : sur une machine sans compilateur, le
    contrôle ne testerait plus rien, et personne ne s'en apercevrait. Le binaire
    est donc écrit à la main, avec tout ce qu'un vrai exécutable PIE de Debian
    porte : .text, .rodata, .comment, une note de build-id, .interp, .dynstr,
    .dynsym, .dynamic avec NEEDED, .strtab et .symtab, sept segments, et un
    fichier dont l'ordre suit les adresses virtuelles pour que les PT_LOAD soient
    cohérents.
    """
    texte = (b'\x55\x48\x89\xe5\xb8\x01\x00\x00\x00\x5d\xc3'      # main
             + b'\x48\x8d\x05\x00\x00\x00\x00\x89\xf8\xc3')       # fonction_locale
    rodata = b'https://exemple.test/api/secret?cle=abcd\x00'
    commentaire = b'GCC: (Debian 12.2.0-14) 12.2.0\x00'
    interprete = b'/lib64/ld-linux-x86-64.so.2\x00'
    build_id = bytes(range(1, 21))
    note = struct.pack('<III', 4, len(build_id), 3) + b'GNU\x00' + build_id
    noms_dyn = b'\x00libc.so.6\x00puts\x00message_secret\x00'
    noms_symboles = b'\x00main\x00fonction_locale\x00reference.c\x00'

    dynsym = b''
    dynsym += struct.pack('<IBBHQQ', 0, 0, 0, 0, 0, 0)                  # NULL
    dynsym += struct.pack('<IBBHQQ', 11, (1 << 4) | 2, 0, 0, 0, 0)      # puts UNDEF
    dynsym += struct.pack('<IBBHQQ', 16, (1 << 4) | 1, 0, 2, 0x2000,
                          len(rodata))                                  # exporté
    symtab = b''
    symtab += struct.pack('<IBBHQQ', 0, 0, 0, 0, 0, 0)                  # NULL
    symtab += struct.pack('<IBBHQQ', 1, (1 << 4) | 2, 0, 1, 0x1000, 12)  # main
    symtab += struct.pack('<IBBHQQ', 6, (1 << 4) | 2, 0, 1, 0x100c, 12)
    symtab += struct.pack('<IBBHQQ', 22, (0 << 4) | 4, 0, 0xfff1, 0, 0)  # FILE, ABS
    dynamic = b''
    dynamic += struct.pack('<QQ', 1, 1)                 # NEEDED libc.so.6
    dynamic += struct.pack('<QQ', 5, 0x2200)            # STRTAB
    dynamic += struct.pack('<QQ', 10, len(noms_dyn))    # STRSZ
    dynamic += struct.pack('<QQ', 6, 0x2300)            # SYMTAB
    dynamic += struct.pack('<QQ', 11, 24)               # SYMENT
    dynamic += struct.pack('<QQ', 0, 0)                 # DT_NULL

    phoff = 64
    phnum = 7
    pieces = [('texte', texte), ('rodata', rodata), ('note', note),
              ('noms_dyn', noms_dyn), ('dynsym', dynsym), ('dynamic', dynamic),
              ('interprete', interprete), ('commentaire', commentaire),
              ('noms_symboles', noms_symboles), ('symtab', symtab)]
    positions = {}
    curseur = phoff + 56 * phnum
    for nom, donnees in pieces:
        positions[nom] = curseur
        curseur += len(donnees)
        if curseur % 8:
            curseur += 8 - (curseur % 8)

    shstrtab = b'\x00'
    index_noms = {}
    for nom in ('.text', '.rodata', '.comment', '.note.gnu.build-id', '.interp',
                '.dynstr', '.dynsym', '.dynamic', '.strtab', '.symtab',
                '.shstrtab'):
        index_noms[nom] = len(shstrtab)
        shstrtab += nom.encode() + b'\x00'
    positions['shstrtab'] = curseur
    curseur += len(shstrtab)
    if curseur % 8:
        curseur += 8 - (curseur % 8)
    shoff = curseur

    # (nom, type, drapeaux, adresse, decalage, taille, lien, info, align, entsize)
    sections = [
        ('', 0, 0, 0, 0, 0, 0, 0, 0, 0),
        ('.text', 1, 0x6, 0x1000, positions['texte'], len(texte), 0, 0, 16, 0),
        ('.rodata', 1, 0x2, 0x2000, positions['rodata'], len(rodata), 0, 0, 8, 0),
        ('.comment', 1, 0x30, 0, positions['commentaire'], len(commentaire),
         0, 0, 1, 1),
        ('.note.gnu.build-id', 7, 0x2, 0x2100, positions['note'], len(note),
         0, 0, 4, 0),
        ('.interp', 1, 0x2, 0x3100, positions['interprete'], len(interprete),
         0, 0, 1, 0),
        ('.dynstr', 3, 0x2, 0x2200, positions['noms_dyn'], len(noms_dyn),
         0, 0, 1, 0),
        ('.dynsym', 11, 0x2, 0x2300, positions['dynsym'], len(dynsym), 6, 1, 8,
         24),
        ('.dynamic', 6, 0x3, 0x3000, positions['dynamic'], len(dynamic), 6, 0,
         8, 16),
        ('.strtab', 3, 0, 0, positions['noms_symboles'], len(noms_symboles),
         0, 0, 1, 0),
        ('.symtab', 2, 0, 0, positions['symtab'], len(symtab), 9, 1, 8, 24),
        ('.shstrtab', 3, 0, 0, positions['shstrtab'], len(shstrtab), 0, 0, 1, 0),
    ]
    shnum = len(sections)
    shstrndx = shnum - 1

    debut_charge = positions['rodata']
    fin_charge = positions['interprete'] + len(interprete)
    segments = [
        struct.pack('<IIQQQQQQ', 6, 4, phoff, phoff, phoff, 56 * phnum,
                    56 * phnum, 8),                                   # PHDR
        struct.pack('<IIQQQQQQ', 3, 4, positions['interprete'], 0x3100,
                    0x3100, len(interprete), len(interprete), 1),     # INTERP
        struct.pack('<IIQQQQQQ', 1, 5, positions['texte'], 0x1000, 0x1000,
                    len(texte), len(texte), 0x1000),                  # LOAD R+E
        struct.pack('<IIQQQQQQ', 1, 4, debut_charge, 0x2000, 0x2000,
                    fin_charge - debut_charge, fin_charge - debut_charge,
                    0x1000),                                          # LOAD R
        struct.pack('<IIQQQQQQ', 4, 4, positions['note'], 0x2100, 0x2100,
                    len(note), len(note), 4),                         # NOTE
        struct.pack('<IIQQQQQQ', 2, 6, positions['dynamic'], 0x3000,
                    0x3000, len(dynamic), len(dynamic), 8),           # DYNAMIC
        struct.pack('<IIQQQQQQ', 0x6474e551, 6, 0, 0, 0, 0, 0, 16),   # GNU_STACK
    ]

    fichier = bytearray(shoff + 64 * shnum)
    fichier[0:4] = b'\x7fELF'
    fichier[4] = 2                                   # ELFCLASS64
    fichier[5] = 1                                   # ELFDATA2LSB
    fichier[6] = 1                                   # EV_CURRENT
    fichier[7] = 3                                   # ELFOSABI_LINUX
    fichier[16:64] = struct.pack('<HHIQQQIHHHHHH', 3, 62, 1, 0x1000, phoff,
                                 shoff, 0, 64, 56, phnum, 64, shnum, shstrndx)
    fichier[phoff:phoff + 56 * phnum] = b''.join(segments)
    for nom, donnees in pieces:
        debut = positions[nom]
        fichier[debut:debut + len(donnees)] = donnees
    debut = positions['shstrtab']
    fichier[debut:debut + len(shstrtab)] = shstrtab
    for index, (nom, type_s, drapeaux, adresse, decalage, taille, lien, info,
                alignement, entsize) in enumerate(sections):
        base = shoff + index * 64
        fichier[base:base + 64] = struct.pack(
            '<IIQQQQIIQQ', index_noms.get(nom, 0), type_s, drapeaux, adresse,
            decalage, taille, lien, info, alignement, entsize)
    chemin = Path(dossier) / 'synthese.elf'
    chemin.write_bytes(bytes(fichier))
    attendu = {
        'texte': texte,
        'chaine': rodata.rstrip(b'\x00').decode(),
        'build_id': binascii.hexlify(build_id).decode(),
        'interprete': interprete.rstrip(b'\x00').decode(),
        'compilateur': commentaire.split(b'\x00')[0].decode(),
        'shoff': shoff, 'shnum': shnum, 'phnum': phnum,
        'entree': 0x1000, 'taille': len(fichier),
        'bibliotheques': ['libc.so.6'],
        'fonctions_importees': ['puts'],
        'symboles_exportes': ['message_secret'],
        'symboles': ['main', 'fonction_locale', 'reference.c'],
    }
    return chemin, attendu


def _synthese_elf32be(dossier):
    """Construit un ELF32 BIG-ENDIAN (MIPS), octet par octet.

    Cette synthèse n'est pas un luxe : les largeurs de champs ET leur ordre
    diffèrent entre ELF32 et ELF64, et pas seulement par la taille. En 32 bits,
    un en-tête de programme place p_flags en SEPTIÈME position alors qu'en 64
    bits il est en deuxième ; un symbole place st_value et st_size AVANT st_info
    alors qu'en 64 bits ils viennent après. Un parseur écrit pour l'x86-64
    little-endian — le seul format que produit un banc Linux ordinaire — lit donc
    un binaire MIPS ou PowerPC de travers sans jamais lever. Et comme le boutisme
    inverse aussi l'ordre des octets de chaque champ, l'erreur ne se voit pas :
    elle produit des tailles et des adresses plausibles.
    """
    texte = b'\x27\xbd\xff\xe0' + b'\x03\xe0\x00\x08' + b'\x00' * 4
    rodata = b'CHAINE_BIG_ENDIAN_DE_CONTROLE\x00'
    noms_dyn = b'\x00libm.so.6\x00malloc\x00'
    noms_symboles = b'\x00main\x00calcul\x00'

    dynsym = b''
    dynsym += struct.pack('>IIIBBH', 0, 0, 0, 0, 0, 0)                 # NULL
    # noms_dyn = \x00 libm.so.6 \x00 malloc \x00 : « malloc » commence à 11,
    # pas à 10 — 10 est le NUL qui termine « libm.so.6 ».
    dynsym += struct.pack('>IIIBBH', 11, 0, 0, (1 << 4) | 2, 0, 0)      # UNDEF
    symtab = b''
    symtab += struct.pack('>IIIBBH', 0, 0, 0, 0, 0, 0)
    symtab += struct.pack('>IIIBBH', 1, 0x00400100, len(texte),
                          (1 << 4) | 2, 0, 1)                           # main
    symtab += struct.pack('>IIIBBH', 6, 0x00400110, 8, (1 << 4) | 2, 0, 1)
    dynamic = b''
    dynamic += struct.pack('>II', 1, 1)                 # NEEDED libm.so.6
    dynamic += struct.pack('>II', 5, 0x2200)            # STRTAB
    dynamic += struct.pack('>II', 10, len(noms_dyn))    # STRSZ
    dynamic += struct.pack('>II', 6, 0x2300)            # SYMTAB
    dynamic += struct.pack('>II', 11, 16)               # SYMENT
    dynamic += struct.pack('>II', 0, 0)                 # DT_NULL

    phoff = 52
    phnum = 2
    pieces = [('texte', texte), ('rodata', rodata), ('noms_dyn', noms_dyn),
              ('dynsym', dynsym), ('dynamic', dynamic),
              ('noms_symboles', noms_symboles), ('symtab', symtab)]
    positions = {}
    curseur = phoff + 32 * phnum
    for nom, donnees in pieces:
        positions[nom] = curseur
        curseur += len(donnees)
        if curseur % 4:
            curseur += 4 - (curseur % 4)

    shstrtab = b'\x00'
    index_noms = {}
    for nom in ('.text', '.rodata', '.dynstr', '.dynsym', '.dynamic', '.strtab',
                '.symtab', '.shstrtab'):
        index_noms[nom] = len(shstrtab)
        shstrtab += nom.encode() + b'\x00'
    positions['shstrtab'] = curseur
    curseur += len(shstrtab)
    if curseur % 4:
        curseur += 4 - (curseur % 4)
    shoff = curseur

    sections = [
        ('', 0, 0, 0, 0, 0, 0, 0, 0, 0),
        ('.text', 1, 0x6, 0x00400100, positions['texte'], len(texte), 0, 0, 16,
         0),
        ('.rodata', 1, 0x2, 0x00402000, positions['rodata'], len(rodata), 0, 0,
         4, 0),
        ('.dynstr', 3, 0x2, 0x2200, positions['noms_dyn'], len(noms_dyn), 0, 0,
         1, 0),
        ('.dynsym', 11, 0x2, 0x2300, positions['dynsym'], len(dynsym), 3, 1, 4,
         16),
        ('.dynamic', 6, 0x3, 0x3000, positions['dynamic'], len(dynamic), 3, 0,
         4, 8),
        ('.strtab', 3, 0, 0, positions['noms_symboles'], len(noms_symboles), 0,
         0, 1, 0),
        ('.symtab', 2, 0, 0, positions['symtab'], len(symtab), 6, 1, 4, 16),
        ('.shstrtab', 3, 0, 0, positions['shstrtab'], len(shstrtab), 0, 0, 1, 0),
    ]
    shnum = len(sections)
    segments = [
        # ELF32 : p_type, p_offset, p_vaddr, p_paddr, p_filesz, p_memsz,
        # p_flags, p_align — p_flags est en SEPTIÈME position, pas en deuxième.
        struct.pack('>IIIIIIII', 1, positions['texte'], 0x00400100, 0x00400100,
                    positions['dynamic'] + len(dynamic) - positions['texte'],
                    positions['dynamic'] + len(dynamic) - positions['texte'],
                    5, 0x1000),
        struct.pack('>IIIIIIII', 2, positions['dynamic'], 0x3000, 0x3000,
                    len(dynamic), len(dynamic), 6, 4),
    ]

    fichier = bytearray(shoff + 40 * shnum)
    fichier[0:4] = b'\x7fELF'
    fichier[4] = 1                                   # ELFCLASS32
    fichier[5] = 2                                   # ELFDATA2MSB : big-endian
    fichier[6] = 1
    fichier[7] = 0                                   # ELFOSABI_SYSV
    fichier[16:52] = struct.pack('>HHIIIIIHHHHHH', 2, 8, 1, 0x00400100, phoff,
                                 shoff, 0x20000001, 52, 32, phnum, 40, shnum,
                                 shnum - 1)
    fichier[phoff:phoff + 32 * phnum] = b''.join(segments)
    for nom, donnees in pieces:
        debut = positions[nom]
        fichier[debut:debut + len(donnees)] = donnees
    debut = positions['shstrtab']
    fichier[debut:debut + len(shstrtab)] = shstrtab
    for index, (nom, type_s, drapeaux, adresse, decalage, taille, lien, info,
                alignement, entsize) in enumerate(sections):
        base = shoff + index * 40
        fichier[base:base + 40] = struct.pack(
            '>IIIIIIIIII', index_noms.get(nom, 0), type_s, drapeaux, adresse,
            decalage, taille, lien, info, alignement, entsize)
    chemin = Path(dossier) / 'synthese-mips.elf'
    chemin.write_bytes(bytes(fichier))
    attendu = {'classe': '32 bits', 'boutisme': 'big-endian', 'machine': 'MIPS',
               'type': 'EXEC', 'entree': 0x00400100,
               'shnum': shnum, 'phnum': phnum,
               'bibliotheques': ['libm.so.6'],
               'symboles': ['main', 'calcul'],
               'fonctions_importees': ['malloc'],
               'chaine': rodata.rstrip(b'\x00').decode(),
               'drapeaux': 0x20000001, 'taille': len(fichier)}
    return chemin, attendu


def _controles_elf32be(chercher, dossier):
    """Vérifie le chemin ELF32 big-endian, et le croise avec readelf s'il est là.

    C'est le seul endroit du projet où un format qu'aucun compilateur de cette
    machine ne produit est testé : la validation indépendante vient de readelf,
    qui lit le même fichier avec une implémentation différente.
    """
    problemes = []
    compte = [0]

    def constater(condition, message):
        compte[0] += 1
        if not condition:
            problemes.append(message)

    chemin, attendu = _synthese_elf32be(dossier)
    with Lecteur(chemin) as lecteur:
        elf = lire_elf(lecteur)
    if 'erreur' in elf:
        problemes.append('l’ELF32 big-endian doit se lire (%s)' % elf['erreur'])
        COMPTEUR['verifs'] += compte[0]
        return problemes
    constater(elf.get('classe') == attendu['classe'],
              'la classe est %r, attendu %r'
              % (elf.get('classe'), attendu['classe']))
    constater(elf.get('boutisme') == attendu['boutisme'],
              'le boutisme est %r, attendu %r'
              % (elf.get('boutisme'), attendu['boutisme']))
    constater(elf.get('machine') == attendu['machine'],
              'la machine est %r, attendu %r'
              % (elf.get('machine'), attendu['machine']))
    constater(elf.get('type', '').startswith(attendu['type']),
              'le type est %r, attendu %r' % (elf.get('type'), attendu['type']))
    constater(elf.get('entree') == attendu['entree'],
              'le point d’entrée est %r, attendu 0x%x'
              % (elf.get('entree_hex'), attendu['entree']))
    constater(elf.get('drapeaux') == attendu['drapeaux'],
              'e_flags est %r, attendu 0x%x'
              % (elf.get('drapeaux'), attendu['drapeaux']))
    constater(elf.get('abi_nom') == 'System V',
              'l’OS/ABI 0 doit être lu comme System V (%r)' % elf.get('abi_nom'))
    constater(len(elf['sections']) == attendu['shnum'],
              '%d sections lues, attendu %d'
              % (len(elf['sections']), attendu['shnum']))
    constater(len(elf['segments']) == attendu['phnum'],
              '%d segments lus, attendu %d'
              % (len(elf['segments']), attendu['phnum']))
    noms = [s['nom'] for s in elf['sections']]
    for attendu_nom in ('.text', '.rodata', '.dynstr', '.dynsym', '.dynamic',
                        '.strtab', '.symtab', '.shstrtab'):
        constater(attendu_nom in noms,
                  'la section %s manque en big-endian (%r)' % (attendu_nom, noms))
    texte = chercher(elf['sections'], 'nom', '.text', 'la section .text')
    constater(texte.get('adresse') == 0x00400100
              and texte.get('taille') == 12
              and 'EXECINSTR' in str(texte.get('drapeaux')),
              'la section .text est mal lue en ELF32 big-endian (%r)' % texte)
    # En ELF32, p_flags est en SEPTIÈME position ; en ELF64 il est en deuxième.
    # Le lire à la mauvaise place rendrait le décalage du segment comme drapeaux.
    constater([s['type'] for s in elf['segments']] == ['LOAD', 'DYNAMIC'],
              'les segments ELF32 sont faux (%r)'
              % [s['type'] for s in elf['segments']])
    charge = chercher(elf['segments'], 'type', 'LOAD', 'le segment LOAD')
    constater(charge.get('drapeaux') == 'R-E',
              'en ELF32 p_flags est en septième position : les drapeaux du LOAD '
              'sont %r au lieu de R-E' % charge.get('drapeaux'))
    dynamique = chercher(elf['segments'], 'type', 'DYNAMIC',
                         'le segment DYNAMIC')
    constater(dynamique.get('drapeaux') == 'RW-',
              'les drapeaux du DYNAMIC sont %r au lieu de RW-'
              % dynamique.get('drapeaux'))
    # Les symboles ELF32 placent st_value et st_size AVANT st_info.
    symboles = {s['nom'] for s in elf.get('symboles', ())}
    for nom in attendu['symboles']:
        constater(nom in symboles,
                  'le symbole %s manque en ELF32 big-endian (%r)'
                  % (nom, sorted(symboles)))
    main = chercher(elf.get('symboles', ()), 'nom', 'main', 'le symbole main')
    constater(main.get('valeur') == 0x00400100,
              'st_value de main est %r au lieu de 0x400100 : en ELF32, st_value '
              'et st_size viennent AVANT st_info' % main.get('valeur_hex'))
    constater(main.get('taille') == 12,
              'st_size de main est %r au lieu de 12' % main.get('taille'))
    constater(main.get('type') == 'FUNC' and main.get('liaison') == 'GLOBAL',
              'st_info de main est mal décodé (%r / %r)'
              % (main.get('type'), main.get('liaison')))
    constater(main.get('section') == '.text',
              'st_shndx de main ne désigne pas .text (%r)' % main.get('section'))
    malloc = chercher(elf.get('symboles_dynamiques', ()), 'nom', 'malloc',
                      'le symbole dynamique malloc')
    constater(malloc.get('importe') is True,
              'malloc UNDEF doit être importé en ELF32 (%r)' % malloc)
    constater(malloc.get('section') == 'UNDEF (importé)',
              'la section d’un symbole UNDEF est %r' % malloc.get('section'))
    constater(elf.get('imports') == attendu['bibliotheques'],
              'les NEEDED big-endian sont faux (%r)' % elf.get('imports'))
    constater(elf.get('imports_fonctions') == attendu['fonctions_importees'],
              'les fonctions importées sont fausses (%r)'
              % elf.get('imports_fonctions'))
    constater(elf.get('depouille') is False,
              'un ELF32 avec .symtab ne doit pas être dit dépouillé')
    extrait = chaines(chemin, minimum=8)
    attribuer_chaines(elf, extrait['chaines'])
    controle = chercher(extrait['chaines'], 'texte', attendu['chaine'],
                        'la chaîne de contrôle')
    constater(bool(controle),
              'la chaîne big-endian n’est pas retrouvée (%r)'
              % [c['texte'] for c in extrait['chaines']][:6])
    constater(controle.get('section') == '.rodata',
              'la chaîne n’est pas attribuée à .rodata (%r)'
              % controle.get('section'))
    entropies = entropie_par_section(chemin, elf)
    constater(len(entropies) == len(elf['sections']) - 1,
              'toute section présente dans le fichier doit avoir une entropie '
              '(%d sur %d)' % (len(entropies), len(elf['sections']) - 1))
    rapport = analyser(chemin, longueur_chaines=1 << 16)
    constater(rapport['ok'] and rapport['famille']['famille'] == 'elf',
              'analyser() ne reconnaît pas l’ELF32 big-endian')
    constater(not rapport['erreurs'],
              'l’ELF32 big-endian ne doit produire aucune erreur (%r)'
              % rapport['erreurs'])
    constater(any('MIPS' in n for n in rapport['resume']),
              'le résumé doit nommer l’architecture MIPS (%r)' % rapport['resume'])
    brut = chemin.read_bytes()
    for diviseur in (2, 5, 20):
        tronque = Path(dossier) / ('tronque-be-%d.elf' % diviseur)
        tronque.write_bytes(brut[:len(brut) // diviseur])
        try:
            resultat = analyser(tronque, avec_chaines=False)
            constater(resultat['ok'],
                      'un ELF32 big-endian tronqué au 1/%d doit rester '
                      'analysable' % diviseur)
        except Exception as exc:
            problemes.append('un ELF32 big-endian tronqué au 1/%d fait lever %s'
                             % (diviseur, type(exc).__name__))
    # --- croisement avec readelf : seule validation indépendante possible
    # --- d'un format qu'aucun compilateur de cette machine ne produit -------
    if shutil.which('readelf'):
        COMPTEUR['croisements'] += 1
        reference = readelf(chemin, ('-h', '-W'))
        constater(reference['ok'], 'readelf refuse l’ELF32 big-endian '
                                   'synthétique (%r)' % reference.get('erreur'))
        entete = reference['sortie']
        for attendu_texte in ('ELF32', 'big endian', 'MIPS R3000'):
            constater(attendu_texte in entete,
                      'readelf n’annonce pas %s (%r)'
                      % (attendu_texte, entete[:240]))
        compte_sections = re.search(r'Number of section headers:\s+(\d+)', entete)
        constater(bool(compte_sections)
                  and int(compte_sections.group(1)) == attendu['shnum'],
                  'readelf compte %s sections, Pascal Studio %d'
                  % (compte_sections.group(1) if compte_sections else '?',
                     attendu['shnum']))
        compte_segments = re.search(r'Number of program headers:\s+(\d+)', entete)
        constater(bool(compte_segments)
                  and int(compte_segments.group(1)) == attendu['phnum'],
                  'readelf compte %s segments, Pascal Studio %d'
                  % (compte_segments.group(1) if compte_segments else '?',
                     attendu['phnum']))
        entree = re.search(r'Entry point address:\s+(0x[0-9a-f]+)', entete)
        constater(bool(entree) and int(entree.group(1), 16) == attendu['entree'],
                  'readelf annonce un point d’entrée %s, Pascal Studio 0x%x'
                  % (entree.group(1) if entree else '?', attendu['entree']))
        sections = readelf(chemin, ('-S', '-W'))
        for nom in ('.text', '.rodata', '.dynstr', '.dynsym', '.symtab'):
            constater(nom in sections['sortie'],
                      'readelf ne voit pas la section %s' % nom)
        dynamisme = readelf(chemin, ('-d',))
        constater('libm.so.6' in dynamisme['sortie'],
                  'readelf ne voit pas NEEDED libm.so.6')
        segments = readelf(chemin, ('-l', '-W'))
        constater('R E' in segments['sortie'],
                  'readelf ne voit pas un segment R E (%r)'
                  % segments['sortie'][:300])
        constater('0x00400100' in segments['sortie']
                  or '0x400100' in segments['sortie'],
                  'readelf ne voit pas l’adresse virtuelle 0x400100')
        symboles_nm_resultat = symboles_nm(chemin, demangler=False)
        if symboles_nm_resultat['ok']:
            constater(any(s['nom'] == 'main'
                          for s in symboles_nm_resultat['symboles']),
                      'nm ne retrouve pas main dans l’ELF32 big-endian (%r)'
                      % [s['nom'] for s in symboles_nm_resultat['symboles']][:8])
    COMPTEUR['verifs'] += compte[0]
    return problemes


def _synthese_pe64(dossier):
    """Construit un PE32+ (x64) complet : imports, exports, trois sections.

    La table d'imports et la table d'exports sont écrites en RVA, comme dans un
    vrai fichier, puis converties en décalages par le parseur. C'est justement
    cette conversion qui est testée : si elle est fausse, les noms de DLL et de
    fonctions rendus sont des chaînes prises au mauvais endroit — plausibles, et
    fausses.
    """
    alignement_fichier = 0x200
    debut_texte = 0x400
    debut_rdata = debut_texte + 0x200
    debut_data = debut_rdata + 0x200
    rva_texte, rva_rdata, rva_data = 0x1000, 0x2000, 0x3000
    base_image = 0x140000000

    code = b'\x48\x83\xec\x28\xe8\x00\x00\x00\x00\x48\x83\xc4\x28\xc3'
    code += b'\x90' * (0x200 - len(code))
    donnees = b'Message secret du binaire de test\x00'
    donnees += b'\x00' * (0x200 - len(donnees))

    # Disposition interne de .rdata (RVA = rva_rdata + décalage interne)
    NOM_DLL, HINT_1, HINT_2 = 0x00, 0x10, 0x20
    IAT, DESCRIPTEURS, EXPORTS = 0x40, 0x60, 0x90
    FONCTIONS_EXPORTEES, NOMS_EXPORTES, ORDINAUX = 0xb8, 0xbc, 0xc0
    NOM_EXPORT_DLL, NOM_EXPORT_FONCTION = 0xc4, 0xd0
    rdata = bytearray(0x200)
    rdata[NOM_DLL:NOM_DLL + 13] = b'KERNEL32.dll\x00'
    rdata[HINT_1:HINT_1 + 2] = struct.pack('<H', 1)
    rdata[HINT_1 + 2:HINT_1 + 14] = b'ExitProcess\x00'
    rdata[HINT_2:HINT_2 + 2] = struct.pack('<H', 2)
    rdata[HINT_2 + 2:HINT_2 + 15] = b'GetLastError\x00'
    rdata[IAT:IAT + 8] = struct.pack('<Q', rva_rdata + HINT_1)
    rdata[IAT + 8:IAT + 16] = struct.pack('<Q', rva_rdata + HINT_2)
    rdata[IAT + 16:IAT + 24] = struct.pack('<Q', 0)
    rdata[DESCRIPTEURS:DESCRIPTEURS + 20] = struct.pack(
        '<IIIII', rva_rdata + IAT, 0x5f3a1b2c, 0, rva_rdata + NOM_DLL,
        rva_rdata + IAT)
    rdata[DESCRIPTEURS + 20:DESCRIPTEURS + 40] = b'\x00' * 20
    rdata[EXPORTS:EXPORTS + 40] = struct.pack(
        '<IIHHIIIIIII', 0, 0x5f3a1b2c, 1, 0, rva_rdata + NOM_EXPORT_DLL, 1, 1, 1,
        rva_rdata + FONCTIONS_EXPORTEES, rva_rdata + NOMS_EXPORTES,
        rva_rdata + ORDINAUX)
    rdata[FONCTIONS_EXPORTEES:FONCTIONS_EXPORTEES + 4] = struct.pack('<I',
                                                                    rva_texte)
    rdata[NOMS_EXPORTES:NOMS_EXPORTES + 4] = struct.pack(
        '<I', rva_rdata + NOM_EXPORT_FONCTION)
    rdata[ORDINAUX:ORDINAUX + 2] = struct.pack('<H', 0)
    rdata[NOM_EXPORT_DLL:NOM_EXPORT_DLL + 12] = b'exemple.dll\x00'
    rdata[NOM_EXPORT_FONCTION:NOM_EXPORT_FONCTION + 11] = b'MaFonction\x00'
    rdata = bytes(rdata)

    nombre_sections = 3
    taille_optionnel = 240
    taille_en_tetes = debut_texte
    taille_image = rva_data + 0x1000

    en_tete = bytearray(taille_en_tetes)
    en_tete[0:2] = b'MZ'
    en_tete[0x3c:0x40] = struct.pack('<I', 0x80)
    en_tete[0x80:0x84] = b'PE\x00\x00'
    en_tete[0x84:0x98] = struct.pack('<HHIIIHH', 0x8664, nombre_sections,
                                     0x5f3a1b2c, 0, 0, taille_optionnel,
                                     0x22)      # EXECUTABLE_IMAGE | LARGE_ADDRESS
    optionnel = 0x98
    en_tete[optionnel:optionnel + 2] = struct.pack('<H', 0x20b)   # PE32+
    en_tete[optionnel + 2:optionnel + 4] = bytes((14, 0))         # lieur 14.0
    en_tete[optionnel + 4:optionnel + 24] = struct.pack(
        '<IIIII', len(code), len(rdata), 0, rva_texte, rva_texte)
    en_tete[optionnel + 24:optionnel + 32] = struct.pack('<Q', base_image)
    en_tete[optionnel + 32:optionnel + 40] = struct.pack(
        '<II', 0x1000, alignement_fichier)
    en_tete[optionnel + 40:optionnel + 52] = struct.pack('<HHHHHH', 6, 0, 1, 0,
                                                         6, 0)
    en_tete[optionnel + 52:optionnel + 68] = struct.pack('<IIII', 0, taille_image,
                                                         taille_en_tetes, 0)
    en_tete[optionnel + 68:optionnel + 72] = struct.pack('<HH', 3, 0x4160)
    en_tete[optionnel + 72:optionnel + 104] = struct.pack(
        '<QQQQ', 0x100000, 0x1000, 0x100000, 0x1000)
    en_tete[optionnel + 104:optionnel + 112] = struct.pack('<II', 0, 16)
    repertoires = optionnel + 112
    en_tete[repertoires:repertoires + 8] = struct.pack('<II', rva_rdata + EXPORTS,
                                                       40)
    en_tete[repertoires + 8:repertoires + 16] = struct.pack(
        '<II', rva_rdata + DESCRIPTEURS, 40)
    debut_sections = optionnel + taille_optionnel
    entrees = (
        (b'.text\x00\x00\x00', len(code), rva_texte, len(code), debut_texte,
         0x60000020),
        (b'.rdata\x00\x00', len(rdata), rva_rdata, len(rdata), debut_rdata,
         0x40000040),
        (b'.data\x00\x00\x00', len(donnees), rva_data, len(donnees), debut_data,
         0xc0000040),
    )
    for index, (nom, taille_virtuelle, rva, taille_brute, pointeur,
                caracteristiques) in enumerate(entrees):
        base = debut_sections + index * 40
        en_tete[base:base + 8] = nom
        en_tete[base + 8:base + 40] = struct.pack(
            '<IIIIIIHHI', taille_virtuelle, rva, taille_brute, pointeur, 0, 0,
            0, 0, caracteristiques)

    fichier = bytearray(en_tete)
    fichier[debut_texte:debut_texte + len(code)] = code
    fichier[debut_rdata:debut_rdata + len(rdata)] = rdata
    fichier[debut_data:debut_data + len(donnees)] = donnees
    chemin = Path(dossier) / 'synthese.exe'
    chemin.write_bytes(bytes(fichier))
    attendu = {
        'code': code, 'donnees': donnees, 'rdata': rdata,
        'base_image': base_image, 'entree': rva_texte,
        'nombre_sections': nombre_sections,
        'dll': ['KERNEL32.dll'],
        'fonctions': ['ExitProcess', 'GetLastError'],
        'exports': ['MaFonction'],
        'chaine': 'Message secret du binaire de test',
        'horodatage': 0x5f3a1b2c,
        'mitigations': ('DYNAMIC_BASE', 'NX_COMPAT', 'GUARD_CF'),
    }
    return chemin, attendu


def _synthese_macho64(dossier):
    """Construit un Mach-O 64 bits little-endian : deux segments, symboles, dylib.

    Les binaires macOS ne peuvent pas être produits sur Linux, donc aucun banc ne
    pourra jamais en compiler un : la synthèse est ici la seule couverture
    possible, et elle doit être complète (LC_SEGMENT_64 avec sections, LC_SYMTAB,
    LC_LOAD_DYLIB, LC_UUID, LC_MAIN).
    """
    def champ16(texte):
        brut = texte.encode()[:16]
        return brut + b'\x00' * (16 - len(brut))

    texte = b'\x55\x48\x89\xe5\x31\xc0\x5d\xc3' + b'\x90' * 8
    cstring = (b'/usr/lib/libSystem.B.dylib\x00'
               b'chemin/vers/une/ressource\x00'
               b'MARQUEUR_MACHO\x00')
    donnees = b'\x01\x02\x03\x04' * 4
    symboles = b''
    symboles += struct.pack('<IBBHQ', 1, 0xe | 0x1, 1, 0, 0x100000f00)   # _main
    symboles += struct.pack('<IBBHQ', 7, 0x1, 0, 1, 0)                   # _puts
    chaines = b'\x00_main\x00_puts\x00'
    chemin_dylib = b'/usr/lib/libSystem.B.dylib\x00'
    taille_dylib = 24 + ((len(chemin_dylib) + 7) & ~7)

    taille_en_tete = 32
    commandes = (
        (0x19, 72 + 2 * 80),        # LC_SEGMENT_64 __TEXT, 2 sections
        (0x19, 72 + 80),            # LC_SEGMENT_64 __DATA, 1 section
        (0x2, 24),                  # LC_SYMTAB
        (0xc, taille_dylib),        # LC_LOAD_DYLIB
        (0x1b, 24),                 # LC_UUID
        (0x80000028, 24),           # LC_MAIN
    )
    ncmds = len(commandes)
    sizeofcmds = sum(t for _, t in commandes)

    offset_texte, offset_cstring = 0xf00, 0x1000
    offset_donnees = 0x2000
    offset_symboles = 0x2100
    offset_chaines = offset_symboles + len(symboles)
    taille_fichier = offset_chaines + len(chaines)

    fichier = bytearray(taille_fichier)
    fichier[0:32] = struct.pack(
        '<IIIIIIII', 0xfeedfacf, 0x01000007, 3, 2, ncmds, sizeofcmds,
        0x1 | 0x4 | 0x80 | 0x200000, 0)
    position = taille_en_tete
    # __TEXT
    fichier[position:position + 72] = struct.pack(
        '<II', 0x19, 72 + 2 * 80) + champ16('__TEXT') + struct.pack(
            '<QQQQIIII', 0x100000000, 0x2000, 0, offset_cstring + len(cstring),
            7, 5, 2, 0)
    fichier[position + 72:position + 152] = (
        champ16('__text') + champ16('__TEXT')
        + struct.pack('<QQIIIIIIII', 0x100000f00, len(texte), offset_texte, 4,
                      0, 0, 0x80000400, 0, 0, 0))
    fichier[position + 152:position + 232] = (
        champ16('__cstring') + champ16('__TEXT')
        + struct.pack('<QQIIIIIIII', 0x100001000, len(cstring), offset_cstring,
                      0, 0, 0, 0x2, 0, 0, 0))
    position += 72 + 2 * 80
    # __DATA
    fichier[position:position + 72] = struct.pack(
        '<II', 0x19, 72 + 80) + champ16('__DATA') + struct.pack(
            '<QQQQIIII', 0x100002000, 0x1000, offset_donnees, len(donnees),
            3, 3, 1, 0)
    fichier[position + 72:position + 152] = (
        champ16('__data') + champ16('__DATA')
        + struct.pack('<QQIIIIIIII', 0x100002000, len(donnees), offset_donnees,
                      3, 0, 0, 0x0, 0, 0, 0))
    position += 72 + 80
    # LC_SYMTAB
    fichier[position:position + 24] = struct.pack(
        '<IIIIII', 0x2, 24, offset_symboles, 2, offset_chaines, len(chaines))
    position += 24
    # LC_LOAD_DYLIB
    fichier[position:position + 24] = struct.pack('<IIIII', 0xc, taille_dylib, 24,
                                                  2, 0x00010000)
    fichier[position + 24:position + 24 + len(chemin_dylib)] = chemin_dylib
    position += taille_dylib
    # LC_UUID
    fichier[position:position + 8] = struct.pack('<II', 0x1b, 24)
    fichier[position + 8:position + 24] = bytes(range(16))
    position += 24
    # LC_MAIN : entryoff est un DÉCALAGE FICHIER, pas une adresse virtuelle
    fichier[position:position + 24] = struct.pack('<IIQQ', 0x80000028, 24,
                                                  offset_texte, 0)
    fichier[offset_texte:offset_texte + len(texte)] = texte
    fichier[offset_cstring:offset_cstring + len(cstring)] = cstring
    fichier[offset_donnees:offset_donnees + len(donnees)] = donnees
    fichier[offset_symboles:offset_symboles + len(symboles)] = symboles
    fichier[offset_chaines:offset_chaines + len(chaines)] = chaines
    chemin = Path(dossier) / 'synthese.macho'
    chemin.write_bytes(bytes(fichier))
    attendu = {'texte': texte, 'cstring': cstring, 'donnees': donnees,
               'symboles': ['_main', '_puts'],
               'dylib': '/usr/lib/libSystem.B.dylib',
               'entree': offset_texte, 'ncmds': ncmds}
    return chemin, attendu


COMPTEUR = {'verifs': 0, 'croisements': 0}


def verifier():
    """Autocontrôle : binaires synthétiques d'abord, croisement avec binutils ensuite.

    Deux niveaux, parce qu'un seul ne suffit pas.

    Les synthèses vérifient le parseur sur des champs connus et fonctionnent sur
    une machine sans compilateur. Mais un parseur testé uniquement sur ses
    propres synthèses peut être cohérent avec lui-même et faux sur un vrai
    binaire : c'est exactement ce qui arrive quand on se trompe d'un décalage
    dans un en-tête. D'où le second niveau — si gcc, readelf, nm et objdump sont
    présents, un VRAI exécutable est compilé et chaque réponse de Pascal Studio
    est comparée à celle de binutils. Les deux doivent dire la même chose, sinon
    l'un des deux ment et le banc le dit.
    """
    import shutil
    import tempfile

    problemes = []
    COMPTEUR['verifs'] = 0
    COMPTEUR['croisements'] = 0

    def chercher(collection, cle, valeur, quoi):
        """Trouve un élément sans jamais lever.

        Un `next(...)` nu sur un élément manquant lève StopIteration et interrompt
        le banc : tous les contrôles qui suivent ne sont pas exécutés, et le seul
        message est une trace de pile qui ne dit pas ce qui manque. Un élément
        manquant doit être un ÉCHEC NOMMÉ, et le banc doit continuer.
        """
        for element in collection:
            if element.get(cle) == valeur:
                return element
        problemes.append('%s introuvable (%s = %r) ; présents : %r'
                         % (quoi, cle, valeur,
                            [e.get(cle) for e in collection][:14]))
        return {}

    def verif(condition, message):
        # Compter les contrôles n'est pas décoratif : un banc qui saute
        # silencieusement sa partie la plus importante (ici le croisement avec
        # binutils, conditionné à la présence de gcc) rend « OK » sans avoir rien
        # vérifié. Le compte est donc rendu, comme unittest rend « Ran 733 tests ».
        COMPTEUR['verifs'] += 1
        if not condition:
            problemes.append(message)

    dossier = tempfile.mkdtemp(prefix='ps-retro-bin-')
    try:
        # ================= entropie, empreintes, formats ====================
        verif(entropie(b'\x00' * 4096) == 0.0,
              'l’entropie d’octets constants doit être 0')
        verif(entropie(b'ab') == 1.0, 'deux symboles équiprobables valent 1 bit')
        verif(entropie(b'abcd') == 2.0, 'quatre symboles équiprobables valent 2 bits')
        pseudo_aleatoire = bytes((i * 37 + 11) % 251 for i in range(2048))
        verif(entropie(pseudo_aleatoire) > 7.5,
              'l’entropie d’un motif pseudo-aléatoire doit approcher 8 (%.2f)'
              % entropie(pseudo_aleatoire))
        verif(entropie(b'') == 0.0, 'l’entropie du vide doit être 0, pas une levée')
        verif(entropie(bytes(range(256))) == 8.0,
              'les 256 valeurs équiprobables doivent donner exactement 8')
        empreinte = empreintes(b'abc')
        verif(empreinte['sha256'] == 'ba7816bf8f01cfea414140de5dae2223b00361a3'
                                     '96177a9cb410ff61f20015ad',
              'SHA-256 de « abc » faux : %s' % empreinte['sha256'])
        verif(empreinte['md5'] == '900150983cd24fb0d6963f7d28e17f72',
              'MD5 de « abc » faux : %s' % empreinte['md5'])
        verif(empreinte['sha1'] == 'a9993e364706816aba3e25717850c26c9cd0d89d',
              'SHA-1 de « abc » faux : %s' % empreinte['sha1'])
        verif('avertissement' not in empreinte,
              'un fichier entier ne doit pas être annoncé comme échantillon')
        verif('avertissement' in empreintes(b'abcdef', echantillon=3),
              'un échantillon doit être signalé comme tel')
        verif(_taille_texte(1536) == '1.5 Ko', 'formatage de taille faux : %s'
              % _taille_texte(1536))
        verif(_taille_texte(0) == '0 o', 'formatage de zéro faux')

        # ================= familles et ambiguïté ============================
        verif(famille(b'\x7fELF\x02\x01\x01\x00' + b'\x00' * 8)['famille'] == 'elf',
              'un ELF n’est pas reconnu')
        verif(famille(b'MZ' + b'\x00' * 62 + b'\x80\x00\x00\x00')['famille'] == 'pe',
              'un PE n’est pas reconnu')
        verif(famille(b'\xcf\xfa\xed\xfe' + b'\x00' * 8)['famille'] == 'macho',
              'un Mach-O 64 bits n’est pas reconnu')
        java = b'\xca\xfe\xba\xbe' + struct.pack('>HH', 0, 52)
        verif(famille(java)['famille'] == 'class-java',
              'un .class Java doit être distingué d’un binaire gras (%r)'
              % famille(java)['famille'])
        gras = b'\xca\xfe\xba\xbe' + struct.pack('>I', 2)
        verif(famille(gras)['famille'] == 'macho',
              'un binaire gras doit être reconnu comme Mach-O')
        ambigu = famille(b'\xca\xfe\xba\xbe\xff\xff\xff\xff')
        verif(ambigu['famille'] == 'ambigue' and ambigu['ambiguite'],
              '0xCAFEBABE indécidable doit être rendu AMBIGU, pas tranché au '
              'hasard (%r)' % ambigu['famille'])
        verif('deux lectures' in ambigu['raison'],
              'une ambiguïté doit expliquer les deux lectures possibles (%r)'
              % ambigu['raison'])
        verif(famille(b'')['raison'], 'un fichier vide doit être expliqué')
        verif(famille(b'\x00asm\x01\x00\x00\x00')['famille'] == 'wasm',
              'un module WASM n’est pas reconnu')
        verif(famille(b'SQLite format 3\x00')['famille'] == 'sqlite',
              'une base SQLite n’est pas reconnue')
        verif(famille(b'\x1f\x8b\x08\x00' + b'\x00' * 12)['famille'] == 'gzip',
              'un gzip doit être reconnu (%r)'
              % famille(b'\x1f\x8b\x08\x00')['famille'])
        verif(famille(b'PK\x03\x04' + b'\x00' * 12)['famille'] == 'zip',
              'un zip doit être reconnu')
        verif(famille(b'!<arch>\n' + b'\x00' * 12)['famille'] == 'archive-ar',
              'une archive ar doit être reconnue')
        inconnu = famille(b'\x01\x02\x03\x04', 'programme.txt')
        verif(inconnu['famille'] == 'inconnue' and inconnu['ambiguite']
              and 'pas une preuve' in inconnu['raison'],
              'une extension ne doit pas être prise pour une signature (%r)'
              % inconnu)

        # ================= ELF synthétique ==================================
        chemin_elf, attendu_elf = _synthese_elf64(dossier)
        verif(chemin_elf.stat().st_size == attendu_elf['taille'],
              'la taille du fichier synthétique ne correspond pas au plan')
        with Lecteur(chemin_elf) as lecteur:
            elf = lire_elf(lecteur)
        verif('erreur' not in elf, 'l’ELF synthétique doit se lire sans erreur (%s)'
              % elf.get('erreur'))
        verif(elf.get('classe') == '64 bits', 'la classe ELF est fausse : %r'
              % elf.get('classe'))
        verif(elf.get('boutisme') == 'little-endian', 'le boutisme ELF est faux')
        verif(elf.get('machine') == 'x86-64', 'la machine ELF est fausse : %r'
              % elf.get('machine'))
        verif(elf.get('abi_nom') == 'Linux', 'l’OS/ABI est faux : %r'
              % elf.get('abi_nom'))
        verif(elf.get('type_brut') == 3 and elf.get('pie') is True,
              'un ET_DYN doit être signalé comme PIE (%r)' % elf.get('type'))
        verif(elf.get('entree') == attendu_elf['entree'],
              'le point d’entrée ELF est faux (%r)' % elf.get('entree_hex'))
        verif(elf['shnum'] == attendu_elf['shnum']
              and len(elf['sections']) == attendu_elf['shnum'],
              'shnum (%d) ne correspond pas aux sections lues (%d)'
              % (elf['shnum'], len(elf['sections'])))
        verif(elf['phnum'] == attendu_elf['phnum']
              and len(elf['segments']) == attendu_elf['phnum'],
              'phnum (%d) ne correspond pas aux segments lus (%d)'
              % (elf['phnum'], len(elf['segments'])))
        noms_sections = [s['nom'] for s in elf['sections']]
        for attendu in ('.text', '.rodata', '.comment', '.note.gnu.build-id',
                        '.interp', '.dynstr', '.dynsym', '.dynamic', '.strtab',
                        '.symtab', '.shstrtab'):
            verif(attendu in noms_sections,
                  'la section %s manque (%r)' % (attendu, noms_sections))
        texte = chercher(elf['sections'], 'nom', '.text', 'la section .text')
        verif(texte.get('taille') == len(attendu_elf['texte'])
              and 'EXECINSTR' in str(texte.get('drapeaux'))
              and 'ALLOC' in str(texte.get('drapeaux')),
              'la section .text est mal lue (%r)' % texte)
        dynsym = chercher(elf['sections'], 'nom', '.dynsym', 'la section .dynsym')
        verif(dynsym.get('entsize') == 24
              and dynsym.get('lien') == noms_sections.index('.dynstr'),
              'sh_link de .dynsym ne pointe pas vers .dynstr (%r)' % dynsym)
        verif(elf.get('interprete') == attendu_elf['interprete'],
              'l’interpréteur est mal lu (%r attendu %r)'
              % (elf.get('interprete'), attendu_elf['interprete']))
        verif(elf.get('imports') == attendu_elf['bibliotheques'],
              'les bibliothèques requises sont fausses (%r)' % elf.get('imports'))
        verif(elf.get('soname') == '',
              'un exécutable sans DT_SONAME doit rendre une chaîne vide (%r)'
              % elf.get('soname'))
        verif(elf.get('commentaire') == attendu_elf['compilateur'],
              'le compilateur n’est pas lu depuis .comment (%r)'
              % elf.get('commentaire'))
        symboles = {s['nom']: s for s in elf.get('symboles', ())}
        for nom in attendu_elf['symboles']:
            verif(nom in symboles, 'le symbole %s manque dans .symtab (%r)'
                  % (nom, sorted(symboles)))
        main = chercher(elf.get('symboles', ()), 'nom', 'main',
                        'le symbole main')
        verif(main.get('type') == 'FUNC' and main.get('liaison') == 'GLOBAL'
              and main.get('valeur') == 0x1000 and main.get('taille') == 12
              and main.get('section') == '.text',
              'le symbole main est mal lu (%r)' % main)
        fichier_symbole = chercher(elf.get('symboles', ()), 'nom', 'reference.c',
                                   'le symbole FILE')
        verif(fichier_symbole.get('type') == 'FILE'
              and fichier_symbole.get('liaison') == 'LOCAL'
              and fichier_symbole.get('section') == 'ABS',
              'un symbole FILE/ABS est mal lu (%r)' % fichier_symbole)
        puts = chercher(elf.get('symboles_dynamiques', ()), 'nom', 'puts',
                        'le symbole dynamique puts')
        verif(puts.get('importe') and puts.get('section') == 'UNDEF (importé)',
              'un symbole UNDEF doit être marqué importé (%r)' % puts)
        secret = chercher(elf.get('symboles_dynamiques', ()), 'nom',
                          'message_secret', 'le symbole dynamique exporté')
        verif(secret.get('exporte') and secret.get('valeur') == 0x2000,
              'un symbole défini GLOBAL doit être marqué exporté (%r)' % secret)
        verif(elf.get('imports_fonctions') == attendu_elf['fonctions_importees'],
              'les fonctions importées sont fausses (%r)'
              % elf.get('imports_fonctions'))
        verif(elf.get('exports') == attendu_elf['symboles_exportes'],
              'les exports sont faux (%r)' % elf.get('exports'))
        verif(elf.get('depouille') is False,
              'un binaire avec .symtab ne doit pas être dit dépouillé')
        verif(not elf.get('avertissements_symboles'),
              'la table de symboles synthétique ne doit produire aucun '
              'avertissement (%r)' % elf.get('avertissements_symboles'))
        build = next((n.get('build_id') for n in elf.get('notes', ())
                      if n.get('build_id')), '')
        verif(build == attendu_elf['build_id'],
              'le build-id est mal lu (%r attendu %r)'
              % (build, attendu_elf['build_id']))
        types_segments = [s['type'] for s in elf.get('segments', ())]
        for attendu in ('PHDR', 'INTERP', 'LOAD', 'NOTE', 'DYNAMIC',
                        'GNU_STACK'):
            verif(attendu in types_segments, 'le segment %s manque (%r)'
                  % (attendu, types_segments))
        verif(any(s['drapeaux'] == 'R-E' for s in elf['segments']),
              'aucun segment R-E trouvé (%r)'
              % [s['drapeaux'] for s in elf['segments']])
        pile = chercher(elf['segments'], 'type', 'GNU_STACK',
                        'le segment GNU_STACK')
        verif(pile.get('drapeaux') == 'RW-',
              'un GNU_STACK non exécutable doit être rendu RW- (%r)'
              % pile.get('drapeaux'))
        etiquettes = {e['nom'] for e in elf.get('dynamique', ())}
        for attendu in ('NEEDED', 'STRTAB', 'STRSZ', 'SYMTAB', 'SYMENT'):
            verif(attendu in etiquettes, 'l’étiquette dynamique %s manque (%r)'
                  % (attendu, sorted(etiquettes)))
        verif(any(e['nom'] == 'NEEDED' and e.get('texte') == 'libc.so.6'
                  for e in elf['dynamique']),
              'NEEDED n’est pas résolu en nom de bibliothèque')
        verif(elf.get('resume'), 'le résumé ELF est vide')
        verif(any('x86-64' in n for n in elf['resume']),
              'le résumé doit nommer l’architecture (%r)' % elf['resume'])
        verif(any('Compilateur' in n for n in elf['resume']),
              'le résumé doit nommer le compilateur (%r)' % elf['resume'])

        # Chaînes : trouvées, positionnées, attribuées à la bonne section
        extrait = chaines(chemin_elf, minimum=8)
        verif(extrait['ok'], 'la lecture des chaînes a échoué (%r)'
              % extrait.get('erreur'))
        textes = [c['texte'] for c in extrait['chaines']]
        verif(attendu_elf['chaine'] in textes,
              'la chaîne de .rodata n’est pas retrouvée (%r)' % textes[:8])
        verif(attendu_elf['interprete'] in textes,
              'l’interpréteur doit apparaître dans les chaînes')
        attribuer_chaines(elf, extrait['chaines'])
        url = chercher(extrait['chaines'], 'texte', attendu_elf['chaine'],
                       'la chaîne de .rodata')
        verif(url.get('section') == '.rodata',
              'la chaîne n’est pas attribuée à .rodata (%r)' % url.get('section'))
        interp = chercher(extrait['chaines'], 'texte', attendu_elf['interprete'],
                          'la chaîne de .interp')
        verif(interp.get('section') == '.interp',
              'l’interpréteur n’est pas attribué à .interp (%r)'
              % interp.get('section'))
        rodata = chercher(elf['sections'], 'nom', '.rodata', 'la section .rodata')
        verif(url.get('position') == rodata.get('decalage'),
              'la position de la chaîne ne correspond pas au décalage de '
              '.rodata (%r contre %r)'
              % (url.get('position'), rodata.get('decalage')))
        entropies = entropie_par_section(chemin_elf, elf)
        entropie_rodata = chercher(entropies, 'nom', '.rodata',
                                   'l’entropie de .rodata')
        verif(3.0 < (entropie_rodata.get('entropie') or 0) < 6.0,
              'l’entropie de .rodata est invraisemblable (%r)' % entropie_rodata)
        verif(all(e.get('entropie') is not None for e in entropies),
              'toute section présente dans le fichier doit avoir une entropie')
        verif(all(not e['suspecte'] for e in entropies),
              'aucune section de l’ELF synthétique ne doit paraître compressée '
              '(%r)' % [e for e in entropies if e['suspecte']])
        rapport = analyser(chemin_elf, longueur_chaines=1 << 20)
        verif(rapport['ok'] and rapport['famille']['famille'] == 'elf',
              'analyser() ne reconnaît pas son propre ELF synthétique')
        verif(rapport['structure']['format'] == 'ELF',
              'analyser() ne construit pas la structure ELF')
        verif(rapport['empreintes']['sha256']
              == empreintes_fichier(chemin_elf)['sha256'],
              'les empreintes diffèrent entre deux lectures du même fichier')
        verif(rapport['taille'] == attendu_elf['taille'],
              'la taille du rapport est fausse')
        verif(bool(rapport['resume']), 'analyser() doit rendre un résumé lisible')
        verif(not rapport['erreurs'], 'l’ELF synthétique ne doit produire aucune '
                                      'erreur (%r)' % rapport['erreurs'])
        indices_elf = rapport['indices']
        verif(not any('hors de toute section' in i['quoi'] for i in indices_elf),
              'le point d’entrée de l’ELF synthétique tombe dans .text : '
              'l’heuristique ne doit pas se déclencher (%r)'
              % [i['quoi'] for i in indices_elf])

        # Troncature : chaque coupure doit rendre un rapport, jamais lever
        brut_elf = chemin_elf.read_bytes()
        for diviseur in (2, 3, 5, 17, 60, 200):
            tronque = Path(dossier) / ('tronque-%d.elf' % diviseur)
            tronque.write_bytes(brut_elf[:len(brut_elf) // diviseur])
            try:
                resultat = analyser(tronque, avec_chaines=False)
            except Exception as exc:
                problemes.append('un ELF tronqué au 1/%d fait lever %s : %s'
                                 % (diviseur, type(exc).__name__, exc))
                continue
            verif(resultat['ok'], 'un ELF tronqué au 1/%d doit rester analysable'
                  % diviseur)
        tiers = analyser(Path(dossier) / 'tronque-3.elf', avec_chaines=False)
        verif(any('tronqué' in n or 'au-delà' in n for n in tiers['notes']),
              'une troncature doit être DITE, pas seulement tolérée (%r)'
              % tiers['notes'])

        # Un en-tête dont la classe est invalide doit être expliqué
        invalide = Path(dossier) / 'invalide.elf'
        casse = bytearray(brut_elf)
        casse[4] = 7                    # ELFCLASS inexistant
        invalide.write_bytes(bytes(casse))
        with Lecteur(invalide) as lecteur:
            lu = lire_elf(lecteur)
        verif('erreur' in lu and 'classe ELF 7' in lu['erreur'],
              'une classe ELF invalide doit être expliquée (%r)' % lu.get('erreur'))
        casse[4] = 2
        casse[5] = 9                    # boutisme inexistant
        invalide.write_bytes(bytes(casse))
        with Lecteur(invalide) as lecteur:
            lu = lire_elf(lecteur)
        verif('erreur' in lu and 'boutisme' in lu['erreur'],
              'un boutisme ELF invalide doit être expliqué (%r)' % lu.get('erreur'))
        pas_elf = Path(dossier) / 'pas-elf.bin'
        pas_elf.write_bytes(b'BONJOUR' * 40)
        with Lecteur(pas_elf) as lecteur:
            lu = lire_elf(lecteur)
        verif('erreur' in lu, 'lire_elf sur un non-ELF doit le dire')

        # ================= ELF32 big-endian =================================
        problemes.extend(_controles_elf32be(chercher, dossier))

        # ================= PE synthétique ===================================
        chemin_pe, attendu_pe = _synthese_pe64(dossier)
        with Lecteur(chemin_pe) as lecteur:
            pe = lire_pe(lecteur)
        verif('erreur' not in pe, 'le PE synthétique doit se lire (%s)'
              % pe.get('erreur'))
        verif(pe.get('machine') == 'x64 (AMD64/Intel EM64T)',
              'la machine PE est fausse : %r' % pe.get('machine'))
        verif(pe.get('largeur') == 64 and 'PE32+' in pe.get('magique', ''),
              'la largeur du PE est fausse (%r)' % pe.get('magique'))
        verif('avertissement_en_tete' not in pe,
              'un SizeOfOptionalHeader de 240 pour un PE32+ est standard : il ne '
              'doit pas être signalé (%r)' % pe.get('avertissement_en_tete'))
        verif(pe.get('base_image') == attendu_pe['base_image'],
              'la base de l’image PE est fausse : %r'
              % hex(pe.get('base_image', 0)))
        verif(pe.get('sous_systeme') == 'console Windows',
              'le sous-système PE est faux : %r' % pe.get('sous_systeme'))
        verif(pe.get('adresse_entree') == attendu_pe['entree'],
              'le point d’entrée PE est faux : %r' % pe.get('entree_hex'))
        verif(pe.get('horodatage') == attendu_pe['horodatage']
              and pe.get('horodatage_texte', '').startswith('2020-08-17'),
              'l’horodatage PE est mal lu ou mal daté (%r / %r)'
              % (pe.get('horodatage'), pe.get('horodatage_texte')))
        verif(len(pe['sections']) == attendu_pe['nombre_sections'],
              'le nombre de sections PE est faux (%d)' % len(pe['sections']))
        verif([s['nom'] for s in pe['sections']] == ['.text', '.rdata', '.data'],
              'les noms de sections PE sont faux : %r'
              % [s['nom'] for s in pe['sections']])
        section_texte = chercher(pe['sections'], 'nom', '.text',
                                 'la section .text du PE')
        verif(section_texte.get('executable')
              and section_texte.get('taille') == len(attendu_pe['code'])
              and 'CODE' in str(section_texte.get('caracteristiques')),
              'la section .text du PE est mal lue (%r)' % section_texte)
        verif(section_texte.get('ecrire_et_executer') is False,
              'une section .text normale ne doit pas être dite W+X')
        for mitigation in attendu_pe['mitigations']:
            verif(mitigation in pe.get('caracteristiques_dll', ''),
                  'la mitigation %s n’est pas lue (%r)'
                  % (mitigation, pe.get('caracteristiques_dll')))
        verif('EXECUTABLE_IMAGE' in pe.get('caracteristiques', '')
              and pe.get('est_une_dll') is False,
              'les caractéristiques COFF sont mal lues (%r)'
              % pe.get('caracteristiques'))
        verif(_rva_vers_decalage(pe['sections'], 0x2000) == 0x600,
              'la conversion RVA→décalage est fausse (%r)'
              % _rva_vers_decalage(pe['sections'], 0x2000))
        verif(_rva_vers_decalage(pe['sections'], 0x2010) == 0x610,
              'une RVA à l’intérieur d’une section est mal convertie')
        verif(_rva_vers_decalage(pe['sections'], 0x99999) is None,
              'une RVA hors de toute section doit rendre None, pas un décalage '
              'inventé')
        verif([d['dll'] for d in pe.get('imports', ())] == attendu_pe['dll'],
              'les DLL importées sont fausses (%r ; %r)'
              % ([d['dll'] for d in pe.get('imports', ())],
                 pe.get('avertissement_imports')))
        premiere_dll = chercher(pe['imports'], 'dll', attendu_pe['dll'][0],
                                'la DLL importée')
        noms_fonctions = [f['nom'] for f in premiere_dll.get('fonctions', ())]
        verif(noms_fonctions == attendu_pe['fonctions'],
              'les fonctions importées sont fausses (%r)' % noms_fonctions)
        verif(premiere_dll.get('par_ordre') == attendu_pe['fonctions'],
              'la liste par_ordre doit reprendre les noms dans l’ordre')
        verif(premiere_dll.get('horodatage') == attendu_pe['horodatage'],
              'l’horodatage du descripteur d’import est faux (%r)'
              % premiere_dll.get('horodatage'))
        verif(pe.get('exports') == attendu_pe['exports'],
              'les exports sont faux (%r ; %r)'
              % (pe.get('exports'), pe.get('avertissement_exports')))
        verif(pe.get('export_dll') == 'exemple.dll',
              'le nom de la DLL exportatrice est faux (%r)' % pe.get('export_dll'))
        verif(pe.get('manage') is False,
              'un PE sans répertoire COM ne doit pas être dit managé')
        repertoires = {r['nom']: r for r in pe.get('repertoires', ())}
        verif(len(pe['repertoires']) == 16,
              'les 16 répertoires de données doivent être lus (%d)'
              % len(pe['repertoires']))
        verif(repertoires['Import']['present'] and repertoires['Export']['present'],
              'les répertoires Import et Export doivent être présents')
        verif(not repertoires['Ressources']['present'],
              'un répertoire non renseigné doit être marqué absent')
        rapport_pe = analyser(chemin_pe, longueur_chaines=1 << 20)
        verif(rapport_pe['ok'] and rapport_pe['famille']['famille'] == 'pe',
              'analyser() ne reconnaît pas le PE synthétique')
        verif(any(attendu_pe['chaine'] in c['texte']
                  for c in rapport_pe.get('chaines', ())),
              'la chaîne du PE n’est pas retrouvée')
        verif(not any('hors de toute section' in i['quoi']
                      for i in rapport_pe['indices']),
              'l’entrée du PE tombe dans .text : l’heuristique ne doit pas se '
              'déclencher (%r)' % [i['quoi'] for i in rapport_pe['indices']])
        brut_pe = chemin_pe.read_bytes()
        for diviseur in (2, 4, 9, 40):
            tronque = Path(dossier) / ('tronque-%d.exe' % diviseur)
            tronque.write_bytes(brut_pe[:len(brut_pe) // diviseur])
            try:
                resultat = analyser(tronque, avec_chaines=False)
                verif(resultat['ok'], 'un PE tronqué au 1/%d doit rester '
                                      'analysable' % diviseur)
            except Exception as exc:
                problemes.append('un PE tronqué au 1/%d fait lever %s : %s'
                                 % (diviseur, type(exc).__name__, exc))
        casse = Path(dossier) / 'casse.exe'
        donnees_cassees = bytearray(brut_pe)
        donnees_cassees[0x3c:0x40] = struct.pack('<I', 0xffff0000)
        casse.write_bytes(bytes(donnees_cassees))
        with Lecteur(casse) as lecteur:
            pe_casse = lire_pe(lecteur)
        verif('erreur' in pe_casse and 'e_lfanew' in pe_casse['erreur'],
              'un e_lfanew hors du fichier doit être expliqué (%r)'
              % pe_casse.get('erreur'))
        donnees_cassees[0x3c:0x40] = struct.pack('<I', 0x80)
        donnees_cassees[0x80:0x84] = b'XX\x00\x00'
        casse.write_bytes(bytes(donnees_cassees))
        with Lecteur(casse) as lecteur:
            pe_casse = lire_pe(lecteur)
        verif('erreur' in pe_casse and 'signature' in pe_casse['erreur'],
              'une signature PE absente doit être expliquée (%r)'
              % pe_casse.get('erreur'))
        donnees_cassees[0x80:0x84] = b'PE\x00\x00'
        donnees_cassees[0x98:0x9a] = struct.pack('<H', 0x999)
        casse.write_bytes(bytes(donnees_cassees))
        with Lecteur(casse) as lecteur:
            pe_casse = lire_pe(lecteur)
        verif('erreur' in pe_casse and '0x999' in pe_casse['erreur'],
              'un numéro magique inconnu doit être expliqué en nommant la valeur '
              'lue (%r)' % pe_casse.get('erreur'))

        # ================= Mach-O synthétique ===============================
        chemin_macho, attendu_macho = _synthese_macho64(dossier)
        with Lecteur(chemin_macho) as lecteur:
            macho = lire_macho(lecteur)
        verif('erreur' not in macho, 'le Mach-O synthétique doit se lire (%s)'
              % macho.get('erreur'))
        verif(macho.get('largeur') == 64, 'la largeur Mach-O est fausse')
        verif(macho.get('cputype') == 'x86 64 bits',
              'l’architecture Mach-O est fausse : %r' % macho.get('cputype'))
        verif(macho.get('filetype') == 'MH_EXECUTE',
              'le type Mach-O est faux : %r' % macho.get('filetype'))
        verif(macho.get('pie') is True, 'un Mach-O avec MH_PIE doit être dit PIE')
        verif(len(macho.get('commandes', ())) == attendu_macho['ncmds'],
              'le nombre de commandes Mach-O est faux (%d sur %d)'
              % (len(macho.get('commandes', ())), attendu_macho['ncmds']))
        verif('commandes_tronquees' not in macho,
              'les commandes du Mach-O synthétique doivent toutes se lire (%r)'
              % macho.get('commandes_tronquees'))
        segments_macho = [s['segment'] for s in macho.get('segments', ())]
        verif(segments_macho == ['__TEXT', '__DATA'],
              'les segments Mach-O sont faux (%r)' % segments_macho)
        sections_macho = [s['nom'] for s in macho.get('sections', ())]
        verif(sections_macho == ['__text', '__cstring', '__data'],
              'les sections Mach-O sont fausses (%r)' % sections_macho)
        section_texte = chercher(macho['sections'], 'nom', '__text',
                                 'la section __text du Mach-O')
        verif(section_texte.get('taille') == len(attendu_macho['texte'])
              and section_texte.get('decalage') == 0xf00
              and section_texte.get('executable'),
              'la section __text est mal lue (%r)' % section_texte)
        verif(section_texte.get('type') == 'S_REGULAR',
              'le type de section Mach-O est faux (%r)'
              % section_texte.get('type'))
        cstring = chercher(macho['sections'], 'nom', '__cstring',
                           'la section __cstring du Mach-O')
        verif(cstring.get('type') == 'S_CSTRING_LITERALS',
              '__cstring doit être typé S_CSTRING_LITERALS (%r)'
              % cstring.get('type'))
        verif([b['chemin'] for b in macho.get('bibliotheques', ())]
              == [attendu_macho['dylib']],
              'les bibliothèques liées sont fausses (%r)'
              % macho.get('bibliotheques'))
        verif(macho.get('uuid'), 'l’UUID du Mach-O n’est pas lu')
        verif(macho.get('entree') == attendu_macho['entree'],
              'LC_MAIN.entryoff est mal lu (%r)' % macho.get('entree'))
        noms_symboles = [s['nom'] for s in macho.get('symboles', ())]
        verif(noms_symboles == attendu_macho['symboles'],
              'les symboles Mach-O sont faux (%r)' % noms_symboles)
        main_macho = chercher(macho['symboles'], 'nom', '_main',
                              'le symbole Mach-O _main')
        verif(main_macho.get('exporte') is True,
              '_main doit être détecté comme exporté (%r)' % main_macho)
        verif(main_macho.get('type') == 'N_SECT (défini dans une section)',
              'un symbole défini doit être typé N_SECT (%r)'
              % main_macho.get('type'))
        puts_macho = chercher(macho['symboles'], 'nom', '_puts',
                              'le symbole Mach-O _puts')
        verif(puts_macho.get('importe') is True,
              '_puts non défini doit être détecté comme importé (%r)'
              % puts_macho)
        rapport_macho = analyser(chemin_macho, longueur_chaines=1 << 20)
        verif(rapport_macho['ok']
              and rapport_macho['famille']['famille'] == 'macho',
              'analyser() ne reconnaît pas le Mach-O synthétique')
        verif(any('MARQUEUR_MACHO' in c['texte']
                  for c in rapport_macho.get('chaines', ())),
              'les chaînes du Mach-O ne sont pas retrouvées')
        # LC_MAIN.entryoff est un DÉCALAGE FICHIER : le comparer aux adresses
        # virtuelles des sections signalerait un empaquetage inexistant.
        verif(not any('hors de toute section' in i['quoi']
                      for i in rapport_macho['indices']),
              'l’heuristique de point d’entrée ne doit pas s’appliquer à un '
              'Mach-O (%r)' % [i['quoi'] for i in rapport_macho['indices']])

        # ================= formats secondaires ==============================
        classe = Path(dossier) / 'Exemple.class'
        corps = bytearray(struct.pack('>IHH', 0xCAFEBABE, 0, 52))
        corps += struct.pack('>H', 4)
        corps += b'\x01' + struct.pack('>H', 7) + b'Exemple'
        corps += b'\x01' + struct.pack('>H', 4) + b'main'
        corps += b'\x05' + struct.pack('>q', 0x123456789)   # Long : 2 cases
        classe.write_bytes(bytes(corps))
        with Lecteur(classe) as lecteur:
            java_lu = lire_class_java(lecteur)
        verif(java_lu.get('version') == '8', 'la version de classe Java est '
                                             'fausse (%r)' % java_lu.get('version'))
        verif(len(java_lu['constantes']) == 3,
              'les constantes Java ne sont pas toutes lues (%r)'
              % java_lu['constantes'])
        verif(java_lu['constantes'][2].get('occupe_deux_cases') is True,
              'une constante Long doit être signalée comme occupant deux cases')
        verif(any('bytecode' in n for n in java_lu['resume']),
              'le résumé Java doit dire que ce n’est pas du code machine (%r)'
              % java_lu['resume'])
        classe_cassee = Path(dossier) / 'Cassee.class'
        corps = bytearray(struct.pack('>IHH', 0xCAFEBABE, 0, 52))
        corps += struct.pack('>H', 2) + b'\x63'         # étiquette inconnue
        classe_cassee.write_bytes(bytes(corps))
        with Lecteur(classe_cassee) as lecteur:
            java_casse = lire_class_java(lecteur)
        verif('erreur' in java_casse and '99' in java_casse['erreur'],
              'une étiquette de constante inconnue doit être expliquée en '
              'nommant sa valeur (%r)' % java_casse.get('erreur'))

        module = Path(dossier) / 'module.wasm'
        module.write_bytes(b'\x00asm' + struct.pack('<I', 1) + b'\x01\x04\x01'
                           + b'\x00' * 4 + b'\x0a\x01\x00')
        with Lecteur(module) as lecteur:
            wasm = lire_wasm(lecteur)
        verif(wasm.get('version') == 1, 'la version WASM est fausse')
        verif(len(wasm['sections']) == 2, 'les sections WASM ne sont pas lues (%r)'
              % wasm['sections'])
        verif(wasm['sections'][0]['nom'] == 'types',
              'la section 1 d’un module WASM est « types » (%r)'
              % wasm['sections'][0])
        verif(any('pas décodé' in n for n in wasm['resume']),
              'le résumé WASM doit dire que le bytecode n’est pas décodé')

        # ================= vidage et chaînes bornées ========================
        vidage_resultat = vidage(chemin_elf, 0, 64)
        verif(vidage_resultat['ok'] and vidage_resultat['lignes'] == 4,
              'le vidage de 64 octets sur 16 colonnes doit faire 4 lignes (%r)'
              % vidage_resultat['lignes'])
        verif(vidage_resultat['texte'].startswith('00000000  7f 45 4c 46'),
              'le vidage doit commencer par la signature ELF (%r)'
              % vidage_resultat['texte'][:44])
        verif('|.ELF' in vidage_resultat['texte'],
              'le vidage doit inclure la colonne ASCII (%r)'
              % vidage_resultat['texte'][:60])
        au_dela = vidage(chemin_elf, 1 << 30, 16)
        verif(au_dela['ok'] and au_dela['longueur_rendue'] == 0
              and au_dela['texte'] == '' and au_dela.get('note'),
              'un vidage au-delà de la fin doit rendre une note et RIEN '
              'd’autre (%r)' % au_dela)
        debordant = vidage(chemin_elf, attendu_elf['taille'] - 8, 32)
        verif(debordant['longueur_rendue'] == 8 and debordant.get('note'),
              'un vidage à cheval sur la fin doit rendre les 8 octets réels et '
              'le dire (%r)' % debordant)
        verif('00 00 00 00 00 00 00 00  00 00 00 00' not in debordant['texte'],
              'un vidage ne doit jamais compléter par des zéros inventés')
        court = vidage(chemin_elf, 0, 8, colonnes=8)
        verif(court['lignes'] == 1 and court['longueur_rendue'] == 8,
              'le vidage sur 8 colonnes est faux (%r)' % court)
        verif(vidage(chemin_elf, 0, 16, ascii_=False)['texte'].count('|') == 0,
              'sans ASCII, le vidage ne doit pas avoir de colonne texte')
        courtes = chaines(chemin_elf, minimum=200)
        verif(courtes['ok'] and courtes['compte'] == 0,
              'une longueur minimale au-delà de toute chaîne doit rendre 0 (%r)'
              % courtes['compte'])
        refus = chaines(chemin_elf, minimum=0)
        verif(not refus['ok'] and 'au moins 1' in refus['erreur'],
              'une longueur minimale de 0 doit être refusée en le disant (%r)'
              % refus.get('erreur'))
        apres_fin = chaines(chemin_elf, debut=1 << 30)
        verif(apres_fin['ok'] and apres_fin['compte'] == 0
              and apres_fin.get('note'),
              'une plage au-delà de la fin doit être expliquée (%r)' % apres_fin)
        plage = chaines(chemin_elf, minimum=8,
                        debut=elf['sections'][2]['decalage'], longueur=44)
        verif(plage['ok'] and any(c['texte'] == attendu_elf['chaine']
                                  for c in plage['chaines']),
              'une plage ciblée doit retrouver la chaîne de .rodata (%r)'
              % [c['texte'] for c in plage['chaines']])
        bornees = chaines(chemin_elf, minimum=5, limite=2)
        verif(bornees['ok'] and bornees['compte'] == 2 and bornees['tronque'],
              'la limite de chaînes doit couper ET le dire (%r)' % bornees)
        longues = chaines(chemin_pe, minimum=4, encodages=('ascii', 'utf16'))
        verif(longues['ok'], 'la recherche UTF-16 ne doit pas lever')
        inexistant = chaines(Path(dossier) / 'rien.bin')
        verif(not inexistant['ok'] and 'Stat impossible' in inexistant['erreur'],
              'un fichier inexistant doit être expliqué (%r)'
              % inexistant.get('erreur'))

        # ================= heuristiques =====================================
        for indice in heuristiques(chemin_elf, elf, brut_elf[:65536]):
            verif(indice.get('quoi') and indice.get('raison')
                  and indice.get('confiance') in ('forte', 'moyenne', 'faible'),
                  'une heuristique sans raison ni confiance n’en est pas une (%r)'
                  % indice)
        packe = dict(elf)
        packe['sections'] = list(elf['sections']) + [
            {'nom': 'UPX0', 'taille': 4096, 'decalage': 0, 'entropie': 7.95,
             'presente_dans_le_fichier': True, 'adresse': 0x5000}]
        indices_packes = heuristiques(chemin_elf, packe, b'UPX!' + b'\x00' * 100)
        verif(any(i['quoi'].startswith('Empaqueté par UPX') for i in indices_packes),
              'UPX0 doit déclencher l’indice d’empaquetage (%r)'
              % [i['quoi'] for i in indices_packes])
        verif(any(i['quoi'] == 'Section(s) à forte entropie'
                  for i in indices_packes),
              'une entropie de 7,95 doit être signalée (%r)'
              % [i['quoi'] for i in indices_packes])
        upx = chercher(indices_packes, 'quoi', 'Empaqueté par UPX',
                       'l’indice d’empaquetage UPX')
        verif(str(upx.get('commande', '')).startswith('upx -d ')
              and str(upx.get('commande', '')).endswith(chemin_elf.name),
              'l’indice UPX doit donner la commande de décompression avec le nom '
              'du fichier (%r)' % upx.get('commande'))
        verif(str(upx.get('installation', '')).startswith('sudo apt'),
              'l’indice UPX doit dire comment obtenir l’outil')
        mixte = dict(pe)
        mixte['sections'] = [dict(pe['sections'][0], ecrire_et_executer=True)]
        verif(any('inscriptible et exécutable' in i['quoi']
                  for i in heuristiques(chemin_pe, mixte, b'')),
              'une section W+X doit être signalée')
        sans_mitigation = dict(pe, caracteristiques_dll='-')
        verif(any('Aucune mitigation' in i['quoi']
                  for i in heuristiques(chemin_pe, sans_mitigation, b'')),
              'un PE sans ASLR ni DEP doit être signalé')
        depouille = dict(elf, depouille=True, note_depouille='Aucune table '
                         '.symtab : le binaire est dépouillé (strip).')
        verif(any(i['quoi'].startswith('Symboles retirés')
                  for i in heuristiques(chemin_elf, depouille, b'')),
              'un binaire dépouillé doit être signalé')
        statique = dict(elf, statique=True, type_brut=2,
                        note_statique='Aucune bibliothèque dynamique.')
        verif(any(i['quoi'] == 'Liaison statique'
                  for i in heuristiques(chemin_elf, statique, b'')),
              'une liaison statique doit être signalée')
        macho_chiffre = dict(macho, chiffre={'offset': 0, 'taille': 100,
                                             'identifiant': 1})
        verif(any('chiffré' in i['quoi']
                  for i in heuristiques(chemin_macho, macho_chiffre, b'')),
              'un segment chiffré Mach-O doit être signalé')
        pe_manage = dict(pe, manage=True, note_manage='Un répertoire COM/.NET '
                         'est présent.')
        verif(any('managé' in i['quoi']
                  for i in heuristiques(chemin_pe, pe_manage, b'')),
              'un exécutable .NET doit être signalé')
        entree_hors = dict(elf, entree=0x99999999)
        verif(any('hors de toute section' in i['quoi']
                  for i in heuristiques(chemin_elf, entree_hors, b'')),
              'un point d’entrée ELF hors section doit être signalé')

        # ================= outils externes ==================================
        echec = desassembler(Path(dossier) / 'n-existe-pas.bin')
        if _outil('objdump'):
            verif(not echec['ok'] and echec.get('erreur'),
                  'objdump sur un fichier inexistant doit rendre un échec '
                  'expliqué (%r)' % echec)
            verif('commande' in echec, 'la commande lancée doit être rendue')
        refus_option = readelf(chemin_elf, ('--output=/tmp/x',))
        if _outil('readelf'):
            verif(not refus_option['ok']
                  and 'liste autorisée' in refus_option['erreur'],
                  'une option readelf hors liste blanche doit être refusée (%r)'
                  % refus_option.get('erreur'))
            verif(not readelf(chemin_elf, ('-h', 'autre_fichier'))['ok'],
                  'readelf ne doit pas accepter un second fichier en argument')
            autorise = readelf(chemin_elf, ('-h', '-W'))
            verif(autorise['ok'] and 'ELF Header' in autorise['sortie'],
                  'readelf -h doit rendre l’en-tête (%r)'
                  % autorise.get('erreur'))
        refus_adresse = demarrer_adresse(chemin_elf, 'pas-une-adresse')
        verif(not refus_adresse['ok'] and 'hexadécimal' in refus_adresse['erreur'],
              'une adresse invalide doit être refusée en le disant (%r)'
              % refus_adresse.get('erreur'))
        refus_injection = demarrer_adresse(chemin_elf, '0x1000; rm -rf /')
        verif(not refus_injection['ok'],
              'une adresse contenant un point-virgule doit être refusée')
        verif(_adresse('0x1000') == '0x1000' and _adresse(4096) == '0x1000'
              and _adresse('1000') == '0x3e8',
              'la conversion d’adresse est fausse')
        try:
            _adresse('0x1000 && reboot')
            problemes.append('_adresse doit lever sur une injection de commande')
        except ValueError:
            pass
        sans_outil = symboles_nm(chemin_elf)
        if _outil('nm'):
            verif(sans_outil['ok'] and sans_outil['nombre'] > 0,
                  'nm doit rendre des symboles sur l’ELF synthétique (%r)'
                  % sans_outil.get('erreur'))
            verif(all(s.get('type_lecture') for s in sans_outil['symboles']),
                  'chaque symbole nm doit porter une lecture de son type')
        identite = identifer(chemin_elf)
        if _outil('file'):
            verif(identite['ok'] and 'ELF' in identite['avis'],
                  'file doit reconnaître l’ELF synthétique (%r)'
                  % identite.get('avis'))
            avis_pe = identifer(chemin_pe)
            verif(avis_pe['ok'] and 'PE32+' in avis_pe['avis'],
                  'file doit reconnaître le PE32+ synthétique (%r)'
                  % avis_pe.get('avis'))
        else:
            verif(not identite['ok'] and 'n’est pas installé' in identite['raison'],
                  'l’absence de file doit être expliquée')
        verif(not _lancer(['commande-qui-n-existe-pas'])['ok'],
              'une commande absente doit rendre un échec, pas lever')
        verif(_lancer(['commande-qui-n-existe-pas'])['code'] is None,
              'une commande absente doit rendre code=None')

        # ---- la locale imposée, et l'outil qui avertit ---------------------
        # Ces cinq contrôles jouent la règle au lieu de la réciter : la locale
        # est lue dans l'environnement d'un processus fils réellement lancé, et
        # la normalisation est exercée sur un outil qui avertit puis répond.
        # Sans eux, un retour en arrière — retirer env=, ou normaliser avant le
        # repli de syntaxe — ne serait vu par personne.
        python = shutil.which('python3') or shutil.which('python')
        if python:
            lu = _lancer([python, '-c',
                          'import os;print(os.environ.get("LC_ALL",""))'])
            verif(lu['sortie'].strip() == 'C.UTF-8',
                  'les outils doivent être lancés en LC_ALL=C.UTF-8, sinon ils '
                  'répondent dans la langue de la machine et les expressions '
                  'régulières ne trouvent plus rien (reçu %r)'
                  % lu['sortie'].strip())
        averti = _lancer([python or 'python3', '-c',
                          'import sys;'
                          'print("ELF Header:");'
                          'sys.stderr.write("readelf: Error: PHDR non couvert\\n");'
                          'sys.exit(1)'])
        verif(averti['code'] == 1 and not averti['ok'],
              'le code de retour doit rester fidèle avant normalisation (%r)'
              % averti.get('code'))
        normalise = _normaliser_outil(averti)
        verif(normalise['ok'] and normalise.get('averti')
              and normalise['code'] == 1,
              'une sortie exploitable malgré un code non nul doit être retenue '
              'ET annoncée comme un avertissement (%r)' % normalise.get('code'))
        verif(any('PHDR' in a for a in normalise.get('avertissements', [])),
              'l’avis de l’outil doit remonter dans avertissements (%r)'
              % normalise.get('avertissements'))
        muet = _normaliser_outil(
            _lancer([python or 'python3', '-c', 'import sys;sys.exit(2)']))
        verif(not muet['ok'],
              'un outil qui n’a rien écrit doit rester un échec : sinon un '
              'fichier absent passerait pour une analyse vide')

        # ================= Lecteur borné ====================================
        with Lecteur(chemin_elf) as lecteur:
            verif(lecteur.u32(0) == 0x464c457f,
                  'la signature ELF lue en u32 est fausse (%r)' % hex(lecteur.u32(0)))
            verif(lecteur.u8(4) == 2 and lecteur.u8(5) == 1,
                  'la classe et le boutisme doivent se lire octet par octet')
            verif(lecteur.lire(1 << 40, 16) == b'\x00' * 16,
                  'une lecture hors fichier doit rendre des zéros')
            verif(any('au-delà' in t for t in lecteur.troncatures),
                  'une lecture hors fichier doit être NOTÉE (%r)'
                  % lecteur.troncatures)
            verif(len(lecteur.troncatures) == 1,
                  'le même reproche ne doit pas être répété (%r)'
                  % lecteur.troncatures)
            verif(lecteur.chaine(1, 3) == 'ELF',
                  'une chaîne bornée doit rendre exactement sa borne (%r)'
                  % lecteur.chaine(1, 3))
            verif(lecteur.chaine(elf['sections'][5]['decalage'])
                  == attendu_elf['interprete'],
                  'une chaîne terminée par NUL doit s’arrêter au NUL (%r)'
                  % lecteur.chaine(elf['sections'][5]['decalage']))
            verif(lecteur.lire(-5, 5) == b'\x7fELF\x02',
                  'une position négative doit être ramenée à 0 et notée')
            geante = lecteur.lire(0, LECTURE_MAX + 1)
            verif(len(geante) == LECTURE_MAX,
                  'une lecture géante doit être ramenée à la limite (%d octets)'
                  % len(geante))
            del geante
            verif(any('refusée' in t for t in lecteur.troncatures),
                  'un refus de lecture géante doit être noté')
            memoire = lecteur.lire(0, 16)
            verif(memoire == lecteur.lire(0, 16),
                  'la mémoire de lecture doit rendre la même chose')
        manquant = Lecteur(Path(dossier) / 'n-existe-pas.bin')
        verif(manquant.taille == 0 and manquant.troncatures,
              'un fichier inexistant doit rendre un lecteur vide avec sa raison')
        verif(manquant.lire(0, 8) == b'\x00' * 8,
              'un lecteur sans fichier doit rendre des zéros, pas lever')
        manquant.fermer()
        manquant.fermer()

        # ================= croisement avec de VRAIS binaires ================
        gcc = _outil('gcc')
        source = Path(dossier) / 'reference.c'
        source.write_text(
            '#include <stdio.h>\n'
            'const char *message_secret = "MARQUEUR_DE_CONTROLE_XYZ";\n'
            'static int fonction_locale(int a){ return a * 3; }\n'
            'int fonction_publique(int a){ return fonction_locale(a) + 1; }\n'
            'int main(void){ printf("%s %d\\n", message_secret, '
            'fonction_publique(4)); return 0; }\n', 'utf8')
        if not gcc:
            # Sans gcc, le contrôle repose sur les synthèses. Le dire est
            # nécessaire : un banc qui se tait sur ce qu’il n’a pas pu tester
            # laisse croire à une couverture qui n’existe pas.
            print('retro_binaires : gcc absent, le croisement avec binutils '
                  'n’a pas été effectué (les synthèses ont été vérifiées).')
        else:
            binaire = Path(dossier) / 'reference'
            compile = _lancer([gcc, '-no-pie', '-g0', '-o', str(binaire),
                               str(source)], delai=180)
            if not compile['ok'] or not binaire.is_file():
                problemes.append('gcc est présent mais la compilation de '
                                 'référence a échoué : %s'
                                 % (compile.get('erreur', '')
                                    or compile.get('sortie', ''))[:300])
            else:
                with Lecteur(binaire) as lecteur:
                    reel = lire_elf(lecteur)
                verif('erreur' not in reel,
                      'un vrai binaire gcc doit se lire (%r)' % reel.get('erreur'))
                verif(reel.get('machine') == 'x86-64',
                      'le binaire réel n’est pas lu comme x86-64 (%r)'
                      % reel.get('machine'))
                verif(reel.get('classe') == '64 bits',
                      'un binaire Debian amd64 doit être lu comme 64 bits')
                symboles_reels = {s['nom'] for s in reel.get('symboles', ())}
                for attendu in ('main', 'fonction_publique', 'fonction_locale',
                                'message_secret'):
                    verif(attendu in symboles_reels,
                          '%s est absent de .symtab sur un binaire réel non '
                          'dépouillé' % attendu)
                verif(reel.get('imports'),
                      'un exécutable dynamique doit avoir des NEEDED')
                verif(any('libc' in i for i in reel.get('imports', ())),
                      'libc doit apparaître dans les NEEDED (%r)'
                      % reel.get('imports'))
                verif(reel.get('interprete', '').endswith(
                    'ld-linux-x86-64.so.2'),
                      'l’interpréteur dynamique n’est pas reconnu (%r)'
                      % reel.get('interprete'))
                verif(not reel.get('statique'),
                      'un binaire lié à libc ne doit pas être dit statique')
                build = next((n.get('build_id') for n in reel.get('notes', ())
                              if n.get('build_id')), '')
                verif(bool(build) and len(build) >= 8,
                      'le build-id n’est pas lu sur un binaire réel (%r)' % build)
                verif(bool(reel.get('commentaire')),
                      'le compilateur n’est pas lu depuis .comment sur un vrai '
                      'binaire')
                extrait_reel = chaines(binaire, minimum=10)
                verif(any('MARQUEUR_DE_CONTROLE_XYZ' in c['texte']
                          for c in extrait_reel['chaines']),
                      'la chaîne du source n’est pas retrouvée dans le binaire')
                attribuer_chaines(reel, extrait_reel['chaines'])
                marqueur = chercher(extrait_reel['chaines'], 'texte',
                                    'MARQUEUR_DE_CONTROLE_XYZ',
                                    'la chaîne du source')
                verif(marqueur.get('section') == '.rodata',
                      'une chaîne constante doit être attribuée à .rodata (%r)'
                      % marqueur.get('section'))
                rapport_reel = analyser(binaire)
                verif(rapport_reel['ok'] and bool(rapport_reel['resume']),
                      'le rapport d’un binaire réel doit être complet')
                verif(rapport_reel['empreintes']['ok']
                      and len(rapport_reel['empreintes']['sha256']) == 64,
                      'les empreintes d’un binaire réel doivent être calculées')
                verif(not rapport_reel['erreurs'],
                      'un binaire gcc valide ne doit produire aucune erreur (%r)'
                      % rapport_reel['erreurs'])
                if _outil('file'):
                    avis = identifer(binaire)['avis']
                    verif('ELF' in avis and '64-bit' in avis,
                          'file ne confirme pas un ELF 64 bits (%r)' % avis)
                    verif(('executable' in avis) == bool(
                              reel.get('executable') or reel.get('pie')),
                          'file dit %r là où Pascal Studio dit %r : les deux '
                          'doivent s’accorder sur le caractère exécutable'
                          % (avis, reel.get('type')))

                # --- croisement readelf : le contrôle qui distingue un
                # --- parseur cohérent d’un parseur juste --------------------
                COMPTEUR['croisements'] += 1
                if _outil('readelf'):
                    reference = readelf(binaire, ('-h', '-W'))
                    verif(reference['ok'], 'readelf -h a échoué (%r)'
                          % reference.get('erreur'))
                    entete = reference['sortie']
                    verif('Advanced Micro Devices X86-64' in entete,
                          'readelf n’annonce pas x86-64 (%r)' % entete[:200])
                    correspondance = re.search(r'Number of section headers:\s+(\d+)',
                                               entete)
                    verif(correspondance
                          and int(correspondance.group(1)) == reel['shnum'],
                          'le nombre de sections diffère de readelf (%d contre %s)'
                          % (reel['shnum'],
                             correspondance.group(1) if correspondance else '?'))
                    correspondance = re.search(r'Number of program headers:\s+(\d+)',
                                               entete)
                    verif(correspondance
                          and int(correspondance.group(1)) == reel['phnum'],
                          'le nombre de segments diffère de readelf (%d contre %s)'
                          % (reel['phnum'],
                             correspondance.group(1) if correspondance else '?'))
                    correspondance = re.search(r'Entry point address:\s+(0x[0-9a-f]+)',
                                               entete)
                    verif(correspondance
                          and int(correspondance.group(1), 16) == reel['entree'],
                          'le point d’entrée diffère de readelf (%s contre %s)'
                          % (reel['entree_hex'],
                             correspondance.group(1) if correspondance else '?'))
                    correspondance = re.search(r'Type:\s+(\w+)', entete)
                    verif(correspondance and reel['type'].startswith(
                        correspondance.group(1)),
                          'le type diffère de readelf (%r contre %r)'
                          % (reel['type'], correspondance.group(1)
                             if correspondance else '?'))
                    sections = readelf(binaire, ('-S', '-W'))
                    for section in reel['sections']:
                        if section['nom']:
                            verif(section['nom'] in sections['sortie'],
                                  'la section %s lue par Pascal Studio '
                                  'n’apparaît pas dans readelf -S'
                                  % section['nom'])
                    dynamisme = readelf(binaire, ('-d',))
                    for bibliotheque in reel['imports']:
                        verif(bibliotheque in dynamisme['sortie'],
                              'la bibliothèque %s lue par Pascal Studio '
                              'n’apparaît pas dans readelf -d' % bibliotheque)
                    segments = readelf(binaire, ('-l', '-W'))
                    verif(reel['interprete'] in segments['sortie'],
                          'l’interpréteur lu par Pascal Studio n’apparaît pas '
                          'dans readelf -l')
                    symboles_ext = symboles_nm(binaire)
                    if symboles_ext['ok']:
                        noms_nm = {s['nom'] for s in symboles_ext['symboles']}
                        verif('main' in noms_nm,
                              'nm ne retrouve pas main sur un binaire réel')
                        verif('fonction_locale' in noms_nm,
                              'nm ne retrouve pas une fonction statique')
                        for attendu in ('main', 'fonction_publique',
                                        'fonction_locale', 'message_secret'):
                            verif(attendu in noms_nm,
                                  'nm ne retrouve pas %s, que notre .symtab '
                                  'contient pourtant' % attendu)
                    desassemble = desassembler(binaire, symbole='main',
                                               lignes=300)
                    verif(desassemble['ok'], 'le désassemblage de main a échoué '
                                             '(%r)' % desassemble.get('erreur'))
                    verif('<main>:' in desassemble['texte'],
                          'le désassemblage ciblé sur main ne contient pas '
                          '<main>: (%r)' % desassemble['texte'][:200])
                    verif(len(desassemble['texte'].split('\n')) <= 300,
                          'la borne de lignes du désassemblage n’est pas tenue')
                    intel = desassembler(binaire, symbole='main', syntaxe='intel',
                                         lignes=300)
                    verif(intel['ok'] and '-M intel' in intel['commande'],
                          'la syntaxe Intel doit passer -M intel (%r)'
                          % intel.get('commande'))
                    plage = demarrer_adresse(binaire, reel['entree'],
                                             reel['entree'] + 64)
                    verif(plage['ok'] and len(plage['texte']) > 0,
                          'le désassemblage d’une plage est vide (%r)'
                          % plage.get('erreur'))

                # --- binaire dépouillé --------------------------------------
                depouille = Path(dossier) / 'depouille'
                if _lancer([gcc, '-s', '-o', str(depouille), str(source)],
                           delai=180)['ok'] and depouille.is_file():
                    with Lecteur(depouille) as lecteur:
                        sans_symboles = lire_elf(lecteur)
                    verif(sans_symboles.get('depouille') is True,
                          'un binaire -s doit être dit dépouillé')
                    verif('dépouillé' in sans_symboles.get('note_depouille', ''),
                          'le strip doit être expliqué, pas seulement marqué')
                    verif(not sans_symboles.get('symboles'),
                          'un binaire dépouillé ne doit pas rendre de .symtab')
                    verif(any(s.get('importe') or s.get('exporte')
                              for s in sans_symboles.get('symboles_dynamiques',
                                                         ())),
                          '.dynsym subsiste même après strip')
                    verif(not analyser(depouille, avec_chaines=False)['erreurs'],
                          'un binaire dépouillé ne doit produire aucune erreur')

                # --- objet partagé et SONAME ---------------------------------
                partage = Path(dossier) / 'libpartage.so'
                if _lancer([gcc, '-shared', '-fPIC',
                            '-Wl,-soname=libpartage.so.1', '-o', str(partage),
                            str(source)], delai=180)['ok'] and partage.is_file():
                    with Lecteur(partage) as lecteur:
                        bibliotheque = lire_elf(lecteur)
                    verif(bibliotheque.get('objet_partage') is True,
                          'un .so doit être de type DYN')
                    verif(bibliotheque.get('soname') == 'libpartage.so.1',
                          'le SONAME n’est pas lu sur un vrai .so (%r)'
                          % bibliotheque.get('soname'))
                    verif('fonction_publique' in bibliotheque.get('exports', ()),
                          'une fonction globale d’un .so doit être exportée (%r)'
                          % bibliotheque.get('exports', ())[:8])

                # --- objet relocatable --------------------------------------
                objet = Path(dossier) / 'reference.o'
                if _lancer([gcc, '-c', '-o', str(objet), str(source)],
                           delai=180)['ok'] and objet.is_file():
                    with Lecteur(objet) as lecteur:
                        relocatable = lire_elf(lecteur)
                    verif(relocatable.get('type_brut') == 1,
                          'un .o doit être de type REL (%r)'
                          % relocatable.get('type'))
                    verif(relocatable.get('relocations'),
                          'un .o doit porter des relocations')
                    verif(relocatable['relocations_total']
                          >= len(relocatable['relocations']),
                          'le total de relocations doit être au moins la liste')
                    if _outil('readelf'):
                        reference_relocs = readelf(objet, ('-r', '-W'))
                        verif(reference_relocs['ok'],
                              'readelf -r a échoué sur un .o')

        # ================= cohérence des tables =============================
        verif(len(TYPES_ELF) == 5, 'la table des types ELF doit avoir 5 entrées')
        verif(TYPES_ELF[3].startswith('DYN'), 'le type DYN est mal nommé')
        verif(MACHINES_ELF.get(62) == 'x86-64' and MACHINES_ELF.get(3) == 'x86',
              'les machines x86 et x86-64 sont mal nommées')
        for machine in (183, 243, 40, 20):
            verif(machine in MACHINES_ELF,
                  'la machine %d manque dans la table ELF' % machine)
        for machine in (0x8664, 0xaa64, 0x14c):
            verif(machine in MACHINES_PE,
                  'la machine 0x%x manque dans la table PE' % machine)
        verif(len(NOMS_REPERTOIRES_PE) == 16,
              'la table des répertoires PE doit avoir 16 entrées (%d)'
              % len(NOMS_REPERTOIRES_PE))
        verif(NOMS_REPERTOIRES_PE[1] == 'Import'
              and NOMS_REPERTOIRES_PE[0] == 'Export',
              'les répertoires PE 0 et 1 doivent être Export puis Import (%r)'
              % (NOMS_REPERTOIRES_PE[:2],))
        verif(TYPES_SEGMENT_ELF.get(0x6474e551) == 'GNU_STACK',
              'GNU_STACK manque dans la table des segments')
        verif(len(EMPAQUETEURS) >= 5,
              'la table des empaqueteurs doit couvrir les principaux')
        verif(TYPES_SYMBOLE_ELF.get(2) == 'FUNC'
              and TYPES_SYMBOLE_ELF.get(1) == 'OBJECT',
              'les types de symbole ELF sont mal nommés')
        verif(len(TYPES_NM) >= 20, 'la table des types nm est trop courte (%d)'
              % len(TYPES_NM))
        verif(all(len(v) > 3 for v in TYPES_NM.values()),
              'une lecture de type nm ne doit pas être vide')
    finally:
        shutil.rmtree(dossier, ignore_errors=True)
    return problemes


if __name__ == '__main__':
    import sys

    soucis = verifier()
    if soucis:
        for souci in soucis:
            print('ÉCHEC :', souci)
        sys.exit(1)
    print('retro_binaires : %d contrôles, dont %d croisement(s) avec de vrais '
          'binaires compilés ; ELF/PE/Mach-O synthétiques lus, troncatures '
          'tolérées, familles et ambiguïté 0xCAFEBABE traitées.'
          % (COMPTEUR['verifs'], COMPTEUR['croisements']))
