"""Détection de l'outillage de rétro-ingénierie, et de Ghidra en particulier.

Ce module ne fait qu'une chose, mais il la fait sans jamais deviner : dire ce qui
est installé, ce qui manque, et quoi faire pour l'installer. Trois règles, toutes
trois issues d'une contrainte réelle :

  1. GHIDRA N'EST PAS LIVRÉ. L'archive de Pascal Studio fait environ 9 Mo ;
     Ghidra pèse 570 Mo et exige un JDK 21+. Il ne peut pas être vendu avec
     l'application, donc le panneau le DÉTECTE. Un panneau qui promet une
     fonctionnalité conditionnelle sans dire la condition ment par omission.
  2. RIEN NE LÈVE. Une détection qui échoue (un dossier illisible, un `java
     -version` qui écrit sur stderr et rien sur stdout, un binaire absent) rend
     un état dégradé avec sa raison. Le panneau affiche la raison ; il n'affiche
     jamais une zone vide qui laisserait croire que tout va bien.
  3. LA VERSION DE GHIDRA CHANGE LE LANGAGE DE SCRIPT. Ghidra 12.x a supprimé
     Jython : les scripts Python passent par PyGhidra (CPython 3 ponté au JVM
     par JPype). Ghidra 11.x et avant utilisent Jython, donc Python 2.7, donc
     les mêmes scripts ne fonctionnent pas. Détecter la version n'est pas un
     détail de confort : c'est ce qui décide quel postScript écrire.

Les trois voies d'installation réelles sont rendues telles quelles, avec la
contrainte du JDK, plutôt qu'un « installez Ghidra » qui ne mène nulle part.
"""

import importlib.util
import json
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

VERSION = '4.0.0'

# Ghidra 12.x : PyGhidra. 11.x : Jython. La table est explicite parce qu'une
# comparaison de chaînes (« 9.2 » > « 11.0 » en ordre lexicographique) donnerait
# un verdict faux, et silencieusement.
JDK_MINIMUM = ((12, 0), 21), ((11, 3), 21), ((11, 0), 17), ((0, 0), 11)

ENVIRONNEMENTS_GHIDRA = ('PS_GHIDRA_DIR', 'GHIDRA_INSTALL_DIR', 'GHIDRA_HOME',
                         'GHIDRA_DIR')

CHEMINS_GHIDRA = (
    '/usr/lib/ghidra', '/usr/share/ghidra', '/opt/ghidra', '/usr/local/ghidra',
    '/usr/local/lib/ghidra', '/opt/local/ghidra',
)

GLOBES_GHIDRA = (
    '/opt/ghidra*', '/usr/lib/ghidra*', '/usr/share/ghidra*',
    '/usr/local/ghidra*', '/snap/ghidra/*',
)

OUTILS = (
    # (nom, commande, rôle, indispensable)
    ('objdump', 'objdump', 'Désassemblage et en-têtes de tous les formats '
     'reconnus par binutils.', False),
    ('readelf', 'readelf', 'Lecture détaillée des ELF : sections, segments, '
     'symboles, dynamique.', False),
    ('nm', 'nm', 'Liste des symboles, y compris non exportés quand le fichier '
     'n’est pas dépouillé.', False),
    ('strings', 'strings', 'Extraction des chaînes imprimables.', False),
    ('file', 'file', 'Identification par signature, indépendante de '
     'l’extension.', False),
    ('od', 'od', 'Vidage hexadécimal quand aucun autre outil n’est là.', True),
    ('as', 'as', 'Assemblage : nécessaire pour recompiler un extrait modifié.',
     False),
    ('ld', 'ld', 'Édition de liens.', False),
    ('gcc', 'gcc', 'Compilation et liens ; sert aussi à produire des binaires '
     'de référence pour comparer les analyses.', False),
    ('gdb', 'gdb', 'Débogage pas à pas d’un binaire natif.', False),
    ('radare2', 'radare2', 'Suite d’analyse alternative à Ghidra, en ligne de '
     'commande.', False),
    ('rizin', 'rizin', 'Successeur de radare2, mêmes usages.', False),
    ('nasm', 'nasm', 'Assembleur en syntaxe Intel.', False),
    ('java', 'java', 'Machine virtuelle : Ghidra est une application Java.',
     False),
    ('c++filt', 'c++filt', 'Dé-mangling des symboles C++.', False),
)

BIBLIOTHEQUES = (
    ('capstone', 'capstone', 'Désassembleur multi-architectures en Python. Sans '
     'lui, le désassemblage passe par objdump.'),
    ('pyelftools', 'elftools', 'Lecture des ELF en Python pur. Sans lui, ce '
     'module lit les ELF lui-même, ce qui est plus lent mais ne dépend de rien.'),
    ('pefile', 'pefile', 'Lecture des exécutables Windows. Sans lui, ce module '
     'les lit lui-même.'),
    ('lief', 'lief', 'Lecture et modification multi-formats (ELF, PE, Mach-O).'),
    ('unicorn', 'unicorn', 'Émulation de code : permet d’exécuter une fonction '
     'isolée sans lancer le binaire.'),
)

INSTALLATIONS = (
    {'id': 'apt-tiers', 'nom': 'Dépôt tiers (Debian 13 et suivantes)',
     'resume': 'Un dépôt non officiel compile Ghidra depuis ses sources pour '
               'Debian trixie et suivantes, en amd64 et arm64. C’est la seule '
               'voie qui donne des mises à jour par apt.',
     'commandes': (
         "wget -qO - https://apt.lemesre.org/public.key | "
         "sudo gpg --dearmor -o /usr/share/keyrings/lemesre.gpg",
         "echo 'deb [signed-by=/usr/share/keyrings/lemesre.gpg] "
         "https://apt.lemesre.org trixie main' | "
         "sudo tee /etc/apt/sources.list.d/lemesre.list",
         'sudo apt update && sudo apt install ghidra',
     ),
     'installe_dans': '/usr/lib/ghidra',
     'source': 'https://github.com/eric-lemesre/ghidra-debian'},
    {'id': 'kali', 'nom': 'Paquet Kali Linux',
     'resume': 'Kali fournit Ghidra dans son dépôt. Sur une Debian ordinaire, '
               'ce paquet tire des dépendances de Kali : à réserver à une '
               'machine déjà sous Kali.',
     'commandes': ('sudo apt install ghidra',),
     'installe_dans': '/usr/share/ghidra', 'source': ''},
    {'id': 'zip-amont', 'nom': 'Archive officielle (environ 570 Mo)',
     'resume': 'L’amont ne publie qu’une archive zip multiplateforme. Elle '
               'contient tout, ne dépend d’aucun dépôt, mais ne se met pas à '
               'jour toute seule.',
     'commandes': (
         '# Télécharger la dernière version depuis',
         '#   https://github.com/NationalSecurityAgency/ghidra/releases',
         'unzip ghidra_*.zip -d /opt',
         'sudo ln -s /opt/ghidra_*/ghidraRun /usr/local/bin/ghidraRun',
     ),
     'installe_dans': '/opt/ghidra_<version>',
     'source': 'https://github.com/NationalSecurityAgency/ghidra/releases'},
    {'id': 'jdk', 'nom': 'Le JDK exigé par Ghidra',
     'resume': 'Ghidra compile ses scripts à l’exécution : il lui faut un JDK, '
               'pas seulement un JRE. Debian 13 fournit OpenJDK 21.',
     'commandes': ('sudo apt install openjdk-21-jdk',),
     'installe_dans': '/usr/lib/jvm/java-21-openjdk-amd64', 'source': ''},
    {'id': 'pyghidra', 'nom': 'Le pont PyGhidra (Ghidra 12 et plus)',
     'resume': 'Ghidra 12 a supprimé Jython : les scripts Python passent par '
               'PyGhidra, qui relie CPython à la machine virtuelle Java par '
               'JPype. La roue PyGhidra est livrée DANS Ghidra, donc le venv se '
               'crée sans accès réseau. JPype, lui, est dans Debian 13 sous le '
               'nom python3-jpype ; le venv doit donc voir les paquets système.',
     'commandes': (
         'sudo apt install python3-venv python3-jpype',
         'python3 -m venv --system-site-packages '
         '~/.pascal-studio/retro/venv-pyghidra',
         '~/.pascal-studio/retro/venv-pyghidra/bin/pip install --no-index '
         '--no-deps /usr/lib/ghidra/Ghidra/Features/PyGhidra/pypkg/dist/'
         'pyghidra-*.whl',
     ),
     'installe_dans': '~/.pascal-studio/retro/venv-pyghidra',
     'source': 'https://packages.debian.org/trixie/python3-jpype'},
    {'id': 'binutils', 'nom': 'binutils et gdb (analyse sans Ghidra)',
     'resume': 'Ces paquets suffisent pour la plus grande partie du travail : '
               'en-têtes, sections, symboles, désassemblage, débogage. Ils '
               'sont petits et dans Debian.',
     'commandes': ('sudo apt install binutils gdb file strace',),
     'installe_dans': '/usr/bin', 'source': ''},
)

_cache = {'quoi': None, 'quand': 0.0, 'valeur': None}
CACHE_SECONDES = 30.0


def dossier_etat():
    """Le dossier où Pascal Studio garde ses réglages et son cache de projets.

    Hors du projet ouvert : un cache d'analyse de plusieurs centaines de Mo ne
    doit pas apparaître dans l'arborescence du projet de l'utilisateur, et un
    réglage de chemin vers Ghidra ne doit pas dépendre du projet en cours.
    """
    personnalise = os.environ.get('PS_RETRO_DIR')
    if personnalise:
        return Path(os.path.expanduser(personnalise))
    return Path(os.path.expanduser('~/.pascal-studio/retro'))


def _executer(commande, delai=12):
    """(code, sortie fusionnée). Ne lève jamais, et dit pourquoi si ça échoue.

    La sortie d'erreur est FUSIONNÉE : `java -version` écrit sur stderr et rien
    sur stdout. Ne lire que stdout ferait conclure à un JDK absent alors qu'il
    est là — exactement le genre de faux négatif que ce module existe pour
    éviter.
    """
    try:
        # La locale est imposée : `java -version` et les autres outils de
        # détection écrivent leurs diagnostics dans la langue de la machine, et
        # ce texte remonte tel quel dans `raison`, puis dans le panneau.
        environnement = dict(os.environ)
        environnement['LC_ALL'] = 'C.UTF-8'
        environnement['LC_MESSAGES'] = 'C'
        environnement['LANGUAGE'] = 'C'
        environnement['TERM'] = 'dumb'
        termine = subprocess.run(
            commande, capture_output=True, text=True, timeout=delai,
            stdin=subprocess.DEVNULL, errors='replace', env=environnement)
        return termine.returncode, ((termine.stdout or '')
                                    + (termine.stderr or ''))
    except FileNotFoundError:
        return None, 'commande introuvable'
    except subprocess.TimeoutExpired:
        return None, 'délai dépassé (%d s)' % delai
    except OSError as exc:
        return None, 'impossible à lancer : %s' % (exc.strerror or exc)


def lire_version_ghidra(racine):
    """La version d'une installation de Ghidra, lue dans ses fichiers.

    `Ghidra/application.properties` porte `application.version=11.3.1` et
    `application.release.name=PUBLIC`. C'est la source fiable : le nom du
    dossier peut avoir été renommé, et `ghidraRun --version` n'existe pas.
    """
    racine = Path(racine)
    candidats = (racine / 'Ghidra' / 'application.properties',
                 racine / 'application.properties',
                 racine / 'Ghidra' / 'Features' / 'Base' / 'application.properties')
    for candidat in candidats:
        try:
            if not candidat.is_file():
                continue
            texte = candidat.read_text('utf8', 'replace')
        except OSError:
            continue
        correspondance = re.search(r'^\s*application\.version\s*=\s*([0-9][0-9.]*)',
                                   texte, re.MULTILINE)
        if correspondance:
            version = correspondance.group(1).strip()
            publication = re.search(r'^\s*application\.release\.name\s*=\s*(\S+)',
                                    texte, re.MULTILINE)
            return {'version': version,
                    'publication': publication.group(1) if publication else '',
                    'source': str(candidat)}
    return None


def _paire_version(version):
    """(majeure, mineure) en entiers. Une version illisible vaut (0, 0).

    Les comparaisons portent sur des ENTIERS : « 9.2.2 » > « 11.0 » est vrai en
    ordre lexicographique et faux en réalité, et ce module décide du langage de
    script sur cette comparaison.
    """
    morceaux = re.findall(r'\d+', str(version or ''))
    if not morceaux:
        return (0, 0)
    majeure = int(morceaux[0])
    mineure = int(morceaux[1]) if len(morceaux) > 1 else 0
    return (majeure, mineure)


def jdk_requis(version):
    """Le JDK minimal pour une version de Ghidra, d'après la table JDK_MINIMUM."""
    paire = _paire_version(version)
    for seuil, minimum in JDK_MINIMUM:
        if paire >= seuil:
            return minimum
    return JDK_MINIMUM[-1][1]


def langage_de_script(version):
    """« pyghidra » pour Ghidra 12 et plus, « jython » pour 11 et moins.

    Ghidra 12 a supprimé Jython. Écrire un postScript Python 3 pour un Ghidra 11
    échoue obscurément (Jython ne connaît ni les f-strings ni les annotations),
    et écrire du Python 2.7 pour un Ghidra 12 échoue aussi. Le verdict est donc
    rendu AVANT d'écrire le moindre script.
    """
    paire = _paire_version(version)
    if paire[0] == 0:
        return 'inconnu'
    return 'pyghidra' if paire >= (12, 0) else 'jython'


def _roue_pyghidra(racine):
    """La roue PyGhidra livrée DANS Ghidra : un venv se crée sans réseau.

    C'est ce qui rend l'intégration possible sur une machine hors ligne : la
    dépendance Python de Ghidra 12 est fournie par Ghidra 12 lui-même.
    """
    racine = Path(racine)
    motif = racine / 'Ghidra' / 'Features' / 'PyGhidra' / 'pypkg' / 'dist'
    try:
        roues = sorted(motif.glob('pyghidra-*.whl'))
    except OSError:
        roues = []
    return str(roues[-1]) if roues else ''


def chercher_ghidra():
    """Les installations de Ghidra trouvées, dans l'ordre de préférence.

    L'ordre compte : une variable d'environnement est un choix explicite de
    l'utilisateur, donc elle passe avant un chemin standard, qui passe avant un
    dossier deviné dans /opt ou le dossier personnel.
    """
    trouvees = []
    vus = set()

    def proposer(chemin, origine):
        if not chemin:
            return
        try:
            reel = Path(os.path.expanduser(str(chemin))).resolve()
        except (OSError, ValueError):
            return
        cle = str(reel)
        if cle in vus:
            return
        if not reel.is_dir():
            return
        # Une installation de Ghidra se reconnaît à ghidraRun ou à la hiérarchie
        # Ghidra/ : accepter n'importe quel dossier ferait analyser le projet de
        # l'utilisateur comme une installation.
        if not ((reel / 'ghidraRun').is_file() or (reel / 'Ghidra').is_dir()):
            return
        vus.add(cle)
        trouvees.append({'chemin': cle, 'origine': origine})

    for nom in ENVIRONNEMENTS_GHIDRA:
        proposer(os.environ.get(nom), 'variable %s' % nom)
    executable = shutil.which('ghidraRun') or shutil.which('ghidra')
    if executable:
        try:
            reel = Path(executable).resolve()
            proposer(reel.parent, 'commande %s' % Path(executable).name)
            if reel.parent.name == 'support':
                proposer(reel.parent.parent, 'commande %s'
                         % Path(executable).name)
        except OSError:
            pass
    for chemin in CHEMINS_GHIDRA:
        proposer(chemin, 'chemin standard')
    for motif in GLOBES_GHIDRA:
        try:
            for correspondance in sorted(Path('/').glob(motif.lstrip('/')),
                                         key=lambda p: p.name, reverse=True):
                proposer(correspondance, 'recherche %s' % motif)
        except OSError:
            continue
    for dossier in (Path.home(), Path('/opt'), Path('/usr/local')):
        try:
            for correspondance in sorted(dossier.glob('ghidra*'),
                                         key=lambda p: p.name, reverse=True):
                proposer(correspondance, 'dossier personnel ou local')
        except OSError:
            continue
    # Un réglage enregistré par l'utilisateur dans le panneau prime tout : c'est
    # lui qui sait où il a décompressé l'archive.
    try:
        reglage = dossier_etat() / 'ghidra.json'
        if reglage.is_file():
            donnees = json.loads(reglage.read_text('utf8', 'replace'))
            if isinstance(donnees, dict):
                proposer(donnees.get('chemin'), 'réglage enregistré')
                if donnees.get('chemin'):
                    trouvees.insert(0, trouvees.pop())
    except (OSError, ValueError):
        pass
    return trouvees


def etat_ghidra(installation=None):
    """L'état complet de Ghidra : présent, version, langage de script, JDK, venv.

    Chaque champ absent est accompagné d'une raison et d'une commande, jamais
    d'un simple `False` : le panneau doit pouvoir afficher autre chose que
    « indisponible ».
    """
    trouvees = chercher_ghidra()
    if installation:
        try:
            choisie = Path(os.path.expanduser(str(installation))).resolve()
        except (OSError, ValueError):
            choisie = None
        if choisie is None or not choisie.is_dir():
            return {'present': False, 'chemin': '', 'raison':
                    'Le chemin indiqué « %s » n’est pas un dossier existant.'
                    % installation, 'installations': trouvees,
                    'installations_commandes': INSTALLATIONS}
        trouvees = [{'chemin': str(choisie), 'origine': 'choix explicite'}] + trouvees
    if not trouvees:
        return {'present': False, 'chemin': '',
                'raison': 'Aucune installation de Ghidra trouvée. Pascal Studio '
                          'ne la fournit pas : elle pèse environ 570 Mo et '
                          'exige un JDK 21 ou plus.',
                'installations': [],
                'installations_commandes': INSTALLATIONS,
                'recherche_dans': list(ENVIRONNEMENTS_GHIDRA)
                + list(CHEMINS_GHIDRA)}
    premiere = trouvees[0]
    racine = Path(premiere['chemin'])
    etat = {'present': True, 'chemin': str(racine),
            'origine': premiere['origine'], 'autres': trouvees[1:],
            'installations_commandes': INSTALLATIONS,
            'lanceur': str(racine / 'ghidraRun')
            if (racine / 'ghidraRun').is_file() else ''}
    version = lire_version_ghidra(racine)
    if version:
        etat['version'] = version['version']
        etat['publication'] = version.get('publication', '')
        etat['version_source'] = version['source']
        etat['majeure'], etat['mineure'] = _paire_version(version['version'])
        etat['langage'] = langage_de_script(version['version'])
        etat['jdk_requis'] = jdk_requis(version['version'])
    else:
        etat['version'] = ''
        etat['langage'] = 'inconnu'
        etat['jdk_requis'] = 21
        etat['raison_version'] = (
            'Le dossier « %s » ne contient pas Ghidra/application.properties : '
            'la version n’a pas pu être lue, donc le langage de script '
            '(PyGhidra pour 12.x, Jython pour 11.x) n’a pas pu être choisi. '
            'Vérifiez qu’il s’agit bien de la racine d’une installation.'
            % racine)
    if etat['langage'] == 'jython':
        etat['avertissement_langage'] = (
            'Cette version de Ghidra utilise Jython, donc Python 2.7 : les '
            'postScripts Python 3 que Pascal Studio écrit pour Ghidra 12 ne '
            'fonctionneront pas tels quels. Les opérations demandant un script '
            '(décompilation, xrefs, recherche) seront refusées avec cette '
            'explication plutôt que d’échouer obscurément.')
    # --- JDK -----------------------------------------------------------------
    jdk = etat_jdk()
    etat['jdk'] = jdk
    requis = etat.get('jdk_requis') or 21
    if not jdk['present']:
        etat['jdk_manquant'] = (
            'Aucun JDK utilisable n’a été trouvé. Ghidra %s exige un JDK %d ou '
            'plus : sans lui, Ghidra ne démarre pas du tout. Commande : '
            'sudo apt install openjdk-%d-jdk'
            % (etat.get('version') or '(version inconnue)', requis, requis))
    elif jdk['majeure'] < requis:
        etat['jdk_insuffisant'] = (
            'Le JDK trouvé est la version %s, et Ghidra %s exige %d ou plus. '
            'Commande : sudo apt install openjdk-%d-jdk'
            % (jdk['version'], etat.get('version') or '(version inconnue)',
               requis, requis))
    # --- PyGhidra ------------------------------------------------------------
    roue = _roue_pyghidra(racine)
    etat['roue_pyghidra'] = roue
    if etat.get('langage') == 'pyghidra' and not roue:
        etat['roue_manquante'] = (
            'Ghidra 12 scripte par PyGhidra, mais la roue attendue dans '
            'Ghidra/Features/PyGhidra/pypkg/dist/ est absente : l’installation '
            'est incomplète, ou il s’agit d’une version intermédiaire. Sans '
            'elle, le venv ne peut pas être créé hors ligne.')
    etat['venv'] = etat_venv()
    etat['pret'] = bool(
        etat.get('version') and etat.get('langage') != 'inconnu'
        and jdk['present'] and jdk['majeure'] >= requis
        and (etat['langage'] == 'jython' or roue))
    if not etat['pret']:
        manquants = []
        if not etat.get('version'):
            manquants.append('la version de Ghidra')
        if not jdk['present'] or jdk['majeure'] < requis:
            manquants.append('un JDK %d ou plus' % requis)
        if etat.get('langage') == 'pyghidra' and not roue:
            manquants.append('la roue PyGhidra')
        if manquants:
            etat['manques'] = manquants
    return etat


def etat_jdk():
    """Le JDK trouvé : version, chemin, et s'il est utilisable.

    Deux sources : JAVA_HOME, puis `java` dans le PATH. La sortie est fusionnée
    parce que `java -version` écrit sur stderr.
    """
    candidats = []
    home = os.environ.get('JAVA_HOME')
    if home:
        candidats.append((Path(home) / 'bin' / 'java', 'JAVA_HOME'))
    which = shutil.which('java')
    if which:
        candidats.append((Path(which), 'PATH'))
    for chemin, origine in candidats:
        if not chemin.exists():
            continue
        code, sortie = _executer([str(chemin), '-version'], delai=10)
        if code is None:
            return {'present': False, 'raison': sortie, 'chemin': str(chemin),
                    'origine': origine}
        correspondance = re.search(
            r'version\s+"(\d+)(?:\.(\d+))?(?:\.(\d+))?(?:[._-]([^"]*))?"', sortie)
        if not correspondance:
            return {'present': False, 'chemin': str(chemin), 'origine': origine,
                    'raison': 'La sortie de « java -version » ne contient pas '
                              'de numéro de version lisible : %s'
                              % sortie.strip().split('\n')[0][:160]}
        texte = correspondance.group(1)
        # Java 8 et avant s'écrivaient « 1.8.0_362 » : la majeure réelle est 8.
        if texte == '1' and correspondance.group(2):
            majeure = int(correspondance.group(2))
            version = '%s.%s' % (texte, correspondance.group(2))
        else:
            majeure = int(texte)
            version = texte
            if correspondance.group(2):
                version += '.' + correspondance.group(2)
        return {'present': True, 'chemin': str(chemin), 'origine': origine,
                'version': version, 'majeure': majeure,
                'sortie': sortie.strip().split('\n')[0][:200],
                'javac': bool(shutil.which('javac'))}
    return {'present': False,
            'raison': 'Aucune commande `java` dans le PATH et JAVA_HOME n’est '
                      'pas défini.'}


def etat_venv():
    """Le venv PyGhidra que Pascal Studio crée et réutilise.

    Il est dans le dossier d'état, jamais dans le projet : il pèse plusieurs
    dizaines de Mo et ne doit pas être recopié ni indexé avec le projet de
    l'utilisateur.
    """
    racine = dossier_etat() / 'venv-pyghidra'
    python = racine / 'bin' / 'python3'
    etat = {'chemin': str(racine), 'present': racine.is_dir(),
            'python': str(python) if python.is_file() else '',
            'pyghidra': False}
    if not python.is_file():
        etat['raison'] = ('Le venv PyGhidra n’a pas encore été créé. Il se crée '
                          'depuis la roue livrée dans Ghidra, sans accès '
                          'réseau.')
        return etat
    code, sortie = _executer([str(python), '-c', 'import pyghidra; '
                              'print(pyghidra.__version__)'], delai=30)
    if code == 0 and sortie.strip():
        etat['pyghidra'] = True
        etat['version'] = sortie.strip().split('\n')[-1][:40]
    else:
        etat['raison'] = ('Le venv existe mais pyghidra n’y est pas importable '
                          '(%s). Le recréer suffit : supprimez %s puis relancez '
                          'une analyse.' % (sortie.strip().split('\n')[-1][:160],
                                            racine))
    return etat


def etat_outils(rafraichir=False):
    """Les outils de la chaîne, avec leur version quand elle est lisible."""
    if not rafraichir and _cache['quoi'] == 'outils' and \
            (time.monotonic() - _cache['quand']) < CACHE_SECONDES:
        return _cache['valeur']
    sortie = []
    for nom, commande, role, indispensable in OUTILS:
        chemin = shutil.which(commande)
        entree = {'nom': nom, 'commande': commande, 'role': role,
                  'present': bool(chemin), 'chemin': chemin or '',
                  'indispensable': indispensable}
        if chemin and nom in ('objdump', 'readelf', 'nm', 'file', 'gdb',
                              'radare2', 'rizin', 'nasm', 'gcc', 'as', 'ld'):
            code, texte = _executer([chemin, '--version'], delai=8)
            if code is not None and texte.strip():
                entree['version'] = texte.strip().split('\n')[0][:120]
        if not chemin:
            entree['installation'] = ('sudo apt install %s' % _paquet_de(nom))
        sortie.append(entree)
    _cache.update({'quoi': 'outils', 'quand': time.monotonic(), 'valeur': sortie})
    return sortie


PAQUETS = {
    'objdump': 'binutils', 'readelf': 'binutils', 'nm': 'binutils',
    'as': 'binutils', 'ld': 'binutils', 'c++filt': 'binutils',
    'strings': 'binutils', 'file': 'file', 'od': 'coreutils',
    'gcc': 'gcc', 'gdb': 'gdb', 'radare2': 'radare2', 'rizin': 'rizin',
    'nasm': 'nasm', 'java': 'openjdk-21-jdk',
}


def _paquet_de(nom):
    return PAQUETS.get(nom, nom)


def etat_bibliotheques():
    """Les bibliothèques Python utiles, détectées SANS les importer.

    `importlib.util.find_spec` ne charge pas le module : importer capstone ou
    lief pour savoir s'ils existent coûterait plusieurs centaines de
    millisecondes et pourrait lever sur une installation cassée.
    """
    sortie = []
    for nom, module, role in BIBLIOTHEQUES:
        try:
            present = importlib.util.find_spec(module) is not None
        except (ImportError, ValueError):
            present = False
        sortie.append({'nom': nom, 'module': module, 'role': role,
                       'presente': present,
                       'installation': 'pip install %s' % nom})
    return sortie


def etat_cache():
    """Le cache des projets analysés : ce qui existe, et ce que ça pèse."""
    racine = dossier_etat() / 'projets'
    projets = []
    octets = 0
    try:
        if racine.is_dir():
            for entree in sorted(racine.iterdir()):
                if not entree.is_dir():
                    continue
                taille = 0
                for fichier in entree.rglob('*'):
                    try:
                        if fichier.is_file():
                            taille += fichier.stat().st_size
                    except OSError:
                        continue
                octets += taille
                projets.append({'nom': entree.name, 'chemin': str(entree),
                                'octets': taille})
    except OSError as exc:
        return {'chemin': str(racine), 'projets': [], 'octets': 0,
                'raison': 'Lecture impossible : %s' % (exc.strerror or exc)}
    return {'chemin': str(racine), 'projets': projets, 'octets': octets}


def capacites(rafraichir=False, installation=None):
    """Tout ce que le panneau doit savoir pour s'afficher, en une réponse."""
    ghidra = etat_ghidra(installation)
    outils = etat_outils(rafraichir)
    bibliotheques = etat_bibliotheques()
    disponibles = [o['nom'] for o in outils if o['present']]
    absents = [o['nom'] for o in outils if not o['present']]
    manquants = []
    if not ghidra['present']:
        manquants.append({
            'quoi': 'Ghidra', 'pourquoi': ghidra['raison'],
            'voies': [i for i in INSTALLATIONS if i['id'] != 'jdk']})
    else:
        for champ in ('jdk_manquant', 'jdk_insuffisant'):
            if champ in ghidra:
                manquants.append({'quoi': 'JDK', 'pourquoi': ghidra[champ],
                                  'voies': [i for i in INSTALLATIONS
                                            if i['id'] == 'jdk']})
        if 'roue_manquante' in ghidra:
            manquants.append({'quoi': 'PyGhidra',
                              'pourquoi': ghidra['roue_manquante'], 'voies': []})
        # Le venv est ce qui manque le plus souvent : Ghidra et le JDK peuvent
        # être installés sans que le pont Python le soit. Le nommer évite que le
        # panneau dise « Ghidra prêt » alors qu’aucune analyse scriptée ne peut
        # aboutir.
        if (ghidra.get('langage') == 'pyghidra' and ghidra.get('roue_pyghidra')
                and not ghidra.get('venv', {}).get('pyghidra')):
            manquants.append({
                'quoi': 'Le venv PyGhidra',
                'pourquoi': ghidra['venv'].get(
                    'raison',
                    'Le venv PyGhidra n’a pas encore été créé : sans lui, aucun '
                    'postScript ne peut s’exécuter dans Ghidra 12.')
                + ' Il se crée depuis la roue livrée dans Ghidra, sans accès '
                  'réseau, à condition que JPype soit installé '
                  '(sudo apt install python3-jpype).',
                'voies': [i for i in INSTALLATIONS if i['id'] == 'pyghidra']})
        if 'raison_version' in ghidra:
            manquants.append({'quoi': 'Version de Ghidra',
                              'pourquoi': ghidra['raison_version'], 'voies': []})
    if not any(o['nom'] == 'objdump' and o['present'] for o in outils):
        manquants.append({
            'quoi': 'binutils',
            'pourquoi': 'Sans objdump ni readelf, le désassemblage et la '
                        'lecture détaillée des ELF ne sont pas possibles : il '
                        'ne reste que la lecture Python des en-têtes, des '
                        'symboles et des chaînes.',
            'voies': [i for i in INSTALLATIONS if i['id'] == 'binutils']})
    return {
        'ok': True, 'version': VERSION,
        'ghidra': ghidra,
        'outils': outils,
        'outils_disponibles': disponibles,
        'outils_absents': absents,
        'bibliotheques': bibliotheques,
        'manquants': manquants,
        'dossier_etat': str(dossier_etat()),
        'cache': etat_cache(),
        # Ce que le panneau peut faire SANS Ghidra. C'est la réponse à
        # l'exigence « le panneau doit rester pleinement utile » : la liste est
        # rendue explicite pour que l'interface puisse l'afficher au lieu de
        # laisser l'utilisateur deviner ce qui marche.
        'sans_ghidra': [
            'En-têtes et tables des sections, segments et symboles (ELF, PE, '
            'Mach-O) lus en Python pur.',
            'Chaînes imprimables avec leur position et leur encodage.',
            'Entropie par section : une section compressée ou chiffrée se voit '
            'avant même de désassembler.',
            'Empreintes SHA-256, MD5 et tailles, pour identifier un échantillon.',
            'Désassemblage et vidage via objdump quand binutils est installé.',
            'Symboles et imports via readelf et nm, dé-manglés par c++filt.',
            'Détection de compilateur, d’empaqueteur et de liaison statique.',
        ],
        'avec_ghidra': [
            'Analyse automatique complète, mise en cache dans un projet.',
            'Décompilation en C d’une fonction.',
            'Désassemblage enrichi (types, noms, commentaires de Ghidra).',
            'Références croisées : qui appelle, qui lit cette adresse.',
            'Recherche de motifs d’octets et de chaînes dans tout le binaire.',
            'Graphes d’appel et liste des fonctions détectées.',
        ] if ghidra.get('pret') else [],
    }


def enregistrer_chemin(chemin):
    """Mémorise un chemin vers Ghidra choisi par l'utilisateur.

    Un réglage explicite prime toute détection : c'est l'utilisateur qui sait où
    il a décompressé l'archive, et une détection automatique peut trouver une
    autre installation que celle qu'il veut utiliser.
    """
    if not chemin:
        try:
            (dossier_etat() / 'ghidra.json').unlink()
        except OSError:
            pass
        return {'ok': True, 'chemin': '', 'message': 'Réglage effacé.'}
    cible = Path(os.path.expanduser(str(chemin)))
    if not cible.is_dir():
        return {'ok': False,
                'erreur': 'Le chemin « %s » n’est pas un dossier existant. Rien '
                          'n’a été enregistré.' % chemin}
    if not ((cible / 'ghidraRun').is_file() or (cible / 'Ghidra').is_dir()):
        return {'ok': False,
                'erreur': 'Le dossier « %s » ne ressemble pas à une '
                          'installation de Ghidra : ni ghidraRun ni le dossier '
                          'Ghidra ne s’y trouve. Indiquez la RACINE de '
                          'l’installation.' % cible}
    try:
        racine = dossier_etat()
        racine.mkdir(parents=True, exist_ok=True)
        fichier = racine / 'ghidra.json'
        fichier.write_text(json.dumps({'chemin': str(cible.resolve()),
                                       'enregistre': time.time()},
                                      ensure_ascii=False, indent=1), 'utf8')
        os.chmod(fichier, 0o600)
    except OSError as exc:
        return {'ok': False,
                'erreur': 'Enregistrement impossible : %s' % (exc.strerror or exc)}
    _cache.clear()
    _cache.update({'quoi': None, 'quand': 0.0, 'valeur': None})
    etat = etat_ghidra()
    return {'ok': True, 'chemin': str(cible.resolve()),
            'message': 'Ghidra %s enregistré.' % (etat.get('version')
                                                  or '(version illisible)'),
            'ghidra': etat}


def oublier_cache(quoi='projets'):
    """Supprime le cache : les projets analysés, ou tout le dossier d'état."""
    racine = dossier_etat()
    cibles = {'projets': racine / 'projets', 'venv': racine / 'venv-pyghidra',
              'tout': racine}
    if quoi not in cibles:
        return {'ok': False, 'erreur': 'Cible inconnue : %s. Les cibles sont %s.'
                % (quoi, ', '.join(sorted(cibles)))}
    cible = cibles[quoi]
    if not cible.exists():
        return {'ok': True, 'supprime': 0,
                'message': 'Rien à supprimer : %s n’existe pas.' % cible}
    compte = sum(1 for f in cible.rglob('*') if f.is_file())
    try:
        shutil.rmtree(cible)
    except OSError as exc:
        return {'ok': False,
                'erreur': 'Suppression impossible : %s' % (exc.strerror or exc)}
    return {'ok': True, 'supprime': compte,
            'message': '%d fichier(s) supprimé(s) dans %s.' % (compte, cible)}


def verifier():
    """Contrôle interne : il porte sur ce qui est vérifiable SANS Ghidra.

    Ghidra ne peut pas être installé dans un banc (570 Mo, un JDK 21). Mais une
    installation PEUT être imitée : un dossier avec ghidraRun et
    Ghidra/application.properties suffit à ce que la détection se prononce. C'est
    ce qui permet de vérifier le seul comportement qui compte vraiment — que la
    version lue décide du langage de script, et qu'un JDK trop ancien soit dit
    insuffisant plutôt qu'accepté.
    """
    import tempfile

    problemes = []

    def verif(condition, message):
        if not condition:
            problemes.append(message)

    verif(_paire_version('11.3.1') == (11, 3), 'version 11.3.1 mal découpée')
    verif(_paire_version('12.0') == (12, 0), 'version 12.0 mal découpée')
    verif(_paire_version('9.2.2') == (9, 2), 'version 9.2.2 mal découpée')
    verif(_paire_version('') == (0, 0), 'une version vide doit valoir (0, 0)')
    verif(_paire_version(None) == (0, 0), 'une version absente doit valoir (0, 0)')
    # La comparaison qui décide du langage de script : lexicographiquement,
    # « 9.2.2 » > « 12.0 ». Si le découpage était faux, Ghidra 9 serait traité
    # comme un Ghidra 12 et recevrait un postScript PyGhidra inutilisable.
    verif(_paire_version('9.2.2') < _paire_version('12.0'),
          '9.2.2 doit être inférieur à 12.0 en comparaison numérique')
    verif(langage_de_script('11.3.1') == 'jython',
          'Ghidra 11.3.1 doit donner Jython')
    verif(langage_de_script('12.0.1') == 'pyghidra',
          'Ghidra 12.0.1 doit donner PyGhidra')
    verif(langage_de_script('10.4') == 'jython', 'Ghidra 10.4 doit donner Jython')
    verif(langage_de_script('') == 'inconnu',
          'une version illisible ne doit pas choisir un langage')
    verif(jdk_requis('12.0') == 21, 'Ghidra 12 exige le JDK 21')
    verif(jdk_requis('11.3.1') == 21, 'Ghidra 11.3 exige le JDK 21')
    verif(jdk_requis('11.0.2') == 17, 'Ghidra 11.0 exige le JDK 17')
    verif(jdk_requis('9.2') == 11, 'Ghidra 9.2 exige le JDK 11')

    dossier = tempfile.mkdtemp(prefix='ps-retro-detect-')
    try:
        # --- une installation IMITÉE, sans Ghidra réel ----------------------
        fausse = Path(dossier) / 'ghidra_12.0.1_PUBLIC'
        (fausse / 'Ghidra').mkdir(parents=True)
        (fausse / 'ghidraRun').write_text('#!/bin/sh\nexit 0\n', 'utf8')
        (fausse / 'Ghidra' / 'application.properties').write_text(
            'application.java.min=21\napplication.version=12.0.1\n'
            'application.release.name=PUBLIC\n', 'utf8')
        roue = (fausse / 'Ghidra' / 'Features' / 'PyGhidra' / 'pypkg' / 'dist')
        roue.mkdir(parents=True)
        (roue / 'pyghidra-12.0.1-py3-none-any.whl').write_bytes(b'PK\x03\x04')

        version = lire_version_ghidra(fausse)
        verif(version and version['version'] == '12.0.1'
              and version['publication'] == 'PUBLIC',
              'la version n’est pas lue dans application.properties (%r)' % version)
        verif(lire_version_ghidra(Path(dossier)) is None,
              'un dossier quelconque ne doit pas être pris pour une version')

        ancien = os.environ.get('PS_GHIDRA_DIR')
        os.environ['PS_GHIDRA_DIR'] = str(fausse)
        try:
            trouvees = chercher_ghidra()
            verif(trouvees and trouvees[0]['chemin'] == str(fausse.resolve()),
                  'la variable d’environnement doit primer (%r)' % trouvees[:1])
            verif('variable PS_GHIDRA_DIR' in trouvees[0]['origine'],
                  'l’origine de la détection doit être dite (%r)'
                  % trouvees[0]['origine'])
            etat = etat_ghidra()
            verif(etat['present'] and etat['version'] == '12.0.1',
                  'l’état ne reprend pas la version (%r)' % etat.get('version'))
            verif(etat['langage'] == 'pyghidra',
                  'Ghidra 12 doit être détecté comme PyGhidra (%r)'
                  % etat.get('langage'))
            verif(etat['roue_pyghidra'].endswith('.whl'),
                  'la roue PyGhidra livrée doit être trouvée (%r)'
                  % etat.get('roue_pyghidra'))
            verif(etat['jdk_requis'] == 21, 'le JDK requis doit être 21')
            jdk = etat['jdk']
            if jdk['present'] and jdk['majeure'] < 21:
                verif('jdk_insuffisant' in etat and not etat['pret'],
                      'un JDK trop ancien doit être dit INSUFFISANT et rendre le '
                      'pont non prêt (%r)' % jdk.get('version'))
                verif('sudo apt install openjdk-21-jdk' in etat['jdk_insuffisant'],
                      'le message doit donner la commande d’installation')
            elif not jdk['present']:
                verif('jdk_manquant' in etat and not etat['pret'],
                      'un JDK absent doit être dit MANQUANT')
            else:
                verif(etat['pret'], 'avec un JDK suffisant et la roue, le pont '
                                    'doit être prêt')
        finally:
            if ancien is None:
                os.environ.pop('PS_GHIDRA_DIR', None)
            else:
                os.environ['PS_GHIDRA_DIR'] = ancien

        # --- une installation sans version ----------------------------------
        muette = Path(dossier) / 'ghidra-muette'
        muette.mkdir()
        (muette / 'ghidraRun').write_text('#!/bin/sh\n', 'utf8')
        etat = etat_ghidra(muette)
        verif(etat['present'] and etat['langage'] == 'inconnu',
              'une installation sans version doit rendre « inconnu », pas un '
              'langage deviné (%r)' % etat.get('langage'))
        verif('raison_version' in etat and not etat['pret'],
              'l’absence de version doit être expliquée et rendre le pont non prêt')

        # --- une installation en Jython -------------------------------------
        onze = Path(dossier) / 'ghidra_11.3.1_PUBLIC'
        (onze / 'Ghidra').mkdir(parents=True)
        (onze / 'ghidraRun').write_text('#!/bin/sh\n', 'utf8')
        (onze / 'Ghidra' / 'application.properties').write_text(
            'application.version=11.3.1\n', 'utf8')
        etat = etat_ghidra(onze)
        verif(etat['langage'] == 'jython',
              'Ghidra 11.3.1 doit être détecté comme Jython')
        verif('avertissement_langage' in etat
              and 'Python 2.7' in etat['avertissement_langage'],
              'Jython doit être signalé comme limitant à Python 2.7')

        # --- un dossier qui n'est pas Ghidra --------------------------------
        quelconque = Path(dossier) / 'projet'
        quelconque.mkdir()
        (quelconque / 'main.c').write_text('int main(){return 0;}\n', 'utf8')
        refus = etat_ghidra(quelconque)
        verif(refus.get('langage') == 'inconnu' and not refus.get('pret'),
              'un dossier quelconque choisi explicitement ne doit pas recevoir '
              'un langage de script deviné (%r)' % refus.get('langage'))
        verif('application.properties' in refus.get('raison_version', ''),
              'le dossier non-Ghidra doit être expliqué, pas seulement marqué '
              'inconnu')
        verif(not enregistrer_chemin(quelconque)['ok'],
              'enregistrer un dossier qui n’est pas Ghidra doit être refusé')
        verif(chercher_ghidra() == chercher_ghidra(),
              'deux détections successives doivent être stables')
    finally:
        shutil.rmtree(dossier, ignore_errors=True)

    # --- ce qui est vérifiable sur la machine réelle -------------------------
    outils = etat_outils(rafraichir=True)
    verif(len(outils) == len(OUTILS),
          'la liste des outils est incomplète (%d sur %d)'
          % (len(outils), len(OUTILS)))
    for outil in outils:
        if outil['present']:
            verif(bool(outil['chemin']),
                  'l’outil %s est dit présent sans chemin' % outil['nom'])
        else:
            verif('installation' in outil and outil['installation'].startswith('sudo'),
                  'un outil absent doit donner sa commande d’installation (%s)'
                  % outil['nom'])
    verif(any(o['nom'] == 'od' and o['indispensable'] for o in outils),
          'od doit être marqué indispensable : c’est le seul vidage hexadécimal '
          'toujours présent')
    bibliotheques = etat_bibliotheques()
    verif(len(bibliotheques) == len(BIBLIOTHEQUES),
          'la liste des bibliothèques est incomplète')
    for bibliotheque in bibliotheques:
        verif('role' in bibliotheque and 'installation' in bibliotheque,
              'une bibliothèque sans rôle ni commande d’installation (%s)'
              % bibliotheque['nom'])

    etat = capacites(rafraichir=True)
    verif(etat['ok'] and isinstance(etat['sans_ghidra'], list)
          and len(etat['sans_ghidra']) >= 5,
          'capacites() doit annoncer ce qui marche SANS Ghidra')
    if not etat['ghidra'].get('pret'):
        verif(not etat['avec_ghidra'],
              'les capacités Ghidra ne doivent pas être annoncées quand le pont '
              'n’est pas prêt')
        verif(bool(etat['manquants']),
              'un Ghidra non prêt doit lister ce qui manque')
        for manquant in etat['manquants']:
            verif(manquant['pourquoi'] and len(manquant['pourquoi']) > 30,
                  'ce qui manque doit être EXPLIQUÉ, pas seulement nommé (%r)'
                  % manquant['quoi'])
    verif(len(INSTALLATIONS) >= 5,
          'les voies d’installation doivent couvrir le dépôt tiers, Kali, le zip '
          'amont, le JDK et le pont PyGhidra')
    voies = [i['id'] for i in INSTALLATIONS]
    for attendu in ('apt-tiers', 'kali', 'zip-amont', 'jdk', 'pyghidra'):
        verif(attendu in voies, 'la voie d’installation « %s » est absente'
              % attendu)
    for voie in INSTALLATIONS:
        verif(voie['commandes'] and all(c.strip() for c in voie['commandes']),
              'la voie « %s » n’a pas de commandes' % voie['nom'])
    pyghidra = next((i for i in INSTALLATIONS if i['id'] == 'pyghidra'), None)
    verif(pyghidra is not None, 'la voie d’installation « pyghidra » est absente')
    texte_pyghidra = ' '.join((pyghidra or {}).get('commandes', ()))
    verif('--system-site-packages' in texte_pyghidra,
          'le venv PyGhidra DOIT voir les paquets système : c’est là que se '
          'trouve JPype, installé par apt et non par la roue de Ghidra')
    verif('python3-jpype' in texte_pyghidra,
          'la voie PyGhidra doit nommer le paquet Debian qui fournit JPype')
    verif('--no-index' in texte_pyghidra,
          'l’installation de la roue PyGhidra doit se faire sans réseau, donc '
          'avec --no-index')
    verif('pyghidra-*.whl' in texte_pyghidra,
          'la commande doit viser la roue livrée dans Ghidra, pas un '
          'téléchargement')

    jdk = etat_jdk()
    verif(isinstance(jdk, dict) and 'present' in jdk,
          'etat_jdk() doit toujours rendre un état, jamais lever')
    if jdk['present']:
        verif(jdk['majeure'] >= 1, 'une version de JDK lue doit être un entier')

    refus = enregistrer_chemin('/chemin/qui/n/existe/pas')
    verif(not refus['ok'] and 'existant' in refus['erreur'],
          'un chemin inexistant doit être refusé sans rien enregistrer')
    refus = enregistrer_chemin('/tmp')
    verif(not refus['ok'] and 'ghidraRun' in refus['erreur'],
          'un dossier qui n’est pas Ghidra doit être refusé en disant pourquoi')
    verif(not oublier_cache('inconnu')['ok'],
          'une cible de cache inconnue doit être refusée')

    return problemes


if __name__ == '__main__':
    import sys

    soucis = verifier()
    if soucis:
        for souci in soucis:
            print('ÉCHEC :', souci)
        sys.exit(1)
    etat = capacites(rafraichir=True)
    ghidra = etat['ghidra']
    print('retro_detection : Ghidra %s%s ; %d outil(s) présent(s) sur %d ; '
          '%d bibliothèque(s) Python ; autocontrôle OK.'
          % ('présent ' + ghidra['version'] if ghidra['present'] else 'absent',
             '' if ghidra.get('pret', True) else ' (pont non prêt)',
             len(etat['outils_disponibles']), len(etat['outils']),
             sum(1 for b in etat['bibliotheques'] if b['presente'])))
