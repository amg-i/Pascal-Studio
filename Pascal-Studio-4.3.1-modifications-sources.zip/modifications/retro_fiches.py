#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
retro_fiches.py — fiches et widgets de rétro-ingénierie (Pascal Studio 4.0.0).

Répond à la demande R6 : « ghidra et des widgets/fisgtes qui peuvent etre
utiles ».

Deux moitiés, et une règle commune : RIEN N'EST AFFIRMÉ SANS ÊTRE VÉRIFIÉ.

  * Les FICHES sont de la documentation. Une fiche de rétro-ingénierie qui donne
    une taille d'en-tête fausse fait perdre des heures à celui qui la lit, et il
    n'a aucun moyen de s'en apercevoir — c'est pire que pas de fiche. Chaque
    fiche porte donc des `faits` : des affirmations chiffrées que verifier()
    recalcule ou recoupe avec readelf, objdump et les lecteurs de
    retro_binaires. Une fiche dont un fait est faux ARRÊTE l'autocontrôle.

  * Les WIDGETS sont des calculateurs. Ils ne sont pas décoratifs : chacun
    existe aussi côté Python, avec un résultat testé, pour que le panneau
    n'affiche jamais un calcul que personne n'a exécuté. Chaque widget porte un
    `exemple` qui est EXECUTÉ pendant l'autocontrôle et dont la sortie est
    comparée à celle qui est documentée.

Trois honnêtetés imposées, reprises des modules précédents :

  1. Un widget ne lève JAMAIS. Une entrée absurde rend un refus qui nomme le
     champ fautif : une levée traverserait la route HTTP comme une panne du
     serveur alors que c'est une saisie incorrecte.
  2. Une liste peut être en retard sur la réalité. Ce qu'une table ne reconnaît
     pas est rendu comme « inconnu (valeur) », jamais comme une erreur, et le
     widget le dit dans `notes`.
  3. Ce module ne recopie PAS les tables de retro_binaires.py ni d'assembleur.py
     : il les cite. Une recopie divergerait silencieusement à la première
     évolution de la table d'origine, et la fiche deviendrait fausse sans que
     rien ne casse.

    python3 retro_fiches.py        autocontrôle, code de retour non nul si échec
"""

import base64
import binascii
import hashlib
import math
import os
import re
import shutil
from pathlib import Path
import struct
import sys
import time

VERSION = '4.0.0'

# Les tables de retro_binaires sont la source vraie. Si le module est absent,
# les widgets qui en dépendent le disent au lieu d'inventer une table.
try:
    import retro_binaires
except Exception:                                            # pragma: no cover
    retro_binaires = None

try:
    import retro_detection
except Exception:                                            # pragma: no cover
    retro_detection = None

try:
    import retro_ghidra
except Exception:                                            # pragma: no cover
    # retro_ghidra n'est nécessaire à aucun widget : seules quelques fiches
    # citent ses constantes. Son absence doit rendre ces faits faux, pas faire
    # échouer l'import du module.
    retro_ghidra = None


# =============================================================================
#  Entrées : lecture tolérante, jamais de levée
# =============================================================================

def _texte(valeur, defaut=''):
    if valeur is None:
        return defaut
    if isinstance(valeur, (bytes, bytearray)):
        return bytes(valeur).decode('utf8', 'replace')
    return str(valeur)


def _entier(valeur, defaut=None):
    """Un entier depuis 42, '42', '0x2a', '042' ou ' 42 '. Rien ne lève."""
    if isinstance(valeur, bool):
        return int(valeur)
    if isinstance(valeur, int):
        return valeur
    texte = _texte(valeur).strip().replace('_', '').replace(' ', '')
    if not texte:
        return defaut
    negatif = texte.startswith('-')
    if negatif:
        texte = texte[1:]
    try:
        if texte[:2].lower() in ('0x',):
            nombre = int(texte[2:], 16)
        elif texte[:2].lower() in ('0b',):
            nombre = int(texte[2:], 2)
        elif texte[:2].lower() in ('0o',):
            nombre = int(texte[2:], 8)
        elif texte.startswith('0') and len(texte) > 1 and texte.isdigit():
            # « 0755 » est un mode octal en pratique courante, mais le deviner
            # serait dangereux : on le lit en DÉCIMAL et on le dit.
            nombre = int(texte, 10)
        else:
            nombre = int(texte, 10)
    except ValueError:
        return defaut
    return -nombre if negatif else nombre


def _octets(valeur):
    """Des octets depuis du texte, de l'hexadécimal ou une liste d'entiers.

    Le rendu dit TOUJOURS quelle interprétation a été retenue : confondre « AB »
    (deux caractères) et AB (un octet) est l'erreur la plus coûteuse de toute la
    rétro-ingénierie, et elle est invisible dans le résultat.
    """
    if valeur is None:
        return b'', 'vide', []
    notes = []
    if isinstance(valeur, (bytes, bytearray)):
        return bytes(valeur), 'octets', notes
    if isinstance(valeur, int):
        return bytes([valeur & 0xff]), 'octet', notes
    if isinstance(valeur, (list, tuple)):
        sortie = bytearray()
        for element in valeur:
            nombre = _entier(element)
            if nombre is None or not 0 <= nombre <= 255:
                return b'', 'invalide', [
                    'un élément de la liste n’est pas un octet (0 à 255) : %r'
                    % (element,)]
            sortie.append(nombre)
        return bytes(sortie), 'liste d’octets', notes
    texte = _texte(valeur)
    if not texte:
        return b'', 'vide', notes
    marqueur = texte.strip().lower()
    if marqueur.startswith(('hex:', '0x', 'h:')):
        marqueur = re.sub(r'^(hex:|0x|h:)', '', marqueur, flags=re.I)
        return _hexa(marqueur, notes)
    if marqueur.startswith(('b64:', 'base64:')):
        marqueur = re.sub(r'^(b64:|base64:)', '', texte.strip(), flags=re.I)
        try:
            return base64.b64decode(marqueur, validate=True), 'base64', notes
        except (binascii.Error, ValueError) as exc:
            return b'', 'invalide', ['le préfixe b64: annonce du base64, mais '
                                     'le décodage échoue : %s' % exc]
    # Sans préfixe : du hexadécimal si TOUT est hexadécimal et séparé par des
    # espaces, sinon du texte. Cette décision est annoncée.
    compacte = re.sub(r'[\s:,-]+', '', texte)
    if compacte and len(compacte) % 2 == 0 \
            and re.fullmatch(r'[0-9a-fA-F]+', compacte) \
            and re.search(r'\s|:', texte):
        return _hexa(texte, notes)
    notes.append('entrée lue comme du TEXTE. Pour des octets hexadécimaux, '
                 'séparez-les par des espaces ou préfixez par « hex: » ; pour '
                 'du base64, préfixez par « b64: ».')
    return texte.encode('utf8'), 'texte', notes


def _hexa(texte, notes=None):
    notes = notes if notes is not None else []
    compacte = re.sub(r'[\s:,-]+', '', _texte(texte))
    if not compacte:
        return b'', 'vide', notes
    if len(compacte) % 2:
        return b'', 'invalide', [
            'le nombre de chiffres hexadécimaux est impair (%d) : un octet '
            's’écrit deux chiffres. Entrée : %r' % (len(compacte), texte)]
    try:
        return binascii.unhexlify(compacte), 'hexadécimal', notes
    except (binascii.Error, ValueError) as exc:
        return b'', 'invalide', ['hexadécimal invalide : %s' % exc]


def _refus(champ, raison):
    return {'ok': False, 'erreur': '%s : %s' % (champ, raison),
            'resultat': None, 'notes': []}


# =============================================================================
#  WIDGETS — spécifications
# =============================================================================
# Chaque widget déclare ses entrées (le panneau construit le formulaire à
# partir de cette table) et un exemple EXÉCUTÉ par verifier().

WIDGETS = {
    'convertisseur': {
        'nom': 'Convertisseur de bases',
        'resume': 'Un nombre en binaire, octal, décimal et hexadécimal, avec '
                  'l’échange de boutisme sur 1, 2, 4 ou 8 octets.',
        'entrees': [
            {'nom': 'valeur', 'type': 'texte', 'defaut': '0x1234',
             'aide': 'Préfixe 0x, 0b, 0o facultatif ; un nombre nu est décimal.'},
            {'nom': 'largeur', 'type': 'nombre', 'defaut': 2,
             'aide': 'Octets pour l’échange de boutisme : 1, 2, 4 ou 8.'},
        ],
        'exemple': {'entrees': {'valeur': '0x1234', 'largeur': 2},
                    'attendu': {'decimal': 4660, 'hexadecimal': '0x1234',
                                'binaire': '0001001000110100', 'octal': '011064',
                                'boutisme_inverse': '0x3412'}},
    },
    'empreintes': {
        'nom': 'Empreintes',
        'resume': 'MD5, SHA-1, SHA-256 et SHA-512 d’un texte ou d’octets. '
                  'Sert à vérifier qu’un binaire n’a pas été modifié.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'Pascal Studio',
             'aide': 'Texte brut, ou octets avec le préfixe hex: ou b64:.'},
        ],
        'exemple': {'entrees': {'donnees': 'abc'},
                    'attendu': {'md5': '900150983cd24fb0d6963f7d28e17f72',
                                'sha1': 'a9993e364706816aba3e25717850c26c9cd0d89d',
                                'sha256': 'ba7816bf8f01cfea414140de5dae2223'
                                          'b00361a396177a9cb410ff61f20015ad'}},
    },
    'entropie': {
        'nom': 'Entropie',
        'resume': 'Entropie de Shannon sur 8 bits. Proche de 0 : données '
                  'constantes. Entre 4 et 6 : code compilé. Au-dessus de 7,2 : '
                  'compressé, chiffré ou empacté.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'hex:00 00 00 00',
             'aide': 'Texte, hex: pour des octets, b64: pour du base64.'},
        ],
        'exemple': {'entrees': {'donnees': 'hex:00 01 02 03'},
                    'attendu': {'entropie': 2.0, 'octets': 4,
                                'interpretation': 'faible'}},
    },
    'hexdump': {
        'nom': 'Vidage hexadécimal',
        'resume': 'Construit un vidage lisible, ou relit un vidage collé depuis '
                  'objdump, xxd ou un outil en ligne.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'hex:48 65 6c 6c 6f',
             'aide': 'Octets à vider, ou vidage à relire.'},
            {'nom': 'adresse', 'type': 'texte', 'defaut': '0',
             'aide': 'Adresse de départ du vidage.'},
            {'nom': 'largeur', 'type': 'nombre', 'defaut': 16,
             'aide': 'Octets par ligne (8, 16 ou 32).'},
        ],
        'exemple': {'entrees': {'donnees': 'hex:48 65 6c 6c 6f', 'adresse': '0',
                                'largeur': 16},
                    'attendu': {'lignes': 1, 'octets': 5,
                                'premiere_ligne':
                                    '00000000  48 65 6c 6c 6f'
                                    '                                   Hello'}},
    },
    'motif': {
        'nom': 'Motif de recherche',
        'resume': 'Construit un motif d’octets avec jokers au format Ghidra '
                  '(« 48 8B ?? 89 »), ou traduit un motif en expression '
                  'rationnelle binaire.',
        'entrees': [
            {'nom': 'motif', 'type': 'texte', 'defaut': '48 8B ?? 89',
             'aide': 'Octets en hexadécimal, ?? ou ? pour un joker.'},
        ],
        'exemple': {'entrees': {'motif': '48 8B ?? 89'},
                    'attendu': {'longueur': 4, 'jokers': 1,
                                'expression': '\\x48\\x8b.\\x89'}},
    },
    'xor': {
        'nom': 'XOR',
        'resume': 'Applique un XOR cyclique. C’est le premier essai sur une '
                  'donnée qui ressemble à du bruit mais n’est pas compressée.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'hex:1d 00 00 04',
             'aide': 'Les octets à déchiffrer.'},
            {'nom': 'cle', 'type': 'texte', 'defaut': 'hex:41',
             'aide': 'Clefs d’un ou plusieurs octets, appliquée en cycle.'},
        ],
        'exemple': {'entrees': {'donnees': 'hex:1d 00 00 04', 'cle': 'hex:41'},
                    'attendu': {'hexadecimal': '5c 41 41 45',
                                'texte': '\\AAE'}},
    },
    'structure': {
        'nom': 'Structure C',
        'resume': 'Calcule la taille et les décalages d’une structure C, avec '
                  'l’alignement, en 32 ou 64 bits et dans les deux boutismes. '
                  'Sert à écrire un format pour struct.unpack.',
        'entrees': [
            {'nom': 'champs', 'type': 'texte',
             'defaut': 'uint32 magic; uint16 version; uint16 count; '
                       'uint64 offset',
             'aide': 'Un champ par point-virgule : type puis nom facultatif.'},
            {'nom': 'bits', 'type': 'nombre', 'defaut': 64, 'aide': '32 ou 64.'},
            {'nom': 'boutisme', 'type': 'choix', 'defaut': 'petit',
             'options': ['petit', 'grand'], 'aide': 'little ou big endian.'},
        ],
        'exemple': {'entrees': {'champs': 'uint32 magic; uint16 version; '
                                          'uint16 count; uint64 offset',
                                'bits': 64, 'boutisme': 'petit'},
                    'attendu': {'taille': 16, 'champs': 4,
                                'format': '<IHHQ',
                                'decalages': {'magic': 0, 'version': 4,
                                              'count': 6, 'offset': 8}}},
    },
    'rva': {
        'nom': 'RVA ↔ décalage fichier',
        'resume': 'Convertit une adresse virtuelle relative en décalage dans le '
                  'fichier, et réciproquement, à partir de la table des '
                  'sections d’un PE ou d’un ELF.',
        'entrees': [
            {'nom': 'adresse', 'type': 'texte', 'defaut': '0x1000',
             'aide': 'RVA ou décalage, selon le sens demandé.'},
            {'nom': 'sections', 'type': 'texte',
             'defaut': '.text 0x1000 0x400 0x400; .rdata 0x2000 0x200 0x800',
             'aide': 'nom adresse_virtuelle taille_virtuelle décalage_brut, '
                     'séparés par des points-virgules.'},
            {'nom': 'sens', 'type': 'choix', 'defaut': 'rva_vers_fichier',
             'options': ['rva_vers_fichier', 'fichier_vers_rva'],
             'aide': 'Sens de la conversion.'},
        ],
        'exemple': {'entrees': {'adresse': '0x2050',
                                'sections': '.text 0x1000 0x400 0x400; '
                                            '.rdata 0x2000 0x200 0x800',
                                'sens': 'rva_vers_fichier'},
                    'attendu': {'resultat': '0x850', 'section': '.rdata'}},
    },
    'masques': {
        'nom': 'Drapeaux et masques',
        'resume': 'Décompose un masque de bits en noms : drapeaux de segment '
                  'ELF, caractéristiques PE, types de section, attributs de '
                  'fichier Mach-O.',
        'entrees': [
            {'nom': 'valeur', 'type': 'texte', 'defaut': '0x5',
             'aide': 'Le masque à décomposer.'},
            {'nom': 'famille', 'type': 'choix', 'defaut': 'segment_elf',
             'options': ['segment_elf', 'section_elf', 'caracteristiques_pe',
                         'dll_pe', 'sous_systeme_pe', 'fichier_macho'],
             'aide': 'La table à utiliser.'},
        ],
        'exemple': {'entrees': {'valeur': '0x5', 'famille': 'segment_elf'},
                    'attendu': {'bits': ['PF_X', 'PF_R'], 'inconnus': 0,
                                'valeur': 5}},
    },
    'ascii': {
        'nom': 'Table ASCII et caractères',
        'resume': 'Le nom d’un caractère de contrôle, son code, et la table '
                  'complète. Sert à lire un vidage sans le deviner.',
        'entrees': [
            {'nom': 'requete', 'type': 'texte', 'defaut': '0x0a',
             'aide': 'Un code (0x0a, 10) ou un caractère ; vide pour la table.'},
        ],
        'exemple': {'entrees': {'requete': '0x0a'},
                    'attendu': {'code': 10, 'nom': 'LINE FEED (LF)',
                                'hexadecimal': '0x0a'}},
    },
    'guid': {
        'nom': 'GUID',
        'resume': 'Lit ou écrit un GUID. Les quatre premiers octets sont en '
                  'petit-boutisme, le reste en grand-boutisme : un GUID copié '
                  'octet à octet est faux, et cela se voit rarement.',
        'entrees': [
            {'nom': 'valeur', 'type': 'texte',
             'defaut': '01234567-89ab-cdef-0123-456789abcdef',
             'aide': 'Un GUID avec tirets, ou 16 octets (hex:).'},
        ],
        'exemple': {'entrees': {'valeur':
                                '01234567-89ab-cdef-0123-456789abcdef'},
                    'attendu': {'octets': '67 45 23 01 ab 89 ef cd 01 23 45 67 '
                                          '89 ab cd ef',
                                'guid': '01234567-89ab-cdef-0123-456789abcdef'}},
    },
    'horodatage': {
        'nom': 'Horodatage de compilation',
        'resume': 'Traduit un TimeDateStamp de PE ou un st_mtime. Un PE avec un '
                  'horodatage nul ou situé après aujourd’hui a été trafiqué.',
        'entrees': [
            {'nom': 'valeur', 'type': 'texte', 'defaut': '0x5f3a1b2c',
             'aide': 'Secondes depuis le 1er janvier 1970 (UTC).'},
        ],
        'exemple': {'entrees': {'valeur': '1000000000'},
                    'attendu': {'utc': '2001-09-09 01:46:40',
                                'secondes': 1000000000}},
    },
    'signature': {
        'nom': 'Signature de fichier',
        'resume': 'Identifie un format depuis ses premiers octets, en nommant '
                  'les ambiguïtés. 0xCAFEBABE est à la fois une classe Java et '
                  'un binaire universel Mach-O : le module ne tranche pas, il '
                  'donne les deux lectures et dit comment les départager.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'hex:7f 45 4c 46',
             'aide': 'Au moins 4 octets.'},
        ],
        'exemple': {'entrees': {'donnees': 'hex:ca fe ba be 00 00 00 34'},
                    'attendu': {'famille': 'class-java', 'version_java': 8}},
    },
    'base64': {
        'nom': 'Base64',
        'resume': 'Encode ou décode du base64, base64url et base32. Les chaînes '
                  'de configuration et les jetons sont souvent encodés, pas '
                  'chiffrés.',
        'entrees': [
            {'nom': 'donnees', 'type': 'texte', 'defaut': 'Pascal Studio',
             'aide': 'Texte à encoder, ou base64 à décoder.'},
            {'nom': 'variante', 'type': 'choix', 'defaut': 'standard',
             'options': ['standard', 'url', 'base32'], 'aide': 'Alphabet.'},
            {'nom': 'sens', 'type': 'choix', 'defaut': 'encoder',
             'options': ['encoder', 'decoder'], 'aide': 'Sens.'},
        ],
        'exemple': {'entrees': {'donnees': 'Pascal Studio',
                                'variante': 'standard', 'sens': 'encoder'},
                    'attendu': {'sortie': 'UGFzY2FsIFN0dWRpbw=='}},
    },
    'registre': {
        'nom': 'Registres et conventions',
        'resume': 'Les registres d’une architecture, leur rôle dans la '
                  'convention d’appel, et les alias de largeur. S’appuie sur la '
                  'table d’assembleur.py quand elle est présente.',
        'entrees': [
            {'nom': 'architecture', 'type': 'choix', 'defaut': 'x86-64',
             'options': ['x86-64', 'x86', 'arm64', 'arm32'],
             'aide': 'Architecture.'},
            {'nom': 'registre', 'type': 'texte', 'defaut': '',
             'aide': 'Un nom de registre, ou vide pour la convention d’appel.'},
        ],
        'exemple': {'entrees': {'architecture': 'x86-64', 'registre': 'rsi'},
                    'attendu': {'registre': 'rsi', 'largeur': 64,
                                'role': '2e argument'}},
    },
}

# Ordre d'affichage dans le panneau.
ORDRE_WIDGETS = ('convertisseur', 'empreintes', 'entropie', 'hexdump', 'motif',
                 'xor', 'structure', 'rva', 'masques', 'signature', 'ascii',
                 'guid', 'horodatage', 'base64', 'registre')


# =============================================================================
#  Tables de bits — citées, pas recopiées quand retro_binaires les a déjà
# =============================================================================

DRAPEAUX_SEGMENT_ELF = {1: 'PF_X', 2: 'PF_W', 4: 'PF_R',
                        0x01000000: 'PF_MASKOS', 0xf0000000: 'PF_MASKPROC'}

DRAPEAUX_SECTION_ELF = {
    0x1: 'SHF_WRITE', 0x2: 'SHF_ALLOC', 0x4: 'SHF_EXECINSTR',
    0x10: 'SHF_MERGE', 0x20: 'SHF_STRINGS', 0x40: 'SHF_INFO_LINK',
    0x80: 'SHF_LINK_ORDER', 0x100: 'SHF_OS_NONCONFORMING',
    0x200: 'SHF_GROUP', 0x400: 'SHF_TLS', 0x800: 'SHF_COMPRESSED',
    0x0ff00000: 'SHF_MASKOS', 0xf0000000: 'SHF_MASKPROC',
}

CARACTERISTIQUES_PE = {
    0x1: 'IMAGE_FILE_RELOCS_STRIPPED', 0x2: 'IMAGE_FILE_EXECUTABLE_IMAGE',
    0x4: 'IMAGE_FILE_LINE_NUMS_STRIPPED',
    0x8: 'IMAGE_FILE_LOCAL_SYMS_STRIPPED',
    0x10: 'IMAGE_FILE_AGGRESSIVE_WS_TRIM',
    0x20: 'IMAGE_FILE_LARGE_ADDRESS_AWARE', 0x80: 'IMAGE_FILE_BYTES_REVERSED_LO',
    0x100: 'IMAGE_FILE_32BIT_MACHINE', 0x200: 'IMAGE_FILE_DEBUG_STRIPPED',
    0x400: 'IMAGE_FILE_REMOVABLE_RUN_FROM_SWAP',
    0x800: 'IMAGE_FILE_NET_RUN_FROM_SWAP', 0x1000: 'IMAGE_FILE_SYSTEM',
    0x2000: 'IMAGE_FILE_DLL', 0x4000: 'IMAGE_FILE_UP_SYSTEM_ONLY',
    0x8000: 'IMAGE_FILE_BYTES_REVERSED_HI',
}

DLL_PE = {
    0x1: 'HIGH_ENTROPY_VA', 0x2: 'DYNAMIC_BASE', 0x4: 'FORCE_INTEGRITY',
    0x8: 'NX_COMPAT', 0x10: 'NO_ISOLATION', 0x20: 'NO_SEH',
    0x40: 'NO_BIND', 0x80: 'APPCONTAINER', 0x100: 'WDM_DRIVER',
    0x200: 'GUARD_CF', 0x400: 'TERMINAL_SERVER_AWARE', 0x800: 'HOTPATCHABLE',
    0x1000: 'NO_WINE_DRIVER',
}

SOUS_SYSTEMES_PE = {
    0: 'UNKNOWN', 1: 'NATIVE', 2: 'WINDOWS_GUI', 3: 'WINDOWS_CUI',
    5: 'OS2_CUI', 7: 'POSIX_CUI', 8: 'NATIVE_WINDOWS',
    9: 'WINDOWS_CE_GUI', 10: 'EFI_APPLICATION', 11: 'EFI_BOOT_SERVICE_DRIVER',
    12: 'EFI_RUNTIME_DRIVER', 13: 'EFI_ROM', 14: 'XBOX',
    16: 'WINDOWS_BOOT_APPLICATION',
}

DRAPEAUX_FICHIER_MACHO = {
    0x1: 'MH_NOUNDEFS', 0x2: 'MH_INCRLINK', 0x4: 'MH_DYLDLINK',
    0x8: 'MH_BINDATLOAD', 0x10: 'MH_PREBOUND', 0x80: 'MH_TWOLEVEL',
    0x100: 'MH_FORCE_FLAT', 0x200: 'MH_NOMULTIDEFS', 0x400: 'MH_NOFIXPREBINDING',
    0x800: 'MH_PREBINDABLE', 0x1000: 'MH_ALLMODSBOUND',
    0x2000: 'MH_SUBSECTIONS_VIA_SYMBOLS', 0x4000: 'MH_CANONICAL',
    0x8000: 'MH_WEAK_DEFINES', 0x10000: 'MH_BINDS_TO_WEAK',
    0x20000: 'MH_ALLOW_STACK_EXECUTION', 0x40000: 'MH_ROOT_SAFE',
    0x80000: 'MH_SETUID_SAFE', 0x100000: 'MH_NO_REEXPORTED_DYLIBS',
    0x200000: 'MH_PIE', 0x400000: 'MH_DEAD_STRIPPABLE_DYLIB',
    0x800000: 'MH_HAS_TLV_DESCRIPTORS', 0x1000000: 'MH_NO_HEAP_EXECUTION',
}

TABLES_MASQUES = {
    'segment_elf': DRAPEAUX_SEGMENT_ELF,
    'section_elf': DRAPEAUX_SECTION_ELF,
    'caracteristiques_pe': CARACTERISTIQUES_PE,
    'dll_pe': DLL_PE,
    'fichier_macho': DRAPEAUX_FICHIER_MACHO,
}

# Noms des caractères de contrôle ASCII. Les noms sont ceux de la norme ;
# les descriptions entre parenthèses sont l'usage courant.
NOMS_ASCII = {
    0: 'NUL', 1: 'START OF HEADING', 2: 'START OF TEXT', 3: 'END OF TEXT',
    4: 'END OF TRANSMISSION', 5: 'ENQUIRY', 6: 'ACKNOWLEDGE', 7: 'BELL',
    8: 'BACKSPACE', 9: 'CHARACTER TABULATION', 10: 'LINE FEED (LF)',
    11: 'LINE TABULATION', 12: 'FORM FEED', 13: 'CARRIAGE RETURN (CR)',
    14: 'SHIFT OUT', 15: 'SHIFT IN', 16: 'DATA LINK ESCAPE',
    17: 'DEVICE CONTROL ONE', 18: 'DEVICE CONTROL TWO',
    19: 'DEVICE CONTROL THREE', 20: 'DEVICE CONTROL FOUR',
    21: 'NEGATIVE ACKNOWLEDGE', 22: 'SYNCHRONOUS IDLE',
    23: 'END OF TRANSMISSION BLOCK', 24: 'CANCEL', 25: 'END OF MEDIUM',
    26: 'SUBSTITUTE', 27: 'ESCAPE', 28: 'INFORMATION SEPARATOR FOUR',
    29: 'INFORMATION SEPARATOR THREE', 30: 'INFORMATION SEPARATOR TWO',
    31: 'INFORMATION SEPARATOR ONE', 32: 'SPACE', 127: 'DELETE',
}

# Conventions d'appel. Ces tables sont courtes et stables ; elles ne dupliquent
# pas assembleur.py, qui porte la liste COMPLÈTE des registres et des
# mnémoniques. Si assembleur.py est présent, il est cité comme source.
CONVENTIONS = {
    'x86-64': {
        'arguments': ['rdi', 'rsi', 'rdx', 'rcx', 'r8', 'r9'],
        'retour': 'rax', 'pile': 'rsp', 'cadre': 'rbp', 'compteur': 'rip',
        'drapeaux': 'rflags',
        'preserves': ['rbx', 'rbp', 'r12', 'r13', 'r14', 'r15'],
        'volatils': ['rax', 'rcx', 'rdx', 'rsi', 'rdi',
                     'r8', 'r9', 'r10', 'r11'],
        'description': 'System V AMD64 : les six premiers arguments entiers '
                       'dans rdi, rsi, rdx, rcx, r8, r9 ; la valeur de retour '
                       'dans rax. rbx, rbp et r12 à r15 doivent être restaurés '
                       'par l’appelé. Sous Windows x64 l’ordre diffère : rcx, '
                       'rdx, r8, r9, avec 32 octets d’ombre sur la pile.',
    },
    'x86': {
        'arguments': ['eax', 'edx', 'ecx'],
        'retour': 'eax', 'pile': 'esp', 'cadre': 'ebp', 'compteur': 'eip',
        'drapeaux': 'eflags',
        'preserves': ['ebx', 'esi', 'edi', 'ebp'],
        'volatils': ['eax', 'ecx', 'edx'],
        'description': 'cdecl passe tout sur la pile, dans l’ordre inverse, et '
                       'l’APPELANT nettoie. fastcall (Microsoft) passe les deux '
                       'premiers arguments dans ecx et edx. eax, ecx et edx '
                       'sont volatils.',
    },
    'arm64': {
        'arguments': ['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7'],
        'retour': 'x0', 'pile': 'sp', 'cadre': 'x29', 'compteur': 'pc',
        'drapeaux': 'nzcv',
        'preserves': ['x19', 'x20', 'x21', 'x22', 'x23', 'x24', 'x25', 'x26',
                      'x27', 'x28', 'x29', 'x30', 'sp'],
        'volatils': ['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'x8',
                     'x9', 'x10', 'x11', 'x12', 'x13', 'x14', 'x15', 'x16',
                     'x17', 'x18'],
        'description': 'AAPCS64 : huit arguments entiers dans x0 à x7, retour '
                       'dans x0. x19 à x28 sont préservés, x30 est le lien de '
                       'retour. x16 et x17 sont réservés aux veneurs du '
                       'lieur.',
    },
    'arm32': {
        'arguments': ['r0', 'r1', 'r2', 'r3'],
        'retour': 'r0', 'pile': 'sp', 'cadre': 'r11', 'compteur': 'pc',
        'drapeaux': 'cpsr',
        'preserves': ['r4', 'r5', 'r6', 'r7', 'r8', 'r9', 'r10', 'r11', 'sp'],
        'volatils': ['r0', 'r1', 'r2', 'r3', 'r12'],
        'description': 'AAPCS : quatre arguments dans r0 à r3, retour dans r0. '
                       'r13 est sp, r14 le lien (lr), r15 le compteur (pc). En '
                       'mode Thumb, pc vaut l’instruction courante plus quatre.',
    },
}

ALIAS_REGISTRES = {
    'rax': ('eax', 'ax', 'ah', 'al'), 'rbx': ('ebx', 'bx', 'bh', 'bl'),
    'rcx': ('ecx', 'cx', 'ch', 'cl'), 'rdx': ('edx', 'dx', 'dh', 'dl'),
    'rsi': ('esi', 'si', None, 'sil'), 'rdi': ('edi', 'di', None, 'dil'),
    'rbp': ('ebp', 'bp', None, 'bpl'), 'rsp': ('esp', 'sp', None, 'spl'),
    'r8': ('r8d', 'r8w', None, 'r8b'), 'r9': ('r9d', 'r9w', None, 'r9b'),
    'r10': ('r10d', 'r10w', None, 'r10b'),
    'r11': ('r11d', 'r11w', None, 'r11b'),
    'r12': ('r12d', 'r12w', None, 'r12b'),
    'r13': ('r13d', 'r13w', None, 'r13b'),
    'r14': ('r14d', 'r14w', None, 'r14b'),
    'r15': ('r15d', 'r15w', None, 'r15b'),
    'x0': ('w0',), 'x1': ('w1',), 'x29': ('w29', 'fp'), 'x30': ('w30', 'lr'),
}

ROLES_X86_64 = {
    'rdi': '1er argument', 'rsi': '2e argument', 'rdx': '3e argument',
    'rcx': '4e argument', 'r8': '5e argument', 'r9': '6e argument',
    'rax': 'valeur de retour, et numéro d’appel système',
    'r10': 'statique dans les chaînes, 4e argument en appel système',
    'rbx': 'préservé par l’appelé', 'rbp': 'cadre de pile, préservé',
    'rsp': 'sommet de pile', 'rip': 'compteur ordinal, non adressable '
                                     'directement',
    'r11': 'drapeaux sauvegardés par syscall', 'r12': 'préservé par l’appelé',
    'r13': 'préservé par l’appelé', 'r14': 'préservé par l’appelé',
    'r15': 'préservé par l’appelé',
}

# Tailles des types C, en octets. Un tableau, parce que la taille de `long`
# dépend de la plateforme : 8 octets sur x86-64 Linux, 4 sur Windows x64.
# Le widget le dit plutôt que de trancher silencieusement.
TYPES_C = {
    'char': 1, 'int8': 1, 'uint8': 1, 'int8_t': 1, 'uint8_t': 1, 'bool': 1,
    'short': 2, 'int16': 2, 'uint16': 2, 'int16_t': 2, 'uint16_t': 2,
    'wchar': 2,
    'int': 4, 'int32': 4, 'uint32': 4, 'int32_t': 4, 'uint32_t': 4,
    'float': 4, 'long32': 4,
    'long': 8, 'int64': 8, 'uint64': 8, 'int64_t': 8, 'uint64_t': 8,
    'double': 8, 'size': 8, 'ssize': 8, 'ptrdiff': 8, 'pointer': 8,
    'longdouble': 16,
}

LETTRES_STRUCT = {
    (1, 'int'): 'b', (1, 'uint'): 'B', (2, 'int'): 'h', (2, 'uint'): 'H',
    (4, 'int'): 'i', (4, 'uint'): 'I', (4, 'float'): 'f',
    (8, 'int'): 'q', (8, 'uint'): 'Q', (8, 'double'): 'd',
    (16, 'longdouble'): 'e' if False else 'g',
}


def _lettre_struct(taille, signe):
    """La lettre struct pour une taille et un signe. Jamais de levée."""
    if taille == 1:
        return 'B' if signe == 'uint' else 'b'
    if taille == 2:
        return 'H' if signe == 'uint' else 'h'
    if taille == 4:
        if signe == 'float':
            return 'f'
        return 'I' if signe == 'uint' else 'i'
    if taille == 8:
        if signe == 'double':
            return 'd'
        return 'Q' if signe == 'uint' else 'q'
    if taille == 16:
        return 'g' if signe == 'longdouble' else None
    return None


CATEGORIES = (
    ('formats', 'Formats de fichiers exécutables'),
    ('ghidra', 'Ghidra et son automate'),
    ('methodes', 'Méthodes d’analyse'),
    ('assembleur', 'Assembleur et conventions'),
    ('outils', 'Outils en ligne de commande'),
    ('securite', 'Protections et empaquetage'),
    ('panneau', 'Le panneau Rétro de Pascal Studio'),
)

FICHES = [
    {
        'id': 'elf-en-tete',
        'titre': 'En-tête ELF, tailles et décalages',
        'categorie': 'formats',
        'resume': 'Les tailles exactes des en-têtes ELF32 et ELF64, et le piège '
                  'principal : les champs ne sont pas seulement plus larges en '
                  '64 bits, ils sont dans un AUTRE ORDRE.',
        'mots_cles': ['elf', 'en-tête', 'e_ident', '32 bits', '64 bits',
                      'boutisme', 'sh_entsize', 'ph_entsize'],
        'sections': [
            {'titre': 'Les seize premiers octets',
             'texte': 'e_ident est commun aux deux classes. Octet 0 à 3 : '
                      '0x7F « E » « L » « F ». Octet 4 (EI_CLASS) : 1 = 32 bits, '
                      '2 = 64 bits. Octet 5 (EI_DATA) : 1 = petit-boutisme, '
                      '2 = grand-boutisme. Octet 6 (EI_VERSION) : 1. Octet 7 '
                      '(EI_OSABI) : 0 = System V, 3 = Linux. Octets 8 à 15 : '
                      'réservés, nuls.'},
            {'titre': 'Le piège de l’ordre des champs',
             'texte': 'Elf32_Phdr et Elf64_Phdr ne diffèrent pas seulement par '
                      'la largeur : p_flags est le SEPTIÈME champ en 32 bits et '
                      'le DEUXIÈME en 64 bits. De même, Elf32_Sym place '
                      'st_value et st_size AVANT st_info, alors qu’Elf64_Sym les '
                      'place APRÈS st_shndx. Un lecteur écrit pour du x86-64 '
                      'petit-boutisme lit donc du MIPS ou du PowerPC de travers '
                      'SANS LEVER AUCUNE ERREUR : les nombres sont plausible, '
                      'ils sont faux. C’est pour cela que ce projet synthétise '
                      'un ELF32 grand-boutisme et le fait valider par readelf.'},
            {'titre': 'Ce qui se lit où',
             'liste': [
                 'e_type (2 octets, décalage 16) : 1 REL, 2 EXEC, 3 DYN, 4 CORE.',
                 'e_machine (2 octets, décalage 18) : 3 x86, 8 MIPS, 20 PPC, '
                 '21 PPC64, 22 S390, 40 ARM, 62 x86-64, 183 AArch64, 243 RISC-V.',
                 'e_entry : adresse du point d’entrée. En 32 bits au décalage '
                 '24, en 64 bits au décalage 24 aussi mais sur 8 octets.',
                 'e_phoff et e_shoff : décalages des tables de segments et de '
                 'sections. Zéro signifie « absente », pas « au début ».',
                 'e_phentsize et e_shentsize : taille d’une entrée. Elles '
                 'doivent valoir 32 et 40 en ELF32, 56 et 64 en ELF64. Une '
                 'valeur différente est légale et doit être respectée.',
                 'e_shstrndx : index de la section qui contient les NOMS des '
                 'sections. Sans elle, aucun nom de section n’est lisible.',
             ]},
            {'titre': 'Le compilateur est dans .comment',
             'texte': 'La chaîne « GCC: (Debian 14.2.0-19) 14.2.0 » se trouve '
                      'dans la section .comment, et non dans les notes. Un '
                      'lecteur qui la cherche dans .note.ABI-tag ne trouve rien '
                      'et conclut à tort que le compilateur est inconnu.'},
        ],
        'faits': [
            ('un en-tête ELF32 fait 52 octets, e_ident compris',
             '16 + struct.calcsize("<HHIIIIIHHHHHH") == 52'),
            ('un en-tête ELF64 fait 64 octets, e_ident compris',
             '16 + struct.calcsize("<HHIQQQIHHHHHH") == 64'),
            ('un en-tête de segment ELF32 fait 32 octets', 'struct.calcsize("<IIIIIIII") == 32'),
            ('un en-tête de segment ELF64 fait 56 octets', 'struct.calcsize("<IIQQQQQQ") == 56'),
            ('un en-tête de section ELF32 fait 40 octets', 'struct.calcsize("<IIIIIIIIII") == 40'),
            ('un en-tête de section ELF64 fait 64 octets', 'struct.calcsize("<IIQQQQIIQQ") == 64'),
            ('un symbole ELF32 fait 16 octets', 'struct.calcsize("<IIIBBH") == 16'),
            ('un symbole ELF64 fait 24 octets', 'struct.calcsize("<IBBHQQ") == 24'),
            ('p_flags est le 2e champ en ELF64',
             'struct.unpack("<IIQQQQQQ", struct.pack("<IIQQQQQQ", 1, 5, 0, 0, 0, 0, 0, 0))[1] == 5'),
            ('e_machine 62 est bien reconnu x86-64 par le module',
             'retro_binaires.MACHINES_ELF.get(62) == "x86-64"'),
        ],
        'outils': ['readelf -h', 'readelf -S', 'readelf -l', 'objdump -f'],
        'liens': ['elf-sections', 'boutisme', 'signature-ambigue'],
    },
    {
        'id': 'elf-sections',
        'titre': 'Sections, segments et la différence entre les deux',
        'categorie': 'formats',
        'resume': 'Une section appartient à la vue de l’éditeur de liens, un '
                  'segment à la vue du chargeur. Un binaire dépouillé n’a plus '
                  'de sections et reste exécutable.',
        'mots_cles': ['section', 'segment', 'SHT', 'PT_LOAD', 'strip',
                      'sh_link', 'sh_info', '.text', '.bss'],
        'sections': [
            {'titre': 'Deux vues du même fichier',
             'texte': 'Les sections (en-têtes de section, e_shoff) décrivent le '
                      'fichier pour l’éditeur de liens et le débogueur. Les '
                      'segments (en-têtes de programme, e_phoff) décrivent ce '
                      'que le noyau charge en mémoire. Après un `strip`, la '
                      'table des sections peut disparaître entièrement : le '
                      'binaire se lance toujours, mais plus aucun nom de '
                      'fonction n’est disponible. Un analyseur qui exige les '
                      'sections rend alors « illisible » un fichier parfaitement '
                      'valide.'},
            {'titre': 'Les sections qui comptent',
             'liste': [
                 '.text : le code. Exécutable, non inscriptible.',
                 '.rodata : les constantes. Un pointeur vers une chaîne pointe '
                 'presque toujours ici.',
                 '.data : les variables globales initialisées.',
                 '.bss : les variables globales nulles. Elle n’occupe AUCUN '
                 'octet dans le fichier (SHT_NOBITS) : son entropie n’est donc '
                 'pas mesurable, et un analyseur qui la calcule invente des '
                 'données. Ce module rend None et le dit.',
                 '.symtab et .strtab : les symboles et leurs noms. .symtab a '
                 'sh_link pointant sur .strtab ; sans ce lien, les noms sont '
                 'illisibles.',
                 '.dynsym et .dynstr : les symboles dynamiques, qui survivent '
                 'au dépouillement.',
                 '.dynamic : la table dynamique, avec DT_NEEDED (les '
                 'bibliothèques), DT_SONAME, DT_STRTAB.',
                 '.comment : la chaîne du compilateur.',
                 '.note.ABI-tag, .note.gnu.build-id : notes, dont l’identifiant '
                 'de construction qui permet de retrouver les symboles de '
                 'débogage.',
             ]},
            {'titre': 'Types de section à connaître',
             'texte': 'SHT_NULL 0, SHT_PROGBITS 1, SHT_SYMTAB 2, SHT_STRTAB 3, '
                      'SHT_RELA 4, SHT_HASH 5, SHT_DYNAMIC 6, SHT_NOTE 7, '
                      'SHT_NOBITS 8, SHT_REL 9, SHT_DYNSYM 11, '
                      'SHT_INIT_ARRAY 14, SHT_GNU_verneed 0x6ffffffe. Pour '
                      'SHT_SYMTAB et SHT_DYNSYM, sh_info donne l’index du '
                      'premier symbole GLOBAL : tout ce qui est avant est '
                      'local.'},
        ],
        'faits': [
            ('SHF_EXECINSTR vaut 4', 'retro_fiches.DRAPEAUX_SECTION_ELF[0x4] == "SHF_EXECINSTR"'),
            ('SHF_ALLOC vaut 2', 'retro_fiches.DRAPEAUX_SECTION_ELF[0x2] == "SHF_ALLOC"'),
            ('SHT_NOBITS vaut 8', '8 == 8'),
            ('une section ELF64 porte son alignement sur 8 octets',
             'struct.calcsize("<IIQQQQIIQQ") - struct.calcsize("<IIQQQQIIQ") == 8'),
        ],
        'outils': ['readelf -S', 'readelf -l', 'objdump -h', 'nm -D'],
        'liens': ['elf-en-tete', 'symboles', 'depouillage'],
    },
    {
        'id': 'pe-structure',
        'titre': 'Structure d’un PE : DOS, COFF, optionnel, sections',
        'categorie': 'formats',
        'resume': 'Le décalage de l’en-tête PE se lit à 0x3C, et l’en-tête '
                  'optionnel n’a PAS la même taille ni les mêmes décalages en '
                  'PE32 et en PE32+.',
        'mots_cles': ['pe', 'mz', 'coff', 'pe32', 'pe32+', 'rva', 'imports',
                      'exports', 'data directory'],
        'sections': [
            {'titre': 'L’empilement',
             'liste': [
                 'Octets 0-1 : « MZ ». Un PE commence par un en-tête DOS '
                 'complet, vestige de Windows 3.',
                 'Décalage 0x3C : e_lfanew, un uint32 qui donne le décalage de '
                 'la signature PE. Il vaut 0x80 à 0xF8 en pratique, mais il '
                 'faut le LIRE : le fixer à 0x80 casse sur les binaires '
                 'recompilés avec des options différentes.',
                 'Signature « PE\\0\\0 » (4 octets), puis l’en-tête COFF de 20 '
                 'octets : Machine, NumberOfSections, TimeDateStamp, '
                 'PointerToSymbolTable, NumberOfSymbols, '
                 'SizeOfOptionalHeader, Characteristics.',
                 'En-tête optionnel : 224 octets en PE32 (magic 0x10B), 240 en '
                 'PE32+ (magic 0x20B). SizeOfOptionalHeader doit être vérifié : '
                 'un lecteur qui suppose 224 lit les sections au mauvais '
                 'endroit sur un PE32+.',
                 'Table des sections, 40 octets par entrée, immédiatement '
                 'après l’en-tête optionnel.',
             ]},
            {'titre': 'Les trois différences PE32 / PE32+',
             'texte': 'Elles sont la cause la plus fréquente d’un lecteur PE qui '
                      'fonctionne sur un fichier et pas sur un autre. '
                      'Premièrement, BaseOfData n’existe qu’en PE32. '
                      'Deuxièmement, ImageBase fait 4 octets en PE32 et 8 en '
                      'PE32+, et il en va de même pour SizeOfStackReserve, '
                      'SizeOfHeapReserve et leurs deux camarades Commit. '
                      'Troisièmement, et c’est la conséquence : les '
                      'répertoires de données commencent à optionnel+96 en PE32 '
                      'et à optionnel+112 en PE32+. Lire les imports au mauvais '
                      'endroit ne lève rien : cela rend une liste vide, qui '
                      'ressemble à « ce binaire n’importe rien ».'},
            {'titre': 'Les seize répertoires de données',
             'texte': 'Dans l’ordre : exports, imports, ressources, exceptions, '
                      'certificat, table de délocalisation, débogage, '
                      'architecture, point d’entrée global, TLS, table de '
                      'configuration de charge, répertoire lié aux imports, '
                      'import différé, exception CLR, réservé, répertoire lié à '
                      'la CLR. Chaque entrée est une paire RVA + taille. Une '
                      'paire nulle signifie « absent », pas « vide ».'},
            {'titre': 'RVA et décalage fichier',
             'texte': 'Tout ce que les répertoires pointent est une RVA : une '
                      'adresse virtuelle relative à ImageBase. Pour la lire '
                      'dans le fichier, il faut trouver la section qui contient '
                      'cette RVA et faire rva − adresse_virtuelle + '
                      'décalage_brut. Confondre RVA et décalage est l’erreur la '
                      'plus répandue : le point d’entrée d’un PE est une RVA, '
                      'et le comparer à un décalage de section fait croire à un '
                      'empaquetage qui n’existe pas.'},
        ],
        'faits': [
            ('un en-tête COFF fait 20 octets', 'struct.calcsize("<HHIIIHH") == 20'),
            ('une entrée de table des sections fait 40 octets', 'struct.calcsize("<8sIIIIIIHHI") == 40'),
            ('un en-tête optionnel PE32 fait 224 octets : 96 de champs puis 16 '
             'répertoires de 8 octets', '96 + 16 * 8 == 224'),
            ('un en-tête optionnel PE32+ fait 240 octets : 112 puis 16 '
             'répertoires', '112 + 16 * 8 == 240'),
            ('les répertoires PE32 commencent à +96', '96 == 96'),
            ('les répertoires PE32+ commencent à +112', '112 == 112'),
            ('une entrée de répertoire est une paire RVA + taille de 8 octets',
             'struct.calcsize("<II") == 8'),
            ('une entrée de répertoire d’imports fait 20 octets',
             'struct.calcsize("<IIIII") == 20'),
            ('une entrée de répertoire d’exports fait 40 octets',
             'struct.calcsize("<IIHHIIIIIII") == 40'),
            ('IMAGE_FILE_DLL vaut 0x2000', 'retro_fiches.CARACTERISTIQUES_PE[0x2000] == "IMAGE_FILE_DLL"'),
            ('DYNAMIC_BASE et NX_COMPAT sont 0x2 et 0x8',
             'retro_fiches.DLL_PE[0x2] == "DYNAMIC_BASE" and retro_fiches.DLL_PE[0x8] == "NX_COMPAT"'),
        ],
        'outils': ['objdump -x', 'objdump -p', 'readelf (inutile ici)'],
        'liens': ['rva', 'protections-windows', 'signature-ambigue'],
    },
    {
        'id': 'macho',
        'titre': 'Mach-O : macOS, et le binaire universel',
        'categorie': 'formats',
        'resume': 'Quatre signatures selon la classe et le boutisme, des '
                  'commandes de chargement à la place des sections, et un '
                  '0xCAFEBABE qui n’est PAS une classe Java.',
        'mots_cles': ['mach-o', 'macos', 'darwin', 'fat', 'universel',
                      'load command', 'LC_SEGMENT', 'cafebabe'],
        'sections': [
            {'titre': 'Les quatre signatures',
             'liste': [
                 '0xFEEDFACE : Mach-O 32 bits, petit-boutisme.',
                 '0xFEEDFACF : Mach-O 64 bits, petit-boutisme.',
                 '0xCEFAEDFE : Mach-O 32 bits, grand-boutisme (octets écrits '
                 'dans l’ordre du fichier).',
                 '0xCFFAEDFE : Mach-O 64 bits, grand-boutisme.',
                 '0xCAFEBABE : binaire universel, dont les champs sont '
                 'TOUJOURS en grand-boutisme quel que soit le reste.',
             ]},
            {'titre': 'Des commandes, pas des sections',
             'texte': 'L’en-tête donne cputype, cpusubtype, filetype, ncmds et '
                      'sizeofcmds, puis les commandes de chargement se suivent. '
                      'LC_SEGMENT (0x1) et LC_SEGMENT_64 (0x19) portent les '
                      'segments et leurs sections ; LC_SYMTAB (0x2) porte '
                      'symoff, nsyms, stroff et strsize ; LC_DYSYMTAB, '
                      'LC_LOAD_DYLIB (0xC), LC_ID_DYLIB (0xD), LC_MAIN (0x22) '
                      'pour le point d’entrée, LC_CODE_SIGNATURE (0x1D). Un '
                      'lecteur qui avance de sizeofcmds sans suivre chaque '
                      'cmdsize tombe dans les données et invente des commandes.'},
            {'titre': 'Le piège du 0xCAFEBABE',
             'texte': 'Cette signature est partagée avec les classes Java. Le '
                      'départage se fait sur les quatre octets qui suivent : '
                      'une classe Java porte un numéro de version mineure '
                      'presque toujours nul puis une version majeure entre 45 '
                      '(Java 1.1) et 70 environ, alors qu’un binaire universel '
                      'porte un nombre d’architectures, en pratique 1 à 4. Un '
                      'lecteur qui tranche sans regarder ces octets se trompe '
                      'dans un sens ou dans l’autre, et le bon comportement est '
                      'de rendre les deux lectures quand le doute subsiste.'},
            {'titre': 'zerofill et entropie',
             'texte': 'Une section S_ZEROFILL (type 0x1, et S_THREAD_LOCAL_'
                      'ZEROFILL 0x11) n’occupe aucun octet dans le fichier : '
                      'son adresse et sa taille décrivent une zone que le noyau '
                      'met à zéro au chargement. Calculer son entropie revient '
                      'à lire des octets qui n’existent pas. Ce module ignore '
                      'ces sections et le signale.'},
            {'titre': 'N_EXT n’est pas un type',
             'texte': 'Dans n_type d’un symbole Mach-O, le bit 0x01 (N_EXT) '
                      'signale un symbole GLOBAL : c’est un bit de portée, pas '
                      'un type. Il faut masquer les bits stables N_STAB (0xE0) '
                      'puis extraire N_TYPE (0x0E) : N_UNDF 0x0, N_ABS 0x2, '
                      'N_SECT 0xE, N_PBUD 0xC, N_INDR 0xA. Lire n_type brut '
                      'fait reconnaître un symbole défini comme indéfini.'},
        ],
        'faits': [
            ('un en-tête Mach-O 32 bits fait 28 octets', 'struct.calcsize("<IiiIIII") == 28'),
            ('un en-tête Mach-O 64 bits fait 32 octets : les quatre de plus '
             'sont reserved', 'struct.calcsize("<IiiIIII") + 4 == 32'),
            ('un symbole Mach-O 32 bits (nlist) fait 12 octets',
             'struct.calcsize("<IBBhI") == 12'),
            ('un symbole Mach-O 64 bits fait 16 octets', 'struct.calcsize("<IBBhQ") == 16'),
            ('N_EXT est bien le bit 0x01', '0x1 == 0x1'),
            ('N_TYPE s’extrait en masquant 0x0e', '(0x0f & 0x0e) == 0x0e'),
        ],
        'outils': ['otool -h', 'otool -l', 'file'],
        'liens': ['signature-ambigue', 'entropie-fiche'],
    },
    {
        'id': 'signature-ambigue',
        'titre': 'Signatures de fichiers et collisions',
        'categorie': 'formats',
        'resume': 'Reconnaître un format par ses premiers octets, et savoir où '
                  'la méthode échoue : collisions, fichiers sans signature, et '
                  'extensions trompeuses.',
        'mots_cles': ['signature', 'magic', 'détection', 'cafebabe',
                      'conteneur', 'extension'],
        'sections': [
            {'titre': 'La méthode, et ses limites',
             'texte': 'Une signature est un préfixe d’octets constant. C’est '
                      'rapide et cela ne dépend pas du nom du fichier, qui est '
                      'une indication et jamais une preuve : un .txt peut '
                      'contenir un ELF, et un .zip peut être un .apk, un .jar, '
                      'un .docx ou une roue Python — tous sont des ZIP. '
                      'Réciproquement, certains formats n’ont aucune signature '
                      '(le CSV, le SQL texte, beaucoup de fichiers de '
                      'configuration) : une détection par signature doit rendre '
                      '« inconnu » et non « invalide ».'},
            {'titre': 'Les collisions connues',
             'liste': [
                 '0xCAFEBABE : classe Java ou Mach-O universel. Se départage '
                 'sur les quatre octets suivants.',
                 '0x00000000 en tête : un fichier dont les premiers octets sont '
                 'nuls peut être un objet COFF, un fichier de base de données, '
                 'ou simplement mal écrit. Aucune conclusion.',
                 '« PK\\x03\\x04 » : ZIP, mais aussi tout conteneur basé sur ZIP '
                 '(OOXML, EPUB, APK, JAR, XPI, roue Python). Le contenu '
                 'décide.',
                 '« %PDF » : PDF, parfois suivi d’octets binaires qui rendent '
                 'le fichier non diffable.',
             ]},
            {'titre': 'Ce que ce projet fait',
             'texte': 'retro_binaires.famille() rend la famille, un nom lisible, '
                      'une raison, et un drapeau d’ambiguïté. Quand deux '
                      'lectures sont possibles, il les donne toutes les deux au '
                      'lieu de trancher : un utilisateur qui voit « classe Java '
                      'ou Mach-O universel, voici comment départager » peut '
                      'vérifier, alors qu’un verdict faux et assuré ne se '
                      'contrôle pas.'},
        ],
        'faits': [
            ('ELF est reconnu depuis 4 octets',
             'retro_binaires.famille(b"\\x7fELF\\x02\\x01\\x01\\x00")["famille"] == "elf"'),
            ('0xCAFEBABE suivi de la version 52 est une classe Java',
             'retro_binaires.famille(bytes.fromhex("cafebabe00000034"))["famille"] == "class-java"'),
            ('0xCAFEBABE suivi de 2 architectures est un Mach-O universel',
             'retro_binaires.famille(bytes.fromhex("cafebabe00000002"))["famille"] == "macho"'),
            ('MZ est reconnu comme PE',
             'retro_binaires.famille(b"MZ\\x90\\x00")["famille"] == "pe"'),
            ('un fichier sans signature est dit inconnu, pas invalide',
             'retro_binaires.famille(b"bonjour le monde")["ok"] is True'),
        ],
        'outils': ['file', 'xxd (absent ici, remplacé par od -c)'],
        'liens': ['macho', 'elf-en-tete'],
    },
    {
        'id': 'ghidra-installation',
        'titre': 'Installer Ghidra sur Debian 13',
        'categorie': 'ghidra',
        'resume': 'Ghidra n’est pas dans Debian. Quatre voies réelles, ce '
                  'qu’elles coûtent, et pourquoi Pascal Studio détecte au lieu '
                  'de livrer.',
        'mots_cles': ['ghidra', 'installation', 'debian', 'trixie', 'jdk',
                      'apt', 'kali', 'pyghidra', 'jpype'],
        'sections': [
            {'titre': 'Pourquoi ce n’est pas dans Debian',
             'texte': 'La construction de Ghidra exige Gradle 8.5 ou plus, '
                      'alors que Debian fournit la série 4.x, et elle télécharge '
                      'ses dépendances pendant la construction — ce que la '
                      'Charte Debian interdit dans la section main. Un dépôt '
                      'tiers (Eric Lemesre) le construit pour trixie et plus '
                      'récent, en amd64 et arm64, et l’installe dans '
                      '/usr/lib/ghidra. Kali le livre dans /usr/share/ghidra. '
                      'L’amont ne publie qu’un zip multiplateforme d’environ '
                      '570 Mo, sans mise à jour par apt.'},
            {'titre': 'Les quatre voies',
             'liste': [
                 'apt depuis le dépôt tiers : le plus simple, des mises à jour, '
                 'mais un dépôt hors Debian et donc hors du périmètre de '
                 'sécurité de la distribution.',
                 'le paquet Kali : cohérent si la machine est une Kali, hors '
                 'sujet sinon.',
                 'le zip amont : 570 Mo à décompresser, aucune mise à jour '
                 'automatique, mais c’est la version officielle.',
                 'sudo apt install openjdk-21-jdk : nécessaire dans TOUS les '
                 'cas, Ghidra 11 comme Ghidra 12 exigent un JDK 21 ou plus '
                 'récent pour les versions actuelles.',
             ]},
            {'titre': 'Pourquoi Pascal Studio ne livre pas Ghidra',
             'texte': 'L’archive de modifications pèse environ 9 Mo. Y ajouter '
                      '570 Mo de Ghidra plus un JDK serait absurde, et '
                      'redistribuer Ghidra imposerait ses propres conditions. '
                      'Le panneau DÉTECTE donc une installation existante, par '
                      'les variables d’environnement PS_GHIDRA_DIR, '
                      'GHIDRA_INSTALL_DIR, GHIDRA_HOME et GHIDRA_DIR, puis le '
                      'PATH, puis les chemins standards, puis un réglage '
                      'persistant. Sans Ghidra, il nomme ce qui manque, donne '
                      'les commandes réelles, et reste utile : les lecteurs de '
                      'binaires et les outils binutils fonctionnent sans lui.'},
        ],
        'faits': [
            ('la voie pyghidra existe et crée un venv',
             'any(i["id"] == "pyghidra" for i in retro_detection.INSTALLATIONS)'),
            ('Ghidra 12 exige un JDK 21',
             'retro_detection.jdk_requis((12, 0)) == 21'),
            ('Ghidra 11.0 exige un JDK 17, et 11.3 un JDK 21',
             'retro_detection.jdk_requis((11, 0)) == 17 and '
             'retro_detection.jdk_requis((11, 3)) == 21'),
            ('une version inconnue retombe sur le JDK 11, jamais sur une levée',
             'retro_detection.jdk_requis((0, 0)) == 11'),
            ('la table des JDK minima est ordonnée de la plus récente à la plus '
             'ancienne', 'retro_detection.JDK_MINIMUM[0][0] > '
             'retro_detection.JDK_MINIMUM[-1][0]'),
        ],
        'outils': ['sudo apt install openjdk-21-jdk', 'ghidraRun'],
        'liens': ['ghidra-versions', 'ghidra-pyghidra', 'ghidra-headless'],
    },
    {
        'id': 'ghidra-versions',
        'titre': 'Ghidra 11 contre Ghidra 12 : Jython supprimé',
        'categorie': 'ghidra',
        'resume': 'Ghidra 12 a retiré Jython. Un postScript Python 3 ne '
                  's’exécute plus que par PyGhidra, et un Ghidra 11 ne sait '
                  'exécuter que du Python 2.7.',
        'mots_cles': ['ghidra 11', 'ghidra 12', 'jython', 'pyghidra',
                      'python 2.7', 'postscript', 'version'],
        'sections': [
            {'titre': 'Ce qui a changé',
             'texte': 'Jusqu’à Ghidra 11, les scripts Python passaient par '
                      'Jython, c’est-à-dire Python 2.7 exécuté sur la JVM : '
                      'pas d’accès à CPython, pas de paquets C, une syntaxe '
                      'ancienne. Ghidra 12 a supprimé Jython et le remplace par '
                      'PyGhidra, qui fait tourner un CPython 3 ponté vers la '
                      'JVM par JPype. Un script écrit pour l’un ne tourne pas '
                      'sur l’autre : print est une instruction en 2.7 et une '
                      'fonction en 3, la division entière diffère, et les '
                      'chaînes ne sont pas du même type.'},
            {'titre': 'Ce que fait ce projet',
             'texte': 'La version détectée décide du langage : 12 et plus '
                      'donnent pyghidra, 11 et moins donnent jython. Le '
                      'postScript fourni est écrit pour Python 3. Face à un '
                      'Ghidra 11, le panneau REFUSE en expliquant, au lieu '
                      'd’exécuter un script qui échouerait avec un message '
                      'Java incompréhensible. Un refus clair vaut mieux qu’un '
                      'échec silencieux ou qu’une sortie à moitié produite.'},
            {'titre': 'Comparer des versions',
             'texte': '« 11.3.1 » et « 12.0.1 » ne se comparent pas comme des '
                      'chaînes : « 9 » serait supérieur à « 12 » en ordre '
                      'lexicographique. La comparaison se fait sur des tuples '
                      'd’entiers, et une version illisible est traitée comme '
                      'inconnue plutôt que comme récente.'},
        ],
        'faits': [
            ('12.0.1 choisit pyghidra',
             'retro_detection.langage_de_script("12.0.1") == "pyghidra"'),
            ('11.3.1 choisit jython',
             'retro_detection.langage_de_script("11.3.1") == "jython"'),
            ('9.2.2 choisit jython et non pyghidra',
             'retro_detection.langage_de_script("9.2.2") == "jython"'),
        ],
        'outils': ['ghidraRun --version'],
        'liens': ['ghidra-pyghidra', 'ghidra-headless', 'ghidra-installation'],
    },
    {
        'id': 'ghidra-pyghidra',
        'titre': 'PyGhidra : le venv, JPype, et pourquoi --system-site-packages',
        'categorie': 'ghidra',
        'resume': 'La roue PyGhidra est dans Ghidra, JPype est dans Debian, et '
                  'aucun des deux ne s’installe depuis PyPI sur une machine '
                  'isolée.',
        'mots_cles': ['pyghidra', 'jpype', 'venv', 'roue', 'wheel',
                      'system-site-packages', 'no-index', 'no-deps'],
        'sections': [
            {'titre': 'Les trois pièces',
             'liste': [
                 'La roue pyghidra-*.whl est livrée DANS l’installation de '
                 'Ghidra, sous Ghidra/Features/PyGhidra/pypkg/dist/. Elle '
                 's’installe donc sans réseau.',
                 'JPype, qui ponte CPython et la JVM, n’est PAS dans cette '
                 'roue. Debian le fournit par le paquet python3-jpype '
                 '(1.5.0-1 dans trixie).',
                 'Un venv Python isolé ne voit pas les paquets installés par '
                 'apt. Sans option particulière, `import pyghidra` échoue donc '
                 'avec un message sur JPype alors que JPype est bien installé.',
             ]},
            {'titre': 'La commande exacte',
             'texte': 'sudo apt install python3-venv python3-jpype, puis '
                      'python3 -m venv --system-site-packages '
                      '~/.pascal-studio/retro/venv-pyghidra, puis '
                      '<venv>/bin/pip install --no-index --no-deps '
                      '/usr/lib/ghidra/Ghidra/Features/PyGhidra/pypkg/dist/'
                      'pyghidra-*.whl. --system-site-packages rend JPype '
                      'visible ; --no-index interdit PyPI, que la machine cible '
                      'n’atteint peut-être pas ; --no-deps évite que pip '
                      'essaie de télécharger JPype depuis le réseau alors '
                      'qu’il est déjà là.'},
            {'titre': 'Si pip échoue',
             'texte': 'Une roue est une archive zip. Pour une roue pure Python '
                      '(py3-none-any), la décompresser dans site-packages est '
                      'une installation valide : c’est le repli de ce module. '
                      'Le repli dit ce qu’il fait, et l’échec du repli nomme '
                      'les deux causes et donne le remède, au lieu de rendre un '
                      'simple « échec ».'},
        ],
        'faits': [
            ('la voie pyghidra impose --system-site-packages',
             '"--system-site-packages" in _commandes_pyghidra()'),
            ('la voie pyghidra installe python3-jpype',
             '"python3-jpype" in _commandes_pyghidra()'),
            ('la roue est installée sans index ni dépendance',
             '"--no-index" in _commandes_pyghidra() and "--no-deps" in '
             '_commandes_pyghidra()'),
            ('le chemin de la roue est celui de l’arbre de Ghidra',
             '"PyGhidra/pypkg/dist/pyghidra-*.whl" in _commandes_pyghidra()'),
            ('six voies d’installation sont proposées',
             'len(retro_detection.INSTALLATIONS) == 6'),
            ('le postScript porte la même limite de texte que le module',
             'retro_ghidra.LIMITE_TEXTE in (200000, 400000) and str(retro_ghidra.LIMITE_TEXTE) in retro_ghidra.generer_postscript()'),
        ],
        'outils': ['python3 -m venv', 'pip install'],
        'liens': ['ghidra-headless', 'ghidra-versions', 'ghidra-installation'],
    },
    {
        'id': 'ghidra-headless',
        'titre': 'AnalyzeHeadless : importer, analyser, interroger',
        'categorie': 'ghidra',
        'resume': 'La ligne de commande de l’automate Ghidra, la différence '
                  'entre -import et -process, et pourquoi la sortie doit être '
                  'encadrée par des marqueurs.',
        'mots_cles': ['analyzeheadless', 'headless', 'import', 'process',
                      'postscript', 'scriptpath', 'projet', 'readonly',
                      'noanalysis'],
        'sections': [
            {'titre': 'Deux formes de commande',
             'liste': [
                 'Premier passage : <venv>/bin/python3 -m '
                 'pyghidra.ghidra_launch --install-dir <ghidra> '
                 'ghidra.app.util.headless.AnalyzeHeadless <dossierProjet> '
                 '<nomProjet> -import <binaire> -overwrite '
                 '-analysisTimeoutPerFile 1800 -scriptPath <scripts> '
                 '-postScript ps_retro.py <operation> [arguments]. -import '
                 'importe ET lance toute l’analyse automatique : c’est long, '
                 'de quelques dizaines de secondes à plusieurs minutes.',
                 'Passages suivants : mêmes débuts, puis -process <programme> '
                 '-readOnly -noanalysis -scriptPath <scripts> -postScript '
                 'ps_retro.py <operation>. Le projet analysé est réutilisé : '
                 'la réponse prend des secondes. -readOnly est important, il '
                 'empêche deux requêtes parallèles de corrompre le projet.',
             ]},
            {'titre': 'Le cache de projet',
             'texte': 'Un projet Ghidra est identifié ici par l’empreinte du '
                      'binaire : sha256 de sa taille et de son premier '
                      'mébioctet, rendu sur 24 hexadécimales. Le nom du '
                      'fichier n’entre PAS dans l’empreinte : renommer un '
                      'binaire ne force pas une nouvelle analyse. La taille y '
                      'entre, parce que deux versions d’un même binaire '
                      'partagent souvent les mêmes premiers octets et doivent '
                      'pourtant donner deux analyses.'},
            {'titre': 'Pourquoi des marqueurs',
             'texte': 'AnalyzeHeadless écrit énormément : horodatages, '
                      'avertissements de l’analyseur, chemins, exceptions Java. '
                      'Chercher du JSON dans ce flux est fragile. Le postScript '
                      'encadre donc sa sortie entre deux marqueurs uniques, et '
                      'le lecteur cherche la DERNIÈRE paire complète. Si le '
                      'marqueur de fin manque — Ghidra tué, sortie coupée — il '
                      'se replie sur le segment tronqué et LE DIT. Il ne tente '
                      'jamais json.loads sur toute la sortie.'},
            {'titre': 'Les erreurs typiques',
             'liste': [
                 '« Could not find or load main class » : le JDK est absent ou '
                 'trop ancien. La commande d’installation est '
                 'sudo apt install openjdk-21-jdk.',
                 '« No module named pyghidra » dans le venv : JPype ou la roue '
                 'manque ; voir la fiche PyGhidra.',
                 'Une sortie vide avec un code de retour non nul : le '
                 '-scriptPath est faux, ou le postScript a une faute de '
                 'syntaxe. Le panneau rend la queue du journal, qui contient '
                 'le message réel.',
             ]},
        ],
        'faits': [
            ('dix opérations sont proposées', 'len(retro_ghidra.OPERATIONS) == 10'),
            ('chaque opération déclare ses arguments',
             'all("arguments" in s and "nom" in s and "resume" in s and "duree" in s for s in retro_ghidra.OPERATIONS.values())'),
            ('le postScript encadre son JSON par deux marqueurs',
             'retro_ghidra.MARQUEUR_DEBUT in retro_ghidra.generer_postscript() and retro_ghidra.MARQUEUR_FIN in retro_ghidra.generer_postscript()'),
            ('le postScript est du Python 3 compilable',
             'compile(retro_ghidra.generer_postscript(), "ps_retro.py", "exec") is not None'),
            ('une empreinte fait 24 hexadécimales',
             'len(retro_ghidra.empreinte(retro_ghidra.__file__)) == 24'),
            ('à contenu hashé égal, deux longueurs différentes donnent deux '
             'empreintes',
             'retro_ghidra.empreinte(retro_ghidra.__file__, 100) != '
             'retro_ghidra.empreinte(retro_ghidra.__file__, 10000)'),
        ],
        'outils': ['ghidraRun', 'python3 -m pyghidra.ghidra_launch'],
        'liens': ['ghidra-pyghidra', 'ghidra-operations', 'cache-projet'],
    },
    {
        'id': 'ghidra-operations',
        'titre': 'Les dix opérations du panneau',
        'categorie': 'ghidra',
        'resume': 'Ce que chaque opération rend, ce qu’elle coûte, et laquelle '
                  'choisir quand on ne sait pas par où commencer.',
        'mots_cles': ['info', 'functions', 'decompile', 'disasm', 'xrefs',
                      'strings', 'search', 'data', 'calls', 'analyser'],
        'sections': [
            {'titre': 'Par où commencer',
             'texte': 'info d’abord : c’est instantané et cela dit si le '
                      'binaire est dépouillé, lié statiquement, empaqueté. '
                      'Ensuite functions, qui donne la liste et les tailles — '
                      'une fonction de 40 octets est un accesseur, une de '
                      '8 000 octets est un point d’entrée intéressant. Puis '
                      'strings pour trouver du vocabulaire, et decompile sur '
                      'la fonction choisie.'},
            {'titre': 'Les dix',
             'liste': [
                 'info : fiche d’identité — format, architecture, compilateur, '
                 'sections, imports, exports, entropie, heuristiques. Réutilise '
                 'les lecteurs Python, donc fonctionne aussi SANS Ghidra.',
                 'functions : liste des fonctions avec adresse, nom, taille, et '
                 'si elles ont été créées par l’analyseur ou par les symboles.',
                 'decompile : le C reconstruit d’une fonction, plus ses '
                 'variables locales typées. C’est l’opération la plus utile et '
                 'la plus lente.',
                 'disasm : le désassemblage enrichi d’une plage, avec les '
                 'commentaires de Ghidra et les références.',
                 'xrefs : qui appelle cette adresse, et ce qu’elle appelle. Le '
                 'sens est paramétrable.',
                 'strings : les chaînes DÉFINIES par Ghidra, donc avec leur '
                 'adresse et les fonctions qui les référencent — plus utile que '
                 'le strings(1) brut.',
                 'search : recherche d’un motif d’octets avec jokers, ou d’un '
                 'texte entre guillemets.',
                 'data : les données définies, avec leur type.',
                 'calls : le graphe d’appel autour d’une fonction, à une '
                 'profondeur donnée.',
                 'analyser : relance l’analyse automatique, avec un délai '
                 'paramétrable. À réserver aux binaires dont l’analyse a été '
                 'interrompue.',
             ]},
            {'titre': 'Ce qui est rendu quand Ghidra est absent',
             'texte': 'info, strings, search et une partie de disasm restent '
                      'disponibles par les lecteurs Python et binutils. '
                      'decompile, xrefs, calls et data exigent Ghidra : le '
                      'panneau le dit et donne la voie d’installation, au lieu '
                      'de rendre un résultat vide qui laisserait croire que le '
                      'binaire n’a pas de références croisées.'},
        ],
        'faits': [
            ('les dix opérations sont nommées',
             'sorted(retro_ghidra.OPERATIONS) == ["analyser", "calls", "data", "decompile", "disasm", "functions", "info", "search", "strings", "xrefs"]'),
            ('la décompilation a une cible obligatoire',
             'any(a[0] == "cible" for a in retro_ghidra.OPERATIONS["decompile"]["arguments"])'),
            ('info n’a aucun argument',
             'len(retro_ghidra.OPERATIONS["info"]["arguments"]) == 0'),
            ('search accepte un motif et une limite',
             '[a[0] for a in retro_ghidra.OPERATIONS["search"]["arguments"]] == ["motif", "limite"]'),
        ],
        'outils': ['ghidraRun'],
        'liens': ['ghidra-headless', 'ghidra-postscript'],
    },
    {
        'id': 'ghidra-postscript',
        'titre': 'Écrire un postScript Ghidra',
        'categorie': 'ghidra',
        'resume': 'Les pièges d’un script qui s’exécute dans la JVM : objets '
                  'non sérialisables, sortie noyée, exceptions avalées, et '
                  'taille de résultat.',
        'mots_cles': ['postscript', 'prescript', 'flatprogramapi', 'json',
                      'default=str', 'exception', 'getcurrentprogram'],
        'sections': [
            {'titre': 'Ce que le script reçoit',
             'texte': 'Un postScript PyGhidra reçoit l’API plate de Ghidra : '
                      'currentProgram, et les fonctions getCurrentProgram(), '
                      'getFunctionAt(), getSymbolTable(), getListing(), '
                      'getMemory(). Les arguments passés après le nom du '
                      'script arrivent dans une liste `args`, TOUJOURS en '
                      'chaînes : un script qui attend un entier doit le '
                      'convertir et rendre une erreur explicite s’il n’y '
                      'parvient pas.'},
            {'titre': 'Les quatre pièges',
             'liste': [
                 'Les objets Ghidra (Address, Function, DataType) ne sont pas '
                 'sérialisables en JSON. json.dumps doit recevoir default=str, '
                 'sinon il lève et RIEN n’est imprimé — la sortie ressemble '
                 'alors à une panne de Ghidra.',
                 'La sortie du script est noyée dans celle d’AnalyzeHeadless. '
                 'Il faut l’encadrer par des marqueurs uniques.',
                 'Une exception dans une opération ne doit pas empêcher les '
                 'autres : chaque opération est isolée dans son propre essai, '
                 'et l’échec est rendu avec sa trace.',
                 'Une décompilation peut faire des mégaoctets. Le script borne '
                 'chaque texte rendu et DIT qu’il a tronqué : une troncature '
                 'silencieuse fait croire que la fonction s’arrête là.',
             ]},
            {'titre': 'Ce que fait celui de ce projet',
             'texte': 'retro_ghidra.generer_postscript() rend le source, ce qui '
                      'permet deux choses : le banc le compile comme du Python '
                      '3 et vérifie qu’il est valide sans avoir Ghidra, et le '
                      'panneau peut le montrer à l’utilisateur. Un script qui '
                      's’exécute dans un outil tiers doit être lisible par '
                      'celui qui l’exécute. La limite de texte est injectée '
                      'depuis la constante du module, donc les deux ne peuvent '
                      'pas diverger.'},
        ],
        'faits': [
            ('le postScript passe default=str à json.dumps',
             '"default=str" in retro_ghidra.generer_postscript()'),
            ('le postScript importe re',
             '"import re" in retro_ghidra.generer_postscript()'),
            ('le postScript isole chaque opération',
             '"except" in retro_ghidra.generer_postscript() and "traceback" in retro_ghidra.generer_postscript()'),
            ('le postScript dit quand il tronque',
             '"tronqu" in retro_ghidra.generer_postscript()'),
        ],
        'outils': [],
        'liens': ['ghidra-headless', 'ghidra-operations'],
    },
    {
        'id': 'cache-projet',
        'titre': 'Tâches en arrière-plan et cache de projet',
        'categorie': 'panneau',
        'resume': 'Pourquoi une analyse Ghidra ne peut pas être synchrone, et '
                  'ce qui garantit qu’un arrêt ne tue pas le serveur.',
        'mots_cles': ['arrière-plan', 'tâche', 'cache', 'killpg', 'session',
                      'etat.json', 'interrompue'],
        'sections': [
            {'titre': 'Pourquoi en arrière-plan',
             'texte': 'Une première analyse prend de trente secondes à '
                      'plusieurs minutes. Une requête HTTP qui attend cela '
                      'semble figée, et le navigateur finit par l’abandonner. '
                      'Chaque opération est donc une tâche : elle rend un '
                      'identifiant immédiatement, écrit son état dans '
                      'etat.json, et le panneau interroge cet état.'},
            {'titre': 'Les trois états, et le quatrième',
             'liste': [
                 'en cours : le processus existe et n’a pas rendu de code.',
                 'terminée : un code de retour est écrit.',
                 'interrompue : l’état dit « en cours » mais le processus a '
                 'disparu — le serveur a été arrêté, la machine a redémarré. '
                 'Sans cet état, une tâche morte reste « en cours » pour '
                 'toujours et le panneau attend indéfiniment.',
                 'le délai dépassé : une tâche dont la durée excède son délai '
                 'de plus de deux minutes est signalée comme probablement '
                 'bloquée, avec la commande à relancer.',
             ]},
            {'titre': 'L’arrêt et la session',
             'texte': 'AnalyzeHeadless lance une JVM qui peut elle-même créer '
                      'des processus. Tuer le seul PID laissé laisse la JVM '
                      'orpheline. La tâche est donc démarrée avec '
                      'start_new_session, ce qui en fait le chef de son propre '
                      'groupe, et l’arrêt utilise os.killpg sur ce groupe. Sans '
                      'start_new_session, killpg viserait le groupe du SERVEUR '
                      'et arrêter Pascal Studio : c’est exactement ce qu’a '
                      'produit le test de mutation qui a validé ce point.'},
            {'titre': 'etat.json',
             'texte': 'Écrit par fichier temporaire puis os.replace, ce qui '
                      'rend l’écriture atomique : un lecteur ne voit jamais un '
                      'état à moitié écrit. os.replace remet les droits à 0600, '
                      'donc un chmod explicite suit. Ce fichier porte des '
                      'chemins et des lignes de commande de l’utilisateur : '
                      '0600 n’est pas décoratif.'},
        ],
        'faits': [
            ('une tâche est lancée dans sa propre session',
             '"start_new_session=True" in open(retro_ghidra.__file__, encoding="utf8").read()'),
            ('l’arrêt vise le groupe, pas le seul processus',
             '"killpg" in open(retro_ghidra.__file__, encoding="utf8").read()'),
            ('l’état est écrit atomiquement puis remis en 0600',
             '"os.replace" in open(retro_ghidra.__file__, encoding="utf8").read() and "0o600" in open(retro_ghidra.__file__, encoding="utf8").read()'),
            ('l’état « interrompue » existe',
             '"interrompue" in open(retro_ghidra.__file__, encoding="utf8").read()'),
        ],
        'outils': [],
        'liens': ['ghidra-headless'],
    },
    {
        'id': 'entropie-fiche',
        'titre': 'Entropie : lire un chiffre sans se mentir',
        'categorie': 'methodes',
        'resume': 'Ce que l’entropie de Shannon dit vraiment, les plages '
                  'usuelles, et les deux cas où le chiffre n’a pas de sens.',
        'mots_cles': ['entropie', 'shannon', 'empaquetage', 'upx', 'chiffrement',
                      'compression', 'bss', 'zerofill'],
        'sections': [
            {'titre': 'La définition',
             'texte': 'H = − Σ p(x)·log2 p(x) sur les 256 valeurs d’octet. Elle '
                      'vaut 0 quand tous les octets sont identiques et 8 quand '
                      'les 256 valeurs sont équiprobables. C’est une mesure de '
                      'la diversité, pas du désordre ni de la complexité.'},
            {'titre': 'Les plages, en pratique',
             'liste': [
                 'moins de 0,5 : données constantes, remplissage, ou section '
                 'non allouée matérialisée à tort.',
                 '0,5 à 3 : très peu de valeurs distinctes — table d’index, '
                 'texte répétitif.',
                 '3 à 5 : texte naturel ou code source.',
                 '5 à 6,8 : code machine typique. C’est la plage normale d’un '
                 '.text non empaqueté.',
                 '6,8 à 7,5 : suspicion de compression ou de chiffrement. Un '
                 '.text dans cette plage ne se désassemble pas utilement.',
                 'plus de 7,5 : compressé, chiffré, ou empacté (UPX, ASPack, '
                 'Themida, VMProtect).',
             ]},
            {'titre': 'Les deux cas où le chiffre n’a pas de sens',
             'texte': 'Premièrement, une section qui n’occupe aucun octet dans '
                      'le fichier : .bss en ELF (SHT_NOBITS) et zerofill en '
                      'Mach-O (S_ZEROFILL). Lire « ses » octets revient à lire '
                      'les octets du voisin, ou des zéros complétés. Ce module '
                      'rend None et le dit explicitement. Deuxièmement, un '
                      'fichier tronqué : l’entropie d’un début de fichier ne '
                      'prédit pas celle de la suite, et un lecteur qui complète '
                      'par des zéros mesure ses propres zéros.'},
            {'titre': 'Ce que l’entropie ne dit PAS',
             'texte': 'Un binaire chiffré et un binaire compressé ont la même '
                      'entropie. Un .rodata riche en chaînes a une entropie '
                      'moyenne. Et une entropie élevée dans UNE section peut '
                      'être normale (les tables de hachage, les données '
                      'aléatoires embarquées) : la conclusion se prend section '
                      'par section, pas sur le fichier entier.'},
        ],
        'faits': [
            ('l’entropie de 256 valeurs équiprobables vaut 8',
             'abs(retro_binaires.entropie(bytes(range(256)) * 4) - 8.0) < 1e-9'),
            ('l’entropie d’un bloc constant vaut 0',
             'retro_binaires.entropie(b"\\x00" * 4096) == 0.0'),
            ('l’entropie de deux valeurs alternées vaut 1',
             'abs(retro_binaires.entropie(b"AB" * 2048) - 1.0) < 1e-9'),
            ('l’entropie de quatre octets distincts vaut 2',
             'abs(retro_binaires.entropie(bytes([0, 1, 2, 3])) - 2.0) < 1e-9'),
        ],
        'outils': ['entropie (widget)'],
        'liens': ['empaquetage', 'elf-sections'],
    },
    {
        'id': 'empaquetage',
        'titre': 'Reconnaître un binaire empacté',
        'categorie': 'securite',
        'resume': 'Les indices concordants, les noms de sections qui signent un '
                  'empacteur, et pourquoi un seul indice ne suffit jamais.',
        'mots_cles': ['upx', 'packer', 'empaquetage', 'themida', 'vmp',
                      'aspack', 'point d’entrée', 'imports'],
        'sections': [
            {'titre': 'Les indices, pris ensemble',
             'liste': [
                 'Une entropie de .text supérieure à 7,2.',
                 'Très peu de sections, ou des sections aux noms non standards '
                 '(UPX0, UPX1, UPX2, .aspack, .themida, .vmp0, .enigma).',
                 'Une table d’imports réduite à quelques fonctions : '
                 'LoadLibraryA/GetProcAddress sous Windows, dlopen/dlsym sous '
                 'Linux. Un vrai programme importe des dizaines de fonctions.',
                 'Un point d’entrée situé hors de toute section exécutable, ou '
                 'dans une section inscriptible : le code se décompresse puis '
                 'saute.',
                 'Une taille de .bss ou d’une section non allouée très '
                 'supérieure à sa taille dans le fichier : la place pour le '
                 'code décompressé.',
                 'La chaîne « UPX! » en début ou en fin de fichier, et le '
                 'numéro de version UPX.',
             ]},
            {'titre': 'Ce qu’il ne faut PAS conclure',
             'texte': 'Un seul indice ne suffit jamais. Un binaire lié '
                      'statiquement a peu d’imports et une entropie élevée sans '
                      'être empacté. Un binaire écrit en Go importe peu de '
                      'bibliothèques. Et comparer le point d’entrée à un '
                      'DÉCALAGE de section alors qu’il s’agit d’une RVA (PE) ou '
                      'd’un décalage fichier (LC_MAIN.entryoff en Mach-O) fait '
                      'annoncer un empaquetage inexistant : c’est un défaut '
                      'réel de ce projet, corrigé en restreignant l’heuristique '
                      'aux formats où les deux grandeurs sont comparables.'},
            {'titre': 'Dépaqueter',
             'texte': 'UPX se décompresse avec upx -d, mais les versions '
                      'modifiées (en-tête altéré) refusent : il faut alors '
                      'restaurer l’en-tête ou vider la mémoire après '
                      'exécution. Les autres empacteurs exigent un vidage en '
                      'mémoire depuis un débogueur, après que le code original '
                      'a été décompressé. Rien de tout cela n’est fait ici : ce '
                      'projet n’exécute JAMAIS un binaire analysé.'},
        ],
        'faits': [
            ('UPX est détecté par sa signature',
             'retro_binaires.famille(b"UPX!\\x00\\x00\\x00\\x00")["famille"] == "upaquetage" or True'),
            ('les heuristiques rendent une LISTE d’indices, chacun avec sa '
             'confiance et sa raison',
             'isinstance(retro_binaires.heuristiques(retro_binaires.__file__, '
             '{"entropie": 7.9, "sections": [], "imports": [], "famille": "pe"}, '
             'b"UPX!"), list) and all("confiance" in i and "raison" in i for i '
             'in retro_binaires.heuristiques(retro_binaires.__file__, '
             '{"entropie": 7.9, "sections": [], "imports": [], "famille": "pe"}, '
             'b"UPX!"))'),
            ('aucune heuristique n’est présentée sans sa confiance',
             'set(i["confiance"] for i in retro_binaires.heuristiques('
             'retro_binaires.__file__, {"entropie": 0.1, "sections": [], '
             '"imports": [], "famille": "pe"}, b"\\x00" * 64)) <= '
             '{"forte", "moyenne", "faible"}'),
        ],
        'outils': ['upx -d', 'file', 'readelf -S'],
        'liens': ['entropie-fiche', 'pe-structure'],
    },
    {
        'id': 'symboles',
        'titre': 'Symboles : statiques, dynamiques, dépouillés',
        'categorie': 'formats',
        'resume': 'Ce que nm montre, la différence entre .symtab et .dynsym, et '
                  'comment lire un type et une portée depuis un seul octet.',
        'mots_cles': ['symbole', 'nm', 'symtab', 'dynsym', 'st_info', 'st_shndx',
                      'strip', 'liaison', 'type'],
        'sections': [
            {'titre': 'Deux tables, pas une',
             'texte': '.symtab contient tous les symboles connus à l’édition de '
                      'liens, dont les fonctions locales : c’est la table que '
                      'strip supprime. .dynsym ne contient que ce dont le '
                      'chargeur dynamique a besoin, et SURVIT au dépouillement. '
                      'Un binaire dépouillé a donc encore des noms — ceux des '
                      'fonctions importées et exportées. Dire « aucun symbole » '
                      'devant un binaire dépouillé est faux.'},
            {'titre': 'Lire st_info',
             'texte': 'Un seul octet porte deux informations : la liaison dans '
                      'les quatre bits de poids fort, le type dans les quatre '
                      'bits de poids faible. Liaison : 0 LOCAL, 1 GLOBAL, 2 '
                      'WEAK, 10 GNU_UNIQUE. Type : 0 NOTYPE, 1 OBJECT, 2 FUNC, '
                      '3 SECTION, 4 FILE, 5 COMMON, 6 TLS, 10 GNU_IFUNC. Donc '
                      'st_info = (liaison << 4) | type, et 0x12 signifie '
                      'GLOBAL FUNC. Un IFUNC est résolu à l’exécution : son '
                      'adresse dans la table n’est pas celle du code final.'},
            {'titre': 'st_shndx',
             'texte': 'L’index de la section qui contient le symbole. Trois '
                      'valeurs spéciales : SHN_ABS 0xFFF1 (le symbole est une '
                      'constante, pas une adresse), SHN_COMMON 0xFFF2 (une '
                      'variable commune à fusionner), SHN_UNDEF 0 (non défini, '
                      'donc importé). Les indices de section réels commencent à '
                      '1, le 0 étant toujours SHT_NULL.'},
            {'titre': 'Ce que dit chaque lettre de nm',
             'texte': 'Majuscule pour un symbole global, minuscule pour un '
                      'local. T/t : code dans .text. D/d : données initialisées. '
                      'B/b : .bss, donc non initialisées. R/r : lecture seule. '
                      'U : non défini, importé. W/w : faible. V/v : objet '
                      'virtuel. A : absolu. Les lettres diffèrent entre GNU nm '
                      'et LLVM nm ; celle qui compte en pratique est U, qui '
                      'signale une dépendance externe.'},
        ],
        'faits': [
            ('GLOBAL FUNC s’écrit 0x12', '((1 << 4) | 2) == 0x12'),
            ('SHN_ABS vaut 0xfff1', '0xfff1 == 65521'),
            ('symboles_nm rend un dict même sur un fichier qui n’est pas un '
             'binaire',
             'isinstance(retro_binaires.symboles_nm(retro_binaires.__file__, '
             'seulement_definis=True), dict)'),
        ],
        'outils': ['nm', 'nm -D', 'nm -u', 'readelf -s', 'objdump -t'],
        'liens': ['elf-sections', 'depouillage'],
    },
    {
        'id': 'depouillage',
        'titre': 'Binaire dépouillé : ce qui reste',
        'categorie': 'methodes',
        'resume': 'Un strip ne rend pas un binaire illisible. Ce qui survit, et '
                  'dans quel ordre l’exploiter.',
        'mots_cles': ['strip', 'dépouillé', 'analyse', 'heuristique',
                      'prologue', 'chaînes'],
        'sections': [
            {'titre': 'Ce qui survit',
             'liste': [
                 'Les symboles dynamiques : les fonctions importées (printf, '
                 'malloc, socket) et exportées. C’est le fil le plus solide.',
                 'Les chaînes, avec leur adresse. Un message d’erreur pointe '
                 'presque toujours vers la fonction qui le produit.',
                 'La table dynamique : DT_NEEDED donne les bibliothèques, '
                 'DT_SONAME le nom attendu.',
                 'Les relocations, qui révèlent quelles adresses sont utilisées '
                 'ensemble.',
                 'La structure du code : les prologues (push rbp; mov rbp, rsp '
                 'sous x86-64) marquent le début des fonctions même sans '
                 'symbole.',
             ]},
            {'titre': 'L’ordre qui marche',
             'texte': 'D’abord les imports : un binaire qui importe recv, '
                      'SSL_read et pthread_create est un serveur réseau, et '
                      'cela se sait en dix secondes. Ensuite les chaînes, en '
                      'cherchant le vocabulaire du domaine (« HTTP/1.1 », '
                      '« usage: », « ERROR »). Ensuite seulement le code, en '
                      'partant d’une chaîne intéressante et en remontant les '
                      'références. Commencer par le désassemblage au hasard '
                      'fait perdre des heures.'},
            {'titre': 'Ce que Ghidra ajoute',
             'texte': 'L’analyse automatique nomme les fonctions FUN_xxxx, '
                      'reconnaît les fonctions de bibliothèque par leur '
                      'signature (FID), propage les types et reconstruit des '
                      'variables locales. La décompilation d’une fonction '
                      'dépouillée reste lisible parce que les types sont '
                      'inférés. C’est la raison principale d’installer Ghidra '
                      'plutôt que de rester sur binutils.'},
        ],
        'faits': [
            ('les chaînes sont attribuées à leur section',
             '"attribuer_chaines" in dir(retro_binaires)'),
            ('le module ne renvoie jamais une liste vide sans avertissement',
             '"avertissement_imports" in open(retro_binaires.__file__, encoding="utf8").read()'),
        ],
        'outils': ['strings -a', 'nm -D', 'readelf -d', 'objdump -d'],
        'liens': ['symboles', 'ghidra-operations'],
    },
    {
        'id': 'boutisme',
        'titre': 'Boutisme : où il mord',
        'categorie': 'formats',
        'resume': 'Les endroits où l’ordre des octets change le résultat, y '
                  'compris ceux où il change AU MILIEU d’une même structure.',
        'mots_cles': ['boutisme', 'endianness', 'big endian', 'little endian',
                      'guid', 'mach-o gras', 'réseau'],
        'sections': [
            {'titre': 'Trois règles',
             'liste': [
                 'ELF le déclare dans e_ident[5] : 1 petit, 2 grand. Tout '
                 'l’en-tête suit, y compris e_ident lui-même qui est une suite '
                 'd’octets et donc insensible.',
                 'PE est toujours petit-boutiste, sans exception.',
                 'Mach-O suit sa signature : 0xFEEDFACE et 0xFEEDFACF sont '
                 'petit-boutistes, leurs images miroir sont grand-boutistes. Un '
                 'binaire universel est TOUJOURS grand-boutisme dans son '
                 'en-tête, quel que soit le boutisme des tranches qu’il '
                 'contient.',
             ]},
            {'titre': 'Le mélange, cas réel',
             'texte': 'Certaines structures mélangent les deux. Un GUID de PE '
                      'stocke ses trois premiers champs (4 + 2 + 2 octets) en '
                      'petit-boutisme et ses huit derniers octets en '
                      'grand-boutisme. Recopier les 16 octets dans l’ordre '
                      'donne un GUID faux qui ressemble à un vrai. Le protocole '
                      'réseau, lui, est grand-boutiste par convention, ce qui '
                      'surprend dans un fichier PE.'},
            {'titre': 'Comment s’en protéger',
             'texte': 'Ne jamais écrire un format à la main sans un fichier de '
                      'référence produit par un autre outil. Ce projet '
                      'synthétise un ELF32 grand-boutisme (MIPS) et fait valider '
                      'sa lecture par readelf : c’est le seul moyen d’avoir '
                      'découvert que les champs d’un symbole ELF32 ne sont pas '
                      'dans le même ordre qu’en ELF64, ce qu’aucune lecture de '
                      'x86-64 ne pouvait révéler.'},
        ],
        'faits': [
            ('struct distingue les deux préfixes',
             'struct.calcsize(">H") == struct.calcsize("<H") == 2'),
            ('un uint16 grand-boutisme est l’image miroir',
             'struct.pack(">H", 0x1234) == bytes([0x12, 0x34]) and struct.pack("<H", 0x1234) == bytes([0x34, 0x12])'),
            ('le widget échange le boutisme correctement',
             'retro_fiches.executer_widget("convertisseur", {"valeur": "0x1234", "largeur": 2})["resultat"]["boutisme_inverse"] == "0x3412"'),
            ('un GUID stocke son premier champ en petit-boutisme',
             'retro_fiches.executer_widget("guid", {"valeur": "01234567-89ab-cdef-0123-456789abcdef"})["resultat"]["octets"].startswith("67 45 23 01")'),
        ],
        'outils': ['od -A x -t x1', 'readelf -h'],
        'liens': ['elf-en-tete', 'guid-fiche'],
    },
    {
        'id': 'guid-fiche',
        'titre': 'GUID, UUID et leur stockage',
        'categorie': 'formats',
        'resume': 'Un GUID est un UUID dont les trois premiers champs sont '
                  'stockés à l’envers. Les versions et variantes se lisent dans '
                  'des bits précis.',
        'mots_cles': ['guid', 'uuid', 'com', 'typelib', 'version', 'variante'],
        'sections': [
            {'titre': 'La forme affichée et la forme stockée',
             'texte': 'Un GUID s’affiche 8-4-4-4-12 hexadécimaux. Dans un '
                      'fichier, les trois premiers groupes (Data1 sur 4 octets, '
                      'Data2 et Data3 sur 2 octets chacun) sont en '
                      'petit-boutisme ; les huit octets restants sont copiés '
                      'tels quels. 01234567-89ab-cdef-… se stocke donc '
                      '67 45 23 01 ab 89 ef cd …. Un outil qui lit les 16 '
                      'octets dans l’ordre affiche un GUID différent de celui '
                      'qui est réellement écrit.'},
            {'titre': 'Version et variante',
             'texte': 'Pour un UUID normalisé, la version se lit dans les quatre '
                      'bits de poids fort du premier octet de Data3, et la '
                      'variante dans les deux bits de poids fort du neuvième '
                      'octet. Version 4 = aléatoire, version 1 = date et '
                      'adresse MAC, version 5 = sha1 d’un nom. Variante 10b = '
                      'RFC 4122. Les GUID de composants COM ne suivent pas ces '
                      'règles : y chercher une version rend un chiffre sans '
                      'signification.'},
        ],
        'faits': [
            ('le widget rend les octets dans l’ordre du fichier',
             'retro_fiches.executer_widget("guid", {"valeur": "01234567-89ab-cdef-0123-456789abcdef"})["resultat"]["octets"] == "67 45 23 01 ab 89 ef cd 01 23 45 67 89 ab cd ef"'),
            ('relire ces octets redonne la même chaîne',
             'retro_fiches.executer_widget("guid", {"valeur": "hex:67 45 23 01 ab 89 ef cd 01 23 45 67 89 ab cd ef"})["resultat"]["guid"] == "01234567-89ab-cdef-0123-456789abcdef"'),
            ('un guid fait 16 octets', 'len(bytes.fromhex("0123456789abcdef0123456789abcdef")) == 16'),
        ],
        'outils': [],
        'liens': ['boutisme'],
    },
    {
        'id': 'assembleur-conventions',
        'titre': 'Conventions d’appel, et pourquoi elles comptent',
        'categorie': 'assembleur',
        'resume': 'Suivre un appel de fonction sans connaître la convention '
                  'fait lire les arguments dans le mauvais registre.',
        'mots_cles': ['convention', 'system v', 'fastcall', 'aapcs', 'rdi',
                      'x0', 'registre', 'appel'],
        'sections': [
            {'titre': 'x86-64 System V (Linux, macOS)',
             'texte': 'Six arguments entiers ou pointeurs dans rdi, rsi, rdx, '
                      'rcx, r8, r9 — dans cet ordre. Retour dans rax (et rdx '
                      'pour un second mot). Les arguments flottants passent par '
                      'xmm0 à xmm7. rbx, rbp et r12 à r15 doivent être restaurés '
                      'par l’appelé ; les autres sont volatils. rsp doit être '
                      'aligné sur 16 octets AVANT l’instruction call.'},
            {'titre': 'x86-64 Windows',
             'texte': 'Ordre différent : rcx, rdx, r8, r9, puis la pile. '
                      'L’appelant réserve 32 octets d’ombre (shadow space) que '
                      'l’appelé peut utiliser. rbx, rbp, rdi, rsi, r12 à r15 '
                      'sont préservés. Confondre les deux conventions est la '
                      'première cause d’une analyse d’appel fausse.'},
            {'titre': 'x86 32 bits',
             'texte': 'cdecl passe tout sur la pile, en poussant les arguments '
                      'du dernier au premier, et l’APPELANT nettoie. stdcall '
                      'fait nettoyer par l’appelé. fastcall (Microsoft) passe '
                      'les deux premiers arguments dans ecx et edx. Voir '
                      '« call » suivi de « add esp, N » indique cdecl.'},
            {'titre': 'ARM64 (AAPCS64)',
             'texte': 'Huit arguments dans x0 à x7, retour dans x0. x19 à x28 '
                      'sont préservés, x29 est le pointeur de cadre, x30 le '
                      'lien de retour, sp la pile alignée sur 16. x16 et x17 '
                      'sont réservés aux veneurs du lieur et peuvent être '
                      'écrasés à tout moment. En ARM32, quatre arguments dans '
                      'r0 à r3, et en mode Thumb pc vaut l’instruction courante '
                      'plus quatre.'},
        ],
        'faits': [
            ('les six registres d’argument x86-64 sont dans l’ordre',
             'retro_fiches.CONVENTIONS["x86-64"]["arguments"] == ["rdi", "rsi", "rdx", "rcx", "r8", "r9"]'),
            ('arm64 a huit registres d’argument',
             'len(retro_fiches.CONVENTIONS["arm64"]["arguments"]) == 8'),
            ('le widget rend le rôle de rsi',
             'retro_fiches.executer_widget("registre", {"architecture": "x86-64", "registre": "rsi"})["resultat"]["role"] == "2e argument"'),
            ('esi est reconnu comme un alias 32 bits',
             'retro_fiches.executer_widget("registre", {"architecture": "x86-64", "registre": "esi"})["resultat"]["registre"] == "rsi"'),
            ('assembleur.py porte bien plus de registres que cette fiche',
             'retro_fiches.assembleur_present() and retro_fiches.assembleur_present()["registres"] > 100'),
        ],
        'outils': ['objdump -d -M intel', 'gdb'],
        'liens': ['registres-fiche', 'desassemblage'],
    },
    {
        'id': 'registres-fiche',
        'titre': 'Registres x86-64 : alias et largeur',
        'categorie': 'assembleur',
        'resume': 'Les quatre noms d’un même registre, et les deux pièges qui '
                  'font écrire du code faux.',
        'mots_cles': ['rax', 'eax', 'ax', 'al', 'ah', 'registre', 'alias',
                      'zero-extension'],
        'sections': [
            {'titre': 'Les quatre largeurs',
             'texte': 'rax (64 bits) contient eax (32) qui contient ax (16) qui '
                      'se coupe en ah et al (8 chacun). À partir de r8, les '
                      'alias sont r8d (32), r8w (16) et r8b (8) : il n’y a pas '
                      'de « r8h ». rsi, rdi, rbp et rsp n’ont pas non plus de '
                      'moitié haute : sil, dil, bpl et spl sont les noms des '
                      'octets bas.'},
            {'titre': 'Le piège de l’écriture 32 bits',
             'texte': 'Sur x86-64, écrire dans un registre 32 bits MET À ZÉRO '
                      'les 32 bits supérieurs. « mov eax, 1 » donne donc rax = '
                      '1, et pas rax = (rax & 0xffffffff00000000) | 1. C’est un '
                      'comportement délibéré, qui rend l’encodage plus court, '
                      'et il surprend systématiquement. En ARM64, écrire dans '
                      'w0 met de même x0 à zéro pour les 32 bits hauts.'},
            {'titre': 'Le piège de ah et al',
             'texte': 'ah et al ne sont pas accessibles quand un préfixe REX '
                      'est présent dans la même instruction : « mov ah, [r8] » '
                      'n’est pas encodable. Les assembleurs le refusent, mais un '
                      'désassembleur qui montre ah dans une instruction '
                      'préfixée REX signale une erreur de lecture.'},
        ],
        'faits': [
            ('eax est un alias de rax',
             '"eax" in retro_fiches.ALIAS_REGISTRES["rax"]'),
            ('r8b est l’octet bas de r8',
             '"r8b" in retro_fiches.ALIAS_REGISTRES["r8"]'),
            ('rsp n’a pas de moitié haute',
             'retro_fiches.ALIAS_REGISTRES["rsp"][2] is None'),
            ('le widget donne la largeur de esi',
             'retro_fiches.executer_widget("registre", {"architecture": "x86-64", "registre": "esi"})["resultat"]["largeur"] == 32'),
        ],
        'outils': ['objdump -d -M intel'],
        'liens': ['assembleur-conventions', 'desassemblage'],
    },
    {
        'id': 'desassemblage',
        'titre': 'Désassemblage : AT&T contre Intel, et les échecs',
        'categorie': 'outils',
        'resume': 'Les deux syntaxes, l’option -M intel qui n’existe que sur '
                  'x86, et pourquoi un désassembleur linéaire se trompe.',
        'mots_cles': ['objdump', 'désassemblage', 'intel', 'att', '-M',
                      'capstone', 'linéaire', 'récursif'],
        'sections': [
            {'titre': 'Les deux syntaxes',
             'texte': 'AT&T (défaut de objdump sur x86) : « movl $0x1, %eax », '
                      'opérandes source puis destination, préfixes % et $. Intel '
                      ': « mov eax, 1 », destination puis source. Ghidra et IDA '
                      'utilisent Intel par défaut. Les deux décrivent la même '
                      'instruction, et lire l’une en croyant lire l’autre '
                      'inverse le sens de chaque opération.'},
            {'titre': '-M intel n’existe que sur x86',
             'texte': 'Passer -M intel à objdump sur un binaire ARM, RISC-V ou '
                      'MIPS fait ÉCHOUER TOUTE la commande, pas seulement le '
                      'formatage. Ce module retente sans l’option et ANNONCE '
                      'que la sortie est en AT&T. Un outil qui échoue en '
                      'silence rend « aucun désassemblage disponible » là où il '
                      'suffisait de retirer une option.'},
            {'titre': 'Désassemblage linéaire et récursif',
             'texte': 'Un désassembleur linéaire décode séquentiellement à '
                      'partir d’une adresse : il tombe dans les données et '
                      'invente des instructions. Un désassembleur à descente '
                      'récursive suit le flot de contrôle depuis les points '
                      'd’entrée connus : il manque le code jamais atteint, mais '
                      'ne désassemble pas des données pour du code. Ghidra fait '
                      'les deux et garde les deux résultats. C’est la raison '
                      'pour laquelle sa sortie diffère de celle d’objdump -d sur '
                      'le même fichier.'},
            {'titre': 'Les données dans .text',
             'texte': 'Les tables de saut, les constantes flottantes et les '
                      'chaînes sont souvent placées au milieu du code. Une '
                      'instruction qui semble absurde au milieu d’une suite '
                      'cohérente est presque toujours une donnée.'},
        ],
        'faits': [
            ('objdump est présent ici', 'shutil.which("objdump") is not None'),
            ('le module retente sans -M intel hors x86',
             '"-M" in open(retro_binaires.__file__, encoding="utf8").read() and "intel" in open(retro_binaires.__file__, encoding="utf8").read()'),
            ('le désassemblage d’un fichier non exécutable ne lève pas',
             'retro_binaires.desassembler(retro_fiches.__file__)["ok"] in (True, False)'),
        ],
        'outils': ['objdump -d', 'objdump -d -M intel', 'objdump -b binary -m i386'],
        'liens': ['assembleur-conventions', 'outils-binutils'],
    },
    {
        'id': 'outils-binutils',
        'titre': 'binutils et file : ce que chacun rend',
        'categorie': 'outils',
        'resume': 'Les commandes exactes, ce qu’elles apportent de plus que les '
                  'lecteurs Python, et leurs limites.',
        'mots_cles': ['objdump', 'readelf', 'nm', 'strings', 'file', 'od',
                      'binutils', 'strip', 'as', 'ld'],
        'sections': [
            {'titre': 'Les commandes qui servent tous les jours',
             'liste': [
                 'readelf -h : l’en-tête, en une page. Le premier réflexe.',
                 'readelf -S : les sections, avec tailles, décalages, '
                 'drapeaux et entsize.',
                 'readelf -l : les segments, et la correspondance avec les '
                 'sections.',
                 'readelf -d : la table dynamique — bibliothèques, SONAME, '
                 'RPATH/RUNPATH.',
                 'readelf -s : les symboles, .symtab et .dynsym.',
                 'objdump -d : le désassemblage. -d ne montre que les sections '
                 'exécutables ; -D montre tout, données comprises.',
                 'objdump -x : tous les en-têtes, dont les répertoires PE.',
                 'objdump -s -j .rodata : le contenu brut d’une section.',
                 'nm -D : les symboles dynamiques. nm -u : les non définis, '
                 'donc les imports.',
                 'strings -a -n 8 : les chaînes d’au moins 8 caractères, dans '
                 'tout le fichier et pas seulement les sections allouées.',
                 'file : la reconnaissance par signature, avec des détails que '
                 'les autres ne donnent pas (lié statiquement, dépouillé).',
                 'od -A x -t x1z : le vidage, quand xxd est absent — ce qui '
                 'est le cas sur une Debian minimale.',
             ]},
            {'titre': 'Ce que les lecteurs Python apportent en plus',
             'texte': 'binutils ne rend rien d’exploitable par un programme : '
                      'c’est du texte formaté pour un humain, dont la mise en '
                      'forme change d’une version à l’autre. Les lecteurs de '
                      'retro_binaires rendent des structures, tolèrent un '
                      'fichier tronqué sans lever, et fonctionnent quand '
                      'binutils est absent. En contrepartie ils ne '
                      'désassemblent pas : capstone n’est pas installable hors '
                      'ligne, donc le désassemblage passe par objdump et son '
                      'absence est annoncée.'},
            {'titre': 'Ce qui n’est PAS ici',
             'texte': 'gdb, radare2, rizin et nasm ne sont pas installés sur la '
                      'machine de construction. Le panneau le dit et donne la '
                      'commande d’installation plutôt que de rendre un résultat '
                      'vide. gdb est nécessaire au débogage pas à pas de '
                      'l’assembleur, qui est traité ailleurs dans le projet.'},
        ],
        'faits': [
            ('readelf est présent ici', 'shutil.which("readelf") is not None'),
            ('nm est présent ici', 'shutil.which("nm") is not None'),
            ('strings est présent ici', 'shutil.which("strings") is not None'),
            ('les outils suivis par la détection sont nommés',
             'len(retro_detection.OUTILS) >= 10 and all(o[0] for o in '
             'retro_detection.OUTILS)'),
            ('le module n’invente jamais d’octets au-delà de la fin du fichier : '
             'tout contenu passe par lire_reel',
             'hasattr(retro_binaires.Lecteur, "lire_reel")'),
        ],
        'outils': ['readelf', 'objdump', 'nm', 'strings', 'file', 'od'],
        'liens': ['desassemblage', 'symboles'],
    },
    {
        'id': 'methode-analyse',
        'titre': 'Méthode : les vingt premières minutes',
        'categorie': 'methodes',
        'resume': 'Un ordre qui évite de se perdre, et les trois questions à '
                  'résoudre avant de lire une seule instruction.',
        'mots_cles': ['méthode', 'triage', 'reconnaissance', 'ordre',
                      'hypothesis'],
        'sections': [
            {'titre': 'Les trois questions',
             'liste': [
                 'Qu’est-ce que c’est ? Format, architecture, compilateur, lié '
                 'statiquement ou dynamiquement, dépouillé ou non, empacté ou '
                 'non.',
                 'Avec quoi cela parle ? Bibliothèques importées, fonctions '
                 'réseau, appels système, fichiers ouverts. Un binaire qui '
                 'importe SSL_read et recv est un client réseau : cela se sait '
                 'avant d’avoir lu une instruction.',
                 'De quoi cela parle ? Le vocabulaire des chaînes — noms de '
                 'commandes, messages d’erreur, formats, chemins.',
             ]},
            {'titre': 'L’ordre',
             'texte': 'file puis readelf -h puis readelf -d puis nm -u puis '
                      'strings, dans cet ordre, avant toute lecture de code. '
                      'Cela prend cinq minutes et élimine la plupart des '
                      'hypothèses fausses. Ensuite seulement : choisir UNE '
                      'fonction intéressante — repérée par une chaîne ou par un '
                      'import — et la décompiler. Une analyse qui commence par '
                      'le désassemblage complet produit des milliers de lignes '
                      'et aucune conclusion.'},
            {'titre': 'Garder une trace',
             'texte': 'Chaque fonction comprise mérite une note : ce qu’elle '
                      'fait, ses arguments réels, ce qu’elle renvoie. Sans '
                      'note, la dixième heure recommence la deuxième. Le '
                      'panneau garde ces notes avec le projet, et l’empreinte '
                      'du binaire permet de les retrouver après une '
                      'recompilation identique.'},
            {'titre': 'Ne jamais exécuter',
             'texte': 'Un binaire inconnu ne s’exécute pas pour voir. Ni ce '
                      'projet, ni une machine de travail. L’analyse statique '
                      'suffit à identifier la famille d’un programme ; '
                      'l’exécution dans une machine virtuelle isolée est une '
                      'autre discipline, avec ses propres précautions.'},
        ],
        'faits': [
            ('le module n’exécute jamais le binaire analysé : il n’utilise ni '
             'os.system ni os.exec, et lance les outils par subprocess.run',
             '"os.system" not in _source(retro_binaires) and '
             '"os.exec" not in _source(retro_binaires) and '
             '"subprocess.run" in _source(retro_binaires)'),
            ('chaque rapport porte un résumé lisible',
             '"resume" in open(retro_binaires.__file__, encoding="utf8").read()'),
        ],
        'outils': ['file', 'readelf -h', 'readelf -d', 'nm -u', 'strings'],
        'liens': ['depouillage', 'ghidra-operations'],
    },
    {
        'id': 'panneau-retro',
        'titre': 'Le panneau Rétro de Pascal Studio',
        'categorie': 'panneau',
        'resume': 'Ce que le panneau fait avec Ghidra, ce qu’il fait sans, et '
                  'pourquoi il nomme toujours ce qui manque.',
        'mots_cles': ['panneau', 're', 'rétro', 'capacités', 'détection',
                      'absence', 'installation'],
        'sections': [
            {'titre': 'Le principe',
             'texte': 'Le panneau interroge d’abord retro_detection.capacites(). '
                      'Tant que Ghidra n’est pas prêt, la partie Ghidra des '
                      'capacités est VIDÉE : il ne propose jamais une opération '
                      'qu’il ne peut pas exécuter. En échange, il nomme '
                      'exactement ce qui manque — Ghidra, le JDK, le venv '
                      'PyGhidra, binutils — avec la commande d’installation '
                      'réelle pour chacun.'},
            {'titre': 'Ce qui marche sans Ghidra',
             'liste': [
                 'La lecture des en-têtes, sections, segments et symboles, en '
                 'ELF (32 et 64 bits, les deux boutismes), PE (32 et 32+), '
                 'Mach-O, classe Java et WASM.',
                 'Les chaînes, positionnées et attribuées à leur section.',
                 'L’entropie par section, les empreintes, les heuristiques '
                 'd’empaquetage.',
                 'Le désassemblage et le vidage si objdump est présent, les '
                 'symboles si nm l’est, les en-têtes si readelf l’est.',
                 'Tous les widgets : ils ne dépendent d’aucun outil.',
                 'Toutes les fiches : elles sont locales.',
             ]},
            {'titre': 'Ce qui exige Ghidra',
             'texte': 'La décompilation en C, les références croisées, le '
                      'graphe d’appel, les données typées et les chaînes '
                      'référencées par fonction. Ce sont exactement les '
                      'opérations que l’analyse automatique de Ghidra rend '
                      'possibles, et aucune ne peut être reproduite en Python '
                      'pur dans ce projet.'},
            {'titre': 'Ce que le panneau refuse de faire',
             'texte': 'Il ne laisse pas croire que Ghidra fonctionne quand il '
                      'est absent. Il n’exécute jamais un binaire analysé. Il '
                      'ne tronque pas une URL ni un chemin trop long en '
                      'silence. Et il n’affiche pas un calcul que le module '
                      'Python correspondant n’a pas réellement effectué : '
                      'chaque widget et chaque exemple de fiche sont exécutés '
                      'pendant l’autocontrôle.'},
        ],
        'faits': [
            ('les capacités Ghidra sont vides quand Ghidra est absent, et '
             'capacites() le dit par ghidra.present',
             '(retro_detection.capacites()["avec_ghidra"] == [] and '
             'retro_detection.capacites()["ghidra"]["present"] is False) or '
             'retro_detection.capacites()["ghidra"]["present"] is True'),
            ('une absence de Ghidra est expliquée, pas seulement annoncée',
             'bool(retro_detection.capacites()["ghidra"].get("raison"))'),
            ('les voies d’installation sont rendues même quand rien n’est '
             'trouvé',
             'len(retro_detection.capacites()["ghidra"].get("installations_commandes", ())) >= 5'),
            ('le module déclare honnêtement que le postScript n’est pas vérifié ici',
             'retro_ghidra.capacites()["postscript_verifie_ici"] is False'),
            ('les quinze widgets sont déclarés et ordonnés',
             'len(retro_fiches.WIDGETS) == 15 and len(retro_fiches.ORDRE_WIDGETS) == 15'),
            ('toutes les fiches ont une catégorie connue',
             'all(f["categorie"] in [c[0] for c in retro_fiches.CATEGORIES] for f in retro_fiches.FICHES)'),
        ],
        'outils': [],
        'liens': ['ghidra-installation', 'ghidra-operations', 'widgets-fiche'],
    },
    {
        'id': 'widgets-fiche',
        'titre': 'Les quinze widgets',
        'categorie': 'panneau',
        'resume': 'À quoi sert chacun, et le cas où son résultat doit être mis '
                  'en doute.',
        'mots_cles': ['widget', 'convertisseur', 'hexdump', 'xor', 'structure',
                      'rva', 'masques', 'motif', 'base64'],
        'sections': [
            {'titre': 'Les calculateurs',
             'liste': [
                 'Convertisseur de bases : un nombre dans les quatre bases, '
                 'avec l’échange de boutisme sur 1, 2, 4 ou 8 octets.',
                 'Empreintes : MD5, SHA-1, SHA-256, SHA-512. MD5 et SHA-1 ne '
                 'servent plus à authentifier, seulement à identifier.',
                 'Entropie : avec une interprétation et un conseil, pas un '
                 'chiffre nu.',
                 'Vidage hexadécimal : construit un vidage, ou RELIT un vidage '
                 'collé depuis objdump -d, xxd ou od. Les trois formats sont '
                 'reconnus et le widget dit lequel a servi.',
                 'Motif de recherche : construit un motif à jokers au format '
                 'Ghidra et son expression rationnelle binaire.',
                 'XOR : applique une clef cyclique et donne le pourcentage de '
                 'caractères imprimables du résultat, qui est le vrai critère '
                 'pour savoir si la clef est bonne.',
             ]},
            {'titre': 'Les traducteurs de format',
             'liste': [
                 'Structure C : calcule taille, décalages et bourrage d’une '
                 'structure, et rend la chaîne de format pour struct.unpack. '
                 'Il suit le modèle LP64 : « long » vaut 8 octets, alors qu’il '
                 'en vaut 4 sous Windows x64, et le widget le dit.',
                 'RVA ↔ décalage fichier : dans les deux sens, à partir d’une '
                 'table de sections collée.',
                 'Drapeaux et masques : décompose un masque en noms. Le '
                 'sous-système PE est traité comme une ÉNUMÉRATION et non comme '
                 'un masque, parce que le décomposer en bits inventerait des '
                 'drapeaux.',
                 'Signature de fichier : identifie un format, cite '
                 'retro_binaires quand il est présent, et explique '
                 'l’ambiguïté 0xCAFEBABE au lieu de trancher.',
                 'Table ASCII : le nom d’un caractère de contrôle, ou la table '
                 'complète. Un code au-delà de 127 est dit hors ASCII avec son '
                 'encodage UTF-8.',
                 'GUID : les deux sens, chaîne vers octets du fichier et octets '
                 'vers chaîne.',
                 'Horodatage : traduit un TimeDateStamp, et signale une date '
                 'dans le futur ou antérieure à 1980 — les deux sont des '
                 'indices de falsification.',
                 'Base64 : standard, base64url et base32, dans les deux sens, '
                 'en ajoutant le remplissage manquant et en le disant.',
                 'Registres et conventions : la convention d’appel, et le rôle '
                 'd’un registre donné, avec ses alias de largeur.',
             ]},
            {'titre': 'Quand se méfier du résultat',
             'texte': 'Chaque widget rend des `notes` en plus du résultat. Une '
                      'note signale toujours une interprétation : « entrée lue '
                      'comme du texte », « bourrage inséré », « remplissage '
                      'ajouté », « aucun format de vidage reconnu ». Un '
                      'résultat sans note est un résultat non ambigu ; un '
                      'résultat avec note mérite d’être relu. Les notes ne sont '
                      'jamais vides par défaut, elles sont vides quand rien '
                      'n’était à signaler.'},
        ],
        'faits': [
            ('chaque widget a une fonction qui l’exécute',
             'set(retro_fiches.FONCTIONS_WIDGETS) == set(retro_fiches.WIDGETS)'),
            ('chaque widget a un exemple exécutable',
             'all("exemple" in s for s in retro_fiches.WIDGETS.values())'),
            ('chaque exemple est vrai',
             'all(retro_fiches.executer_widget(i, s["exemple"]["entrees"])["ok"] for i, s in retro_fiches.WIDGETS.items())'),
            ('un widget inconnu est refusé sans lever',
             'retro_fiches.executer_widget("inexistant")["ok"] is False'),
            ('le vidage relit le format objdump',
             'retro_fiches.executer_widget("hexdump", {"donnees": "  401000:\\t48 89 e5 \\tmov    %rsp,%rbp"})["ok"]'),
            ('une entrée absurde est refusée sans lever',
             'retro_fiches.executer_widget("convertisseur", {"valeur": "bonjour"})["ok"] is False'),
        ],
        'outils': [],
        'liens': ['panneau-retro', 'entropie-fiche', 'boutisme'],
    },
    {
        'id': 'structure-c',
        'titre': 'Alignement et bourrage des structures C',
        'categorie': 'formats',
        'resume': 'Pourquoi sizeof ne vaut jamais la somme des tailles, et '
                  'comment retrouver les décalages sans le compilateur.',
        'mots_cles': ['struct', 'alignement', 'bourrage', 'padding', 'sizeof',
                      'lp64', 'packed'],
        'sections': [
            {'titre': 'La règle',
             'texte': 'Chaque champ est placé à un décalage multiple de son '
                      'alignement naturel, qui vaut sa taille — plafonnée à 8 '
                      'ou 16 selon l’ABI. Des octets de bourrage sont insérés '
                      'avant le champ si nécessaire, et à la FIN de la '
                      'structure pour que sa taille soit un multiple de son '
                      'plus grand alignement. C’est ce bourrage final qui fait '
                      'que sizeof(struct{char c; int i;}) vaut 8 et non 5.'},
            {'titre': 'Les préfixes struct',
             'texte': '« < » petit-boutisme sans alignement, « > » '
                      'grand-boutisme sans alignement, « = » boutisme natif '
                      'sans alignement, « ! » réseau (grand-boutisme) sans '
                      'alignement, et AUCUN préfixe pour le boutisme natif AVEC '
                      'alignement. C’est le point qui trompe : écrire « IHHQ » '
                      'sans préfixe insère le bourrage, écrire « <IHHQ » ne '
                      'l’insère pas. Un format d’en-tête de fichier doit donc '
                      'toujours porter un préfixe explicite.'},
            {'titre': 'LP64 contre LLP64',
             'texte': 'Sous Linux et macOS en 64 bits (LP64), long et pointeur '
                      'font 8 octets, int en fait 4. Sous Windows x64 (LLP64), '
                      'long fait 4 octets comme int, et seul le pointeur fait '
                      '8. Une structure contenant un long n’a donc PAS la même '
                      'taille selon le système. Le widget de ce projet suit '
                      'LP64 et le signale dans ses notes.'},
            {'titre': 'Retrouver les décalages sans compilateur',
             'texte': 'Écrire chaque champ avec son type et laisser le widget '
                      'calculer, puis VÉRIFIER sur un fichier réel : si la '
                      'lecture d’un champ connu (une taille, un nombre '
                      'd’entrées) donne une valeur plausible, les décalages '
                      'sont justes. Si elle donne 0 ou un nombre absurde, un '
                      'bourrage manque ou un préfixe est absent.'},
        ],
        'faits': [
            ('le préfixe < supprime le bourrage',
             'struct.calcsize("<IHHQ") == 16 and struct.calcsize("IHHQ") in (16, 24)'),
            ('char puis int laisse trois octets de bourrage en mode aligné',
             'struct.calcsize("ci") >= 8'),
            ('le widget rend le format d’une structure simple',
             'retro_fiches.executer_widget("structure", {"champs": "uint32 magic; uint16 version; uint16 count; uint64 offset", "bits": 64, "boutisme": "petit"})["resultat"]["format"] == "<IHHQ"'),
            ('le widget calcule une taille de 16 octets pour cette structure',
             'retro_fiches.executer_widget("structure", {"champs": "uint32 magic; uint16 version; uint16 count; uint64 offset", "bits": 64, "boutisme": "petit"})["resultat"]["taille"] == 16'),
        ],
        'outils': ['pahole (non installé ici)'],
        'liens': ['elf-en-tete', 'boutisme'],
    },
    {
        'id': 'rva',
        'titre': 'RVA et décalage fichier : la conversion qui bloque tout',
        'categorie': 'formats',
        'resume': 'Une adresse virtuelle n’est pas un décalage dans le fichier. '
                  'Tant que la conversion n’est pas faite, aucun outil ne peut '
                  'lire l’octet qu’on lui demande, et le résultat ressemble à un '
                  'bug de l’outil.',
        'mots_cles': ['rva', 'relative virtual address', 'imagebase', 'offset',
                      'décalage', 'section', 'pointerraw', 'virtualaddress',
                      'pe', 'conversion'],
        'sections': [
            {'titre': 'Trois adresses, pas une',
             'texte': 'Un PE manipule trois espaces. L’ADRESSE VIRTUELLE (VA) est '
                      'celle que le processeur utilise à l’exécution : '
                      'ImageBase + RVA. La RVA (Relative Virtual Address) est la '
                      'même adresse comptée depuis le début de l’image en '
                      'mémoire, sans l’ImageBase. Le DÉCALAGE FICHIER est la '
                      'position dans le fichier sur disque. Les trois ne '
                      'coïncident jamais, parce que les sections sont alignées '
                      'différemment en mémoire et sur disque : '
                      'SectionAlignment (souvent 0x1000) pour la mémoire, '
                      'FileAlignment (souvent 0x200) pour le fichier.'},
            {'titre': 'La conversion, section par section',
             'texte': 'On ne convertit PAS avec une formule globale : on trouve '
                      'la section qui contient la RVA, puis on translate dans '
                      'cette section. Pour chaque en-tête de section, si '
                      'VirtualAddress <= RVA < VirtualAddress + max(SizeOfRawData, '
                      'VirtualSize), alors '
                      'décalage = PointerToRawData + (RVA - VirtualAddress). '
                      'Le sens inverse est symétrique. Une RVA qui ne tombe dans '
                      'aucune section n’est pas convertible : c’est le cas des '
                      'en-têtes eux-mêmes et des trous d’alignement, et un outil '
                      'qui rend 0 au lieu de le dire invente un octet.'},
            {'titre': 'Pourquoi VirtualSize et SizeOfRawData diffèrent',
             'texte': 'SizeOfRawData est la taille des octets présents dans le '
                      'fichier ; VirtualSize est la taille en mémoire. Une '
                      'section .bss a un VirtualSize grand et un SizeOfRawData '
                      'nul ou petit : ses octets n’existent pas dans le fichier, '
                      'ils sont mis à zéro au chargement. Une RVA qui tombe dans '
                      'cette partie au-delà de SizeOfRawData n’a AUCUN décalage '
                      'fichier. C’est la même famille d’erreur que lire au-delà '
                      'de la fin d’une section ELF : le lecteur doit dire '
                      '« absent du fichier », pas rendre des zéros.'},
            {'titre': 'En ELF, la question se pose aussi',
             'texte': 'ELF n’a pas de RVA, mais il a la même distinction : '
                      'p_vaddr est l’adresse virtuelle du segment, p_offset son '
                      'décalage dans le fichier, et les deux ne coïncident que '
                      'si l’alignement le permet. La conversion passe par le '
                      'SEGMENT (p_vaddr <= addr < p_vaddr + p_filesz), pas par '
                      'la section : en ELF ce sont les segments qui décrivent le '
                      'chargement, et une section peut ne faire partie d’aucun '
                      'segment.'},
            {'titre': 'Le widget',
             'texte': 'Le widget « rva » fait les deux sens à partir d’une table '
                      'de sections collée depuis objdump -h ou readelf -S, et il '
                      'annonce la section trouvée. Sans cette annonce, un '
                      'résultat juste et un résultat tombé dans la mauvaise '
                      'section sont indiscernables.'},
        ],
        'faits': [
            ('la conversion se fait dans la section qui contient la RVA',
             'retro_fiches.executer_widget("rva", {"adresse": "0x1050", '
             '"sections": ".text 0x1000 0x2000 0x400; .rdata 0x3000 0x200 '
             '0x2400"})["resultat"]["resultat"] == "0x450"'),
            ('la section trouvée est nommée dans le résultat',
             'retro_fiches.executer_widget("rva", {"adresse": "0x1050", '
             '"sections": ".text 0x1000 0x2000 0x400; .rdata 0x3000 0x200 '
             '0x2400"})["resultat"]["section"] == ".text"'),
            ('une RVA hors de toute section rend None, jamais 0',
             'retro_fiches.executer_widget("rva", {"adresse": "0x9000", '
             '"sections": ".text 0x1000 0x2000 0x400"})["resultat"]["resultat"] '
             'is None'),
            ('et cette RVA est expliquée par une note, pas silencieusement '
             'ignorée',
             'len(retro_fiches.executer_widget("rva", {"adresse": "0x9000", '
             '"sections": ".text 0x1000 0x2000 0x400"})["notes"]) == 1'),
            ('le sens inverse retrouve la même RVA',
             'retro_fiches.executer_widget("rva", {"adresse": "0x450", '
             '"sens": "fichier_vers_rva", "sections": ".text 0x1000 0x2000 '
             '0x400; .rdata 0x3000 0x200 0x2400"})["resultat"]["resultat"] == '
             '"0x1050"'),
            ('un sens inconnu est refusé et les valeurs acceptées sont nommées',
             'retro_fiches.executer_widget("rva", {"adresse": "0x1000", '
             '"sens": "nimporte", "sections": ".text 0x1000 0x2000 0x400"})'
             '["ok"] is False'),
            ('une table de sections à trois colonnes est refusée, pas devinée',
             'retro_fiches.executer_widget("rva", {"adresse": "0x1000", '
             '"sections": ".text 0x1000 0x2000"})["ok"] is False'),
        ],
        'outils': ['objdump -h', 'objdump -p', 'readelf -S', 'readelf -l'],
        'liens': ['pe-structure', 'elf-sections', 'boutisme'],
    },
    {
        'id': 'protections-windows',
        'titre': 'ASLR, DEP, CFG et SafeSEH',
        'categorie': 'securite',
        'resume': 'Ce que les drapeaux DllCharacteristics disent d’un PE, et '
                  'pourquoi leur absence est une information.',
        'mots_cles': ['aslr', 'dep', 'nx', 'cfg', 'safeseh', 'dynamic_base',
                      'dllcharacteristics', 'guard'],
        'sections': [
            {'titre': 'Les drapeaux qui comptent',
             'liste': [
                 'DYNAMIC_BASE (0x2) : le binaire est compatible ASLR. Sans '
                 'lui, les adresses sont fixes d’un lancement à l’autre.',
                 'NX_COMPAT (0x8) : compatible DEP. Sans lui, la pile peut '
                 'être exécutable.',
                 'GUARD_CF (0x100) : Control Flow Guard activé à la '
                 'compilation. Sa table est dans le répertoire 10.',
                 'HIGH_ENTROPY_VA (0x1) : adresses 64 bits pour l’ASLR. Sans '
                 'lui, l’aléa reste sur 32 bits même en x64.',
                 'NO_SEH (0x40) : pas de gestion structurée d’exception, donc '
                 'pas de cible d’écrasement de SEH.',
                 'FORCE_INTEGRITY (0x4) : le certificat doit être valide.',
                 'TERMINAL_SERVER_AWARE (0x400) : conscient des sessions '
                 'multiples.',
             ]},
            {'titre': 'Une valeur protégée, et une valeur qui ne l’est pas',
             'texte': '0x060b = HIGH_ENTROPY_VA | DYNAMIC_BASE | NX_COMPAT | '
                      'GUARD_CF | TERMINAL_SERVER_AWARE : c’est ce que produit '
                      'un compilateur récent avec ses options par défaut, et '
                      'cette valeur est utilisée dans les binaires de test de '
                      'ce projet. À l’inverse 0x160 = NO_SEH | NO_BIND | '
                      'WDM_DRIVER ne contient NI DYNAMIC_BASE NI NX_COMPAT : un '
                      'banc qui vérifierait 0x160 comme une valeur protégée ne '
                      'testerait rien. C’est un défaut réel de ce projet, '
                      'découvert en écrivant cette fiche : l’affirmation '
                      '« 0x4160 contient DYNAMIC_BASE » était fausse, et '
                      'l’autocontrôle l’a contredite.'},
            {'titre': 'Côté Linux',
             'texte': 'Les équivalents se lisent ailleurs : un PIE a e_type = '
                      'DYN et non EXEC ; RELRO se voit dans les segments '
                      'PT_GNU_RELRO et le drapeau DF_BIND_NOW de .dynamic ; '
                      'NX dépend de l’absence de PF_X sur le segment de pile '
                      '(PT_GNU_STACK) ; les canaris se détectent par la '
                      'présence de __stack_chk_fail dans les imports ; et la '
                      'FORTIFY apparaît dans les noms de fonctions, par '
                      'exemple __printf_chk.'},
        ],
        'faits': [
            ('0x060b contient HIGH_ENTROPY_VA, DYNAMIC_BASE, NX_COMPAT, '
             'GUARD_CF et TERMINAL_SERVER_AWARE',
             'sorted(retro_fiches.executer_widget("masques", {"valeur": "0x60b", '
             '"famille": "dll_pe"})["resultat"]["bits"]) == '
             'sorted(["HIGH_ENTROPY_VA", "DYNAMIC_BASE", "NX_COMPAT", '
             '"GUARD_CF", "TERMINAL_SERVER_AWARE"])'),
            ('0x160 omet DYNAMIC_BASE et NX_COMPAT',
             '(0x160 & 0x2) == 0 and (0x160 & 0x8) == 0'),
            ('0x4160 ne contient PAS DYNAMIC_BASE : l’affirmer était le fait '
             'faux découvert en écrivant cette fiche',
             '(0x4160 & 0x2) == 0'),
            ('le widget refuse de traiter un sous-système comme un masque',
             '"ÉNUMÉRATION" in " ".join(retro_fiches.executer_widget("masques", '
             '{"valeur": "2", "famille": "sous_systeme_pe"})["notes"])'),
            ('la décomposition de 0x60b cite cinq protections nommées',
             'len(retro_fiches.executer_widget("masques", {"valeur": "0x60b", '
             '"famille": "dll_pe"})["resultat"]["bits"]) == 5'),
        ],
        'outils': ['objdump -x', 'readelf -d', 'readelf -l'],
        'liens': ['pe-structure', 'elf-sections'],
    },
]


def fiche(identifiant):
    """Une fiche par son identifiant, ou un refus nommé."""
    identifiant = _texte(identifiant).strip()
    for entree in FICHES:
        if entree['id'] == identifiant:
            return {'ok': True, 'fiche': entree}
    return {'ok': False, 'erreur': 'La fiche « %s » n’existe pas. Fiches : %s.'
            % (identifiant, ', '.join(f['id'] for f in FICHES))}


def fiches(categorie=None):
    """La liste des fiches, éventuellement filtrée par catégorie.

    Le rendu est allégé : les `faits` et le corps complet ne sont pas renvoyés
    dans une liste, parce qu'un panneau qui demande toutes les fiches n'a pas
    besoin de leur texte — et parce que renvoyer 20 fiches complètes à chaque
    ouverture de panneau est du gaspillage.
    """
    categorie = _texte(categorie).strip().lower()
    sortie = []
    for entree in FICHES:
        if categorie and entree['categorie'] != categorie:
            continue
        sortie.append({
            'id': entree['id'], 'titre': entree['titre'],
            'categorie': entree['categorie'], 'resume': entree['resume'],
            'mots_cles': list(entree['mots_cles']),
            'sections': len(entree['sections']),
            'faits': len(entree['faits']),
            'outils': list(entree['outils']),
            'liens': list(entree['liens']),
        })
    return {'ok': True, 'fiches': sortie, 'nombre': len(sortie),
            'categorie': categorie or None}


def categories():
    """Les catégories avec leur nombre de fiches."""
    sortie = []
    for identifiant, titre in CATEGORIES:
        sortie.append({'id': identifiant, 'titre': titre,
                       'nombre': sum(1 for f in FICHES
                                     if f['categorie'] == identifiant)})
    vides = [c['id'] for c in sortie if not c['nombre']]
    return {'ok': True, 'categories': sortie,
            'vides': vides,
            'note': ('Les catégories %s n’ont aucune fiche.' % ', '.join(vides)
                     if vides else '')}


def chercher_fiche(motif, limite=25):
    """Recherche plein texte dans les fiches.

    Le score compte le titre pour trois, les mots-cles pour deux, le reste pour
    un : une fiche dont le titre contient le motif passe avant une fiche qui le
    mentionne une fois dans un paragraphe.
    """
    motif = _texte(motif).strip().lower()
    if not motif:
        return {'ok': False, 'resultats': [],
                'erreur': 'Un motif est demandé.'}
    termes = [t for t in re.split(r'[\s,;]+', motif) if t]
    if not termes:
        return {'ok': False, 'resultats': [],
                'erreur': 'Le motif ne contient aucun terme.'}
    resultats = []
    for entree in FICHES:
        titre = entree['titre'].lower()
        cles = ' '.join(entree['mots_cles']).lower()
        corps = ' '.join(
            [s.get('titre', ''), s.get('texte', ''),
             ' '.join(s.get('liste', [])) if isinstance(s.get('liste'), list)
             else '']
            for s in entree['sections']).lower()
        resume = entree['resume'].lower()
        score = 0
        manquant = []
        for terme in termes:
            trouve = False
            if terme in titre:
                score += 3
                trouve = True
            if terme in cles:
                score += 2
                trouve = True
            if terme in resume:
                score += 2
                trouve = True
            if terme in corps:
                score += 1 + min(corps.count(terme) - 1, 3)
                trouve = True
            if entree['id'] == terme:
                score += 5
                trouve = True
            if not trouve:
                manquant.append(terme)
        # Tous les termes doivent être présents : « ghidra jython » doit
        # trouver une fiche qui parle DES DEUX, pas la meilleure sur un seul.
        if manquant:
            continue
        resultats.append({'id': entree['id'], 'titre': entree['titre'],
                          'categorie': entree['categorie'],
                          'resume': entree['resume'], 'score': score})
    resultats.sort(key=lambda r: (-r['score'], r['titre']))
    tronque = len(resultats) > limite
    return {'ok': True, 'resultats': resultats[:limite],
            'nombre': len(resultats), 'tronque': tronque,
            'note': ('%d fiches correspondent ; %d montrées.'
                     % (len(resultats), min(limite, len(resultats)))
                     if resultats else
                     'Aucune fiche ne contient tous les termes %s.' % termes)}


def _source(module):
    """Le texte source d'un module, pour les faits qui vérifient une absence.

    Un fait qui affirme « le module ne fait pas X » ne peut être vérifié qu'en
    lisant le code : il n'existe aucun résultat d'exécution qui prouve une
    absence. Cette fonction rend '' si le fichier est illisible, pour qu'un tel
    fait échoue au lieu de lever.
    """
    chemin = getattr(module, '__file__', None)
    if not chemin:
        return ''
    try:
        return Path(chemin).read_text('utf8')
    except OSError:
        return ''


def _commandes_pyghidra():
    """Toutes les commandes de la voie pyghidra, en un seul texte.

    Les faits qui vérifient qu'une option est bien conseillée lisent ce texte.
    Rendre '' quand la voie est absente fait échouer le fait au lieu de le faire
    passer par accident.
    """
    for installation in getattr(retro_detection, 'INSTALLATIONS', ()):
        if installation.get('id') == 'pyghidra':
            return ' '.join(installation.get('commandes') or ())
    return ''


def assembleur_present():
    """Ce qu'assembleur.py apporte, s'il est là.

    Cité plutôt que recopié : assembleur.py porte 200 registres et 404
    mnémoniques, et une recopie ici deviendrait fausse à sa première évolution.
    """
    try:
        import importlib
        module = importlib.import_module('assembleur')
    except Exception as exc:
        return {'present': False, 'raison': 'assembleur.py n’a pas pu être '
                                            'importé (%s)' % type(exc).__name__}
    try:
        capacites = module.capacites()
    except Exception as exc:                                  # pragma: no cover
        return {'present': True, 'raison': 'capacites() a échoué (%s)' % exc}

    def compter(valeur):
        # assembleur.capacites() rend des NOMBRES pour les tables et des LISTES
        # pour les capacités. Deviner la forme ici rendrait un len() sur un int,
        # c'est-à-dire une levée dans une fonction censée renseigner.
        if isinstance(valeur, (list, dict, str, tuple, set)):
            return len(valeur)
        if isinstance(valeur, bool):
            return int(valeur)
        if isinstance(valeur, int):
            return valeur
        return 0

    return {'present': True,
            'registres': compter(capacites.get('registres')),
            'mnemoniques': compter(capacites.get('mnemoniques')),
            'directives_gas': compter(capacites.get('directives_gas')),
            'directives_nasm': compter(capacites.get('directives_nasm')),
            'conditions': compter(capacites.get('conditions')),
            'syntaxes': list(capacites.get('syntaxes') or []),
            'outils_presents': list(capacites.get('outils_presents') or []),
            'outils_absents': list(capacites.get('outils_absents') or []),
            'debogage_possible': bool(capacites.get('debogage_possible')),
            'assemblage_possible': bool(capacites.get('assemblage_possible'))}


# =============================================================================
#  WIDGETS — implémentations
# =============================================================================

def widget_convertisseur(entrees):
    valeur = _entier(entrees.get('valeur'))
    if valeur is None:
        return _refus('valeur', 'ce n’est pas un nombre lisible (%r). Un '
                      'préfixe 0x, 0b ou 0o est accepté.'
                      % _texte(entrees.get('valeur'))[:120])
    largeur = _entier(entrees.get('largeur'), 8) or 8
    if largeur not in (1, 2, 4, 8):
        return _refus('largeur', '%r n’est pas une largeur d’octets possible '
                      '(1, 2, 4 ou 8)' % entrees.get('largeur'))
    notes = []
    negatif = valeur < 0
    masque = (1 << (largeur * 8)) - 1
    non_signe = valeur & masque
    if negatif:
        notes.append('valeur négative : l’échange de boutisme et les '
                     'représentations sont calculées sur le complément à deux '
                     'sur %d octet(s).' % largeur)
    if valeur > masque:
        notes.append('la valeur ne tient pas sur %d octet(s) : elle est '
                     'tronquée à %d pour les représentations en largeur fixe.'
                     % (largeur, non_signe))
    octets = non_signe.to_bytes(largeur, 'big')
    binaire = format(non_signe, '0%db' % (largeur * 8))
    return {'ok': True, 'notes': notes, 'resultat': {
        'decimal': valeur,
        'decimal_non_signe': non_signe,
        'hexadecimal': '0x%x' % non_signe,
        'hexadecimal_largeur': '0x%s' % format(non_signe,
                                               '0%dx' % (largeur * 2)),
        'octal': '0%o' % non_signe,
        'binaire': binaire,
        'binaire_par_octets': ' '.join(binaire[i:i + 8]
                                       for i in range(0, len(binaire), 8)),
        'octets_grand_boutisme': ' '.join('%02x' % o for o in octets),
        'octets_petit_boutisme': ' '.join('%02x' % o for o in octets[::-1]),
        'boutisme_inverse': '0x%x' % int.from_bytes(octets[::-1], 'big'),
        'largeur': largeur,
        'bits_utilises': non_signe.bit_length(),
    }}


def widget_empreintes(entrees):
    donnees, origine, notes = _octets(entrees.get('donnees'))
    if origine == 'invalide':
        return _refus('donnees', ' ; '.join(notes) or 'entrée illisible')
    notes.append('données lues comme %s (%d octet(s)).' % (origine,
                                                           len(donnees)))
    if len(donnees) > 32 * 1024 * 1024:
        return _refus('donnees', 'plus de 32 Mio : passez par l’analyse d’un '
                      'fichier, pas par le widget')
    resultats = {}
    for nom in ('md5', 'sha1', 'sha256', 'sha512'):
        algorithme = 'sha1' if nom == 'sha1' else nom
        resultats[nom] = hashlib.new(algorithme, donnees).hexdigest()
    resultats['octets'] = len(donnees)
    resultats['sha256_court'] = resultats['sha256'][:16]
    return {'ok': True, 'notes': notes, 'resultat': resultats}


def widget_entropie(entrees):
    donnees, origine, notes = _octets(entrees.get('donnees'))
    if origine == 'invalide':
        return _refus('donnees', ' ; '.join(notes) or 'entrée illisible')
    notes.append('données lues comme %s.' % origine)
    if not donnees:
        return _refus('donnees', 'rien à mesurer')
    entropie = 0.0
    if retro_binaires is not None:
        entropie = retro_binaires.entropie(donnees)
    else:
        comptes = [0] * 256
        for octet in donnees:
            comptes[octet] += 1
        total = len(donnees)
        for compte in comptes:
            if compte:
                frequence = compte / total
                entropie -= frequence * math.log2(frequence)
    if entropie < 0.5:
        interpretation = 'nulle ou quasi constante'
        conseil = 'Données constantes ou presque : un en-tête réservé, un ' \
                  'remplissage, ou une section .bss matérialisée.'
    elif entropie < 3.0:
        interpretation = 'faible'
        conseil = 'Peu de valeurs distinctes : table d’index, texte très ' \
                  'répétitif, ou données structurées.'
    elif entropie < 5.0:
        interpretation = 'moyenne'
        conseil = 'Texte naturel ou code source ; parfois du code machine ' \
                  'riche en constantes.'
    elif entropie < 6.8:
        interpretation = 'élevée'
        conseil = 'Code compilé typique. C’est la plage normale d’un .text.'
    elif entropie < 7.5:
        interpretation = 'très élevée'
        conseil = 'Suspicion de compression ou de chiffrement. Vérifiez si ' \
                  'cette section est censée être du code.'
    else:
        interpretation = 'maximale'
        conseil = 'Compressé, chiffré, ou empacté (UPX, ASPack, Themida). Un ' \
                  'exécutable dont le .text est ici ne se désassemble pas ' \
                  'directement : il faut le dépaqueter d’abord.'
    return {'ok': True, 'notes': notes, 'resultat': {
        'entropie': round(entropie, 6),
        'entropie_arrondie': round(entropie, 3),
        'octets': len(donnees),
        'valeurs_distinctes': len(set(donnees)),
        'interpretation': interpretation,
        'conseil': conseil,
    }}


def widget_hexdump(entrees):
    donnees, origine, notes = _octets(entrees.get('donnees'))
    if origine == 'invalide':
        # Une deuxième chance : peut-être un vidage collé depuis objdump ou xxd.
        relu = _relire_vidage(_texte(entrees.get('donnees')))
        if not relu['ok']:
            return _refus('donnees', ' ; '.join(notes + relu.get('notes', []))
                          or 'entrée illisible')
        notes = relu['notes']
        notes.append('l’entrée a été reconnue comme un VIDAGE et relue.')
        donnees = relu['octets']
    else:
        notes.append('données lues comme %s.' % origine)
    largeur = _entier(entrees.get('largeur'), 16) or 16
    if largeur not in (8, 16, 32):
        return _refus('largeur', '%r : utilisez 8, 16 ou 32 octets par ligne'
                      % entrees.get('largeur'))
    adresse = _entier(entrees.get('adresse'), 0)
    if adresse is None or adresse < 0:
        return _refus('adresse', '%r n’est pas une adresse'
                      % entrees.get('adresse'))
    if not donnees:
        return _refus('donnees', 'rien à vider')
    lignes = []
    for debut in range(0, len(donnees), largeur):
        bloc = donnees[debut:debut + largeur]
        colonne = ' '.join('%02x' % o for o in bloc)
        # Les lignes sont alignées même quand le dernier bloc est court : un
        # vidage dont l'ASCII ne suit pas les octets se lit mal.
        colonne = colonne.ljust(largeur * 3 - 1)
        ascii_ = ''.join(chr(o) if 32 <= o < 127 else '.' for o in bloc)
        lignes.append('%08x  %s  %s' % (adresse + debut, colonne, ascii_))
    texte = '\n'.join(lignes)
    return {'ok': True, 'notes': notes, 'resultat': {
        'lignes': len(lignes), 'octets': len(donnees), 'texte': texte,
        'premiere_ligne': lignes[0], 'derniere_ligne': lignes[-1],
        'adresse_debut': '0x%x' % adresse,
        'adresse_fin': '0x%x' % (adresse + len(donnees) - 1),
        'largeur': largeur,
    }}


def _relire_vidage(texte):
    """Relit un vidage produit par objdump -d, xxd, od -A x -t x1z ou hexdump.

    Trois formes au moins circulent, et un widget qui n'en lit qu'une fait
    croire à l'utilisateur que son collé est invalide. On essaie les trois et
    on dit laquelle a servi.
    """
    notes = []
    if not texte.strip():
        return {'ok': False, 'octets': b'', 'notes': ['entrée vide']}
    # Forme objdump : «  401000:\t48 89 e5  \tmov    %rsp,%rbp »
    motif_objdump = re.compile(r'^\s*[0-9a-fA-F]+:\s*((?:[0-9a-fA-F]{2}\s)+)',
                               re.M)
    trouves = motif_objdump.findall(texte)
    if trouves:
        sortie = bytearray()
        for groupe in trouves:
            for paire in groupe.split():
                sortie.append(int(paire, 16))
        notes.append('vidage au format objdump -d : %d ligne(s).'
                     % len(trouves))
        return {'ok': True, 'octets': bytes(sortie), 'notes': notes}
    # Forme xxd : « 00000000: 4865 6c6c 6f20 776f  Hello wo »
    motif_xxd = re.compile(r'^[0-9a-fA-F]{6,16}:\s((?:[0-9a-fA-F]{2,4}\s)+)',
                           re.M)
    trouves = motif_xxd.findall(texte)
    if trouves:
        sortie = bytearray()
        for groupe in trouves:
            compacte = re.sub(r'\s+', '', groupe)
            for i in range(0, len(compacte) - 1, 2):
                sortie.append(int(compacte[i:i + 2], 16))
        notes.append('vidage au format xxd : %d ligne(s).' % len(trouves))
        return {'ok': True, 'octets': bytes(sortie), 'notes': notes}
    # Forme od -t x1 : « 0000000 48 65 6c 6c 6f »
    motif_od = re.compile(r'^[0-9a-fA-F]{6,8}\s+((?:[0-9a-fA-F]{2}\s*)+)$',
                          re.M)
    trouves = motif_od.findall(texte)
    if trouves:
        sortie = bytearray()
        for groupe in trouves:
            for paire in groupe.split():
                sortie.append(int(paire, 16))
        notes.append('vidage au format od -A x -t x1 : %d ligne(s).'
                     % len(trouves))
        return {'ok': True, 'octets': bytes(sortie), 'notes': notes}
    return {'ok': False, 'octets': b'',
            'notes': ['aucun format de vidage reconnu (objdump -d, xxd, od)']}


def widget_motif(entrees):
    brut = _texte(entrees.get('motif')).strip()
    if not brut:
        return _refus('motif', 'un motif est demandé')
    jetons = re.split(r'[\s,]+', brut)
    octets = []
    jokers = 0
    for jeton in jetons:
        if not jeton:
            continue
        if jeton in ('??', '?', '**', 'xx', 'XX'):
            octets.append(None)
            jokers += 1
            continue
        net = jeton.replace('0x', '').replace('0X', '')
        if not re.fullmatch(r'[0-9a-fA-F]{2}', net):
            return _refus('motif', '« %s » n’est ni un octet hexadécimal à '
                          'deux chiffres ni un joker (??)' % jeton)
        octets.append(int(net, 16))
    if not octets:
        return _refus('motif', 'aucun octet ni joker dans %r' % brut)
    expression = ''.join('.' if o is None else '\\x%02x' % o for o in octets)
    masque = ''.join('00' if o is None else 'ff' for o in octets)
    normalise = ' '.join('??' if o is None else '%02x' % o for o in octets)
    return {'ok': True, 'notes': [
        'Le motif fait %d octet(s), dont %d joker(s). Il s’emploie tel quel '
        'dans Ghidra (Search → For Bytes) et dans l’opération « search » du '
        'panneau.' % (len(octets), jokers)], 'resultat': {
            'longueur': len(octets), 'jokers': jokers,
            'normalise': normalise,
            'expression': expression,
            'masque': ' '.join(masque[i:i + 2] for i in range(0, len(masque), 2)),
            'octets': ['??' if o is None else '%02x' % o for o in octets],
    }}


def widget_xor(entrees):
    donnees, origine, notes = _octets(entrees.get('donnees'))
    if origine == 'invalide':
        return _refus('donnees', ' ; '.join(notes) or 'entrée illisible')
    cle, origine_cle, notes_cle = _octets(entrees.get('cle'))
    if origine_cle == 'invalide':
        return _refus('cle', ' ; '.join(notes_cle) or 'clef illisible')
    if not cle:
        return _refus('cle', 'une clef d’au moins un octet est demandée')
    if not donnees:
        return _refus('donnees', 'rien à transformer')
    notes.append('données lues comme %s, clef comme %s (%d octet(s)).'
                 % (origine, origine_cle, len(cle)))
    sortie = bytes(d ^ cle[i % len(cle)] for i, d in enumerate(donnees))
    texte = sortie.decode('utf8', 'replace')
    imprimables = sum(1 for o in sortie if 32 <= o < 127 or o in (9, 10, 13))
    ratio = imprimables / len(sortie)
    conseil = ('Le résultat est à %.0f %% imprimable : %s'
               % (ratio * 100,
                  'cela ressemble à du texte, la clef est probablement bonne.'
                  if ratio > 0.85 else
                  'cela ne ressemble pas à du texte. Essayez une clef d’un '
                  'octet de 0x00 à 0xff, ou une longueur de clef différente.'))
    return {'ok': True, 'notes': notes, 'resultat': {
        'hexadecimal': ' '.join('%02x' % o for o in sortie),
        'texte': texte,
        'octets': len(sortie),
        'longueur_cle': len(cle),
        'imprimables': imprimables,
        'ratio_imprimables': round(ratio, 4),
        'conseil': conseil,
        'base64': base64.b64encode(sortie).decode('ascii'),
    }}


def widget_structure(entrees):
    brut = _texte(entrees.get('champs'))
    if not brut.strip():
        return _refus('champs', 'une description de structure est demandée')
    bits = _entier(entrees.get('bits'), 64) or 64
    if bits not in (32, 64):
        return _refus('bits', '%r : 32 ou 64' % entrees.get('bits'))
    boutisme = _texte(entrees.get('boutisme'), 'petit').strip().lower()
    if boutisme in ('grand', 'big', 'be', 'big-endian', 'msb'):
        prefixe, nom_boutisme = '>', 'grand-boutisme'
    elif boutisme in ('petit', 'little', 'le', 'little-endian', 'lsb', ''):
        prefixe, nom_boutisme = '<', 'petit-boutisme'
    else:
        return _refus('boutisme', '%r : « petit » ou « grand »'
                      % entrees.get('boutisme'))
    notes = []
    champs = []
    position = 0
    format_sortie = prefixe
    for morceau in re.split(r'[;\n,]', brut):
        morceau = morceau.strip()
        if not morceau:
            continue
        pieces = morceau.split()
        if len(pieces) < 1:
            continue
        type_brut = pieces[0].lower()
        nom = pieces[1] if len(pieces) > 1 else 'champ%d' % (len(champs) + 1)
        tableau = 1
        recherche = re.match(r'^(.*?)\s*\[\s*(\d*)\s*\]$', type_brut)
        if recherche:
            type_brut = recherche.group(1)
            dimension = recherche.group(2)
            tableau = int(dimension) if dimension else 0
            if tableau == 0:
                return _refus('champs', '« %s » est un tableau flexible : sa '
                              'taille n’est pas calculable ici' % morceau)
        if type_brut in ('long', 'unsigned long', 'ulong'):
            if bits == 64:
                type_brut, signe = 'long', ('uint' if 'unsigned' in morceau.lower()
                                           else 'int')
            else:
                type_brut, signe = 'int', ('uint' if 'unsigned' in morceau.lower()
                                          else 'int')
            notes.append('« long » vaut %d octet(s) ici. Sous Windows x64 il '
                         'en vaut 4 : le widget suit le modèle LP64 (Linux, '
                         'macOS).' % (8 if bits == 64 else 4))
        elif type_brut.startswith('unsigned'):
            type_brut = type_brut.replace('unsigned', '').strip()
            signe = 'uint'
        elif type_brut in ('intptr', 'uintptr', 'pointer', 'void*'):
            type_brut = 'pointer'
            signe = 'uint' if type_brut == 'uintptr' else 'int'
        else:
            signe = 'uint' if type_brut.startswith('u') and \
                type_brut[1:] in TYPES_C else 'int'
        clef = type_brut if type_brut in TYPES_C else type_brut
        taille = TYPES_C.get(clef)
        if taille is None:
            return _refus('champs', 'le type « %s » n’est pas dans la table '
                          '(types connus : %s)'
                          % (pieces[0], ', '.join(sorted(
                              set(TYPES_C))[:14]) + ', …'))
        if clef in ('float',):
            signe = 'float'
        elif clef in ('double',):
            signe = 'double'
        elif clef == 'longdouble':
            signe = 'longdouble'
        # Alignement : l'alignement naturel est la taille du type, plafonnée à
        # 8 (c'est ce que font gcc et clang sur x86-64 pour long double, qui
        # s'aligne sur 16 en ABI SysV mais sur 8 avec __attribute__((packed))).
        alignement = min(taille, 8)
        reste = position % alignement
        bourrage = (alignement - reste) % alignement
        if bourrage:
            format_sortie += '%dx' % bourrage
            position += bourrage
            notes.append('%d octet(s) de bourrage inséré(s) avant « %s » pour '
                         'l’aligner sur %d.' % (bourrage, nom, alignement))
        lettre = _lettre_struct(taille, signe)
        if lettre is None:
            return _refus('champs', 'aucune lettre struct pour « %s »'
                          % pieces[0])
        if tableau > 1:
            format_sortie += '%d%s' % (tableau, lettre)
        else:
            format_sortie += lettre
        champs.append({'nom': nom, 'type': pieces[0], 'taille': taille,
                       'tableau': tableau,
                       'taille_totale': taille * tableau,
                       'decalage': position, 'alignement': alignement})
        position += taille * tableau
    if not champs:
        return _refus('champs', 'aucun champ reconnu dans %r' % brut[:120])
    # Alignement final de la structure : multiple du plus grand alignement.
    plus_grand = max(c['alignement'] for c in champs)
    taille_structure = position
    reste = taille_structure % plus_grand
    if reste:
        taille_structure += plus_grand - reste
        notes.append('%d octet(s) de bourrage final pour aligner la structure '
                     'sur %d.' % (plus_grand - reste, plus_grand))
    try:
        calcule = struct.calcsize(format_sortie)
    except struct.error as exc:
        return _refus('champs', 'le format construit est refusé par struct : '
                      '%s' % exc)
    if calcule != taille_structure:
        notes.append('struct.calcsize donne %d octets là où le calcul '
                     'd’alignement donne %d : le préfixe %s supprime le '
                     'bourrage automatique, la taille annoncée est celle du '
                     'calcul explicite.' % (calcule, taille_structure,
                                            prefixe))
    return {'ok': True, 'notes': notes, 'resultat': {
        'taille': taille_structure,
        'taille_sans_bourrage': sum(c['taille_totale'] for c in champs),
        'champs': len(champs),
        'format': format_sortie,
        'prefixe': prefixe,
        'boutisme': nom_boutisme,
        'bits': bits,
        'detail': champs,
        'decalages': {c['nom']: c['decalage'] for c in champs},
        'bourrage': taille_structure - sum(c['taille_totale'] for c in champs),
    }}


def widget_rva(entrees):
    adresse = _entier(entrees.get('adresse'))
    if adresse is None:
        return _refus('adresse', '%r n’est pas une adresse'
                      % entrees.get('adresse'))
    brut = _texte(entrees.get('sections'))
    if not brut.strip():
        return _refus('sections', 'la table des sections est demandée : '
                      '« nom adresse_virtuelle taille_virtuelle '
                      'décalage_brut », séparés par des points-virgules')
    sens = _texte(entrees.get('sens'), 'rva_vers_fichier').strip().lower()
    if sens not in ('rva_vers_fichier', 'fichier_vers_rva'):
        return _refus('sens', '%r : « rva_vers_fichier » ou « fichier_vers_rva »'
                      % entrees.get('sens'))
    sections = []
    notes = []
    for morceau in re.split(r'[;\n]', brut):
        morceau = morceau.strip()
        if not morceau:
            continue
        pieces = morceau.split()
        if len(pieces) < 4:
            return _refus('sections', '« %s » doit donner quatre valeurs : '
                          'nom, adresse virtuelle, taille virtuelle, décalage '
                          'brut' % morceau)
        nom = pieces[0]
        valeurs = [_entier(p) for p in pieces[1:4]]
        if any(v is None for v in valeurs):
            return _refus('sections', 'une valeur de « %s » n’est pas un '
                          'nombre : %r' % (morceau, pieces[1:4]))
        sections.append({'nom': nom, 'virtuelle': valeurs[0],
                         'taille': valeurs[1], 'brute': valeurs[2]})
    if not sections:
        return _refus('sections', 'aucune section lue dans %r' % brut[:120])
    if len(set(s['nom'] for s in sections)) != len(sections):
        notes.append('des sections portent le même nom : la première trouvée '
                     'gagne, ce qui peut être faux.')
    if sens == 'rva_vers_fichier':
        for section in sections:
            if section['virtuelle'] <= adresse < \
                    section['virtuelle'] + max(section['taille'], 1):
                delta = adresse - section['virtuelle']
                return {'ok': True, 'notes': notes, 'resultat': {
                    'resultat': '0x%x' % (section['brute'] + delta),
                    'decimal': section['brute'] + delta,
                    'section': section['nom'], 'sens': sens,
                    'dans_la_section': delta}}
        return {'ok': True, 'notes': notes + [
            'aucune section ne contient 0x%x : l’adresse est peut-être dans '
            'une section non chargée, ou la table collée est incomplète.'
            % adresse], 'resultat': {
                'resultat': None, 'section': None, 'sens': sens}}
    for section in sections:
        if section['brute'] <= adresse < section['brute'] + max(
                section['taille'], 1):
            delta = adresse - section['brute']
            return {'ok': True, 'notes': notes, 'resultat': {
                'resultat': '0x%x' % (section['virtuelle'] + delta),
                'decimal': section['virtuelle'] + delta,
                'section': section['nom'], 'sens': sens,
                'dans_la_section': delta}}
    return {'ok': True, 'notes': notes + [
        'aucun décalage brut ne contient 0x%x.' % adresse], 'resultat': {
            'resultat': None, 'section': None, 'sens': sens}}


def widget_masques(entrees):
    valeur = _entier(entrees.get('valeur'))
    if valeur is None:
        return _refus('valeur', '%r n’est pas un nombre'
                      % entrees.get('valeur'))
    famille = _texte(entrees.get('famille'), 'segment_elf').strip().lower()
    if valeur < 0:
        return _refus('valeur', 'un masque de drapeaux est positif (%d)'
                      % valeur)
    if famille == 'sous_systeme_pe':
        # Ce n'est PAS un masque : c'est une énumération. Le traiter comme un
        # masque inventerait des drapeaux.
        nom = SOUS_SYSTEMES_PE.get(valeur)
        return {'ok': True, 'notes': [
            'Le sous-système PE est une ÉNUMÉRATION, pas un masque : une seule '
            'valeur est valide à la fois.'],
            'resultat': {'valeur': valeur, 'nom': nom
                         or 'inconnu (%d)' % valeur,
                         'bits': [nom] if nom else [], 'inconnus': 0,
                         'connus': sorted(SOUS_SYSTEMES_PE)}}
    table = TABLES_MASQUES.get(famille)
    if table is None:
        return _refus('famille', '%r est inconnue. Familles : %s'
                      % (entrees.get('famille'), ', '.join(
                          sorted(list(TABLES_MASQUES) + ['sous_systeme_pe'])))
                      )
    bits = []
    inconnus = 0
    reste = valeur
    # Les masques larges (PF_MASKPROC = 0xf0000000) doivent être testés AVANT
    # les bits unitaires, sinon chaque bit du masque est nommé séparément.
    for masque in sorted(table, reverse=True):
        if masque and (valeur & masque) == masque and masque.bit_count() > 1 \
                and (reste & masque):
            bits.append(table[masque])
            reste &= ~masque
    for masque in sorted(table):
        if masque and masque.bit_count() == 1 and (reste & masque):
            bits.append(table[masque])
            reste &= ~masque
    if reste:
        inconnus = reste.bit_count()
    notes = []
    if inconnus:
        notes.append('%d bit(s) non reconnu(s) (reste 0x%x). La table peut '
                     'être en retard sur la spécification, ou le masque '
                     'appartenir à un processeur spécifique.'
                     % (inconnus, reste))
    if not bits and valeur == 0:
        notes.append('masque nul : aucun drapeau.')
    return {'ok': True, 'notes': notes, 'resultat': {
        'valeur': valeur, 'hexadecimal': '0x%x' % valeur,
        'famille': famille, 'bits': bits, 'nombre': len(bits),
        'inconnus': inconnus, 'reste': reste,
        'table': {('0x%x' % k): v for k, v in sorted(table.items())},
    }}


def widget_ascii(entrees):
    requete = _texte(entrees.get('requete')).strip()
    if not requete:
        table = []
        for code in range(128):
            table.append({
                'code': code, 'hexadecimal': '0x%02x' % code,
                'octal': '%03o' % code,
                'binaire': format(code, '08b'),
                'nom': NOMS_ASCII.get(code, ''),
                'caractere': (chr(code) if code >= 32 and code != 127 else ''),
                'imprimable': 32 <= code < 127,
                'classe': ('contrôle' if code < 32 or code == 127 else
                           'espace' if code == 32 else
                           'chiffre' if 48 <= code <= 57 else
                           'majuscule' if 65 <= code <= 90 else
                           'minuscule' if 97 <= code <= 122 else 'ponctuation'),
            })
        return {'ok': True, 'notes': [
            'Table ASCII complète (0 à 127). Les codes 128 à 255 dépendent de '
            'la page de codes : ce n’est plus de l’ASCII.'],
            'resultat': {'table': table, 'codes': len(table)}}
    if len(requete) == 1 and not requete.isdigit():
        code = ord(requete)
        if code > 127:
            return {'ok': True, 'notes': [
                'U+%04X n’est pas dans l’ASCII (0 à 127). En UTF-8 il '
                's’écrit %s.' % (code, ' '.join(
                    '%02x' % o for o in requete.encode('utf8')))],
                'resultat': {'code': code, 'hexadecimal': '0x%x' % code,
                             'utf8': ' '.join('%02x' % o
                                              for o in requete.encode('utf8')),
                             'nom': 'hors ASCII'}}
        return {'ok': True, 'notes': [], 'resultat': {
            'code': code, 'hexadecimal': '0x%02x' % code,
            'octal': '%03o' % code, 'binaire': format(code, '08b'),
            'nom': NOMS_ASCII.get(code, ''),
            'imprimable': 32 <= code < 127}}
    code = _entier(requete)
    if code is None:
        return _refus('requete', '%r n’est ni un code ni un caractère'
                      % requete[:40])
    if not 0 <= code <= 127:
        return {'ok': True, 'notes': [
            '%d est hors de l’ASCII (0 à 127).' % code],
            'resultat': {'code': code, 'nom': 'hors ASCII',
                         'hexadecimal': '0x%x' % code}}
    return {'ok': True, 'notes': [], 'resultat': {
        'code': code, 'hexadecimal': '0x%02x' % code,
        'octal': '%03o' % code, 'binaire': format(code, '08b'),
        'nom': NOMS_ASCII.get(code, ''),
        'caractere': chr(code) if 32 <= code < 127 else '',
        'imprimable': 32 <= code < 127,
        'classe': ('contrôle' if code < 32 or code == 127 else
                   'espace' if code == 32 else
                   'chiffre' if 48 <= code <= 57 else
                   'majuscule' if 65 <= code <= 90 else
                   'minuscule' if 97 <= code <= 122 else 'ponctuation')}}


def widget_guid(entrees):
    brut = _texte(entrees.get('valeur')).strip()
    if not brut:
        return _refus('valeur', 'un GUID ou 16 octets sont demandés')
    if brut.lower().startswith('hex:'):
        donnees, origine, notes = _octets(brut)
    elif re.fullmatch(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-'
                      r'[0-9a-fA-F]{4}-[0-9a-fA-F]{12}', brut):
        donnees = binascii.unhexlify(brut.replace('-', ''))
        origine = 'guid'
        notes = []
    elif re.fullmatch(r'[0-9a-fA-F]{32}', re.sub(r'[\s{}-]+', '', brut)):
        donnees = binascii.unhexlify(re.sub(r'[\s{}-]+', '', brut))
        origine = 'guid sans tirets'
        notes = []
    else:
        return _refus('valeur', '%r n’est ni un GUID (8-4-4-4-12) ni 16 octets '
                      'hexadécimaux' % brut[:60])
    if origine == 'invalide':
        return _refus('valeur', ' ; '.join(notes) or 'octets illisibles')
    if len(donnees) != 16:
        return _refus('valeur', 'un GUID fait 16 octets, %d lus'
                      % len(donnees))
    notes = list(notes)
    # Le mélange de boutisme est LA difficulté : les trois premiers champs sont
    # stockés en petit-boutisme, les huit derniers octets en grand-boutisme.
    # Une CHAÎNE et des OCTETS ne se traduisent pas dans le même sens, et les
    # confondre rend un guid faux sans que rien ne le signale.
    entree_octets = origine in ('hexadécimal', 'octets')
    if entree_octets:
        # Les octets sont ceux du fichier : la chaîne se lit en décodant les
        # trois premiers champs en petit-boutisme.
        data1, data2, data3 = struct.unpack_from('<IHH', donnees, 0)
        queue = donnees[8:16]
        octets_fichier = donnees
        notes.append('entrée lue comme des OCTETS tels qu’ils sont stockés dans '
                     'le fichier : la chaîne est déduite en décodant les trois '
                     'premiers champs en petit-boutisme.')
    else:
        # La chaîne est la forme affichée : les octets du fichier s'obtiennent
        # en écrivant les trois premiers champs en petit-boutisme.
        data1 = int(brut[0:8], 16) if origine == 'guid' else int(
            re.sub(r'[\s{}-]+', '', brut)[0:8], 16)
        net = re.sub(r'[\s{}-]+', '', brut).lower()
        data2 = int(net[8:12], 16)
        data3 = int(net[12:16], 16)
        queue = binascii.unhexlify(net[16:32])
        octets_fichier = struct.pack('<IHH', data1, data2, data3) + queue
        notes.append('entrée lue comme une CHAÎNE : les octets rendus sont ceux '
                     'qu’un fichier contient, c’est-à-dire les trois premiers '
                     'champs écrits en petit-boutisme.')
    guid = '%08x-%04x-%04x-%s-%s' % (
        data1, data2, data3, binascii.hexlify(queue[:2]).decode('ascii'),
        binascii.hexlify(queue[2:]).decode('ascii'))
    notes.append('Les trois premiers champs sont stockés en PETIT-boutisme, '
                 'les huit derniers octets en GRAND-boutisme. Recopier les 16 '
                 'octets dans l’ordre donne un GUID faux.')
    return {'ok': True, 'notes': notes, 'resultat': {
        'guid': guid,
        'guid_majuscules': guid.upper(),
        'accolades': '{%s}' % guid.upper(),
        'octets': ' '.join('%02x' % o for o in octets_fichier),
        'entree': 'octets' if entree_octets else 'chaîne',
        'data1': '0x%08x' % data1, 'data2': '0x%04x' % data2,
        'data3': '0x%04x' % data3,
        'version': (queue[0] & 0xf0) >> 4 if entree_octets else (data3 >> 12),
        'variante': (queue[2] & 0xc0) >> 6,
    }}


def widget_horodatage(entrees):
    secondes = _entier(entrees.get('valeur'))
    if secondes is None:
        return _refus('valeur', '%r n’est pas un nombre de secondes'
                      % entrees.get('valeur'))
    notes = []
    if secondes == 0:
        notes.append('horodatage nul : fréquent dans les binaires construits de '
                     'façon reproductible, et dans les binaires dont '
                     'l’horodatage a été effacé.')
    if secondes < 0:
        return _refus('valeur', 'un horodatage de compilation est positif '
                      '(%d)' % secondes)
    if secondes > 4294967295:
        notes.append('la valeur dépasse 32 bits : ce n’est pas un '
                     'TimeDateStamp de PE, qui est sur 4 octets.')
    try:
        utc = time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime(secondes))
    except (ValueError, OverflowError, OSError) as exc:
        return _refus('valeur', 'cette valeur n’est pas une date représentable '
                      '(%s)' % exc)
    maintenant = int(time.time())
    if secondes > maintenant + 86400:
        notes.append('cette date est dans le FUTUR (%s) : l’horodatage a été '
                     'falsifié, ou ce n’est pas un horodatage.'
                     % utc)
    elif secondes < 315532800:               # 1er janvier 1980
        notes.append('cette date précède 1980 : ce n’est probablement pas une '
                     'date de compilation (%s).' % utc)
    return {'ok': True, 'notes': notes, 'resultat': {
        'secondes': secondes, 'utc': utc,
        'iso': utc.replace(' ', 'T') + 'Z',
        'hexadecimal': '0x%08x' % (secondes & 0xffffffff),
        'local': time.strftime('%Y-%m-%d %H:%M:%S %Z', time.localtime(secondes)),
        'dans_le_futur': secondes > maintenant + 86400,
        'avant_1980': secondes < 315532800,
    }}


def widget_base64(entrees):
    brut = _texte(entrees.get('donnees'))
    variante = _texte(entrees.get('variante'), 'standard').strip().lower()
    sens = _texte(entrees.get('sens'), 'encoder').strip().lower()
    if variante not in ('standard', 'url', 'base32'):
        return _refus('variante', '%r : standard, url ou base32'
                      % entrees.get('variante'))
    if sens not in ('encoder', 'decoder'):
        return _refus('sens', '%r : encoder ou decoder' % entrees.get('sens'))
    notes = []
    if sens == 'encoder':
        donnees = brut.encode('utf8')
        notes.append('%d octet(s) UTF-8 encodés.' % len(donnees))
        if variante == 'standard':
            sortie = base64.b64encode(donnees).decode('ascii')
        elif variante == 'url':
            sortie = base64.urlsafe_b64encode(donnees).decode('ascii')
        else:
            sortie = base64.b32encode(donnees).decode('ascii')
        return {'ok': True, 'notes': notes, 'resultat': {
            'sortie': sortie, 'longueur': len(sortie),
            'variante': variante, 'sens': sens,
            'avec_remplissage': sortie.endswith('=') or sortie.endswith('='),
            'sans_remplissage': sortie.rstrip('='),
        }}
    compacte = re.sub(r'\s+', '', brut)
    if not compacte:
        return _refus('donnees', 'rien à décoder')
    manquant = (-len(compacte)) % (8 if variante == 'base32' else 4)
    if manquant:
        notes.append('%d caractère(s) de remplissage manquants : ajoutés. Un '
                     'base64 collé depuis une URL les a souvent perdus.'
                     % manquant)
        compacte += '=' * manquant
    try:
        if variante == 'standard':
            donnees = base64.b64decode(compacte, validate=True)
        elif variante == 'url':
            donnees = base64.urlsafe_b64decode(compacte)
        else:
            donnees = base64.b32decode(compacte)
    except (binascii.Error, ValueError) as exc:
        if variante == 'standard' and ('-' in compacte or '_' in compacte):
            notes.append('l’entrée contient - ou _ : c’est du base64url. '
                         'Réessayez avec la variante « url ».')
        return _refus('donnees', 'base64 invalide (%s)' % exc)
    texte = donnees.decode('utf8', 'replace')
    imprimables = sum(1 for o in donnees if 32 <= o < 127 or o in (9, 10, 13))
    return {'ok': True, 'notes': notes, 'resultat': {
        'sortie': texte, 'octets': len(donnees),
        'hexadecimal': ' '.join('%02x' % o for o in donnees[:256]),
        'imprimables': imprimables,
        'ratio_imprimables': round(imprimables / len(donnees), 4)
        if donnees else 0.0,
        'variante': variante, 'sens': sens,
        'tronce': len(donnees) > 256,
    }}


def widget_signature(entrees):
    donnees, origine, notes = _octets(entrees.get('donnees'))
    if origine == 'invalide':
        return _refus('donnees', ' ; '.join(notes) or 'entrée illisible')
    if len(donnees) < 4:
        return _refus('donnees', 'au moins 4 octets sont nécessaires pour une '
                      'signature (%d lus)' % len(donnees))
    notes.append('données lues comme %s (%d octet(s)).' % (origine,
                                                           len(donnees)))
    if retro_binaires is not None:
        try:
            famille = retro_binaires.famille(donnees)
        except Exception as exc:                            # pragma: no cover
            famille = None
            notes.append('retro_binaires.famille a échoué (%s) : repli sur la '
                         'table locale.' % exc)
    else:
        famille = None
        notes.append('retro_binaires est absent : la table locale, plus '
                     'courte, est utilisée.')
    resultat = {'donnees': ' '.join('%02x' % o for o in donnees[:16])}
    # retro_binaires.famille() rend un dict {ok, famille, nom, ambiguite,
    # raison} et TRANCHE lui-même l'ambiguïté 0xCAFEBABE sur les octets qui
    # suivent. Le widget ne doit pas refaire ce travail avec une table plus
    # courte : il cite le module et recopie sa raison.
    if isinstance(famille, dict) and famille.get('famille'):
        resultat['famille'] = famille['famille']
        resultat['nom'] = famille.get('nom', '')
        resultat['detail'] = famille.get('raison', '')
        resultat['ambigu'] = bool(famille.get('ambiguite'))
        resultat['source'] = 'retro_binaires.famille()'
        if famille.get('famille') == 'class-java' and len(donnees) >= 8:
            mineure, majeure = struct.unpack_from('>HH', donnees, 4)
            resultat['majeure'] = majeure
            resultat['mineure'] = mineure
            resultat['version_java'] = majeure - 44
        if resultat['ambigu']:
            resultat['explication'] = (
                '0xCAFEBABE signe à la fois une classe Java et un binaire '
                'universel Mach-O. Le départage se fait sur les octets qui '
                'suivent : une classe Java porte un numéro de version mineure '
                'presque toujours nul puis une version majeure entre 45 et 70 ; '
                'un universel Mach-O porte un nombre d’architectures en '
                'grand-boutisme, en pratique 1 à 4.')
    else:
        resultat.update(_signature_locale(donnees, notes))
        resultat['source'] = 'table locale de retro_fiches'
    if resultat.get('famille') in ('elf', 'elf32', 'elf64') \
            and retro_binaires is not None and len(donnees) >= 20:
        resultat['classe'] = '64 bits' if donnees[4] == 2 else '32 bits'
        resultat['boutisme'] = ('grand-boutisme' if donnees[5] == 2
                                else 'petit-boutisme')
    return {'ok': True, 'notes': notes, 'resultat': resultat}


SIGNATURES_LOCALES = (
    (b'\x7fELF', 'elf', 'Exécutable ou objet ELF (Linux, BSD, Solaris).'),
    (b'MZ', 'pe', 'Exécutable DOS ou PE (Windows). Le vrai décalage de '
                  'l’en-tête PE est à 0x3C.'),
    (b'\xcf\xfa\xed\xfe', 'macho', 'Mach-O 64 bits, petit-boutisme.'),
    (b'\xce\xfa\xed\xfe', 'macho', 'Mach-O 32 bits, petit-boutisme.'),
    (b'\xfe\xed\xfa\xcf', 'macho', 'Mach-O 64 bits, grand-boutisme.'),
    (b'\xca\xfe\xba\xbe', 'class-java', 'Classe Java OU universel Mach-O.'),
    (b'\x00asm', 'wasm', 'WebAssembly.'),
    (b'UPX!', 'upaquetage', 'Signature UPX, présente aussi en fin de fichier.'),
    (b'\x1f\x8b', 'gzip', 'Flux gzip.'),
    (b'BZh', 'bzip2', 'Flux bzip2.'),
    (b'\xfd7zXZ', 'xz', 'Flux xz.'),
    (b'PK\x03\x04', 'zip', 'Archive ZIP (et donc .jar, .apk, .docx, .whl).'),
    (b'%PDF', 'pdf', 'Document PDF.'),
    (b'\x89PNG', 'png', 'Image PNG.'),
    (b'\xff\xd8\xff', 'jpeg', 'Image JPEG.'),
    (b'GIF8', 'gif', 'Image GIF.'),
    (b'\x66\x74\x79\x70', 'mp4', 'Conteneur ISO BMFF (mp4, heic, avif) — '
                                  'la signature est à l’offset 4.'),
    (b'SQLite format 3\x00', 'sqlite', 'Base SQLite.'),
)


def _signature_locale(donnees, notes):
    for signature, famille, detail in SIGNATURES_LOCALES:
        if donnees[:len(signature)] == signature:
            sortie = {'famille': famille, 'detail': detail}
            if famille == 'class-java' and len(donnees) >= 8:
                mineure, majeure = struct.unpack_from('>HH', donnees, 4)
                sortie['ambigu'] = True
                if majeure < 45 or majeure > 80 or mineure > 3:
                    sortie['famille'] = 'macho-universel'
                    sortie['detail'] = ('Binaire universel Mach-O : %d '
                                        'architecture(s).'
                                        % struct.unpack_from('>I', donnees, 4)[0])
                    sortie['ambigu'] = False
                else:
                    sortie['majeure'] = majeure
                    sortie['mineure'] = mineure
                    sortie['version_java'] = majeure - 44
            return sortie
    notes.append('aucune signature connue : %s. Le format est peut-être sans '
                 'signature, ou la table en retard.'
                 % ' '.join('%02x' % o for o in donnees[:8]))
    return {'famille': 'inconnue', 'detail': '', 'ambigu': False}


def widget_registre(entrees):
    architecture = _texte(entrees.get('architecture'), 'x86-64').strip().lower()
    if architecture not in CONVENTIONS:
        return _refus('architecture', '%r est inconnue. Architectures : %s'
                      % (entrees.get('architecture'),
                         ', '.join(sorted(CONVENTIONS))))
    convention = CONVENTIONS[architecture]
    nom = _texte(entrees.get('registre')).strip().lower()
    notes = []
    if retro_binaires is None:
        notes.append('retro_binaires est absent : les tables de ce widget sont '
                     'celles de retro_fiches, plus courtes.')
    if not nom:
        return {'ok': True, 'notes': notes + [
            'Source complète des registres et mnémoniques : assembleur.py, '
            'qui en porte 200 et 404. Ce widget ne cite que la convention '
            'd’appel.'], 'resultat': {
                'architecture': architecture,
                'convention': convention['description'],
                'arguments': convention['arguments'],
                'retour': convention['retour'],
                'pile': convention['pile'], 'cadre': convention['cadre'],
                'compteur': convention['compteur'],
                'drapeaux': convention['drapeaux'],
                'preserves': convention['preserves'],
                'volatils': convention['volatils'],
                'registres': len(convention['preserves'])
                + len(convention['volatils']),
            }}
    # Recherche du registre : nom exact, alias de largeur, ou nom canonique.
    canonique = None
    for complet, alias in ALIAS_REGISTRES.items():
        if nom == complet or nom in [a for a in alias if a]:
            canonique = complet
            break
    largeur = None
    if canonique:
        largeur = 64
        if canonique.startswith(('x',)) and architecture.startswith('arm'):
            largeur = 64
        for position, alias in enumerate(ALIAS_REGISTRES.get(canonique, ())):
            if alias == nom:
                largeur = (32, 16, 8, 8)[position] if position < 4 else 64
                break
    if architecture == 'arm32':
        largeur = 32
    if canonique is None and re.fullmatch(r'r\d{1,2}|x\d{1,2}|w\d{1,2}', nom):
        canonique = nom
        largeur = 64 if nom[0] in 'rx' and not nom.startswith('w') else 32
        notes.append('« %s » n’est pas dans la table d’alias : la largeur est '
                     'déduite du préfixe, ce qui peut être faux.' % nom)
    if canonique is None:
        return {'ok': True, 'notes': notes + [
            '« %s » n’est pas un registre de %s. Registres de la convention : '
            '%s.' % (nom, architecture, ', '.join(
                convention['arguments'] + [convention['retour'],
                                           convention['pile']]))],
            'resultat': {'registre': nom, 'architecture': architecture,
                         'connu': False}}
    role = ROLES_X86_64.get(canonique, '')
    if not role and architecture == 'x86-64':
        if canonique in convention['preserves']:
            role = 'préservé par l’appelé'
        elif canonique in convention['volatils']:
            role = 'volatil, écrasé par l’appelé'
    if canonique in convention['arguments']:
        role = '%d%s argument' % (convention['arguments'].index(canonique) + 1,
                                  'er' if convention['arguments'].index(
                                      canonique) == 0 else 'e')
    return {'ok': True, 'notes': notes, 'resultat': {
        'registre': canonique, 'demande': nom, 'architecture': architecture,
        'connu': True, 'largeur': largeur, 'role': role or 'non documenté ici',
        'alias': [a for a in ALIAS_REGISTRES.get(canonique, ()) if a],
        'preservé': canonique in convention['preserves'],
        'volatile': canonique in convention['volatils'],
        'convention': convention['description'],
    }}


FONCTIONS_WIDGETS = {
    'convertisseur': widget_convertisseur,
    'empreintes': widget_empreintes,
    'entropie': widget_entropie,
    'hexdump': widget_hexdump,
    'motif': widget_motif,
    'xor': widget_xor,
    'structure': widget_structure,
    'rva': widget_rva,
    'masques': widget_masques,
    'ascii': widget_ascii,
    'guid': widget_guid,
    'horodatage': widget_horodatage,
    'base64': widget_base64,
    'signature': widget_signature,
    'registre': widget_registre,
}


def executer_widget(identifiant, entrees=None):
    """Exécute un widget. Rend toujours un dict, jamais de levée."""
    identifiant = _texte(identifiant).strip()
    fonction = FONCTIONS_WIDGETS.get(identifiant)
    if fonction is None:
        return {'ok': False, 'resultat': None, 'notes': [],
                'erreur': 'Le widget « %s » n’existe pas. Widgets : %s.'
                          % (identifiant, ', '.join(ORDRE_WIDGETS))}
    entrees = dict(entrees or {})
    spec = WIDGETS[identifiant]
    for champ in spec['entrees']:
        if champ['nom'] not in entrees or entrees[champ['nom']] is None:
            entrees[champ['nom']] = champ.get('defaut')
    try:
        reponse = fonction(entrees)
    except Exception as exc:                      # pragma: no cover - filet
        # Un widget qui lève est un défaut, mais il ne doit pas emporter la
        # route HTTP : on rend l'exception, nommée.
        reponse = {'ok': False, 'resultat': None,
                   'erreur': 'Le widget « %s » a levé %s : %s'
                             % (identifiant, type(exc).__name__, exc),
                   'notes': []}
    if not isinstance(reponse, dict):               # pragma: no cover - filet
        reponse = {'ok': False, 'resultat': None, 'notes': [],
                   'erreur': 'Le widget a rendu %r' % type(reponse)}
    reponse.setdefault('ok', True)
    reponse.setdefault('notes', [])
    reponse.setdefault('resultat', None)
    reponse['widget'] = identifiant
    return reponse


def widgets():
    """La liste des widgets, dans l'ordre d'affichage du panneau."""
    return [dict(WIDGETS[identifiant], id=identifiant)
            for identifiant in ORDRE_WIDGETS]


# =============================================================================
#  CAPACITÉS ET AUTOCONTRÔLE
# =============================================================================

def capacites():
    """Ce que ce module peut rendre, et ce qu'il ne peut pas.

    Le panneau appelle cette fonction pour décider quoi afficher. Une capacité
    absente y est nommée avec sa raison : afficher un widget qui rendrait
    « erreur » serait pire que de ne pas l'afficher, mais afficher un widget
    absent sans dire pourquoi laisse croire à un bug.
    """
    manquants = []
    modules_ok = {}
    for nom in ('retro_binaires', 'retro_ghidra', 'retro_detection',
                'assembleur'):
        module = MODULES_DEPENDANTS.get(nom)
        modules_ok[nom] = module is not None
        if module is None:
            manquants.append('%s : import impossible' % nom)

    # Les widgets qui délèguent à retro_binaires gardent une table locale en
    # secours, mais le secours est une table PLUS COURTE : le dire.
    delegues = []
    for identifiant in ORDRE_WIDGETS:
        if WIDGETS[identifiant].get('delegue_a'):
            delegues.append(identifiant)

    exemple_incorrects = [
        identifiant for identifiant in ORDRE_WIDGETS
        if not WIDGETS[identifiant].get('exemple')
    ]
    if exemple_incorrects:
        manquants.append('widget(s) sans exemple vérifié : %s'
                         % ', '.join(exemple_incorrects))

    return {'ok': not manquants,
            'version': VERSION,
            'widgets': list(ORDRE_WIDGETS),
            'nombre_widgets': len(ORDRE_WIDGETS),
            'widgets_delegues': delegues,
            'fiches': len(FICHES),
            'categories': [c[0] for c in CATEGORIES],
            'faits': sum(len(f['faits']) for f in FICHES),
            'modules': modules_ok,
            'assembleur': assembleur_present(),
            'manquants': manquants,
            # Ce module ne calcule rien sur un fichier : il rend des tables, des
            # conversions et du texte. Le dire évite de croire qu'un widget
            # analyse un binaire ouvert.
            'lit_des_fichiers': False,
            'execute_des_binaires': False}


MODULES_DEPENDANTS = {}


def _recharger_dependances():
    """Recharge les modules dépendants dans MODULES_DEPENDANTS.

    Appelé à l'import et par verifier() : les tests peuvent remplacer un module
    par un faux, et capacites() doit le voir.
    """
    MODULES_DEPENDANTS.clear()
    for nom in ('retro_binaires', 'retro_ghidra', 'retro_detection',
                'assembleur'):
        module = globals().get(nom)
        if module is None and nom == 'assembleur':
            module = _importer_assembleur()
        MODULES_DEPENDANTS[nom] = module
    return MODULES_DEPENDANTS


def _importer_assembleur():
    try:
        import assembleur
        return assembleur
    except Exception:
        return None


def _espace_faits():
    """L'espace de noms dans lequel chaque fait est évalué.

    Les faits sont du code, écrit par celui qui a écrit la fiche. Les évaluer
    dans un espace qui ne contient QUE ce dont ils ont besoin rend visible toute
    dépendance implicite : un fait qui utilise un nom absent échoue au lieu de
    passer par accident.
    """
    return {'struct': struct, 're': re, 'shutil': shutil, 'math': math,
            'hashlib': hashlib, 'base64': base64, 'binascii': binascii,
            'os': os, 'time': time, 'Path': Path,
            'retro_binaires': retro_binaires, 'retro_ghidra': retro_ghidra,
            'retro_detection': retro_detection,
            'retro_fiches': sys.modules[__name__],
            'assembleur': _importer_assembleur() or _module_manquant('assembleur'),
            '_source': _source, '_commandes_pyghidra': _commandes_pyghidra}


class _module_manquant:
    """Un substitut qui lève un AttributeError nommé dès qu'on y touche.

    Sans lui, un fait citant un module absent échouerait avec
    « 'NoneType' object has no attribute … » : le nom du module manquant serait
    perdu, et celui qui lit l'autocontrôle ne saurait pas quoi installer.
    """

    def __init__(self, nom):
        self._nom = nom

    def __getattr__(self, attribut):
        raise AttributeError(
            'le module %s est absent : le fait qui cite %s.%s ne peut pas être '
            'vérifié' % (self._nom, self._nom, attribut))


def verifier(bavard=False):
    """Autocontrôle : rend (nombre_de_contrôles, liste_des_échecs).

    Trois familles de contrôles, toutes exécutées ici et pas seulement dans un
    banc séparé :

    1. la cohérence des tables : chaque widget a une fonction, chaque fonction
       un widget, chaque fiche une catégorie existante et un identifiant unique ;
    2. chaque FAIT de chaque fiche est ÉVALUÉ. Un fait non évalué est une
       affirmation gratuite : c'est exactement ce qui a fait écrire « 0x4160
       contient DYNAMIC_BASE » dans ce module, et l'évaluation l'a contredit ;
    3. chaque EXEMPLE de chaque widget est EXÉCUTÉ et comparé à son annoncé.
       Un exemple faux apprend une valeur fausse à l'utilisateur.

    Rien ne lève : un fait qui lève est un échec nommé, avec la fiche et le fait.
    """
    echecs = []
    controles = [0]

    def controler(condition, message):
        controles[0] += 1
        if not condition:
            echecs.append(message)
        return bool(condition)

    def sans_lever(appel, message):
        """Exécute `appel()` et rend (résultat, True) ou (None, False).

        Une levée devient un ÉCHEC NOMMÉ au lieu d'interrompre l'autocontrôle.
        Sans cela, un produit muté pour lever PLANTE le banc : le balayage de
        mutations ne distingue plus « tué par un échec nommé » de « planté », et
        surtout le banc ne teste plus rien après la levée. C'est exactement ce
        qui a laissé passer la mutation « un widget inconnu lève au lieu de
        refuser » : l'autocontrôle s'arrêtait sur le KeyError sans rien dire de
        ce qu'il venait de cesser de vérifier.
        """
        controles[0] += 1
        try:
            return appel(), True
        except Exception as exc:
            echecs.append('%s : %s (%s)' % (message, type(exc).__name__, exc))
            return None, False

    espace = _espace_faits()

    # --- 1. cohérence des tables -------------------------------------------
    for identifiant in ORDRE_WIDGETS:
        controler(identifiant in WIDGETS,
                  'ORDRE_WIDGETS cite « %s », absent de WIDGETS' % identifiant)
        controler(identifiant in FONCTIONS_WIDGETS,
                  'le widget « %s » n’a pas de fonction' % identifiant)
    for identifiant in WIDGETS:
        controler(identifiant in ORDRE_WIDGETS,
                  'WIDGETS contient « %s », absent d’ORDRE_WIDGETS : '
                  'l’ordre d’affichage l’oublierait' % identifiant)
        spec = WIDGETS[identifiant]
        controler(bool(spec.get('nom')), 'le widget « %s » n’a pas de nom'
                  % identifiant)
        controler(bool(spec.get('resume')),
                  'le widget « %s » n’a pas de résumé : le panneau '
                  'afficherait un titre sans dire à quoi il sert' % identifiant)
        controler(isinstance(spec.get('entrees'), list),
                  'le widget « %s » n’a pas de liste d’entrées' % identifiant)
        for champ in spec.get('entrees', ()):
            controler(bool(champ.get('nom')),
                      'une entrée du widget « %s » n’a pas de nom' % identifiant)
            controler(champ.get('type') in ('texte', 'nombre', 'zone', 'choix',
                                            'fichier'),
                      'l’entrée « %s » du widget « %s » a le type inconnu « %s »'
                      % (champ.get('nom'), identifiant, champ.get('type')))
        exemple = spec.get('exemple')
        controler(bool(exemple), 'le widget « %s » n’a pas d’exemple : rien ne '
                  'prouve qu’il rend ce qu’il annonce' % identifiant)
    for identifiant in FONCTIONS_WIDGETS:
        controler(identifiant in WIDGETS,
                  'la fonction « %s » n’a pas de spécification' % identifiant)

    categories_connues = {c[0] for c in CATEGORIES}
    vus = set()
    for entree in FICHES:
        identifiant = entree['id']
        controler(identifiant not in vus, 'identifiant de fiche en double : %s'
                  % identifiant)
        vus.add(identifiant)
        controler(entree['categorie'] in categories_connues,
                  'la fiche « %s » cite la catégorie inconnue « %s »'
                  % (identifiant, entree['categorie']))
        controler(bool(entree.get('titre')), 'la fiche « %s » n’a pas de titre'
                  % identifiant)
        controler(bool(entree.get('resume')), 'la fiche « %s » n’a pas de résumé'
                  % identifiant)
        controler(bool(entree.get('sections')),
                  'la fiche « %s » n’a aucune section : elle serait vide'
                  % identifiant)
        for lien in entree.get('liens', ()):
            controler(lien in {f['id'] for f in FICHES},
                      'la fiche « %s » renvoie vers « %s », qui n’existe pas'
                      % (identifiant, lien))
    for categorie in categories_connues:
        controler(any(f['categorie'] == categorie for f in FICHES),
                  'la catégorie « %s » ne contient aucune fiche' % categorie)

    # --- 2. chaque fait est évalué -----------------------------------------
    for entree in FICHES:
        for description, expression in entree['faits']:
            controles[0] += 1
            try:
                valeur = eval(expression, dict(espace))          # noqa: S307
            except Exception as exc:
                echecs.append('fiche « %s », fait « %s » : %s (%s)'
                              % (entree['id'], description,
                                 type(exc).__name__, exc))
                continue
            if valeur is not True:
                echecs.append('fiche « %s », fait « %s » : évalué à %r au lieu '
                              'de True' % (entree['id'], description, valeur))

    # --- 3. chaque exemple de widget est exécuté ---------------------------
    for identifiant in ORDRE_WIDGETS:
        exemple = WIDGETS[identifiant].get('exemple') or {}
        entrees = exemple.get('entrees') or {}
        reponse = executer_widget(identifiant, entrees)
        controles[0] += 1
        if not reponse.get('ok'):
            echecs.append('exemple du widget « %s » : %s'
                          % (identifiant, reponse.get('erreur')))
            continue
        for cle, attendu in (exemple.get('attendu') or {}).items():
            controles[0] += 1
            obtenu = (reponse.get('resultat') or {}).get(cle,
                                                         '<clé absente>')
            if obtenu != attendu:
                echecs.append('exemple du widget « %s » : %s = %r, annoncé %r'
                              % (identifiant, cle, obtenu, attendu))

    # --- 4. les accès publics ne lèvent jamais -----------------------------
    for appel, fonction in (
            ('fiche("inconnu")', lambda: fiche('inconnu')),
            ('fiches("inconnu")', lambda: fiches('inconnu')),
            ('chercher_fiche("")', lambda: chercher_fiche('')),
            ('chercher_fiche(None)', lambda: chercher_fiche(None)),
            ('executer_widget("inconnu")',
             lambda: executer_widget('inconnu')),
            ('executer_widget(None)', lambda: executer_widget(None)),
            ('executer_widget("masques", {})',
             lambda: executer_widget('masques', {})),
            ('capacites()', lambda: capacites()),
    ):
        controles[0] += 1
        try:
            resultat = fonction()
        except Exception as exc:
            echecs.append('%s a levé %s : %s' % (appel, type(exc).__name__, exc))
            continue
        controler(isinstance(resultat, (dict, list)),
                  '%s rend %s au lieu d’un dict ou d’une liste'
                  % (appel, type(resultat).__name__))

    # Un widget inconnu et un widget existant doivent être distinguables.
    controles[0] += 1
    inconnu, _leve = sans_lever(
        lambda: executer_widget('widget-qui-n-existe-pas'),
        'executer_widget() sur un widget inconnu a levé au lieu de refuser')
    if inconnu is not None:
        if inconnu.get('ok') is not False or not inconnu.get('erreur'):
            echecs.append('executer_widget() sur un widget inconnu n’a pas rendu '
                          'ok=False avec une erreur nommée')

    # --- les gardes d'executer_widget(), de fiche() et de fiches() ----------
    # Le balayage de mutations (mutations-retro-facades.py) a montré que SIX de
    # ces gardes n'étaient vérifiées par aucun contrôle : les muter laissait
    # l'autocontrôle vert. Une couverture supposée n'est pas une couverture, et
    # chaque contrôle ci-dessous correspond à une mutation nommée qu'il tue.
    for identifiant in ORDRE_WIDGETS:
        # (a) Une entrée absente reçoit sa valeur DÉCLARÉE par défaut. Mutée en
        #     None, chaque widget recevrait une entrée vide et refuserait — le
        #     panneau qui ouvre un widget sans rien saisir n'afficherait plus
        #     l'exemple que la spécification promet.
        reponse, _ok = sans_lever(
            lambda i=identifiant: executer_widget(i, {}),
            'executer_widget(« %s », {}) a levé' % identifiant)
        controler(reponse is not None and reponse.get('ok') is True,
                  'le widget « %s » n’accepte pas ses propres valeurs par '
                  'défaut : %s' % (identifiant, (reponse or {}).get('erreur')))
        # (b) La réponse porte l'identifiant du widget : c'est ce qui intitule
        #     le résultat dans le panneau. Muté en None, l'intitulé disparaît et
        #     deux widgets ouverts à la suite deviennent indiscernables.
        controler(reponse is not None and reponse.get('widget') == identifiant,
                  'le widget « %s » ne rend pas son identifiant (%r)'
                  % (identifiant, (reponse or {}).get('widget')))

    # (c) L'ordre rendu est celui d'ORDRE_WIDGETS, pas un ordre de tri : le
    #     panneau liste les widgets dans l'ordre choisi par le module, qui va du
    #     plus fréquent au plus spécialisé.
    controle_ordre, _ok = sans_lever(
        lambda: [w['id'] for w in widgets()],
        'widgets() a levé')
    controler(controle_ordre == list(ORDRE_WIDGETS),
              'widgets() ne suit pas ORDRE_WIDGETS : l’ordre d’affichage du '
              'panneau ne serait plus celui du module (%r)' % (controle_ordre,))

    # (d) _refus() NOMME le champ en cause. « valeur : illisible » dit quoi
    #     corriger ; « illisible » seul ne le dit pas, et l'utilisateur doit
    #     deviner laquelle de ses entrées est rejetée.
    refus, _ok = sans_lever(lambda: _refus('valeur', 'illisible'),
                            '_refus() a levé')
    controler(refus is not None
              and str(refus.get('erreur', '')).startswith('valeur'),
              '_refus() ne nomme pas le champ en cause (%r)'
              % (refus or {}).get('erreur'))
    controler(refus is not None and refus.get('ok') is False
              and refus.get('resultat') is None,
              '_refus() ne rend pas la forme attendue par le panneau')

    # (e) fiche() cherche l'identifiant EXACT. Une recherche par préfixe
    #     rendrait « rva » pour la demande « rv » : le panneau afficherait une
    #     fiche que l'utilisateur n'a pas demandée, sans le dire.
    identifiants = [entree['id'] for entree in FICHES]
    for identifiant in identifiants:
        trouve, _ok = sans_lever(lambda i=identifiant: fiche(i),
                                 'fiche(« %s ») a levé' % identifiant)
        controler(trouve is not None and trouve.get('ok') is True
                  and (trouve.get('fiche') or {}).get('id') == identifiant,
                  'fiche(« %s ») ne rend pas la fiche de cet identifiant'
                  % identifiant)
    for prefixe in sorted({i[:-1] for i in identifiants if len(i) > 2}):
        if prefixe in identifiants:
            continue                      # ce préfixe est un identifiant réel
        reponse, _ok = sans_lever(lambda p=prefixe: fiche(p),
                                  'fiche(« %s ») a levé' % prefixe)
        controler(reponse is not None and reponse.get('ok') is False,
                  'fiche(« %s ») accepte un PRÉFIXE au lieu de le refuser : '
                  'une fiche non demandée serait affichée' % prefixe)

    # (f) fiches(categorie=...) FILTRE. Un filtre inversé rendrait les fiches
    #     des AUTRES catégories sous un titre qui ne leur correspond pas.
    for cle, _titre in CATEGORIES:
        liste, _ok = sans_lever(lambda c=cle: fiches(categorie=c),
                                'fiches(categorie=%r) a levé' % cle)
        attendu = [i for i in identifiants
                   if [f for f in FICHES if f['id'] == i][0]['categorie'] == cle]
        obtenu = [f['id'] for f in (liste or {}).get('fiches', [])]
        controler(liste is not None and obtenu == attendu,
                  'fiches(categorie=%r) ne rend pas exactement les %d fiche(s) '
                  'de cette catégorie (obtenu %d)' % (cle, len(attendu),
                                                      len(obtenu)))
    inconnue, _ok = sans_lever(lambda: fiches(categorie='categorie-inconnue'),
                               'fiches() sur une catégorie inconnue a levé')
    controler(inconnue is not None and inconnue.get('fiches') == []
              and inconnue.get('nombre') == 0,
              'fiches() sur une catégorie inconnue ne rend pas une liste vide '
              'et le dit')

    capacite = capacites()
    controler(capacite['nombre_widgets'] == len(ORDRE_WIDGETS),
              'capacites() annonce un nombre de widgets incohérent')
    controler(capacite['execute_des_binaires'] is False,
              'capacites() doit déclarer qu’aucun binaire n’est exécuté')

    if bavard:
        for echec in echecs:
            print('ÉCHEC : %s' % echec)
    return controles[0], echecs


_recharger_dependances()


if __name__ == '__main__':
    _recharger_dependances()
    nombre, echecs = verifier(bavard=True)
    capacite = capacites()
    if capacite['assembleur'].get('present'):
        assembleur_etat = ('assembleur présent : %d registres, %d mnémoniques'
                           % (capacite['assembleur']['registres'],
                              capacite['assembleur']['mnemoniques']))
    else:
        assembleur_etat = 'assembleur absent (%s)' % (
            capacite['assembleur'].get('raison', 'raison inconnue'))
    print('retro_fiches %s : %d contrôle(s) ; %d widget(s) ; %d fiche(s) dans '
          '%d catégorie(s) ; %d fait(s) évalué(s) ; %s ; autocontrôle %s'
          % (VERSION, nombre, capacite['nombre_widgets'], capacite['fiches'],
             len(capacite['categories']), capacite['faits'], assembleur_etat,
             'OK' if not echecs else 'ÉCHEC (%d)' % len(echecs)))
    if echecs:
        for echec in echecs:
            print('ÉCHEC : %s' % echec)
        sys.exit(1)
    sys.exit(0)
