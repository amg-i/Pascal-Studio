"""Heuristic diagnostics after non-zero exits for Ruby exceptions and Rust/Go panics.
The original programs run unchanged. Terminal output may imitate a traceback.
"""
import hashlib,re
from pathlib import Path
ANSI=re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
RUBY=re.compile(r'^(.+?\.rb):(\d+)(?::in [`\'‘].*?[\'’])?:\s*(.*?\([^()\r\n]*(?:Error|Exception|Interrupt|Exit)\))\s*$',re.M)
RUST=re.compile(r"^thread ['‘].*?['’] panicked at (.+?\.rs):(\d+):(\d+):\s*$",re.M)
GO=re.compile(r'^\s*(.+?\.go):(\d+)(?:\s+\+0x[0-9a-f]+)?\s*$',re.M)

def parse(output,code,kind,root,cwd,external_files,started_ns):
 if code in (None,0) or kind not in ('rust','go','ruby'):return []
 text=ANSI.sub('',output).replace('\r\n','\n').replace('\r','\n');match=None;message='';column=1
 if kind=='ruby':
  match=RUBY.search(text)
  if match:message=match.group(3)
 elif kind=='rust':
  match=RUST.search(text)
  if match:
   column=int(match.group(3));rest=text[match.end():].strip().splitlines();message='Panique Rust : '+(rest[0] if rest else 'panique non interceptée')
 else:
  panic=re.search(r'^panic:\s*(.*)$',text,re.M)
  if panic:match=GO.search(text[panic.end():]);message='Panique Go : '+panic.group(1)
 if not match:return []
 try:
  p=Path(match.group(1));p=(p if p.is_absolute() else Path(cwd)/p).resolve();root=Path(root).resolve()
  try:key=p.relative_to(root).as_posix()
  except ValueError:key=next((k for k,v in external_files.items() if Path(v).resolve()==p),'')
  if not key or p.suffix.lower() not in ('.rs','.go','.rb') or not p.is_file():return []
  stat=p.stat()
  if stat.st_mtime_ns>started_ns or stat.st_size>2_000_000:return []
  with p.open('r',encoding='utf8',newline='') as f:source=f.read()
  if p.stat().st_mtime_ns!=stat.st_mtime_ns:return []
  line=int(match.group(2));lines=source.splitlines()
  if line<1 or line>len(lines):return []
  # Rust reports character columns; Go and Ruby backtraces usually omit columns.
  src=lines[line-1]
  if kind=='rust':column=len(src[:max(0,column-1)].encode('utf-16-le'))//2+1
  else:column=len(src[:len(src)-len(src.lstrip())].encode('utf-16-le'))//2+1
  return [{'file':key,'line':line,'column':column,'endColumn':column+1,'severity':'error','message':'Exécution '+kind.capitalize()+' : '+message[:700],'code':'Runtime'+kind.capitalize(),'sourceHash':hashlib.sha256(source.encode('utf8')).hexdigest()}]
 except (OSError,ValueError,UnicodeError):return []
