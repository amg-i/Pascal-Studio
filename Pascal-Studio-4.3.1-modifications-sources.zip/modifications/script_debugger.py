"""Integrated Python bdb and Node inspector adapters for the IDE debug panel.

The Python control socket is inherited, and Node binds its inspector to an
unpredictable local-only port. Neither mechanism is a security sandbox.
"""
import json, os, pty, queue, re, shutil, signal, socket, subprocess, sys, termios, threading, time, urllib.parse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'vendor'))
import websocket

class ScriptDebugger:
 def __init__(self,root,external_files=None):
  self.root=Path(root).resolve();self.external_files=external_files if external_files is not None else {};self.lock=threading.RLock();self.sendlock=threading.Lock();self.stoplock=threading.Lock();self.pending={};self.seq=0;self.proc=None;self.master=None;self.channel=None;self.mode=None;self.bpmap={};self.frames_raw=[];self.first_pause=True
  self.data={'active':False,'state':'idle','reason':'','frame':None,'frames':[],'variables':[],'output':'','message':'','breakpoints':[]}
 def snapshot(self):
  with self.lock:return dict(self.data)
 def file(self,key):
  if not isinstance(key,str):raise ValueError('Fichier invalide.')
  p=self.external_files.get(key) if key.startswith('@external:') else (self.root/key).resolve()
  if p is None or (not key.startswith('@external:') and not p.is_relative_to(self.root)) or not p.is_file():raise ValueError('Fichier de point d’arrêt invalide.')
  return Path(p).resolve()
 def key(self,path):
  if path.startswith('file://'):path=urllib.parse.unquote(urllib.parse.urlparse(path).path)
  try:
   p=Path(path).resolve()
   try:return p.relative_to(self.root).as_posix()
   except ValueError:return next((k for k,v in self.external_files.items() if Path(v).resolve()==p),'')
  except (ValueError,OSError):return ''
 def _output(self,text):
  with self.lock:self.data['output']=(self.data['output']+text)[-2_000_000:]
 def request(self,command,args=None,timeout=8):
  with self.lock:
   if not self.channel:raise ValueError('Session de débogage inactive.')
   self.seq+=1;ident=self.seq;waiter=queue.Queue(1);self.pending[ident]=waiter;channel=self.channel;mode=self.mode
  obj={'id':ident,'command':command,'args':args or {}} if mode=='python' else {'id':ident,'method':command,'params':args or {}}
  try:
   payload=json.dumps(obj,ensure_ascii=True)
   with self.sendlock:
    if mode=='python':channel.sendall((payload+'\n').encode())
    else:channel.send(payload)
   try:result=waiter.get(timeout=timeout)
   except queue.Empty:raise ValueError('Le débogueur ne répond pas.')
   if 'error' in result:
    error=result['error'];raise ValueError(error.get('message',str(error)) if isinstance(error,dict) else str(error))
   return result.get('result',{})
  finally:
   with self.lock:self.pending.pop(ident,None)
 def listen(self,channel,mode,proc):
  try:
   if mode=='python':
    with channel.makefile('r',encoding='utf8') as stream:
     for line in stream:self.event(json.loads(line),proc)
   else:
    while True:
     try:line=channel.recv()
     except websocket.WebSocketTimeoutException:continue
     if not line:break
     self.event(json.loads(line),proc)
  except (OSError,ValueError,websocket.WebSocketException):pass
  finally:
   with self.lock:
    if self.proc is proc:
     for q in self.pending.values():
      try:q.put_nowait({'error':'La session de débogage est terminée.'})
      except queue.Full:pass
 def event(self,obj,proc):
  with self.lock:
   if self.proc is not proc:return
  if 'id' in obj:
   with self.lock:q=self.pending.get(obj['id'])
   if q:
    try:q.put_nowait(obj)
    except queue.Full:pass
   return
  if self.mode=='python':
   event=obj.get('event')
   if event=='paused':
    frames=[{**f,'file':self.key(f.get('file',''))} for f in obj.get('frames',[])];frame=frames[0] if frames else None
    with self.lock:self.data.update(state='paused',reason=obj.get('reason',''),frames=frames,frame=frame,variables=obj.get('variables',[]))
   elif event=='running':
    with self.lock:self.data.update(state='running',frame=None,frames=[],variables=[])
   elif event=='finished':threading.Thread(target=self._finish,args=(proc,),daemon=True).start()
   return
  method=obj.get('method');args=obj.get('params',{})
  if method=='Debugger.resumed':
   with self.lock:self.data.update(state='running',frame=None,frames=[],variables=[])
  elif method=='Debugger.paused':
   raw=args.get('callFrames',[]);self.frames_raw=raw
   # The first break is Node's --inspect-brk bootstrap. Do not skip a user
   # breakpoint at the exact initial line.
   first=self.first_pause;self.first_pause=False
   if first:
    top=raw[0] if raw else {};loc=top.get('location',{});url=top.get('url','') or self.script_urls.get(loc.get('scriptId'),'');key=self.key(url) if url else ''
    if any(scope.get('type')=='module' for scope in top.get('scopeChain',[])) or not any(k[0]==key and k[1]==loc.get('lineNumber',-2)+1 for k in self.bpmap):
     threading.Thread(target=self._resume_initial,daemon=True).start();return
   frames=[]
   for i,f in enumerate(raw):
    loc=f.get('location',{});url=f.get('url','') or self.script_urls.get(loc.get('scriptId'),'');frames.append({'file':self.key(url) if url else '', 'line':loc.get('lineNumber',0)+1,'function':f.get('functionName') or '(global)','level':str(i)})
   with self.lock:self.data.update(state='paused',reason=args.get('reason','paused'),frame=frames[0] if frames else None,frames=frames,variables=[])
   threading.Thread(target=self._node_variables,args=(raw,proc),daemon=True).start()
  elif method=='Debugger.scriptParsed':self.script_urls[args.get('scriptId')]=args.get('url','')
  elif method=='Runtime.executionContextCreated':
   context=args.get('context',{})
   if context.get('auxData',{}).get('isDefault'):self.main_context=context.get('id')
  elif method=='Runtime.executionContextsCleared' or (method=='Runtime.executionContextDestroyed' and args.get('executionContextId')==self.main_context):
   # Node normally waits for the inspector to disconnect at program end.
   threading.Thread(target=self._finish,args=(proc,),daemon=True).start()
 def _resume_initial(self):
  try:self.request('Debugger.resume')
  except Exception:pass
 def _node_variables(self,frames,proc):
  if not frames:return
  local=next((x for x in frames[0].get('scopeChain',[]) if x.get('type') in ('local','block','script','module')),None)
  if not local:return
  try:
   props=self.request('Runtime.getProperties',{'objectId':local['object']['objectId'],'ownProperties':True}).get('result',[])
   values=[]
   for p in props[:300]:
    value=p.get('value',{});v=value.get('value',value.get('unserializableValue',value.get('description',value.get('type','?'))));values.append({'name':p.get('name','?'),'value':str(v)[:500]})
   with self.lock:
    if self.proc is proc and self.data['state']=='paused' and self.frames_raw is frames:self.data['variables']=values
  except Exception:pass
 def _finish(self,proc):
  # Let any buffered console data be drained before releasing the session.
  time.sleep(.2);self.stop(finished=True,expected=proc)
 def start(self,kind,target,breakpoints):
  if self.snapshot()['active']:raise ValueError('Arrêtez la session de débogage en cours.')
  target=self.file(target);self.mode=kind;self.script_urls={};self.main_context=None;self.first_pause=True;self.bpmap={};self.frames_raw=[]
  if len(breakpoints)>1000:raise ValueError('Trop de points d’arrêt.')
  checked=[{'key':b['path'],'line':int(b['line']),'path':str(self.file(b['path']))} for b in breakpoints]
  self.master,slave=pty.openpty();attrs=termios.tcgetattr(slave);attrs[3]&=~termios.ECHO;termios.tcsetattr(slave,termios.TCSANOW,attrs)
  parent=child=None
  try:
   if kind=='python':
    parent,child=socket.socketpair();env={**os.environ,'PS_DEBUG_FD':str(child.fileno())};cmd=[sys.executable,'-u',str(Path(__file__).with_name('python_debug_runtime.py')),str(target)]
    proc=subprocess.Popen(cmd,cwd=target.parent,stdin=slave,stdout=slave,stderr=slave,env=env,pass_fds=(child.fileno(),),start_new_session=True);child.close();self.channel=parent
   elif kind=='javascript':
    exe=shutil.which('node')
    if not exe:raise ValueError('Installez Node.js : sudo apt install nodejs')
    proc=subprocess.Popen([exe,'--inspect-brk=127.0.0.1:0',str(target)],cwd=target.parent,stdin=slave,stdout=slave,stderr=subprocess.PIPE,start_new_session=True)
   else:raise ValueError('Langage de débogage non pris en charge.')
   self.proc=proc
   with self.lock:self.data.update(active=True,state='starting',reason='',frame=None,frames=[],variables=[],output='',message='',breakpoints=[])
   master=self.master
   def read_console():
    try:
     while True:
      try:buf=os.read(master,4096)
      except OSError:break
      if not buf:break
      with self.lock:
       if self.proc is not proc:break
      self._output(buf.decode('utf8','replace').replace('\r\n','\n'))
    finally:
     try:os.close(master)
     except OSError:pass
   threading.Thread(target=read_console,daemon=True).start()
   if kind=='javascript':
    urlqueue=queue.Queue(1)
    def read_stderr():
     for raw in iter(proc.stderr.readline,b''):
      line=raw.decode('utf8','replace');match=re.search(r'Debugger listening on (ws://\S+)',line)
      if match:urlqueue.put(match.group(1))
      elif 'For help, see: https://nodejs.org/en/docs/inspector' not in line and 'Debugger attached.' not in line and 'Waiting for the debugger to disconnect' not in line:self._output(line)
     proc.stderr.close()
    threading.Thread(target=read_stderr,daemon=True).start()
    try:url=urlqueue.get(timeout=8)
    except queue.Empty:raise ValueError('Node.js n’a pas démarré son inspecteur.')
    self.channel=websocket.create_connection(url,timeout=1,suppress_origin=True,http_proxy_host=None)
   threading.Thread(target=self.listen,args=(self.channel,kind,proc),daemon=True).start()
   if kind=='python':
    self.request('setup',{'target':str(target),'breakpoints':[{'path':b['path'],'line':b['line']} for b in checked]})
    self.bpmap={(b['key'],b['line']):None for b in checked}
   else:
    self.request('Runtime.enable');self.request('Debugger.enable')
    for b in checked:self.add_breakpoint(b['key'],b['line'])
    self.request('Runtime.runIfWaitingForDebugger')
   with self.lock:
    if self.data['state']=='starting':self.data['state']='running'
    self.data['breakpoints']=[{'path':k[0],'line':k[1],'resolvedLine':k[1]} for k in self.bpmap]
   def reap():
    proc.wait()
    with self.lock:current=self.proc is proc
    if current:threading.Thread(target=self.stop,kwargs={'finished':True,'expected':proc},daemon=True).start()
   threading.Thread(target=reap,daemon=True).start()
  except Exception:
   if child:
    try:child.close()
    except OSError:pass
   if parent and self.channel is not parent:parent.close()
   self.stop();raise
  finally:
   try:os.close(slave)
   except OSError:pass
 def add_breakpoint(self,key,line):
  path=self.file(key);line=int(line)
  if line<1:raise ValueError('Ligne invalide.')
  if (key,line) in self.bpmap:return
  if self.mode=='python':self.request('breakpoint',{'path':str(path),'line':line,'enabled':True});ident=None
  else:ident=self.request('Debugger.setBreakpointByUrl',{'url':path.as_uri(),'lineNumber':line-1}).get('breakpointId')
  self.bpmap[(key,line)]=ident
  with self.lock:self.data['breakpoints']=[{'path':k[0],'line':k[1],'resolvedLine':k[1]} for k in self.bpmap]
 def remove_breakpoint(self,key,line):
  line=int(line);k=(key,line)
  if k not in self.bpmap:return
  if self.mode=='python':self.request('breakpoint',{'path':str(self.file(key)),'line':line,'enabled':False})
  else:self.request('Debugger.removeBreakpoint',{'breakpointId':self.bpmap[k]})
  self.bpmap.pop(k,None)
  with self.lock:self.data['breakpoints']=[{'path':x[0],'line':x[1],'resolvedLine':x[1]} for x in self.bpmap]
 def action(self,action):
  if action not in ('continue','next','step','finish','pause'):raise ValueError('Commande invalide.')
  if self.mode=='python':self.request(action)
  else:self.request({'continue':'Debugger.resume','next':'Debugger.stepOver','step':'Debugger.stepInto','finish':'Debugger.stepOut','pause':'Debugger.pause'}[action])
 def evaluate(self,expression):
  if self.snapshot()['state']!='paused':raise ValueError('Mettez le programme en pause avant d’évaluer.')
  if not expression.strip() or '\n' in expression:raise ValueError('Expression invalide.')
  if self.mode=='python':return self.request('evaluate',{'expression':expression}).get('value','')
  if not self.frames_raw:raise ValueError('Pile indisponible.')
  r=self.request('Debugger.evaluateOnCallFrame',{'callFrameId':self.frames_raw[0]['callFrameId'],'expression':expression,'returnByValue':True})
  if 'exceptionDetails' in r:raise ValueError(r['exceptionDetails'].get('text','Évaluation impossible.'))
  v=r.get('result',{});return str(v.get('value',v.get('unserializableValue',v.get('description','undefined'))))
 def input(self,text):
  if self.snapshot()['state']!='running':raise ValueError('Le programme n’est pas en cours d’exécution.')
  os.write(self.master,(text+'\n').encode());self._output(text+'\n')
 def stop(self,finished=False,expected=None):
  with self.stoplock:
   proc=self.proc
   if expected is not None and proc is not expected:return
   channel=self.channel;self.channel=None
   if channel:
    try:channel.close()
    except Exception:pass
   if proc and proc.poll() is None:
    try:os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
     try:os.killpg(proc.pid,signal.SIGKILL)
     except ProcessLookupError:pass
     proc.wait(timeout=2)
   with self.lock:
    if self.proc is proc:self.data.update(active=False,state='finished' if finished else 'idle',frame=None,frames=[],variables=[])
