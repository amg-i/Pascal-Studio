"""Execution commands and non-executing syntax checks for scripts."""
import ast,json,re,shutil,subprocess,sys
from pathlib import Path

def module_type(path):
 p=Path(path).resolve()
 if p.suffix.lower()=='.mjs':return 'module'
 if p.suffix.lower()=='.cjs':return 'commonjs'
 for d in (p.parent,*p.parents):
  q=d/'package.json'
  if q.is_file():
   try:return 'module' if json.loads(q.read_text(encoding='utf8')).get('type')=='module' else 'commonjs'
   except (OSError,ValueError,UnicodeError):return 'commonjs'
 return 'commonjs'

def analyze(kind,path,key,content):
 if not isinstance(content,str) or len(content.encode('utf8'))>2_000_000:raise ValueError('Tampon trop volumineux.')
 diag=[];output=''
 if kind=='python':
  worker=Path(__file__).resolve().parent/'python_analyzer.py'
  try:
   result=subprocess.run([sys.executable,'-I',str(worker),str(path),str(key)],input=content,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=8)
   if result.returncode:raise ValueError('Processus d’analyse Python arrêté.')
   parsed=json.loads(result.stdout)
   if not isinstance(parsed,dict) or 'state' not in parsed:raise ValueError('Réponse de l’analyse Python invalide.')
   parsed['output']='\n'.join(f"{x['file']}:{x['line']}:{x['column']}: {x['severity']}: {x['message']}" for x in parsed.get('diagnostics',[]))
   return parsed
  except subprocess.TimeoutExpired:return {'state':'timeout','ok':False,'diagnostics':[],'message':'Analyse Python interrompue après 8 secondes.','output':''}
  except (OSError,ValueError,json.JSONDecodeError):return {'state':'unavailable','ok':False,'diagnostics':[],'message':'Analyse Python indisponible.','output':''}
 elif kind=='ruby':
  exe=shutil.which('ruby')
  if not exe:return {'state':'unavailable','ok':False,'diagnostics':[],'message':'Installez Ruby : sudo apt install ruby.','output':''}
  try:r=subprocess.run([exe,'-c','-'],input=content,capture_output=True,text=True,errors='replace',timeout=8,cwd=Path(path).parent)
  except subprocess.TimeoutExpired:return {'state':'timeout','ok':False,'diagnostics':[],'message':'Analyse Ruby interrompue après 8 secondes.','output':''}
  output=(r.stdout+r.stderr)[-8000:]
  if r.returncode:
   match=re.search(r'(?:-:|stdin:)(\d+):\s*(.*)',output)
   diag=[{'file':key,'line':int(match.group(1)) if match else 1,'column':1,'severity':'error','message':match.group(2) if match else 'Syntaxe Ruby invalide.'}]
 elif kind in ('javascript','php'):
  name='node' if kind=='javascript' else 'php';exe=shutil.which(name)
  if not exe:return {'state':'unavailable','ok':False,'diagnostics':[],'message':f'Installez {"Node.js (nodejs)" if kind=="javascript" else "PHP (php-cli)"}.','output':''}
  cmd=[exe,'--check','--input-type='+module_type(path)] if kind=='javascript' else [exe,'-l']
  try:r=subprocess.run(cmd,input=content,capture_output=True,text=True,errors='replace',timeout=8,cwd=Path(path).parent)
  except subprocess.TimeoutExpired:return {'state':'timeout','ok':False,'diagnostics':[],'message':'Analyse interrompue après 8 secondes.','output':''}
  output=(r.stdout+r.stderr)[-8000:]
  if r.returncode:
   if kind=='javascript':
    m=re.search(r'(?:\[stdin\]|<stdin>|stdin):(?P<line>\d+)(?::(?P<col>\d+))?',output)
    row=int(m.group('line')) if m else 1;col=int(m.group('col') or 1) if m else 1
    lines=output.splitlines()
    for i,line in enumerate(lines):
     if '^' in line and i>0:col=line.index('^')+1;break
    detail=re.search(r'(?:SyntaxError|Error):\s*(.*)',output);message=detail.group(1) if detail else 'Syntaxe JavaScript invalide.'
   else:
    m=re.search(r'on line (\d+)',output);row=int(m.group(1)) if m else 1;col=1
    detail=re.search(r'(?:Parse|Fatal) error:\s*(.*?)(?: in .*? on line \d+)',output,re.I);message=detail.group(1) if detail else 'Syntaxe PHP invalide.'
   diag=[{'file':key,'line':row,'column':col,'severity':'error','message':message}]
 else:return {'state':'unsupported','ok':False,'diagnostics':[],'message':'Analyse non disponible pour ce fichier.','output':''}
 return {'state':'ready','ok':not diag,'diagnostics':diag,'message':(('Analyse Ruby : '+str(len(diag))+' erreur(s)') if diag else 'Analyse syntaxique Ruby à jour') if kind=='ruby' else ('Analyse syntaxique à jour' if not diag else None),'output':output}

def build(kind,path,key):
 path=Path(path)
 try:content=path.read_text(encoding='utf-8')
 except (OSError,UnicodeError) as e:raise ValueError('Lecture impossible : '+str(e))
 r=analyze(kind,path,key,content)
 if r['state']!='ready':
  if kind=='python':return {'ok':True,'output':'Analyse indisponible : l’interpréteur vérifiera la syntaxe au lancement.\n','diagnostics':[],'kind':kind,'command':[sys.executable,'-u',str(path)],'cwd':str(path.parent)}
  raise ValueError(r.get('message') or 'Analyse indisponible.')
 command=None
 if r['ok'] and kind=='python':command=[sys.executable,'-u',str(path)]
 elif r['ok'] and kind=='javascript':command=[shutil.which('node'),str(path)]
 elif r['ok'] and kind=='ruby':command=[shutil.which('ruby'),str(path)]
 return {'ok':r['ok'],'output':r['output'] or ('Syntaxe correcte.\n' if r['ok'] else 'Syntaxe invalide.\n'),'diagnostics':r['diagnostics'],'kind':kind,'command':command,'cwd':str(path.parent)}
