"""Swift et Kotlin : compilation mono-fichier et analyse sans exécution.

Swift utilise « swiftc » (paquet Debian « swiftlang ») ; Kotlin utilise
« kotlinc » et le lanceur « kotlin » (paquet Debian « kotlin »), qui s'appuient
sur une JVM.

L'analyse Swift utilise « swiftc -typecheck » : elle ne produit aucun binaire et
n'exécute jamais le programme. Kotlin n'a pas d'équivalent rapide : une
compilation JVM prend plusieurs dizaines de secondes, ce qui est inutilisable en
suivi en direct. Les erreurs Kotlin n'apparaissent donc qu'à la compilation.

Ces outils ne sont pas des bacs à sable : ils utilisent les mêmes droits que
l'utilisateur et peuvent lire les fichiers du projet pendant la compilation.
"""
import hashlib, os, re, shutil, subprocess, tempfile
from pathlib import Path

KINDS = {'swift': ('.swift',), 'kotlin': ('.kt', '.kts')}
TOOLS = {'swift': ('swiftc', 'swiftlang'), 'kotlin': ('kotlinc', 'kotlin')}
LAUNCHERS = {'kotlin': ('kotlin', 'java')}

# Swift n'autorise les instructions de haut niveau que dans un fichier nommé
# « main.swift ». Un programme mono-fichier porte souvent un autre nom : on
# réessaie alors sur une copie, sans modifier le fichier du projet.
TOPLEVEL = 'expressions are not allowed at the top level'

# swiftc et kotlinc signalent tous deux « chemin:ligne:colonne: niveau: message ».
DIAG = re.compile(r'^(.+?):(\d+):(\d+):\s*(error|warning):\s*(.*)$', re.M)
# kotlinc ajoute des erreurs globales sans emplacement, ex. « error: ... ».
KOTLIN_GLOBAL = re.compile(r'^error:\s*(.+)$', re.M)

SWIFT_ANALYZE_TIMEOUT = 25
SWIFT_BUILD_TIMEOUT = 240
KOTLIN_BUILD_TIMEOUT = 300


def kind(path):
    suffix = Path(path).suffix.lower()
    return next((name for name, exts in KINDS.items() if suffix in exts), None)


def executable(k):
    """Chemin de l'outil principal ; ValueError avec le paquet Debian sinon."""
    name, package = TOOLS[k]
    exe = shutil.which(name)
    if not exe:
        raise ValueError('Installez ' + package + ' : sudo apt install ' + package)
    if k == 'kotlin':
        missing = [x for x in LAUNCHERS['kotlin'] if not shutil.which(x)]
        if missing:
            raise ValueError('Kotlin requiert aussi ' + ' et '.join(missing) +
                             ' : sudo apt install kotlin default-jre-headless')
    return exe


def invoke(cmd, cwd, timeout=30):
    """Exécute sans shell ; retourne (code, sortie fusionnée bornée)."""
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                           encoding='utf8', errors='replace', timeout=timeout,
                           env={**os.environ, 'LC_ALL': 'C.UTF-8', 'TERM': 'dumb'})
        return p.returncode, (p.stdout + p.stderr)[-200_000:]
    except subprocess.TimeoutExpired:
        raise ValueError('Compilation interrompue après ' + str(timeout) + ' secondes.')


def utf16col(content, row, col):
    """Colonne en caractères -> colonne UTF-16 attendue par l'éditeur."""
    lines = content.splitlines()
    line = lines[row - 1] if 0 < row <= len(lines) else ''
    return len(line[:max(0, col - 1)].encode('utf-16-le')) // 2 + 1


def parse_diagnostics(k, output, key, content):
    rows = []
    total = max(1, len(content.splitlines()))
    for m in DIAG.finditer(output):
        _, row, col, severity, message = m.groups()
        row = int(row)
        if row < 1 or row > total:
            row = min(max(row, 1), total)
            col = 1
        rows.append({'file': key, 'line': row, 'column': utf16col(content, row, int(col)),
                     'severity': 'warning' if severity == 'warning' else 'error',
                     'message': message[:800]})
    if k == 'kotlin' and not rows:
        m = KOTLIN_GLOBAL.search(output)
        if m:
            rows.append({'file': key, 'line': 1, 'column': 1, 'severity': 'error',
                         'message': m.group(1)[:800]})
    return rows[:100]


def _swift_run(exe, args, p, content, temp, timeout):
    """Lance swiftc sur le fichier du projet, puis sur une copie « main.swift ».

    Le second essai n'intervient que si Swift refuse le code de haut niveau,
    ce qui arrive pour tout programme mono-fichier non nommé main.swift.
    """
    code, out = invoke([exe] + args + [str(p)], p.parent, timeout=timeout)
    if code and TOPLEVEL in out:
        src = Path(temp) / 'main.swift'
        src.write_text(content, encoding='utf8')
        code, out = invoke([exe] + args + [str(src)], p.parent, timeout=timeout)
        # Les lignes sont identiques : seul le chemin affiché change.
        out = out.replace(str(src), str(p)).replace(src.name, p.name)
    return code, out


def analyze(k, path, key, content):
    """Analyse du tampon actif. N'exécute jamais le programme."""
    if not isinstance(content, str) or len(content.encode('utf8')) > 2_000_000:
        raise ValueError('Tampon trop volumineux.')
    p = Path(path)
    k = kind(p) if not k else k
    if k == 'kotlin':
        return {'state': 'unsupported', 'ok': False, 'diagnostics': [],
                'message': 'Analyse en direct indisponible pour Kotlin : la compilation JVM '
                           'prend plusieurs dizaines de secondes. Lancez le programme pour '
                           'obtenir les erreurs.',
                'output': ''}
    try:
        exe = executable(k)
    except ValueError as e:
        return {'state': 'unavailable', 'ok': False, 'diagnostics': [], 'message': str(e), 'output': ''}
    with tempfile.TemporaryDirectory(prefix='ps-swift-') as temp:
        try:
            code, out = _swift_run(exe, ['-typecheck', '-I', str(p.parent)], p, content,
                                   temp, SWIFT_ANALYZE_TIMEOUT)
        except ValueError as e:
            return {'state': 'timeout', 'ok': False, 'diagnostics': [], 'message': str(e), 'output': ''}
    found = parse_diagnostics(k, out, key, content)
    if code and not found:
        tail = out.strip().splitlines()
        found = [{'file': key, 'line': 1, 'column': 1, 'severity': 'error',
                  'message': (tail[-1] if tail else 'Analyse interrompue.')[:800]}]
    return {'state': 'ready', 'ok': code == 0, 'diagnostics': found,
            'message': None if code == 0 or found else 'Analyse Swift à jour.', 'output': out}


def build(root, build_dir, path, key, debug=False):
    """Compile un seul fichier. Retourne un binaire (Swift) ou une commande (Kotlin)."""
    p = Path(path).resolve()
    k = kind(p)
    try:
        content = p.read_text(encoding='utf8')
    except (OSError, UnicodeError) as e:
        raise ValueError('Lecture impossible : ' + str(e))
    exe = executable(k)
    base = {'kind': k, 'diagnostics': [], 'cwd': str(p.parent)}

    if k == 'kotlin':
        if p.suffix.lower() == '.kts':
            # Un script .kts est compilé puis exécuté par kotlinc au lancement.
            return {**base, 'ok': True, 'binary': None,
                    'output': 'Script Kotlin : kotlinc le compile puis l’exécute au lancement.\n',
                    'command': [exe, '-script', str(p)]}
        jar = Path(build_dir) / ('kotlin-' + hashlib.sha256(str(p).encode()).hexdigest()[:20] + '.jar')
        jar.unlink(missing_ok=True)
        args = ['-g'] if debug else []
        try:
            code, out = invoke([exe] + args + ['-d', str(jar), str(p)], p.parent,
                               timeout=KOTLIN_BUILD_TIMEOUT)
        except ValueError as e:
            return {**base, 'ok': False, 'binary': None, 'output': str(e) + '\n', 'command': None}
        found = parse_diagnostics(k, out, key, content)
        ok = code == 0 and jar.is_file()
        launcher = shutil.which(LAUNCHERS['kotlin'][0])
        return {**base, 'ok': ok, 'binary': None,
                'output': out or ('Compilation réussie.\n' if ok else 'Compilation impossible.\n'),
                'diagnostics': found,
                'command': [launcher, str(jar)] if ok and launcher else None}

    binary = Path(build_dir) / ('swift-' + hashlib.sha256(str(p).encode()).hexdigest()[:20])
    binary.unlink(missing_ok=True)
    with tempfile.TemporaryDirectory(prefix='ps-swiftbuild-', dir=str(build_dir)) as temp:
        args = (['-g', '-Onone'] if debug else ['-O']) + ['-I', str(p.parent), '-o', str(binary)]
        try:
            code, out = _swift_run(exe, args, p, content, temp, SWIFT_BUILD_TIMEOUT)
        except ValueError as e:
            return {**base, 'ok': False, 'binary': None, 'output': str(e) + '\n'}
    found = parse_diagnostics(k, out, key, content)
    ok = code == 0 and binary.is_file()
    return {**base, 'ok': ok,
            'output': out or ('Compilation réussie.\n' if ok else 'Compilation impossible.\n'),
            'diagnostics': found, 'binary': str(binary) if ok else None}
