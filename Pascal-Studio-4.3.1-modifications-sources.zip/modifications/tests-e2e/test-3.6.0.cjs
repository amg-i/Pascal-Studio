/* Test de bout en bout des nouveautés 3.6.0 dans l'AppImage.
 *
 *   PS_EXEC=/chemin/Pascal-Studio-3.6.0.AppImage node test-3.6.0.cjs
 *
 * Vérifie : le dialogue « Nouveau fichier » avec ses types, la création d'un
 * fichier Swift et d'un fichier Kotlin, les logos à la place des lettres, la
 * ligne d'identité du panneau Git et le panneau de persistance des connexions.
 *
 * Nécessite Playwright et Electron, comme les autres tests de ce dossier.
 */
const {_electron:electron}=require('playwright');
const fs=require('fs'),path=require('path'),os=require('os'),assert=require('assert');

const EXEC=process.env.PS_EXEC;
if(!EXEC) throw new Error('Définissez PS_EXEC avec le chemin de l’AppImage 3.6.0.');

const dossier=fs.mkdtempSync(path.join(os.tmpdir(),'ps-360-prj-'));
fs.writeFileSync(path.join(dossier,'main.pas'),'program A; begin end.\n');

(async()=>{
const app=await electron.launch({executablePath:EXEC,args:['--no-sandbox'],env:{
  ...process.env,
  PASCAL_WORKSPACE:dossier,
  XDG_CONFIG_HOME:fs.mkdtempSync(path.join(os.tmpdir(),'ps-360-cfg-')),
  XDG_CACHE_HOME:fs.mkdtempSync(path.join(os.tmpdir(),'ps-360-cache-')),
}});
const p=await app.firstWindow();
p.on('dialog',d=>d.accept());
p.on('pageerror',e=>console.log('PAGEERROR',e.message));
await p.waitForSelector('.tree-row',{timeout:30000});
console.log('Application démarrée sur',dossier);

// ----------------------------------------------------------- dialogue
async function ouvrirDialogue(){
  await p.getByText('Fichier',{exact:true}).first().click();
  await p.getByText('Nouveau fichier…',{exact:true}).click();
  await p.waitForSelector('.ps-newfile-modal',{timeout:8000});
}

await ouvrirDialogue();
const nbTypes=await p.locator('.ps-newfile-type').count();
assert.ok(nbTypes>=25,'au moins 25 types attendus, trouvé '+nbTypes);
console.log('Dialogue « Nouveau fichier » :',nbTypes,'types proposés');

// Les types ont un logo ou une lettre de repli, jamais rien.
const logos=await p.evaluate(()=>Array.from(document.querySelectorAll('.ps-newfile-logo'))
  .map(e=>({classe:e.className,texte:e.textContent})));
assert.equal(logos.length,nbTypes);
const avecLogo=logos.filter(l=>/psl-/.test(l.classe));
const avecLettre=logos.filter(l=>/ps-logo-lettre/.test(l.classe));
assert.equal(avecLogo.length+avecLettre.length,nbTypes,'chaque type a un logo ou une lettre');
assert.ok(avecLogo.length>=20,'la majorité des types ont un vrai logo, trouvé '+avecLogo.length);
for(const l of avecLogo) assert.equal(l.texte,'','un logo remplace la lettre');
assert.ok(logos.some(l=>/psl-swift/.test(l.classe)),'logo Swift présent');
assert.ok(logos.some(l=>/psl-kotlin/.test(l.classe)),'logo Kotlin présent');
console.log('Logos :',avecLogo.length,'vrais logos,',avecLettre.length,'lettres de repli');

// Aperçu du chemin avant validation.
const champ=p.locator('.ps-newfile-name');
await champ.fill('main');
await p.locator('.ps-newfile-type',{hasText:'Swift'}).first().click();
const apercu=await p.locator('.ps-newfile-preview').innerText();
assert.ok(apercu.includes('main.swift'),'aperçu attendu main.swift, obtenu : '+apercu);
console.log('Aperçu :',apercu.replace(/\s+/g,' '));
await p.getByRole('button',{name:'Créer le fichier'}).click();
await p.waitForSelector('.ps-newfile-modal',{state:'detached',timeout:8000});
await p.waitForTimeout(700);
assert.ok(fs.existsSync(path.join(dossier,'main.swift')),'main.swift créé sur le disque');
const contenuSwift=fs.readFileSync(path.join(dossier,'main.swift'),'utf8');
assert.ok(contenuSwift.includes('print("Bonjour Swift")'),contenuSwift);
console.log('main.swift créé avec son contenu de départ');

// Sous-dossier + Kotlin, sans saisir l'extension.
await ouvrirDialogue();
await p.locator('.ps-newfile-name').fill('src/App');
await p.locator('.ps-newfile-type',{hasText:'Kotlin'}).first().click();
const apercuKt=await p.locator('.ps-newfile-preview').innerText();
assert.ok(apercuKt.includes('src/App.kt'),apercuKt);
await p.getByRole('button',{name:'Créer le fichier'}).click();
await p.waitForSelector('.ps-newfile-modal',{state:'detached',timeout:8000});
await p.waitForTimeout(700);
assert.ok(fs.existsSync(path.join(dossier,'src','App.kt')),'src/App.kt créé');
assert.ok(fs.readFileSync(path.join(dossier,'src','App.kt'),'utf8').includes('fun main()'));
console.log('src/App.kt créé dans un sous-dossier');

// Annulation : Escape ne crée rien.
const avant=fs.readdirSync(dossier).length;
await ouvrirDialogue();
await p.locator('.ps-newfile-name').fill('ne-pas-creer');
await p.keyboard.press('Escape');
await p.waitForSelector('.ps-newfile-modal',{state:'detached',timeout:5000});
assert.ok(!fs.existsSync(path.join(dossier,'ne-pas-creer.swift')),'Escape ne crée rien');
console.log('Escape annule sans rien créer');

// ------------------------------------------------------------------ logos
// Les badges de l'arborescence portent le logo en image de fond, pas la lettre.
const badges=await p.evaluate(()=>{
  const out={};
  for(const el of document.querySelectorAll('.lang-file-icon')){
    const kind=(el.className.match(/lang-icon-([\w-]+)/)||[])[1];
    if(!kind) continue;
    const cs=getComputedStyle(el);
    out[kind]={image:cs.backgroundImage,couleur:cs.color,texte:el.textContent,
               titre:el.title};
  }
  return out;
});
for(const kind of ['swift','kotlin']){
  assert.ok(badges[kind],'badge manquant pour '+kind);
  assert.ok(badges[kind].image.includes('logos-langages/'+kind+'.svg'),
            'logo attendu pour '+kind+', obtenu '+badges[kind].image);
  assert.equal(badges[kind].couleur,'rgba(0, 0, 0, 0)','la lettre doit être invisible');
  assert.ok(badges[kind].texte,'le texte reste présent pour les lecteurs d’écran');
  assert.ok(badges[kind].titre,'un title doit rester');
}
console.log('Logos dans l’arborescence :',
  Object.keys(badges).filter(k=>badges[k].image.includes('logos-langages')).length,
  'langages avec un vrai logo');
// Pascal garde sa lettre : aucun logo officiel libre n'existe.
assert.ok(!badges.pascal.image.includes('logos-langages'),'Pascal garde son badge à lettres');
assert.ok(badges.pascal.couleur!=='rgba(0, 0, 0, 0)','la lettre Pascal reste visible');

// ------------------------------------------------------------------- Git
await p.evaluate(()=>fetch('/api/git',{method:'POST',headers:{'Content-Type':'application/json'},
  body:JSON.stringify({})})).catch(()=>{});
const reponseInit=await p.evaluate(async()=>{
  const r=await fetch('/api/git/init',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({})});
  return r.json();
});
assert.ok(reponseInit.repo||reponseInit.installed,'dépôt Git initialisé');
console.log('Dépôt Git initialisé dans le projet de test');

const identiteAvant=await p.evaluate(async()=>{
  const r=await fetch('/api/git');return (await r.json()).identity;
});
assert.ok(identiteAvant,'l’API renvoie une identité');
assert.equal(identiteAvant.source,'none','par défaut, aucune identité : '+JSON.stringify(identiteAvant));
console.log('Identité par défaut :',identiteAvant.source,'(aucune) — conforme');

// Se connecter à un dépôt sans compte associé ne doit poser aucune identité.
const distante=await p.evaluate(async()=>{
  const r=await fetch('/api/git/remote',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({url:'https://github.com/alice/mon-projet.git'})});
  return r.json();
});
assert.equal(distante.identity.source,'none',
  'sans compte connecté, aucune identité : '+JSON.stringify(distante.identity));
assert.ok(distante.output,'le serveur explique le résultat');
console.log('Origine posée, message :',distante.output);

// Ligne d'identité dans le panneau Git.
await p.getByText('Contrôle de version',{exact:true}).first().click().catch(()=>{});
const ligne=await p.locator('.git-identity-row').first();
if(await ligne.count()){
  const texte=await ligne.innerText();
  assert.ok(/Identité/i.test(texte),texte);
  assert.ok(/configuration globale|aucune|compte|manuelle/.test(texte),
    'la provenance doit être annoncée : '+texte);
  console.log('Panneau Git :',texte.replace(/\s+/g,' '));
}else{
  console.log('Panneau Git non ouvert dans cette configuration — vérification API seule.');
}

// --------------------------------------------------------------- comptes
{
  const bouton=p.getByText('Comptes et dépôts distants',{exact:true}).first();
  if(await bouton.count()){await bouton.click();await p.waitForTimeout(500);}
}
if(await p.locator('.ps-persist').count()){
  const resume=await p.locator('.ps-persist summary').innerText();
  assert.ok(/conserv/i.test(resume),resume);
  await p.locator('.ps-persist summary').click();
  const texte=await p.locator('.ps-persist').innerText();
  assert.ok(texte.includes('~/.config/pascal-studio/'),texte);
  assert.ok(/Ne plus rien conserver/.test(texte),'action de purge attendue');
  console.log('Panneau de persistance présent :',resume);
}else{
  console.log('Panneau des comptes non ouvert — vérification du texte du jeton seule.');
}
const html=await p.content();
assert.ok(!html.includes('conservé en mémoire jusqu’à la fermeture'),
  'l’ancien texte sur le jeton doit avoir disparu');
console.log('Ancien texte « conservé en mémoire » absent');

await app.close();
console.log('PASS');
})().catch(e=>{console.error('ECHEC :',e&&e.message||e);process.exit(1)});
