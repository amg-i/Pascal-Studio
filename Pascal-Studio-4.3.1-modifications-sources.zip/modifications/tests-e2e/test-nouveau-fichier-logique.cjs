/* Test du dialogue « Nouveau fichier » sans Electron ni navigateur réel.
 *
 * Lance nouveau-fichier.js sur un DOM minimal écrit ici, puis vérifie la
 * construction du chemin, le choix du type, l'ajout automatique de l'extension,
 * les logos, l'annulation et les modèles de départ.
 *
 *   node test-nouveau-fichier-logique.cjs
 *
 * Le test dans l'application réelle (AppImage + Playwright) est
 * test-nouveau-fichier.cjs.
 */
const fs = require('fs');
const path = require('path');
const assert = require('assert');
const vm = require('vm');

// ---------------------------------------------------------------- DOM minimal
class Element {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.children = [];
    this.parent = null;
    this.className = '';
    this._text = '';
    this.attributes = {};
    this.listeners = {};
    this.disabled = false;
    this.value = '';
    this.removed = false;
    this._type = '';
  }
  get type() { return this._type || this.attributes.type || ''; }
  set type(v) { this._type = v; this.attributes.type = v; }
  // Comme dans le vrai DOM : lire textContent concatène le texte des enfants,
  // l'écrire les remplace.
  get textContent() {
    if (this.children.length) return this.children.map(c => c.textContent).join('');
    return this._text;
  }
  set textContent(v) { this._text = String(v); this.children = []; }
  append(...nodes) { for (const n of nodes) { n.parent = this; this.children.push(n); } }
  replaceChildren(...nodes) { this.children = []; this.append(...nodes); }
  setAttribute(k, v) { this.attributes[k] = String(v); }
  getAttribute(k) { return this.attributes[k]; }
  addEventListener(kind, fn) { (this.listeners[kind] = this.listeners[kind] || []).push(fn); }
  removeEventListener(kind, fn) {
    this.listeners[kind] = (this.listeners[kind] || []).filter(f => f !== fn);
  }
  fire(kind, event) {
    const e = Object.assign({ type: kind, preventDefault() {}, stopPropagation() {},
                              target: this }, event || {});
    for (const fn of (this.listeners[kind] || []).slice()) fn(e);
    return e;
  }
  focus() { document.activeElement = this; this.fire('focus'); }
  remove() {
    this.removed = true;
    if (this.parent) {
      this.parent.children = this.parent.children.filter(c => c !== this);
      this.parent = null;
    }
  }
  contains(node) {
    for (const c of this.children) if (c === node || c.contains(node)) return true;
    return false;
  }
  _classe(selector) { return (selector.match(/^\.([\w-]+)$/) || [])[1]; }
  querySelector(selector) {
    const veutSubmit = selector === 'button[type=submit]';
    const classe = this._classe(selector);
    const parcours = el => {
      for (const c of el.children) {
        if (veutSubmit && c.tagName === 'BUTTON' && c.type === 'submit') return c;
        if (classe && (' ' + c.className + ' ').includes(' ' + classe + ' ')) return c;
        const trouve = parcours(c);
        if (trouve) return trouve;
      }
      return null;
    };
    return parcours(this);
  }
  querySelectorAll(selector) {
    const classe = this._classe(selector);
    const out = [];
    const parcours = el => {
      for (const c of el.children) {
        if (classe && (' ' + c.className + ' ').includes(' ' + classe + ' ')) out.push(c);
        parcours(c);
      }
    };
    parcours(this);
    return out;
  }
}

const document = {
  activeElement: null,
  listeners: {},
  body: new Element('body'),
  createElement: tag => new Element(tag),
  addEventListener(kind, fn) { (this.listeners[kind] = this.listeners[kind] || []).push(fn); },
  removeEventListener(kind, fn) {
    this.listeners[kind] = (this.listeners[kind] || []).filter(f => f !== fn);
  },
  fire(kind, event) {
    const e = Object.assign({ type: kind, preventDefault() {}, stopPropagation() {},
                              target: this.body }, event || {});
    for (const fn of (this.listeners[kind] || []).slice()) fn(e);
    return e;
  },
  contains(node) { return node === this.body || this.body.contains(node); },
  querySelector(sel) { return this.body.querySelector(sel); },
};

const sandbox = { window: {}, document, console, Promise, Set, Object, String, Array, Error };
sandbox.window.document = document;
vm.createContext(sandbox);

const SCRIPT = path.join(__dirname, '..', 'nouveau-fichier.js');
vm.runInContext(fs.readFileSync(SCRIPT, 'utf8'), sandbox, { filename: SCRIPT });

const ouvrirDialogue = sandbox.window.PSNewFileDialog;
const types = sandbox.window.PSNewFileTypes;
const modele = sandbox.window.PSNewFileTemplate;
assert.equal(typeof ouvrirDialogue, 'function', 'window.PSNewFileDialog doit être exposé');

let reussis = 0;
async function cas(titre, fn) { await fn(); reussis++; console.log('  ok  ' + titre); }

// Ouvre le dialogue et renvoie l'overlay ajouté au document.
function overlay() { return document.body.children[document.body.children.length - 1]; }
function boutonType(el, typeId) {
  return el.querySelectorAll('.ps-newfile-type')[types.findIndex(t => t.id === typeId)];
}
async function choisir(nom, typeId, options) {
  const promesse = ouvrirDialogue(options || { defaultType: typeId });
  const el = overlay();
  const input = el.querySelector('.ps-newfile-name');
  input.value = nom;
  input.fire('input');
  boutonType(el, typeId).fire('click');
  el.querySelector('.ps-newfile-modal').fire('submit');
  return { resultat: await promesse, el };
}
async function fermer(options) {
  const promesse = ouvrirDialogue(options || { defaultType: 'pascal' });
  const el = overlay();          // à capturer avant la fermeture : l'overlay est retiré
  el.querySelector('.ps-newfile-close').fire('click');
  return { resultat: await promesse, el };
}

(async () => {
  // ------------------------------------------------------------- catalogue
  console.log('Catalogue des types');
  await cas('25 types proposés', () => assert.equal(types.length, 25));
  await cas('swift et kotlin présents, aux côtés des langages existants', () => {
    const ids = types.map(t => t.id);
    for (const attendu of ['pascal', 'swift', 'kotlin', 'python', 'c', 'cpp', 'csharp',
                           'javascript', 'html', 'css', 'php', 'rust', 'go', 'ruby',
                           'fortran', 'perl', 'basic', 'ocaml', 'lua', 'latex',
                           'markdown', 'xml', 'makefile', 'cmake', 'plaintext']) {
      assert.ok(ids.includes(attendu), attendu + ' manquant');
    }
  });
  await cas('chaque type a un libellé et une extension définie', () => {
    for (const t of types) {
      assert.ok(t.label, 'libellé manquant pour ' + t.id);
      assert.equal(typeof t.ext, 'string', 'ext manquante pour ' + t.id);
    }
  });
  await cas('les noms imposés sont Makefile et CMakeLists.txt', () => {
    const imposes = types.filter(t => t.nomFixe).map(t => t.nomFixe).sort();
    assert.deepEqual(imposes, ['CMakeLists.txt', 'Makefile']);
  });
  await cas('le catalogue expose la présence d’un logo', () => {
    const parId = Object.fromEntries(types.map(t => [t.id, t.logo]));
    assert.equal(parId.swift, true);
    assert.equal(parId.kotlin, true);
    assert.equal(parId.pascal, false, 'Pascal garde son badge à lettres');
    assert.equal(parId.makefile, false);
  });

  // ------------------------------------------------------- chemin construit
  console.log('Chemin construit');
  const chemins = [
    ['calcul', 'pascal', 'calcul.pas'],
    ['main', 'swift', 'main.swift'],
    ['App', 'kotlin', 'App.kt'],
    ['src/outils/tri', 'pascal', 'src/outils/tri.pas'],
    ['src/outils/tri', 'swift', 'src/outils/tri.swift'],
    ['calcul.pas', 'pascal', 'calcul.pas'],
    ['module.kts', 'kotlin', 'module.kts'],
    ['script.py', 'python', 'script.py'],
    ['/absolu/nom', 'python', 'absolu/nom.py'],
    ['dossier//nom', 'c', 'dossier/nom.c'],
    ['./relatif', 'go', 'relatif.go'],
    ['  espacé  ', 'lua', 'espacé.lua'],
    ['', 'makefile', 'Makefile'],
    ['src/build', 'makefile', 'src/Makefile'],
    ['src/Makefile', 'makefile', 'src/Makefile'],
    ['peu-importe', 'cmake', 'CMakeLists.txt'],
    ['projet/', 'cmake', 'projet/CMakeLists.txt'],
    ['projet/', 'makefile', 'projet/Makefile'],
    ['src/build/', 'makefile', 'src/build/Makefile'],
    ['src/', 'swift', 'src.swift'],
    ['notes', 'plaintext', 'notes.txt'],
    ['style', 'css', 'style.css'],
    ['page', 'html', 'page.html'],
    ['rapport', 'latex', 'rapport.tex'],
    ['config', 'xml', 'config.xml'],
  ];
  for (const [nom, typeId, attendu] of chemins) {
    const { resultat } = await choisir(nom, typeId);
    await cas('« ' + nom + ' » + ' + typeId + ' -> ' + attendu, () => {
      assert.ok(resultat, 'le dialogue a renvoyé null');
      assert.equal(resultat.path, attendu);
    });
  }

  // --------------------------------------------------------------- contenus
  console.log('Contenu initial proposé');
  await cas('Swift : point de départ exécutable', async () => {
    const { resultat } = await choisir('demo', 'swift');
    assert.ok(/print\("Bonjour Swift"\)/.test(resultat.content), resultat.content);
  });
  await cas('Kotlin : fun main', async () => {
    const { resultat } = await choisir('demo', 'kotlin');
    assert.ok(/fun main\(\)/.test(resultat.content), resultat.content);
    assert.ok(/println/.test(resultat.content), resultat.content);
  });
  await cas('Pascal : modèle d’origine conservé', async () => {
    const { resultat } = await choisir('calcul', 'pascal');
    assert.ok(resultat.content.includes('program NouveauProgramme;'), resultat.content);
    assert.ok(resultat.content.includes('{$mode objfpc}{$H+}'), resultat.content);
    assert.ok(resultat.content.includes('begin'), resultat.content);
  });
  await cas('Texte brut : contenu vide', async () => {
    const { resultat } = await choisir('notes', 'plaintext');
    assert.equal(resultat.content, '');
  });
  await cas('le type est renvoyé avec le chemin', async () => {
    const { resultat } = await choisir('App', 'kotlin');
    assert.equal(resultat.type, 'kotlin');
  });

  // ------------------------------------------------------------------ refus
  console.log('Noms refusés');
  for (const [nom, typeId] of [['', 'pascal'], ['..', 'pascal'], ['a/b/..', 'c'],
                               ['x\\y', 'python'], ['a\u0000b', 'go'], ['/', 'swift']]) {
    const promesse = ouvrirDialogue({ defaultType: typeId });
    const el = overlay();
    const input = el.querySelector('.ps-newfile-name');
    input.value = nom;
    input.fire('input');
    const apercu = el.querySelector('.ps-newfile-preview');
    await cas('« ' + JSON.stringify(nom) + ' » annoncé invalide', () => {
      assert.ok(apercu.textContent.includes('Nom invalide'), apercu.textContent);
      assert.equal(el.querySelector('button[type=submit]').disabled, true,
                   '« Créer le fichier » doit être désactivé');
    });
    el.querySelector('.ps-newfile-close').fire('click');
    await cas('  et fermer rend null', async () => assert.equal(await promesse, null));
  }

  await cas('valider un nom invalide ne crée rien', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'pascal' });
    const el = overlay();
    el.querySelector('.ps-newfile-name').value = '..';
    el.querySelector('.ps-newfile-name').fire('input');
    el.querySelector('.ps-newfile-modal').fire('submit');
    assert.equal(el.removed, false, 'le dialogue doit rester ouvert');
    el.querySelector('.ps-newfile-close').fire('click');
    assert.equal(await promesse, null);
  });

  // ------------------------------------------------------------ annulation
  console.log('Annulation, focus et accessibilité');
  await cas('Escape ferme et rend null', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'swift' });
    document.fire('keydown', { key: 'Escape' });
    assert.equal(await promesse, null);
  });
  await cas('une autre touche ne ferme pas', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'swift' });
    document.fire('keydown', { key: 'a' });
    assert.equal(overlay().removed, false);
    overlay().querySelector('.ps-newfile-close').fire('click');
    assert.equal(await promesse, null);
  });
  await cas('Annuler ferme et rend null', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'swift' });
    const el = overlay();
    boutonType(el, 'kotlin').fire('click');
    el.querySelector('.prompt-buttons').children[0].fire('click');
    assert.equal(await promesse, null);
  });
  await cas('cliquer l’arrière-plan ferme', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'swift' });
    const el = overlay();
    el.fire('mousedown', { target: el });
    assert.equal(await promesse, null);
  });
  await cas('cliquer dans la modale ne ferme pas', async () => {
    const promesse = ouvrirDialogue({ defaultType: 'swift' });
    const el = overlay();
    const modal = el.querySelector('.ps-newfile-modal');
    el.fire('mousedown', { target: modal });
    assert.equal(el.removed, false);
    el.querySelector('.ps-newfile-close').fire('click');
    assert.equal(await promesse, null);
  });
  await cas('le dialogue est retiré du document après fermeture', async () => {
    const avant = document.body.children.length;
    const { el } = await fermer();
    assert.equal(el.removed, true);
    assert.equal(document.body.children.length, avant);
  });
  await cas('l’écouteur Escape global est retiré', async () => {
    const avant = (document.listeners.keydown || []).length;
    const p = ouvrirDialogue({ defaultType: 'pascal' });
    assert.equal((document.listeners.keydown || []).length, avant + 1);
    overlay().querySelector('.ps-newfile-close').fire('click');
    await p;
    assert.equal((document.listeners.keydown || []).length, avant);
  });
  await cas('le focus part sur le champ de saisie puis revient', async () => {
    const origine = new Element('div');
    origine.focus = function () { document.activeElement = this; };
    document.body.append(origine);
    origine.focus();
    const p = ouvrirDialogue({ defaultType: 'swift' });
    assert.equal(document.activeElement.className.includes('ps-newfile-name'), true);
    overlay().querySelector('.ps-newfile-close').fire('click');
    await p;
    assert.equal(document.activeElement, origine);
  });
  await cas('choisir un type ramène le focus sur le champ', async () => {
    const p = ouvrirDialogue({ defaultType: 'pascal' });
    const el = overlay();
    boutonType(el, 'swift').fire('click');
    assert.ok(document.activeElement.className.includes('ps-newfile-name'));
    el.querySelector('.ps-newfile-close').fire('click');
    await p;
  });
  await cas('un logo est posé pour swift et kotlin, une lettre pour pascal', async () => {
    const p = ouvrirDialogue({ defaultType: 'pascal' });
    const el = overlay();
    const logoDe = id => boutonType(el, id).children[0];
    assert.ok(logoDe('swift').className.includes('psl-swift'));
    assert.ok(logoDe('kotlin').className.includes('psl-kotlin'));
    assert.ok(logoDe('pascal').className.includes('ps-logo-lettre'));
    assert.equal(logoDe('pascal').textContent, 'P');
    assert.equal(logoDe('makefile').textContent, 'M');
    assert.equal(logoDe('basic').textContent, 'Ba');
    assert.equal(logoDe('swift').textContent, '', 'le logo remplace la lettre');
    assert.equal(logoDe('swift').getAttribute('aria-hidden'), 'true');
    el.querySelector('.ps-newfile-close').fire('click');
    await p;
  });
  await cas('un seul type est marqué sélectionné (role=radio)', async () => {
    const p = ouvrirDialogue({ defaultType: 'kotlin' });
    const el = overlay();
    const boutons = el.querySelectorAll('.ps-newfile-type');
    const idx = types.findIndex(t => t.id === 'kotlin');
    assert.equal(boutons.length, types.length);
    assert.equal(boutons[idx].getAttribute('aria-checked'), 'true');
    assert.equal(boutons[idx].getAttribute('role'), 'radio');
    assert.ok(boutons[idx].className.includes('actif'));
    assert.equal(boutons.filter(b => b.getAttribute('aria-checked') === 'true').length, 1);
    assert.equal(el.querySelectorAll('.ps-newfile-grid').length, 1);
    // Changer de type déplace la sélection.
    boutonType(el, 'swift').fire('click');
    assert.equal(boutons[idx].getAttribute('aria-checked'), 'false');
    assert.equal(boutons[types.findIndex(t => t.id === 'swift')].getAttribute('aria-checked'), 'true');
    assert.equal(boutons.filter(b => b.getAttribute('aria-checked') === 'true').length, 1);
    el.querySelector('.ps-newfile-close').fire('click');
    await p;
  });
  await cas('saisir une extension connue resynchronise le type', async () => {
    const p = ouvrirDialogue({ defaultType: 'pascal' });
    const el = overlay();
    const input = el.querySelector('.ps-newfile-name');
    input.value = 'module.swift';
    input.fire('input');
    input.fire('change');
    assert.equal(boutonType(el, 'swift').getAttribute('aria-checked'), 'true');
    assert.ok(el.querySelector('.ps-newfile-preview').textContent.includes('module.swift'));
    el.querySelector('.ps-newfile-modal').fire('submit');
    const r = await p;
    assert.equal(r.path, 'module.swift');
    assert.ok(r.content.includes('Bonjour Swift'));
  });
  await cas('choisir Makefile pré-remplit le champ', async () => {
    const p = ouvrirDialogue({ defaultType: 'pascal' });
    const el = overlay();
    boutonType(el, 'makefile').fire('click');
    assert.equal(el.querySelector('.ps-newfile-name').value, 'Makefile');
    assert.ok(el.querySelector('.ps-newfile-preview').textContent.includes('Makefile'));
    el.querySelector('.ps-newfile-close').fire('click');
    await p;
  });
  await cas('un nom initial est repris et l’aperçu suit', async () => {
    const p = ouvrirDialogue({ defaultType: 'swift', initialName: 'bonus' });
    const el = overlay();
    assert.equal(el.querySelector('.ps-newfile-name').value, 'bonus');
    assert.ok(el.querySelector('.ps-newfile-preview').textContent.includes('bonus.swift'));
    el.querySelector('.ps-newfile-modal').fire('submit');
    assert.equal((await p).path, 'bonus.swift');
  });

  // ---------------------------------------------------------------- modèles
  console.log('Modèles par extension (repli sans dialogue)');
  const modeles = [
    ['main.swift', 'Bonjour Swift'],
    ['Main.kt', 'fun main()'],
    ['build.gradle.kts', 'fun main()'],
    ['tri.pas', 'program NouveauProgramme;'],
    ['a.py', 'Bonjour Python'],
    ['a.rs', 'Bonjour Rust'],
    ['a.f90', 'Bonjour Fortran'],
    ['a.lua', 'Bonjour Lua'],
    ['a.ml', 'Bonjour OCaml'],
    ['Makefile', 'all:'],
    ['makefile', 'all:'],
    ['GNUmakefile', 'all:'],
    ['CMakeLists.txt', 'cmake_minimum_required'],
    ['a.inconnu', ''],
    ['', ''],
    [null, ''],
  ];
  for (const [nom, attendu] of modeles) {
    await cas('modèle de ' + JSON.stringify(nom) + ' contient « ' + attendu + ' »', () => {
      assert.ok(modele(nom).includes(attendu), JSON.stringify(modele(nom)));
    });
  }

  console.log('\nPASS — ' + reussis + ' vérifications');
})().catch(e => { console.error('ECHEC :', e && e.stack || e); process.exit(1); });
