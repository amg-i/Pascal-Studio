"""3.5 focused integration tests: isolated SQLite; local mock model, no actual agent commands."""
import os,sys,tempfile,asyncio,json
from pathlib import Path
from unittest.mock import patch
T=tempfile.TemporaryDirectory();os.environ['DB_PATH']=str(Path(T.name)/'history.db');os.environ['MEMORY_CLOUD']='0';os.environ['AGENT_ALLOW_CLOUD']='0'
A=Path(__file__).resolve().parents[1]/'assistant-ia';sys.path[:0]=[str(A),str(A/'vendor-ddgs'),str(A/'vendor-python')]
import httpx,core,agent,orchestra,server

def test_basics():
 assert core.MODELS['chat']=='qwen3:4b' and core.MODELS['code']=='qwen2.5-coder:7b' and core.MODELS['math']=='qwen3:8b'
 assert orchestra.AGENT_MODELS['operateur']=='qwen2.5-coder:7b' and orchestra.AGENT_MODELS['dolphin']=='dolphin3:8b'
 assert any(a['name']=='dolphin' for a in orchestra.all_agents())
 for t in ['write_file','run_command']:
  assert agent.needs_approval(t,False) and not agent.needs_approval(t,True)
 for text in ["Je ne peux pas vous aider avec cette demande.","Je ne suis pas en mesure de fournir cela.","I cannot assist with that request."]:
  assert server.refusal_detected(text),text
 for text in ["Voici la réponse.","Je ne peux pas me connecter au réseau", "Je ne sais pas."]:
  assert not server.refusal_detected(text),text
 # Old settings migrate once, then the user's later changes survive.
 server.set_setting('ui',json.dumps({'mode':'local','web':'off','tools':'off'}))
 assert server.ui_settings()['web']=='on' and server.ui_settings()['tools']=='auto'
 server.set_setting('ui',json.dumps({'mode':'local','web':'off','tools':'full'}))
 assert server.ui_settings()['web']=='off' and server.ui_settings()['tools']=='full'
 # Fail-closed remains in every mode if account/firewall missing.
 with patch.object(agent.isolation,'status',return_value=(False,'isolation absente')):
  assert not agent.execute('write_file',{'path':'/tmp/non','content':'x'})['ok']
 print('models, migration, approval modes, refusal detection, fail-closed PASS')

def test_agent_modes():
 calls=[]
 def stream(model,messages,tools,ctx):
  if not any(m.get('role')=='tool' for m in messages):
   yield ('calls',[{'id':'a1','name':'write_file','args':{'path':'/tmp/test.txt','content':'bonjour'}}])
  else:yield ('text','Terminé.')
 with patch.object(core,'is_online',return_value=False),patch.object(core,'native_tools',return_value=True),patch.object(core,'stream_local_tools',side_effect=stream),patch.object(agent,'precheck',return_value=None),patch.object(agent,'execute',side_effect=lambda n,a:(calls.append((n,a)) or {'ok':True,'text':'écrit'})),patch.object(agent,'log_call'):
  ev=list(core.run_agent([], 'écris un fichier','full','local','chat',approve_all=True,model_override='qwen3:4b'))
  assert calls and not any(x['type']=='approval' for x in ev) and any(x['type']=='tool_result' and x['ok'] for x in ev)
  calls.clear()
  with patch.object(agent,'wait_approval',return_value=False):
   ev=list(core.run_agent([], 'écris un fichier','full','local','chat',approve_all=False,model_override='qwen3:4b'))
  assert not calls and any(x['type']=='approval' for x in ev) and any(x['type']=='tool_result' and x['denied'] for x in ev)
 print('auto action / denied approval PASS')

def test_agent_models():
 specs={x['name']:x for x in orchestra.all_agents()};seen=[]
 def fake(*args,**kwargs):
  seen.append(args[-2]);yield {'type':'text','t':'ok'}
 ctx={'custom':'','skills':[],'msg':'hi','history':[],'level':'full','mode':'local','memory':'','cid':'x','approve_all':True,'images':None,'model':'','web':True}
 with patch.object(core,'run',side_effect=fake),patch.object(core,'run_agent',side_effect=fake):
  for a,w in [('codeur','qwen2.5-coder:7b'),('operateur','qwen2.5-coder:7b'),('calculateur','qwen3:8b'),('redacteur','qwen3:4b'),('dolphin','dolphin3:8b')]:
   h={};list(orchestra._step(ctx,specs[a],'test',[],h,False));assert seen[-1]==w,(a,seen[-1],w)
  ctx['model']='manual:7b';list(orchestra._step(ctx,specs['codeur'],'test',[],{},False));assert seen[-1]=='manual:7b'
  list(orchestra._step(ctx,specs['dolphin'],'test',[],{},False));assert seen[-1]=='dolphin3:8b'
 print('per-agent models and manual override PASS')

async def test_http():
 class Tags:
  def raise_for_status(self): pass
  def json(self):return {'models':[{'name':'dolphin3:8b'}]}
 def decline(*args,**kwargs):
  yield {'type':'meta','category':'chat','label':'Chat','engine':'local','provider':'Ollama','model':'qwen3:4b','notes':[]}
  yield {'type':'text','t':'Je ne peux pas vous aider avec cette demande.'}
 def fallback(*args,**kwargs):
  assert args[-2]=='dolphin3:8b' and args[8] is True
  yield {'type':'meta','category':'chat','label':'Dolphin','engine':'local','provider':'Ollama','model':'dolphin3:8b','notes':[]}
  yield {'type':'text','t':'Réponse alternative locale.'}
 transport=httpx.ASGITransport(app=server.app,client=('127.0.0.1',12345))
 async with httpx.AsyncClient(transport=transport,base_url='http://127.0.0.1:8765') as c:
  cid=(await c.post('/api/conversations',json={})).json()['id']
  with patch.object(orchestra,'run_team',side_effect=decline),patch.object(core.requests,'get',return_value=Tags()),patch.object(core,'run_agent',side_effect=fallback),patch.object(server,'bg_memory'),patch.object(server,'bg_skill'),patch.object(server,'bg_compress'):
   res=await c.post('/api/conversations/'+cid+'/chat',json={'message':'Question de test','mode':'local','tools':'auto','web':'on','team':'off'})
  data=[json.loads(x) for x in res.text.splitlines()];assert any('seconde tentative' in x.get('t','') for x in data);assert any(x.get('t')=='Réponse alternative locale.' for x in data)
  res=await c.get('/api/conversations/'+cid);assert 'Réponse alternative locale.' in res.json()['messages'][-1]['content']
  # Never replay after any tool action, even if output contains a refusal.
  def acted(*args,**kwargs):
   yield {'type':'tool','id':'x','name':'write_file','args':{'path':'/tmp/x','content':'x'}}
   yield {'type':'text','t':'Je ne peux pas vous aider avec cette demande.'}
  with patch.object(orchestra,'run_team',side_effect=acted),patch.object(core,'run_agent',side_effect=AssertionError('do not replay')),patch.object(server,'bg_memory'),patch.object(server,'bg_compress'):
   res=await c.post('/api/conversations/'+cid+'/chat',json={'message':'autre','tools':'auto','web':'on','team':'off'})
  assert 'Réponse de Dolphin' not in res.text
 print('HTTP streaming Dolphin retry and no replay after write PASS')

if __name__=='__main__':
 test_basics();test_agent_modes();test_agent_models();asyncio.run(test_http());T.cleanup()
