/* Harnais DOM minimal partagé par les bancs d'interface (4.0.0).
 *
 * jsdom n'est pas installé dans l'environnement de construction, et il ne
 * faudrait pas qu'un banc en dépende : ces bancs doivent tourner avec le seul
 * Node livré. Ce module fournit donc un DOM suffisant pour exécuter réellement
 * les scripts d'interface — pas pour les lire.
 *
 * Trois leçons payées, à ne pas réapprendre :
 *
 *   1. innerHTML DOIT être analysé. Les scripts d'interface construisent leur
 *      structure par innerHTML puis la retrouvent par querySelector. Un harnais
 *      qui stocke la chaîne sans la parser laisse ces sélecteurs renvoyer null,
 *      et le banc passe au vert en ne testant rien.
 *
 *   2. firstChild, lastChild et closest DOIVENT exister. data-studio.js se sert
 *      de firstChild comme garde de remontage : un harnais qui l'omet faisait
 *      ACCUSER LE PRODUIT (« l'éditeur est reconstruit à chaque mutation »)
 *      pour sa propre lacune. Chaque propriété DOM qu'un script utilise est une
 *      propriété que le harnais doit fournir, sous peine de faux échec.
 *
 *   3. Les sélecteurs d'attribut [data-cle] doivent être gérés. Un matcheur qui
 *      ne connaît que #id, .classe et le nom de balise renvoie null en silence.
 *
 * Ce fichier ne contient AUCUNE assertion : il est un outil, pas un banc.
 */
'use strict';

/* ------------------------------------------------------------------ DOM ---- */

class Classe {
  constructor(noeud) { this.noeud = noeud; }
  get liste() {
    const v = this.noeud._classes;
    return v ? String(v).split(/\s+/).filter(Boolean) : [];
  }
  contains(c) { return this.liste.indexOf(c) >= 0; }
  add(...cs) {
    const e = new Set(this.liste);
    for (const c of cs) if (c) e.add(c);
    this.noeud._classes = [...e].join(' ');
  }
  remove(...cs) {
    const e = new Set(this.liste);
    for (const c of cs) e.delete(c);
    this.noeud._classes = [...e].join(' ');
  }
  toggle(c, force) {
    const presente = this.contains(c);
    const vouloir = force === undefined ? !presente : !!force;
    if (vouloir) this.add(c); else this.remove(c);
    return vouloir;
  }
}

class Noeud {
  constructor(tag) {
    this.tagName = String(tag || '').toUpperCase();
    this.children = [];
    this.parent = null;
    this.dataset = {};
    this.style = {};
    this._attrs = {};
    this._classes = '';
    this._texte = '';
    this._html = '';
    this._ecouteurs = {};
    this.classList = new Classe(this);
    this.value = '';
    this.placeholder = '';
    this.disabled = false;
    this.checked = false;
    this.required = false;
    this.hidden = false;
  }
  /* firstChild existe dans un vrai DOM et data-studio.js s'en sert comme
   * garde de remontage : un stub qui l'omettrait laisserait l'éditeur se
   * reconstruire à chaque mutation, et le banc accuserait le produit à tort. */
  /* nodeType est fondamental dans un vrai DOM : 1 pour un élément, 3 pour un
   * texte, 8 pour un commentaire. Un script hôte qui écrit
   * `valeur.nodeType ? valeur : document.createTextNode(valeur)` — la forme la
   * plus naturelle — transformerait SANS ERREUR chaque élément en texte si le
   * stub ne l'expose pas. Le panneau rendrait des « [object Object] » et le
   * banc accuserait le produit. */
  get nodeType() { return this.tagName === '#TEXT' ? 3 : 1; }
  get nodeName() { return this.tagName; }
  get firstChild() { return this.children.length ? this.children[0] : null; }
  get lastChild() { return this.children.length ? this.children[this.children.length - 1] : null; }
  get firstElementChild() {
    for (const c of this.children) if (c.tagName !== '#TEXT') return c;
    return null;
  }
  /* Géométrie : les panneaux flottants la lisent pour se déplacer et se
   * redimensionner. Le modèle est volontairement simple — des styles en px
   * cumulés le long des parents — mais il doit EXISTER, sinon un panneau qui
   * calcule sa position lève et le banc échoue pour une mauvaise raison. */
  getBoundingClientRect() {
    const nombre = v => { const n = parseFloat(v); return Number.isFinite(n) ? n : 0; };
    let gauche = nombre(this.style.left), haut = nombre(this.style.top);
    const largeur = nombre(this.style.width) || 100;
    const hauteur = nombre(this.style.height) || 30;
    let p = this.parent;
    while (p) { gauche += nombre(p.style.left); haut += nombre(p.style.top); p = p.parent; }
    return { left: gauche, top: haut, right: gauche + largeur, bottom: haut + hauteur,
      width: largeur, height: hauteur, x: gauche, y: haut };
  }
  get offsetLeft() { return parseFloat(this.style.left) || 0; }
  get offsetTop() { return parseFloat(this.style.top) || 0; }
  get offsetWidth() { return this.getBoundingClientRect().width; }
  get offsetHeight() { return this.getBoundingClientRect().height; }
  /* parentNode est LE nom du DOM ; `parent` n'existe pas. Un script qui teste
   * `n.parentNode === zone` reçoit undefined si le harnais ne l'expose pas, et
   * le panneau croit alors que la vue n'est pas attachée : il la réattache à
   * chaque activation et ne masque jamais les onglets inactifs. */
  get parentNode() { return this.parent; }
  set parentNode(v) { this.parent = v; }
  get parentElement() { return this.parent; }
  get nextSibling() {
    if (!this.parent) return null;
    const fr = this.parent.children;
    return fr[fr.indexOf(this) + 1] || null;
  }
  closest(sel) { let n = this; while (n) { if (matcheur(n, sel)) return n; n = n.parent; } return null; }
  get ownerDocument() { return this._ownerDocument || null; }
  set ownerDocument(d) { this._ownerDocument = d; }
  get className() { return this._classes; }
  set className(v) { this._classes = String(v || ''); }
  /* Dans un vrai DOM, title/id/href sont des propriétés qui REFLETENT
   * l'attribut du même nom. Un script d'interface écrit `b.title` et lit donc
   * undefined si le harnais ne les reflète pas — et le banc échoue sur le
   * harnais au lieu d'échouer sur le produit. */
  get title() { return this._attrs.title || ''; }
  set title(v) { this.setAttribute('title', v); }
  get id() { return this._attrs.id || ''; }
  set id(v) { this.setAttribute('id', v); }
  get href() { return this._attrs.href || ''; }
  set href(v) { this.setAttribute('href', v); }
  get type() { return this._attrs.type || ''; }
  set type(v) { this.setAttribute('type', v); }
  get isConnected() {
    let n = this;
    while (n.parent) n = n.parent;
    return n === this.ownerDocumentRoot;
  }
  get textContent() {
    if (this.children.length === 0) return this._texte;
    return this._texte + this.children.map(c => c.textContent).join('');
  }
  set textContent(v) { this._texte = String(v); this.children = []; this._html = ''; }
  get innerHTML() { return this._html; }
  set innerHTML(v) {
    this._html = String(v);
    this.children = [];
    this._texte = '';
    for (const fils of parseHTML(this._html)) { this.appendChild(fils); }
    this._html = this._html; /* conservé : le banc inspecte le balisage brut */
  }
  setAttribute(k, v) {
    this._attrs[k] = String(v);
    if (k === 'class') this._classes = String(v);
    else if (k === 'value') this.value = String(v);
    else if (k === 'placeholder') this.placeholder = String(v);
    else if (k === 'checked') this.checked = true;
    else if (k === 'required') this.required = true;
    else if (k === 'disabled') this.disabled = true;
    /* `hidden` est un attribut IDL réfléchi dans un vrai DOM : un script qui
     * écrit setAttribute('hidden','') puis lit n.hidden recevrait undefined ici,
     * et un banc qui compte les sections visibles accuserait le produit. */
    else if (k === 'hidden') this.hidden = true;
    else if (k.indexOf('data-') === 0) {
      const cle = k.slice(5).replace(/-([a-z])/g, (m, l) => l.toUpperCase());
      this.dataset[cle] = String(v);
    } else if (k === 'aria-label') this._attrs[k] = String(v);
  }
  getAttribute(k) { return Object.prototype.hasOwnProperty.call(this._attrs, k) ? this._attrs[k] : null; }
  appendChild(n) {
    if (!n) return n;
    if (Array.isArray(n)) { for (const x of n) this.appendChild(x); return n; }
    n.parent = this;
    this.children.push(n);
    notifier(this);
    return n;
  }
  append(...ns) { for (const n of ns) { if (n !== undefined && n !== null) this.appendChild(n); } }
  replaceChildren(...ns) {
    for (const c of this.children) c.parent = null;
    this.children = [];
    this._html = '';
    this.append(...ns);
    notifier(this);
  }
  remove() {
    if (!this.parent) return;
    const i = this.parent.children.indexOf(this);
    if (i >= 0) this.parent.children.splice(i, 1);
    this.parent = null;
    notifier(this);
  }
  addEventListener(type, fn) {
    (this._ecouteurs[type] = this._ecouteurs[type] || []).push(fn);
  }
  removeEventListener(type, fn) {
    const l = this._ecouteurs[type] || [];
    const i = l.indexOf(fn);
    if (i >= 0) l.splice(i, 1);
  }
  dispatchEvent(ev) {
    /* Un vrai événement DOM porte toujours preventDefault, stopPropagation et
     * target. Les bancs construisent des événements synthétiques : compléter
     * ici évite à chaque banc d'y penser, et évite surtout un échec qui
     * accuserait le produit pour un événement incomplet. */
    const e = ev || {};
    if (typeof e.preventDefault !== 'function') e.preventDefault = () => { e.defaultPrevented = true; };
    if (typeof e.stopPropagation !== 'function') e.stopPropagation = () => { e.propagationArretee = true; };
    if (typeof e.stopImmediatePropagation !== 'function') e.stopImmediatePropagation = e.stopPropagation;
    if (e.target === undefined) e.target = this;
    if (e.currentTarget === undefined) e.currentTarget = this;
    const l = this._ecouteurs[e.type] || [];
    for (const fn of l.slice()) fn.call(this, e);
    return true;
  }
  focus() { this._ownerDocument && (this._ownerDocument.activeElement = this); }
  /* blur, select et click sont réellement appelés par les scripts d'interface :
   * les omettre fait lever le banc sur le harnais, pas sur le produit. */
  blur() { if (this._ownerDocument && this._ownerDocument.activeElement === this) this._ownerDocument.activeElement = this._ownerDocument.body; }
  select() { this.__selection = true; }
  click() { return this.dispatchEvent({ type: 'click', target: this, preventDefault() {}, stopPropagation() {} }); }
  querySelectorAll(sel) {
    const brut = String(sel).trim();
    /* Combinaisons et listes de sélecteurs non gérées : lever plutôt que de
     * renvoyer un résultat partiel qui ferait passer un banc à tort. */
    if (/[>+~]|,|\[[^\]]*[~^$*|]=/.test(brut)) {
      throw new Error('harnais-dom : sélecteur non géré « ' + brut
        + ' » (combinaison, liste ou attribut avec opérateur).');
    }
    const out = [];
    const parts = brut.split(/\s+/);   /* espaces = combinateur descendant */
    const matche = (n, s) => matcheur(n, s);
    const descends = (racine, idx) => {
      for (const c of racine.children) {
        if (matche(c, parts[idx])) {
          if (idx === parts.length - 1) out.push(c);
          else descends(c, idx + 1);
        }
        descends(c, idx);
      }
    };
    descends(this, 0);
    return out;
  }
  querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
}

/* Sélecteurs réellement employés par data-studio.js : .classe, balise,
 * [attribut], [data-cle], #id — et leurs combinaisons descendantes. */
/* Découpe un sélecteur composé en ses parties (.classe, #id, balise,
 * [attr], :not(...)). Un split naïf sur « . » cassait :not(.cachee) en
 * « :not( » et « .cachee) » : le harnais ne trouvait plus rien, et le banc
 * en concluait à tort que le produit était fautif. Les parenthèses et les
 * crochets sont donc respectés. */
function decouperSelecteur(sel) {
  const parties = [];
  let courante = '';
  let prof = 0;
  for (const c of sel) {
    const ouvre = (c === '(' || c === '[');
    const ferme = (c === ')' || c === ']');
    if (prof === 0 && !ouvre && (c === '.' || c === '#' || c === ':') && courante) {
      parties.push(courante);
      courante = '';
    }
    if (ouvre) prof += 1;
    courante += c;
    if (ferme) prof -= 1;
  }
  if (courante) parties.push(courante);
  return parties;
}

function matcheur(n, sel) {
  if (!sel) return false;
  return decouperSelecteur(sel).every(partie => {
    if (!partie) return true;
    if (partie[0] === '.') return n.classList.contains(partie.slice(1));
    if (partie[0] === '#') return n.getAttribute('id') === partie.slice(1);
    if (partie[0] === ':') {
      const non = /^:not\(([^()]*)\)$/.exec(partie);
      if (non) return !matcheur(n, non[1]);
      /* Un sélecteur non géré qui renvoie silencieusement « rien » est le pire
       * défaut d'un harnais : le banc passe au vert en ne testant rien, ou
       * échoue en accusant le produit. Mieux vaut lever. */
      throw new Error('harnais-dom : pseudo-classe non gérée dans « ' + sel
        + ' ». L’ajouter au harnais plutôt que de laisser le banc conclure à tort.');
    }
    if (partie[0] === '[') {
      const brut = partie.slice(1, partie.indexOf(']') > 0 ? partie.indexOf(']') : partie.length);
      const [cle, ...reste] = brut.split('=');
      if (reste.length) {
        const attendu = reste.join('=').replace(/^["']|["']$/g, '');
        return valeurAttr(n, cle) === attendu;
      }
      return valeurAttr(n, cle) !== null;
    }
    return n.tagName === partie.toUpperCase();
  });
}
function valeurAttr(n, cle) {
  if (cle.indexOf('data-') === 0) {
    const k = cle.slice(5).replace(/-([a-z])/g, (m, l) => l.toUpperCase());
    return Object.prototype.hasOwnProperty.call(n.dataset, k) ? n.dataset[k] : null;
  }
  if (cle === 'class') return n.className || null;
  return n.getAttribute(cle);
}

/* Parseur HTML minimal, suffisant pour le balisage posé par innerHTML. */
function parseHTML(html) {
  const racines = [];
  const pile = [];
  const courants = () => (pile.length ? pile[pile.length - 1].children : racines);
  const rattacher = (n) => {
    n.parent = pile.length ? pile[pile.length - 1] : null;
    courants().push(n);
  };
  let i = 0;
  while (i < html.length) {
    const ouv = html.indexOf('<', i);
    if (ouv < 0) {
      const t = html.slice(i);
      if (t.trim()) { const n = new Noeud('#text'); n._texte = t; rattacher(n); }
      break;
    }
    if (ouv > i) {
      const t = html.slice(i, ouv);
      if (t.trim()) { const n = new Noeud('#text'); n._texte = t; rattacher(n); }
    }
    if (html.startsWith('<!--', ouv)) {
      const fin = html.indexOf('-->', ouv);
      i = fin < 0 ? html.length : fin + 3;
      continue;
    }
    const fin = html.indexOf('>', ouv);
    if (fin < 0) break;
    let balise = html.slice(ouv + 1, fin);
    i = fin + 1;
    if (balise[0] === '/') {
      const nom = balise.slice(1).trim().toUpperCase();
      for (let p = pile.length - 1; p >= 0; p--) {
        if (pile[p].tagName === nom) { pile.length = p; break; }
      }
      continue;
    }
    const autoFermante = balise.endsWith('/');
    if (autoFermante) balise = balise.slice(0, -1);
    const m = /^([^\s/]+)([\s\S]*)$/.exec(balise.trim());
    if (!m) continue;
    const n = new Noeud(m[1]);
    const attrs = m[2];
    const re = /([^\s=]+)\s*=\s*("([^"]*)"|'([^']*)')|([^\s=]+)(?=\s|$)/g;
    let a;
    while ((a = re.exec(attrs))) {
      if (a[1]) n.setAttribute(a[1], a[3] !== undefined ? a[3] : a[4]);
      else if (a[5]) n.setAttribute(a[5], '');
    }
    rattacher(n);
    if (!autoFermante && !/^(BR|HR|INPUT|IMG|META|LINK|PATH|ELLIPSE)$/.test(n.tagName)) pile.push(n);
  }
  return racines;
}

/* ------------------------------------------------- observateur de mutations */
let fileMutations = 0;
let observateurs = [];
function notifier(noeud) {
  fileMutations += 1;
  for (const o of observateurs) o._notifie();
}
class MutationObserverStub {
  constructor(cb) { this.cb = cb; this.cibles = []; this._enFile = 0; observateurs.push(this); }
  observe(cible, opts) { this.cibles.push({ cible, opts }); }
  disconnect() { this.cibles = []; }
  takeRecords() { const n = this._enFile; this._enFile = 0; return new Array(n).fill({}); }
  _notifie() { this._enFile += 1; }
  declencher() { this._enFile = 0; this.cb([], this); }
}



/* --------------------------------------------------------------- fabrique -- */

function creerDocument(opts) {
  const options = opts || {};
  const documentElement = new Noeud('html');
  const head = new Noeud('head');
  const body = new Noeud('body');
  documentElement.append(head, body);
  const document = {
    readyState: options.readyState || 'complete',
    documentElement, body, head,
    activeElement: body,
    createElement: tag => new Noeud(tag),
    createTextNode: t => { const n = new Noeud('#text'); n._texte = String(t); return n; },
    querySelector: sel => documentElement.querySelector(sel),
    querySelectorAll: sel => documentElement.querySelectorAll(sel),
    addEventListener(type, fn) {
      (this._ev = this._ev || {})[type] = (this._ev[type] || []).concat([fn]);
    },
    removeEventListener(type, fn) {
      const l = (this._ev && this._ev[type]) || [];
      const i = l.indexOf(fn);
      if (i >= 0) l.splice(i, 1);
    },
  };
  documentElement.ownerDocument = document;

  /* isConnected remonte jusqu'à la racine : chaque nœud doit donc savoir quelle
   * elle est. À rappeler après tout ajout au document. */
  function rafraichir() {
    (function marque(n) {
      n.ownerDocumentRoot = documentElement;
      n._ownerDocument = document;
      for (const c of n.children) marque(c);
    })(documentElement);
  }
  rafraichir();
  return { document, documentElement, body, head, rafraichir };
}

function compteurMutations() { return fileMutations; }

function reinitialiserObservateurs() {
  fileMutations = 0;
  observateurs.length = 0;
}

function declencherObservateurs() {
  for (const o of observateurs.slice()) o.declencher();
}

module.exports = {
  Noeud, Classe, parseHTML, matcheur, valeurAttr, decouperSelecteur, MutationObserverStub,
  creerDocument, compteurMutations, reinitialiserObservateurs, declencherObservateurs,
  observateurs: () => observateurs,
};
