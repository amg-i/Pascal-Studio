"""Serveur de test : démarrer le VRAI server.py pour un banc de bout en bout.

Factorisé parce que deux bancs en ont besoin (routes de données, routes du
navigateur) et parce que les pièges y sont les mêmes :

  * `server.py` n'est PAS une application Starlette — `TestClient` ne sert à
    rien ici, il faut un vrai socket. L'app Starlette est celle de l'assistant
    IA, un autre serveur.
  * `/api/tree` a un cache partagé de 0,75 s. Une sonde de disponibilité qui
    l'interroge avant la création des fixtures le remplit à vide, et le banc
    accuse alors le produit pour son propre artefact. `pret()` sonde donc une
    route SANS cache.
  * Le journal du serveur doit être écrit HORS de l'espace de travail, sinon
    `/api/tree` le liste comme un fichier du projet.

Usage :
    from serveur_de_test import ServeurDeTest
    with ServeurDeTest(variables={'PS_NAVIGATEUR_DIR': dossier}) as srv:
        srv.ecrire('base.sqlite', contenu)
        statut, corps = srv.client.get('/api/tree')
        statut, corps = srv.client.data('open', path='base.sqlite')
        espace = srv.espace()          # le répertoire de travail temporaire
"""

import io
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
SERVEUR = os.path.join(MODIFICATIONS, 'server.py')


def port_libre():
    prise = socket.socket()
    prise.bind(('127.0.0.1', 0))
    port = prise.getsockname()[1]
    prise.close()
    return port


class Client:
    """Le minimum pour parler au serveur : GET, POST brut, et /api/data/*."""

    def __init__(self, port):
        self.base = 'http://127.0.0.1:%d' % port

    def _lire(self, requete):
        try:
            with urllib.request.urlopen(requete, timeout=30) as rep:
                brut = rep.read().decode('utf-8')
                try:
                    return rep.status, json.loads(brut)
                except ValueError:
                    return rep.status, {'brut': brut[:400]}
        except urllib.error.HTTPError as erreur:
            brut = erreur.read().decode('utf-8')
            try:
                return erreur.code, json.loads(brut)
            except ValueError:
                return erreur.code, {'brut': brut[:400]}

    def get(self, chemin, entetes=None):
        return self._lire(urllib.request.Request(self.base + chemin,
                                                headers=entetes or {}))

    def post(self, chemin, entetes=None, **corps):
        requete = urllib.request.Request(
            self.base + chemin, data=json.dumps(corps).encode('utf-8'),
            headers=dict({'Content-Type': 'application/json'}, **(entetes or {})))
        return self._lire(requete)

    def data(self, route, **corps):
        return self.post('/api/data/' + route, **corps)

    def pret(self):
        try:
            urllib.request.urlopen(self.base + '/api/process', timeout=2)
            return True
        except Exception:
            return False


class ServeurDeTest:
    """Contexte : démarre server.py, attend qu'il écoute, puis l'arrête."""

    def __init__(self, variables=None, attente=40):
        self.variables = variables or {}
        self.attente = attente
        self.port = port_libre()
        self.racine = tempfile.mkdtemp(prefix='ps-test-ws-')
        self.journal_dir = tempfile.mkdtemp(prefix='ps-test-log-')
        self.chemin_journal = os.path.join(self.journal_dir, 'serveur.log')
        self.processus = None
        self.client = Client(self.port)

    def __enter__(self):
        environnement = dict(os.environ)
        environnement['PASCAL_WORKSPACE'] = self.racine
        environnement['PASCAL_PORT'] = str(self.port)
        environnement['PASCAL_HOST'] = '127.0.0.1'
        environnement['PYTHONPATH'] = MODIFICATIONS
        environnement.update({k: str(v) for k, v in self.variables.items()})
        self.processus = subprocess.Popen(
            [sys.executable, SERVEUR], cwd=MODIFICATIONS, env=environnement,
            stdout=io.open(self.chemin_journal, 'wb'), stderr=subprocess.STDOUT)
        echeance = time.monotonic() + self.attente
        while time.monotonic() < echeance:
            if self.processus.poll() is not None:
                raise RuntimeError(
                    'le serveur s’est terminé avant d’écouter :\n' + self.journal())
            if self.client.pret():
                # Rend le contexte entier, pas seulement le client : un banc doit
                # pouvoir écrire ses fixtures dans l'espace de travail du serveur.
                return self
            time.sleep(0.25)
        raise RuntimeError('le serveur n’a pas répondu en %d s' % self.attente)

    def __exit__(self, *_):
        if self.processus and self.processus.poll() is None:
            self.processus.terminate()
            try:
                self.processus.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.processus.kill()
        shutil.rmtree(self.racine, ignore_errors=True)
        shutil.rmtree(self.journal_dir, ignore_errors=True)
        return False

    def journal(self):
        try:
            return io.open(self.chemin_journal, encoding='utf-8',
                           errors='replace').read()[-1500:]
        except OSError:
            return '(journal illisible)'

    def espace(self):
        return self.racine

    def chemin(self, nom):
        return os.path.join(self.racine, nom)

    def ecrire(self, nom, contenu, mode='w'):
        cible = self.chemin(nom)
        if mode == 'wb':
            io.open(cible, 'wb').write(contenu)
        else:
            io.open(cible, 'w', encoding='utf-8').write(contenu)
        return cible

    def lire(self, nom):
        return io.open(self.chemin(nom), encoding='utf-8').read()


def dependance(nom):
    """True si un module est importable : un banc doit dire ce qui lui manque."""
    import importlib.util
    return importlib.util.find_spec(nom) is not None
