/* Banc de test de aide-index.js, sans navigateur.
 *
 * L'index d'aide est un script hôte qui décore un panneau React existant : il ne
 * se teste pas en lisant son code, il se teste en le laissant construire son
 * panneau dans un DOM suffisant, puis en vérifiant ce qu'il a produit et ce que
 * ses clics déclenchent.
 *
 * Le DOM d'amorce de smoke_nouveau_fichier.js ne suffit pas ici : il ne connaît
 * ni querySelectorAll, ni les sélecteurs descendants, ni classList, ni
 * textContent agrégé. Ce banc en apporte un plus complet, limité aux sélecteurs
 * réellement employés par aide-index.js.
 *
 * Lancer :  node tests/smoke_aide_index.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let OK = 0;
let N = 0;
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  console.log('  ' + titre.padEnd(62) + (bon ? 'CONFORME' : 'DIFFERENT'));
  if (!bon) {
    console.log('      obtenu  : ' + JSON.stringify(obtenu).slice(0, 160));
    console.log('      attendu : ' + JSON.stringify(attendu).slice(0, 160));
  }
}

/* ------------------------------------------------------------------- DOM --- */
class Classe {
  constructor(noeud) { this.noeud = noeud; }
  get liste() {
    return String(this.noeud._className || '').split(/\s+/).filter(Boolean);
  }
  /* Noms du DOM réel : aide-index.js appelle contains(), pas contient().
   * L'alias français ne sert qu'aux assertions de ce banc. */
  contains(c) { return this.liste.indexOf(c) >= 0; }
  contient(c) { return this.contains(c); }
  add(...cs) {
    const l = this.liste;
    for (const c of cs) if (l.indexOf(c) < 0) l.push(c);
    this.noeud._className = l.join(' ');
  }
  remove(...cs) {
    this.noeud._className = this.liste.filter(c => cs.indexOf(c) < 0).join(' ');
  }
  toggle(c, force) {
    const present = this.contient(c);
    const vouloir = force === undefined ? !present : !!force;
    if (vouloir) this.add(c); else this.remove(c);
    return vouloir;
  }
}

/* ---------------------------------------------------------------------------
 * Observateur de mutations RÉEL, et non un no-op.
 *
 * Un stub « observe = () => {} » faisait passer les 45 assertions alors que
 * l'application plantait : aide-index.js reconstruit son panneau à chaque
 * balayage, et ces écritures rappellent l'observateur — cascade sans fin dès
 * que le panneau d'aide existe. Pour que le banc voie ce que voit le
 * navigateur, les écritures du DOM notifient les observateurs, qui livrent leurs
 * enregistrements par micro-tâche, comme MutationObserver le fait vraiment.
 *
 * Un plafond arrête la livraison : une cascade infinie ferait tourner le banc
 * indéfiniment au lieu de le faire échouer. Débordement est donc le signal
 * d'un échec, pas d'une erreur du banc.
 * ------------------------------------------------------------------------ */
const OBSERVATEURS = [];
let CYCLES = 0;
let LIVRAISON = false;
const PLAFOND_CYCLES = 200;
let DEBORDEMENT = false;

function notifierMutation(cible) {
  if (!OBSERVATEURS.length) return;
  for (const o of OBSERVATEURS) {
    if (!o.actif) continue;
    if (o.cible !== cible && !o.cible.contient(cible)) continue;
    o.file.push({ type: 'childList', target: cible });
  }
  if (LIVRAISON) return;
  LIVRAISON = true;
  queueMicrotask(livrer);
}

function livrer() {
  LIVRAISON = false;
  const prets = OBSERVATEURS.filter(o => o.actif && o.file.length);
  if (!prets.length) return;
  if (CYCLES >= PLAFOND_CYCLES) { DEBORDEMENT = true; return; }
  CYCLES++;
  for (const o of prets) {
    const records = o.file.splice(0, o.file.length);
    o.rappel(records, o);
  }
  /* Les écritures faites pendant le rappel ont pu relancer une livraison. */
  if (OBSERVATEURS.some(o => o.actif && o.file.length) && !LIVRAISON) {
    LIVRAISON = true;
    queueMicrotask(livrer);
  }
}

class ObservateurMutations {
  constructor(rappel) {
    this.rappel = rappel;
    this.file = [];
    this.cible = null;
    this.actif = false;
    OBSERVATEURS.push(this);
  }
  observe(cible, options) {
    this.cible = cible;
    this.options = options || {};
    this.actif = true;
  }
  disconnect() { this.actif = false; this.file.length = 0; }
  takeRecords() { return this.file.splice(0, this.file.length); }
}

function remettreObservateursAZero() {
  for (const o of OBSERVATEURS) o.disconnect();
  OBSERVATEURS.length = 0;
  CYCLES = 0;
  DEBORDEMENT = false;
  LIVRAISON = false;
}

/* Remet les compteurs à zéro SANS déconnecter l'observateur du script : c'est
 * ce que mesure le scénario d'ouverture du panneau. */
function reinitialiserCompteurs() {
  CYCLES = 0;
  DEBORDEMENT = false;
  for (const o of OBSERVATEURS) o.file.length = 0;
  LIVRAISON = false;
}

class Noeud {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.children = [];
    this.attributes = {};
    this.dataset = {};
    this.style = {};
    this.listeners = {};
    this.parent = null;
    this._className = '';
    this._texte = null;          /* texte posé directement, sans enfant */
    this._id = '';
    this.type = '';
    this.title = '';
    this.disabled = false;
    this.checked = false;
    this._value = '';
    this.classList = new Classe(this);
  }
  get className() { return this._className; }
  set className(v) { this._className = String(v == null ? '' : v); }
  get id() { return this._id; }
  set id(v) { this._id = String(v); this.attributes.id = String(v); }
  /* value avec accesseur sur le prototype : aide-index.js écrit dans un champ
   * contrôlé par React en passant par le descripteur du prototype. Sans cet
   * accesseur, definirValeur() retomberait sur son repli et le banc ne testerait
   * pas le vrai chemin. */
  get value() { return this._value; }
  set value(v) { this._value = String(v); }
  get firstChild() { return this.children[0] || null; }
  get childElementCount() { return this.children.length; }
  get textContent() {
    if (this._texte !== null) return this._texte;
    return this.children.map(c => c.textContent).join('');
  }
  set textContent(v) {
    if (this.children.length) {
      const anciens = this.children;
      this.children = [];
      for (const a of anciens) a.parent = null;
      this._texte = String(v);
      notifierMutation(this);
      return;
    }
    this._texte = String(v);
  }
  append(...enfants) {
    for (const brut of enfants) {
      if (brut == null) continue;
      let e = brut;
      if (typeof e === 'string') { const t = new Noeud('#text'); t._texte = e; e = t; }
      if (e.parent) e.parent.children = e.parent.children.filter(c => c !== e);
      e.parent = this; this.children.push(e); this._texte = null;
      notifierMutation(this);
    }
  }
  appendChild(e) { this.append(e); return e; }
  insertBefore(e, ref) {
    if (e.parent) e.parent.children = e.parent.children.filter(c => c !== e);
    e.parent = this;
    const i = ref ? this.children.indexOf(ref) : -1;
    if (i < 0) this.children.push(e); else this.children.splice(i, 0, e);
    this._texte = null;
    notifierMutation(this);
    return e;
  }
  remove() {
    if (this.parent) {
      const pere = this.parent;
      pere.children = pere.children.filter(c => c !== this);
      this.parent = null;
      notifierMutation(pere);
    }
  }
  /* Utilisé par l'observateur : subtree:true observe tout le sous-arbre. */
  contient(n) {
    for (let e = n; e; e = e.parent) if (e === this) return true;
    return false;
  }
  setAttribute(nom, valeur) {
    this.attributes[nom] = String(valeur);
    if (nom === 'id') this._id = String(valeur);
    else if (nom === 'class') this._className = String(valeur);
    else if (nom.indexOf('data-') === 0) {
      const cle = nom.slice(5).replace(/-([a-z])/g, (m, c) => c.toUpperCase());
      this.dataset[cle] = String(valeur);
    }
  }
  getAttribute(nom) {
    if (nom === 'id') return this._id || this.attributes.id;
    if (nom === 'class') return this._className;
    return this.attributes[nom];
  }
  addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); }
  removeEventListener(type, fn) {
    if (this.listeners[type]) this.listeners[type] = this.listeners[type].filter(f => f !== fn);
  }
  dispatchEvent(ev) {
    ev = ev || {};
    ev.target = ev.target || this;
    ev.preventDefault = ev.preventDefault || (() => {});
    ev.stopPropagation = ev.stopPropagation || (() => {});
    (this.listeners[ev.type] || []).slice().forEach(f => f(ev));
    /* Remonte jusqu'à la racine : c'est ainsi que React reçoit les clics. */
    if (ev.bubbles && this.parent) this.parent.dispatchEvent(ev);
    return true;
  }
  dispatch(type, ev) { ev = ev || {}; ev.type = type; return this.dispatchEvent(ev); }
  click() {
    this._clics = (this._clics || 0) + 1;
    this.dispatchEvent({ type: 'click', bubbles: true, target: this });
  }
  descendants() {
    const tous = [];
    (function marche(n) { for (const c of n.children) { tous.push(c); marche(c); } })(this);
    return tous;
  }
  /* Sélecteurs supportés : .classe, #id, tag, et leurs combinaisons descendantes
   * (« .a .b »), enfants directs (« .a > .b ») et « :scope > .a ». */
  _correspond(partie) {
    if (partie === ':scope') return false;
    let reste = partie;
    if (reste.indexOf('#') === 0) return this._id === reste.slice(1);
    const tag = /^([a-zA-Z][\w-]*)/.exec(reste);
    if (tag && this.tagName !== tag[1].toUpperCase()) return false;
    const classes = reste.match(/\.([\w-]+)/g) || [];
    for (const c of classes) if (!this.classList.contient(c.slice(1))) return false;
    return true;
  }
  _chemin(sel) {
    /* ':scope' désigne le nœud courant : ce n'est pas une étape à chercher, et
     * le traiter comme telle faisait échouer ':scope > .ps-aide-index', donc
     * panneau() recréait un index à chaque mise à jour. '>' qualifie l'étape qui
     * le SUIT, pas celle qui le précède. */
    const etapes = [];
    let direct = false;
    for (const brut of String(sel).trim().split(/\s+/)) {
      if (brut === '>') { direct = true; continue; }
      if (brut === ':scope') continue;
      etapes.push({ partie: brut, direct });
      direct = false;
    }
    return etapes;
  }
  _cherche(sel, plusieurs) {
    const etapes = this._chemin(sel);
    if (!etapes.length) return plusieurs ? [] : null;
    let courants = [this];
    for (const e of etapes) {
      const suivants = [];
      for (const n of courants) {
        const pool = e.direct ? n.children : n.descendants();
        for (const c of pool) if (c._correspond(e.partie)) suivants.push(c);
      }
      courants = suivants;
      if (!courants.length) return plusieurs ? [] : null;
    }
    return plusieurs ? courants : courants[0];
  }
  querySelector(sel) { return this._cherche(sel, false); }
  querySelectorAll(sel) { return this._cherche(sel, true); }
}

/* ------------------------------------------------------- DOM de départ ----- */
const CATALOGUE = {
  total: 3,
  categories: [{ id: 'classique', libelle: 'Classiques' },
               { id: 'esoterique', libelle: 'Ésotériques' }],
  fonctionnalites: [
    { id: 'debogage', libelle: 'Débogage pas à pas' },
    { id: 'completions', libelle: 'Complétion' },
    { id: 'apercu', libelle: 'Aperçu et inspecteur visuel' }],
  langages: [
    { langage: 'python', libelle: 'Python', extensions: ['.py'],
      categorie: 'classique', facettes: ['debogage', 'completions'] },
    { langage: 'html', libelle: 'HTML', extensions: ['.html', '.htm'],
      categorie: 'classique', facettes: ['completions', 'apercu'] },
    { langage: 'brainfuck', libelle: 'Brainfuck', extensions: ['.bf', '.b'],
      categorie: 'esoterique', facettes: ['debogage', 'completions'] }],
};

const AIDE = {
  languages: ['Python', 'Brainfuck'],
  articles: [
    { id: 'py-1', lang: 'Python', group: 'Bases', title: 'Boucles for',
      summary: 'Parcourir une séquence.', intro: false,
      blocks: [{ title: 'Exemple', text: 'Une boucle.', code: 'for i in range(3):\n    print(i)' }] },
    { id: 'bf-1', lang: 'Brainfuck', group: 'Syntaxe', title: 'Les huit commandes',
      summary: 'Le jeu d’instructions complet.', intro: true,
      blocks: [{ title: 'Explication', text: 'Huit commandes, aucun commentaire.', code: '+++.' }] },
    { id: 'bf-2', lang: 'Brainfuck', group: 'Syntaxe', title: 'Boucles crochets',
      summary: 'Répéter jusqu’à zéro.', intro: false,
      blocks: [{ title: 'Exemple', text: 'Une boucle.', code: '+++[-]' }] },
    { id: 'bf-3', lang: 'Brainfuck', group: 'Dans Pascal Studio', title: 'Déboguer pas à pas',
      summary: 'Le pas à pas réel.', intro: false,
      blocks: [{ title: 'Texte', text: 'Aucun point d’arrêt n’est exigé.', code: '' }] },
  ],
};

function construirePanneau() {
  const section = new Noeud('section');
  section.className = 'language-help';
  const barre = new Noeud('div');
  barre.className = 'lh-languages';
  for (const nom of ['Pascal', 'Python', 'Brainfuck']) {
    const b = new Noeud('button');
    b.textContent = nom;
    if (nom === 'Brainfuck') b.className = 'selected';
    barre.append(b);
  }
  const disposition = new Noeud('div');
  disposition.className = 'lh-layout';
  const nav = new Noeud('nav');
  nav.className = 'lh-nav';
  const recherche = new Noeud('div');
  recherche.className = 'lh-search';
  const champ = new Noeud('input');
  champ.id = 'lh-find';
  champ.type = 'search';
  recherche.append(champ);
  const groupe = new Noeud('details');
  groupe.className = 'lh-group';
  const sommaire = new Noeud('summary');
  sommaire.append('Syntaxe ', (() => { const s = new Noeud('span'); s.textContent = '(2)'; return s; })());
  const fiche = new Noeud('button');
  fiche.textContent = 'Boucles crochets';
  const fiche2 = new Noeud('button');
  fiche2.textContent = 'Déboguer pas à pas';
  groupe.append(sommaire, fiche, fiche2);
  nav.append(recherche, groupe);
  disposition.append(nav);
  section.append(barre, disposition);
  return section;
}

const document = {
  readyState: 'complete',
  listeners: {},
  createElement: tag => new Noeud(tag),
  createTextNode: t => { const n = new Noeud('#text'); n._texte = String(t); return n; },
  addEventListener(type, fn) { (this.listeners[type] = this.listeners[type] || []).push(fn); },
  getElementById(id) { return this.documentElement.descendants().find(n => n._id === id) || null; },
  querySelector(sel) { return this.documentElement.querySelector(sel); },
  querySelectorAll(sel) { return this.documentElement.querySelectorAll(sel); },
};
document.documentElement = new Noeud('html');
document.body = new Noeud('body');
document.documentElement.append(document.body);

let requetes = [];
const sandbox = {
  document, console, Promise, Set, Map, Array, Object, String, Number, JSON,
  RegExp, Math, Date, parseInt,
  Event: function (type, options) { this.type = type; Object.assign(this, options || {}); },
  requestAnimationFrame: fn => { fn(); return 1; },
  MutationObserver: ObservateurMutations,
  queueMicrotask,
  fetch: async (url, options) => {
    requetes.push({ url, options });
    return { ok: true, status: 200, json: async () => CATALOGUE };
  },
};
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
sandbox.window.PS_LANG_HELP = AIDE;
sandbox.window.PS_DB_HELP = { languages: ['SQL'], articles: [
  { id: 'sql-1', lang: 'SQL', group: 'Requêtes', title: 'SELECT et WHERE',
    summary: 'Filtrer des lignes.', blocks: [{ title: 'Exemple', text: 'Une requête.',
    code: 'SELECT * FROM t WHERE a = 1' }] }] };

document.body.append(construirePanneau());

const source = fs.readFileSync(path.join(__dirname, '..', 'aide-index.js'), 'utf8');
vm.createContext(sandbox);
new vm.Script(source).runInContext(sandbox);
const win = sandbox.window;
const API = win.PSAideIndex;

/* Le catalogue est chargé par fetch, donc asynchrone. regler() le rend
 * disponible immédiatement : c'est fait pour les bancs, et cela évite de rendre
 * tout le banc asynchrone pour une seule donnée. La requête a bien eu lieu, elle
 * est vérifiée plus bas. */
API.regler({ catalogue: CATALOGUE });

/* ---------------------------------------------------------- vérifications --- */
console.log('=== fonctions pures ===');
verifier('l’API est exposée', typeof API, 'object');
verifier('normaliser retire les accents et met en minuscules',
         API.normaliser('Déboguer — À propos'), 'deboguer — a propos');
verifier('les articles viennent des globaux window', API.articles().length, 5);
const comptes = API.comptes();
verifier('les comptes de fiches par langage',
         Object.keys(comptes).sort().map(k => k + '=' + comptes[k]),
         ['Brainfuck=3', 'Python=1', 'SQL=1']);
verifier('l’index est construit une fois (même objet)',
         API.index() === API.index(), true);

console.log();
console.log('=== panneau construit au chargement ===');
const nav = document.querySelector('.language-help .lh-nav');
const panneau = nav.children[0];
verifier('l’index est le premier enfant de la navigation',
         panneau.className, 'ps-aide-index');
verifier('la barre de langages d’origine est masquée, pas supprimée',
         [document.querySelector('.language-help .lh-languages').className,
          document.querySelectorAll('.language-help .lh-languages button').length],
         ['lh-languages ps-aide-index-cache', 3]);
verifier('quatre zones : filtre, facettes, langues, recherche globale',
         panneau.children.map(c => c.className),
         ['ps-aide-index-filtre', 'ps-aide-index-facettes',
          'ps-aide-index-langues', 'ps-aide-index-global']);

console.log();
console.log('=== facettes de fonctionnalité (venues du serveur) ===');
const zoneFacettes = panneau.children[1];
verifier('le catalogue est demandé à /api/aide/capacites',
         requetes.map(r => r.url), ['/api/aide/capacites']);
verifier('une puce par fonctionnalité du catalogue',
         zoneFacettes.querySelectorAll('.ps-aide-index-facette')
           .map(b => b.children[0].textContent),
         ['Débogage pas à pas', 'Complétion', 'Aperçu et inspecteur visuel']);
verifier('chaque puce affiche le nombre de langages concernés',
         zoneFacettes.querySelectorAll('.ps-aide-index-facette')
           .map(b => b.children[1].textContent), ['2', '3', '1']);
verifier('les puces annoncent leur état aux lecteurs d’écran',
         zoneFacettes.querySelectorAll('.ps-aide-index-facette')
           .map(b => b.getAttribute('aria-pressed')), ['false', 'false', 'false']);

console.log();
console.log('=== index des langages ===');
const zoneLangues = panneau.children[2];
function languesAffichees() {
  return zoneLangues.querySelectorAll('.ps-aide-langue')
    .map(b => b.getAttribute('data-langage'));
}
function categoriesAffichees() {
  return zoneLangues.querySelectorAll('.ps-aide-categorie')
    .map(g => g.children[0].textContent);
}
verifier('les langages du panneau sont repris', languesAffichees(),
         ['Pascal', 'Python', 'Brainfuck']);
verifier('deux catégories, les ésotériques à part', categoriesAffichees(),
         ['Classiques (2)', 'Ésotériques (1)']);
verifier('le compte de fiches est affiché quand il est connu',
         zoneLangues.querySelectorAll('.ps-aide-compte').map(b => b.textContent),
         ['1', '3']);
verifier('un langage sans fiche connue n’affiche pas de faux zéro',
         zoneLangues.querySelectorAll('.ps-aide-langue')[0]
           .querySelectorAll('.ps-aide-compte').length, 0);
verifier('le langage sélectionné est marqué',
         zoneLangues.querySelectorAll('.ps-aide-langue')
           .map(b => b.classList.contient('selected')), [false, false, true]);
verifier('la ligne de compte résume l’index',
         zoneLangues.parent.children[0].children[2].textContent,
         '3 langage(s) sur 3');

console.log();
console.log('=== filtre de langages ===');
const champFiltre = panneau.children[0].children[1];
champFiltre.value = 'bra';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
verifier('le filtre ne garde que ce qui correspond', languesAffichees(), ['Brainfuck']);
verifier('la ligne de compte suit',
         zoneLangues.parent.children[0].children[2].textContent,
         '1 langage(s) sur 3');
champFiltre.value = '.bf';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
verifier('une extension trouve son langage', languesAffichees(), ['Brainfuck']);
champFiltre.value = 'DEBO';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
verifier('un filtre sans correspondance le dit',
         zoneLangues.querySelectorAll('.ps-aide-index-vide')
           .map(p => p.textContent).length, 1);
champFiltre.value = '';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
verifier('vider le filtre restaure la liste', languesAffichees().length, 3);

console.log();
console.log('=== facettes et filtre se combinent ===');
const puceDebogage = zoneFacettes.querySelectorAll('.ps-aide-index-facette')[0];
puceDebogage.dispatch('click', { type: 'click', target: puceDebogage });
verifier('la puce activée filtre l’index', languesAffichees(), ['Python', 'Brainfuck']);
verifier('la puce change d’état', puceDebogage.classList.contient('actif'), true);
champFiltre.value = 'brain';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
verifier('langage ET fonctionnalité : intersection', languesAffichees(), ['Brainfuck']);
champFiltre.value = '';
champFiltre.dispatch('input', { type: 'input', target: champFiltre });
puceDebogage.dispatch('click', { type: 'click', target: puceDebogage });
verifier('recliquer la puce lève le filtre', languesAffichees().length, 3);

console.log();
console.log('=== recherche dans tous les langages ===');
verifier('resultatsGlobaux() calcule indépendamment de la portée affichée',
         API.resultatsGlobaux('boucle').length > 0, true);
API.regler({ porteeGlobale: true });
const zoneGlobale = panneau.children[3];
verifier('la portée est annoncée', zoneGlobale.children[0].children[1].children[1].textContent,
         'Portée : tous les langages. Saisissez un mot dans « Rechercher dans l’aide ».');
const recherche = document.getElementById('lh-find');
recherche.value = 'boucle';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
const resultats = zoneGlobale.children[1].querySelectorAll('.ps-aide-resultat');
verifier('la frappe dans le champ du panneau déclenche la recherche globale',
         resultats.length > 0, true);
verifier('le titre exact passe avant le corps du texte',
         resultats[0].getAttribute('data-titre'), 'Boucles for');
verifier('chaque résultat porte son chemin langage › groupe',
         resultats[0].children[0].textContent, 'Python › Bases');
verifier('les résultats traversent les langages',
         resultats.map(b => b.getAttribute('data-langage')).indexOf('Brainfuck') >= 0, true);
recherche.value = 'deboguer';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
verifier('la recherche est insensible aux accents',
         zoneGlobale.children[1].querySelectorAll('.ps-aide-resultat')
           .map(b => b.getAttribute('data-titre')), ['Déboguer pas à pas']);
recherche.value = 'zzz-introuvable';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
verifier('une recherche sans résultat le dit',
         zoneGlobale.children[1].querySelectorAll('.ps-aide-index-vide').length, 1);

console.log();
console.log('=== facettes appliquées aux résultats ===');
recherche.value = 'boucle';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
/* SQL vient de PS_DB_HELP et n'est pas dans le registre : ses capacités sont
 * inconnues, donc une facette active doit l'écarter des résultats. */
recherche.value = 'requête';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
verifier('sans facette, un langage hors registre reste cherchable',
         zoneGlobale.children[1].querySelectorAll('.ps-aide-resultat')
           .map(b => b.getAttribute('data-langage')), ['SQL']);
puceDebogage.dispatch('click', { type: 'click', target: puceDebogage });
verifier('avec une facette, ce qui n’a pas de capacités connues sort',
         zoneGlobale.children[1].querySelectorAll('.ps-aide-resultat').length, 0);
puceDebogage.dispatch('click', { type: 'click', target: puceDebogage });
recherche.value = 'boucle';
recherche.dispatch('input', { type: 'input', target: recherche, bubbles: true });
verifier('une facette partagée ne retire que les langages qui ne l’ont pas',
         zoneGlobale.children[1].querySelectorAll('.ps-aide-resultat')
           .map(b => b.getAttribute('data-langage')), ['Python', 'Brainfuck']);

console.log();
console.log('=== navigation déléguée ===');
const avant = document.querySelectorAll('.language-help .lh-languages button')
  .map(b => b._clics || 0);
const entreeBrainfuck = zoneLangues.querySelectorAll('.ps-aide-langue')
  .find(b => b.getAttribute('data-langage') === 'Brainfuck');
entreeBrainfuck.dispatch('click', { type: 'click', target: entreeBrainfuck });
const apres = document.querySelectorAll('.language-help .lh-languages button')
  .map(b => b._clics || 0);
verifier('cliquer une entrée de l’index clique le bouton de l’application',
         apres.map((c, i) => c - avant[i]), [0, 0, 1]);

(async () => {
  recherche.value = 'crochets';
  const ouvert = await API.ouvrirFiche('Brainfuck', 'Boucles crochets');
  verifier('ouvrir une fiche retrouve son bouton et le clique', ouvert, true);
  verifier('le champ de recherche du panneau est vidé pour retrouver la fiche',
           document.getElementById('lh-find').value, '');

  console.log();
  console.log('=== comptes appris du panneau ===');
  API.regler({ filtre: '' });
  API.apprendreComptes();
  verifier('le total des groupes affichés complète un langage non publié',
           API.etat().comptesAppris, { Brainfuck: 2 });

  console.log();
  console.log('=== sans serveur ===');
  /* Laisser le chargement initial se régler d'abord : jusque-là le banc était
   * synchrone, donc sa promesse était encore en vol et chargerCapacites() aurait
   * refusé d'en lancer une seconde. */
  await new Promise(r => setTimeout(r, 0));
  requetes = [];
  const sauvegarde = sandbox.fetch;
  /* Le stub en panne note aussi l'URL : c'est ce qui permet de vérifier qu'un
   * nouvel essai a bien été tenté, et pas seulement que l'erreur s'affiche. */
  sandbox.fetch = async (url) => { requetes.push({ url }); throw new Error('réseau coupé'); };
  const autre = construirePanneau();
  document.body.children = [];
  document.body.append(autre);
  /* Remettre le catalogue à nul : sans cela balayer() ne retenterait aucun
   * chargement et la panne du serveur ne serait pas exercée du tout. */
  API.regler({ filtre: '', facettes: [], porteeGlobale: false, catalogue: null,
               reinitialiserIndex: true });
  API.balayer();
  await new Promise(r => setTimeout(r, 10));
  const zone2 = autre.querySelector('.lh-nav').children[0].children[1];
  const erreur = zone2.querySelectorAll('.ps-aide-index-erreur');
  verifier('l’index reste utilisable et dit pourquoi les facettes manquent',
           erreur.length ? erreur[0].textContent : '', 
           'Fonctionnalités indisponibles : réseau coupé');
  verifier('un nouvel essai sera tenté au prochain balayage',
           requetes.map(r => r.url), ['/api/aide/capacites']);
  verifier('la liste des langages fonctionne toujours sans serveur',
           autre.querySelector('.lh-nav').children[0].children[2]
             .querySelectorAll('.ps-aide-langue').length, 3);
  sandbox.fetch = sauvegarde;

  /* ---------------------------------------------------------------------
   * Ouverture du panneau d'aide : la cascade de balayages doit converger.
   *
   * C'est le scénario qui manquait et qui a laissé passer la panne signalée
   * par l'utilisateur : ouvrir l'aide faisait planter l'application. Le
   * balayage reconstruit l'index, ces écritures rappellent l'observateur, qui
   * relance un balayage — sans fin. Rien ne l'arrête tant que le panneau
   * existe, donc le rendu s'emballe et le processus de rendu tombe.
   * ------------------------------------------------------------------- */
  console.log();
  console.log('Ouverture du panneau d’aide, observateur réel :');
  API.regler({ filtre: '', facettes: [], porteeGlobale: false, catalogue: null,
               reinitialiserIndex: true });
  reinitialiserCompteurs();
  const ouverture = construirePanneau();
  document.body.children = [];
  document.body.append(ouverture);           /* l'application ouvre l'aide */
  await new Promise(r => setTimeout(r, 300));
  verifier('aucun débordement de l’observateur (cascade infinie)',
           DEBORDEMENT, false);
  verifier('le nombre de balayages reste borné après l’ouverture',
           CYCLES <= 12, true);
  const stabilise = ouverture.descendants().length;
  const cyclesStabilises = CYCLES;
  await new Promise(r => setTimeout(r, 300));
  verifier('le panneau ne grossit plus une fois ouvert',
           ouverture.descendants().length, stabilise);
  verifier('aucun balayage supplémentaire à l’état stable',
           CYCLES, cyclesStabilises);

  /* Une interaction légitime doit reconstruire une fois, puis se taire. */
  reinitialiserCompteurs();
  API.regler({ filtre: 'brain' });
  await new Promise(r => setTimeout(r, 300));
  verifier('un filtre déclenche un nombre borné de balayages',
           DEBORDEMENT, false);
  verifier('et converge après la reconstruction', CYCLES <= 12, true);
  const apresFiltre = ouverture.descendants().length;
  await new Promise(r => setTimeout(r, 300));
  verifier('aucune écriture résiduelle après le filtre',
           ouverture.descendants().length, apresFiltre);

  console.log();
  console.log(OK + '/' + N + ' vérifications conformes');
  process.exit(OK === N ? 0 : 1);
})();
