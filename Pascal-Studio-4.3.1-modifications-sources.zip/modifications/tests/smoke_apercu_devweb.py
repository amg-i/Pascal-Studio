#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : l'aperçu web et le journal dev web, ensemble.

Ce que les autocontrôles des modules ne peuvent PAS voir
--------------------------------------------------------
    `devweb_journal.py` vérifie son tampon et son injection sur une chaîne.
    `devweb.py` vérifie la façade. Ni l'un ni l'autre ne démarre le VRAI serveur
    d'aperçu : c'est lui qui décide si le script est injecté, si la route de
    collecte existe, et si les gardes (hôte, cookie, taille) tiennent. Trois
    fautes ne sont visibles qu'ici :

      * un `do_POST` absent : le script de capture posterait vers une route
        qui n'existe pas, la page avalerait l'échec (c'est voulu), et le journal
        resterait vide SANS AUCUN message nulle part ;
      * une injection placée après les scripts d'en-tête : les erreurs de ces
        scripts, celles qu'on vient chercher, auraient déjà eu lieu ;
      * une collecte sans cookie : n'importe quel processus de la machine
        pourrait remplir le journal de l'utilisateur.

    Le banc vérifie aussi la coexistence avec l'inspecteur visuel, déjà injecté
    par le même serveur : deux injections dans le même document ne doivent ni se
    marcher dessus, ni se dupliquer.

Lancer :  python3 tests/smoke_apercu_devweb.py
"""

import http.cookiejar
import io
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
sys.path.insert(0, MODIFICATIONS)

import devweb                                   # noqa: E402
import devweb_journal                           # noqa: E402
from web_preview import Preview                 # noqa: E402

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


PAGE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<title>Page aperçue</title>
<link rel="stylesheet" href="style.css">
<script>console.log('script d’en-tête');</script>
</head>
<body>
<h1>Bonjour</h1>
<img src="logo.png" alt="Logo">
<script src="app.js" defer></script>
</body>
</html>
"""

STYLE = "body { color: #111; background: #fff }\n"
APP = "console.warn('avertissement de la page');\n"


def ouvrir(port, chemin, methode='GET', corps=None, entetes=None,
           jar=None, suivre=True):
    """(statut, corps, en-têtes) — sans lever sur une réponse d'erreur."""
    gestionnaires = []
    if jar is not None:
        gestionnaires.append(urllib.request.HTTPCookieProcessor(jar))
    if not suivre:
        class _SansSuivi(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, *a, **k):
                return None
        gestionnaires.append(_SansSuivi())
    ouvreur = urllib.request.build_opener(*gestionnaires)
    requete = urllib.request.Request(
        'http://127.0.0.1:%d%s' % (port, chemin),
        data=corps, method=methode,
        headers=dict({'Content-Type': 'application/json'}, **(entetes or {})))
    try:
        with ouvreur.open(requete, timeout=15) as reponse:
            return (reponse.status, reponse.read(),
                    {k.lower(): v for k, v in reponse.headers.items()})
    except urllib.error.HTTPError as erreur:
        return erreur.code, erreur.read(), {}
    except Exception as exc:
        return None, str(exc).encode(), {}


def principal():
    espace = tempfile.mkdtemp(prefix='ps-apercu-devweb-')
    cache = tempfile.mkdtemp(prefix='ps-apercu-cache-')
    projet = os.path.join(espace, 'site')
    os.makedirs(projet)
    io.open(os.path.join(projet, 'index.html'), 'w', encoding='utf8').write(PAGE)
    io.open(os.path.join(projet, 'style.css'), 'w', encoding='utf8').write(STYLE)
    io.open(os.path.join(projet, 'app.js'), 'w', encoding='utf8').write(APP)

    apercu = Preview(cache)
    devweb.journal_vider()          # le banc part d'un journal vide et connu
    try:
        info = apercu.start(espace, os.path.join(projet, 'index.html'))
        port = info['port']
        verif(info.get('url', '').startswith('http://127.0.0.1:%d/' % port),
              'start() rend une adresse de l’aperçu (%r)' % info.get('url'))
        verif(info.get('mode') == 'static', 'le mode statique est choisi')

        # --------------------------------------------- 1. la page est servie --
        jar = http.cookiejar.CookieJar()
        statut, corps, entetes = ouvrir(port, urllib.parse.urlsplit(
            info['url']).path, jar=jar)
        page = corps.decode('utf8', 'replace')
        verif(statut == 200, 'la page aperçue est servie (%s)' % statut)
        verif('<h1>Bonjour</h1>' in page, 'le contenu du projet est servi')
        verif(entetes.get('x-content-type-options') == 'nosniff',
              'la réponse porte X-Content-Type-Options')
        verif(entetes.get('cache-control') == 'no-store',
              'la réponse n’est pas mise en cache')

        # ------------------------------------------- 2. la capture est placée --
        marqueur = devweb_journal.MARQUEUR
        verif(page.count(marqueur) == 1,
              'le script de capture est présent exactement une fois (%d)'
              % page.count(marqueur))
        tete = page.lower().find('<head')
        capture = page.find(marqueur)
        verif(tete != -1 and capture > tete,
              'le script de capture est DANS <head>')
        # La balise qui PORTE la capture, pas le marqueur à l'intérieur de son
        # texte : comparer la position du marqueur à celle du premier <script>
        # mesurait deux choses différentes et accusait l'ordre d'injection.
        balise_capture = page.lower().rfind('<script', 0, capture)
        premier_script = page.lower().find('<script')
        verif(balise_capture == premier_script and premier_script != -1,
              'le script de capture est le PREMIER <script> du document : en '
              'defer ou en fin de page, il manquerait les erreurs des scripts '
              'd’en-tête (balise de capture à %d, premier script à %d)'
              % (balise_capture, premier_script))
        verif(page.find('script d’en-tête') > capture,
              'le script d’en-tête de la page vient APRÈS la capture')
        verif('__ps_inspecteur_js' in page,
              'l’inspecteur visuel est toujours injecté à côté de la capture')
        verif(page.count('__ps_inspecteur_js') == 1,
              'l’inspecteur visuel n’est pas dupliqué')

        # Deuxième chargement : rien ne doit s'accumuler côté serveur.
        statut, corps2, _ = ouvrir(port, '/site/index.html', jar=jar)
        verif(statut == 200
              and corps2.decode('utf8', 'replace').count(marqueur) == 1,
              'un second chargement n’injecte pas deux fois la capture')

        # Le journal a été vidé AU DÉMARRAGE de l'aperçu, avec une entrée
        # système qui dit quelle page est servie.
        debut = devweb.journal(depuis=0, limite=5)
        verif(debut['total'] == 1
              and debut['entrees'][0]['type'] == 'systeme'
              and 'index.html' in debut['entrees'][0]['message'],
              'le démarrage de l’aperçu vide le journal et dit quelle page est '
              'servie (%r)' % debut['entrees'][:1])

        # --------------------------------------------- 3. les autres fichiers --
        statut, css, _ = ouvrir(port, '/site/style.css', jar=jar)
        texte_css = css.decode('utf8', 'replace')
        verif(statut == 200 and 'color: #111' in texte_css
              and marqueur not in texte_css,
              'une feuille de style n’est pas modifiée par la capture')
        statut, js, _ = ouvrir(port, '/site/app.js', jar=jar)
        verif(statut == 200 and marqueur not in js.decode('utf8', 'replace'),
              'un script du projet n’est pas modifié par la capture')

        # -------------------------------------------- 4. la collecte marche --
        lot = {'entrees': [
            {'type': 'console', 'niveau': 'log', 'message': 'bonjour',
             'arguments': '["bonjour"]', 'page': '/index.html'},
            {'type': 'erreur', 'niveau': 'erreur', 'message': 'x est indéfini',
             'pile': 'ReferenceError: x is not defined\n at app.js:1:1',
             'url': '/app.js', 'ligne': 1, 'colonne': 1},
            {'type': 'reseau', 'message': 'GET /style.css', 'statut': 200,
             'octets_transferes': 44, 'duree': 3.5},
            {'type': 'navigation', 'message': 'chargement', 'ttfb': 1.25,
             'dom_complet': 20.0},
            {'type': 'invention', 'message': 'ce type n’existe pas'},
        ]}
        corps_lot = json.dumps(lot).encode('utf8')
        statut, reponse, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                                    corps=corps_lot, jar=jar)
        recu = json.loads(reponse.decode('utf8')) if statut == 200 else {}
        verif(statut == 200, 'la collecte répond 200 (%s : %r)'
              % (statut, reponse[:120]))
        verif(recu.get('acceptees') == 4,
              'les 4 entrées reconnues sont acceptées (%r)' % recu)
        verif(recu.get('refusees') == 1,
              'l’entrée d’un type inconnu est refusée (%r)' % recu)
        verif(recu.get('total') == 5,
              'le total du journal compte l’entrée système et les 4 acceptées '
              '(%r)' % recu.get('total'))

        etat = devweb.journal(depuis=0, limite=50)
        types = [e['type'] for e in etat['entrees']]
        verif(types == ['systeme', 'console', 'erreur', 'reseau', 'navigation'],
              'le journal rend les entrées dans l’ordre (%r)' % types)
        erreur = [e for e in etat['entrees'] if e['type'] == 'erreur'][0]
        verif(erreur['ligne'] == 1 and 'ReferenceError' in erreur['pile'],
              'une entrée d’erreur garde sa ligne et sa pile (%r)' % erreur)
        reseau = [e for e in etat['entrees'] if e['type'] == 'reseau'][0]
        verif(reseau['statut'] == 200 and reseau['octets_transferes'] == 44,
              'une entrée réseau garde son statut et son poids (%r)' % reseau)
        verif(all(e['id'] for e in etat['entrees']),
              'chaque entrée porte un identifiant de suite')
        verif(etat['suivant'] == etat['entrees'][-1]['id'],
              'le journal rend l’identifiant à rappeler pour la sonde suivante')

        # Interrogation incrémentale : le panneau ne redemande pas ce qu'il a.
        suite = devweb.journal(depuis=etat['suivant'], limite=50)
        verif(suite['entrees'] == [] and suite['total'] == etat['total'],
              'une interrogation depuis le dernier identifiant ne rend rien de '
              'nouveau (%r)' % suite['entrees'])

        # Un message démesuré est recoupé, pas refusé : la page n'y peut rien.
        long = {'entrees': [{'type': 'console', 'niveau': 'log',
                             'message': 'x' * (devweb_journal.MAX_MESSAGE * 3)}]}
        ouvrir(port, '/__ps_devweb_capture', 'POST',
               corps=json.dumps(long).encode(), jar=jar)
        dernier = devweb.journal(depuis=etat['suivant'], limite=10)['entrees']
        verif(dernier and len(dernier[-1]['message'])
              == devweb_journal.MAX_MESSAGE,
              'un message démesuré est recoupé à la borne (%d caractères)'
              % (len(dernier[-1]['message']) if dernier else -1))

        # ------------------------------------------------ 5. les gardes -------
        statut, _, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                              corps=json.dumps({'entrees': []}).encode())
        verif(statut == 403, 'une collecte SANS cookie est refusée (%s)'
              % statut)
        # Sans jar : un HTTPCookieProcessor ajouterait son propre en-tête
        # Cookie à côté du faux, et le bon cookie passerait quand même — le banc
        # accuserait alors la garde d'un artefact de son propre outillage.
        statut, _, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                              corps=json.dumps({'entrees': []}).encode(),
                              entetes={'Cookie': '__ps_preview=pas-le-bon'})
        verif(statut == 403, 'une collecte avec un mauvais cookie est refusée '
              '(%s)' % statut)
        statut, _, _ = ouvrir(port, '/__ps_devweb_journal', 'POST',
                              corps=b'{}', jar=jar)
        verif(statut == 404, 'un autre chemin de collecte n’existe pas (%s)'
              % statut)
        statut, _, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                              corps=b'x' * 200_001, jar=jar,
                              entetes={'Content-Length': '200001'})
        verif(statut == 413, 'un lot démesuré est refusé (%s)' % statut)
        statut, _, _ = ouvrir(port, '/__ps_devweb_capture', 'POST', corps=b'',
                              jar=jar, entetes={'Content-Length': '0'})
        verif(statut == 400 or statut == 411,
              'un lot vide est refusé (%s)' % statut)
        statut, _, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                              corps=json.dumps({'entrees': []}).encode(),
                              jar=jar, entetes={'Host': 'exemple.fr'})
        verif(statut == 403, 'une collecte d’un hôte non local est refusée (%s)'
              % statut)
        # Un corps qui n'est pas du JSON : la page n'y peut rien, la réponse
        # reste 200 avec une raison, et l'aperçu continue de fonctionner.
        statut, reponse, _ = ouvrir(port, '/__ps_devweb_capture', 'POST',
                                    corps=b'pas du json', jar=jar,
                                    entetes={'Content-Type': 'text/plain'})
        recu = json.loads(reponse.decode('utf8')) if statut == 200 else {}
        verif(statut == 200 and recu.get('acceptees') == 0
              and recu.get('erreur'),
              'un corps non JSON est refusé en le disant, sans casser l’aperçu '
              '(%s : %r)' % (statut, recu))
        statut, page2, _ = ouvrir(port, '/site/index.html', jar=jar)
        verif(statut == 200 and b'Bonjour' in page2,
              'l’aperçu sert toujours la page après les refus')

        # ------------------------------------------- 6. l'aperçu s'arrête -----
        apercu.stop()
        verif(apercu.port is None, 'stop() libère le port')
        statut, _, _ = ouvrir(port, '/site/index.html', jar=jar)
        verif(statut is None, 'le serveur d’aperçu ne répond plus après stop()')
    finally:
        try:
            apercu.stop()
        except Exception:
            pass
        shutil.rmtree(espace, ignore_errors=True)
        shutil.rmtree(cache, ignore_errors=True)

    return 0 if not ECHECS else 1


def main():
    depart = time.monotonic()
    code = principal()
    sys.stderr.write('\nsmoke_apercu_devweb : %d contrôles, %d échec(s), %.1f s\n'
                     % (OK + len(ECHECS), len(ECHECS), time.monotonic() - depart))
    if ECHECS:
        for echec in ECHECS:
            sys.stderr.write('  - %s\n' % echec)
    return code


if __name__ == '__main__':
    sys.exit(main())
