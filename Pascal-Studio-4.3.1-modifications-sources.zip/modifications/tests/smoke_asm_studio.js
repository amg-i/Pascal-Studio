#!/usr/bin/env node
/* Banc de fumée : le tokenizer Monaco de l'assembleur (4.0.0).
 *
 * Ce tokenizer est ENGENDRÉ par asm_studio.py depuis les tables d'assembleur.py.
 * Le banc vérifie donc deux choses distinctes, et la seconde est la plus
 * importante :
 *
 *   1. que le fichier produit est un module Monaco utilisable — structure de
 *      `conf` et de `language`, règles du tokenizer composées d'expressions
 *      rationnelles réelles, et aucun attribut `@nom` qui renverrait à une liste
 *      inexistante (Monaco ne le signale pas : la règle cesse simplement de
 *      classer, sans erreur nulle part) ;
 *   2. que le tokenizer et l'analyseur connaissent exactement les mêmes
 *      registres et les mêmes mnémoniques. C'est la raison d'être de
 *      l'engendrement : deux listes écrites séparément finissent par diverger,
 *      et l'éditeur colore alors en mot-clef une instruction que l'analyseur
 *      signale comme inconnue.
 *
 * Emploi : node tests/smoke_asm_studio.js
 */
'use strict';

const {execFileSync} = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const ICI = __dirname;
const MODIFICATIONS = path.resolve(ICI, '..');
const CIBLE = path.join(MODIFICATIONS, 'monaco-additions', 'asm-studio.js');

let pass = 0;
const echecs = [];

function verif(condition, message) {
  if (condition) { pass += 1; return; }
  echecs.push(message);
}

async function charger() {
  /* Le fichier est un module ES ; Node ne l'importe comme tel que sur une
     extension .mjs. On le recopie dans un dossier temporaire plutôt que de
     modifier l'archive. */
  const dossier = fs.mkdtempSync(path.join(os.tmpdir(), 'asm-studio-'));
  const copie = path.join(dossier, 'asm-studio.mjs');
  fs.copyFileSync(CIBLE, copie);
  try {
    return await import(copie);
  } finally {
    fs.rmSync(dossier, {recursive: true, force: true});
  }
}

function tablesPython() {
  const sonde = [
    'import json, sys',
    "sys.path.insert(0, sys.argv[1])",
    'import assembleur',
    'print(json.dumps({',
    "    'registres': sorted(assembleur.TOUS_REGISTRES),",
    "    'mnemoniques': sorted(assembleur.MNEMONIQUES),",
    "    'marqueur': assembleur.MARQUEUR,",
    '}))',
  ].join('\n');
  const sortie = execFileSync('python3', ['-c', sonde, MODIFICATIONS],
    {encoding: 'utf8', timeout: 60000});
  return JSON.parse(sortie);
}

(async () => {
  if (!fs.existsSync(CIBLE)) {
    console.log('ECHEC : asm-studio.js introuvable : ' + CIBLE);
    process.exit(1);
  }
  const brut = fs.readFileSync(CIBLE, 'utf8');
  const module = await charger();
  const py = tablesPython();

  console.log('-- Structure du module');
  verif(typeof module.conf === 'object' && module.conf !== null,
    '« conf » n’est pas exporté comme objet');
  verif(typeof module.language === 'object' && module.language !== null,
    '« language » n’est pas exporté comme objet');
  verif(module.conf.comments && module.conf.comments.lineComment === '#',
    'le commentaire de ligne GAS (« # ») n’est pas déclaré');
  verif(Array.isArray(module.conf.comments.blockComment)
    && module.conf.comments.blockComment[0] === '/*'
    && module.conf.comments.blockComment[1] === '*/',
    'le commentaire de bloc n’est pas /* … */ : '
    + JSON.stringify(module.conf.comments.blockComment));
  verif(Array.isArray(module.conf.brackets) && module.conf.brackets.length >= 2,
    'les paires de crochets et parenthèses ne sont pas déclarées');
  verif(Array.isArray(module.conf.autoClosingPairs)
    && module.conf.autoClosingPairs.length >= 3,
    'les fermetures automatiques ne sont pas déclarées');
  verif(brut.includes('ps-4.0.0-assembleur'),
    'le marqueur de version est absent du fichier engendré');
  verif(brut.includes('ENGENDRÉ'),
    'le fichier n’annonce pas qu’il est engendré : il serait modifié à la main');
  verif(brut.includes('assembleur.py'),
    'le fichier ne nomme pas sa source de vérité');

  console.log('-- Listes de mots');
  for (const nom of ['keywords', 'registers', 'directives']) {
    verif(Array.isArray(module.language[nom]),
      '« ' + nom + ' » n’est pas un tableau');
    verif(module.language[nom].length > 0, '« ' + nom + ' » est vide');
    verif(module.language[nom].every(m => typeof m === 'string' && m.length > 0),
      '« ' + nom + ' » contient une entrée vide ou non textuelle');
    verif(new Set(module.language[nom]).size === module.language[nom].length,
      '« ' + nom + ' » contient des doublons');
  }
  verif(module.language.keywords.length >= 150,
    'seulement ' + module.language.keywords.length + ' mnémoniques colorés');
  verif(module.language.registers.length >= 150,
    'seulement ' + module.language.registers.length + ' registres colorés');
  verif(module.language.directives.length >= 60,
    'seulement ' + module.language.directives.length + ' directives colorées');
  for (const mot of ['mov', 'syscall', 'jmp', 'push', 'pop', 'leave']) {
    verif(module.language.keywords.includes(mot),
      'le mnémonique « ' + mot + ' » n’est pas coloré');
  }
  for (const registre of ['rax', 'eax', 'ah', 'r15d', 'xmm0', 'ymm31', 'rip']) {
    verif(module.language.registers.includes(registre),
      'le registre « ' + registre + ' » n’est pas coloré');
  }
  for (const directive of ['text', 'data', 'globl', 'section', 'db', 'times']) {
    verif(module.language.directives.includes(directive),
      'la directive « ' + directive + ' » n’est pas colorée');
  }

  console.log('-- Règles du tokenizer');
  const racine = module.language.tokenizer && module.language.tokenizer.root;
  verif(Array.isArray(racine) && racine.length >= 10,
    'le tokenizer n’a pas de règles racine exploitables');
  verif(Array.isArray(module.language.tokenizer.commentaire),
    'l’état « commentaire » du tokenizer est absent');
  let nbExpressions = 0;
  const attributsVus = new Set();
  for (const [index, regle] of racine.entries()) {
    verif(Array.isArray(regle) && regle.length >= 2,
      'la règle ' + index + ' n’est pas une paire [motif, action]');
    if (!Array.isArray(regle)) continue;
    verif(regle[0] instanceof RegExp,
      'la règle ' + index + ' n’utilise pas une expression rationnelle réelle : '
      + typeof regle[0]);
    if (regle[0] instanceof RegExp) nbExpressions += 1;
    const action = regle[1];
    if (typeof action === 'string') continue;
    if (action && typeof action === 'object' && action.cases) {
      for (const cle of Object.keys(action.cases)) {
        if (cle.startsWith('@') && cle !== '@default') attributsVus.add(cle);
      }
    }
    if (Array.isArray(action)) {
      for (const sous of action) {
        if (sous && typeof sous === 'object' && sous.cases) {
          for (const cle of Object.keys(sous.cases)) {
            if (cle.startsWith('@') && cle !== '@default') attributsVus.add(cle);
          }
        }
      }
    }
  }
  verif(nbExpressions >= 10,
    'seulement ' + nbExpressions + ' expressions rationnelles dans les règles');
  /* Un attribut @inexistant fait que Monaco ne classe plus rien, sans erreur.
     C'est le défaut silencieux par excellence d'un tokenizer écrit à la main. */
  const declares = new Set(Object.keys(module.language)
    .filter(cle => Array.isArray(module.language[cle])));
  for (const attribut of attributsVus) {
    const nom = attribut.slice(1);
    verif(nom === 'brackets' || declares.has(nom),
      'la règle renvoie à « ' + attribut + ' » qui n’est pas déclaré : Monaco ne '
      + 'classerait plus ces jetons, sans le signaler');
  }
  verif(attributsVus.size >= 2,
    'aucune règle ne classe par liste de mots : la coloration serait muette');

  /* Les familles régulières doivent couvrir ce qui n'est pas listé
     explicitement : sans elles, jz, setne, cmovae et vaddps ne seraient pas
     colorés, alors que l'analyseur les connaît. */
  const motifs = racine.map(r => Array.isArray(r) && r[0] instanceof RegExp
    ? r[0].source : '').join('\n');
  for (const famille of ['j(?:o|no|b', 'set(?:o|no|b', 'cmov(?:o|no|b',
    'ss|sd|ps|pd']) {
    verif(motifs.includes(famille),
      'la famille régulière « ' + famille + '… » est absente du tokenizer');
  }

  console.log('-- Cohérence avec assembleur.py (la raison d’être de l’engendrement)');
  const registresJs = new Set(module.language.registers);
  const registresPy = new Set(py.registres);
  const registresManquants = [...registresPy].filter(r => !registresJs.has(r));
  const registresEnTrop = [...registresJs].filter(r => !registresPy.has(r));
  verif(registresManquants.length === 0,
    registresManquants.length + ' registre(s) connu(s) de l’analyseur ne sont pas '
    + 'colorés : ' + registresManquants.slice(0, 8).join(', '));
  verif(registresEnTrop.length === 0,
    registresEnTrop.length + ' registre(s) colorés sont inconnus de l’analyseur : '
    + registresEnTrop.slice(0, 8).join(', '));

  const mnemoniquesPy = new Set(py.mnemoniques);
  const inconnus = module.language.keywords.filter(m => !mnemoniquesPy.has(m));
  verif(inconnus.length === 0,
    inconnus.length + ' mnémonique(s) coloré(s) sont inconnus de l’analyseur : '
    + inconnus.slice(0, 8).join(', '));
  /* Les formes engendrées par famille (jcc, setcc, cmovcc, SSE/AVX, chaînes,
     MMX) ne sont pas listées explicitement : on vérifie qu'elles sont bien
     couvertes par un motif, en testant chaque mnémonique de l'analyseur contre
     les expressions du tokenizer ou contre la liste explicite. */
  const expressions = racine.filter(r => Array.isArray(r) && r[0] instanceof RegExp)
    .map(r => r[0]);
  const nonCouverts = [];
  for (const mnemonique of py.mnemoniques) {
    if (registresJs.has(mnemonique)) continue;
    if (module.language.keywords.includes(mnemonique)) continue;
    if (expressions.some(e => e.test(mnemonique))) continue;
    nonCouverts.push(mnemonique);
  }
  verif(nonCouverts.length === 0,
    nonCouverts.length + ' mnémonique(s) de l’analyseur ne sont ni listés ni '
    + 'couverts par une famille régulière : ' + nonCouverts.slice(0, 10).join(', '));
  verif(py.marqueur === 'ps-4.0.0-assembleur',
    'le marqueur d’assembleur.py a changé : ' + py.marqueur);

  if (echecs.length) {
    for (const e of echecs) console.log('  ECHEC : ' + e);
    console.log('\nBanc du tokenizer assembleur : ' + pass + ' assertion(s) '
      + 'conformes, ' + echecs.length + ' échec(s).');
    process.exit(1);
  }
  console.log('\nBanc du tokenizer assembleur : ' + pass
    + ' assertions, toutes conformes.');
})().catch(erreur => {
  console.log('EXCEPTION : ' + (erreur && erreur.stack || erreur));
  process.exit(1);
});
