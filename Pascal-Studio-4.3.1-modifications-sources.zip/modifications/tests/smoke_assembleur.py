#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : l'assembleur x86-64 comme langage de l'éditeur (4.0.0).

Ce banc a une particularité qui le rend plus fort qu'un banc ordinaire : quand
binutils est installé, il CONTRE-VÉRIFIE l'analyseur avec le vrai assembleur
`as`. Pour chaque source, il compare « mon analyseur dit que c'est bon » et
« as accepte de l'assembler ». Un désaccord est un échec, dans un sens comme
dans l'autre :

  - l'analyseur accuse un code que `as` accepte  ->  faux positif, et c'est le
    défaut le plus grave qu'un analyseur puisse avoir, parce qu'il apprend à
    l'utilisateur à ne plus le lire ;
  - l'analyseur laisse passer un code que `as` refuse  ->  occasion manquée,
    moins grave mais à connaître.

Pendant le développement, cette contre-vérification a confirmé deux diagnostics
(`bad register name '%eaxx'` et `incorrect register '%rbx' used with 'l'
suffix`) et en a infirmé aucun.

Sont exercés, dans l'ordre :

  1. l'autonomie du module à l'import, et ses tables ;
  2. la reconnaissance de syntaxe, dans toutes ses branches ;
  3. l'analyse : sources valides sans AUCUN diagnostic, puis chaque classe de
     faute avec sa gravité exacte ;
  4. la contre-vérification par `as` quand il est installé ;
  5. la chaîne d'outils : commandes produites sans les exécuter, puis
     assemblage, édition de liens et EXÉCUTION réelles ;
  6. le branchement sur le reste de l'application : registre des langages, mode
     de débogage, analyse en continu, reconnaissance des extensions et
     construction par polyglot.
"""

import importlib.util
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
CIBLE = MODIFICATIONS / 'assembleur.py'

echecs = []
compte = [0]
ignores = []


def verif(condition, message):
    compte[0] += 1
    if not condition:
        echecs.append(message)


def charger(nom, chemin):
    spec = importlib.util.spec_from_file_location(nom, str(chemin))
    module = importlib.util.module_from_spec(spec)
    sys.modules[nom] = module
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------------------
# Sources de référence
# ---------------------------------------------------------------------------

BON_ATT = """.globl _start
.text
_start:
    mov $1, %eax
    mov $1, %edi
    lea msg(%rip), %rsi
    mov $14, %edx
    syscall
    mov $60, %eax
    xor %edi, %edi
    syscall
.data
msg:
    .ascii "Bonjour\\n"
"""

BON_NASM = """section .text
global _start
_start:
    mov rax, 1
    mov rdi, 1
    mov rsi, msg
    mov rdx, 8
    syscall
    mov rax, 60
    xor rdi, rdi
    syscall
section .data
msg db "Bonjour", 10
longueur equ 8
tampon resb 64
"""

BON_INTEL_GAS = """.intel_syntax noprefix
.globl _start
.text
_start:
    mov rax, 1
    mov rdi, 1
    syscall
"""

# Chaque cas : (nom, source, chemin, gravite attendue). La gravite attendue est
# 'aucune', 'error', 'warning' ou 'hint' — celle du diagnostic le plus grave.
CAS_FAUTES = [
    ('registre inexistant en AT&T', '.text\n_start:\n    mov $1, %eaxx\n',
     'x.s', 'error'),
    ('suffixe de taille contre largeur', '.text\n_start:\n    movl %rax, %rbx\n',
     'x.s', 'error'),
    ('arité impossible', '.text\n_start:\n    mov %rax, %rbx, %rcx\n',
     'x.s', 'error'),
    ('étiquette définie deux fois', '.text\n_a:\n    nop\n_a:\n    nop\n',
     'x.s', 'error'),
    ('syntaxe Intel dans un .s', '.text\n_start:\n    mov rax, 1\n    syscall\n',
     'x.s', 'error'),
    ('les deux syntaxes mêlées',
     '.text\n_start:\n    mov $1, %eax\n    mov rbx, 2\n', 'x.s', 'error'),
    # Avertissement et non erreur : « as » ACCEPTE ce fichier, parce qu'en AT&T
    # « # » ouvre un commentaire. La directive n'est pas refusée, elle est
    # ignorée — c'est la contre-vérification par le vrai assembleur qui l'a
    # établi, en infirmant le diagnostic d'abord écrit.
    ('préprocesseur C ignoré dans un .s',
     '#include <stdio.h>\n.text\n_start:\n    mov $1, %eax\n', 'x.s', 'warning'),
    ('directive GAS dans un source NASM',
     'section .text\nglobal _start\n_start:\n    .globl main\n    mov rax,1\n',
     'x.asm', 'warning'),
    ('saut vers un symbole inconnu', '.text\n_start:\n    jmp introuvable\n',
     'x.s', 'warning'),
    ('mnémonique hors de la table', '.text\n_start:\n    rdfsbase %rax\n',
     'x.s', 'hint'),
]

GRAVITES = ('error', 'warning', 'hint', 'info')


def plus_grave(diagnostics):
    for niveau in GRAVITES:
        if any(d['severity'] == niveau for d in diagnostics):
            return niveau
    return 'aucune'


def main():
    if not CIBLE.is_file():
        print('ECHEC : assembleur.py introuvable : %s' % CIBLE)
        return 1

    # ------------------------------------------------------------------ 1
    print('-- Autonomie et tables')
    with tempfile.TemporaryDirectory() as dossier:
        sonde = Path(dossier) / 'sonde.py'
        sonde.write_text('\n'.join([
            'import importlib.util, sys',
            'spec = importlib.util.spec_from_file_location("a", sys.argv[1])',
            'm = importlib.util.module_from_spec(spec)',
            'spec.loader.exec_module(m)',
            'interdits = [x for x in ("langages", "core", "polyglot",',
            '    "verificateurs_statiques", "starlette", "requests")',
            '    if x in sys.modules]',
            'print("INTERDITS:" + (",".join(interdits) if interdits else "aucun"))',
            'print("MARQUEUR:" + m.MARQUEUR)',
        ]), encoding='utf-8')
        processus = subprocess.run(
            [sys.executable, str(sonde), str(CIBLE)], capture_output=True,
            text=True, timeout=60)
        sortie = processus.stdout
        verif(processus.returncode == 0,
              'le module ne s’importe pas seul : %s' % processus.stderr[-300:])
        verif('INTERDITS:aucun' in sortie,
              'le module importe un voisin : %r' % sortie[:200])
        verif('MARQUEUR:ps-4.0.0-assembleur' in sortie,
              'marqueur de version absent ou faux')

    assembleur = charger('assembleur', CIBLE)
    capacites = assembleur.capacites()
    verif(capacites['marqueur'] == 'ps-4.0.0-assembleur', 'marqueur incohérent')
    verif(capacites['registres'] >= 150,
          'seulement %d registres dans la table' % capacites['registres'])
    verif(capacites['conditions'] == 25,
          '%d codes de condition au lieu des 25 distincts de x86'
          % capacites['conditions'])
    verif(capacites['mnemoniques'] >= 300,
          'seulement %d mnémoniques' % capacites['mnemoniques'])
    verif(capacites['directives_gas'] >= 50, 'trop peu de directives GAS')
    verif(capacites['directives_nasm'] >= 50, 'trop peu de directives NASM')
    for registre in ('rax', 'eax', 'ax', 'ah', 'al', 'r15d', 'xmm0', 'ymm31',
                     'rip', 'gs', 'cr3', 'st0'):
        verif(registre in assembleur.TOUS_REGISTRES,
              'registre %s absent de la table' % registre)
    verif('rip' in assembleur.TOUS_REGISTRES,
          '« rip » absent : « lea symbole(%%rip) » serait accusé à tort')
    for absent in ('eaxx', 'r16', 'xmm32', 'eax1'):
        verif(absent not in assembleur.TOUS_REGISTRES,
              '%s est à tort dans la table des registres' % absent)
    for mn in ('mov', 'syscall', 'jmp', 'jz', 'jnz', 'sete', 'cmovae', 'ret',
               'leave', 'addps', 'vaddpd'):
        verif(mn in assembleur.MNEMONIQUES, 'mnémonique %s absent' % mn)
    verif(assembleur.MNEMONIQUES['syscall'] == set(),
          '« syscall » devrait accepter zéro opérande')
    verif(assembleur.MNEMONIQUES['mov'] == {1, 2},
          '« mov » devrait accepter 1 ou 2 opérandes')
    verif(0 in assembleur.MNEMONIQUES['movsd'],
          '« movsd » a perdu l’arité zéro de sa forme « opération sur les '
          'chaînes » en étant écrasée par la forme SSE')
    verif(assembleur._base('movl') == ('mov', 'l'),
          '_base(« movl ») rend %r au lieu de (« mov », « l ») : le contrôle de '
          'largeur ne se déclencherait jamais' % (assembleur._base('movl'),))
    verif(assembleur._base('movsd') == ('movsd', ''),
          '_base(« movsd ») doit rendre le mnémonique entier, pas (« mov », « sd »)')
    verif(assembleur._base('rdfsbase') == ('rdfsbase', ''),
          '_base() découpe un mnémonique inconnu')

    # ------------------------------------------------------------------ 2
    print('-- Reconnaissance de syntaxe')
    cas_syntaxe = [
        ('AT&T complet', BON_ATT, 'bonjour.s', assembleur.ATT),
        ('AT&T sans extension', 'mov $1, %eax', '', assembleur.ATT),
        ('directive .intel_syntax', BON_INTEL_GAS, 'x.s', assembleur.INTEL),
        ('directive .att_syntax', '.att_syntax\nmov $1, %eax', 'x.s',
         assembleur.ATT),
        ('Intel sur .asm', BON_NASM, 'bonjour.asm', assembleur.INTEL),
        ('Intel dans un .s', '.text\n_start:\n    mov rax, 1\n', 'x.s',
         assembleur.INTEL),
        ('MASM', 'mov eax, DWORD PTR [ebx+4]', 'x.asm', assembleur.MASM),
        ('extension .asm seule', '', 'programme.asm', assembleur.INTEL),
        ('extension .s seule', '', 'programme.s', assembleur.ATT),
        ('extension .S seule', '', 'programme.S', assembleur.ATT),
        ('rien du tout', '', '', assembleur.INCONNUE),
    ]
    for nom, source, chemin, attendu in cas_syntaxe:
        obtenu = assembleur.detecter_syntaxe(source, chemin)
        verif(obtenu['syntaxe'] == attendu,
              '%s : syntaxe %r au lieu de %r (indices : %s)'
              % (nom, obtenu['syntaxe'], attendu, obtenu['indices']))
        verif(bool(obtenu['indices']), '%s : aucun indice expliqué' % nom)
        verif('marqueurs' in obtenu, '%s : les marqueurs ne sont pas exposés' % nom)

    verif(assembleur.assembleur_pour(assembleur.INTEL, '.asm')[0] == 'nasm',
          'Intel sur .asm devrait choisir nasm')
    verif(assembleur.assembleur_pour(assembleur.ATT, '.s')[0] == 'as',
          'AT&T sur .s devrait choisir as')
    verif(assembleur.assembleur_pour(assembleur.INTEL, '.s')[1],
          'Intel sur .s devrait avertir de l’absence de .intel_syntax')
    verif(assembleur.assembleur_pour(assembleur.INCONNUE, '')[0] == '',
          'une syntaxe inconnue ne doit pas choisir d’assembleur')

    # ------------------------------------------------------------------ 3
    print('-- Analyse des sources valides')
    for nom, source, chemin in (('AT&T', BON_ATT, 'bonjour.s'),
                                ('NASM', BON_NASM, 'bonjour.asm'),
                                ('Intel sous GAS', BON_INTEL_GAS, 'x.s')):
        resultat = assembleur.analyser(source, chemin)
        verif(resultat['state'] == 'ready', '%s : état %r' % (nom, resultat['state']))
        verif(resultat['ok'] is True,
              '%s valide signalé comme fautif : %s' % (nom, resultat['message']))
        verif(not resultat['diagnostics'],
              '%s valide produit %d diagnostic(s) : %s'
              % (nom, len(resultat['diagnostics']),
                 [d['message'][:70] for d in resultat['diagnostics']]))
        for cle in ('syntaxe', 'indices', 'etiquettes', 'externes'):
            verif(cle in resultat, '%s : la clef %r manque au résultat' % (nom, cle))
    verif('_start' in assembleur.analyser(BON_ATT, 'x.s')['etiquettes'],
          'l’étiquette _start n’est pas relevée en AT&T')
    # Les étiquettes NASM s'écrivent sans deux-points devant une directive de
    # données : « msg db ... », « longueur equ 8 », « tampon resb 64 ». Sans
    # cette reconnaissance, chaque ligne de données était lue comme une
    # instruction au mnémonique inconnu.
    verif(sorted(assembleur.analyser(BON_NASM, 'x.asm')['etiquettes'])
          == ['_start', 'longueur', 'msg', 'tampon'],
          'les étiquettes NASM sans deux-points ne sont pas toutes relevées : %r'
          % assembleur.analyser(BON_NASM, 'x.asm')['etiquettes'])

    print('-- Analyse des fautes')
    for nom, source, chemin, attendu in CAS_FAUTES:
        resultat = assembleur.analyser(source, chemin)
        obtenu = plus_grave(resultat['diagnostics'])
        verif(obtenu == attendu,
              '%s : gravité %r au lieu de %r — %s'
              % (nom, obtenu, attendu,
                 [d['message'][:70] for d in resultat['diagnostics']]))
        if attendu == 'error':
            verif(resultat['ok'] is False, '%s : ok reste vrai malgré une erreur' % nom)
        else:
            verif(resultat['ok'] is True,
                  '%s : une simple remarque ne doit pas mettre ok à faux' % nom)
        for diagnostic in resultat['diagnostics']:
            verif(diagnostic['line'] >= 1, '%s : ligne %r' % (nom, diagnostic['line']))
            verif(diagnostic['column'] >= 1,
                  '%s : colonne %r' % (nom, diagnostic['column']))
            verif(diagnostic['severity'] in GRAVITES,
                  '%s : gravité inconnue %r' % (nom, diagnostic['severity']))
            verif(bool(diagnostic['message'].strip()),
                  '%s : message vide' % nom)

    # Le garde-fou de taille, et un source vide qui ne doit rien casser.
    verif(assembleur.analyser('', 'x.s')['state'] == 'ready',
          'un source vide devrait être analysable sans erreur')
    verif(assembleur.analyser('mov $1, %eax\n' * 2, '')['state'] == 'ready',
          'un source sans chemin devrait être analysable')
    verif(assembleur.analyser('x' * (assembleur.LIMITE_TAILLE + 10),
                              'x.s')['state'] == 'unavailable',
          'le garde-fou de taille ne se déclenche pas')

    # ------------------------------------------------------------------ 4
    print('-- Contre-vérification par le vrai assembleur « as »')
    if not shutil.which('as'):
        ignores.append('« as » absent : la contre-vérification et la '
                       'construction réelle sont ignorées')
    else:
        desaccords = []
        epreuves = [('AT&T valide', BON_ATT, 'bonjour.s'),
                    ('Intel sous GAS', BON_INTEL_GAS, 'x.s'),
                    ('registre inexistant', CAS_FAUTES[0][1], 'x.s'),
                    ('suffixe contre largeur', CAS_FAUTES[1][1], 'x.s'),
                    ('arité impossible', CAS_FAUTES[2][1], 'x.s'),
                    ('étiquette en double', CAS_FAUTES[3][1], 'x.s'),
                    ('Intel dans un .s', CAS_FAUTES[4][1], 'x.s'),
                    ('préprocesseur C ignoré', CAS_FAUTES[6][1], 'x.s')]
        with tempfile.TemporaryDirectory() as dossier:
            for nom, source, nom_fichier in epreuves:
                chemin = Path(dossier) / nom_fichier
                chemin.write_text(source, encoding='utf-8')
                analyse = assembleur.analyser(source, nom_fichier)
                objet = Path(dossier) / 'sortie.o'
                objet.unlink(missing_ok=True)
                processus = subprocess.run(
                    ['as', '--64', str(chemin), '-o', str(objet)],
                    capture_output=True, text=True, timeout=60)
                accepte = processus.returncode == 0 and objet.is_file()
                if analyse['ok'] != accepte:
                    desaccords.append(
                        '%s : l’analyseur dit %s, « as » dit %s (%s)'
                        % (nom, 'valide' if analyse['ok'] else 'fautif',
                           'valide' if accepte else 'fautif',
                           (processus.stderr or '').strip().split('\n')[-1][:90]))
        verif(not desaccords,
              'désaccord(s) avec le vrai assembleur : ' + ' | '.join(desaccords))
        verif(len(epreuves) >= 8, 'trop peu d’épreuves de contre-vérification')

    # ------------------------------------------------------------------ 5
    print('-- Chaîne d’outils')
    outils = assembleur.outils_disponibles()
    for cle in ('presents', 'absents', 'assemblage', 'liens', 'debogage'):
        verif(cle in outils, 'outils_disponibles() sans la clef %r' % cle)
    for outil, commande in outils['absents'].items():
        if commande:
            verif(commande.startswith('sudo apt install')
                  or commande.startswith('voir ')
                  or commande.startswith('pip')
                  or commande.startswith('gem')
                  or commande.startswith('opam'),
                  'l’outil absent %r propose une installation douteuse : %r'
                  % (outil, commande))
    commande, raison = assembleur.commande_assemblage(
        assembleur.ATT, 'x.s', 'x.o', '.s')
    if commande:
        verif(commande[0] == 'as' and '--64' in commande,
              'la commande AT&T devrait être « as --64 » : %r' % commande)
        verif(raison == '', 'une raison est donnée alors que la commande existe')
    else:
        verif('sudo apt install' in raison,
              'l’absence d’assembleur devrait donner la commande d’installation')
    commande, raison = assembleur.commande_assemblage(
        assembleur.INTEL, 'x.asm', 'x.o', '.asm')
    if commande:
        verif(commande[0] == 'nasm' and 'elf64' in commande,
              'la commande NASM devrait cibler elf64 : %r' % commande)
    commande, raison = assembleur.commande_liens('x.o', 'x.out', '_start')
    if commande:
        verif(commande[0] == 'ld', 'un _start devrait passer par « ld » : %r' % commande)
        verif('-static' in commande,
              'l’édition de liens d’un _start devrait être statique par défaut')
    commande, raison = assembleur.commande_liens('x.o', 'x.out', 'main')
    if commande:
        verif(commande[0] == 'gcc', 'un main devrait passer par « gcc » : %r' % commande)

    with tempfile.TemporaryDirectory() as dossier:
        source = Path(dossier) / 'bonjour.s'
        source.write_text(BON_ATT, encoding='utf-8')
        verif(assembleur.entree_du(source) == '_start',
              'entree_du() devrait trouver _start')
        source2 = Path(dossier) / 'avec_main.s'
        source2.write_text(BON_ATT.replace('_start', 'main'), encoding='utf-8')
        verif(assembleur.entree_du(source2) == 'main',
              'entree_du() devrait trouver main')
        manque = Path(dossier) / 'absent.s'
        verif(assembleur.entree_du(manque) == '_start',
              'entree_du() sur un fichier absent devrait replier sur _start')

    if shutil.which('as') and shutil.which('ld'):
        with tempfile.TemporaryDirectory() as dossier:
            source = Path(dossier) / 'bonjour.s'
            source.write_text(BON_ATT, encoding='utf-8')
            construction = assembleur.construire(source, Path(dossier) / 'sortie')
            verif(construction['ok'] is True,
                  'la construction réelle a échoué : %s' % construction['output'][-300:])
            verif(construction['kind'] == 'asm', 'kind devrait valoir « asm »')
            verif(construction['binary'] and os.path.isfile(construction['binary']),
                  'aucun exécutable produit')
            verif(os.access(construction['binary'], os.X_OK),
                  'l’exécutable produit n’est pas exécutable')
            execution = assembleur.executer(source, Path(dossier) / 'sortie2')
            verif(execution['ok'] is True,
                  'l’exécution réelle a échoué : %s' % execution['output'][-300:])
            verif('Bonjour' in execution['output'],
                  'le programme assemblé n’a pas imprimé sa sortie : %r'
                  % execution['output'][-200:])
            verif(execution.get('code_retour') == 0,
                  'code de retour %r au lieu de 0' % execution.get('code_retour'))

            # Un source fautif doit échouer proprement, sans exception ni
            # exécutable fantôme.
            fautive = Path(dossier) / 'fautif.s'
            fautive.write_text(CAS_FAUTES[0][1], encoding='utf-8')
            echec = assembleur.construire(fautive, Path(dossier) / 'sortie3')
            verif(echec['ok'] is False, 'un source fautif devrait échouer')
            verif(echec['binary'] is None,
                  'un échec ne doit pas annoncer d’exécutable')
            verif(bool(echec['output'].strip()),
                  'un échec doit expliquer pourquoi')
            verif(assembleur.construire(Path(dossier) / 'absent.s',
                                        Path(dossier) / 's')['ok'] is False,
                  'un fichier absent devrait échouer sans exception')
    else:
        ignores.append('« as » ou « ld » absent : la construction réelle est ignorée')

    # ------------------------------------------------------------------ 5bis
    print('-- Extraits de complétion, rendus comme Monaco les rend')
    # Les extraits sont envoyés avec insertTextFormat 2 : ce sont des extraits
    # Monaco, où « $1 » est une tabulation et où un « $ » littéral s’écrit « \$ ».
    # En AT&T, chaque immédiat commence par « $ » : mal échappé, l’extrait
    # insérait « mov $, %eax » au lieu de « mov $1, %eax ». Six extraits sur
    # douze étaient faux de cette façon, et rien d’autre ne pouvait le montrer :
    # il faut RENDRE l’extrait, puis assembler le résultat.
    def rendre(texte):
        """Rend un extrait comme Monaco le rend, miroir des tabulations compris.

        `\\$` donne un « $ » littéral, `${n:défaut}` donne son défaut, et `$n`
        reprend le défaut de la tabulation n — sans ce dernier point, « loop $2 »
        rendait « loop » alors que Monaco reprend l'étiquette « boucle ».
        """
        defauts = {}
        for numero, corps in re.findall(r'\$\{(\d+)(?::([^{}]*))?\}', texte):
            defauts.setdefault(numero, corps or '')
        sortie = []
        i = 0
        while i < len(texte):
            c = texte[i]
            if c == '\\' and i + 1 < len(texte) and texte[i + 1] in '$}\\':
                sortie.append(texte[i + 1])
                i += 2
                continue
            if c == '$':
                if i + 1 < len(texte) and texte[i + 1] == '{':
                    profondeur, j = 0, i + 1
                    while j < len(texte):
                        if texte[j] == '{':
                            profondeur += 1
                        elif texte[j] == '}':
                            profondeur -= 1
                            if profondeur == 0:
                                break
                        j += 1
                    corps = texte[i + 2:j]
                    sortie.append(corps.split(':', 1)[1] if ':' in corps else '')
                    i = j + 1
                    continue
                nombre = re.match(r'\$(\d+)', texte[i:])
                if nombre:
                    sortie.append(defauts.get(nombre.group(1), ''))
                    i += nombre.end()
                    continue
                sortie.append('$')
                i += 1
                continue
            sortie.append(c)
            i += 1
        return ''.join(sortie)

    import bibliotheques_completion
    asm_bib = bibliotheques_completion.bibliotheque('asm')
    verif(len(asm_bib.extraits) >= 10,
          'seulement %d extraits pour l’assembleur' % len(asm_bib.extraits))
    verif(len(asm_bib.mots_clefs) >= 400,
          'seulement %d mots-clefs : les mnémoniques ne sont pas tous proposés'
          % len(asm_bib.mots_clefs))
    verif(len(asm_bib.types) >= 150,
          'seulement %d registres proposés en complétion' % len(asm_bib.types))
    verif('mov' in asm_bib.mots_clefs and 'syscall' in asm_bib.mots_clefs,
          'les mnémoniques de base ne sont pas dans les mots-clefs')
    verif('rax' in asm_bib.types and 'xmm0' in asm_bib.types,
          'les registres ne sont pas dans les types proposés')
    verif(len(asm_bib.motifs) >= 3,
          'trop peu de motifs d’extraction : les étiquettes du projet ne '
          'seraient pas proposées')
    # Les tables doivent venir d'assembleur.py, pas d'une copie : un second
    # tableau finirait par diverger et la complétion proposerait des mnémoniques
    # que l'analyseur ne connaît pas.
    verif(set(asm_bib.mots_clefs) >= set(assembleur.MNEMONIQUES),
          'des mnémoniques de l’analyseur manquent à la complétion')
    verif(set(asm_bib.types) == set(assembleur.TOUS_REGISTRES),
          'les registres proposés ne sont pas exactement ceux de l’analyseur')

    rendus = {}
    for extrait in asm_bib.extraits:
        rendu = rendre(extrait.insertion)
        rendus[extrait.libelle] = rendu
        # « ${ » et « $$ » ne doivent plus apparaître après le rendu. En
        # revanche « $1 » est ATTENDU : c'est un immédiat AT&T littéral, et
        # c'est précisément ce que la première version de cette assertion
        # refusait à tort — elle accusait le rendu correct.
        verif('${' not in rendu,
              'l’extrait « %s » garde un emplacement réservé non rendu : %r'
              % (extrait.libelle, rendu[:120]))
        verif('$$' not in rendu,
              'l’extrait « %s » garde un « $$ » : %r' % (extrait.libelle, rendu[:120]))
        verif(bool(extrait.detail.strip()),
              'l’extrait « %s » n’explique rien' % extrait.libelle)

    # Les immédiats AT&T doivent avoir survécu au rendu.
    verif('mov $1, %eax' in rendus['hello AT&T'],
          '« hello AT&T » n’a pas conservé l’immédiat : %r' % rendus['hello AT&T'][:120])
    verif('mov $60, %eax' in rendus['hello AT&T'],
          '« hello AT&T » n’a pas conservé le numéro d’appel système exit')
    verif('mov $1, %eax' in rendus['écrire sur stdout'],
          '« écrire sur stdout » n’a pas conservé l’immédiat')
    verif('mov $8, %edx' in rendus['écrire sur stdout'],
          '« écrire sur stdout » n’a pas conservé la longueur rendue')
    verif('mov $0, %edi' in rendus['quitter'],
          '« quitter » n’a pas conservé le code de retour rendu')
    verif('sub $32, %rsp' in rendus['prologue'],
          '« prologue » n’a pas conservé la taille de cadre rendue')
    verif('mov $10, %rcx' in rendus['boucle décomptée'],
          '« boucle décomptée » n’a pas conservé le compteur rendu')
    verif('loop boucle' in rendus['boucle décomptée'],
          '« boucle décomptée » n’a pas repris l’étiquette en cible de saut')
    verif('mov $1, %edi' in rendus['appel conforme à System V']
          and 'mov $6, %r9d' in rendus['appel conforme à System V'],
          '« appel conforme à System V » n’a pas conservé ses six immédiats')
    # Ce qui ne doit PAS porter de « $ » : les registres et les décalages.
    verif('cmp %rax, %rbx' in rendus['comparaison et saut'],
          '« comparaison et saut » a reçu un « $ » qui n’a pas lieu d’être')
    verif('mov -8(%rbp), %rax' in rendus['accès à une variable locale'],
          '« accès à une variable locale » devrait rester sans « $ »')
    verif('.intel_syntax noprefix' in rendus['entête Intel pour as'],
          'l’entête Intel n’est pas rendue intacte')

    # L'épreuve décisive : les deux programmes complets, une fois rendus, doivent
    # s'assembler pour de vrai.
    if shutil.which('as'):
        with tempfile.TemporaryDirectory() as dossier:
            chemin = Path(dossier) / 'extrait.s'
            chemin.write_text(rendus['hello AT&T'], encoding='utf-8')
            processus = subprocess.run(
                ['as', '--64', str(chemin), '-o', str(Path(dossier) / 'e.o')],
                capture_output=True, text=True, timeout=60)
            verif(processus.returncode == 0,
                  'l’extrait « hello AT&T » rendu ne s’assemble pas : %s'
                  % (processus.stderr or '').strip()[-220:])
    else:
        ignores.append('l’assemblage des extraits rendus est ignoré, faute de « as »')

    # ------------------------------------------------------------------ 6
    print('-- Branchement sur le reste de l’application')
    sys.path.insert(0, str(MODIFICATIONS))
    import langages
    import debogueur_universel
    import polyglot
    import verificateurs_statiques

    # 41 depuis la 4.3.0 : « piet_texte » est la SOURCE texte d'un programme
    # Piet (.piett), entrée distincte de « piet » (.png) — voir langages.py.
    verif(len(langages.tous()) == 41,
          'le registre compte %d langages au lieu de 41' % len(langages.tous()))
    verif('asm' in langages.tous(), '« asm » est absent du registre')
    entree = langages.langage('asm')
    verif(entree is not None, 'langages.langage("asm") rend None')
    verif(entree.libelle == 'Assembleur',
          'libellé %r au lieu de « Assembleur »' % entree.libelle)
    verif(tuple(entree.extensions) == ('.asm', '.s', '.S', '.nasm'),
          'extensions %r' % (entree.extensions,))
    verif(entree.debogueur == 'gdb', 'débogueur %r au lieu de gdb' % entree.debogueur)
    verif(entree.essai == 'compile',
          'essai %r au lieu de compile' % entree.essai)
    verif(entree.bibliotheque == 'asm',
          'clef de complétion %r au lieu de asm' % entree.bibliotheque)
    verif(entree.graphique is False, 'l’assembleur n’est pas un langage graphique')
    verif(entree.verificateur == ('verificateurs_statiques', 'analyze'),
          'l’analyse statique n’est pas branchée : %r' % (entree.verificateur,))
    verif(bool(entree.remarque.strip()),
          'la remarque devrait nommer les deux syntaxes et les outils à installer')
    for nom in ('asm', '.asm', '.s', '.S', '.nasm', 'Assembleur', 'assembly',
                'assembleur', 'x86_64', 'nasm', 'gas'):
        verif(langages.resoudre(nom) == 'asm',
              'resoudre(%r) ne rend pas « asm »' % nom)

    modes = debogueur_universel.tous_les_modes()
    verif(modes.get('asm') == 'reel',
          'le mode de débogage de l’assembleur est %r au lieu de « reel »'
          % modes.get('asm'))
    sans_debogage = sorted(i for i, v in modes.items()
                           if v == debogueur_universel.MODE_AUCUN)
    verif(sans_debogage == ['csproj', 'json', 'plaintext'],
          'langages sans débogage : %r au lieu de csproj, json, plaintext'
          % (sans_debogage,))
    debogables = sum(1 for v in modes.values()
                     if v != debogueur_universel.MODE_AUCUN)
    # Compte DÉRIVÉ du registre et non épinglé : il suivait 37 en 4.0.0 et
    # devrait être ressassé à chaque langage ajouté. La source texte Piet
    # (.piett, 4.3.0) le porte à 38 — son pas à pas passe par le moteur Piet
    # existant, donc elle est réellement débogable.
    verif(debogables == len(langages.tous()) - len(sans_debogage),
          '%d langages débogables au lieu de %d'
          % (debogables, len(langages.tous()) - len(sans_debogage)))

    for nom_fichier in ('programme.asm', 'startup.s', 'startup.S', 'boot.nasm'):
        verif(polyglot.kind(nom_fichier) == 'asm',
              'polyglot.kind(%r) rend %r au lieu de « asm »'
              % (nom_fichier, polyglot.kind(nom_fichier)))
    for nom_fichier, attendu in (('main.c', 'c'), ('x.cpp', 'cpp'),
                                 ('hello.bf', 'brainfuck'), ('x.pas', 'pascal'),
                                 ('x.py', 'python'), ('Makefile', 'make')):
        verif(polyglot.kind(nom_fichier) == attendu,
              'polyglot.kind(%r) a été déréglé : %r au lieu de %r'
              % (nom_fichier, polyglot.kind(nom_fichier), attendu))

    for cle in ('asm', '.asm', 'assembleur', 'Assembleur'):
        resultat = verificateurs_statiques.analyze(cle, 'x.s', 'x.s', BON_ATT)
        verif(resultat['state'] == 'ready',
              'analyze(%r) rend l’état %r' % (cle, resultat['state']))
        verif(resultat['ok'] is True, 'analyze(%r) refuse un source valide' % cle)
    resultat = verificateurs_statiques.analyze(
        'asm', 'x.s', 'x.s', CAS_FAUTES[0][1])
    verif(resultat['ok'] is False, 'analyze() laisse passer un registre inexistant')
    verif(len(resultat['diagnostics']) >= 1, 'aucun diagnostic rendu')
    for cle in ('file', 'line', 'column', 'endLine', 'endColumn', 'severity',
                'message'):
        verif(cle in resultat['diagnostics'][0],
              'le diagnostic rendu n’a pas la clef %r attendue par l’interface' % cle)
    verif('Assembleur' in resultat['message'],
          'le message ne nomme pas le langage : %r' % resultat['message'])

    # Les colonnes doivent être converties en UTF-16, comme partout ailleurs :
    # sur une ligne contenant un caractère non latin, une colonne brute décale
    # le soulignement dans Monaco.
    source_accent = '.text\n_é:\n    mov $1, %eaxx\n'
    resultat = verificateurs_statiques.analyze('asm', 'x.s', 'x.s', source_accent)
    verif(resultat['state'] == 'ready', 'un source accentué casse l’analyse')
    if resultat['diagnostics']:
        brut = assembleur.analyser(source_accent, 'x.s')['diagnostics'][0]['column']
        verif(resultat['diagnostics'][0]['column'] >= brut,
              'la colonne n’est pas convertie en UTF-16 : %r < %r'
              % (resultat['diagnostics'][0]['column'], brut))

    if shutil.which('as') and shutil.which('ld'):
        with tempfile.TemporaryDirectory() as dossier:
            source = Path(dossier) / 'bonjour.s'
            source.write_text(BON_ATT, encoding='utf-8')
            externes = {}
            construction = polyglot.build(dossier, str(Path(dossier) / 'sortie'),
                                          str(source), externes)
            verif(construction['kind'] == 'asm',
                  'polyglot.build() rend le kind %r' % construction['kind'])
            verif(construction['ok'] is True,
                  'polyglot.build() échoue sur un source valide : %s'
                  % construction['output'][-300:])
            verif(construction['binary'] and os.path.isfile(construction['binary']),
                  'polyglot.build() ne produit pas d’exécutable')
            verif(isinstance(construction['diagnostics'], list),
                  'les diagnostics de build() ne sont pas une liste')
            processus = subprocess.run([construction['binary']],
                                       capture_output=True, text=True, timeout=20)
            verif('Bonjour' in processus.stdout,
                  'le binaire construit par polyglot n’imprime rien : %r'
                  % processus.stdout)
    else:
        ignores.append('polyglot.build() sur l’assembleur ignoré, faute de « as »')

    # ------------------------------------------------------------------ fin
    if ignores:
        for motif in ignores:
            print('  ignoré : %s' % motif)
    if echecs:
        for echec in echecs:
            print('  ECHEC : %s' % echec)
        print('\nBanc de l’assembleur : %d assertions, %d échec(s).'
              % (compte[0], len(echecs)))
        return 1
    print('\nBanc de l’assembleur : %d assertions, toutes conformes.' % compte[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
