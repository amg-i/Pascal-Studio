/* Banc de la boucle de rendu des vues déléguées (4.3.1).
 *
 * POURQUOI CE BANC EXISTE
 *   La 4.3.0 a livré trois défauts que les bancs existants ne pouvaient pas
 *   voir, parce qu'ils jouaient `synchroniser()` un nombre fixé de fois et
 *   regardaient l'état résultant — jamais ce que le rappel coûtait à chaque
 *   passage :
 *
 *   D. UNE BOUCLE DE RENDU À 60 IMAGES PAR SECONDE. ps-hotes.js observe
 *      document.body avec { subtree:true, childList:true } et regroupe les
 *      rappels sur requestAnimationFrame. Son contrat est écrit dans son
 *      en-tête : « Chaque rappel reste idempotent et doit revenir immédiatement
 *      s'il n'y a rien à faire — c'est ce qui empêche la boucle (un rendu
 *      produit des mutations, qui réveillent l'observateur, qui rappelle le
 *      rendu…) ». Or `rendreColonnes()` commençait par `vider(conteneur)` puis
 *      RECRÉAIT chaque colonne et chaque séparateur à chaque passage, et
 *      `rendreOnglets()` faisait de même dans la barre d'onglets. Dès qu'une
 *      vue était ouverte, chaque passage produisait donc des mutations
 *      childList, qui réveillaient l'observateur, qui rappelait le rendu.
 *      Conséquences mesurées par l'utilisateur : le curseur change d'état en
 *      permanence (l'application reteste le survol soixante fois par seconde),
 *      le <webview> du navigateur est détaché puis rattaché à chaque image —
 *      Electron le détruit, donc le navigateur ne charge rien et ne répond plus
 *      — et un clic tombe sur un noeud qui vient d'être remplacé, ce qui fait
 *      qu'un second panneau ne s'ouvre pas et qu'un panneau fermé ne se
 *      rouvre pas.
 *
 *   B. LA ZONE SE MASQUAIT DÈS L'OUVERTURE. `synchroniser()` se terminait par
 *      « si mode plein, une vue active et un onglet de fichier actif :
 *      display:none ». Comme ouvrir() et activer() appellent synchroniser(), et
 *      que la barre garde presque toujours un onglet de fichier actif, ouvrir
 *      un panneau le masquait aussitôt — et cliquer sa vignette aussi. C'est
 *      « les panneaux dev web et rétro n'arrivent plus à se charger ».
 *      L'affichage doit suivre l'INTENTION de l'utilisateur : ouvrir, activer,
 *      scinder ou recoller une vue sont des demandes explicites ; aller sur un
 *      onglet de FICHIER rend la main à l'éditeur.
 *
 *   A. LE NOEUD DÉLÉGUÉ RESTAIT UNE FENÊTRE FLOTTANTE. `.psnav-panel` est
 *      `position:fixed; right:18px; bottom:18px; width:min(1180px,92vw);
 *      height:min(820px,88vh); z-index:8000`, et navigateur-studio.css est
 *      injectée APRÈS vues-studio.css : à spécificité égale, c'est elle qui
 *      gagne. Le noeud sortait du flux de la colonne, se plaçait par rapport à
 *      la fenêtre et couvrait l'application — sa barre de titre (cursor:grab)
 *      et ses cinq poignées (ew/ns/nwse-resize) promenaient le curseur partout,
 *      et la colonne restait vide.
 *
 *   C. LES POIGNÉES DE LA FENÊTRE RESTAIENT ARMÉES. Leurs gestionnaires
 *      pointerdown écrivaient left/top/width/height EN LIGNE sur un noeud dont
 *      la colonne possède la géométrie.
 *
 * CE QUE CE BANC MESURE
 *   Pour D, il ne compte pas les mutations du harnais (son `replaceChildren()`
 *   appelle `notifier()` même sur un conteneur déjà vide, ce qui surestimerait
 *   l'écriture) : il compte les CRÉATIONS D'ÉLÉMENTS par passage et l'IDENTITÉ
 *   des noeuds rendus. Un rappel qui recrée ses éléments à chaque passage est
 *   un rappel qui produit des mutations childList dans un vrai navigateur, donc
 *   une boucle. Un rappel idempotent ne crée rien et ne déplace rien.
 *
 * Lancer :  node tests/smoke_boucle_vues.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const MODS = path.join(ICI, '..');
let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 300)
    + '\n      attendu : ' + serie(attendu).slice(0, 300));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* ------------------------------------------------------------ l'application -- */

/* La structure réelle du bundle : nav.activitybar + aside.sidebar +
 * main.studio-main, et dans studio-main une div.tabbar qui contient les
 * onglets de fichier, l'hôte des vignettes et le remplissage. */
function construireApplication(opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const document = harnais.document;

  const activite = document.createElement('nav');
  activite.className = 'activitybar';

  const laterale = document.createElement('aside');
  laterale.className = 'sidebar';

  const principal = document.createElement('main');
  principal.className = 'studio-main';

  const barre = document.createElement('div');
  barre.className = 'tabbar';
  barre.style.height = '36px';
  const ongletFichier = document.createElement('div');
  /* Le bundle marque l'onglet courant par la classe `active`. */
  ongletFichier.className = 'tab' + (opts.ongletFichierActif === false ? '' : ' active');
  ongletFichier.setAttribute('title', 'main.pas');
  ongletFichier.textContent = 'main.pas';
  const secondFichier = document.createElement('div');
  secondFichier.className = 'tab';
  secondFichier.setAttribute('title', 'autre.pas');
  secondFichier.textContent = 'autre.pas';
  const hoteOnglets = document.createElement('div');
  hoteOnglets.className = 'ps-onglets-host';
  const remplissage = document.createElement('div');
  remplissage.className = 'tabbar-fill';
  barre.append(ongletFichier, secondFichier, hoteOnglets, remplissage);

  const ariane = document.createElement('div');
  ariane.className = 'breadcrumb';
  ariane.style.height = '22px';

  const editeur = document.createElement('div');
  editeur.className = 'editor-and-details';

  principal.append(barre, ariane, editeur);
  document.body.append(activite, laterale, principal);
  harnais.rafraichir();
  return { harnais, document, activite, laterale, principal, barre, ariane,
    hoteOnglets, ongletFichier, secondFichier, editeur };
}

/* Un panneau de navigateur réduit à ce qui compte ici : un noeud racine portant
 * la classe de la fenêtre flottante, une barre de titre, une poignée de
 * redimensionnement et un <webview>. */
function fauxPanneau(document, classe) {
  const panneau = document.createElement('div');
  panneau.className = classe;
  const titre = document.createElement('div');
  titre.className = 'psnav-titlebar';
  const poignee = document.createElement('div');
  poignee.className = 'psnav-resize psnav-r-e';
  const wv = document.createElement('webview');
  wv.className = 'psnav-vue';
  panneau.append(titre, poignee, wv);
  return { panneau, titre, poignee, wv };
}

function charger(app) {
  const document = app.document;
  const compte = { creations: 0 };
  const rafFile = [];
  const createElementOriginal = document.createElement.bind(document);
  document.createElement = function (tag) {
    compte.creations += 1;
    return createElementOriginal(tag);
  };

  const sandbox = {
    document: document,
    console: { error: function () {}, log: function () {}, warn: function () {} },
    setTimeout: function (fn) { return 0; },
    clearTimeout: function () {},
    setInterval: function () { return 0; },
    clearInterval: function () {},
    MutationObserver: H.MutationObserverStub,
    /* Les images sont jouées À LA MAIN : c'est le seul moyen de compter ce que
     * chaque passage coûte, au lieu de laisser le harnais les exécuter en
     * cascade. */
    requestAnimationFrame: function (fn) { rafFile.push(fn); return rafFile.length; },
    Date: Date, JSON: JSON, Math: Math, Object: Object, Array: Array,
    String: String, Number: Number, Boolean: Boolean, Promise: Promise,
    parseInt: parseInt, parseFloat: parseFloat, isFinite: isFinite,
    TypeError: TypeError, Error: Error,
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  const ecouteursFenetre = [];
  sandbox.window.addEventListener = function (type, fn) {
    ecouteursFenetre.push({ type: type, fn: fn });
  };
  vm.createContext(sandbox);

  /* ps-hotes.js d'abord : c'est lui qui possède l'observateur, et c'est son
   * contrat d'idempotence que ce banc fait respecter. */
  vm.runInContext(fs.readFileSync(path.join(MODS, 'ps-hotes.js'), 'utf8'),
    sandbox, { filename: 'ps-hotes.js' });
  vm.runInContext(fs.readFileSync(path.join(MODS, 'vues-studio.js'), 'utf8'),
    sandbox, { filename: 'vues-studio.js' });

  function jouerImages() {
    const file = rafFile.splice(0, rafFile.length);
    file.forEach(function (fn) { fn(Date.now()); });
    return file.length;
  }
  /* Un passage complet : l'observateur livre ses mutations, puis les rappels
   * regroupés jouent sur l'image suivante — exactement ce que fait un
   * navigateur. */
  function passage() {
    H.declencherObservateurs();
    const joues = jouerImages();
    app.harnais.rafraichir();
    return joues;
  }
  return { sandbox, Vues: sandbox.PSVues, PSHotes: sandbox.PSHotes, compte,
    passage, jouerImages, ecouteursFenetre };
}

function identiteColonne(zone) {
  if (!zone || !zone.children) return null;
  for (let i = 0; i < zone.children.length; i += 1) {
    const c = zone.children[i];
    if (c.className && String(c.className).indexOf('ps-vues-colonne') >= 0) return c;
  }
  return null;
}

function zoneDe(document) { return document.querySelector('.ps-vues-zone'); }

/* ------------------------------------------------------------------ D. boucle -- */

function serieBoucle() {
  const app = construireApplication({});
  const banc = charger(app);
  const { Vues, compte, passage } = banc;

  vrai('PSHotes est chargé avant les vues', !!banc.PSHotes);
  vrai('PSVues est publié', !!Vues && typeof Vues.ouvrir === 'function');

  const faux = fauxPanneau(app.document, 'psnav-panel');
  Vues.ouvrir({ id: 'navigateur', titre: 'Navigateur', icone: '⌾',
    noeud: faux.panneau });

  /* L'ouverture elle-même crée les éléments : c'est normal. Ce qui est interdit,
   * c'est d'en recréer à chaque passage alors que rien n'a changé. */
  const apresOuverture = compte.creations;
  vrai('ouvrir() a rendu une colonne', !!identiteColonne(zoneDe(app.document)));

  const premiere = identiteColonne(zoneDe(app.document));
  const parentPremier = faux.panneau.parentNode;
  const couts = [];
  for (let i = 0; i < 25; i += 1) {
    passage();
    const avant = compte.creations;
    passage();
    couts.push(compte.creations - avant);
  }

  verifier('25 passages à état inchangé ne créent AUCUN élément '
    + '(rappel idempotent : sans cela, chaque passage produit des mutations '
    + 'childList qui réveillent ps-hotes et la boucle tourne à 60 images/s)',
    couts.reduce(function (s, v) { return s + v; }, 0), 0);
  vrai('la colonne rendue est le MÊME noeud après 50 passages '
    + '(un <webview> déplacé dans le DOM est rechargé par Electron)',
    identiteColonne(zoneDe(app.document)) === premiere);
  vrai('le noeud du panneau n’a pas changé de parent',
    faux.panneau.parentNode === parentPremier);
  vrai('le <webview> reste attaché au panneau',
    faux.wv.parentNode === faux.panneau);
  verifier('ps-hotes joue UN seul observateur pour les deux hôtes suivis',
    banc.PSHotes.statistiques().observateurs, 1);

  /* Le glisser du séparateur rappelle rendreColonnes() à chaque pointermove :
   * là non plus il ne faut pas recréer le noeud du panneau. */
  const deuxieme = fauxPanneau(app.document, 'psdw-panneau');
  Vues.ouvrir({ id: 'devweb', titre: 'Dev Web', icone: '◇', noeud: deuxieme.panneau });
  verifier('deux panneaux ouverts font deux colonnes', Vues.colonnes().length, 2);
  const separateurs = zoneDe(app.document).querySelectorAll('.ps-vues-sep');
  verifier('un séparateur entre les deux colonnes', separateurs.length, 1);
  const parentAvantGlisser = faux.panneau.parentNode;
  const avantGlisser = compte.creations;
  separateurs[0].dispatchEvent({ type: 'pointerdown', clientX: 400, clientY: 10,
    target: separateurs[0], currentTarget: separateurs[0],
    preventDefault: function () {}, stopPropagation: function () {} });
  const liste = (app.document._ev && app.document._ev.pointermove) || [];
  for (let i = 0; i < 8; i += 1) {
    liste.slice().forEach(function (fn) {
      fn({ clientX: 400 + i, clientY: 10, preventDefault: function () {} });
    });
  }
  vrai('glisser le séparateur ne déplace pas le noeud du panneau',
    faux.panneau.parentNode === parentAvantGlisser);
  vrai('glisser le séparateur recrée peu d’éléments (au plus les entetes)',
    compte.creations - avantGlisser < 40);
  const fin = (app.document._ev && app.document._ev.pointerup) || [];
  fin.slice().forEach(function (fn) { fn({ clientX: 408, clientY: 10 }); });
  verifier('après le glisser, la classe de glisser est retirée',
    String(zoneDe(app.document).className).indexOf('ps-vues-glisse'), -1);

  /* Refermer une colonne puis la rouvrir : c'est le défaut « une fois fermé, on
   * ne peut plus le rouvrir ». */
  Vues.fermerColonne('devweb');
  verifier('refermer une colonne laisse la vue en vignette',
    Vues.vues().filter(function (v) { return v.id === 'devweb'; })[0].affichée, false);
  vrai('la vignette de la vue masquée est dans la barre',
    app.hoteOnglets.querySelectorAll('.ps-vue-onglet').length >= 1);
  Vues.activer('devweb');
  verifier('rouvrir la vue masquée refait une colonne', Vues.colonnes().length, 2);
  passage();
  vrai('la vue rouverte est rendue dans une colonne',
    !!deuxieme.panneau.parentNode
    && String(deuxieme.panneau.parentNode.className).indexOf('ps-vues-corps') >= 0);
}

/* ---------------------------------------------------- B. affichage sur intention -- */

function serieIntention() {
  const app = construireApplication({});
  const banc = charger(app);
  const { Vues, passage } = banc;
  const faux = fauxPanneau(app.document, 'psnav-panel');

  vrai('un onglet de fichier est actif avant toute ouverture',
    String(app.ongletFichier.className).indexOf('active') >= 0);

  Vues.ouvrir({ id: 'navigateur', titre: 'Navigateur', icone: '⌾',
    noeud: faux.panneau });
  passage();
  verifier('ouvrir un panneau pendant qu’un fichier est ouvert AFFICHE la zone '
    + '(4.3.0 : elle se masquait aussitôt, donc le panneau ne chargeait jamais)',
    zoneDe(app.document).style.display, 'block');

  /* Aller sur un onglet de FICHIER rend la main à l'éditeur. Le harnais ne fait
   * pas remonter les événements : un écouteur délégué se joue sur SON noeud,
   * avec la vraie cible dans `target` — comme le fait un navigateur. */
  app.barre.dispatchEvent({ type: 'click', target: app.ongletFichier,
    preventDefault: function () {}, stopPropagation: function () {} });
  passage();
  verifier('cliquer un onglet de fichier masque la zone',
    zoneDe(app.document).style.display, 'none');
  vrai('la vue n’est pas détruite : son noeud reste attaché',
    !!faux.panneau.parentNode);

  /* Cliquer la vignette doit la ramener, même si l'onglet de fichier est
   * toujours actif — sinon le panneau est perdu jusqu'au redémarrage. */
  const vignette = app.hoteOnglets.querySelectorAll('.ps-vue-onglet')[0];
  vrai('la vignette existe dans la barre d’onglets', !!vignette);
  app.hoteOnglets.dispatchEvent({ type: 'click', target: vignette,
    preventDefault: function () {}, stopPropagation: function () {} });
  passage();
  verifier('cliquer la vignette réaffiche la zone',
    zoneDe(app.document).style.display, 'block');

  /* Un second panneau pendant que le premier est ouvert : c'est le défaut
   * « quand un panneau est ouvert, l'autre ne peut plus s'ouvrir ». */
  const deuxieme = fauxPanneau(app.document, 'psdw-panneau');
  Vues.ouvrir({ id: 'devweb', titre: 'Dev Web', icone: '◇', noeud: deuxieme.panneau });
  passage();
  verifier('ouvrir un second panneau donne deux colonnes', Vues.colonnes().length, 2);
  verifier('la zone reste affichée avec deux panneaux',
    zoneDe(app.document).style.display, 'block');
  vrai('le second panneau est rendu dans sa colonne',
    !!deuxieme.panneau.parentNode
    && String(deuxieme.panneau.parentNode.className).indexOf('ps-vues-corps') >= 0);

  /* Passer sur un AUTRE fichier masque la zone, même sans clic sur la barre
   * (navigation au clavier, ouverture depuis l'explorateur). */
  app.ongletFichier.className = 'tab';
  app.secondFichier.className = 'tab active';
  passage();
  verifier('un autre onglet de fichier devenu actif masque la zone',
    zoneDe(app.document).style.display, 'none');

  /* Un passage de plus ne doit rien changer : l'état est stable. */
  const avant = zoneDe(app.document).style.display;
  passage();
  verifier('l’état d’affichage est stable d’un passage à l’autre',
    zoneDe(app.document).style.display, avant);
}

/* ------------------------------------------------- A. géométrie rendue à la zone -- */

function serieGeometrie() {
  const feuilles = fs.readFileSync(path.join(MODS, 'vues-studio.css'), 'utf8');
  const navCss = fs.readFileSync(path.join(MODS, 'navigateur-studio.css'), 'utf8');

  vrai('la fenêtre flottante du navigateur est bien position:fixed '
    + '(c’est ce que la délégation doit neutraliser)',
    /\.psnav-panel\{[^}]*position:fixed/.test(navCss));
  vrai('la feuille des vues rend la géométrie du noeud délégué à la zone',
    /\.ps-vues-corps>\*\{[^}]*position:relative\s*!important/.test(feuilles));
  vrai('l’ancrage à la fenêtre est neutralisé',
    /\.ps-vues-corps>\*\{[^}]*left:auto\s*!important/.test(feuilles)
    && /\.ps-vues-corps>\*\{[^}]*bottom:auto\s*!important/.test(feuilles));
  vrai('la taille fixe de la fenêtre flottante est neutralisée',
    /\.ps-vues-corps>\*\{[^}]*width:100%\s*!important/.test(feuilles)
    && /\.ps-vues-corps>\*\{[^}]*height:100%\s*!important/.test(feuilles));
  vrai('le z-index 8000 de la fenêtre ne passe pas au-dessus de la colonne',
    /\.ps-vues-corps>\*\{[^}]*z-index:auto\s*!important/.test(feuilles));
  vrai('les poignées de redimensionnement sont retirées dans une colonne',
    /\.ps-vues-corps \.psnav-resize[^{]*\{display:none\s*!important\}/.test(feuilles));
  vrai('les poignées du panneau dev web sont retirées dans une colonne',
    /\.ps-vues-corps \.psdw-poignee[^{]*\{display:none\s*!important\}/.test(feuilles)
    || /\.ps-vues-corps \.psnav-resize,\.ps-vues-corps \.psdw-poignee,\s*\.ps-vues-corps \.ps-re-redim\{display:none\s*!important\}/.test(feuilles));
  vrai('la poignée de la fenêtre rétro est retirée dans une colonne',
    /ps-re-redim\{display:none\s*!important\}/.test(feuilles));
  vrai('le curseur « main fermée » des barres de titre est rendu au curseur '
    + 'courant dans une colonne (c’est lui qui promenait le curseur partout)',
    /\.ps-vues-corps \.psnav-titlebar[^{]*\{cursor:default\s*!important/.test(feuilles));
  vrai('le :active des barres de titre ne reprend pas le curseur grabbing',
    /psnav-titlebar:active[^{]*\{cursor:default\s*!important/.test(feuilles));
  vrai('les boutons gardent leur propre curseur : la règle ne vise que les '
    + 'barres, pas leurs enfants',
    !/\.ps-vues-corps \*[^{]*\{[^}]*cursor/.test(feuilles));
}

/* --------------------------------------------- C. poignées désarmées en colonne -- */

function serieGardes() {
  const cibles = [
    ['navigateur-studio.js', 'psnav-titlebar', 'psnav-resize'],
    ['devweb-studio.js', 'psdw-barre', 'psdw-poignee'],
    ['re-studio.js', 'ps-re-fenetre-barre', 'ps-re-redim'],
  ];
  cibles.forEach(function (cible) {
    const source = fs.readFileSync(path.join(MODS, cible[0]), 'utf8');
    vrai(cible[0] + ' définit la garde « dans une colonne »',
      /function dansUneColonne\(noeud\)/.test(source));
    vrai(cible[0] + ' : la garde regarde le parent .ps-vues-corps',
      /dansUneColonne[\s\S]{0,220}ps-vues-corps/.test(source));
    /* Chaque gestionnaire pointerdown qui écrit la géométrie en ligne doit être
     * gardé. On compte les gardes et les écritures : une écriture sans garde
     * est une fenêtre qui arrache son noeud à la colonne. */
    const gardes = (source.match(/if \(dansUneColonne\(/g) || []).length;
    const ecritures = (source.match(/\.style\.(left|top|width|height) =/g) || []).length;
    vrai(cible[0] + ' : au moins deux gestionnaires gardés (déplacer et '
      + 'redimensionner), écritures en ligne = ' + ecritures, gardes >= 2);
  });
}

/* ------------------------------------------------------------------------ main -- */

function main() {
  H.reinitialiserObservateurs();
  serieBoucle();
  H.reinitialiserObservateurs();
  serieIntention();
  H.reinitialiserObservateurs();
  serieGeometrie();
  serieGardes();

  const total = N;
  if (echecs.length) {
    console.log('ECHEC smoke_boucle_vues : %d contrôle(s) en échec sur %d',
      echecs.length, total);
    echecs.forEach(function (e) { console.log('   - ' + e); });
    return 1;
  }
  console.log('smoke_boucle_vues : %d contrôles, aucun échec', total);
  return 0;
}

process.exit(main());
