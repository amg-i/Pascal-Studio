/* Banc de test du catalogue d'aide assemblé, sans navigateur.
 *
 * Ce banc vérifie une chose que rien d'autre ne voit : l'ORDRE de chargement des
 * fichiers d'aide dans index.html. Le bundle construit sa base au moment de son
 * évaluation —
 *
 *   A_={languages:[...internes,...(window.PS_DB_HELP?.languages||[]),
 *                  ...(window.PS_LANG_HELP?.languages||[]),
 *                  ...(window.PS_LATEX_HELP?.languages||[])],
 *       articles:[...internes,...(window.PS_DB_HELP?.articles||[]),
 *                 ...(window.PS_LANG_HELP?.articles||[]),
 *                 ...(window.PS_EXTRA_HELP?.articles||[]),
 *                 ...(window.PS_LATEX_HELP?.articles||[])]}
 *
 * Un catalogue chargé en « defer » s'exécuterait APRÈS le module, donc après
 * cette construction : ses fiches n'existeraient pas pour le panneau d'aide, et
 * rien ne le signalerait — le panneau s'afficherait simplement sans les dix
 * langages. C'est exactement ce que ce banc refuse.
 *
 * Il rejoue ensuite l'assemblage dans l'ordre réel d'index.html et contrôle le
 * résultat : les dix langages présents, leurs fiches, l'unicité des
 * identifiants, et l'absence de doublon dans la liste des langages (trois
 * fichiers ajoutent leurs fiches à window.PS_LANG_HELP, un quatrième l'assigne).
 *
 * Lancer :  node tests/smoke_catalogue_aide.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let OK = 0;
let N = 0;
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  console.log('  ' + titre.padEnd(60) + (bon ? 'CONFORME' : 'DIFFERENT'));
  if (!bon) {
    console.log('      obtenu  : ' + JSON.stringify(obtenu).slice(0, 200));
    console.log('      attendu : ' + JSON.stringify(attendu).slice(0, 200));
  }
}

/* Libellés du registre (langages.py). Le banc Python test_verificateurs_statiques
 * et smoke_facade.py vérifient le registre lui-même ; les recopier ici est
 * volontaire : si un libellé change, l'aide et ce banc doivent tomber ensemble. */
const LIBELLES_ESOTERIQUES = ['Brainfuck', 'Whitespace', 'Piet', 'LOLCODE',
  'ArnoldC', 'Chef', 'Shakespeare', 'INTERCAL', 'FRACTRAN', 'Malbolge'];

const RACINE = path.join(__dirname, '..', '..');
const INTERFACE = path.join(RACINE, 'interface-compilee');
const INDEX = path.join(INTERFACE, 'index.html');
const ASSETS = path.join(INTERFACE, 'assets');

if (!fs.existsSync(INDEX)) {
  console.log('interface-compilee/index.html introuvable : banc ignoré.');
  process.exit(0);
}

const html = fs.readFileSync(INDEX, 'utf8');

/* ------------------------------------------------- ordre de chargement ----- */
console.log('=== ordre de chargement dans index.html ===');
const scripts = [];
const motif = /<script([^>]*)src="\/assets\/([^"]+)"/g;
let m;
while ((m = motif.exec(html)) !== null) {
  scripts.push({ attrs: m[1], src: m[2], position: m.index });
}
const parNom = {};
for (const s of scripts) parNom[s.src] = s;

verifier('aide-esoteriques.js est chargé', !!parNom['aide-esoteriques.js'], true);
verifier('aide-esoteriques.js n’est PAS en defer (sinon trop tard)',
         /\bdefer\b/.test((parNom['aide-esoteriques.js'] || {}).attrs || ''), false);
verifier('aide-esoteriques.js n’est PAS un module',
         /\bmodule\b/.test((parNom['aide-esoteriques.js'] || {}).attrs || ''), false);

/* Le catalogue de l'assembleur (4.0.0) est soumis exactement aux mêmes
 * contraintes : script classique, avant le bundle. Un « defer » le ferait
 * s'exécuter après, et l'assembleur n'aurait alors aucune aide, sans qu'aucune
 * erreur n'apparaisse nulle part — le panneau afficherait simplement un langage
 * de moins. */
verifier('aide-assembleur.js est chargé', !!parNom['aide-assembleur.js'], true);
verifier('aide-assembleur.js n’est PAS en defer (sinon trop tard)',
         /\bdefer\b/.test((parNom['aide-assembleur.js'] || {}).attrs || ''), false);
verifier('aide-assembleur.js n’est PAS un module',
         /\bmodule\b/.test((parNom['aide-assembleur.js'] || {}).attrs || ''), false);

const bundle = scripts.find(s => /^index-.*\.js$/.test(s.src));
verifier('le bundle est présent', !!bundle, true);
verifier('le catalogue ésotérique est chargé AVANT le bundle',
         parNom['aide-esoteriques.js'].position < bundle.position, true);
verifier('le catalogue de l’assembleur est chargé AVANT le bundle',
         parNom['aide-assembleur.js'].position < bundle.position, true);
verifier('le catalogue de l’assembleur vient APRÈS celui des ésotériques',
         parNom['aide-esoteriques.js'].position < parNom['aide-assembleur.js'].position,
         true);

/* Tous les autres catalogues d'aide doivent rester avant le bundle : ce banc
 * existe pour que cette propriété ne se perde pas au prochain ajout. */
const CATALOGUES = ['database-help.js', 'nouveaux-langages-aide.js',
  'aide-complementaire.js', 'aide-cinq-langages.js', 'aide-swift-kotlin.js',
  'aide-latex.js', 'aide-esoteriques.js', 'aide-assembleur.js'];
for (const c of CATALOGUES) {
  verifier(c + ' avant le bundle', parNom[c] && parNom[c].position < bundle.position, true);
}
/* Les décorateurs, eux, doivent venir APRÈS : ils agissent sur le DOM monté. */
for (const d of ['aide-exemples.js', 'aide-index.js', 'nouveau-fichier.js']) {
  verifier(d + ' en defer après le bundle',
           parNom[d] && /\bdefer\b/.test(parNom[d].attrs)
             && parNom[d].position > bundle.position, true);
}
const styles = fs.readFileSync(INDEX, 'utf8');
verifier('aide-index.css est lié', /href="\/assets\/aide-index\.css"/.test(styles), true);
verifier('aide-exemples.css est toujours lié',
         /href="\/assets\/aide-exemples\.css"/.test(styles), true);

/* ------------------------------------------------------- assemblage réel --- */
console.log();
console.log('=== assemblage de la base d’aide, dans l’ordre réel ===');
const sandbox = { console };
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);

const charges = [];
for (const s of scripts) {
  if (!CATALOGUES.includes(s.src)) continue;
  const fichier = path.join(ASSETS, s.src);
  if (!fs.existsSync(fichier)) { charges.push(s.src + ' (ABSENT)'); continue; }
  try {
    new vm.Script(fs.readFileSync(fichier, 'utf8'), { filename: s.src })
      .runInContext(sandbox);
    charges.push(s.src);
  } catch (e) {
    charges.push(s.src + ' (ERREUR : ' + e.message + ')');
  }
}
verifier('les huit catalogues s’exécutent sans erreur', charges, CATALOGUES);

/* Ce que fait le bundle, à ceci près que ses fiches internes (Pascal, C, C++)
 * ne sont pas énumérables depuis un script hôte : les comptes ci-dessous sont
 * donc des planchers, pas des totaux. */
const win = sandbox.window;
const langues = [].concat(
  (win.PS_DB_HELP && win.PS_DB_HELP.languages) || [],
  (win.PS_LANG_HELP && win.PS_LANG_HELP.languages) || [],
  (win.PS_LATEX_HELP && win.PS_LATEX_HELP.languages) || []);
const fiches = [].concat(
  (win.PS_DB_HELP && win.PS_DB_HELP.articles) || [],
  (win.PS_LANG_HELP && win.PS_LANG_HELP.articles) || [],
  (win.PS_EXTRA_HELP && win.PS_EXTRA_HELP.articles) || [],
  (win.PS_LATEX_HELP && win.PS_LATEX_HELP.articles) || []);

console.log('  langages publiés : ' + langues.length
            + ' · fiches publiées : ' + fiches.length);

const manquants = LIBELLES_ESOTERIQUES.filter(l => langues.indexOf(l) < 0);
verifier('les dix langages ésotériques sont publiés', manquants, []);

const doublons = langues.filter((l, i) => langues.indexOf(l) !== i);
verifier('aucun langage n’est publié deux fois', doublons, []);

const ids = fiches.map(f => f.id);
const idsDoubles = ids.filter((x, i) => ids.indexOf(x) !== i);
verifier('les identifiants de fiches sont uniques', idsDoubles, []);

const incompletes = fiches.filter(f => !f || !f.lang || !f.group || !f.title
  || typeof f.summary !== 'string' || !Array.isArray(f.blocks));
verifier('toutes les fiches ont lang, group, title, summary et blocks',
         incompletes.map(f => f && f.id), []);

console.log();
console.log('=== les dix langages dans le catalogue ===');
const parLangue = {};
for (const f of fiches) parLangue[f.lang] = (parLangue[f.lang] || 0) + 1;
for (const l of LIBELLES_ESOTERIQUES) {
  const n = parLangue[l] || 0;
  verifier(l.padEnd(12) + ' a au moins 10 fiches', n >= 10, true);
  console.log('      ' + l.padEnd(12) + ' : ' + n + ' fiches');
}
const totalEso = LIBELLES_ESOTERIQUES.reduce((s, l) => s + (parLangue[l] || 0), 0);
verifier('les dix langages totalisent au moins 145 fiches', totalEso >= 145, true);
console.log('      total ésotérique : ' + totalEso + ' fiches');

/* Les fiches ésotériques portent des identifiants préfixés : c'est ce qui permet
 * de les retrouver sans ambiguïté dans un catalogue partagé. */
const eso = fiches.filter(f => /^eso-/.test(String(f.id)));
verifier('les identifiants « eso- » ne débordent pas des dix langages',
         [...new Set(eso.map(f => f.lang))].sort(), LIBELLES_ESOTERIQUES.slice().sort());

/* Les exemples doivent être exécutables : le bouton « Tester » envoie le code du
 * bloc, et un bloc sans code n'en affiche pas. */
const exemples = eso.filter(f => (f.blocks || []).some(b => b && b.code));
verifier('au moins 80 fiches ésotériques portent un exemple',
         exemples.length >= 80, true);
console.log('      fiches avec exemple : ' + exemples.length);
const avecEntree = eso.filter(f => (f.blocks || []).some(b => b && typeof b.entree === 'string' && b.entree));
console.log('      fiches déclarant une entrée standard : ' + avecEntree.length);

/* ------------------------------------------------ l'assembleur (4.0.0) --- */
console.log();
console.log('=== l’assembleur dans le catalogue ===');
verifier('« Assembleur » est publié comme langage', langues.indexOf('Assembleur') >= 0,
         true);
const asm = fiches.filter(f => f.lang === 'Assembleur');
verifier('l’assembleur a au moins 30 fiches', asm.length >= 30, true);
console.log('      fiches : ' + asm.length);
verifier('les fiches de l’assembleur portent l’identifiant préfixé « asm- »',
         asm.every(f => /^asm-/.test(String(f.id))), true);
verifier('aucune fiche d’un autre langage ne porte le préfixe « asm- »',
         fiches.filter(f => /^asm-/.test(String(f.id)) && f.lang !== 'Assembleur').length,
         0);
/* Les groupes doivent couvrir ce que la demande nommait : assemblage, édition et
 * aide. Une aide qui ne parlerait que d'instructions sans dire comment assembler
 * et déboguer ne répondrait pas à la question. */
const groupes = [...new Set(asm.map(f => f.group))];
for (const attendu of ['Les deux syntaxes', 'Les registres', 'Les instructions',
  'La convention d’appel', 'Les directives', 'Assembler, lier, exécuter',
  'Exemples', 'Limites assumées']) {
  verifier('le groupe « ' + attendu + ' » existe', groupes.indexOf(attendu) >= 0,
           true);
}
const exemplesAsm = asm.filter(f => (f.blocks || []).some(b => b && b.code));
verifier('au moins 5 exemples sont exécutables', exemplesAsm.length >= 5, true);
console.log('      exemples exécutables : ' + exemplesAsm.length);
/* Honnêteté : un exemple vérifié pendant la génération le dit, et un exemple qui
 * n'a pas pu l'être le dit aussi. Les deux doivent être distinguables. */
const verifies = exemplesAsm.filter(f =>
  (f.blocks || []).some(b => /réellement obtenue/.test(String(b.text))));
verifier('les exemples exécutés annoncent leur sortie réelle',
         verifies.length >= 5, true);
const nonVerifies = exemplesAsm.filter(f =>
  (f.blocks || []).some(b => /NON VÉRIFIÉE/.test(String(b.text))));
console.log('      exemples vérifiés par exécution : ' + verifies.length
            + ' · publiés sans vérification possible : ' + nonVerifies.length);
/* Les faits techniques qui coûtent cher s'ils manquent doivent être écrits. */
const toutTexte = asm.map(f => (f.blocks || []).map(b => String(b.text)).join(' '))
  .join(' ');
for (const fait of ['syscall', 'rcx', 'r10', '.intel_syntax', 'rip',
  'System V', '_start', 'sudo apt install gdb']) {
  verifier('l’aide mentionne « ' + fait + ' »', toutTexte.indexOf(fait) >= 0, true);
}

console.log();
console.log(OK + '/' + N + ' vérifications conformes');
process.exit(OK === N ? 0 : 1);
