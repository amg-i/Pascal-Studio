# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, '/home/user/work/modifications')
import langages_esoteriques as E

def essai(titre, code, attendu, entree='', limite=100000):
    m = E.Chef(code, entree=entree)
    r = m.executer(limite=limite)
    ok = r['sortie'] == attendu
    print('  %-44s %s' % (titre, 'CONFORME' if ok else 'DIFFERENT'))
    if not ok:
        print('      sortie  : %r' % r['sortie'][:120])
        print('      attendu : %r' % attendu[:120])
        print('      etat    : %s | %s' % (r['state'], r['message'][:80]))
        print('      diags   : %s' % [d['message'][:70] for d in r['diagnostics']][:3])
    return ok

CAKE = '''Hello World Cake with Chocolate sauce.

This prints hello world, while being tastier than Hello World Souffle. The main
chef makes a " world!" cake, which he puts in the baking dish. When he gets the
sous chef to make the "Hello" chocolate sauce, it gets put into the baking dish
and then the whole thing is printed when he refrigerates the sauce. When
actually cooking, I'm interpreting the chocolate sauce baking dish to be
separate from the cake one and Liquify to mean either melt or blend depending on
context.

Ingredients.
33 g chocolate chips
100 g butter
54 ml double cream
2 pinches baking powder
114 g sugar
111 ml beaten eggs
119 g flour
32 g cocoa powder
0 g cake mixture

Cooking time: 25 minutes.

Pre-heat oven to 180 degrees Celsius.

Method.
Put chocolate chips into the mixing bowl.
Put butter into the mixing bowl.
Put sugar into the mixing bowl.
Put beaten eggs into the mixing bowl.
Put flour into the mixing bowl.
Put baking powder into the mixing bowl.
Put cocoa  powder into the mixing bowl.
Stir the mixing bowl for 1 minute.
Combine double cream into the mixing bowl.
Stir the mixing bowl for 4 minutes.
Liquefy the contents of the mixing bowl.
Pour contents of the mixing bowl into the baking dish.
bake the cake mixture.
Wait until baked.
Serve with chocolate sauce.

chocolate sauce.

Ingredients.
111 g sugar
108 ml hot water
108 ml heated double cream
101 g dark chocolate
72 g milk chocolate

Method.
Clean the mixing bowl.
Put sugar into the mixing bowl.
Put hot water into the mixing bowl.
Put heated double cream into the mixing bowl.
dissolve the sugar.
agitate the sugar until dissolved.
Liquefy the dark chocolate.
Put dark chocolate into the mixing bowl.
Liquefy the milk chocolate.
Put milk chocolate into the mixing bowl.
Liquefy contents of the mixing bowl.
Pour contents of the mixing bowl into the baking dish.
Refrigerate for 1 hour.
'''

total = 0; n = 0
print('=== recette publiee : Hello World Cake with Chocolate sauce ===')
# La recette principale n'a pas de « Serves », donc seule la sauce (qui se
# termine par « Refrigerate for 1 hour. ») imprime : « Hello ».
# Attendu EXACT, et il est plus riche que « Hello » seul :
#  * la recette principale verse son gateau dans le plat 1, sans « Serves » ;
#  * « Serve with chocolate sauce » lance un sous-chef qui recoit une COPIE des
#    bols et des plats de l'appelant, donc aussi le plat 1 deja rempli ;
#  * la sauce se termine par « Refrigerate for 1 hour. », qui imprime SON premier
#    plat : d'abord la sauce « Hello » (empilee au-dessus), puis le gateau herite.
# Le gateau sort en chr(2)+« wo »+chr(1728)+« rd! » au lieu de « world! » parce
# que cette recette est d'abord un vrai gateau : « Combine double cream » fait
# 32*54=1728 et « baking powder » ajoute 2. La page esolangs le reconnait elle
# meme. Reproduire ces valeurs « fausses » prouve que Stir, Combine, Liquefy et
# le transfert entre chefs sont fideles.
ATTENDU_CAKE = ('Hello' + chr(2) + chr(119) + chr(111) + chr(1728)
                + chr(114) + chr(100) + chr(33))
n+=1; total+=essai('Hello World Cake (chaine complete)', CAKE, ATTENDU_CAKE)

print()
print('=== recettes ecrites pour verifier chaque operation ===')
n+=1; total+=essai('Hello world! liquide', '''Hello World!.

Ingredients.
72 ml h
101 ml e
108 ml l1
108 ml l2
111 ml o1
32 ml sp
119 ml w
111 ml o2
114 ml r
108 ml l3
100 ml d
33 ml bang

Method.
Put bang into the mixing bowl.
Put d into the mixing bowl.
Put l3 into the mixing bowl.
Put r into the mixing bowl.
Put o2 into the mixing bowl.
Put w into the mixing bowl.
Put sp into the mixing bowl.
Put o1 into the mixing bowl.
Put l2 into the mixing bowl.
Put l1 into the mixing bowl.
Put e into the mixing bowl.
Put h into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', 'Hello world!')

n+=1; total+=essai('Add (somme sur le sommet)', '''Addition.

Ingredients.
10 g a
32 g b

Method.
Put a into the mixing bowl.
Add b to the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '42\n')

n+=1; total+=essai('Remove / Combine / Divide', '''Arithmetique.

Ingredients.
100 g a
8 g b
5 g c
2 g d

Method.
Put a into the mixing bowl.
Remove b from the mixing bowl.
Pour contents of the mixing bowl into the baking dish.
Clean the mixing bowl.
Put b into the mixing bowl.
Combine c into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.
Clean the mixing bowl.
Put a into the mixing bowl.
Divide c into the mixing bowl.
Pour contents of the mixing bowl into the 2nd baking dish.

Serves 2.
''', '40\n92\n20\n')   # les deux Pour versent dans le MEME plat : 40 est au-dessus de 92

n+=1; total+=essai('Fold (depile dans l ingredient)', '''Pliage.

Ingredients.
7 g x
0 g y

Method.
Put x into the mixing bowl.
Fold y into the mixing bowl.
Put y into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '7\n')

n+=1; total+=essai('Stir for N minutes (roule le sommet)', '''Remuage.

Ingredients.
1 g un
2 g deux
3 g trois
4 g quatre

Method.
Put un into the mixing bowl.
Put deux into the mixing bowl.
Put trois into the mixing bowl.
Put quatre into the mixing bowl.
Stir the mixing bowl for 2 minutes.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '3\n4\n2\n1\n')   # [1,2,3,4] -> roule 2 -> [1,2,4,3] ; depile 3,4,2,1

n+=1; total+=essai('Liquefy / Liquify (ancienne orthographe)', '''Liquefaction.

Ingredients.
65 g a
66 g b

Method.
Put a into the mixing bowl.
Liquefy a.
Put a into the mixing bowl.
Put b into the mixing bowl.
Liquify b.
Put b into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', 'B66\nA65\n')   # chaque Put fige la designation sec/liquide de l'instant

n+=1; total+=essai('Add dry ingredients', '''Secs.

Ingredients.
10 g sec1
32 g sec2
65 ml liquide

Method.
Add dry ingredients to the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '42\n')

n+=1; total+=essai('Take from refrigerator (entree)', '''Lecture.

Ingredients.
0 g n

Method.
Take n from refrigerator.
Put n into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '42\n', entree='42\n')

n+=1; total+=essai('boucle : 3 iterations', '''Compte.

Ingredients.
3 g counter

Method.
Knead the counter.
Clean the mixing bowl.
Put counter into the mixing bowl.
Pour contents of the mixing bowl into the 2nd baking dish.
Mix the counter until kneaded.

Serves 2.
''', '1\n2\n3\n')

n+=1; total+=essai('Set aside sort de la boucle', '''Cassure.

Ingredients.
9 g counter

Method.
Knead the counter.
Clean the mixing bowl.
Put counter into the mixing bowl.
Pour contents of the mixing bowl into the 2nd baking dish.
Set aside.
Mix the counter until kneaded.

Serves 2.
''', '9\n')

n+=1; total+=essai('recette auxiliaire rend son 1er bol', '''Principal.

Ingredients.
1 g x

Method.
Put x into the mixing bowl.
Serve with helper.
Pour contents of the mixing bowl into the baking dish.

Serves 1.

helper.

Ingredients.
7 g y

Method.
Clean the mixing bowl.
Put y into the mixing bowl.
''', '7\n1\n')

n+=1; total+=essai('Serves 2 imprime deux plats', '''Deux plats.

Ingredients.
1 g a
2 g b

Method.
Put a into the mixing bowl.
Pour contents of the mixing bowl into the baking dish.
Clean the mixing bowl.
Put b into the mixing bowl.
Pour contents of the mixing bowl into the 2nd baking dish.

Serves 2.
''', '1\n2\n')

n+=1; total+=essai('le 2nd mixing bowl est separe du 1er', '''Bols multiples.

Ingredients.
5 g a
9 g b

Method.
Put a into the mixing bowl.
Put b into the 2nd mixing bowl.
Pour contents of the 2nd mixing bowl into the baking dish.
Pour contents of the mixing bowl into the baking dish.

Serves 1.
''', '5\n9\n')

print()
print('=== detection d erreurs ===')
cas = [('ingredient jamais declare', '''Erreur.

Ingredients.
1 g a

Method.
Put zz into the mixing bowl.

Serves 1.
'''),
       ('bol vide pour Fold', '''Erreur.

Ingredients.
1 g a

Method.
Fold a into the mixing bowl.

Serves 1.
'''),
       ('division par zero', '''Erreur.

Ingredients.
10 g a
0 g b

Method.
Put a into the mixing bowl.
Divide b into the mixing bowl.

Serves 1.
'''),
       ('boucle jamais refermee', '''Erreur.

Ingredients.
3 g c

Method.
Knead the c.
Put c into the mixing bowl.

Serves 1.
'''),
       ('until sans ouverture', '''Erreur.

Ingredients.
3 g c

Method.
Mix the c until kneaded.

Serves 1.
'''),
       ('recette auxiliaire introuvable', '''Erreur.

Ingredients.
1 g a

Method.
Serve with inexistante.

Serves 1.
'''),
       ('phrase non reconnue', '''Erreur.

Ingredients.
1 g a

Method.
Danser avec les loups.

Serves 1.
'''),
       ('entree epuisee', '''Erreur.

Ingredients.
0 g n

Method.
Take n from refrigerator.

Serves 1.
''')]
detectes = 0
for titre, code in cas:
    m = E.Chef(code); r = m.executer(limite=3000)
    msgs = [d['message'] for d in r['diagnostics'] if d['severity']=='error']
    if msgs: detectes += 1
    print('  %-32s etat=%-7s %s' % (titre, r['state'], (msgs[:1] or ['AUCUN'])[0][:70]))

print()
print('=== garde-fous de structure ===')
m = E.Chef('Pas de titre ici\nIngredients.\n1 g a\n'); r = m.executer(limite=100)
print('  sans titre              : %s' % [d['message'][:60] for d in r['diagnostics']][:1])
m = E.Chef('Recette.\n\nIngredients.\n1 g a\n\nMethod.\nPut a into the mixing bowl.\n'); r = m.executer(limite=100)
print('  sans « Serves N. »      : %s' % [d['message'][:70] for d in r['diagnostics']][:1])
print()
print('%d/%d executions conformes ; %d/%d erreurs detectees' % (total, n, detectes, len(cas)))
