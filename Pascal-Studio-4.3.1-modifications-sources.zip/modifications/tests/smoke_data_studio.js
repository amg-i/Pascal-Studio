/* Banc de data-studio.js : l'éditeur de données ouvert dans un ONGLET (4.0.0).
 *
 * Ce script était une modale plein écran ; il monte maintenant dans l'élément
 * `.ps-data-host` que l'application crée pour un fichier de données, tout en
 * gardant la modale pour les connexions serveur. Le banc exécute réellement le
 * fichier livré dans un DOM suffisant, avec un serveur factice qui répond aux
 * mêmes routes, et vérifie ce que l'utilisateur verrait.
 *
 * Pourquoi un parseur HTML et pas le harnais de smoke_page_ia.js :
 *   data-studio.js construit sa structure par `box.innerHTML='<header…><div
 *   class="psdata-body"><aside class="psdata-sidebar">…'` puis la retrouve par
 *   `$('.psdata-sidebar', layer)`. Un harnais qui stocke innerHTML comme une
 *   chaîne sans le parser laisserait ces sélecteurs renvoyer null, et le banc
 *   passerait au vert en ne testant rien.
 *
 * Lancer :  node tests/smoke_data_studio.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'data-studio.js');

let OK = 0;
let N = 0;
const echecs = [];
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  else {
    echecs.push(titre + '\n      obtenu  : ' + JSON.stringify(obtenu).slice(0, 240)
      + '\n      attendu : ' + JSON.stringify(attendu).slice(0, 240));
  }
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* ------------------------------------------------------- serveur factice --- */
const appels = [];
let reponses = {};
function definirReponse(route, valeur) { reponses[route] = valeur; }

function fetchStub(url, opts) {
  const u = String(url);
  appels.push({ url: u, opts: opts || null });
  const route = u.split('?')[0];
  let corps = null;
  try { corps = opts && opts.body ? JSON.parse(opts.body) : null; } catch (e) { corps = null; }
  const cle = route + '|' + (corps ? JSON.stringify(corps) : '');
  let rep;
  if (Object.prototype.hasOwnProperty.call(reponses, cle)) rep = reponses[cle];
  else if (Object.prototype.hasOwnProperty.call(reponses, route)) rep = reponses[route];
  else rep = { erreur: 'route non prévue par le banc : ' + route };
  const statut = rep && rep.__statut ? rep.__statut : 200;
  const ok = statut >= 200 && statut < 300;
  const payload = rep && rep.__erreur !== undefined ? { error: rep.__erreur } : rep;
  return Promise.resolve({
    ok, status: statut,
    json: () => Promise.resolve(payload),
  });
}

/* ------------------------------------------------------------ exécution ---- */
const source = fs.readFileSync(SCRIPT, 'utf8');

const ctx = H.creerDocument();
const documentElement = ctx.documentElement;
const body = ctx.body;
const documentStub = ctx.document;
const rafraichirRacine = ctx.rafraichir;

const barActivity = new H.Noeud('div');
barActivity.className = 'activitybar';
body.append(barActivity);
rafraichirRacine();

let confirmations = [];
const fenetre = {
  PSOpenDbHelp: () => { fenetre.__aideAppelee = (fenetre.__aideAppelee || 0) + 1; },
  PSFMActivate: entry => { fenetre.__onglets = (fenetre.__onglets || []).concat([entry]); },
};
fenetre.window = fenetre;

const intervalles = [];
const sandbox = {
  window: fenetre,
  document: documentStub,
  navigator: { clipboard: { writeText: () => Promise.resolve() } },
  fetch: fetchStub,
  console,
  setTimeout: (fn) => { Promise.resolve().then(fn); return 0; },
  setInterval: (fn, ms) => { intervalles.push({ fn, ms }); return intervalles.length; },
  clearInterval: () => {},
  MutationObserver: H.MutationObserverStub,
  confirm: (msg) => { confirmations.push(String(msg)); return confirmations.__reponse !== false; },
  alert: () => {},
  TextEncoder: typeof TextEncoder !== 'undefined' ? TextEncoder : undefined,
  Promise, Map, Set, JSON, Math, Date, Object, Array, String, Number, Boolean, Error, RegExp,
  encodeURIComponent, decodeURIComponent, parseInt, parseFloat, isNaN,
};
sandbox.globalThis = sandbox;
sandbox.self = sandbox;

vm.createContext(sandbox);
let erreurChargement = null;
try { vm.runInContext(source, sandbox, { filename: 'data-studio.js' }); }
catch (e) { erreurChargement = e; }

/* L'attachement initial a tourné au chargement (readyState='complete'). */
rafraichirRacine();

function ticks(n) {
  let p = Promise.resolve();
  for (let i = 0; i < n; i++) p = p.then(() => { rafraichirRacine(); });
  return p;
}

async function attendre(n = 14) { await ticks(n); }

function nouvelHote(chemin) {
  const hote = new H.Noeud('div');
  hote.className = 'ps-data-host';
  hote.dataset.path = chemin;
  body.append(hote);
  rafraichirRacine();
  H.declencherObservateurs();
  return hote;
}

function texteDe(noeud) { return noeud ? noeud.textContent : ''; }

async function main() {
  /* ---- 1. Le fichier livré se charge sans lever ------------------------- */
  vrai('data-studio.js s’exécute sans erreur de chargement',
    erreurChargement === null);
  if (erreurChargement) {
    console.error('ERREUR DE CHARGEMENT : ' + erreurChargement.stack);
    terminer(1);
    return;
  }

  /* ---- 2. Le bouton de la barre d'activité ------------------------------ */
  const boutons = barActivity.querySelectorAll('.psdata-launch');
  verifier('un seul bouton « Données » est posé dans la barre d’activité',
    boutons.length, 1);
  vrai('le bouton porte un libellé accessible',
    boutons[0] && boutons[0].getAttribute('aria-label') === 'Données et bases SQL');
  vrai('le bouton contient une icône SVG',
    boutons[0] && /<svg/.test(boutons[0].innerHTML));

  /* ---- 3. attach() est idempotent : pas de deuxième bouton -------------- */
  const avant = barActivity.querySelectorAll('.psdata-launch').length;
  /* L'intervalle posé par le script rejoue attach() toutes les 2 s. */
  verifier('un rappel périodique d’attach() est bien posé', intervalles.length >= 1, true);
  if (intervalles.length) { intervalles[0].fn(); rafraichirRacine(); }
  verifier('le rappel périodique ne duplique pas le bouton',
    barActivity.querySelectorAll('.psdata-launch').length, avant);

  /* ---- 4. Un observateur de mutations est posé -------------------------- */
  verifier('un MutationObserver est enregistré', H.observateurs().length, 1);
  vrai('il observe tout le document',
    H.observateurs()[0] && H.observateurs()[0].cibles.length === 1
    && H.observateurs()[0].cibles[0].cible === documentElement);
  vrai('il observe les ajouts de nœuds dans les sous-arbres',
    H.observateurs()[0] && H.observateurs()[0].cibles[0].opts
    && H.observateurs()[0].cibles[0].opts.subtree === true
    && H.observateurs()[0].cibles[0].opts.childList === true);

  /* ---- 5. Un fichier SQLite ouvre un onglet éditable -------------------- */
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'donnees.sqlite' }),
    { id: 'sid-1', kind: 'sqlite', label: 'donnees.sqlite', location: '/p/donnees.sqlite', revision: 'r1' });
  definirReponse('/api/data/tables|' + JSON.stringify({ id: 'sid-1' }),
    { tables: [{ schema: '', name: 'Clients', type: 'table' }, { schema: '', name: 'Vues', type: 'view' }] });
  definirReponse('/api/tree', { tree: [{ type: 'folder', name: 'd', children: [
    { type: 'file', name: 'donnees.sqlite', path: 'donnees.sqlite' },
    { type: 'file', name: 'clients.xlsx', path: 'clients.xlsx' },
    { type: 'file', name: 'notes.txt', path: 'notes.txt' },
  ] }] });

  const hote1 = nouvelHote('donnees.sqlite');
  await attendre();
  vrai('l’éditeur est monté dans l’hôte de l’onglet',
    hote1.children.length === 1 && hote1.children[0].classList.contains('psdata-embed'));
  const zone1 = hote1.querySelector('.psdata-main');
  vrai('une zone principale existe', !!zone1);
  const pied1 = hote1.querySelector('.psdata-footer');
  vrai('un pied de page existe', !!pied1);
  vrai('l’ouverture est annoncée',
    /Source ouverte : donnees\.sqlite/.test(texteDe(pied1)));
  vrai('le titre du fichier est affiché', /donnees\.sqlite/.test(texteDe(zone1)));
  vrai('la pastille annonce SQLite', /SQLite/.test(texteDe(zone1.querySelector('.psdata-badge'))));
  vrai('la liste des tables est rendue', /Clients/.test(texteDe(zone1)) && /Vues/.test(texteDe(zone1)));
  vrai('une vue est signalée comme telle', /vue/.test(texteDe(zone1)));
  vrai('le bouton de requête SQL est présent', /Requête SQL/.test(texteDe(zone1)));
  vrai('en onglet, aucune barre latérale de sources n’est créée',
    hote1.querySelector('.psdata-sidebar') === null);
  vrai('en onglet, le bouton « Fermer la source » est absent',
    !/Fermer la source/.test(texteDe(zone1)));

  /* ---- 6. La session est mise en cache : rouvrir ne relit pas ----------- */
  const appelsOpenAvant = appels.filter(a => /\/api\/data\/open/.test(a.url)).length;
  hote1.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  await attendre(4);
  const hote1bis = nouvelHote('donnees.sqlite');
  await attendre();
  const appelsOpenApres = appels.filter(a => /\/api\/data\/open/.test(a.url)).length;
  verifier('rouvrir le même fichier ne rouvre pas de session serveur',
    appelsOpenApres, appelsOpenAvant);
  vrai('l’éditeur est remonté après fermeture/réouverture de l’onglet',
    hote1bis.children.length === 1);

  /* ---- 7. Le montage ne reboucle pas sur ses propres mutations ---------- */
  const mutationsAvant = H.compteurMutations();
  H.declencherObservateurs();
  await attendre(4);
  H.declencherObservateurs();
  await attendre(4);
  verifier('relancer l’observateur ne remonte pas l’éditeur',
    hote1bis.children.length, 1);
  vrai('les mutations provoquées restent bornées', H.compteurMutations() - mutationsAvant < 200);

  /* ---- 8. Un classeur XLSX : pastille, miroir annoncé, requête ---------- */
  hote1bis.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'clients.xlsx' }),
    { id: 'sid-2', kind: 'xlsx', label: 'clients.xlsx', location: '/p/clients.xlsx', revision: 'r2', miroir: true });
  definirReponse('/api/data/tables|' + JSON.stringify({ id: 'sid-2' }),
    { tables: [{ schema: '', name: 'Clients', type: 'table' }], miroir: true });
  const hote2 = nouvelHote('clients.xlsx');
  await attendre();
  const zone2 = hote2.querySelector('.psdata-main');
  vrai('la pastille nomme le format classeur',
    /Classeur XLSX/.test(texteDe(zone2.querySelector('.psdata-badge'))));
  vrai('le pied annonce la copie de travail en mémoire',
    /Copie de travail en mémoire/.test(texteDe(hote2.querySelector('.psdata-footer'))));

  /* Choisir la table, puis passer en mode requête. */
  const boutonTable = zone2.querySelectorAll('button').find(b => /^Clients/.test(b.textContent.trim()));
  vrai('un bouton porte le nom de la feuille', !!boutonTable);
  definirReponse('/api/data/rows', { columns: ['id', 'nom'], rows: [[1, 'Ada'], [2, 'Grace']], total: 2, editable: false, miroir: true });
  if (boutonTable) { boutonTable.dispatchEvent({ type: 'click' }); }
  await attendre();
  const boutonRequete = zone2.querySelectorAll('button').find(b => /Requête SQL/.test(b.textContent));
  vrai('le bouton de requête est cliquable', !!boutonRequete);
  if (boutonRequete) boutonRequete.dispatchEvent({ type: 'click' });
  await attendre();
  const zone2b = hote2.querySelector('.psdata-main');
  vrai('un champ de saisie de requête est présent',
    zone2b.querySelectorAll('textarea').length >= 1);
  vrai('le miroir est expliqué dans le volet de requête',
    /miroir SQLite reconstruit/.test(texteDe(zone2b)));
  vrai('il est dit qu’une requête modificatrice sera refusée',
    /refusée parce qu’elle n’écrirait rien/.test(texteDe(zone2b)));
  vrai('deux boutons d’exécution sont proposés',
    zone2b.querySelectorAll('button').filter(b => /Exécuter/.test(b.textContent)).length === 2);

  /* L'observateur se déclenche sur N'IMPORTE QUELLE mutation du document, y
   * compris celles que l'éditeur provoque lui-même. S'il remontait l'éditeur à
   * chaque fois, le champ serait un nœud neuf : la frappe en cours, le point
   * d'insertion et le défilement seraient perdus sans qu'aucune erreur
   * n'apparaisse. On contrôle donc l'identité du nœud, pas seulement sa valeur. */
  const aireAvant = zone2b.querySelector('textarea');
  H.declencherObservateurs();
  await attendre(4);
  const aireApres = hote2.querySelector('.psdata-main').querySelector('textarea');
  vrai('une mutation du document ne reconstruit pas l’éditeur', aireApres === aireAvant);
  vrai('le volet de requête survit aux mutations répétées',
    hote2.querySelector('.psdata-main').querySelectorAll('textarea').length === 1);

  /* ---- 9. Une requête refusée affiche sa raison dans les résultats ------ */
  definirReponse('/api/data/query', { __statut: 400, __erreur: 'Requête refusée : seule la lecture est possible sur une copie de travail.' });
  const aire = zone2b.querySelector('textarea');
  vrai('le champ de requête est éditable', !!aire);
  if (aire) { aire.value = 'DELETE FROM Clients'; aire.dispatchEvent({ type: 'input' }); }
  const valider = zone2b.querySelectorAll('button').find(b => /Exécuter et valider/.test(b.textContent));
  vrai('le bouton « Exécuter et valider » existe', !!valider);
  confirmations.length = 0;
  if (valider) valider.dispatchEvent({ type: 'click' });
  await attendre();
  verifier('une confirmation est demandée avant d’exécuter',
    confirmations.length >= 1, true);
  const zone2c = hote2.querySelector('.psdata-main');
  vrai('la raison du refus est affichée dans le volet de résultats',
    /Requête refusée — Requête refusée : seule la lecture/.test(texteDe(zone2c)));
  vrai('le refus est aussi signalé en pied de page',
    /refusée/i.test(texteDe(hote2.querySelector('.psdata-footer'))));

  /* ---- 10. Un fichier qui n'est pas une base : repli texte -------------- */
  hote2.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'faux.sqlite' }),
    { __statut: 400, __erreur: 'l’extension annonce une base SQLite mais l’amorce n’est pas « SQLite format 3 » : ce fichier est ouvert comme texte' });
  definirReponse('/api/file', { content: 'ceci n’est pas une base\ndeuxième ligne\n' });
  definirReponse('/api/save', { ok: true });
  const hote3 = nouvelHote('faux.sqlite');
  await attendre();
  const zone3 = hote3.querySelector('.psdata-main');
  vrai('l’échec est expliqué, pas silencieux',
    /n’a pas pu être ouvert comme base de données/.test(texteDe(zone3)));
  vrai('la raison du serveur est reprise mot pour mot',
    /amorce n’est pas « SQLite format 3 »/.test(texteDe(zone3)));
  const boutonTexte = zone3.querySelectorAll('button').find(b => /Ouvrir comme texte/.test(b.textContent));
  vrai('un bouton propose le repli texte', !!boutonTexte);
  if (boutonTexte) boutonTexte.dispatchEvent({ type: 'click' });
  await attendre();
  const zone3b = hote3.querySelector('.psdata-main');
  const aireTexte = zone3b.querySelector('textarea');
  vrai('le repli texte affiche le contenu du fichier', !!aireTexte);
  verifier('le contenu est bien celui du fichier',
    aireTexte ? aireTexte.value : null, 'ceci n’est pas une base\ndeuxième ligne\n');
  vrai('la pastille dit Texte', /Texte/.test(texteDe(zone3b.querySelector('.psdata-badge'))));
  vrai('un bouton d’enregistrement est présent',
    zone3b.querySelectorAll('button').some(b => /Enregistrer/.test(b.textContent)));
  /* Modifier puis enregistrer doit passer par /api/save avec le bon chemin. */
  if (aireTexte) { aireTexte.value = 'ligne modifiée\n'; aireTexte.dispatchEvent({ type: 'input' }); }
  const enregistrer = zone3b.querySelectorAll('button').find(b => /Enregistrer/.test(b.textContent));
  confirmations.length = 0;
  if (enregistrer) enregistrer.dispatchEvent({ type: 'click' });
  await attendre();
  const appelSave = appels.filter(a => a.url === '/api/save').pop();
  vrai('l’enregistrement passe par /api/save', !!appelSave);
  verifier('le chemin et le texte sont envoyés',
    appelSave ? JSON.parse(appelSave.opts.body) : null,
    { path: 'faux.sqlite', content: 'ligne modifiée\n' });

  /* ---- 11. Un emplacement synthétique n'est pas traité comme un fichier -- */
  hote3.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  const hote4 = nouvelHote('@remote:1/donnees.sqlite');
  await attendre();
  vrai('un chemin synthétique est refusé avec une explication',
    /emplacement synthétique ou une source distante non téléchargée/.test(texteDe(hote4.querySelector('.psdata-main'))));
  verifier('aucun appel d’ouverture n’est émis pour un chemin synthétique',
    appels.filter(a => /\/api\/data\/open/.test(a.url) && /@remote/.test(a.opts.body)).length, 0);

  /* ---- 12. Changer de fichier dans le même hôte ------------------------- */
  hote4.dataset.path = 'donnees.sqlite';
  rafraichirRacine();
  H.declencherObservateurs();
  await attendre();
  vrai('changer data-path remonte l’éditeur pour le nouveau fichier',
    /donnees\.sqlite/.test(texteDe(hote4.querySelector('.psdata-main'))));

  /* ---- 13. Sans hôte, rien n'est monté et rien ne lève ------------------ */
  hote4.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  await attendre(4);
  verifier('aucun hôte de données ne subsiste', documentStub.querySelectorAll('.ps-data-host').length, 0);

  /* ---- 14. La modale reste disponible pour les connexions serveur ------- */
  fenetre.__onglets = [];
  const boutonBarre = barActivity.querySelector('.psdata-launch');
  boutonBarre.dispatchEvent({ type: 'click' });
  await attendre();
  const modale = body.querySelector('.psdata-overlay');
  vrai('le bouton de la barre ouvre la modale', !!modale);
  vrai('la modale expose les connexions serveur',
    /Connexion serveur/.test(texteDe(modale.querySelector('.psdata-sidebar'))));
  /* Le texte rendu, pas innerHTML : la structure de la modale est posée sur
   * l'élément enfant, jamais sur la surcouche elle-même. Tester innerHTML ici
   * renverrait toujours la chaîne vide et le contrôle passerait à tort… ou
   * échouerait à tort, comme il vient de le faire. */
  vrai('la modale annonce les nouveaux formats',
    /XLSX/.test(texteDe(modale)) && /ODS/.test(texteDe(modale)) && /XML/.test(texteDe(modale)));
  vrai('la modale dit que les fichiers du projet s’ouvrent en onglet',
    /s’ouvrent dans leur propre onglet/.test(texteDe(modale.querySelector('.psdata-footer'))));
  vrai('la modale distingue « Tout fermer » de « fermer le panneau »',
    modale.querySelectorAll('button').some(b => b.textContent === 'Tout fermer')
    && modale.querySelectorAll('button').some(b => b.textContent === '✕'));

  /* La liste des fichiers du projet doit inclure les nouveaux formats. */
  const listeProjet = modale.querySelector('.psdata-project-list');
  vrai('la liste du projet contient le classeur XLSX',
    !!listeProjet && /clients\.xlsx/.test(texteDe(listeProjet)));
  vrai('la liste du projet contient la base SQLite',
    !!listeProjet && /donnees\.sqlite/.test(texteDe(listeProjet)));
  vrai('la liste du projet écarte un fichier non compatible',
    !!listeProjet && !/notes\.txt/.test(texteDe(listeProjet)));

  /* Cliquer un fichier du projet doit ouvrir un ONGLET, pas l'éditer ici. */
  const boutonFichier = listeProjet.querySelectorAll('button').find(b => b.textContent.trim() === 'clients.xlsx');
  vrai('chaque fichier du projet est un bouton', !!boutonFichier);
  if (boutonFichier) boutonFichier.dispatchEvent({ type: 'click' });
  await attendre(4);
  verifier('cliquer un fichier du projet demande l’ouverture d’un onglet',
    fenetre.__onglets.map(e => e.path), ['clients.xlsx']);
  verifier('le contenu de l’onglet est laissé vide, c’est ce script qui le charge',
    fenetre.__onglets.map(e => e.content), ['']);
  verifier('la modale se retire pour laisser voir l’onglet',
    body.querySelectorAll('.psdata-overlay').length, 0);

  /* ---- 15. Réouvrir la modale ne duplique rien -------------------------- */
  boutonBarre.dispatchEvent({ type: 'click' });
  await attendre(4);
  verifier('une seule modale à la fois', body.querySelectorAll('.psdata-overlay').length, 1);
  boutonBarre.dispatchEvent({ type: 'click' });
  await attendre(4);
  verifier('un second clic ne crée pas une deuxième modale',
    body.querySelectorAll('.psdata-overlay').length, 1);

  /* ---- 16. Les opérations de structure sur un classeur ------------------ */
  /* Un classeur est le cas le plus exposé : c'est lui dont l'enregistrement
   * renvoyait {'error': "'conn'"} — le nom d'une variable Python en guise
   * d'explication. Le banc vérifie donc les boutons, ce qu'ils envoient, et ce
   * que l'utilisateur lit en retour. */
  for (const h of body.querySelectorAll('.ps-data-host')) h.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'stock.ods' }),
    { id: 'sid-ods', kind: 'ods', label: 'stock.ods', location: '/p/stock.ods',
      revision: 'r3', miroir: true, editable: true,
      tables: [{ schema: '', name: 'Stock', type: 'table' }] });
  definirReponse('/api/data/tables|' + JSON.stringify({ id: 'sid-ods' }),
    { tables: [{ schema: '', name: 'Stock', type: 'table' }], miroir: true });
  const COLONNES_ODS = [
    { name: 'article', type: 'TEXT', pk: false, generated: false },
    { name: 'quantite', type: 'TEXT', pk: false, generated: false }];
  definirReponse('/api/data/rows',
    { columns: COLONNES_ODS, rows: [['vis', '120'], ['écrou', '340']], total: 2,
      offset: 0, more: false, editable: true, miroir: true, entete: true });
  const hoteOds = nouvelHote('stock.ods');
  await attendre();
  let zone = hoteOds.querySelector('.psdata-main');
  const boutonFeuille = zone.querySelectorAll('button')
    .find(b => /^Stock/.test(b.textContent.trim()));
  vrai('la feuille du classeur est listée', !!boutonFeuille);
  if (boutonFeuille) boutonFeuille.dispatchEvent({ type: 'click' });
  await attendre();
  zone = hoteOds.querySelector('.psdata-main');
  const libelles = zone.querySelectorAll('button').map(b => b.textContent.trim());
  for (const attendu of ['＋ Ligne', '＋ Colonne…', '－ Colonne…', '－ Table',
    '＋ Table…', 'Enregistrer']) {
    vrai('la grille d’un classeur propose « ' + attendu + ' »',
      libelles.includes(attendu));
  }
  /* Plusieurs pastilles coexistent : celle du FORMAT, dans l'en-tête, et celle
   * de la grille. C'est celle de la grille qui dit si l'on peut modifier. */
  const panneau = zone.querySelector('.psdata-table-panel');
  vrai('la pastille de la grille dit qu’elle est modifiable',
    !!panneau && /Modifiable/.test(texteDe(panneau.querySelector('.psdata-badge'))));

  /* Ajouter une colonne : la boîte de dialogue, puis la demande envoyée. */
  appels.length = 0;
  definirReponse('/api/data/structure',
    { ok: true, instruction: 'colonne « prix » ajoutée à « Stock »',
      tables: [{ schema: '', name: 'Stock', type: 'table' }], revision: 'r4' });
  verifier('aucune boîte de dialogue ne traîne appelsAvant l’ouverture',
    body.querySelectorAll('.psdata-subdialog').length, 0);
  const boutonColonne = zone.querySelectorAll('button')
    .find(b => b.textContent.trim() === '＋ Colonne…');
  boutonColonne.dispatchEvent({ type: 'click' });
  await attendre(4);
  let carte = body.querySelector('.psdata-subdialog form');
  vrai('une boîte de dialogue s’ouvre pour la colonne', !!carte);
  let champs = carte ? carte.querySelectorAll('input') : [];
  vrai('la boîte demande le nom de la colonne', champs.length >= 1);
  vrai('un classeur ne demande pas de type de colonne',
    !!carte && carte.querySelectorAll('select').length === 0);
  vrai('la valeur par défaut est proposée pour les lignes existantes',
    champs.length >= 2);
  if (champs[0]) champs[0].value = 'prix';
  if (champs[1]) champs[1].value = '0';
  if (carte) carte.dispatchEvent({ type: 'submit' });
  /* La chaîne est longue : envoi, rechargement des tables, rendu, rechargement
   * des lignes, puis seulement le pied de page. Un compte de tours trop court
   * ferait accuser le produit pour l'impatience du banc. */
  await attendre(20);
  let envois = appels.filter(a => a.url.endsWith('/api/data/structure'));
  verifier('une seule demande de structure a été envoyée', envois.length, 1);
  if (envois.length) {
    const corpsDemande = JSON.parse(envois[0].opts.body);
    verifier('l’action demandée est add_column', corpsDemande.action, 'add_column');
    verifier('la colonne demandée est celle saisie', corpsDemande.column, 'prix');
    verifier('la valeur par défaut est transmise', corpsDemande.default, '0');
    verifier('la table visée est la feuille affichée', corpsDemande.name, 'Stock');
    verifier('la session est transmise', corpsDemande.id, 'sid-ods');
  }
  vrai('l’instruction réellement exécutée est dite en pied de page',
    /colonne « prix » ajoutée/.test(texteDe(hoteOds.querySelector('.psdata-footer'))));

  /* Supprimer une table : confirmation, puis demande. */
  appels.length = 0;
  confirmations.length = 0;
  definirReponse('/api/data/structure',
    { ok: true, instruction: 'table « Stock » supprimée du fichier',
      tables: [], revision: 'r5' });
  zone = hoteOds.querySelector('.psdata-main');
  const boutonSuppr = zone.querySelectorAll('button')
    .find(b => b.textContent.trim() === '－ Table');
  boutonSuppr.dispatchEvent({ type: 'click' });
  await attendre(6);
  verifier('une confirmation est demandée appelsAvant de supprimer la table',
    confirmations.length >= 1, true);
  vrai('la confirmation nomme la table',
    /Stock/.test(confirmations[0] || ''));
  vrai('la confirmation dit que le fichier sera réécrit, pas qu’un déclencheur SQL tournera',
    /réécrit/.test(confirmations[0] || '') && !/déclencheur/.test(confirmations[0] || ''));
  envois = appels.filter(a => a.url.endsWith('/api/data/structure'));
  verifier('une seule demande de suppression a été envoyée', envois.length, 1);
  if (envois.length) {
    const corpsDemande = JSON.parse(envois[0].opts.body);
    verifier('l’action demandée est drop_table', corpsDemande.action, 'drop_table');
    verifier('la table visée est celle affichée', corpsDemande.name, 'Stock');
  }

  /* Un refus du serveur doit être lu, et non perdu dans la console. */
  appels.length = 0;
  definirReponse('/api/data/structure',
    { __statut: 400, __erreur: 'Ce fichier n’a qu’une seule table : tout supprimer le laisserait sans aucune table exploitable.' });
  definirReponse('/api/data/tables|' + JSON.stringify({ id: 'sid-ods' }),
    { tables: [{ schema: '', name: 'Stock', type: 'table' }], miroir: true });
  /* La suppression précédente a rendu une liste de tables vide : c'est ce que
   * le serveur a dit. « Actualiser les tables » la relit, comme le ferait
   * l'utilisateur, et la feuille réapparaît. */
  zone = hoteOds.querySelector('.psdata-main');
  const boutonActualiser = zone.querySelectorAll('button')
    .find(b => /Actualiser les tables/.test(b.textContent));
  vrai('la liste des tables peut être actualisée', !!boutonActualiser);
  if (boutonActualiser) boutonActualiser.dispatchEvent({ type: 'click' });
  await attendre();
  zone = hoteOds.querySelector('.psdata-main');
  const boutonTableOds = zone.querySelectorAll('button')
    .find(b => /^Stock/.test(b.textContent.trim()));
  vrai('la feuille réapparaît après actualisation', !!boutonTableOds);
  if (boutonTableOds) boutonTableOds.dispatchEvent({ type: 'click' });
  await attendre();
  zone = hoteOds.querySelector('.psdata-main');
  const boutonSuppr2 = zone.querySelectorAll('button')
    .find(b => b.textContent.trim() === '－ Table');
  vrai('la grille réaffiche le bouton de suppression', !!boutonSuppr2);
  if (boutonSuppr2) boutonSuppr2.dispatchEvent({ type: 'click' });
  await attendre(6);
  vrai('un refus du serveur est affiché en pied de page',
    /aucune table exploitable/.test(texteDe(hoteOds.querySelector('.psdata-footer'))));

  /* ---- 17. Une grille en lecture seule dit POURQUOI --------------------- */
  /* Un classeur à formules ne peut pas être réécrit sans les perdre : le dire
   * à l'ouverture évite de faire saisir des modifications qui seront refusées. */
  definirReponse('/api/data/rows',
    { columns: COLONNES_ODS, rows: [['vis', '120']], total: 1, offset: 0,
      more: false, editable: false, miroir: true, entete: true,
      raison_lecture_seule: 'Ce classeur contient des formules. Enregistrez une copie CSV, ou modifiez le classeur dans son application d’origine.' });
  zone.querySelectorAll('button').find(b => b.textContent.trim() === '－ Colonne…')
    .dispatchEvent({ type: 'click' });
  await attendre(4);
  carte = body.querySelector('.psdata-subdialog form');
  vrai('la suppression de colonne passe aussi par une boîte de dialogue', !!carte);
  if (carte) carte.querySelector('button').dispatchEvent({ type: 'click' });
  await attendre(2);
  zone = hoteOds.querySelector('.psdata-main');
  const boutonFeuille2 = zone.querySelectorAll('button')
    .find(b => /^Stock/.test(b.textContent.trim()));
  if (boutonFeuille2) boutonFeuille2.dispatchEvent({ type: 'click' });
  await attendre();
  zone = hoteOds.querySelector('.psdata-main');
  vrai('la raison de la lecture seule est affichée telle quelle',
    /Ce classeur contient des formules/.test(texteDe(zone)));
  const panneauLecture = zone.querySelector('.psdata-table-panel');
  vrai('la pastille de la grille dit « Lecture seule »',
    !!panneauLecture && /Lecture seule/.test(texteDe(panneauLecture.querySelector('.psdata-badge'))));
  const libellesLecture = zone.querySelectorAll('button').map(b => b.textContent.trim());
  vrai('une grille en lecture seule ne propose pas d’enregistrer',
    !libellesLecture.includes('Enregistrer'));
  vrai('une grille en lecture seule ne propose pas de supprimer la table',
    !libellesLecture.includes('－ Table'));

  /* ---- 18. Un document XML : créer une table explique le refus ---------- */
  for (const h of body.querySelectorAll('.ps-data-host')) h.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'carnet.xml' }),
    { id: 'sid-xml', kind: 'xml', label: 'carnet.xml', location: '/p/carnet.xml',
      revision: 'rx', miroir: true, editable: true,
      tables: [{ schema: '', name: 'contact', type: 'table' }] });
  definirReponse('/api/data/tables|' + JSON.stringify({ id: 'sid-xml' }),
    { tables: [{ schema: '', name: 'contact', type: 'table' }], miroir: true });
  definirReponse('/api/data/rows',
    { columns: [{ name: 'id', type: 'TEXT', pk: false, generated: false },
      { name: 'nom', type: 'TEXT', pk: false, generated: false }],
      rows: [['1', 'Ada']], total: 1, offset: 0, more: false, editable: true,
      miroir: true, entete: true });
  const hoteXml = nouvelHote('carnet.xml');
  await attendre();
  zone = hoteXml.querySelector('.psdata-main');
  const boutonContact = zone.querySelectorAll('button')
    .find(b => /^contact/.test(b.textContent.trim()));
  if (boutonContact) boutonContact.dispatchEvent({ type: 'click' });
  await attendre();
  zone = hoteXml.querySelector('.psdata-main');
  vrai('un XML propose aussi le bouton « ＋ Table… »',
    zone.querySelectorAll('button').map(b => b.textContent.trim()).includes('＋ Table…'));
  const appelsAvant = appels.length;
  zone.querySelectorAll('button').find(b => b.textContent.trim() === '＋ Table…')
    .dispatchEvent({ type: 'click' });
  await attendre(4);
  verifier('aucune boîte de dialogue ne s’ouvre pour un XML',
    body.querySelectorAll('.psdata-subdialog').length, 0);
  verifier('aucune demande n’est envoyée au serveur', appels.length, appelsAvant);
  vrai('le pied de page explique pourquoi un XML refuse une nouvelle table',
    /éléments répétés/.test(texteDe(hoteXml.querySelector('.psdata-footer'))));
  vrai('le pied de page donne la voie de recours',
    /comme texte/.test(texteDe(hoteXml.querySelector('.psdata-footer'))));
  /* En XML, une colonne peut être un attribut : la boîte doit le demander. */
  zone.querySelectorAll('button').find(b => b.textContent.trim() === '＋ Colonne…')
    .dispatchEvent({ type: 'click' });
  await attendre(4);
  carte = body.querySelector('.psdata-subdialog form');
  vrai('une boîte de dialogue s’ouvre pour une colonne XML', !!carte);
  vrai('la boîte XML propose de ranger la colonne dans un attribut',
    !!carte && /attribut/.test(texteDe(carte)));
  appels.length = 0;
  definirReponse('/api/data/structure',
    { ok: true, instruction: 'colonne « @ville » ajoutée à « contact »',
      tables: [{ schema: '', name: 'contact', type: 'table' }], revision: 'rx2' });
  champs = carte ? carte.querySelectorAll('input') : [];
  if (champs[0]) champs[0].value = 'ville';
  const choix = carte ? carte.querySelectorAll('select') : [];
  if (choix.length) { choix[choix.length - 1].value = 'attribut'; }
  if (carte) carte.dispatchEvent({ type: 'submit' });
  await attendre(6);
  envois = appels.filter(a => a.url.endsWith('/api/data/structure'));
  verifier('une demande d’ajout de colonne XML a été envoyée', envois.length, 1);
  if (envois.length) {
    const corpsDemande = JSON.parse(envois[0].opts.body);
    verifier('le choix « attribut » est transmis', corpsDemande.attribut, true);
    verifier('la colonne XML demandée', corpsDemande.column, 'ville');
  }

  /* ---- 19. Un script SQL : les instructions sont RÉDIGÉES, pas exécutées  */
  for (const h of body.querySelectorAll('.ps-data-host')) h.remove();
  rafraichirRacine();
  H.declencherObservateurs();
  definirReponse('/api/data/open|' + JSON.stringify({ path: 'schema.sql' }),
    { id: 'sid-sql', kind: 'sql', label: 'schema.sql', location: '/p/schema.sql',
      revision: 'rs', text: 'CREATE TABLE t (a INTEGER);\n' });
  const hoteSql = nouvelHote('schema.sql');
  await attendre();
  zone = hoteSql.querySelector('.psdata-main');
  vrai('un script SQL propose d’insérer une instruction',
    zone.querySelectorAll('button').map(b => b.textContent.trim())
      .includes('Insérer une instruction…'));
  appels.length = 0;
  zone.querySelectorAll('button').find(b => b.textContent.trim() === 'Insérer une instruction…')
    .dispatchEvent({ type: 'click' });
  await attendre(4);
  carte = body.querySelector('.psdata-subdialog form');
  vrai('une boîte de dialogue rédige l’instruction', !!carte);
  if (carte) {
    const entrees = carte.querySelectorAll('input');
    /* 0 : table, 1 : colonne, 2 : type (select), 3 : colonnes de la création. */
    const choixInstruction = carte.querySelectorAll('select');
    if (choixInstruction[0]) choixInstruction[0].value = 'CREATE TABLE';
    if (entrees[0]) entrees[0].value = 'clients';
    if (entrees[2]) entrees[2].value = 'id INTEGER, nom TEXT, solde NUMERIC(10,2)';
    carte.dispatchEvent({ type: 'submit' });
  }
  await attendre(6);
  verifier('aucune demande de structure n’est envoyée pour un script',
    appels.filter(a => a.url.endsWith('/api/data/structure')).length, 0);
  const aireSql = hoteSql.querySelector('.psdata-main').querySelector('textarea');
  vrai('le champ de texte porte l’instruction rédigée', !!aireSql);
  const texteSql = aireSql ? aireSql.value : '';
  vrai('l’instruction CREATE TABLE est rédigée', /CREATE TABLE "clients"/.test(texteSql));
  vrai('les colonnes saisies sont reprises', /"id" INTEGER/.test(texteSql)
    && /"nom" TEXT/.test(texteSql) && /"solde" NUMERIC\(10,2\)/.test(texteSql));
  vrai('le texte d’origine est conservé', /CREATE TABLE t \(a INTEGER\);/.test(texteSql));
  vrai('le pied de page dit que rien n’a été exécuté',
    /Instruction insérée/.test(texteDe(hoteSql.querySelector('.psdata-footer')))
    && /enregistrez/.test(texteDe(hoteSql.querySelector('.psdata-footer'))));
  vrai('le script est marqué comme à enregistrer',
    /Modifications non enregistrées/.test(texteDe(hoteSql.querySelector('.psdata-main'))));

  terminer(0);
}

function terminer(code) {
  rafraichirRacine();
  console.log('smoke_data_studio.js : ' + OK + ' / ' + N + ' contrôles OK');
  if (echecs.length) {
    console.log('\nÉCHECS (' + echecs.length + ') :');
    for (const e of echecs) console.log('  - ' + e);
  }
  process.exit(echecs.length ? 1 : code);
}

main().catch(e => {
  console.error('Le banc a levé : ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
