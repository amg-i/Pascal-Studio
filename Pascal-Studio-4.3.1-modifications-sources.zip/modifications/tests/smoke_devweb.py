#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc des modules dev web (4.0.0), sans serveur HTTP.

Ce que ce banc couvre et que les autocontrôles des modules ne couvrent pas
--------------------------------------------------------------------------
    Chaque module devweb_* s'autocontrôle à l'exécution (`python3 devweb_x.py`).
    Ces autocontrôles vérifient le module isolé. Ce banc vérifie ce qui n'existe
    qu'entre eux, sur un VRAI projet écrit sur disque :

      * l'encodage : un document cp1252, un document avec BOM, un document dont
        la déclaration de charset contredit les octets. Un audit qui lit mal
        l'encodage produit des constats sur un texte que l'utilisateur ne voit
        pas ;
      * la configuration d'en-têtes dans un SOUS-DOSSIER : un .htaccess placé à
        côté de la page, comme Apache le lit vraiment. Ne regarder que la racine
        du projet faisait dire « aucun en-tête déclaré » sur des projets
        correctement configurés ;
      * l'inventaire : dossiers cachés, node_modules, fichiers sans extension,
        profondeur ;
      * le générateur d'empreinte SRI sur un fichier réel ET sur une URL servie
        par un serveur jetable — le seul cas où un générateur fait du réseau, ce
        qui doit être dit dans les notes ;
      * le journal : bornes du tampon, entrées perdues comptées et non
        silencieuses, suite d'identifiants, nettoyage des champs inconnus.

Lancer :  python3 tests/smoke_devweb.py
"""

import base64
import http.server
import json
import os
import shutil
import struct
import sys
import tempfile
import threading
import time
import zlib

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
sys.path.insert(0, MODIFICATIONS)

import devweb                                     # noqa: E402
import devweb_journal                             # noqa: E402

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def png(largeur=4, hauteur=4):
    def morceau(type_, donnees):
        return (struct.pack('>I', len(donnees)) + type_ + donnees
                + struct.pack('>I', zlib.crc32(type_ + donnees) & 0xffffffff))
    ihdr = struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0)
    brut = b''.join(b'\x00' + b'\x10\x20\x30' * largeur for _ in range(hauteur))
    return (b'\x89PNG\r\n\x1a\n' + morceau(b'IHDR', ihdr)
            + morceau(b'IDAT', zlib.compress(brut)) + morceau(b'IEND', b''))


PAGE = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page du banc dev web</title>
<meta name="description" content="Une description assez longue pour passer le contrôle de longueur des moteurs de recherche, entre 70 et 160 caractères.">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<h1>Titre</h1>
<img src="img/logo.png" alt="Logo" width="4" height="4">
<img src="img/Logo.png" alt="Casse différente">
<a href="manquant.html">Lien cassé</a>
<script src="app.js" defer></script>
</body>
</html>
"""

STYLE = "body{color:#111;background:#fff}\n.titre{font-size:2rem\n.pied{margin:0}\n"
APP = "console.log('bonjour');\n"
HTACCESS = ('<IfModule mod_headers.c>\n'
            '  Header always set X-Content-Type-Options "nosniff"\n'
            '  Header always set Content-Security-Policy "default-src \'self\'"\n'
            '</IfModule>\n')


def construire_projet():
    """Un projet réaliste : un sous-dossier servi, des dossiers à ignorer, des
    fichiers sans extension, une feuille cassée, une casse différente."""
    racine = tempfile.mkdtemp(prefix='ps-devweb-banc-')
    site = os.path.join(racine, 'site')
    for sous in ('css', 'img', '.git', 'node_modules/paquet'):
        os.makedirs(os.path.join(site, sous))
    ecrire = lambda chemin, contenu, mode='w': (          # noqa: E731
        open(chemin, mode, encoding=None if mode == 'wb' else 'utf8')
        .write(contenu))
    ecrire(os.path.join(site, 'index.html'), PAGE)
    ecrire(os.path.join(site, 'css', 'style.css'), STYLE)
    ecrire(os.path.join(site, 'app.js'), APP)
    ecrire(os.path.join(site, '.htaccess'), HTACCESS)
    ecrire(os.path.join(site, 'img', 'logo.png'), png(4, 4), 'wb')
    ecrire(os.path.join(site, 'LICENCE'), 'Texte sans extension.\n')
    ecrire(os.path.join(site, '.git', 'config'), '[core]\n')
    ecrire(os.path.join(site, 'node_modules', 'paquet', 'index.js'), 'x\n')
    return racine, site


# ------------------------------------------------------------------ encodages --
def banc_encodages():
    texte = '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">' \
            '<title>Encodage hétéroclite</title></head><body>café</body></html>'

    donnees = texte.encode('utf8')
    lu, encodage, note = devweb._decoder(donnees)
    verif(encodage == 'utf-8' and lu == texte and not note,
          'un document UTF-8 est lu comme UTF-8 (%r)' % encodage)

    avec_bom = b'\xef\xbb\xbf' + texte.encode('utf8')
    lu, encodage, note = devweb._decoder(avec_bom)
    verif(encodage == 'utf-8-sig' and not lu.startswith('\ufeff'),
          'un BOM UTF-8 est reconnu et retiré (%r, %r)' % (encodage, lu[:6]))

    cp1252 = ('<html><head><meta charset="windows-1252"><title>Café</title>'
              '</head><body>œuf à Noël</body></html>').encode('cp1252')
    lu, encodage, note = devweb._decoder(cp1252)
    verif('œuf à Noël' in lu,
          'un document windows-1252 déclaré est décodé correctement (%r, %r)'
          % (encodage, lu[-40:]))

    # La déclaration dit UTF-8 mais les octets sont du windows-1252 : c'est le
    # cas réel d'un fichier enregistré dans le mauvais encodage. Le lecteur doit
    # suivre les OCTETS, pas la déclaration, et le dire.
    menteur = ('<html><head><meta charset="utf-8"><title>Café</title></head>'
               '<body>œuf</body></html>').encode('cp1252')
    lu, encodage, note = devweb._decoder(menteur)
    verif(encodage in ('cp1252', 'iso-8859-15', 'iso-8859-1')
          and 'œuf' in lu,
          'une déclaration contredite par les octets ne casse pas la lecture '
          '(%r, %r)' % (encodage, lu[-30:]))

    rapport = devweb.auditer(contenu=menteur, cible='menteur.html')
    verif(rapport.get('ok') and rapport.get('encodage') != 'utf-8',
          'l’audit rend l’encodage réellement utilisé (%r)' % rapport.get('encodage'))
    verif(rapport.get('ok') and rapport.get('cible') == 'menteur.html',
          'un document mal encodé est audité jusqu’au bout')

    binaire = bytes(range(256))
    lu, encodage, note = devweb._decoder(binaire)
    verif(isinstance(lu, str) and encodage,
          'une suite d’octets quelconque rend un texte et un encodage, sans lever')
    verif(devweb._decoder('')[0] == '', 'un document vide rend une chaîne vide')
    verif(devweb._decoder(texte)[1] == 'utf-8',
          'une chaîne déjà décodée est rendue telle quelle')


# ------------------------------------------------------------------ inventaire --
def banc_inventaire(site):
    r = devweb.inventaire(chemin=site)
    verif(r['ok'], 'l’inventaire d’un projet réel répond ok')
    chemins = {p['chemin'] for p in r['pages']}
    verif(chemins == {'index.html'}, 'une seule page HTML est trouvée (%r)' % chemins)
    verif(r['page_accueil'] == 'index.html',
          'la page d’accueil est index.html (%r)' % r['page_accueil'])
    groupes = {c['groupe'] for c in r['categories']}
    verif({'html', 'css', 'javascript', 'images', 'autres'} <= groupes,
          'les catégories attendues sont présentes (%r)' % sorted(groupes))
    serveur = [c for c in r['categories'] if c['groupe'] == 'serveur']
    verif(serveur and serveur[0]['nombre'] == 1,
          '.htaccess est compté comme fichier de serveur (%r)' % serveur[:1])
    verif(r['ignores'] >= 2,
          'les dossiers cachés et node_modules sont écartés et comptés (%s)'
          % r['ignores'])
    verif(all('node_modules' not in p['chemin'] and not p['chemin'].startswith('.')
              for p in r['pages']),
          'aucun fichier ignoré ne figure dans les pages')
    # index.html, css/style.css, app.js, .htaccess, img/logo.png et LICENCE :
    # six fichiers utiles, .git/ et node_modules/ étant écartés.
    verif(r['nombre_fichiers'] == 6,
          'l’inventaire compte 6 fichiers utiles (%s)' % r['nombre_fichiers'])

    # Un fichier sans extension est classé, pas perdu.
    verif(r['nombre_fichiers'] >= 5 and r['octets'] > 0,
          'l’inventaire mesure un poids total (%s octets)' % r['octets'])

    refus = devweb.inventaire(chemin=os.path.join(site, 'absent'))
    verif(not refus['ok'], 'un dossier inexistant est refusé')
    verif(not devweb.inventaire(chemin=os.path.join(site, 'index.html'))['ok'],
          'un fichier n’est pas inventorié comme un dossier')


# ------------------------------------------------------- configuration d'en-têtes
def banc_en_tetes(site):
    chemin = os.path.join(site, 'index.html')
    r = devweb.auditer(chemin=chemin, racine=os.path.dirname(site))
    verif(r['ok'], 'l’audit d’un projet avec .htaccess en sous-dossier répond ok')
    constats = [c for a in r['audits'].values() for c in a]
    declares = [c for c in constats if c['code'] == 'en-tete-declare']
    verif(len(declares) == 2,
          'les deux en-têtes du .htaccess en sous-dossier sont trouvés (%d)'
          % len(declares))
    verif(any('site/.htaccess' in c['message'] or '.htaccess' in c['message']
              for c in declares),
          'le fichier qui déclare l’en-tête est nommé (%r)'
          % [c['message'][:70] for c in declares])
    # Cohérence entre les règles qui lisent le MÊME fait : ce .htaccess ne
    # déclare pas Referrer-Policy et la page n'a pas de meta referrer, donc le
    # constat est juste. Le test de cohérence est la converse : ajouter la meta
    # doit le faire disparaître, sinon deux règles liraient deux réalités.
    verif(any(c['code'] == 'referrer-non-defini' for c in constats),
          'l’absence de Referrer-Policy est signalée quand rien ne la déclare')
    avec_meta = open(chemin, encoding='utf8').read().replace(
        '<meta charset="utf-8">',
        '<meta charset="utf-8">\n<meta name="referrer" '
        'content="strict-origin-when-cross-origin">')
    r2 = devweb.auditer(contenu=avec_meta, cible='index.html',
                        racine=os.path.dirname(site), chemin=chemin)
    constats2 = [c for a in r2['audits'].values() for c in a]
    verif(not any(c['code'] == 'referrer-non-defini' for c in constats2),
          'une meta referrer fait disparaître le constat — les deux règles '
          'lisent bien le même fait')
    # La CSP est déclarée : aucune règle ne doit la dire absente.
    verif(not any(c['code'] == 'en-tete-non-declare'
                  and 'CONTENT-SECURITY-POLICY' in c['message'] for c in constats),
          'la CSP déclarée dans le sous-dossier n’est pas dite absente')
    verif(any(c['code'] == 'casse-differente' for c in constats),
          'une référence dont la casse diffère du fichier est signalée')
    verif(any(c['code'] == 'fichier-introuvable' for c in constats),
          'un lien cassé est signalé')
    verif(any(c['code'] == 'css-accolade-ouverte'
              and 'css/style.css' in c['message'] for c in constats),
          'l’erreur de la feuille liée nomme la feuille')


# ------------------------------------------------------------------ générateurs --
def banc_generateurs(site):
    r = devweb.generer('sri', {'chemin': os.path.join(site, 'app.js'),
                               'url': 'https://cdn.example/app.js'})
    verif(r['ok'], 'SRI sur un fichier local répond ok (%r)' % r.get('erreur'))
    verif('integrity="sha384-' in r['contenu'],
          'l’empreinte est présente dans la balise')
    verif('crossorigin="anonymous"' in r['contenu'],
          'crossorigin accompagne integrity')
    empreinte = base64.b64encode(
        __import__('hashlib').new('sha384', open(os.path.join(site, 'app.js'),
                                                 'rb').read()).digest()).decode()
    verif(empreinte in r['contenu'],
          'l’empreinte correspond au fichier, recalculée indépendamment')
    verif(not any('TÉLÉCHARGÉ' in n for n in r['notes']),
          'un fichier local ne prétend pas avoir été téléchargé')

    r2 = devweb.generer('sri', {'algorithme': 'sha256',
                                'chemin': os.path.join(site, 'app.js')})
    verif('sha256-' in r2['contenu'], 'l’algorithme demandé est respecté')
    # Un paramètre « choix » hors liste est ramené à sa valeur par défaut par la
    # façade AVANT d'atteindre le générateur : c'est le comportement voulu (une
    # interface ne propose que des valeurs valides, et une requête fabriquée ne
    # doit pas produire un fichier invalide). Ce n'est pas silencieux pour
    # autant : la réponse rend les paramètres réellement appliqués.
    r3 = devweb.generer('sri', {'algorithme': 'md5',
                                'chemin': os.path.join(site, 'app.js')})
    verif('sha384-' in r3['contenu']
          and r3['parametres']['algorithme'] == 'sha384',
          'un algorithme hors liste retombe sur sha384 et la réponse le montre '
          '(%r)' % r3.get('parametres', {}).get('algorithme'))
    r4 = devweb.generer('sri', {'chemin': os.path.join(site, 'absent.js')})
    verif(not r4['ok'] and 'introuvable' in (r4.get('erreur') or '').lower(),
          'un fichier absent est dit introuvable (%r)' % r4.get('erreur'))

    # Tous les générateurs, avec des paramètres réalistes : aucun ne doit
    # laisser de gabarit non rempli ni rendre un fichier vide.
    for generateur in devweb.capacites()['generateurs']:
        identifiant = generateur['id']
        if identifiant == 'sri':
            continue                              # déjà couvert, et il exige une entrée
        parametres = {'titre': 'Titre du banc', 'site': 'Banc', 'nom': 'Banc',
                      'description': 'Description du banc.', 'url': 'https://banc.fr/',
                      'image': 'https://banc.fr/i.jpg', 'domaine': 'banc.fr',
                      'csp': "default-src 'self'", 'urls': 'https://banc.fr/',
                      'chemin': os.path.join(site, 'app.js')}
        resultat = devweb.generer(identifiant, parametres)
        verif(resultat['ok'], 'le générateur %s réussit (%r)'
              % (identifiant, resultat.get('erreur')))
        if not resultat['ok']:
            continue
        verif('{{' not in resultat['contenu'] and '}}' not in resultat['contenu'],
              'le générateur %s ne laisse aucun gabarit' % identifiant)
        verif(len(resultat['contenu'].strip()) > 40,
              'le générateur %s rend un fichier substantiel' % identifiant)
        verif(resultat['octets'] == len(resultat['contenu'].encode('utf8')),
              'le générateur %s annonce le bon poids' % identifiant)
        if resultat['langage'] == 'json':
            try:
                json.loads(resultat['contenu'])
                valide = True
            except ValueError:
                valide = False
            verif(valide, 'le générateur %s rend un JSON valide' % identifiant)
        if resultat['langage'] == 'xml':
            import xml.etree.ElementTree as ET
            try:
                ET.fromstring(resultat['contenu'])
                valide = True
            except ET.ParseError:
                valide = False
            verif(valide, 'le générateur %s rend un XML valide' % identifiant)


# --------------------------------------------------------------------- journal --
def banc_journal():
    devweb.journal_vider('Banc des modules dev web')
    lot = {'entrees': [{'type': 'console', 'niveau': 'log', 'message': 'x'}]}
    r = devweb.capturer(json.dumps(lot))
    verif(r['acceptees'] == 1 and r['refusees'] == 0, 'une entrée valide est acceptée')
    r = devweb.capturer(json.dumps({'entrees': [{'type': 'invention'}]}))
    verif(r['refusees'] == 1 and r['acceptees'] == 0,
          'une entrée d’un type inconnu est refusée')
    r = devweb.capturer(json.dumps({'entrees': [{'type': 'console', 'niveau': 'log',
                                                 'message': 'x',
                                                 'champ_inconnu': 'secret'}]}))
    entree = devweb.journal(depuis=0, limite=500)['entrees'][-1]
    verif('champ_inconnu' not in entree,
          'un champ qui n’est pas dans le schéma est jeté, pas recopié')
    r = devweb.capturer('pas du json')
    verif(r['acceptees'] == 0 and r['erreur'], 'un corps non JSON est refusé en le disant')
    r = devweb.capturer(json.dumps([1, 2, 3]))
    verif(r['acceptees'] == 0 and r['erreur'], 'un tableau JSON est refusé')
    r = devweb.capturer(json.dumps({'entrees': 'pas-une-liste'}))
    verif(r['acceptees'] == 0 and r['erreur'], 'un lot sans liste est refusé')
    r = devweb.capturer('x' * (devweb_journal.MAX_CORPS + 10))
    verif(r['acceptees'] == 0 and 'volumineux' in r['erreur'],
          'un corps démesuré est refusé avant d’être analysé')

    # Un lot plus grand que la borne est tronqué ET le dit.
    gros = {'entrees': [{'type': 'console', 'niveau': 'log', 'message': 'm%d' % i}
                        for i in range(devweb_journal.MAX_LOT + 50)]}
    r = devweb.capturer(json.dumps(gros))
    verif(r['acceptees'] == devweb_journal.MAX_LOT,
          'un lot est tronqué à la borne (%s)' % r['acceptees'])
    verif('erreur' in r and 'tronqué' in r['erreur'],
          'la troncature du lot est annoncée')

    # Un message démesuré est recoupé, pas refusé.
    long = {'entrees': [{'type': 'console', 'niveau': 'log',
                         'message': 'y' * (devweb_journal.MAX_MESSAGE * 3)}]}
    devweb.capturer(json.dumps(long))
    derniere = devweb.journal(depuis=0, limite=1000)['entrees'][-1]
    verif(len(derniere['message']) <= devweb_journal.MAX_MESSAGE + 20,
          'un message démesuré est recoupé (%d)' % len(derniere['message']))

    # La suite d'identifiants permet une interrogation incrémentale sans trou.
    etat = devweb.journal(depuis=0, limite=3)
    verif(len(etat['entrees']) == 3 and etat['suivant'] == etat['entrees'][-1]['id'],
          'la limite est respectée et « suivant » pointe après la dernière entrée')
    suite = devweb.journal(depuis=etat['suivant'], limite=1000)
    verif(all(e['id'] > etat['suivant'] for e in suite['entrees']),
          'une interrogation incrémentale ne rend rien d’ancien')
    verif(suite['total'] == devweb.statistiques()['total'],
          'le total est cohérent entre journal() et statistiques()')

    # La borne du tampon : les entrées les plus anciennes tombent, et c'est compté.
    devweb.journal_vider()
    paquets = devweb_journal.MAX_ENTREES // devweb_journal.MAX_LOT + 3
    for i in range(paquets):
        devweb.capturer(json.dumps(
            {'entrees': [{'type': 'console', 'niveau': 'log', 'message': 'm%d' % j}
                         for j in range(devweb_journal.MAX_LOT)]}))
    stats = devweb.statistiques()
    verif(stats['total'] <= devweb_journal.MAX_ENTREES,
          'le tampon ne dépasse pas sa capacité (%s > %s)'
          % (stats['total'], devweb_journal.MAX_ENTREES))
    verif(stats['perdues'] > 0,
          'les entrées que le tampon a dû laisser tomber sont COMPTÉES (%s)'
          % stats['perdues'])
    lecture = devweb.journal(depuis=0, limite=5000)
    verif(lecture['perdues'] == stats['perdues'],
          'la lecture du journal annonce les mêmes pertes que les statistiques')
    devweb.journal_vider('Fin du banc journal')
    verif(devweb.statistiques()['total'] == 1,
          'vidanger le journal ne laisse que l’entrée système')


# -------------------------------------------------------------------- client ----
class _Gestionnaire(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        if self.path == '/entetes':
            self.send_response(200)
            self.send_header('Content-Type', 'text/plain; charset=utf-8')
            self.send_header('X-Frame-Options', 'DENY')
            self.send_header('Set-Cookie', 'a=1; HttpOnly')
            self.send_header('Set-Cookie', 'b=2; Secure')
            self.send_header('Content-Length', '2')
            self.end_headers()
            self.wfile.write(b'ok')
        elif self.path == '/redirige':
            self.send_response(301)
            self.send_header('Location', '/entetes')
            self.send_header('Content-Length', '0')
            self.end_headers()
        else:
            self.send_error(404)


def banc_client():
    serveur = http.server.ThreadingHTTPServer(('127.0.0.1', 0), _Gestionnaire)
    serveur.daemon_threads = True
    fil = threading.Thread(target=serveur.serve_forever, daemon=True)
    fil.start()
    base = 'http://127.0.0.1:%d' % serveur.server_port
    try:
        r = devweb.requeter(base + '/entetes')
        verif(r['ok'] and r['statut'] == 200, 'une requête locale réelle aboutit')
        verif(r['locale'], 'une adresse 127.0.0.1 est dite locale')
        verif(r['entetes']['set-cookie'] == ['a=1; HttpOnly', 'b=2; Secure'],
              'deux en-têtes homonymes sont tous rendus (%r)'
              % r['entetes'].get('set-cookie'))
        verif(r['entetes']['x-frame-options'] == 'DENY',
              'les noms d’en-têtes sont normalisés en minuscules')
        r = devweb.requeter(base + '/redirige', suivre=False)
        verif(r['statut'] == 301 and len(r['chaine']) == 1
              and r['entetes']['location'] == '/entetes',
              'suivre=False s’arrête sur la redirection et montre Location')
        r = devweb.requeter(base + '/redirige')
        verif(r['statut'] == 200 and len(r['chaine']) == 2
              and r['redirections'] == 1,
              'par défaut la redirection est suivie et la chaîne conservée')
        r = devweb.requeter(base + '/entetes', methode='HEAD')
        verif(r['statut'] in (200, 501),
              'une requête HEAD est acceptée (%r)' % r.get('erreur'))
        # L'audit des liens utilise ce chemin : un serveur qui refuse HEAD ne
        # doit pas faire conclure à un lien cassé.
        r = devweb.requeter('http://127.0.0.1:1/x')
        verif(not r['ok'] and r['erreur'] and 'écoute' in r['erreur'],
              'un port fermé est expliqué (%r)' % r['erreur'])
        # L'aperçu texte ne doit jamais lever, même sur une réponse vide.
        verif(isinstance(devweb.client_apercu(r) if hasattr(devweb, 'client_apercu')
                         else devweb.devweb_client.apercu(r), str),
              'un aperçu texte est rendu pour une réponse en échec')
    finally:
        serveur.shutdown()
        serveur.server_close()


def main():
    depart = time.monotonic()
    banc_encodages()
    racine, site = construire_projet()
    try:
        banc_inventaire(site)
        banc_en_tetes(site)
        banc_generateurs(site)
        banc_journal()
        banc_client()
    finally:
        shutil.rmtree(racine, ignore_errors=True)
    sys.stderr.write('\nsmoke_devweb : %d contrôles, %d échec(s), %.1f s\n'
                     % (OK + len(ECHECS), len(ECHECS), time.monotonic() - depart))
    if ECHECS:
        for echec in ECHECS:
            sys.stderr.write('  - %s\n' % echec)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
