/* Banc du script de capture injecté dans l'aperçu (4.0.0).
 *
 * Le script capturé est celui que devweb_journal.py injecte RÉELLEMENT dans les
 * pages servies par l'aperçu : ce banc l'exécute tel quel, dans un contexte vm,
 * avec des stubs pour window, console, document, performance, fetch, location,
 * setTimeout et setInterval. Aucun fichier intermédiaire, aucune copie : si le
 * script injecté change, le banc teste le nouveau.
 *
 * Pourquoi ce banc existe
 * -----------------------
 * Ce script tourne DANS LA PAGE DE L'UTILISATEUR. Une faute ici ne casse pas le
 * panneau : elle casse la page observée, ou pire, elle la casse silencieusement
 * (un message console perdu, un envoi qui boucle, une exception non interceptée
 * qui apparaît dans la console de l'utilisateur et lui fait croire que SON code
 * est fautif). Les propriétés vérifiées sont donc d'abord des propriétés de
 * non-nuisance :
 *
 *   1. console.* appelle toujours la fonction d'origine, avec les arguments
 *      D'ORIGINE, le bon `this`, et rend sa valeur de retour ;
 *   2. rien ne lève vers la page : un objet circulaire, un symbole, un nœud du
 *      DOM, une méthode absente, un fetch en échec — tout est avalé ;
 *   3. le trafic de la capture ne se journalise pas lui-même (sinon chaque envoi
 *      produirait une entrée réseau, qui produirait un envoi…) ;
 *   4. un envoi en cours bloque le suivant : pas deux lots simultanés, pas de
 *      boucle de renvoi quand le serveur ne répond pas ;
 *   5. le script est idempotent : la même page servie deux fois, ou le script
 *      injecté deux fois, ne double pas chaque message.
 *
 * Lancer :  node tests/smoke_devweb_journal.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { execFileSync } = require('child_process');

const ICI = __dirname;
const MODULE = path.join(ICI, '..', 'devweb_journal.py');

/* Le script est extrait du module Python qui le porte : c'est la seule façon de
 * tester ce qui est réellement injecté. */
const source = execFileSync('python3', ['-c',
  'import sys; sys.path.insert(0, ' + JSON.stringify(path.dirname(MODULE)) + ');' +
  'import devweb_journal; sys.stdout.write(devweb_journal.SCRIPT_CAPTURE)'],
  { encoding: 'utf8' });

let OK = 0;
let N = 0;
const echecs = [];
function verifier(titre, obtenu, attendu) {
  N += 1;
  const a = JSON.stringify(obtenu) === undefined ? String(obtenu) : JSON.stringify(obtenu);
  const b = JSON.stringify(attendu) === undefined ? String(attendu) : JSON.stringify(attendu);
  if (a === b) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + a.slice(0, 260) + '\n      attendu : ' + b.slice(0, 260));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }
function faux(titre, condition) { verifier(titre, !!condition, false); }
function contient(titre, texte, morceau) {
  N += 1;
  if (String(texte || '').indexOf(morceau) >= 0) OK += 1;
  else echecs.push(titre + '\n      « ' + morceau + ' » absent de : ' + String(texte || '').slice(0, 260));
}

function creerEnvironnement(opts) {
  const options = opts || {};
  const envois = [];
  const timeouts = [];
  const intervalles = [];
  const ecouteursWindow = {};
  const ecouteursDocument = {};
  const originaux = {};
  const entreesConsole = [];

  const niveaux = options.niveaux || ['log', 'info', 'warn', 'error', 'debug', 'trace'];
  const consoleStub = {};
  niveaux.forEach(n => {
    originaux[n] = function () {
      entreesConsole.push({ niveau: n, args: Array.prototype.slice.call(arguments),
        this: this === consoleStub });
      return 'retour-' + n;
    };
    consoleStub[n] = originaux[n];
  });

  const performanceStub = {
    entrees: { resource: [], navigation: [] },
    getEntriesByType(t) { return this.entrees[t] || []; },
  };

  const window = {
    addEventListener(type, fn, capture) {
      (ecouteursWindow[type] = ecouteursWindow[type] || []).push({ fn, capture });
    },
    removeEventListener() {},
    performance: options.sansPerformance ? undefined : performanceStub,
    location: { href: 'http://127.0.0.1:4321/site/index.html' },
    innerWidth: 1200, innerHeight: 800,
  };
  window.window = window;
  window.self = window;

  function fetchStub(url, o) {
    const corps = (() => { try { return JSON.parse(o.body); } catch (e) { return null; } })();
    envois.push({ url: String(url), methode: o && o.method, corps,
      keepalive: !!(o && o.keepalive), credentials: o && o.credentials,
      entetes: (o && o.headers) || {} });
    if (options.fetchEchoue) return Promise.reject(new Error('réseau coupé'));
    if (options.fetchLent) return new Promise(() => {});          // ne répond jamais
    return Promise.resolve({ ok: true, status: 200 });
  }

  const documentStub = {
    addEventListener(type, fn) { (ecouteursDocument[type] = ecouteursDocument[type] || []).push(fn); },
    removeEventListener() {},
    readyState: 'loading',
  };

  const sandbox = {
    window, document: documentStub, console: consoleStub, location: window.location,
    performance: performanceStub, fetch: fetchStub,
    setTimeout: (fn, ms) => { timeouts.push({ fn, ms }); return timeouts.length; },
    setInterval: (fn, ms) => { intervalles.push({ fn, ms }); return intervalles.length; },
    clearTimeout: () => {}, clearInterval: () => {},
    Date, Object, Array, JSON, Math, String, Number, Boolean, Error, TypeError, RegExp, Symbol,
    Promise, isNaN, parseInt, parseFloat,
  };
  if (options.avecNode) {
    sandbox.Node = function Node() {};
    sandbox.Node.prototype = {};
  }
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;
  vm.createContext(sandbox);

  let erreur = null;
  try { vm.runInContext(source, sandbox, { filename: 'script-capture.js' }); }
  catch (e) { erreur = e; }

  function emettreWindow(type, champs) {
    const ev = Object.assign({ type }, champs || {});
    for (const e of (ecouteursWindow[type] || []).slice()) e.fn(ev);
    return ev;
  }
  function emettreDocument(type, champs) {
    const ev = Object.assign({ type }, champs || {});
    for (const fn of (ecouteursDocument[type] || []).slice()) fn(ev);
    return ev;
  }
  function attendre(n) {
    let p = Promise.resolve();
    for (let i = 0; i < (n || 10); i++) p = p.then(() => {});
    return p;
  }
  function viderTimeouts() {
    let garde = 0;
    while (timeouts.length && garde < 200) {
      const t = timeouts.shift();
      garde += 1;
      try { t.fn(); } catch (e) { echecs.push('un minuteur du script a levé : ' + e.message); }
    }
  }
  function tick(n) {
    viderTimeouts();
    return attendre(n);
  }
  function lancerIntervalles() {
    for (const i of intervalles.slice()) {
      try { i.fn(); } catch (e) { echecs.push('un intervalle du script a levé : ' + e.message); }
    }
  }
  function derniersEnvois() { return envois; }
  function entreesEnvoyees() {
    const toutes = [];
    envois.forEach(e => { if (e.corps && Array.isArray(e.corps.entrees)) toutes.push.apply(toutes, e.corps.entrees); });
    return toutes;
  }
  return { sandbox, window, console: consoleStub, originaux, entreesConsole, envois,
    derniersEnvois, entreesEnvoyees, emettreWindow, emettreDocument, tick, viderTimeouts,
    lancerIntervalles, timeouts, intervalles, erreur, performance: performanceStub,
    ecouteursWindow, document: documentStub };
}

async function principal() {
  verifier('le script de capture est extrait du module Python', source.length > 4000, true);
  contient('le script porte le marqueur d’idempotence', source, '__psDevwebCapture');
  contient('le script poste sur une adresse relative', source, "'/__ps_devweb_capture'");
  faux('le script ne construit aucune adresse absolue', /https?:\/\/[^'"\s]*__ps_devweb/.test(source));

  /* ------------------------------------------------- 1. chargement et console */
  const env = creerEnvironnement({ avecNode: true });
  verifier('le script s’exécute sans lever', env.erreur, null);
  vrai('le marqueur d’idempotence est posé', env.window.__psDevwebCapture);
  verifier('un seul intervalle de collecte est installé', env.intervalles.length, 1);
  ['log', 'info', 'warn', 'error', 'debug', 'trace'].forEach(n => {
    vrai('console.' + n + ' est enveloppé', env.console[n] !== env.originaux[n]);
  });

  /* la fonction d'origine est appelée, avec les arguments d'origine */
  const objet = { a: 1 };
  const retour = env.console.log('bonjour', objet, 42);
  verifier('console.log rend la valeur de la fonction d’origine', retour, 'retour-log');
  verifier('la fonction d’origine a été appelée une fois', env.entreesConsole.length, 1);
  verifier('les arguments D’ORIGINE sont transmis, pas leur sérialisation',
    env.entreesConsole[0].args[0], 'bonjour');
  verifier('l’objet est transmis par référence', env.entreesConsole[0].args[1] === objet, true);
  verifier('`this` reste console', env.entreesConsole[0].this, true);

  /* chaque niveau porte son nom */
  env.console.warn('attention');
  env.console.error('cassé');
  env.console.trace('trace');
  await env.tick(4);
  env.viderTimeouts();
  await env.attendre ? null : null;
  await env.tick(4);
  const envoyees = env.entreesEnvoyees();
  vrai('des entrées ont été envoyées', envoyees.length >= 4);
  const parNiveau = {};
  envoyees.forEach(e => { parNiveau[e.niveau] = (parNiveau[e.niveau] || 0) + 1; });
  verifier('chaque niveau de console est journalisé avec son nom',
    ['log', 'warn', 'error', 'trace'].every(n => parNiveau[n] >= 1), true);
  verifier('toutes les entrées de console portent le type « console »',
    envoyees.every(e => e.type === 'console'), true);
  verifier('chaque entrée porte la page d’origine',
    envoyees[0].page, 'http://127.0.0.1:4321/site/index.html');
  vrai('chaque entrée porte un horodatage', envoyees[0].horodatage > 0);
  verifier('l’envoi vise la route de collecte', env.envois[0].url, '/__ps_devweb_capture');
  verifier('l’envoi est un POST', env.envois[0].methode, 'POST');
  verifier('l’envoi est marqué keepalive pour survivre au déchargement',
    env.envois[0].keepalive, true);
  verifier('l’envoi emporte le cookie d’aperçu', env.envois[0].credentials, 'same-origin');
  contient('l’envoi est déclaré comme JSON',
    JSON.stringify(env.envois[0].entetes), 'application/json');

  /* ------------------------------------------------------ 2. sérialisation --- */
  const env2 = creerEnvironnement({ avecNode: true });
  const circulaire = { nom: 'racine' };
  circulaire.moi = circulaire;
  let leve = null;
  try { env2.console.log(circulaire); } catch (e) { leve = e; }
  verifier('un objet circulaire ne lève pas dans la page', leve, null);
  const profond = { a: { b: { c: { d: { e: 1 } } } } };
  env2.console.log(profond);
  env2.console.log(new TypeError('type cassé'));
  env2.console.log(function maFonction() {});
  env2.console.log(Symbol('symbole'));
  env2.console.log([1, 2, 3].concat(new Array(30).fill(0)));
  const noeud = Object.create(env2.sandbox.Node.prototype);
  noeud.nodeType = 1; noeud.tagName = 'DIV'; noeud.id = 'x'; noeud.className = 'y';
  env2.console.log(noeud);
  env2.console.log('x'.repeat(9000));
  env2.console.log(undefined, null, 12n);
  await env2.tick(4);
  env2.viderTimeouts();
  await env2.tick(4);
  const lots2 = env2.entreesEnvoyees();
  contient('un cycle est dit circulaire', lots2[0].message, '[circulaire]');
  contient('une profondeur excessive est bornée', lots2[1].message, '{…}');
  contient('une Error est sérialisée avec son nom et son message',
    lots2[2].message, 'TypeError: type cassé');
  contient('une fonction est nommée', lots2[3].message, '[function maFonction]');
  contient('un symbole est rendu', lots2[4].message, 'symbole');
  /* 3 + 30 = 33 éléments ; le script en garde 20 et annonce les 13 restants.
   * Vérifier le nombre ajouté par le banc plutôt que le reste aurait été une
   * attente fausse qui passe par accident si la borne change. */
  contient('un long tableau est tronqué au reste près', lots2[5].message, '…13');
  contient('un nœud du DOM est rendu comme une balise', lots2[6].message, '<div id="x"');
  vrai('un message démesuré est coupé', lots2[7].message.length <= 4100);
  contient('une coupure est signalée', lots2[7].message, '[coupé]');
  verifier('undefined, null et bigint passent', lots2[8].message, 'undefined');

  /* ---------------------------------------------------------- 3. erreurs ----- */
  const env3 = creerEnvironnement({});
  env3.emettreWindow('error', { message: 'x n’est pas défini', filename: '/app.js',
    lineno: 12, colno: 4, error: { stack: 'ReferenceError: x is not defined\n at app.js:12:4' },
    target: env3.window });
  env3.emettreWindow('error', { target: { tagName: 'IMG', src: '/img/manquante.png' } });
  env3.emettreWindow('error', { target: { tagName: 'SCRIPT',
    src: '/__ps_devweb_capture' } });
  env3.emettreWindow('unhandledrejection', { reason: new Error('promesse cassée') });
  env3.emettreWindow('unhandledrejection', { reason: 'une chaîne' });
  await env3.tick(4);
  env3.viderTimeouts();
  await env3.tick(4);
  const lots3 = env3.entreesEnvoyees();
  const erreurScript = lots3.find(e => e.message.indexOf('x n’est pas défini') >= 0);
  vrai('une erreur de script est journalisée', erreurScript);
  verifier('l’erreur de script porte sa ligne', erreurScript.ligne, 12);
  verifier('l’erreur de script porte sa colonne', erreurScript.colonne, 4);
  verifier('l’erreur de script porte son fichier', erreurScript.url, '/app.js');
  contient('l’erreur de script porte sa pile', erreurScript.pile, 'ReferenceError');
  const ressource = lots3.find(e => e.ressource === '/img/manquante.png');
  vrai('une ressource qui ne charge pas est journalisée', ressource);
  contient('la ressource nomme sa balise', ressource.message, 'IMG');
  verifier('la ressource porte son initiateur', ressource.initiateur, 'img');
  faux('le trafic de la capture ne se journalise pas lui-même',
    lots3.some(e => String(e.ressource || '').indexOf('__ps_devweb') >= 0));
  const promesses = lots3.filter(e => e.message.indexOf('Promesse rejetée') >= 0);
  verifier('les deux rejets non interceptés sont journalisés', promesses.length, 2);
  contient('un rejet portant une Error est nommé', promesses[0].message, 'Error: promesse cassée');
  contient('un rejet portant une chaîne est rendu tel quel', promesses[1].message, 'une chaîne');

  /* -------------------------------------------------- 4. réseau et navigation */
  const env4 = creerEnvironnement({});
  env4.performance.entrees.resource = [
    { name: 'http://127.0.0.1:4321/style.css', startTime: 10, duration: 4.5,
      initiatorType: 'link', transferSize: 1200, encodedBodySize: 1100,
      decodedBodySize: 3000, responseStatus: 200 },
    { name: 'http://127.0.0.1:4321/__ps_inspecteur_js', startTime: 11, duration: 1 },
    { name: 'http://127.0.0.1:4321/app.js', startTime: 12, duration: 2 },
  ];
  env4.performance.entrees.navigation = [
    { duration: 320, responseStart: 60, requestStart: 40, domComplete: 300,
      loadEventEnd: 315, transferSize: 4200, decodedBodySize: 9000 },
  ];
  env4.lancerIntervalles();
  await env4.attendre ? null : null;
  await env4.tick(6);
  env4.viderTimeouts();
  await env4.tick(6);
  const lots4 = env4.entreesEnvoyees();
  const reseau = lots4.filter(e => e.type === 'reseau');
  verifier('les ressources sont journalisées', reseau.length, 2);
  faux('l’inspecteur visuel n’est pas journalisé comme une ressource du projet',
    reseau.some(e => String(e.ressource).indexOf('__ps_inspecteur') >= 0));
  const css = reseau.find(e => e.ressource.indexOf('style.css') >= 0);
  verifier('le poids transféré est repris', css.octets_transferes, 1200);
  verifier('le poids décompressé est repris', css.octets_decodes, 3000);
  verifier('le statut de la ressource est repris', css.statut, 200);
  verifier('la durée est reprise', css.duree, 4.5);
  verifier('l’initiateur est repris', css.initiateur, 'link');
  const nav = lots4.filter(e => e.type === 'navigation');
  verifier('la navigation est journalisée une fois', nav.length, 1);
  verifier('le TTFB est calculé, pas recopié', nav[0].ttfb, 20);
  verifier('le temps DOM est repris', nav[0].dom_complet, 300);
  /* la même ressource ne doit pas être renvoyée à chaque collecte */
  const avant = env4.entreesEnvoyees().length;
  env4.lancerIntervalles();
  await env4.tick(6);
  env4.viderTimeouts();
  await env4.tick(6);
  verifier('une ressource déjà vue n’est pas renvoyée',
    env4.entreesEnvoyees().length, avant);
  verifier('la navigation n’est pas renvoyée non plus',
    env4.entreesEnvoyees().filter(e => e.type === 'navigation').length, 1);
  /* une nouvelle ressource, elle, est prise */
  env4.performance.entrees.resource.push({ name: 'http://127.0.0.1:4321/logo.png',
    startTime: 40, duration: 8, initiatorType: 'img', transferSize: 900 });
  env4.lancerIntervalles();
  await env4.tick(6);
  env4.viderTimeouts();
  await env4.tick(6);
  vrai('une ressource apparue plus tard est journalisée',
    env4.entreesEnvoyees().some(e => String(e.ressource || '').indexOf('logo.png') >= 0));

  /* ------------------------------------------------------- 5. non-nuisance --- */
  const env5 = creerEnvironnement({ fetchEchoue: true });
  env5.console.log('un message');
  await env5.tick(4);
  env5.viderTimeouts();
  let rejetNonIntercepte = null;
  process.once('unhandledRejection', r => { rejetNonIntercepte = r; });
  await env5.attendre ? null : null;
  await env5.tick(8);
  verifier('un envoi en échec ne remonte pas à la page', rejetNonIntercepte, null);
  verifier('l’envoi a bien été tenté', env5.envois.length, 1);
  /* après un échec, la file est vidée : pas de boucle de renvoi */
  const envoisAvant = env5.envois.length;
  env5.lancerIntervalles();
  await env5.tick(6);
  env5.viderTimeouts();
  await env5.tick(6);
  verifier('un lot perdu n’est pas renvoyé indéfiniment', env5.envois.length, envoisAvant);

  /* un envoi en cours bloque le suivant */
  const env6 = creerEnvironnement({ fetchLent: true });
  env6.console.log('premier');
  await env6.tick(4);
  env6.viderTimeouts();
  await env6.tick(4);
  verifier('le premier lot est parti', env6.envois.length, 1);
  env6.console.log('second');
  env6.console.log('troisième');
  env6.viderTimeouts();
  await env6.tick(6);
  env6.lancerIntervalles();
  await env6.tick(6);
  verifier('un second lot ne part pas pendant que le premier est en vol',
    env6.envois.length, 1);

  /* ---------------------------------------------------------- 6. bornes ------ */
  const env7 = creerEnvironnement({});
  for (let i = 0; i < 400; i++) env7.console.log('message ' + i);
  await env7.tick(4);
  env7.viderTimeouts();
  await env7.tick(8);
  env7.lancerIntervalles();
  await env7.tick(8);
  const tailles = env7.envois.map(e => (e.corps && e.corps.entrees ? e.corps.entrees.length : 0));
  vrai('plusieurs lots sont nécessaires pour 400 messages', tailles.length >= 2);
  vrai('aucun lot ne dépasse la borne annoncée', tailles.every(t => t <= 60));
  const toutEnvoye = tailles.reduce((a, b) => a + b, 0);
  vrai('la file est bornée : tout n’est pas forcément envoyé, mais rien ne bloque',
    toutEnvoye > 0 && toutEnvoye <= 400);

  /* ------------------------------------------------------ 7. idempotence ----- */
  const env8 = creerEnvironnement({});
  const enveloppeLog = env8.console.log;
  let secondeErreur = null;
  try { vm.runInContext(source, env8.sandbox, { filename: 'script-capture.js (2e fois)' }); }
  catch (e) { secondeErreur = e; }
  verifier('une seconde exécution ne lève pas', secondeErreur, null);
  verifier('console.log n’est pas ré-enveloppé', env8.console.log === enveloppeLog, true);
  env8.console.log('une seule fois');
  verifier('la fonction d’origine n’est appelée qu’une fois', env8.entreesConsole.length, 1);
  verifier('un seul intervalle de collecte malgré deux exécutions',
    env8.intervalles.length, 1);

  /* ------------------------------------------- 8. robustesse aux stubs pauvres */
  const env9 = creerEnvironnement({ niveaux: ['log'], sansPerformance: true });
  verifier('un console réduit est géré sans lever', env9.erreur, null);
  faux('une méthode absente n’est pas enveloppée', env9.console.warn);
  let leve9 = null;
  try { env9.console.log('bonjour'); env9.lancerIntervalles(); } catch (e) { leve9 = e; }
  verifier('l’absence de performance ne casse ni la console ni la collecte', leve9, null);
  await env9.tick(6);
  env9.viderTimeouts();
  await env9.tick(6);
  verifier('le message est quand même journalisé sans performance',
    env9.entreesEnvoyees().length, 1);

  /* aucune fuite dans la portée globale : le script est une IIFE */
  const env10 = creerEnvironnement({});
  const clefs = Object.keys(env10.sandbox).filter(k =>
    ['window', 'self', 'globalThis', 'document', 'console', 'location', 'performance',
      'fetch', 'setTimeout', 'setInterval', 'clearTimeout', 'clearInterval',
      'Date', 'Object', 'Array', 'JSON', 'Math', 'String', 'Number', 'Boolean',
      'Error', 'TypeError', 'RegExp', 'Symbol', 'Promise', 'isNaN', 'parseInt',
      'parseFloat'].indexOf(k) < 0);
  verifier('aucune variable interne ne fuit dans la portée globale de la page',
    clefs, []);

  return echecs.length ? 1 : 0;
}

principal().then(code => {
  process.stderr.write('\nsmoke_devweb_journal : ' + N + ' contrôles, '
    + (N - OK) + ' échec(s)\n');
  if (echecs.length) {
    echecs.forEach(e => process.stderr.write('  ÉCHEC : ' + e + '\n'));
    process.exit(1);
  }
  process.exit(code);
}).catch(e => {
  process.stderr.write('Exception du banc : ' + (e && e.stack || e) + '\n');
  process.exit(1);
});
