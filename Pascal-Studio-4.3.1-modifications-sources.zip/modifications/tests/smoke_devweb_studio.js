/* Banc du panneau dev web (4.0.0).
 *
 * Ce banc exécute réellement devweb-studio.js dans le harnais DOM partagé, avec
 * un serveur simulé qui rend les vraies formes de réponse des routes
 * /api/devweb, /api/tree, /api/web/start et /api/create.
 *
 * Trois scénarios, parce que le panneau a trois façons de mal se comporter et
 * qu'une seule est bruyante :
 *
 *   A. l'hôte .ps-devweb-host n'existe pas (la barre latérale est fermée) :
 *      le script doit charger sans erreur et ne rien écrire dans le DOM ;
 *   B. les capacités sont INDISPONIBLES (modules devweb absents de l'image,
 *      route en échec) : c'est le cas dangereux. Un panneau qui reste vide ne
 *      dit rien, et l'utilisateur conclut que la fonctionnalité n'existe pas.
 *      Le banc vérifie que le panneau NOMME la raison ;
 *   C. tout fonctionne : chaque section est ouverte, exercée, et les requêtes
 *      réellement envoyées sont vérifiées champ par champ.
 *
 * Ce que le banc cherche en priorité, parce que ce sont les défauts déjà
 * rencontrés dans ce projet :
 *   - une requête envoyée avec un champ que le serveur ignore (une option
 *     d'audit inventée côté interface) ;
 *   - une réponse d'échec lue comme un succès (le serveur renvoie `error`,
 *     `erreur` ou `ok:false` selon la route — les trois doivent être vus) ;
 *   - un panneau qui se reconstruit en boucle via son propre MutationObserver ;
 *   - un déplacement de fenêtre qui exige une coordonnée absolue au lieu d'un
 *     delta relatif.
 *
 * Lancer :  node tests/smoke_devweb_studio.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'devweb-studio.js');
const source = fs.readFileSync(SCRIPT, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];
function serie(valeur) {
  const brut = JSON.stringify(valeur);
  return brut === undefined ? String(valeur) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = serie(obtenu) === serie(attendu);
  if (bon) OK += 1;
  else {
    echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 260)
      + '\n      attendu : ' + serie(attendu).slice(0, 260));
  }
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }
function faux(titre, condition) { verifier(titre, !!condition, false); }
function contient(titre, texte, morceau) {
  N += 1;
  if (String(texte || '').indexOf(morceau) >= 0) OK += 1;
  else echecs.push(titre + '\n      « ' + morceau + ' » absent de : '
    + String(texte || '').slice(0, 260));
}
function texte(noeud) { return noeud ? noeud.textContent : ''; }

/* ------------------------------------------------------- capacités réelles -- */
function capacites() {
  return {
    ok: true, version: '4.0.0',
    audits: [
      { id: 'accessibilite', nom: 'Accessibilité', resume: 'Noms accessibles, étiquettes.' },
      { id: 'securite', nom: 'Sécurité', resume: 'En-têtes, motifs dangereux.' },
      { id: 'liens', nom: 'Liens', resume: 'Références cassées.' },
      { id: 'poids', nom: 'Poids', resume: 'Octets et requêtes.' },
      { id: 'metadonnees', nom: 'Métadonnées', resume: 'Titre, description, partage.' },
      { id: 'validation', nom: 'Validation', resume: 'Structure du document.' },
    ],
    gravites: ['erreur', 'avertissement', 'info', 'ok'],
    generateurs: [
      { id: 'page-html5', nom: 'Page HTML5 complète', groupe: 'Pages', langage: 'html',
        fichier: 'index.html', description: 'Une page responsive.',
        parametres: [
          { nom: 'titre', libelle: 'Titre', type: 'texte', defaut: '' },
          { nom: 'hsts', libelle: 'HSTS', type: 'case', defaut: true },
          { nom: 'encadrement', libelle: 'Encadrement', type: 'choix',
            defaut: 'DENY', options: ['DENY', 'SAMEORIGIN'] },
          { nom: 'navigation', libelle: 'Menu', type: 'liste', defaut: 'Accueil|/' },
        ] },
      { id: 'sri', nom: 'Empreinte SRI', groupe: 'Sécurité', langage: 'html',
        fichier: 'sri.txt', description: 'Calcule une empreinte.', parametres: [] },
    ],
    groupes_generateurs: ['Pages', 'Sécurité'],
    extraits: [
      { id: 'centrer-flex', groupe: 'Mise en page', titre: 'Centrer un élément',
        langage: 'css', description: 'La forme la plus courte.', octets: 210 },
      { id: 'typographie-fluide', groupe: 'Mise en page', titre: 'Typographie fluide',
        langage: 'css', description: 'clamp()', octets: 300 },
    ],
    groupes_extraits: ['Mise en page', 'Accessibilité'],
    viewports: [
      { id: 'mobile-s', nom: 'Mobile étroit', categorie: 'mobile', largeur: 320, hauteur: 568, dpr: 2, note: '' },
      { id: 'tablette', nom: 'Tablette', categorie: 'tablette', largeur: 768, hauteur: 1024, dpr: 2, note: '' },
      { id: 'portable', nom: 'Portable', categorie: 'bureau', largeur: 1366, hauteur: 768, dpr: 1, note: '' },
      { id: 'bureau', nom: 'Bureau', categorie: 'bureau', largeur: 1600, hauteur: 900, dpr: 1, note: '' },
    ],
    en_tetes_securite: [{ nom: 'content-security-policy', gravite: 'avertissement',
      role: 'Limite les origines.', conseil: 'default-src \'self\'', https_uniquement: false }],
    motifs_dangereux: [{ code: 'eval', gravite: 'erreur', langage: 'javascript',
      raison: 'eval exécute une chaîne.', conseil: 'JSON.parse' }],
    journal: { marqueur: '__ps_devweb_capture', capacite: 3000,
      types: ['console', 'erreur', 'reseau', 'navigation', 'systeme'],
      statistiques: { total: 0 } },
  };
}

function rapportAudit() {
  const resume = {};
  ['accessibilite', 'securite', 'liens', 'poids', 'metadonnees', 'validation']
    .forEach(a => { resume[a] = { erreur: 1, avertissement: 1, info: 1, ok: 1, note: 80 }; });
  resume._global = { erreur: 6, avertissement: 6, info: 6, ok: 6 };
  return {
    ok: true, cible: 'site/index.html', genre: 'document', statut: 200,
    encodage: 'utf-8', notes: ['Une note de lecture.'], note_globale: 62,
    resume: resume,
    audits: {
      accessibilite: [{ code: 'img-sans-alt', gravite: 'erreur',
        message: 'Une image n’a pas d’attribut alt.', conseil: 'Décrivez l’image.',
        ligne: 12, colonne: 3, element: '<img src="x.png">', extrait: '<img src="x.png">' }],
      securite: [{ code: 'eval', gravite: 'erreur', message: 'eval trouvé dans app.js.',
        conseil: 'JSON.parse.', ligne: null, colonne: null, element: '', extrait: '' }],
      liens: [{ code: 'fichier-introuvable', gravite: 'erreur',
        message: '« manquant.png » est introuvable.', conseil: '', ligne: 18,
        colonne: null, element: '<img>', extrait: '' }],
      poids: [{ code: 'poids-total', gravite: 'ok', message: '3,0 Ko.', conseil: '',
        ligne: null, colonne: null, element: '', extrait: '' }],
      metadonnees: [{ code: 'og-incomplet', gravite: 'avertissement',
        message: 'Open Graph incomplet.', conseil: '', ligne: null, colonne: null,
        element: '', extrait: '' }],
      validation: [{ code: 'css-accolade-ouverte', gravite: 'erreur',
        message: 'Bloc { jamais fermé. Dans css/style.css, ligne 2.', conseil: '',
        ligne: null, colonne: null, element: '', extrait: '' }],
    },
    donnees: { poids: { total: 3047, transfere: 3047, requetes: 3 } },
  };
}

/* ------------------------------------------------------------ environnement -- */
function construire(opts) {
  const options = opts || {};
  const ctx = H.creerDocument();
  if (options.hote !== false) {
    const barre = new H.Noeud('aside');
    barre.className = 'sidebar';
    const hote = new H.Noeud('div');
    hote.className = 'ps-devweb-host';
    barre.append(hote);
    ctx.body.append(barre);
    ctx.rafraichir();
  }

  const appels = [];
  const stockage = {};
  let journalServeur = [
    { id: 1, type: 'systeme', niveau: 'info', message: 'Aperçu démarré : site/index.html',
      horodatage: 1700000000000, page: '' },
    { id: 2, type: 'console', niveau: 'log', message: 'bonjour', horodatage: 1700000001000,
      page: '/index.html', arguments: '["bonjour"]' },
    { id: 3, type: 'erreur', niveau: 'error', message: 'x est indéfini',
      horodatage: 1700000002000, url: '/app.js', ligne: 4, colonne: 2,
      pile: 'ReferenceError: x is not defined\n  at app.js:4:2' },
  ];
  let prochainId = 4;

  function reponse(ok, statut, corps) {
    return Promise.resolve({
      ok: ok, status: statut,
      json: () => Promise.resolve(JSON.parse(JSON.stringify(corps))),
      text: () => Promise.resolve(JSON.stringify(corps)),
    });
  }

  function fetchStub(url, o) {
    const u = String(url);
    const methode = (o && o.method) || 'GET';
    let corps = null;
    try { corps = o && o.body ? JSON.parse(o.body) : null; } catch (e) { corps = null; }
    appels.push({ url: u, methode, corps });

    if (u === '/api/tree') {
      return reponse(true, 200, { tree: [
        { name: 'site', path: 'site', type: 'folder', children: [
          { name: 'index.html', path: 'site/index.html', type: 'file' },
          { name: 'style.css', path: 'site/style.css', type: 'file' },
          { name: 'app.js', path: 'site/app.js', type: 'file' }] },
        { name: 'index.html', path: 'index.html', type: 'file' },
        { name: 'notes.md', path: 'notes.md', type: 'file' }] });
    }
    if (u === '/api/web/start') {
      if (!corps || !corps.path) return reponse(false, 400, { error: 'Chemin invalide' });
      return reponse(true, 200, { url: 'http://127.0.0.1:4321/__ps_auth/jeton/' + corps.path,
        mode: corps.mode || 'static', port: 4321, root: '/tmp/projet', path: corps.path });
    }
    if (u === '/api/web/stop') return reponse(true, 200, { ok: true });
    if (u === '/api/create') {
      if (options.creationRefusee) return reponse(false, 400, { error: 'Le fichier existe déjà.' });
      return reponse(true, 200, { ok: true });
    }
    if (u === '/api/save') return reponse(true, 200, { ok: true });

    if (u !== '/api/devweb') return reponse(false, 404, { error: 'Introuvable' });
    if (options.capacitesHS && methode === 'GET') {
      return reponse(false, 500, { error: 'Les modules devweb sont absents.' });
    }
    if (methode === 'GET') return reponse(true, 200, capacites());

    const action = corps && corps.action;
    if (action === 'journal') {
      const depuis = (corps && corps.depuis) || 0;
      const entrees = journalServeur.filter(e => e.id > depuis);
      return reponse(true, 200, { entrees: entrees,
        suivant: journalServeur.length ? journalServeur[journalServeur.length - 1].id : depuis,
        perdues: 0, total: journalServeur.length, sequence: prochainId - 1, capacite: 3000 });
    }
    if (action === 'journal-vider') {
      journalServeur = [{ id: 1, type: 'systeme', niveau: 'info',
        message: (corps && corps.raison) || '', horodatage: 1700000010000, page: '' }];
      prochainId = 2;
      return reponse(true, 200, { ok: true, total: 1, par_type: {} });
    }
    if (action === 'auditer') {
      if (!corps.path && !corps.url && !corps.contenu) {
        return reponse(true, 200, { ok: false, erreur: 'Aucune cible fournie.' });
      }
      if (options.auditEchoue) {
        return reponse(false, 400, { error: 'Le fichier est hors du projet.' });
      }
      const r = rapportAudit();
      if (corps.seulement) {
        const garde = {};
        corps.seulement.forEach(a => { if (r.audits[a]) garde[a] = r.audits[a]; });
        r.audits = garde;
      }
      if (corps.url) r.cible = corps.url;
      r.optionsRecues = corps.options || {};
      return reponse(true, 200, r);
    }
    if (action === 'generer') {
      const id = corps && corps.generateur;
      if (id === 'inconnu') return reponse(true, 200, { ok: false,
        erreur: 'Générateur « inconnu » inconnu. Les disponibles sont : page-html5.' });
      if (id === 'sri' && !(corps.parametres && (corps.parametres.chemin || corps.parametres.url))) {
        return reponse(true, 200, { ok: false,
          erreur: 'Aucune empreinte n’a pu être calculée. Renseignez un fichier local ou une URL.' });
      }
      return reponse(true, 200, { ok: true, id: id, nom: 'Page HTML5 complète',
        groupe: 'Pages', langage: 'html', fichier: 'index.html',
        contenu: '<!DOCTYPE html>\n<html lang="fr">\n<title>Titre du banc</title>\n</html>\n',
        notes: ['La description est un texte d’exemple : remplacez-le.'],
        parametres: (corps && corps.parametres) || {}, octets: 62 });
    }
    if (action === 'extraits') {
      if (corps && corps.extrait) {
        return reponse(true, 200, { ok: true, extrait: { id: corps.extrait,
          groupe: 'Mise en page', langage: 'css', titre: 'Centrer un élément',
          description: 'La forme la plus courte.',
          code: '.parent { display: grid; place-items: center; min-height: 100vh; }' } });
      }
      const q = ((corps && corps.recherche) || '').toLowerCase();
      const g = (corps && corps.groupe) || '';
      const liste = capacites().extraits.filter(e =>
        (!g || e.groupe === g) && (!q || (e.titre + e.description).toLowerCase().indexOf(q) >= 0));
      return reponse(true, 200, { ok: true, extraits: liste, groupes: ['Mise en page'] });
    }
    if (action === 'requeter') {
      if (!corps || !corps.url) return reponse(false, 400, { error: 'Adresse manquante.' });
      if (/^ftp:/i.test(corps.url)) return reponse(true, 200, { ok: false, url: corps.url,
        erreur: 'Le schéma « ftp » n’est pas accepté.', methode: corps.methode });
      return reponse(true, 200, { ok: true, url: corps.url, adresse_demandee: corps.url,
        methode: corps.methode || 'GET', statut: 200, raison: 'OK', locale: false,
        entetes: { 'content-type': 'application/json', 'set-cookie': ['a=1', 'b=2'] },
        corps: '{"ok":true}', base64: null, binaire: false, encodage: 'utf-8',
        octets: 11, tronque: false, duree_ms: 12.5, tls_verifie: true,
        chaine: [{ url: corps.url, statut: 200, raison: 'OK' }],
        apercu: 'GET ' + corps.url + ' → 200 OK' });
    }
    if (action === 'inventaire') {
      return reponse(true, 200, { ok: true, racine: '/tmp/projet', nombre_fichiers: 5,
        octets: 3122, nombre_pages: 2, page_accueil: 'site/index.html', ignores: 1,
        pages: [{ chemin: 'site/index.html', octets: 834, nom: 'index.html' },
          { chemin: 'index.html', octets: 210, nom: 'index.html' }],
        categories: [{ groupe: 'html', nombre: 2, octets: 1044, extensions: { html: 2 } },
          { groupe: 'css', nombre: 1, octets: 46, extensions: { css: 1 } }] });
    }
    if (action === 'inconnue') return reponse(false, 400, { error: 'Action dev web inconnue : inconnue' });
    return reponse(true, 200, capacites());
  }

  const fenetreEcouteurs = {};
  const fenetre = {
    addEventListener(type, fn) { (fenetreEcouteurs[type] = fenetreEcouteurs[type] || []).push(fn); },
    removeEventListener(type, fn) {
      const l = fenetreEcouteurs[type] || [];
      const i = l.indexOf(fn);
      if (i >= 0) l.splice(i, 1);
    },
    innerWidth: 1600, innerHeight: 1000,
    isSecureContext: options.pasSecurise ? false : true,
    location: { origin: 'http://127.0.0.1:8765', href: 'http://127.0.0.1:8765/' },
    open: (u, cible) => { fenetre.__ouverts = (fenetre.__ouverts || []).concat([{ url: u, cible }]); return null; },
    localStorage: {
      getItem: c => (Object.prototype.hasOwnProperty.call(stockage, c) ? stockage[c] : null),
      setItem: (c, v) => { stockage[c] = String(v); },
      removeItem: c => { delete stockage[c]; },
    },
  };
  fenetre.window = fenetre;
  if (options.pasDePSFM) fenetre.PSFMActivate = undefined;
  else fenetre.PSFMActivate = entree => { fenetre.__onglets = (fenetre.__onglets || []).concat([entree]); };

  const intervalles = [];
  const timeouts = [];
  const sandbox = {
    window: fenetre,
    document: ctx.document,
    navigator: { userAgent: 'Mozilla/5.0 (X11; Linux x86_64) Electron/33.4.11 PascalStudio/4.0.0',
      clipboard: { writeText: t => { fenetre.__presse = (fenetre.__presse || []).concat([t]); return Promise.resolve(); } } },
    localStorage: fenetre.localStorage,
    fetch: fetchStub,
    console,
    setTimeout: (fn, ms) => { timeouts.push({ fn, ms }); return timeouts.length; },
    setInterval: (fn, ms) => { intervalles.push({ fn, ms }); return intervalles.length; },
    clearInterval: id => { const i = intervalles.findIndex(x => x.id === id); if (i >= 0) intervalles.splice(i, 1); },
    clearTimeout: id => { const i = timeouts.findIndex(x => x.id === id); if (i >= 0) timeouts.splice(i, 1); },
    MutationObserver: H.MutationObserverStub,
    Promise, Map, Set, JSON, Math, Date, Object, Array, String, Number, Boolean, Error, RegExp,
    encodeURIComponent, decodeURIComponent, parseInt, parseFloat, isNaN,
  };
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;
  vm.createContext(sandbox);

  let erreur = null;
  try { vm.runInContext(source, sandbox, { filename: 'devweb-studio.js' }); }
  catch (e) { erreur = e; }
  ctx.rafraichir();

  function viderTimeouts() {
    let garde = 0;
    while (timeouts.length && garde < 60) {
      const t = timeouts.shift();
      garde += 1;
      try { t.fn(); } catch (e) { /* le panneau attrape ses erreurs */ }
      ctx.rafraichir();
    }
  }
  function ticks(n) {
    let p = Promise.resolve();
    for (let i = 0; i < (n || 24); i++) p = p.then(() => { viderTimeouts(); ctx.rafraichir(); });
    return p;
  }
  function emettreFenetre(type, champs) {
    const ev = Object.assign({ type }, champs || {});
    if (typeof ev.preventDefault !== 'function') ev.preventDefault = () => {};
    if (typeof ev.stopPropagation !== 'function') ev.stopPropagation = () => {};
    for (const fn of (fenetreEcouteurs[type] || []).slice()) fn(ev);
    ctx.rafraichir();
    return ev;
  }
  function ajouterEntrees(nouvelles) {
    nouvelles.forEach(e => { e.id = prochainId++; journalServeur.push(e); });
    return journalServeur.length;
  }
  function sonder() {
    /* Les intervalles du banc ne se déclenchent pas seuls : c'est au banc de
     * décider quand la sonde tourne, sinon il testerait un horodatage et non un
     * comportement. */
    for (const i of intervalles.slice()) {
      try { i.fn(); } catch (e) { /* le panneau attrape ses erreurs */ }
    }
    ctx.rafraichir();
  }
  const hote = () => ctx.document.querySelector('.ps-devweb-host');
  const panneau = () => ctx.document.querySelector('.psdw-panneau');
  const statut = () => texte(ctx.document.querySelector('.psdw-statut'));
  const fenetreFlottante = () => ctx.document.querySelector('.psdw-fenetre');
  function clic(noeud, champs) {
    if (!noeud) {
      N += 1;
      echecs.push('clic sur un nœud absent (un bouton attendu n’a pas été rendu)');
      return;
    }
    noeud.dispatchEvent(Object.assign({ type: 'click', target: noeud, currentTarget: noeud }, champs || {}));
    ctx.rafraichir();
  }
  function sections() {
    return (ctx.document.querySelectorAll('.psdw-section-tete') || [])
      .map(b => texte(b.querySelector('.psdw-section-titre')));
  }
  function ouvrirSection(id) {
    const tetes = ctx.document.querySelectorAll('.psdw-section-tete') || [];
    const ordre = ['apercu', 'journal', 'audits', 'generer', 'extraits', 'requetes', 'projet'];
    const i = ordre.indexOf(id);
    if (i < 0 || !tetes[i]) throw new Error('section introuvable : ' + id);
    clic(tetes[i]);
  }
  function boutons(nom) {
    return (ctx.document.querySelectorAll('.psdw-btn') || []).filter(b => texte(b) === nom);
  }
  function dernierAppel(url, action) {
    const filtres = appels.filter(a => a.url === url && (!action || (a.corps && a.corps.action === action)));
    return filtres.length ? filtres[filtres.length - 1] : null;
  }
  return { ctx, sandbox, fenetre, appels, intervalles, timeouts, erreur, ticks, viderTimeouts,
    emettreFenetre, hote, panneau, statut, fenetreFlottante, clic, sections, ouvrirSection,
    boutons, dernierAppel, stockage, journal: () => journalServeur,
    ajouterEntrees, sonder };
}

/* ---------------------------------------------------------------- scénario A */
async function scenarioA() {
  const env = construire({ hote: false });
  verifier('A. le script charge sans hôte', env.erreur, null);
  await env.ticks(16);
  verifier('A. rien n’est écrit dans le DOM sans hôte',
    (env.ctx.document.querySelectorAll('.psdw-panneau') || []).length, 0);
  vrai('A. l’API du panneau est exportée', env.sandbox.window.PSDevWeb);
  verifier('A. aucune requête n’est envoyée sans hôte', env.appels.length, 0);
  const etat = env.sandbox.window.PSDevWeb.etat();
  verifier('A. l’état dit que l’hôte est absent', etat.hote, false);
}

/* ---------------------------------------------------------------- scénario B */
async function scenarioB() {
  const env = construire({ capacitesHS: true });
  verifier('B. le script charge même si les capacités sont indisponibles', env.erreur, null);
  await env.ticks(10);
  const panneau = env.panneau();
  vrai('B. un panneau est quand même rendu', panneau);
  const brut = texte(panneau);
  contient('B. le panneau NOMME la raison de l’indisponibilité', brut,
    'Les modules devweb sont absents');
  contient('B. le panneau dit quoi faire', brut, 'devweb');
  faux('B. le panneau ne reste pas vide', brut.trim().length < 10);
  faux('B. aucune section n’est proposée sans capacités',
    (env.ctx.document.querySelectorAll('.psdw-section-tete') || []).length);
}

/* ---------------------------------------------------------------- scénario C */
async function scenarioC() {
  const env = construire({});
  verifier('C. le script charge', env.erreur, null);
  await env.ticks(12);

  /* --- structure du panneau ------------------------------------------------ */
  vrai('C. le panneau est rendu dans l’hôte', env.panneau());
  verifier('C. les sept sections sont proposées', env.sections(),
    ['Aperçu', 'Journal de la page', 'Audits', 'Générer', 'Extraits', 'Requêtes HTTP', 'Projet']);
  contient('C. la zone d’état est initialisée', env.statut(), 'Prêt');
  vrai('C. les capacités ont été lues', env.dernierAppel('/api/devweb'));
  verifier('C. les capacités sont lues en GET', env.dernierAppel('/api/devweb').methode, 'GET');
  verifier('C. toutes les sections sont fermées au départ',
    (env.ctx.document.querySelectorAll('.psdw-section-corps') || [])
      .filter(c => !c.hidden).length, 0);
  vrai('C. l’arbre du projet est lu pour le sélecteur de fichiers',
    env.dernierAppel('/api/tree'));

  /* --- idempotence : attach() est rappelé toutes les 2 s ------------------- */
  const avant = (env.ctx.document.querySelectorAll('.psdw-panneau') || []).length;
  env.sandbox.window.PSDevWeb.ouvrir();
  await env.ticks(14);
  verifier('C. un second rendu ne duplique pas le panneau',
    (env.ctx.document.querySelectorAll('.psdw-panneau') || []).length, avant);

  /* --- journal ------------------------------------------------------------- */
  env.ouvrirSection('journal');
  await env.ticks(18);
  const entrees = env.ctx.document.querySelectorAll('.psdw-entree') || [];
  verifier('C. les entrées du journal sont rendues', entrees.length, 3);
  /* La liste est rendue de la plus récente à la plus ancienne : chercher un
   * message à une position fixe testerait l'ordre d'affichage, pas le contenu. */
  const brutJournal = entrees.map(texte).join(' | ');
  contient('C. une entrée porte son message', brutJournal, 'Aperçu démarré');
  contient('C. une entrée porte son type', brutJournal, 'console');
  contient('C. l’entrée la plus récente est affichée en premier',
    texte(entrees[0]), 'x est indéfini');
  vrai('C. une sonde périodique est installée', env.intervalles.length >= 1);
  const corps = env.ctx.document.querySelector('.psdw-corps-journal');
  const filtres = (corps.querySelectorAll('.psdw-filtre') || []).map(b => texte(b));
  vrai('C. les filtres du journal sont proposés', filtres.length >= 6);
  vrai('C. le filtre « Problèmes » existe', filtres.some(t => t.indexOf('Problèmes') === 0));

  /* le filtre « erreur » ne garde que les erreurs */
  const boutonErreur = (corps.querySelectorAll('.psdw-filtre') || [])
    .find(b => texte(b).indexOf('erreur') === 0);
  env.clic(boutonErreur);
  await env.ticks(2);
  verifier('C. le filtre par type ne garde que les entrées de ce type',
    (env.ctx.document.querySelectorAll('.psdw-entree') || []).length, 1);
  contient('C. l’entrée conservée est l’erreur',
    texte(env.ctx.document.querySelector('.psdw-entree')), 'x est indéfini');

  /* le détail d'une entrée ouvre la fenêtre flottante avec la pile */
  env.clic(env.ctx.document.querySelector('.psdw-entree'));
  await env.ticks(2);
  vrai('C. le détail d’une entrée ouvre la fenêtre flottante', env.fenetreFlottante());
  contient('C. le détail montre la pile d’appel',
    texte(env.fenetreFlottante()), 'ReferenceError');
  contient('C. le détail montre la ligne', texte(env.fenetreFlottante()), 'ligne');

  /* vider le journal passe par le serveur */
  env.sandbox.window.PSDevWeb.ouvrir('journal');
  await env.ticks(14);
  const vider = env.boutons('Vider')[0];
  vrai('C. un bouton « Vider » existe', vider);
  env.clic(vider);
  await env.ticks(16);
  const appelVide = env.dernierAppel('/api/devweb', 'journal-vider');
  vrai('C. vider le journal appelle le serveur', appelVide);
  contient('C. la raison du vidage est transmise', appelVide.corps.raison, 'panneau dev web');

  /* --- aperçu -------------------------------------------------------------- */
  env.ouvrirSection('apercu');
  await env.ticks(16);
  const champ = env.ctx.document.querySelector('.psdw-corps-apercu .psdw-input');
  vrai('C. un champ de fichier est proposé', champ);
  const selecteur = env.ctx.document.querySelector('.psdw-corps-apercu .psdw-select');
  vrai('C. le sélecteur de fichiers est peuplé depuis /api/tree',
    selecteur && (selecteur.querySelectorAll('option') || []).length > 1);
  const optionsFichiers = (selecteur.querySelectorAll('option') || []).map(o => o.value);
  vrai('C. le sélecteur ne propose que des pages et des feuilles',
    optionsFichiers.indexOf('notes.md') < 0 && optionsFichiers.indexOf('site/index.html') >= 0);

  champ.value = 'site/index.html';
  env.clic(env.boutons('Démarrer')[0]);
  await env.ticks(18);
  const appelStart = env.dernierAppel('/api/web/start');
  vrai('C. démarrer l’aperçu appelle /api/web/start', appelStart);
  verifier('C. le chemin choisi est transmis', appelStart.corps.path, 'site/index.html');
  verifier('C. le mode est déduit du fichier', appelStart.corps.mode, 'static');
  contient('C. l’adresse de l’aperçu est affichée', env.statut(), '127.0.0.1:4321');
  vrai('C. l’état du panneau connaît l’aperçu',
    env.sandbox.window.PSDevWeb.apercu() && env.sandbox.window.PSDevWeb.apercu().port === 4321);
  vrai('C. un bouton « Arrêter » apparaît', env.boutons('Arrêter').length >= 1);
  vrai('C. un bouton « Auditer cette page » apparaît',
    env.boutons('Auditer cette page').length >= 1);

  /* fenêtre d'aperçu : iframe + viewport */
  env.clic(env.boutons('Fenêtre d’aperçu')[0]);
  await env.ticks(14);
  const cadre = env.ctx.document.querySelector('#psdw-cadre');
  vrai('C. la fenêtre d’aperçu contient un cadre', cadre);
  verifier('C. le cadre pointe sur l’adresse de l’aperçu',
    cadre.getAttribute('src').indexOf('/__ps_auth/jeton/') >= 0, true);
  contient('C. le cadre est isolé par sandbox', cadre.getAttribute('sandbox') || '', 'allow-scripts');
  contient('C. le cadre autorise la même origine, nécessaire à la collecte du journal',
    cadre.getAttribute('sandbox') || '', 'allow-same-origin');
  verifier('C. le viewport par défaut est appliqué au cadre',
    cadre.style.width, '1366px');
  const selectVp = env.fenetreFlottante().querySelector('.psdw-select');
  vrai('C. le sélecteur de viewport est dans la fenêtre d’aperçu', selectVp);
  verifier('C. les viewports sont regroupés par catégorie',
    (selectVp.querySelectorAll('optgroup') || []).length, 3);
  selectVp.value = 'mobile-s';
  selectVp.dispatchEvent({ type: 'change', target: selectVp });
  await env.ticks(2);
  verifier('C. choisir un viewport redimensionne le cadre, pas la fenêtre',
    cadre.style.width, '320px');

  /* --- audits -------------------------------------------------------------- */
  env.ouvrirSection('audits');
  await env.ticks(14);
  const champAudit = env.ctx.document.querySelector('.psdw-corps-audits .psdw-input');
  champAudit.value = 'site/index.html';
  const cases = env.ctx.document.querySelectorAll('.psdw-audit-case') || [];
  verifier('C. une case par audit est proposée', cases.length, 6);
  cases[1].checked = false;                      // on décoche « Sécurité »
  env.clic(env.boutons('Auditer le fichier')[0]);
  await env.ticks(18);
  const appelAudit = env.dernierAppel('/api/devweb', 'auditer');
  vrai('C. l’audit est envoyé', appelAudit);
  verifier('C. l’audit porte sur le chemin choisi', appelAudit.corps.path, 'site/index.html');
  verifier('C. un audit décoché n’est pas demandé',
    appelAudit.corps.seulement, ['accessibilite', 'liens', 'poids', 'metadonnees', 'validation']);
  faux('C. aucune option inconnue du serveur n’est envoyée',
    Object.keys(appelAudit.corps.options || {}).some(k => ['verifier_distant', 'delai_distant'].indexOf(k) < 0));
  contient('C. la note globale est annoncée', env.statut(), '62');
  vrai('C. le rapport s’ouvre dans la fenêtre flottante', env.fenetreFlottante());
  const constats = env.ctx.document.querySelectorAll('.psdw-constat') || [];
  verifier('C. les constats de l’audit restreint sont rendus', constats.length, 5);
  contient('C. un constat montre son message', texte(constats[0]), 'alt');
  contient('C. un constat montre son conseil', texte(env.fenetreFlottante()), 'Décrivez');
  contient('C. un constat montre son code', texte(env.fenetreFlottante()), 'img-sans-alt');
  contient('C. la note d’encodage de lecture est reprise',
    texte(env.fenetreFlottante()), 'Une note de lecture');
  /* le filtre par gravité */
  const filtreErreur = (env.fenetreFlottante().querySelectorAll('.psdw-filtre') || [])
    .find(b => texte(b) === 'erreur');
  vrai('C. le rapport propose un filtre par gravité', filtreErreur);
  env.clic(filtreErreur);
  await env.ticks(2);
  const apresFiltre = env.ctx.document.querySelectorAll('.psdw-constat') || [];
  vrai('C. le filtre par gravité réduit la liste',
    apresFiltre.length > 0 && apresFiltre.length < constats.length);
  vrai('C. tous les constats restants sont des erreurs',
    (env.ctx.document.querySelectorAll('.psdw-c-erreur') || []).length === apresFiltre.length);

  /* un échec d'audit doit être dit, pas avalé */
  const envEchec = construire({ auditEchoue: true });
  await envEchec.ticks(12);
  envEchec.ouvrirSection('audits');
  await envEchec.ticks(14);
  envEchec.ctx.document.querySelector('.psdw-corps-audits .psdw-input').value = 'x.html';
  envEchec.clic(envEchec.boutons('Auditer le fichier')[0]);
  await envEchec.ticks(18);
  if (process.env.PSDW_DEBUG) {
    console.error('DEBUG échec audit : statut=', JSON.stringify(envEchec.statut()),
      'appels=', JSON.stringify(envEchec.appels.map(a => a.url + ':' + (a.corps && a.corps.action))));
  }
  contient('C. un refus du serveur est affiché tel quel', envEchec.statut(),
    'hors du projet');

  /* --- générateurs --------------------------------------------------------- */
  env.ouvrirSection('generer');
  await env.ticks(14);
  const lignes = env.ctx.document.querySelectorAll('.psdw-corps-generer .psdw-ligne') || [];
  verifier('C. les générateurs sont listés', lignes.length, 2);
  contient('C. les générateurs sont groupés', texte(env.ctx.document.querySelector('.psdw-corps-generer')), 'Pages');
  env.clic(lignes[0]);
  await env.ticks(14);
  const forme = env.fenetreFlottante().querySelector('.psdw-forme');
  vrai('C. le formulaire du générateur est rendu', forme);
  verifier('C. un champ par paramètre est rendu',
    (forme.querySelectorAll('.psdw-param') || []).length, 4);
  vrai('C. un paramètre « case » devient une case à cocher',
    forme.querySelector('#psdw-p-hsts') && forme.querySelector('#psdw-p-hsts').checked === true);
  vrai('C. un paramètre « choix » devient un menu déroulant',
    forme.querySelector('#psdw-p-encadrement') &&
    (forme.querySelector('#psdw-p-encadrement').querySelectorAll('option') || []).length === 2);
  vrai('C. un paramètre « liste » devient une zone de texte',
    forme.querySelector('#psdw-p-navigation').tagName === 'TEXTAREA');
  forme.querySelector('#psdw-p-titre').value = 'Titre du banc';
  env.clic((forme.querySelectorAll('.psdw-btn') || []).find(b => texte(b) === 'Générer'));
  await env.ticks(18);
  const appelGen = env.dernierAppel('/api/devweb', 'generer');
  vrai('C. la génération est envoyée', appelGen);
  verifier('C. l’identifiant du générateur est transmis', appelGen.corps.generateur, 'page-html5');
  verifier('C. la valeur saisie est transmise', appelGen.corps.parametres.titre, 'Titre du banc');
  verifier('C. une case à cocher est transmise comme booléen',
    appelGen.corps.parametres.hsts, true);
  verifier('C. une liste est transmise comme tableau',
    appelGen.corps.parametres.navigation, ['Accueil|/']);
  contient('C. le fichier généré est affiché', texte(env.fenetreFlottante()), '<!DOCTYPE html>');
  contient('C. les notes du générateur sont affichées', texte(env.fenetreFlottante()),
    'texte d’exemple');
  vrai('C. un champ de nom de fichier est proposé',
    env.fenetreFlottante().querySelectorAll('.psdw-input').length >= 1);

  /* enregistrer : d'abord /api/create, et un bouton d'écrasement si ça échoue */
  const nomFichier = (env.fenetreFlottante().querySelectorAll('.psdw-input') || [])
    .filter(i => i.value === 'index.html')[0];
  vrai('C. le nom de fichier proposé vient du générateur', nomFichier);
  const bEnregistrer = (env.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b) === 'Enregistrer dans le projet');
  env.clic(bEnregistrer);
  await env.ticks(16);
  vrai('C. l’enregistrement passe par /api/create', env.dernierAppel('/api/create'));
  verifier('C. le contenu généré est transmis à la création',
    env.dernierAppel('/api/create').corps.content.indexOf('<!DOCTYPE html>') === 0, true);

  const envEcrase = construire({ creationRefusee: true });
  await envEcrase.ticks(12);
  envEcrase.ouvrirSection('generer');
  await envEcrase.ticks(4);
  envEcrase.clic((envEcrase.ctx.document.querySelectorAll('.psdw-corps-generer .psdw-ligne') || [])[0]);
  await envEcrase.ticks(4);
  const forme2 = envEcrase.fenetreFlottante().querySelector('.psdw-forme');
  envEcrase.clic((forme2.querySelectorAll('.psdw-btn') || []).find(b => texte(b) === 'Générer'));
  await envEcrase.ticks(6);
  envEcrase.clic((envEcrase.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b) === 'Enregistrer dans le projet'));
  await envEcrase.ticks(6);
  contient('C. un échec de création est dit', envEcrase.statut(), 'existe déjà');
  vrai('C. un bouton d’écrasement explicite est proposé',
    (envEcrase.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
      .some(b => texte(b).indexOf('Écraser') === 0));
  faux('C. rien n’est écrasé sans validation', envEcrase.dernierAppel('/api/save'));
  envEcrase.clic((envEcrase.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b).indexOf('Écraser') === 0));
  await envEcrase.ticks(6);
  vrai('C. l’écrasement validé passe par /api/save', envEcrase.dernierAppel('/api/save'));

  /* un générateur qui échoue doit dire pourquoi */
  env.sandbox.window.PSDevWeb.generer('sri');
  await env.ticks(14);
  const forme3 = env.fenetreFlottante().querySelector('.psdw-forme');
  env.clic((forme3.querySelectorAll('.psdw-btn') || []).find(b => texte(b) === 'Générer'));
  await env.ticks(16);
  contient('C. un générateur sans entrée dit pourquoi il échoue', env.statut(),
    'empreinte');

  /* --- extraits ------------------------------------------------------------ */
  env.ouvrirSection('extraits');
  await env.ticks(16);
  const listeExtraits = env.ctx.document.querySelectorAll('.psdw-corps-extraits .psdw-ligne') || [];
  verifier('C. les extraits sont listés', listeExtraits.length, 2);
  const recherche = env.ctx.document.querySelector('.psdw-corps-extraits .psdw-input');
  recherche.value = 'clamp';
  recherche.dispatchEvent({ type: 'input', target: recherche });
  await env.ticks(16);
  const appelEx = env.dernierAppel('/api/devweb', 'extraits');
  verifier('C. la recherche est envoyée avec anti-rebond', appelEx.corps.recherche, 'clamp');
  if (process.env.PSDW_DEBUG) {
    console.error('DEBUG extraits : appels=', JSON.stringify(
      env.appels.filter(a => a.corps && a.corps.action === 'extraits').map(a => a.corps)),
      'lignes=', (env.ctx.document.querySelectorAll('.psdw-corps-extraits .psdw-ligne') || []).length);
  }
  verifier('C. un seul extrait correspond à la recherche',
    (env.ctx.document.querySelectorAll('.psdw-corps-extraits .psdw-ligne') || []).length, 1);
  env.clic((env.ctx.document.querySelectorAll('.psdw-corps-extraits .psdw-ligne') || [])[0]);
  await env.ticks(16);
  contient('C. l’extrait affiche son code', texte(env.fenetreFlottante()), 'place-items');
  vrai('C. un bouton « Copier l’extrait » existe',
    (env.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
      .some(b => texte(b).indexOf('Copier') === 0));
  env.clic((env.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b).indexOf('Copier') === 0));
  await env.ticks(14);
  vrai('C. la copie passe par le presse-papiers', (env.fenetre.__presse || []).length === 1);
  contient('C. le texte copié est le code de l’extrait', (env.fenetre.__presse || [])[0],
    'place-items');

  /* --- requêtes ------------------------------------------------------------ */
  env.ouvrirSection('requetes');
  await env.ticks(14);
  const champUrl = env.ctx.document.querySelector('.psdw-corps-requetes .psdw-input');
  champUrl.value = 'https://api.exemple.fr/v1/pages';
  env.clic(env.boutons('Ouvrir l’éditeur de requête')[0]);
  await env.ticks(14);
  const f = env.fenetreFlottante();
  vrai('C. l’éditeur de requête s’ouvre', f);
  verifier('C. l’adresse saisie est reprise', f.querySelector('.psdw-input').value,
    'https://api.exemple.fr/v1/pages');
  const entetes = f.querySelectorAll('.psdw-textarea')[0];
  entetes.value = 'Accept: application/json\nX-Clef: abc\nmalformee';
  const corpsRequete = f.querySelectorAll('.psdw-textarea')[1];
  corpsRequete.value = '{"q":1}';
  const methode = f.querySelector('.psdw-select');
  methode.value = 'POST';
  methode.dispatchEvent({ type: 'change', target: methode });
  env.clic((f.querySelectorAll('.psdw-btn') || []).find(b => texte(b) === 'Envoyer'));
  await env.ticks(16);
  faux('C. un en-tête mal formé bloque l’envoi', env.dernierAppel('/api/devweb', 'requeter'));
  contient('C. un en-tête mal formé est expliqué', env.statut(), 'malformee');
  contient('C. le format attendu est rappelé', env.statut(), 'Nom: valeur');

  entetes.value = 'Accept: application/json\nX-Clef: abc';
  env.clic((f.querySelectorAll('.psdw-btn') || []).find(b => texte(b) === 'Envoyer'));
  await env.ticks(18);
  const appelReq = env.dernierAppel('/api/devweb', 'requeter');
  vrai('C. la requête est envoyée', appelReq);
  verifier('C. la méthode choisie est transmise', appelReq.corps.methode, 'POST');
  verifier('C. les en-têtes sont transmis comme objet', appelReq.corps.entetes,
    { Accept: 'application/json', 'X-Clef': 'abc' });
  verifier('C. un corps JSON est transmis comme objet', appelReq.corps.corps, { q: 1 });
  verifier('C. le délai est transmis comme nombre', typeof appelReq.corps.delai, 'number');
  verifier('C. le suivi des redirections est transmis', appelReq.corps.suivre, true);
  contient('C. le statut de la réponse est affiché', texte(env.fenetreFlottante()), '200');
  contient('C. la durée est affichée', texte(env.fenetreFlottante()), 'ms');
  contient('C. les en-têtes homonymes sont tous affichés',
    texte(env.fenetreFlottante()), 'a=1 | b=2');
  contient('C. le corps de la réponse est affiché', texte(env.fenetreFlottante()), '{"ok":true}');

  /* un schéma refusé doit être dit */
  const url2 = env.fenetreFlottante().querySelector('.psdw-input');
  url2.value = 'ftp://exemple.fr/x';
  env.clic((env.fenetreFlottante().querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b) === 'Envoyer'));
  await env.ticks(16);
  contient('C. un schéma refusé est expliqué', env.statut(), 'schéma');

  /* --- projet -------------------------------------------------------------- */
  env.ouvrirSection('projet');
  await env.ticks(14);
  env.clic(env.boutons('Faire l’inventaire')[0]);
  await env.ticks(18);
  vrai('C. l’inventaire est demandé', env.dernierAppel('/api/devweb', 'inventaire'));
  contient('C. l’inventaire affiche le nombre de fichiers', env.statut(), '5 fichier(s)');
  const corpsProjet = env.ctx.document.querySelector('.psdw-corps-projet');
  contient('C. les catégories sont affichées', texte(corpsProjet), 'html');
  vrai('C. les pages trouvées proposent l’aperçu',
    (corpsProjet.querySelectorAll('.psdw-btn') || []).some(b => texte(b) === 'Aperçu'));
  vrai('C. les pages trouvées proposent l’audit',
    (corpsProjet.querySelectorAll('.psdw-btn') || []).some(b => texte(b) === 'Audit'));

  /* --- fenêtre flottante : déplacement, taille, plein écran, fermeture ------ */
  env.sandbox.window.PSDevWeb.requete('https://exemple.fr/');
  await env.ticks(14);
  const fl = env.fenetreFlottante();
  vrai('C. la fenêtre flottante existe', fl);
  if (process.env.PSDW_DEBUG) {
    console.error('DEBUG fenêtres :', (env.ctx.document.querySelectorAll('.psdw-fenetre') || []).length);
    (env.ctx.document.querySelectorAll('.psdw-fenetre') || []).forEach((f, i) =>
      console.error('  #' + i + ' enfants :', f.children.map(c => c.tagName + '.' + (c.className || '')).join(' | ') || '(vide)'));
    console.error('DEBUG body enfants :', env.ctx.body.children.map(c => c.tagName + '.' + (c.className || '')).join(' | '));
  }
  if (process.env.PSDW_DEBUG) {
    console.error('DEBUG fl enfants :', fl.children.length,
      fl.children.map(c => c.tagName + '/' + JSON.stringify(c.className) + '/' + JSON.stringify(c._classes)).join(' , '));
    try { console.error('DEBUG querySelectorAll :', fl.querySelectorAll('.psdw-barre').length); }
    catch (e) { console.error('DEBUG querySelectorAll LÈVE :', e.message); }
    console.error('DEBUG matcheur direct :', H.matcheur(fl.children[0], '.psdw-barre'));
  }
  const barre = fl.querySelector('.psdw-barre');
  barre.dispatchEvent({ type: 'pointerdown', clientX: 100, clientY: 100, target: barre });
  env.emettreFenetre('pointermove', { clientX: 160, clientY: 140 });
  env.emettreFenetre('pointerup', {});
  verifier('C. le déplacement suit le mouvement RELATIF du pointeur',
    fl.style.left, '60px');
  verifier('C. le déplacement vertical suit aussi le pointeur', fl.style.top, '40px');
  vrai('C. la géométrie est mémorisée', env.stockage['ps-devweb-fenetre']);
  const poignee = fl.querySelector('.psdw-r-se');
  vrai('C. une poignée de redimensionnement existe', poignee);
  /* Le harnais calcule la géométrie à partir des styles en ligne : sans taille
   * explicite, la fenêtre ferait 100×30 par convention, et l'attente dépendrait
   * de cette convention au lieu de tester le comportement. */
  fl.style.width = '400px';
  fl.style.height = '260px';
  poignee.dispatchEvent({ type: 'pointerdown', clientX: 200, clientY: 200, target: poignee });
  env.emettreFenetre('pointermove', { clientX: 320, clientY: 260 });
  env.emettreFenetre('pointerup', {});
  verifier('C. la largeur suit le déplacement du POINTEUR (+120 px)',
    fl.style.width, '520px');
  verifier('C. la hauteur suit le déplacement du POINTEUR (+60 px)',
    fl.style.height, '320px');
  poignee.dispatchEvent({ type: 'pointerdown', clientX: 200, clientY: 200, target: poignee });
  env.emettreFenetre('pointermove', { clientX: 10, clientY: 10 });
  env.emettreFenetre('pointerup', {});
  verifier('C. la largeur ne descend pas sous un minimum utilisable',
    fl.style.width, '360px');
  const bPlein = (barre.querySelectorAll('.psdw-btn') || [])[0];
  env.clic(bPlein);
  vrai('C. la fenêtre peut passer en plein écran', fl.classList.contains('psdw-plein'));
  env.clic(bPlein);
  faux('C. la fenêtre peut quitter le plein écran', fl.classList.contains('psdw-plein'));
  env.clic((barre.querySelectorAll('.psdw-btn') || [])[1]);
  faux('C. la fenêtre se ferme', env.fenetreFlottante());
  verifier('C. une seule fenêtre flottante à la fois',
    (env.ctx.document.querySelectorAll('.psdw-fenetre') || []).length, 0);

  /* --- ouverture d'un fichier dans un onglet -------------------------------- */
  /* Le journal a été vidé plus haut : la page aperçue continue de produire des
   * messages, et c'est cette entrée-là (une erreur avec une URL et une ligne)
   * qui doit proposer l'ouverture du fichier en cause. */
  env.ajouterEntrees([{ type: 'erreur', niveau: 'error', message: 'y est indéfini',
    horodatage: 1700000099000, url: '/app.js', ligne: 4, colonne: 2,
    pile: 'ReferenceError: y is not defined\n  at app.js:4:2', page: '/index.html' }]);
  env.sandbox.window.PSDevWeb.ouvrir('journal');
  await env.ticks(14);
  env.sonder();
  await env.ticks(16);
  const entreeErreur = (env.ctx.document.querySelectorAll('.psdw-entree') || [])
    .find(e => texte(e).indexOf('y est indéfini') >= 0);
  vrai('C. une nouvelle entrée arrivée après un vidage est rendue', entreeErreur);
  env.clic(entreeErreur);
  await env.ticks(14);
  const fen = env.fenetreFlottante();
  vrai('C. le détail de la nouvelle erreur ouvre la fenêtre', fen);
  const bOuvrir = fen && (fen.querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b).indexOf('Ouvrir') === 0);
  vrai('C. le détail d’une erreur propose d’ouvrir le fichier en cause', bOuvrir);
  env.clic(bOuvrir);
  await env.ticks(14);
  vrai('C. l’ouverture passe par PSFMActivate', (env.fenetre.__onglets || []).length === 1);
  verifier('C. le chemin ouvert est celui de la ressource en faute',
    (env.fenetre.__onglets || [])[0].path, 'app.js');
  contient('C. la ligne est rappelée dans l’état, faute de pouvoir l’imposer',
    env.statut(), 'ligne 4');

  /* --- arrêt de l'aperçu ---------------------------------------------------- */
  env.sandbox.window.PSDevWeb.ouvrir('apercu');
  await env.ticks(14);
  env.clic(env.boutons('Arrêter')[0]);
  await env.ticks(16);
  vrai('C. l’arrêt appelle /api/web/stop', env.dernierAppel('/api/web/stop'));
  if (process.env.PSDW_DEBUG) {
    console.error('DEBUG arrêt aperçu : statut=', JSON.stringify(env.statut()),
      'appels=', JSON.stringify(env.appels.slice(-4).map(a => a.url)));
  }
  verifier('C. l’état ne connaît plus d’aperçu', env.sandbox.window.PSDevWeb.apercu(), null);

  /* --- copie refusée : le navigateur n'est pas en contexte sécurisé --------- */
  const envNonSecurise = construire({ pasSecurise: true });
  await envNonSecurise.ticks(12);
  envNonSecurise.ouvrirSection('extraits');
  await envNonSecurise.ticks(16);
  envNonSecurise.clic((envNonSecurise.ctx.document.querySelectorAll('.psdw-corps-extraits .psdw-ligne') || [])[0]);
  await envNonSecurise.ticks(16);
  const fenNonSecurise = envNonSecurise.fenetreFlottante();
  vrai('C. l’extrait s’ouvre hors contexte sécurisé', fenNonSecurise);
  envNonSecurise.clic(fenNonSecurise && (fenNonSecurise.querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b).indexOf('Copier') === 0));
  await envNonSecurise.ticks(14);
  faux('C. la copie hors contexte sécurisé n’utilise pas navigator.clipboard',
    (envNonSecurise.fenetre.__presse || []).length);

  /* --- PSFMActivate absent : le dire plutôt que de ne rien faire ------------ */
  const envSansPSFM = construire({ pasDePSFM: true });
  await envSansPSFM.ticks(12);
  envSansPSFM.sandbox.window.PSDevWeb.ouvrir('journal');
  await envSansPSFM.ticks(14);
  /* Ouvrir la section ne suffit pas : le contenu vient de la sonde. Sans cet
   * appel, le banc chercherait une entrée qui n'a pas encore été demandée au
   * serveur, et accuserait le produit pour son propre oubli. */
  envSansPSFM.sonder();
  await envSansPSFM.ticks(16);
  const entrees3 = envSansPSFM.ctx.document.querySelectorAll('.psdw-entree') || [];
  verifier('C. le journal est rendu dans un environnement sans PSFMActivate',
    entrees3.length, 3);
  const entreeErreur3 = entrees3.find(e => texte(e).indexOf('x est indéfini') >= 0);
  vrai('C. l’entrée d’erreur est rendue', entreeErreur3);
  envSansPSFM.clic(entreeErreur3);
  await envSansPSFM.ticks(14);
  const fen3 = envSansPSFM.fenetreFlottante();
  vrai('C. le détail s’ouvre même sans PSFMActivate', fen3);
  const bOuvrir2 = fen3 && (fen3.querySelectorAll('.psdw-btn') || [])
    .find(b => texte(b).indexOf('Ouvrir') === 0);
  vrai('C. sans PSFMActivate, le bouton d’ouverture est quand même proposé',
    bOuvrir2);
  envSansPSFM.clic(bOuvrir2);
  await envSansPSFM.ticks(14);
  contient('C. sans PSFMActivate, le panneau dit quoi faire à la main',
    envSansPSFM.statut(), 'n’expose pas l’ouverture en onglet');
  contient('C. sans PSFMActivate, le chemin et la ligne sont quand même donnés',
    envSansPSFM.statut(), 'app.js');
}

async function main() {
  await scenarioA();
  await scenarioB();
  await scenarioC();
  process.stderr.write('\nsmoke_devweb_studio : ' + N + ' contrôles, '
    + (N - OK) + ' échec(s)\n');
  if (echecs.length) {
    echecs.forEach(e => process.stderr.write('  ÉCHEC : ' + e + '\n'));
    process.exit(1);
  }
  process.exit(0);
}

main().catch(e => { process.stderr.write('Exception du banc : ' + (e && e.stack || e) + '\n'); process.exit(1); });
