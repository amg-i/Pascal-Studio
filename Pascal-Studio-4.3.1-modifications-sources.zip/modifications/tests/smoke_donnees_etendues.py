#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : les formats de données étendus de l'onglet éditeur (4.0.0).

Ce banc travaille sur de VRAIS fichiers écrits dans un dossier temporaire — un
classeur XLSX produit par openpyxl, un classeur ODS construit comme une archive
ZIP avec son content.xml, un document XML, une base SQLite réelle, et des
fichiers dont le nom MENT. Un lecteur de formats se juge sur ce qu'il refuse et
sur ce qu'il ne devine pas : un tableau faux est pire qu'un refus.

Sont exercés :

  1. l'autonomie du module et ses capacités déclarées ;
  2. la reconnaissance par SIGNATURE, y compris les deux cas où le nom ment :
     « faux.sqlite » qui contient du texte, et « export.dat » qui est une vraie
     base SQLite ;
  3. la lecture des classeurs et de l'XML, avec la séparation de l'en-tête et ses
     trois garde-fous (case vide, noms en double, ligne numérique) ;
  4. le miroir SQL : sélection, agrégat, jointure entre deux feuilles, refus des
     modifications, et ABSENCE de faux refus sur un commentaire ou un littéral
     qui contient un mot interdit ;
  5. les bornes et l'écriture XLSX, dont le refus d'écraser un classeur qui porte
     des formules ;
  6. l'ÉCRITURE réelle des trois formats miroirs (XLSX, ODS, XML) : aller-retour
     sans perte, case/ligne/colonne ajoutées et supprimées, structure de
     l'archive ODF (entrée « mimetype » première et non compressée, manifeste,
     entrées annexes recopiées), déclaration, DOCTYPE, commentaires et espaces de
     noms conservés en XML ;
  7. la POLITIQUE DE FUSION : une table non mentionnée survit, une suppression
     passe par une demande explicite, et ce qui ne peut pas être écrit est refusé
     en nommant la raison et la voie de recours ;
  8. le branchement sur « database_tools.Manager », sans lequel le module serait
     correct et inutile.
"""

import importlib.util
import os
import shutil
import sqlite3
import sys
import tempfile
import zipfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
CIBLE = MODIFICATIONS / 'donnees_etendues.py'

echecs = []
compte = [0]


def verif(condition, message):
    compte[0] += 1
    if not condition:
        echecs.append(message)


ODS_CONTENU = '''<?xml version="1.0" encoding="UTF-8"?>
<office:document-content
 xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.2">
<office:body><office:spreadsheet>
<table:table table:name="Stock">
<table:table-row><table:table-cell><text:p>article</text:p></table:table-cell><table:table-cell><text:p>quantite</text:p></table:table-cell></table:table-row>
<table:table-row><table:table-cell><text:p>vis</text:p></table:table-cell><table:table-cell><text:p>120</text:p></table:table-cell></table:table-row>
<table:table-row><table:table-cell><text:p>écrou</text:p></table:table-cell><table:table-cell><text:p>340</text:p></table:table-cell></table:table-row>
<table:table-row table:number-rows-repeated="2"><table:table-cell><text:p>rondelle</text:p></table:table-cell><table:table-cell><text:p>900</text:p></table:table-cell></table:table-row>
</table:table>
</office:spreadsheet></office:body></office:document-content>'''

ODS_FORMULES = ODS_CONTENU.replace(
    '<table:table table:name="Stock">', '<table:table table:name="Calculs">').replace(
    '<table:table-cell><text:p>vis</text:p></table:table-cell>',
    '<table:table-cell table:formula="of:=[.A1]+[.B1]" office:value-type="float"'
    ' office:value="5"><text:p>vis</text:p></table:table-cell>')

XML_BIBLIO = ('<?xml version="1.0"?>\n<bibliotheque>\n'
              '  <livre><titre>Dune</titre><auteur>Herbert</auteur>'
              '<annee>1965</annee></livre>\n'
              '  <livre><titre>Fondation</titre><auteur>Asimov</auteur>'
              '<annee>1951</annee></livre>\n'
              '  <livre><titre>Neuromancien</titre><auteur>Gibson</auteur>'
              '<annee>1984</annee></livre>\n'
              '</bibliotheque>\n')

XML_SANS_REPEATITION = ('<?xml version="1.0"?>\n<config>\n'
                        '  <serveur>local</serveur>\n  <port>8080</port>\n'
                        '</config>\n')

# Un XML tabulaire est très souvent écrit avec des ATTRIBUTS et aucun enfant.
# Le banc ne couvrait que la forme « enfants », et la forme « attributs »
# produisait une table d'une seule colonne « valeur » remplie de vides : un
# SELECT nom FROM contact échouait sur un fichier qui contient bien un nom.
XML_ATTRIBUTS = ('<?xml version="1.0"?>\n<carnet>\n'
                 '  <contact id="1" nom="Ada" ville="Londres"/>\n'
                 '  <contact id="2" nom="Grace" ville="New York"/>\n'
                 '</carnet>\n')

XML_MIXTE = ('<registre>\n'
             '  <ligne id="1"><quantite>3</quantite></ligne>\n'
             '  <ligne id="2"><quantite>7</quantite></ligne>\n'
             '</registre>\n')

# Un attribut et un enfant portant le même nom : aucun des deux ne doit être
# masqué, l'attribut prend la notation XML « @nom ».
XML_COLLISION = ('<r>\n  <e id="A"><id>1</id></e>\n  <e id="B"><id>2</id></e>\n</r>\n')

XML_ESPACES = ('<r xmlns:p="urn:exemple">\n'
               '  <p:l p:id="1" p:nom="Ada"/>\n'
               '  <p:l p:id="2" p:nom="Grace"/>\n'
               '</r>\n')

XML_TEXTE = '<liste>\n  <item>un</item>\n  <item>deux</item>\n</liste>\n'

# XML interdit les espaces dans un nom, mais autorise le tiret et le point,
# qui ne sont pas admis dans un identifiant SQL simple : « code-client » est
# courant et doit devenir « code_client » pour qu'un SELECT fonctionne.
XML_NOM_IMPROPRE = ('<r>\n  <l code-client="a" ref.fournisseur="X"/>\n'
                    '  <l code-client="b" ref.fournisseur="Y"/>\n</r>\n')


def fabriquer(dossier):
    """Écrit les fixtures réelles et rend leurs chemins."""
    chemins = {}
    try:
        import openpyxl
    except ImportError:
        openpyxl = None

    if openpyxl:
        classeur = openpyxl.Workbook()
        feuille = classeur.active
        feuille.title = 'Clients'
        feuille.append(['id', 'nom', 'ville', 'solde'])
        feuille.append([1, 'Alice', 'Paris', 120.5])
        feuille.append([2, 'Bob', 'Lyon', 0])
        feuille.append([3, 'Chloé', 'Nîmes', -14.25])
        commandes = classeur.create_sheet(title='Commandes')
        commandes.append(['id', 'client', 'total'])
        commandes.append([10, 'Alice', 42])
        classeur.save(str(dossier / 'classeur.xlsx'))
        chemins['xlsx'] = dossier / 'classeur.xlsx'

        avec_formule = openpyxl.Workbook()
        f = avec_formule.active
        f.title = 'Calculs'
        f.append(['a', 'b', 'somme'])
        f.append([2, 3, '=A2+B2'])
        avec_formule.save(str(dossier / 'formules.xlsx'))
        chemins['formules'] = dossier / 'formules.xlsx'

        sans_entete = openpyxl.Workbook()
        g = sans_entete.active
        g.title = 'Mesures'
        g.append([11, 12, 13])
        g.append([21, 22, 23])
        sans_entete.save(str(dossier / 'mesures.xlsx'))
        chemins['mesures'] = dossier / 'mesures.xlsx'

        # Deux feuilles dont les titres diffèrent mais dont le nom NETTOYÉ est
        # identique : sans désambiguïsation, le miroir SQL jetait la seconde.
        doublon = openpyxl.Workbook()
        doublon.remove(doublon.active)
        for titre in ('Feuille 1', 'Feuille-1'):
            feuille = doublon.create_sheet(title=titre)
            feuille.append(['a'])
            feuille.append(['1'])
        doublon.save(str(dossier / 'doublon.xlsx'))
        chemins['doublon_xlsx'] = dossier / 'doublon.xlsx'
    else:
        chemins['xlsx'] = None
        chemins['doublon_xlsx'] = None

    with zipfile.ZipFile(str(dossier / 'classeur.ods'), 'w',
                         zipfile.ZIP_STORED) as archive:
        archive.writestr(
            'mimetype',
            b'application/vnd.oasis.opendocument.spreadsheet')
        archive.writestr('content.xml', ODS_CONTENU)
    chemins['ods'] = dossier / 'classeur.ods'

    with zipfile.ZipFile(str(dossier / 'formules.ods'), 'w',
                         zipfile.ZIP_STORED) as archive:
        archive.writestr(
            'mimetype',
            b'application/vnd.oasis.opendocument.spreadsheet')
        archive.writestr('content.xml', ODS_FORMULES)
    chemins['ods_formules'] = dossier / 'formules.ods'

    (dossier / 'biblio.xml').write_text(XML_BIBLIO, encoding='utf-8')
    chemins['xml'] = dossier / 'biblio.xml'
    (dossier / 'config.xml').write_text(XML_SANS_REPEATITION, encoding='utf-8')
    chemins['xml_plat'] = dossier / 'config.xml'
    for cle, contenu in (('xml_attributs', XML_ATTRIBUTS), ('xml_mixte', XML_MIXTE),
                         ('xml_collision', XML_COLLISION), ('xml_espaces', XML_ESPACES),
                         ('xml_texte', XML_TEXTE), ('xml_impropre', XML_NOM_IMPROPRE)):
        (dossier / (cle + '.xml')).write_text(contenu, encoding='utf-8')
        chemins[cle] = dossier / (cle + '.xml')

    base = dossier / 'vraie.sqlite'
    connexion = sqlite3.connect(str(base))
    connexion.execute('CREATE TABLE t (a INTEGER)')
    connexion.execute('INSERT INTO t VALUES (7)')
    connexion.commit()
    connexion.close()
    chemins['sqlite'] = base
    shutil.copyfile(str(base), str(dossier / 'export.dat'))
    chemins['sqlite_mal_nomme'] = dossier / 'export.dat'
    (dossier / 'faux.sqlite').write_text('ceci n’est pas une base\n',
                                         encoding='utf-8')
    chemins['faux_sqlite'] = dossier / 'faux.sqlite'
    (dossier / 'notes.txt').write_text('du texte ordinaire\n', encoding='utf-8')
    chemins['texte'] = dossier / 'notes.txt'
    return chemins


def main():
    if not CIBLE.is_file():
        print('ECHEC : donnees_etendues.py introuvable : %s' % CIBLE)
        return 1
    sys.path.insert(0, str(MODIFICATIONS))

    # ------------------------------------------------------------------ 1
    print('-- Autonomie et capacités')
    spec = importlib.util.spec_from_file_location('donnees_etendues', str(CIBLE))
    module = importlib.util.module_from_spec(spec)
    sys.modules['donnees_etendues'] = module
    spec.loader.exec_module(module)
    verif(module.MARQUEUR == 'ps-4.0.0-donnees', 'marqueur faux ou absent')
    capacites = module.capacites()
    for cle in ('extensions', 'xlsx', 'ods', 'xml', 'signature_sqlite',
                'miroir_sql', 'ecriture_xlsx', 'ecriture_ods', 'ecriture_xml',
                'ecritures_refusees', 'limites'):
        verif(cle in capacites, 'capacites() sans la clef %r' % cle)
    # Une capacité annoncée doit correspondre à une fonction qui existe : le
    # drapeau ne prouve rien, c'est l'appel plus bas qui prouve.
    verif(capacites['ecriture_ods'] is True,
          'l’écriture ODS existe mais n’est pas annoncée')
    verif(capacites['ecriture_xml'] is True,
          'l’écriture XML existe mais n’est pas annoncée')
    verif(capacites['ecriture_xlsx'] is capacites['xlsx'],
          'l’écriture XLSX est annoncée alors qu’openpyxl %s'
          % ('est présent' if capacites['xlsx'] else 'est absent'))
    for nom in ('ecrire_xlsx', 'ecrire_ods', 'ecrire_xml'):
        verif(callable(getattr(module, nom, None)),
              'le module n’a pas de fonction %s()' % nom)
    verif(capacites['limites']['lignes'] == 5000, 'la borne de lignes a changé')

    with tempfile.TemporaryDirectory() as brut:
        dossier = Path(brut)
        c = fabriquer(dossier)

        # -------------------------------------------------------------- 2
        print('-- Reconnaissance par signature')
        detection = module.famille(c['sqlite'])
        verif(detection['famille'] == 'sqlite', 'une vraie base n’est pas reconnue')
        verif(detection['accord'] is True, 'l’accord nom/contenu devrait être vrai')
        verif('SQLite format 3' in detection['raison'],
              'la raison ne cite pas l’amorce : %r' % detection['raison'])

        detection = module.famille(c['sqlite_mal_nomme'])
        verif(detection['famille'] == 'sqlite',
              'une base SQLite nommée .dat n’est pas reconnue par sa signature')
        verif(detection['accord'] is False,
              'le désaccord entre le nom et le contenu devrait être signalé')

        detection = module.famille(c['faux_sqlite'])
        verif(detection['famille'] == 'texte',
              'un .sqlite qui contient du texte devrait retomber sur texte, '
              'pas ouvrir un onglet de binaire illisible')
        verif(detection['accord'] is False,
              'le désaccord devrait être signalé pour le faux .sqlite')
        verif('ouvert comme texte' in detection['raison'],
              'la raison devrait dire que le fichier est ouvert comme texte : %r'
              % detection['raison'])

        detection = module.famille(c['texte'])
        verif(detection['famille'] == 'texte', 'un fichier texte n’est pas reconnu')
        detection = module.famille(dossier / 'absent.xlsx')
        verif(detection['famille'] == 'inconnu',
              'un fichier absent devrait donner « inconnu », pas une exception')
        verif('introuvable' in detection['raison'],
              'la raison d’un fichier absent devrait le dire')

        detection = module.famille(c['ods'])
        verif(detection['famille'] == 'ods', 'un ODS n’est pas reconnu')
        detection = module.famille(c['xml'])
        verif(detection['famille'] == 'xml', 'un XML n’est pas reconnu')
        if c['xlsx']:
            detection = module.famille(c['xlsx'])
            verif(detection['famille'] == 'xlsx', 'un XLSX n’est pas reconnu')
            verif(detection['accord'] is True, 'l’accord devrait être vrai pour .xlsx')

        # Une archive ZIP qui n'est pas un classeur ne doit pas passer pour telle.
        with zipfile.ZipFile(str(dossier / 'autre.xlsx'), 'w') as archive:
            archive.writestr('lisezmoi.txt', 'pas un classeur')
        detection = module.famille(dossier / 'autre.xlsx')
        verif(detection['famille'] == 'zip-autre',
              'une archive ZIP non classeur devrait être dite « zip-autre » : %r'
              % detection['famille'])

        # -------------------------------------------------------------- 3
        print('-- Lecture des classeurs et de l’XML')
        tables, _ = module.lire(c['ods'])
        verif(len(tables) == 1, 'ODS : %d feuille(s) au lieu de 1' % len(tables))
        stock = tables[0]
        verif(stock['colonnes'] == ['article', 'quantite'],
              'ODS : colonnes %r' % stock['colonnes'])
        verif(stock['entete'] is True, 'ODS : l’en-tête n’est pas séparé')
        # La ligne « number-rows-repeated="2" » doit donner DEUX lignes.
        verif(len(stock['lignes']) == 4,
              'ODS : %d lignes, la répétition n’est pas développée'
              % len(stock['lignes']))
        verif(stock['lignes'].count(['rondelle', '900']) == 2,
              'ODS : la ligne répétée n’apparaît pas deux fois : %r'
              % stock['lignes'])
        verif(any('écrou' in l for l in stock['lignes']),
              'ODS : les caractères non latins de base sont perdus')

        tables, _ = module.lire(c['xml'])
        verif(len(tables) == 1, 'XML : %d table(s) au lieu de 1' % len(tables))
        livre = tables[0]
        verif(livre['nom'] == 'livre', 'XML : nom de table %r' % livre['nom'])
        verif(livre['colonnes'] == ['titre', 'auteur', 'annee'],
              'XML : colonnes %r' % livre['colonnes'])
        verif(len(livre['lignes']) == 3, 'XML : %d lignes' % len(livre['lignes']))
        verif(livre['lignes'][0] == ['Dune', 'Herbert', '1965'],
              'XML : première ligne %r' % livre['lignes'][0])

        # La forme « attributs » : la plus courante, et celle qui était cassée.
        tables, _ = module.lire(c['xml_attributs'])
        contact = tables[0]
        verif(contact['colonnes'] == ['id', 'nom', 'ville'],
              'XML attributs : colonnes %r — les attributs doivent devenir des '
              'colonnes, pas une colonne « valeur » vide' % contact['colonnes'])
        verif(contact['lignes'][1] == ['2', 'Grace', 'New York'],
              'XML attributs : deuxième ligne %r' % contact['lignes'][1])
        verif('valeur' not in contact['colonnes'],
              'XML attributs : une colonne « valeur » vide ne doit pas apparaître '
              'quand aucun élément n’a de texte propre')

        # Attribut ET enfant : les deux doivent être lus.
        tables, _ = module.lire(c['xml_mixte'])
        ligne = tables[0]
        verif(ligne['colonnes'] == ['id', 'quantite'],
              'XML mixte : colonnes %r' % ligne['colonnes'])
        verif(ligne['lignes'] == [['1', '3'], ['2', '7']],
              'XML mixte : lignes %r' % ligne['lignes'])

        # Collision de noms : rien n'est masqué.
        tables, _ = module.lire(c['xml_collision'])
        e = tables[0]
        verif(e['colonnes'] == ['@id', 'id'],
              'XML collision : colonnes %r — l’attribut doit prendre « @id » '
              'plutôt que d’être écrasé par l’enfant' % e['colonnes'])
        verif(e['lignes'] == [['A', '1'], ['B', '2']],
              'XML collision : les deux valeurs doivent être distinctes, %r'
              % e['lignes'])

        # Espaces de noms : le nom local est celui qu'un SELECT utilisera.
        tables, _ = module.lire(c['xml_espaces'])
        l = tables[0]
        verif(l['nom'] == 'l', 'XML espacé : nom de table %r' % l['nom'])
        verif(l['colonnes'] == ['id', 'nom'],
              'XML espacé : colonnes %r' % l['colonnes'])

        # Éléments répétés portant seulement du texte.
        tables, _ = module.lire(c['xml_texte'])
        verif(tables[0]['colonnes'] == ['valeur'],
              'XML texte : colonnes %r' % tables[0]['colonnes'])
        verif(tables[0]['lignes'] == [['un'], ['deux']],
              'XML texte : lignes %r' % tables[0]['lignes'])

        # Un nom d'attribut impropre en SQL doit devenir un identifiant simple.
        tables, _ = module.lire(c['xml_impropre'])
        verif(tables[0]['colonnes'] == ['code_client', 'ref_fournisseur'],
              'XML nom impropre : colonnes %r — un tiret ou un point doit '
              'devenir un tiret bas pour qu’un SELECT fonctionne sans guillemets'
              % tables[0]['colonnes'])
        verif(tables[0]['lignes'][0] == ['a', 'X'],
              'XML nom impropre : valeurs %r' % tables[0]['lignes'][0])

        # Un XML sans répétition ne doit PAS devenir une table devinée.
        tables, _ = module.lire(c['xml_plat'])
        verif(tables == [],
              'un XML sans élément répété devrait donner aucune table, pas une '
              'structure devinée : %r' % (tables,))

        if c['xlsx']:
            tables, _ = module.lire(c['xlsx'])
            verif(len(tables) == 2, 'XLSX : %d feuille(s) au lieu de 2' % len(tables))
            clients = tables[0]
            verif(clients['colonnes'] == ['id', 'nom', 'ville', 'solde'],
                  'XLSX : colonnes %r' % clients['colonnes'])
            verif(len(clients['lignes']) == 3,
                  'XLSX : %d lignes, l’en-tête compte encore comme donnée'
                  % len(clients['lignes']))
            # Un flottant entier ne doit pas s'écrire « 0 » ni « 120.50000001 ».
            verif(clients['lignes'][1][3] == '0',
                  'XLSX : le solde entier 0 s’écrit %r' % clients['lignes'][1][3])
            verif(clients['lignes'][0][3] == '120.5',
                  'XLSX : le solde 120.5 s’écrit %r' % clients['lignes'][0][3])
            verif(clients['lignes'][2][3] == '-14.25',
                  'XLSX : le solde négatif s’écrit %r' % clients['lignes'][2][3])
            verif(clients['lignes'][2][1] == 'Chloé',
                  'XLSX : les accents sont perdus : %r' % clients['lignes'][2][1])
            verif(tables[1]['nom'] == 'Commandes',
                  'XLSX : la seconde feuille s’appelle %r' % tables[1]['nom'])

            # Garde-fous de la séparation d'en-tête : une première ligne
            # numérique est une DONNÉE, pas un en-tête.
            tables, _ = module.lire(c['mesures'])
            mesures = tables[0]
            verif(mesures['entete'] is False,
                  'une première ligne entièrement numérique a été prise pour un '
                  'en-tête : la première mesure serait perdue')
            verif(len(mesures['lignes']) == 2,
                  'mesures : %d lignes au lieu de 2' % len(mesures['lignes']))
            verif(mesures['colonnes'] == ['colonne_1', 'colonne_2', 'colonne_3'],
                  'mesures : colonnes %r' % mesures['colonnes'])

        # -------------------------------------------------------------- 4
        print('-- Miroir SQL : requêtes, refus, et absence de faux refus')
        if c['xlsx']:
            tables, _ = module.lire(c['xlsx'])
            resultat = module.interroger(
                tables, 'SELECT nom, ville FROM Clients ORDER BY nom')
            verif(resultat['colonnes'] == ['nom', 'ville'],
                  'miroir : colonnes %r' % resultat['colonnes'])
            verif([l[0] for l in resultat['lignes']] == ['Alice', 'Bob', 'Chloé'],
                  'miroir : le tri par nom donne %r' % resultat['lignes'])
            verif(resultat['miroir'] is True,
                  'le résultat devrait annoncer qu’il vient d’une copie')
            resultat = module.interroger(tables, 'SELECT COUNT(*) AS n FROM Clients')
            verif(resultat['lignes'] == [['3']],
                  'miroir : l’agrégat donne %r' % resultat['lignes'])
            resultat = module.interroger(
                tables,
                'SELECT c.nom, o.total FROM Clients c '
                'JOIN Commandes o ON o.client = c.nom')
            verif(resultat['lignes'] == [['Alice', '42']],
                  'miroir : la jointure entre deux feuilles donne %r'
                  % resultat['lignes'])
            verif(sorted(resultat['tables']) == ['Clients', 'Commandes'],
                  'miroir : les tables disponibles ne sont pas annoncées')

            for requete in ('INSERT INTO Clients VALUES (9,\'x\',\'y\',1)',
                            'UPDATE Clients SET ville=\'Rome\'',
                            'DELETE FROM Clients',
                            'DROP TABLE Clients',
                            'ALTER TABLE Clients ADD COLUMN z TEXT',
                            'CREATE TABLE z (a INT)'):
                try:
                    module.interroger(tables, requete)
                    verif(False, 'le miroir a accepté une modification : %s'
                          % requete)
                except module.DonneesRefusees as erreur:
                    verif('copie' in str(erreur) or 'COPIE' in str(erreur),
                          'le refus n’explique pas que la requête porte sur une '
                          'copie : %r' % str(erreur))

            # Aucun faux refus : un commentaire ou un littéral qui contient un
            # mot interdit ne doit pas être pris pour une modification.
            for requete in ('SELECT * FROM Clients -- INSERT INTO x',
                            "SELECT 'INSERT INTO x' AS texte",
                            'SELECT * FROM Clients /* UPDATE Clients */',
                            "SELECT ville FROM Clients WHERE nom = 'Bob'"):
                try:
                    resultat = module.interroger(tables, requete)
                    verif(isinstance(resultat['lignes'], list),
                          'requête légitime refusée : %s' % requete)
                except module.DonneesRefusees as erreur:
                    verif(False, 'faux refus sur %r : %s' % (requete, erreur))

            verif(module.est_lecture_seule('SELECT 1') is True,
                  'est_lecture_seule refuse un SELECT simple')
            verif(module.est_lecture_seule('DELETE FROM x') is False,
                  'est_lecture_seule accepte un DELETE')
            try:
                module.interroger(tables, '   ')
                verif(False, 'une requête vide devrait être refusée')
            except module.DonneesRefusees:
                verif(True, '')
            try:
                module.interroger(tables, 'SELECT * FROM inexistante')
                verif(False, 'une table inconnue devrait être refusée clairement')
            except module.DonneesRefusees as erreur:
                verif('SQLite' in str(erreur),
                      'une table inconnue devrait citer SQLite : %r' % str(erreur))

        # -------------------------------------------------------------- 5
        print('-- Écriture XLSX et refus d’écraser des formules')
        if c['xlsx']:
            tables, _ = module.lire(c['xlsx'])
            copie = dossier / 'copie.xlsx'
            shutil.copyfile(str(c['xlsx']), str(copie))
            tables[0]['lignes'].append(['4', 'Djamel', 'Lille', '7'])
            module.ecrire_xlsx(copie, tables)
            relues, _ = module.lire(copie)
            verif(len(relues[0]['lignes']) == 4,
                  'l’écriture XLSX n’a pas conservé la ligne ajoutée : %r'
                  % relues[0]['lignes'])
            verif(relues[0]['lignes'][3][1] == 'Djamel',
                  'la ligne ajoutée est altérée : %r' % relues[0]['lignes'][3])
            verif(len(relues) == 2, 'l’écriture a perdu une feuille')
            verif(not list(dossier.glob('copie.xlsx.part')),
                  'un fichier temporaire .part subsiste après l’écriture')
            # Les nombres redeviennent des nombres, pas du texte.
            import openpyxl
            feuille = openpyxl.load_workbook(str(copie))['Clients']
            verif(isinstance(feuille.cell(row=2, column=1).value, int),
                  'un identifiant numérique a été écrit comme texte')

            try:
                module.ecrire_xlsx(c['formules'], tables)
                verif(False, 'écrire par-dessus un classeur à formules devrait '
                             'être refusé : les formules seraient perdues')
            except module.DonneesRefusees as erreur:
                verif('formules' in str(erreur),
                      'le refus ne nomme pas les formules : %r' % str(erreur))

        try:
            module.lire(c['texte'])
            verif(False, 'lire() sur un fichier texte devrait refuser')
        except module.DonneesRefusees as erreur:
            verif('classeur' in str(erreur),
                  'le refus de lire() n’est pas explicite : %r' % str(erreur))

        # -------------------------------------------------------------- 5bis
        # L'écriture réelle des miroirs : c'est elle qui fait d'un onglet de
        # lecture un éditeur. Trois garanties sont vérifiées ici, et ce sont
        # celles dont la perte serait invisible : ce qui n'est pas mentionné
        # survive, ce qui est écrit se relit, et ce qui ne peut pas être écrit
        # est refusé en nommant la raison.
        print('-- Écriture ODS et XML, politique de fusion, refus nommés')

        # --- ODS : aller-retour et structure de l'archive ------------------
        copie_ods = dossier / 'copie.ods'
        shutil.copyfile(str(c['ods']), str(copie_ods))
        # Une entrée annexe : l'écrivain doit la recopier, pas la perdre.
        with zipfile.ZipFile(str(copie_ods), 'a', zipfile.ZIP_DEFLATED) as archive:
            archive.writestr('styles.xml', '<office:document-styles/>')
        os.chmod(str(copie_ods), 0o640)
        tables_ods, _ = module.lire(copie_ods)
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif([t['nom'] for t in relues] == [t['nom'] for t in tables_ods],
              'l’aller-retour ODS a changé les tables : %r' % [t['nom'] for t in relues])
        verif(relues[0]['colonnes'] == tables_ods[0]['colonnes'],
              'l’aller-retour ODS a changé les colonnes : %r' % relues[0]['colonnes'])
        verif(relues[0]['lignes'] == tables_ods[0]['lignes'],
              'l’aller-retour ODS a changé les données : %r' % relues[0]['lignes'])
        verif(relues[0]['entete'] == tables_ods[0]['entete'],
              'l’aller-retour ODS a perdu le drapeau d’en-tête')
        with zipfile.ZipFile(str(copie_ods)) as archive:
            noms = archive.namelist()
            amorce = archive.getinfo('mimetype')
            verif(noms[0] == 'mimetype',
                  'l’entrée mimetype n’est pas la première : %r' % noms[:3])
            verif(amorce.compress_type == zipfile.ZIP_STORED,
                  'l’entrée mimetype est compressée : LibreOffice refusera le fichier')
            verif(archive.read('mimetype')
                  == b'application/vnd.oasis.opendocument.spreadsheet',
                  'le type MIME de l’ODS est faux')
            verif('styles.xml' in noms,
                  'l’entrée annexe styles.xml a été perdue à l’écriture')
            verif('META-INF/manifest.xml' in noms, 'le manifeste ODF est absent')
            manifeste = archive.read('META-INF/manifest.xml').decode('utf-8')
            verif('styles.xml' in manifeste and 'content.xml' in manifeste,
                  'le manifeste ne liste pas toutes les entrées : %r' % manifeste)
        verif((os.stat(str(copie_ods)).st_mode & 0o777) == 0o640,
              'le mode du fichier n’a pas été rétabli : %s'
              % oct(os.stat(str(copie_ods)).st_mode & 0o777))
        verif(not list(dossier.glob('copie.ods.part')),
              'un fichier temporaire .part subsiste après l’écriture ODS')

        # --- ODS : case, ligne, colonne ------------------------------------
        tables_ods[0]['lignes'][0][1] = '999'
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif(relues[0]['lignes'][0][1] == '999',
              'la case modifiée n’a pas été écrite : %r' % relues[0]['lignes'][0])
        tables_ods[0]['lignes'].append(['patinette', '4'])
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif(relues[0]['lignes'][-1] == ['patinette', '4'],
              'la ligne ajoutée n’a pas été écrite : %r' % relues[0]['lignes'][-1])
        del tables_ods[0]['lignes'][1]
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif(len(relues[0]['lignes']) == len(tables_ods[0]['lignes']),
              'la ligne supprimée est revenue : %r' % relues[0]['lignes'])
        tables_ods[0]['colonnes'] = tables_ods[0]['colonnes'] + ['prix']
        tables_ods[0]['lignes'] = [l + ['1,50'] for l in tables_ods[0]['lignes']]
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif(relues[0]['colonnes'][-1] == 'prix',
              'la colonne ajoutée n’a pas été écrite : %r' % relues[0]['colonnes'])
        # Une valeur qui ressemble à un nombre mais n'en est pas un doit rester
        # du texte : « 007 » en 7, ou « 1/2 » en date, sont des pertes.
        verif(relues[0]['lignes'][0][-1] == '1,50',
              'une valeur textuelle a été convertie : %r' % relues[0]['lignes'][0])
        tables_ods[0]['colonnes'] = tables_ods[0]['colonnes'][:-1]
        tables_ods[0]['lignes'] = [l[:-1] for l in tables_ods[0]['lignes']]
        module.ecrire_ods(copie_ods, tables_ods)
        relues, _ = module.lire(copie_ods)
        verif('prix' not in relues[0]['colonnes'],
              'la colonne supprimée est revenue : %r' % relues[0]['colonnes'])

        # --- La fusion : ce qui n'est pas mentionné doit SURVIVRE ----------
        # C'est la perte la plus grave que cette écriture pouvait causer : un
        # appelant qui n'envoie que la feuille éditée ne demande pas la
        # disparition des autres.
        deux_ods = dossier / 'deux.ods'
        module.ecrire_ods(deux_ods, [
            {'nom': 'alpha', 'titre': 'Alpha', 'colonnes': ['a'], 'lignes': [['1']],
             'entete': True},
            {'nom': 'beta', 'titre': 'Beta', 'colonnes': ['b'], 'lignes': [['2']],
             'entete': True},
        ])
        # Les noms employés ensuite sont ceux que la LECTURE rend, comme le fait
        # l'interface : le titre « Alpha » devient la table « Alpha ». Écrire
        # avec des noms inventés ici testerait autre chose que le branchement
        # réel — et masquerait le garde-fou sur la casse.
        creees, _ = module.lire(deux_ods)
        noms_crees = [t['nom'] for t in creees]
        verif(len(creees) == 2, 'la création d’un ODS à deux feuilles a échoué : %r'
              % noms_crees)
        modifiee = dict(creees[0])
        modifiee['lignes'] = [['9']]
        module.ecrire_ods(deux_ods, [modifiee])
        relues, _ = module.lire(deux_ods)
        verif([t['nom'] for t in relues] == noms_crees,
              'écrire une seule feuille a supprimé l’autre : %r au lieu de %r'
              % ([t['nom'] for t in relues], noms_crees))
        verif(relues[0]['lignes'] == [['9']] and relues[1]['lignes'] == [['2']],
              'la fusion a mélangé les données : %r'
              % [(t['nom'], t['lignes']) for t in relues])
        module.ecrire_ods(deux_ods, [], supprimees=[noms_crees[1]])
        relues, _ = module.lire(deux_ods)
        verif([t['nom'] for t in relues] == [noms_crees[0]],
              'une suppression demandée n’a pas été faite : %r'
              % [t['nom'] for t in relues])
        # La casse compte : un nom qui n'en diffère que par là ne doit pas
        # créer en silence une seconde table au même titre.
        autre_casse = (relues[0]['nom'].lower()
                       if relues[0]['nom'] != relues[0]['nom'].lower()
                       else relues[0]['nom'].upper())
        try:
            module.ecrire_ods(deux_ods, [dict(relues[0], nom=autre_casse)])
            verif(False, 'un nom qui ne diffère que par la casse devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('casse' in str(erreur) and autre_casse in str(erreur),
                  'le refus ne nomme pas la casse en jeu : %r' % str(erreur))
        try:
            module.ecrire_ods(deux_ods, [], supprimees=['gamma'])
            verif(False, 'supprimer une table inexistante devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('gamma' in str(erreur),
                  'le refus ne nomme pas la table demandée : %r' % str(erreur))
        try:
            module.ecrire_ods(deux_ods, [relues[0]], supprimees=[relues[0]['nom']])
            verif(False, 'une table à la fois écrite et supprimée devrait être refusée')
        except module.DonneesRefusees as erreur:
            verif('à la fois' in str(erreur),
                  'le refus n’explique pas la contradiction : %r' % str(erreur))
        try:
            module.ecrire_ods(deux_ods, [relues[0], dict(relues[0])])
            verif(False, 'deux tables de même nom devraient être refusées')
        except module.DonneesRefusees as erreur:
            verif('même nom' in str(erreur),
                  'le refus ne nomme pas le doublon : %r' % str(erreur))

        # --- ODS : refus d'écraser des formules ----------------------------
        try:
            module.ecrire_ods(c['ods_formules'], [])
            verif(False, 'écrire par-dessus un ODS à formules devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('formules' in str(erreur),
                  'le refus ODS ne nomme pas les formules : %r' % str(erreur))
        tables_formules, _ = module.lire(c['ods_formules'])
        verif(tables_formules[0]['formules'] is True,
              'un ODS à formules n’est pas annoncé comme tel')

        # --- XML : aller-retour sur les cinq formes de document ------------
        for cle in ('xml_attributs', 'xml_mixte', 'xml_collision', 'xml_espaces',
                    'xml_texte', 'xml_impropre'):
            copie = dossier / ('copie-' + cle + '.xml')
            shutil.copyfile(str(c[cle]), str(copie))
            avant = module.lire_xml(copie)
            module.ecrire_xml(copie, avant)
            apres = module.lire_xml(copie)
            verif([(t['nom'], t['colonnes'], t['lignes']) for t in apres]
                  == [(t['nom'], t['colonnes'], t['lignes']) for t in avant],
                  'l’aller-retour XML de %s a changé les données : %r -> %r'
                  % (cle, [(t['nom'], t['lignes']) for t in avant],
                     [(t['nom'], t['lignes']) for t in apres]))

        # --- XML : déclaration, DOCTYPE, commentaires, espaces de noms -----
        riche = dossier / 'riche.xml'
        riche.write_text(
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<!DOCTYPE carnet SYSTEM "c.dtd">\n'
            '<carnet xmlns:c="urn:c">\n'
            '  <!-- mes contacts -->\n'
            '  <c:contact id="1" nom="Ada"/>\n'
            '  <c:contact id="2" nom="Grace"/>\n'
            '</carnet>\n', encoding='utf-8')
        module.ecrire_xml(riche, module.lire_xml(riche))
        brut = riche.read_bytes()
        verif(b'standalone="yes"' in brut, 'le standalone de la déclaration a été perdu')
        verif(b'<!DOCTYPE carnet SYSTEM "c.dtd">' in brut, 'le DOCTYPE a été perdu')
        verif(b'<!-- mes contacts -->' in brut,
              'un commentaire a été effacé par la réécriture')
        verif(b'xmlns:c="urn:c"' in brut and b'<c:contact' in brut,
              'l’espace de noms ou son préfixe a été perdu : %r' % brut[:200])

        # --- XML : case, ligne, colonne ------------------------------------
        tables_xml = module.lire_xml(riche)
        tables_xml[0]['lignes'][1][1] = 'Grace Hopper'
        module.ecrire_xml(riche, tables_xml)
        relues = module.lire_xml(riche)
        verif(relues[0]['lignes'][1] == ['2', 'Grace Hopper'],
              'la case XML modifiée n’a pas été écrite : %r' % relues[0]['lignes'])
        verif(relues[0]['lignes'][0] == ['1', 'Ada'],
              'une case voisine a été altérée : %r' % relues[0]['lignes'])
        relues[0]['lignes'].append(['3', 'Katherine'])
        module.ecrire_xml(riche, relues)
        verif(module.lire_xml(riche)[0]['lignes'][2] == ['3', 'Katherine'],
              'la ligne XML ajoutée n’a pas été écrite')
        tables_xml = module.lire_xml(riche)
        del tables_xml[0]['lignes'][1]
        module.ecrire_xml(riche, tables_xml)
        verif(module.lire_xml(riche)[0]['lignes'] == [['1', 'Ada'], ['3', 'Katherine']],
              'la ligne XML supprimée est revenue : %r'
              % module.lire_xml(riche)[0]['lignes'])
        tables_xml = module.lire_xml(riche)
        tables_xml[0]['colonnes'] = tables_xml[0]['colonnes'] + ['ville', '@role']
        tables_xml[0]['lignes'] = [l + ['Paris', 'admin'] for l in tables_xml[0]['lignes']]
        module.ecrire_xml(riche, tables_xml)
        apres = module.lire_xml(riche)
        verif('ville' in apres[0]['colonnes'],
              'la colonne enfant ajoutée est absente : %r' % apres[0]['colonnes'])
        verif(all(l[apres[0]['colonnes'].index('ville')] == 'Paris'
                  for l in apres[0]['lignes']),
              'la colonne enfant n’a pas été écrite partout : %r' % apres[0]['lignes'])
        verif('role' in apres[0]['colonnes'] or '@role' in apres[0]['colonnes'],
              'la colonne attribut ajoutée est absente : %r' % apres[0]['colonnes'])
        indice_role = apres[0]['colonnes'].index(
            'role' if 'role' in apres[0]['colonnes'] else '@role')
        verif(all(l[indice_role] == 'admin' for l in apres[0]['lignes']),
              'l’attribut ajouté n’a pas été écrit partout : %r' % apres[0]['lignes'])
        # Le nom d'une colonne ajoutée doit survivre à la relecture : sinon la
        # deuxième écriture verrait une colonne supprimée plus une ajoutée alors
        # que l'utilisateur n'a rien changé.
        module.ecrire_xml(riche, apres)
        verif(module.lire_xml(riche)[0]['colonnes'] == apres[0]['colonnes'],
              'un nom de colonne ajouté n’est pas stable : %r puis %r'
              % (apres[0]['colonnes'], module.lire_xml(riche)[0]['colonnes']))
        garde = list(apres[0]['colonnes'])
        apres[0]['colonnes'] = [x for x in garde if x != 'ville']
        apres[0]['lignes'] = [[v for i, v in enumerate(l) if garde[i] != 'ville']
                              for l in apres[0]['lignes']]
        module.ecrire_xml(riche, apres)
        apres2 = module.lire_xml(riche)
        verif('ville' not in apres2[0]['colonnes'],
              'la colonne XML supprimée est revenue : %r' % apres2[0]['colonnes'])
        verif('<ville>' not in riche.read_text(encoding='utf-8'),
              'l’élément d’une colonne supprimée subsiste dans le document')

        # --- XML : ce qui n'est pas mentionné survit -----------------------
        deux_xml = dossier / 'deux.xml'
        deux_xml.write_text('<r><a x="1"/><a x="2"/><b y="1"/><b y="2"/></r>',
                            encoding='utf-8')
        tables_deux = module.lire_xml(deux_xml)
        verif(sorted(t['nom'] for t in tables_deux) == ['a', 'b'],
              'deux familles d’éléments ne donnent pas deux tables : %r'
              % [t['nom'] for t in tables_deux])
        module.ecrire_xml(deux_xml, [t for t in tables_deux if t['nom'] == 'a'])
        verif(sorted(t['nom'] for t in module.lire_xml(deux_xml)) == ['a', 'b'],
              'écrire une seule table XML a supprimé l’autre : %r'
              % [t['nom'] for t in module.lire_xml(deux_xml)])
        module.ecrire_xml(deux_xml, [], supprimees=['b'])
        verif([t['nom'] for t in module.lire_xml(deux_xml)] == ['a'],
              'une suppression XML demandée n’a pas été faite : %r'
              % [t['nom'] for t in module.lire_xml(deux_xml)])
        verif('<b ' not in deux_xml.read_text(encoding='utf-8'),
              'les éléments d’une table XML supprimée subsistent')

        # --- XML : deux tables de même nom ne se confondent pas ------------
        imbrique = dossier / 'imbrique.xml'
        imbrique.write_text(
            '<r><e><g><h>1</h><h>2</h></g></e><e><g><h>3</h><h>4</h></g></e></r>',
            encoding='utf-8')
        tables_imb = module.lire_xml(imbrique)
        noms_imb = [t['nom'] for t in tables_imb]
        verif(len(noms_imb) == len(set(noms_imb)),
              'deux tables XML portent le même nom : %r' % noms_imb)
        seconde = [t for t in tables_imb if t['nom'].startswith('h')][-1]
        resultat = module.interroger(tables_imb, 'SELECT * FROM "%s"' % seconde['nom'])
        verif([l[0] for l in resultat['lignes']] == ['3', '4'],
              'le miroir SQL ne rend pas la bonne table homonyme : %r'
              % resultat['lignes'])
        # Éditer la table parente ne doit rien coûter aux tables enfants.
        parente = [t for t in tables_imb if t['nom'] == 'e'][0]
        parente['lignes'][0] = ['modifié']
        module.ecrire_xml(imbrique, [parente])
        apres_imb = module.lire_xml(imbrique)
        verif(len(apres_imb) == len(tables_imb),
              'écrire une table XML a fait disparaître les autres : %r'
              % [t['nom'] for t in apres_imb])
        verif([t['lignes'] for t in apres_imb if t['nom'].startswith('h')]
              == [[['1'], ['2']], [['3'], ['4']]],
              'les sous-éléments ont été altérés : %r'
              % [(t['nom'], t['lignes']) for t in apres_imb])

        # --- XML : les refus nommés ----------------------------------------
        try:
            module.ecrire_xml(deux_xml,
                              [{'nom': 'inconnue', 'colonnes': ['x'], 'lignes': [['1']]}])
            verif(False, 'écrire une table XML inconnue devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('inconnue' in str(erreur) and 'texte' in str(erreur),
                  'le refus ne nomme pas la table ni la voie de recours : %r'
                  % str(erreur))
        try:
            module.ecrire_xml(deux_xml,
                              [{'nom': 'a', 'colonnes': ['x'],
                                'lignes': [['z' * (module.MAX_CELLULE + 1)]]}])
            verif(False, 'une cellule XML hors limite devrait être refusée')
        except module.DonneesRefusees as erreur:
            verif(str(module.MAX_CELLULE) in str(erreur),
                  'le refus ne cite pas la limite : %r' % str(erreur))
        try:
            module.ecrire_xml(deux_xml,
                              [{'nom': 'a', 'colonnes': ['x'],
                                'lignes': [['%d' % i] for i in range(module.MAX_LIGNES + 2)]}])
            verif(False, 'trop de lignes XML devraient être refusées')
        except module.DonneesRefusees as erreur:
            verif('lignes' in str(erreur),
                  'le refus ne cite pas les lignes : %r' % str(erreur))
        casse = dossier / 'casse.xml'
        casse.write_text('<r><e/>', encoding='utf-8')
        try:
            module.ecrire_xml(casse, [])
            verif(False, 'écrire un XML invalide devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('invalide' in str(erreur),
                  'le refus ne dit pas que le document est invalide : %r' % str(erreur))
        try:
            module.ecrire_xml(dossier / 'absent.xml', [])
            verif(False, 'écrire un XML absent devrait être refusé')
        except module.DonneesRefusees as erreur:
            verif('illisible' in str(erreur),
                  'le refus d’un fichier absent n’est pas explicite : %r' % str(erreur))
        # Un document sans répétition n'a aucune table : l'écrire ne doit rien
        # casser, et surtout rien inventer.
        plat = dossier / 'plat.xml'
        shutil.copyfile(str(c['xml_plat']), str(plat))
        avant_plat = plat.read_bytes()
        module.ecrire_xml(plat, [])
        verif(module.lire_xml(plat) == [], 'un document plat ne doit rien rendre')
        verif(b'<config' in plat.read_bytes(),
              'un document sans table a été abîmé : %r' % plat.read_bytes()[:120])
        verif(len(plat.read_bytes()) > 0, 'le document plat a été vidé')
        del avant_plat

        # --- XLSX : la fusion et la ligne de titres ------------------------
        if c['xlsx']:
            copie_x = dossier / 'fusion.xlsx'
            shutil.copyfile(str(c['xlsx']), str(copie_x))
            tables_x, _ = module.lire(copie_x)
            verif(tables_x[0]['entete'] is True,
                  'la fixture XLSX devrait avoir un en-tête reconnu')
            tables_x[0]['lignes'][0][1] = 'Alicia'
            module.ecrire_xlsx(copie_x, [tables_x[0]])
            relues_x, _ = module.lire(copie_x)
            verif(len(relues_x) == 2,
                  'écrire une seule feuille XLSX a supprimé l’autre : %r'
                  % [t['nom'] for t in relues_x])
            verif(relues_x[0]['colonnes'] == tables_x[0]['colonnes'],
                  'la ligne de titres a été perdue à l’écriture : %r'
                  % relues_x[0]['colonnes'])
            verif(relues_x[0]['lignes'][0][1] == 'Alicia',
                  'la case XLSX modifiée n’a pas été écrite : %r'
                  % relues_x[0]['lignes'][0])
            verif(len(relues_x[0]['lignes']) == len(tables_x[0]['lignes']),
                  'le nombre de lignes XLSX a changé : %d puis %d'
                  % (len(tables_x[0]['lignes']), len(relues_x[0]['lignes'])))
            module.ecrire_xlsx(copie_x, [], supprimees=[relues_x[1]['nom']])
            relues_x, _ = module.lire(copie_x)
            verif(len(relues_x) == 1,
                  'une suppression XLSX demandée n’a pas été faite : %r'
                  % [t['nom'] for t in relues_x])
            os.chmod(str(copie_x), 0o600)
            module.ecrire_xlsx(copie_x, relues_x)
            verif((os.stat(str(copie_x)).st_mode & 0o777) == 0o600,
                  'le mode du XLSX n’a pas été rétabli : %s'
                  % oct(os.stat(str(copie_x)).st_mode & 0o777))

        # --- Des feuilles homonymes ne se confondent pas -------------------
        if c['doublon_xlsx']:
            tables_d, _ = module.lire(c['doublon_xlsx'])
            noms_d = [t['nom'] for t in tables_d]
            verif(len(noms_d) == len(set(n.lower() for n in noms_d)),
                  'deux feuilles donnent le même nom de table : %r' % noms_d)
            resultat = module.interroger(
                tables_d, 'SELECT COUNT(*) FROM "%s"' % noms_d[-1])
            verif(resultat['lignes'] and resultat['lignes'][0][0] == '1',
                  'le miroir ne voit pas la seconde feuille homonyme : %r'
                  % resultat['lignes'])

        # --- XML : ce qui entoure la racine est recopié --------------------
        # ElementTree ne conserve RIEN de ce qui est hors de l'élément racine :
        # un commentaire placé avant ou après elle n'est nulle part dans l'arbre.
        # Sans ces contrôles, chaque enregistrement effaçait l'en-tête du
        # document, sans erreur et sans trace.
        cas_preambule = (
            ('hors-racine',
             '<?xml version="1.0"?>\n<!-- avant -->\n<!DOCTYPE r SYSTEM "r.dtd">\n'
             '<r>\n<!-- dedans -->\n<e x="1"/><e x="2"/>\n</r>\n<!-- apres -->\n',
             (b'<!-- avant -->', b'<!DOCTYPE r SYSTEM "r.dtd">',
              b'<!-- dedans -->', b'<!-- apres -->'), True),
            ('instructions',
             '<?xml version="1.0"?>\n<?xml-stylesheet href="s.xsl"?>\n'
             '<r><e x="1"/><e x="2"/></r>\n<?fin?>\n',
             (b'<?xml-stylesheet href="s.xsl"?>', b'<?fin?>'), True),
            ('racine-auto-fermante', '<?xml version="1.0"?>\n<config/>\n',
             (b'<config',), False),
            ('sans-declaration', '<r><e x="1"/><e x="2"/></r>',
             (b'encoding="UTF-8"',), True),
            ('doctype-interne',
             '<?xml version="1.0"?>\n<!DOCTYPE r [\n<!ENTITY n "Ada">\n]>\n'
             '<r><e x="1"/><e x="2"/></r>\n',
             (b'<!ENTITY n "Ada">',), True),
        )
        for nom, contenu, attendus, modifiable in cas_preambule:
            fichier = dossier / ('preambule-' + nom + '.xml')
            fichier.write_text(contenu, encoding='utf-8')
            possible, raison = module.ecriture_possible(fichier)
            verif(possible, 'préambule « %s » : écriture refusée à tort : %s'
                  % (nom, raison))
            tables = module.lire_xml(fichier)
            verif(bool(tables) is modifiable,
                  'préambule « %s » : %d table(s) alors que %s'
                  % (nom, len(tables), 'le document en porte' if modifiable
                     else 'le document n’en porte pas'))
            if tables:
                tables[0]['lignes'][0][0] = 'modifie'
            module.ecrire_xml(fichier, tables)
            brut = fichier.read_bytes()
            for morceau in attendus:
                verif(morceau in brut, 'préambule « %s » : %r perdu, obtenu %r'
                      % (nom, morceau, brut[:220]))
            relues = module.lire_xml(fichier)
            verif(bool(relues) is modifiable,
                  'préambule « %s » : le document ne se relit plus comme avant'
                  % nom)
            if relues:
                verif(relues[0]['lignes'][0][0] == 'modifie',
                      'préambule « %s » : la modification n’a pas été écrite : %r'
                      % (nom, relues[0]['lignes']))

        # Une marque d'ordre des octets est recopiée, et une seule fois.
        marque = b'\xef\xbb\xbf'
        fichier = dossier / 'preambule-bom.xml'
        fichier.write_bytes(marque + '<!-- tete -->\n<r><e x="1"/><e x="2"/></r>'.encode('utf-8'))
        possible, raison = module.ecriture_possible(fichier)
        verif(possible, 'un XML avec BOM devrait pouvoir être écrit : %s' % raison)
        tables = module.lire_xml(fichier)
        tables[0]['lignes'][1][0] = 'modifie'
        module.ecrire_xml(fichier, tables)
        brut = fichier.read_bytes()
        verif(brut.startswith(marque) and brut.count(marque) == 1,
              'la BOM n’a pas été recopiée exactement une fois : %r' % brut[:40])
        verif(b'<!-- tete -->' in brut, 'le commentaire d’un XML avec BOM a été perdu')
        verif(module.lire_xml(fichier)[0]['lignes'] == [['1'], ['modifie']],
              'un XML avec BOM ne se relit pas correctement : %r'
              % module.lire_xml(fichier)[0]['lignes'])

        # Un encodage autre qu'UTF-8 est transcodé, pas recopié tel quel : des
        # octets Latin-1 sous une déclaration UTF-8 feraient un document invalide.
        fichier = dossier / 'preambule-latin1.xml'
        fichier.write_bytes(
            '<?xml version="1.0" encoding="ISO-8859-1"?>\n<!-- été -->\n'
            '<r><e nom="René"/><e nom="Zoé"/></r>\n'.encode('latin-1'))
        possible, raison = module.ecriture_possible(fichier)
        verif(possible, 'un XML Latin-1 devrait pouvoir être écrit : %s' % raison)
        tables = module.lire_xml(fichier)
        verif(tables[0]['lignes'][0] == ['René'],
              'la lecture Latin-1 rend autre chose : %r' % tables[0]['lignes'])
        module.ecrire_xml(fichier, tables)
        brut = fichier.read_bytes()
        verif(b'encoding="UTF-8"' in brut and b'encoding="ISO-8859-1"' not in brut,
              'la déclaration d’un XML transcodé annonce encore l’ancien encodage')
        verif('été'.encode('utf-8') in brut,
              'le commentaire accentué n’a pas été transcodé : %r' % brut[:120])
        verif(module.lire_xml(fichier)[0]['lignes'] == [['René'], ['Zoé']],
              'un XML transcodé ne se relit pas : %r' % module.lire_xml(fichier)[0]['lignes'])

        # Un document en UTF-16 ne peut pas être réécrit octet pour octet : le
        # refus est dit à l'OUVERTURE, et non au premier clic sur Enregistrer.
        fichier = dossier / 'preambule-utf16.xml'
        fichier.write_bytes('<?xml version="1.0" encoding="UTF-16"?>\n'
                            '<r><e x="1"/><e x="2"/></r>'.encode('utf-16'))
        verif(module.lire_xml(fichier)[0]['lignes'] == [['1'], ['2']],
              'un XML UTF-16 devrait au moins se LIRE')
        possible, raison = module.ecriture_possible(fichier)
        verif(not possible, 'un XML UTF-16 devrait être annoncé non réécrivable')
        verif('utf-16' in raison.lower() and 'texte' in raison,
              'le refus ne nomme ni l’encodage ni la voie de recours : %r' % raison)

        # --- Ce que l'ouverture annonce correspond à ce que l'écriture fait --
        for cle, attendu in (('ods_formules', False), ('ods', True),
                             ('xml', True), ('xml_plat', True), ('texte', False)):
            possible, raison = module.ecriture_possible(c[cle])
            verif(possible is attendu,
                  'ecriture_possible(%s) rend %s au lieu de %s (raison : %r)'
                  % (cle, possible, attendu, raison))
            verif(bool(raison.strip()) is not attendu,
                  'ecriture_possible(%s) : la raison et le verdict ne concordent pas : %r'
                  % (cle, raison))
        if c['xlsx']:
            possible, raison = module.ecriture_possible(c['xlsx'])
            verif(possible is True, 'un classeur XLSX simple devrait être écrivable : %s' % raison)
            possible, raison = module.ecriture_possible(c['formules'])
            verif(possible is False and 'formules' in raison,
                  'un classeur XLSX à formules devrait être annoncé non écrivable : %r'
                  % raison)

        # --- Ce que l'écriture ne sait pas faire est ANNONCÉ ---------------
        refusees = capacites.get('ecritures_refusees') or {}
        verif('xml_nouvelle_table' in refusees
              and 'xml_renommer_colonne' in refusees,
              'les limites de l’écriture XML ne sont pas déclarées : %r' % refusees)
        for cle, texte in refusees.items():
            verif(bool(str(texte).strip()),
                  'la limite %r est déclarée sans explication' % cle)

        # -------------------------------------------------------------- 6
        # Le branchement sur database_tools.py : c'est ce que l'application
        # appelle réellement. Sans lui, le module serait correct et inutile.
        print('-- Branchement sur database_tools.Manager')
        import database_tools
        gestionnaire = database_tools.Manager()
        try:
            for nom, chemin, attendu in (
                    ('ods', c['ods'], 'ods'), ('xml', c['xml'], 'xml')):
                source = gestionnaire.open_file(str(chemin))
                verif(source['kind'] == attendu,
                      'Manager.open_file(%s) rend le kind %r' % (nom, source['kind']))
                verif(source.get('miroir') is True,
                      '%s : la réponse n’annonce pas le miroir' % nom)
                verif(bool(source.get('tables')),
                      '%s : aucune table annoncée' % nom)
                liste = gestionnaire.list_tables(source['id'])
                verif(bool(liste['tables']),
                      '%s : list_tables ne rend rien' % nom)
                premier = liste['tables'][0]['name']
                page = gestionnaire.rows(source['id'], '', premier, 0)
                verif(bool(page['columns']) and bool(page['rows']),
                      '%s : rows() ne rend ni colonnes ni lignes' % nom)
                verif(all('name' in col for col in page['columns']),
                      '%s : les colonnes n’ont pas la clef « name » attendue par '
                      'l’interface' % nom)
                requete = gestionnaire.query(
                    source['id'], 'SELECT COUNT(*) AS n FROM "%s"' % premier)
                verif(requete['columns'] == ['n'] and requete['rows'],
                      '%s : query() ne rend pas le résultat' % nom)
                verif(requete.get('miroir') is True,
                      '%s : query() n’annonce pas le miroir' % nom)
                verif(requete.get('committed') is False,
                      '%s : une requête sur miroir ne doit rien dire « committé »'
                      % nom)
                try:
                    gestionnaire.query(source['id'], 'DELETE FROM "%s"' % premier)
                    verif(False, '%s : une suppression sur miroir a été acceptée'
                          % nom)
                except database_tools.DataError as erreur:
                    verif('COPIE' in str(erreur) or 'copie' in str(erreur),
                          '%s : le refus n’explique pas la copie : %r'
                          % (nom, str(erreur)))

            if c['xlsx']:
                source = gestionnaire.open_file(str(c['xlsx']))
                verif(source['kind'] == 'xlsx', 'XLSX : kind %r' % source['kind'])
                verif(len(source['tables']) == 2,
                      'XLSX : %d feuille(s) annoncée(s)' % len(source['tables']))
                # Une base SQLite nommée autrement reste une base : c'est la
                # signature qui décide, et c'est le cas que l'ancienne règle
                # ratait.
                source = gestionnaire.open_file(str(c['sqlite_mal_nomme']))
                verif(source['kind'] == 'sqlite',
                      'une base SQLite en .dat n’est pas ouverte comme base : %r'
                      % source['kind'])
                source = gestionnaire.open_file(str(c['sqlite']))
                verif(source['kind'] == 'sqlite', 'SQLite : kind %r' % source['kind'])
                verif(source.get('miroir') is not True,
                      'une vraie base ne doit pas être annoncée comme miroir')
            # Le refus honnête d'un fichier dont le nom ment.
            try:
                gestionnaire.open_file(str(c['faux_sqlite']))
                verif(False, 'un faux .sqlite devrait être refusé avec la raison')
            except database_tools.DataError as erreur:
                verif('texte' in str(erreur),
                      'le refus d’un faux .sqlite devrait renvoyer vers le texte : '
                      '%r' % str(erreur))
        finally:
            gestionnaire.close_all()

    if echecs:
        for echec in echecs:
            print('  ECHEC : %s' % echec)
        print('\nBanc des données étendues : %d assertions, %d échec(s).'
              % (compte[0], len(echecs)))
        return 1
    print('\nBanc des données étendues : %d assertions, toutes conformes.'
          % compte[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
