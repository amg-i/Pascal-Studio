#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : l’espace de travail par projet (3.9.0).

Ce banc s’exécute sur un vrai dossier temporaire, jamais sur une maquette en
mémoire. Un espace de stockage se juge sur ce qu’il refuse : la surface
d’attaque est le chemin reçu du navigateur, et un seul cas mal contenu écrit ou
lit hors du dossier du projet.

Sont exercés, dans l’ordre :

  1. l’autonomie du module à l’import ;
  2. le nettoyage des noms et le découpage des chemins ;
  3. le confinement : remontées « .. », chemins absolus, séparateurs Windows,
     octet nul, nom trop long, chemin trop profond, nom réservé, identifiant de
     projet invalide, lien symbolique sur un fichier, sur un dossier, et sur le
     dossier du projet lui-même ;
  4. les écritures : contenu texte et binaire, collision renommée au lieu
     d’écraser, écrasement explicite, sous-dossier créé, plafonds de taille, de
     quota et de nombre, fichier temporaire nettoyé après un échec ;
  5. le listage, l’aperçu texte et le signalement d’un binaire ;
  6. renommer, supprimer, créer un dossier, et l’index d’origine qui suit.

Deux vérifications portent sur le système réel, hors de l’espace de test : le
vrai /etc/passwd et une vraie cible de lien symbolique doivent être intacts
après tous les essais d’écriture hostile. C’est ce qui distingue un chemin
« contenu » d’un chemin « refusé en apparence ».
"""

import importlib.util
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
ASSISTANT = MODIFICATIONS / 'assistant-ia'
CIBLE = ASSISTANT / 'espace_travail.py'

echecs = []
compte = [0]


def verif(condition, message):
    compte[0] += 1
    if not condition:
        echecs.append(message)


def charger():
    if not CIBLE.is_file():
        echecs.append('espace_travail.py introuvable : %s' % CIBLE)
        return None
    spec = importlib.util.spec_from_file_location('espace_travail', str(CIBLE))
    module = importlib.util.module_from_spec(spec)
    sys.modules['espace_travail'] = module
    spec.loader.exec_module(module)
    return module


SONDE = '\n'.join([
    'import importlib.util, sys',
    'spec = importlib.util.spec_from_file_location("et", sys.argv[1])',
    'm = importlib.util.module_from_spec(spec)',
    'spec.loader.exec_module(m)',
    'lourdes = [x for x in ("requests", "core", "starlette", "uvicorn") if x in sys.modules]',
    'print("LOURDES:" + (",".join(lourdes) if lourdes else "aucune"))',
    'print("MARQUEUR:" + m.MARQUEUR)',
    'noms = ("Espace", "CheminRefusé", "nettoyer_nom", "segments", "categorie",',
    '        "mime", "est_texte", "racine_defaut", "espace_defaut")',
    'print("API:" + str(all(hasattr(m, n) for n in noms)))',
])


def sonder_autonomie():
    with tempfile.TemporaryDirectory() as dossier:
        sonde = os.path.join(dossier, 'sonde.py')
        with open(sonde, 'w', encoding='utf-8') as flux:
            flux.write(SONDE)
        processus = subprocess.run([sys.executable, sonde, str(CIBLE)],
                                   capture_output=True, text=True, timeout=120)
        return processus, processus.stdout


def refuse(appel, message):
    """Vérifie qu’un appel lève CheminRefusé, et non une autre exception."""
    compte[0] += 1
    try:
        resultat = appel()
    except Exception as erreur:                      # noqa : le type exact importe
        if type(erreur).__name__ == 'CheminRefusé':
            return True
        echecs.append('%s : levée %s au lieu de CheminRefusé (%s)'
                      % (message, type(erreur).__name__, erreur))
        return False
    echecs.append('%s : aucun refus, résultat %r' % (message, resultat))
    return False


def main():
    et = charger()
    if et is None:
        return 1

    processus, sortie = sonder_autonomie()
    verif(processus.returncode == 0,
          'la sonde d’autonomie a échoué : %s' % processus.stderr.strip()[:400])
    verif('LOURDES:aucune' in sortie,
          'le module entraîne des dépendances lourdes à l’import : %s' % sortie.strip())
    verif('MARQUEUR:ps-3.9.0-espace' in sortie, 'marqueur de version absent de la sonde')
    verif('API:True' in sortie, 'une fonction publique manque à l’API du module')
    verif(et.MARQUEUR == 'ps-3.9.0-espace', 'MARQUEUR inattendu : %r' % et.MARQUEUR)
    print('autonomie : aucune dépendance lourde, API complète')

    # --- Noms et segments --------------------------------------------------------
    verif(et.nettoyer_nom('photo.jpg') == 'photo.jpg', 'un nom simple est abîmé')
    verif(et.nettoyer_nom('../../etc/passwd') == 'etcpasswd',
          'les séparateurs d’un nom sont conservés : %r' % et.nettoyer_nom('../../etc/passwd'))
    verif(et.nettoyer_nom('a\x00b.jpg') == 'ab.jpg', 'l’octet nul survit au nettoyage')
    verif(et.nettoyer_nom('  nom  avec   espaces  .txt') == 'nom avec espaces .txt',
          'les espaces ne sont pas normalisés : %r' % et.nettoyer_nom('  nom  avec   espaces  .txt'))
    verif(et.nettoyer_nom('...') == '', 'un nom fait de points est accepté')
    verif(et.nettoyer_nom('_index.json') == '', 'le nom réservé de l’index est accepté')
    verif(et.nettoyer_nom(None) == '', 'None produit un nom')
    verif(len(et.nettoyer_nom('x' * 5000)) == et.NOM_MAX,
          'un nom immense n’est pas tronqué à NOM_MAX')
    verif(et.nettoyer_nom('nom:avec*caractères?.txt') == 'nomaveccaractères.txt',
          'les caractères interdits sous Windows ne sont pas retirés')
    verif(et.segments('/etc/passwd') == ['etc', 'passwd'],
          'un chemin absolu n’est pas ramené à des segments relatifs : %r'
          % et.segments('/etc/passwd'))
    verif(et.segments('a\\b\\c.txt') == ['a', 'b', 'c.txt'],
          'le séparateur Windows n’est pas traité comme un séparateur')
    verif(et.segments('./a//b/') == ['a', 'b'], 'les segments vides et « . » survivent')
    verif(et.segments('') == [], 'un chemin vide produit des segments')
    verif('..' in et.segments('a/../b'), 'le segment « .. » doit rester visible pour être refusé')
    print('noms : nettoyage et découpage conformes')

    verif(et.extension('photo.JPG') == 'jpg', 'l’extension n’est pas mise en minuscules')
    verif(et.extension('sans_extension') == '', 'un nom sans point reçoit une extension')
    verif(et.categorie('rapport.docx') == 'documents', 'un docx n’est pas un document')
    verif(et.categorie('donnees.xlsx') == 'tableaux', 'un xlsx n’est pas un tableau')
    verif(et.categorie('archive.zip') == 'archives', 'un zip n’est pas une archive')
    verif(et.categorie('inconnu.xyz') == 'autre', 'une extension inconnue reçoit une famille')
    verif(et.mime('rapport.docx').startswith('application/vnd.openxmlformats'),
          'le MIME d’un docx est faux : %s' % et.mime('rapport.docx'))
    verif(et.mime('inconnu.xyz') == 'application/octet-stream',
          'le MIME par défaut n’est pas octet-stream')
    verif(et.est_texte('notes.txt') is True, 'un .txt n’est pas annoncé comme texte')
    verif(et.est_texte('donnees.csv') is True, 'un .csv n’est pas annoncé comme texte')
    verif(et.est_texte('rapport.docx') is False,
          'un .docx est annoncé comme texte : l’aperçu afficherait du bruit')
    verif(et.est_texte('photo.png') is False, 'un .png est annoncé comme texte')
    print('types : familles, MIME et nature texte cohérents')

    racine = tempfile.mkdtemp(prefix='ps-espace-')
    hors = tempfile.mkdtemp(prefix='ps-hors-')
    passe_reel = '/etc/passwd'
    passe_avant = os.stat(passe_reel).st_mtime if os.path.exists(passe_reel) else None
    try:
        # --- Identifiants de projet ---------------------------------------------
        espace = et.Espace(racine)
        dossier = espace.dossier('abc123def456')
        verif(os.path.isdir(dossier), 'le dossier d’un projet valide n’est pas créé')
        verif(dossier == os.path.join(os.path.realpath(racine), 'abc123def456'),
              'le dossier du projet n’est pas directement sous la racine')
        verif(espace.dossier('abc123def456') == dossier,
              'le dossier d’un projet n’est pas stable d’un appel à l’autre')
        for mauvais in ('', '   ', '..', '.', '../autre', 'a/b', 'a\\b',
                        'x' * 100, 'projet\x00', 'hélà'):
            refuse(lambda m=mauvais: espace.dossier(m),
                   'identifiant de projet accepté à tort : %r' % mauvais)
        print('projets : identifiants valides créés, %d invalides refusés' % 10)

        # --- Confinement des chemins --------------------------------------------
        projet = 'abc123def456'
        espace.ecrire(projet, 'deja_la.txt', 'contenu existant')
        for hostile in ('../secret.txt', 'a/../../b.txt', '../../etc/passwd',
                        'sous/../../dehors.txt', '..\\..\\windows\\system.ini',
                        'a/' * 20 + 'profond.txt', '', '   ', '/',
                        '_index.json', 'sous/_index.json', 'é' * 300 + '.txt'):
            refuse(lambda h=hostile: espace.resoudre(projet, h),
                   'chemin hostile non refusé : %r' % hostile)
        verif(not os.path.exists(os.path.join(hors, 'secret.txt')),
              'un chemin hostile a créé un fichier hors de l’espace')
        # Un chemin absolu doit être refusé, ou ramené dans l’espace. Dans les
        # deux cas il ne doit rien toucher dehors : c’est le vrai /etc/passwd qui
        # en décide, pas le code du module.
        try:
            cible = espace.resoudre(projet, '/etc/passwd')
        except et.CheminRefusé:
            cible = None
        verif(cible is None or cible.startswith(os.path.realpath(racine)),
              'un chemin absolu n’est pas contenu : %s' % cible)
        fiche = espace.ecrire(projet, '/etc/passwd', 'essai confiné')
        verif(fiche['chemin'] == 'etc/passwd',
              'un chemin absolu n’est pas ramené à un chemin d’espace : %r' % fiche['chemin'])
        verif(os.path.exists(os.path.join(dossier, 'etc', 'passwd')),
              'le chemin absolu confiné n’a pas été écrit dans l’espace')
        if passe_avant is not None:
            verif(os.stat(passe_reel).st_mtime == passe_avant,
                  'le vrai /etc/passwd a été modifié par un essai d’écriture')
        print('confinement : %d chemins hostiles refusés, /etc/passwd intact' % 12)

        # --- Liens symboliques ---------------------------------------------------
        secret = os.path.join(hors, 'secret.txt')
        with open(secret, 'w', encoding='utf-8') as flux:
            flux.write('ne pas toucher')
        lien = os.path.join(dossier, 'lien.txt')
        os.symlink(secret, lien)
        refuse(lambda: espace.resoudre(projet, 'lien.txt', existe=True),
               'un lien symbolique vers l’extérieur est résolu')
        refuse(lambda: espace.ecrire(projet, 'lien.txt', 'écrasé', ecraser=True),
               'une écriture sur un lien symbolique est acceptée')
        with open(secret, encoding='utf-8') as flux:
            verif(flux.read() == 'ne pas toucher',
                  'la cible d’un lien symbolique a été écrasée')
        refuse(lambda: espace.lire(projet, 'lien.txt'),
               'la lecture d’un lien symbolique est acceptée')

        sous_lien = os.path.join(dossier, 'souslien')
        os.symlink(hors, sous_lien)
        refuse(lambda: espace.resoudre(projet, 'souslien/fichier.txt'),
               'un chemin traversant un dossier-lien est résolu')
        refuse(lambda: espace.ecrire(projet, 'souslien/fichier.txt', 'x'),
               'une écriture dans un dossier-lien est acceptée')
        verif(not os.path.exists(os.path.join(hors, 'fichier.txt')),
              'un fichier a été créé hors de l’espace via un dossier-lien')

        projet_lien = 'projetlien'
        os.symlink(hors, os.path.join(os.path.realpath(racine), projet_lien))
        refuse(lambda: espace.dossier(projet_lien),
               'un dossier de projet qui est un lien est accepté')
        listing = espace.lister(projet)
        verif(all('lien' not in f['nom'] for f in listing['fichiers']),
              'un lien symbolique apparaît dans le listage')
        verif(all('souslien' not in d['nom'] for d in listing['dossiers']),
              'un dossier-lien apparaît dans le listage')
        print('liens : fichier-lien, dossier-lien et projet-lien refusés')

        # --- Écritures -----------------------------------------------------------
        fiche = espace.ecrire(projet, 'rapport.docx', b'\x00\x01binaire')
        verif(fiche['nom'] == 'rapport.docx' and fiche['octets'] == 9,
              'la fiche d’un dépôt binaire est fausse : %r' % fiche)
        verif(fiche['origine'] == 'depot', 'l’origine d’un dépôt n’est pas tracée')
        verif(fiche['texte'] is False, 'un docx est annoncé comme texte dans sa fiche')
        verif(fiche['marqueur'] == et.MARQUEUR, 'le marqueur manque à la fiche')
        verif(espace.lire(projet, 'rapport.docx') == b'\x00\x01binaire',
              'un contenu binaire n’est pas rendu intact')

        fiche = espace.ecrire(projet, 'note.md', '# Titre', origine='export',
                              detail='export docx de la réponse 12')
        verif(espace.lire(projet, 'note.md').decode('utf-8') == '# Titre',
              'un contenu texte n’est pas encodé en UTF-8')
        verif(fiche['origine'] == 'export' and fiche['detail'].startswith('export docx'),
              'l’origine et le détail d’un export ne sont pas conservés')

        doublon = espace.ecrire(projet, 'note.md', 'autre version')
        verif(doublon['nom'] == 'note (2).md',
              'une collision n’est pas renommée : %r' % doublon['nom'])
        verif(espace.lire(projet, 'note.md').decode('utf-8') == '# Titre',
              'le document déjà déposé a été écrasé par un second dépôt')
        troisieme = espace.ecrire(projet, 'note.md', 'encore')
        verif(troisieme['nom'] == 'note (3).md',
              'la seconde collision n’est pas numérotée : %r' % troisieme['nom'])
        espace.ecrire(projet, 'note.md', 'remplacement', ecraser=True)
        verif(espace.lire(projet, 'note.md').decode('utf-8') == 'remplacement',
              'l’écrasement explicite ne fonctionne pas')

        imbrique = espace.ecrire(projet, 'livrables/2026/rapport.txt', 'profond')
        verif(imbrique['chemin'] == 'livrables/2026/rapport.txt',
              'un chemin imbriqué n’est pas créé : %r' % imbrique['chemin'])
        verif(os.path.isfile(os.path.join(dossier, 'livrables', '2026', 'rapport.txt')),
              'les dossiers parents d’un dépôt imbriqué ne sont pas créés')

        petit = et.Espace(racine, taille_max=10, quota=1000, nombre_max=50)
        refuse(lambda: petit.ecrire(projet, 'gros.txt', 'x' * 11),
               'le plafond de taille par fichier n’est pas appliqué')
        verif(not os.path.exists(os.path.join(dossier, 'gros.txt')),
              'un fichier refusé par la taille a quand même été écrit')
        quota = et.Espace(racine, quota=100, nombre_max=50)
        quota.ecrire('projetquota', 'a.txt', 'x' * 60)
        refuse(lambda: quota.ecrire('projetquota', 'b.txt', 'x' * 60),
               'le quota de l’espace du projet n’est pas appliqué')
        nombre = et.Espace(racine, nombre_max=2)
        nombre.ecrire('projetnombre', 'a.txt', 'x')
        nombre.ecrire('projetnombre', 'b.txt', 'x')
        refuse(lambda: nombre.ecrire('projetnombre', 'c.txt', 'x'),
               'le plafond de nombre de documents n’est pas appliqué')
        espace.ecrire(projet, 'rapport.docx', 'texte', ecraser=True)
        verif(espace.lire(projet, 'rapport.docx') == b'texte',
              'un écrasement explicite ne remplace pas le contenu')
        refuse(lambda: espace.ecrire(projet, 'livrables', 'x', ecraser=True),
               'écraser explicitement un dossier est accepté')
        verif(os.path.isdir(os.path.join(dossier, 'livrables')),
              'un dossier ciblé par un dépôt a disparu')
        # Sans écrasement, un dépôt visant un nom de dossier crée un frère numéroté :
        # rien n'est détruit, et l'utilisateur retrouve son document.
        frere = espace.ecrire(projet, 'livrables', 'x')
        verif(frere['chemin'] == 'livrables (2)',
              'un dépôt sur un nom de dossier ne produit pas un frère numéroté : %r'
              % frere['chemin'])
        verif(os.path.isdir(os.path.join(dossier, 'livrables')),
              'le dossier a été remplacé par le dépôt d’un frère numéroté')
        verif(not [n for n in os.listdir(dossier) if n.endswith('.part')],
              'un fichier temporaire .part subsiste après un échec')
        refuse(lambda: espace.ecrire(projet, 'note.md', object()),
               'un contenu qui n’est ni texte ni octets est accepté')
        print('écritures : collisions renommées, plafonds appliqués, temporaires nettoyés')

        # --- Listage et aperçu ---------------------------------------------------
        # Des documents dédiés, que les essais précédents n’ont pas modifiés : un
        # banc qui lit l’état laissé par un autre test ne vérifie rien de stable.
        espace.ecrire(projet, 'export.docx', b'PK\x03\x04export', origine='export',
                      detail='export docx de la réponse 12')
        espace.ecrire(projet, 'binaire.zip', b'\x00\x01\x02zip')
        listing = espace.lister(projet)
        noms = [f['nom'] for f in listing['fichiers']]
        verif('note.md' in noms and 'rapport.docx' in noms,
              'le listage oublie des documents : %r' % noms)
        verif('export.docx' in noms, 'un export capturé n’apparaît pas dans le listage')
        verif(et.INDEX not in noms, 'l’index interne apparaît dans le listage')
        verif(all(not n.endswith(('.part', '.tmp')) for n in noms),
              'un fichier temporaire apparaît dans le listage')
        cles = [(f['dossier'], f['nom']) for f in listing['fichiers']]
        verif(cles == sorted(cles),
              'les documents ne sont pas triés par dossier puis par nom : %r' % cles)
        dossiers = {d['chemin']: d['nom'] for d in listing['dossiers']}
        verif(dossiers.get('livrables') == 'livrables',
              'un dossier de premier niveau est mal listé : %r' % dossiers)
        verif(dossiers.get('livrables/2026') == '2026',
              'un sous-dossier n’est pas listé avec son chemin relatif : %r' % dossiers)
        verif(all('..' not in c for c in dossiers), 'un chemin de dossier remonte')
        verif(listing['projet'] == projet, 'le projet n’est pas identifié dans le listage')
        verif(listing['volume']['nombre'] == len(noms),
              'le volume ne compte pas le même nombre de documents que le listage')
        verif(listing['volume']['octets'] > 0,
              'le volume total est nul alors qu’il y a des documents')
        verif(listing['volume']['quota'] == et.QUOTA_PAR_PROJET,
              'le quota annoncé n’est pas celui du module')
        exportes = [f for f in listing['fichiers'] if f['origine'] == 'export']
        verif(len(exportes) == 1 and exportes[0]['nom'] == 'export.docx',
              'l’origine « export » a disparu du listage : %r'
              % [(f['nom'], f['origine']) for f in listing['fichiers']])
        verif(exportes[0]['detail'].startswith('export docx'),
              'le détail d’un export ne survit pas au listage')

        apercu = espace.apercu(projet, 'note.md')
        verif(apercu['binaire'] is False and apercu['texte'] == 'remplacement',
              'l’aperçu d’un texte est faux : %r' % apercu)
        apercu = espace.apercu(projet, 'binaire.zip')
        verif(apercu['binaire'] is True and apercu['texte'] == '',
              'un document binaire n’est pas signalé comme tel : %r' % apercu)
        verif(espace.apercu(projet, 'export.docx')['binaire'] is True,
              'un docx n’est pas détecté comme binaire')
        long_texte = et.Espace(racine)
        long_texte.ecrire(projet, 'long.txt', 'ligne\n' * 100000)
        apercu = long_texte.apercu(projet, 'long.txt')
        verif(len(apercu['texte']) <= et.TAILLE_APERCU,
              'l’aperçu d’un long texte dépasse la borne : %d' % len(apercu['texte']))
        verif(apercu['tronque'] is True, 'un aperçu tronqué ne le signale pas')
        # Détection de binaire sur le contenu, pas sur l’extension. Un petit ZIP
        # peut ne contenir aucun octet nul : c’est ce cas qui a révélé le défaut.
        verif(et.est_binaire(b'PK\x03\x04export') is True,
              'un ZIP sans octet nul n’est pas détecté comme binaire')
        verif(et.est_binaire(b'%PDF-1.7 ...') is True, 'un PDF n’est pas détecté')
        verif(et.est_binaire(b'donnees \x03\x04 brutes') is True,
              'des octets de contrôle sans amorce ne sont pas détectés')
        verif(et.est_binaire(b'\xc3\x28 invalide') is True,
              'un contenu non décodable en UTF-8 n’est pas détecté')
        verif(et.est_binaire(b'texte normal\navec des sauts\tet tabulations') is False,
              'un texte ordinaire est annoncé comme binaire')
        verif(et.est_binaire(b'') is False, 'un document vide est annoncé comme binaire')
        verif(et.famille_binaire(b'PK\x03\x04x') == 'zip',
              'la famille d’un ZIP n’est pas reconnue')
        verif(et.famille_binaire(b'%PDF-1.4') == 'pdf', 'la famille d’un PDF n’est pas reconnue')
        verif(et.famille_binaire(b'texte') == '', 'une famille est inventée pour un texte')
        espace.ecrire(projet, 'controle.dat', b'donnees \x03 brutes')
        verif(espace.apercu(projet, 'controle.dat')['binaire'] is True,
              'un fichier à octets de contrôle s’aperçoit comme du texte')
        espace.ecrire(projet, 'vide.txt', '')
        apercu = espace.apercu(projet, 'vide.txt')
        verif(apercu['binaire'] is False and apercu['texte'] == '',
              'l’aperçu d’un document vide est faux : %r' % apercu)
        verif(apercu['octets'] == 0, 'la taille d’un document vide est fausse')
        refuse(lambda: espace.apercu(projet, 'absent.txt'),
               'l’aperçu d’un document absent n’est pas refusé')
        refuse(lambda: espace.apercu(projet, 'livrables'),
               'l’aperçu d’un dossier est accepté')
        refuse(lambda: espace.lire(projet, 'absent.txt'),
               'la lecture d’un document absent n’est pas refusée')
        refuse(lambda: espace.lire(projet, 'livrables'),
               'la lecture d’un dossier est acceptée')
        print('listage : %d documents, %d dossiers, aperçus texte et binaire conformes'
              % (len(noms), len(listing['dossiers'])))

        # --- Renommer, supprimer, créer ------------------------------------------
        espace.ecrire(projet, 'brouillon.txt', 'à renommer')
        fiche = espace.renommer(projet, 'brouillon.txt', 'final.txt')
        verif(fiche['nom'] == 'final.txt', 'le renommage ne rend pas la bonne fiche')
        verif(not os.path.exists(os.path.join(dossier, 'brouillon.txt')),
              'l’ancien nom subsiste après un renommage')
        verif(espace.lire(projet, 'final.txt').decode('utf-8') == 'à renommer',
              'le contenu est perdu au renommage')
        refuse(lambda: espace.renommer(projet, 'final.txt', 'note.md'),
               'renommer par-dessus un document existant est accepté')
        refuse(lambda: espace.renommer(projet, 'final.txt', 'final.txt'),
               'renommer vers le même nom est accepté')
        refuse(lambda: espace.renommer(projet, 'final.txt', '../dehors.txt'),
               'renommer vers un chemin hostile est accepté')
        refuse(lambda: espace.renommer(projet, 'absent.txt', 'x.txt'),
               'renommer un document absent est accepté')
        fiche = espace.renommer(projet, 'final.txt', 'range/final.txt')
        verif(fiche['chemin'] == 'range/final.txt',
              'un renommage vers un sous-dossier à créer échoue : %r' % fiche)

        espace.ecrire(projet, 'suivi.md', '# suivi', origine='agent',
                      detail='écrit par l’agent')
        index = espace._lire_index(projet)
        verif(index.get('suivi.md', {}).get('origine') == 'agent',
              'l’index ne conserve pas l’origine d’un document d’agent')
        espace.renommer(projet, 'suivi.md', 'suivi-final.md')
        index = espace._lire_index(projet)
        verif(index.get('suivi-final.md', {}).get('origine') == 'agent',
              'l’index ne suit pas le renommage')
        verif('suivi.md' not in index, 'l’ancienne entrée d’index subsiste après renommage')

        espace.creer_dossier(projet, 'vide')
        verif(os.path.isdir(os.path.join(dossier, 'vide')), 'un dossier n’est pas créé')
        refuse(lambda: espace.creer_dossier(projet, 'vide'),
               'créer un dossier déjà présent est accepté')
        refuse(lambda: espace.creer_dossier(projet, '../dehors'),
               'créer un dossier hors de l’espace est accepté')

        resultat = espace.supprimer(projet, 'suivi-final.md')
        verif(resultat['supprime'] == 'suivi-final.md', 'la suppression ne rend pas le chemin')
        verif(not os.path.exists(os.path.join(dossier, 'suivi-final.md')),
              'un document supprimé est encore présent')
        verif('suivi-final.md' not in espace._lire_index(projet),
              'l’entrée d’index d’un document supprimé subsiste')
        espace.supprimer(projet, 'range')
        verif(not os.path.exists(os.path.join(dossier, 'range')),
              'un dossier supprimé récursivement est encore présent')
        refuse(lambda: espace.supprimer(projet, 'absent.txt'),
               'supprimer un document absent est accepté')
        refuse(lambda: espace.supprimer(projet, '.'),
               'supprimer la racine de l’espace est accepté')
        refuse(lambda: espace.supprimer(projet, '../autre'),
               'supprimer hors de l’espace est accepté')
        avec_lien = os.path.join(dossier, 'dossierlien')
        os.makedirs(avec_lien, exist_ok=True)
        os.symlink(secret, os.path.join(avec_lien, 'lien.txt'))
        refuse(lambda: espace.supprimer(projet, 'dossierlien'),
               'supprimer un dossier contenant un lien est accepté')
        verif(os.path.exists(secret), 'la cible d’un lien a disparu lors d’une suppression')
        shutil.rmtree(avec_lien)

        verif(espace.existe(projet, 'note.md') is True, 'un document présent n’est pas trouvé')
        verif(espace.existe(projet, 'absent.txt') is False, 'un document absent est trouvé')
        verif(espace.existe(projet, '../secret.txt') is False,
              'existe() lève une exception ou répond vrai sur un chemin hostile')
        verif(espace.existe('../../invalide', 'x') is False,
              'existe() lève une exception sur un projet invalide')
        print('modifications : renommage, suppression et création contrôlés')

        # --- Index facultatif ----------------------------------------------------
        os.unlink(os.path.join(dossier, et.INDEX))
        listing = espace.lister(projet)
        verif(len(listing['fichiers']) > 0,
              'la perte de l’index empêche le listage : le dossier n’est plus la source de vérité')
        verif(all(f['origine'] == 'depot' for f in listing['fichiers']),
              'un document sans trace d’index reçoit une origine inventée')
        with open(os.path.join(dossier, et.INDEX), 'w', encoding='utf-8') as flux:
            flux.write('{ json cassé')
        listing = espace.lister(projet)
        verif(len(listing['fichiers']) > 0,
              'un index corrompu empêche le listage')
        espace.ecrire(projet, 'apres-corruption.txt', 'ok')
        verif(espace.existe(projet, 'apres-corruption.txt'),
              'un index corrompu bloque les dépôts suivants')
        print('index : perte et corruption sans effet sur le listage')

        # --- Espace par défaut ---------------------------------------------------
        # Ces fonctions sont réellement appelées. Une assertion « callable() »
        # avait laissé passer une racine_defaut() qui lisait un core.BASE
        # inexistant : elle aurait fait tomber toutes les routes de l’espace au
        # premier lancement, et rien dans ce banc ne l’aurait signalé.
        defaut = et.racine_defaut()
        verif('core' not in sys.modules,
              'racine_defaut() importe core : server.py importe ce module, la référence serait circulaire')
        verif(os.path.isabs(defaut), 'la racine par défaut n’est pas absolue : %r' % defaut)
        verif(defaut.endswith(os.path.join('data', 'espace')),
              'la racine par défaut n’est pas data/espace : %r' % defaut)
        verif(os.path.dirname(os.path.dirname(defaut)) == os.path.realpath(str(ASSISTANT)),
              'la racine par défaut n’est pas sous le dossier de l’assistant : %r' % defaut)
        verif(et.QUOTA_PAR_PROJET > 0 and et.TAILLE_FICHIER_MAX > 0,
              'les plafonds par défaut ne sont pas positifs')
        verif(et.PROFONDEUR_MAX > 1, 'la profondeur maximale empêche les sous-dossiers')

        # PS_ESPACE_RACINE doit vraiment détourner l’espace, singleton compris :
        # c’est ce qui permet à un utilisateur de placer ses documents sur un
        # autre volume, et à ce banc de ne rien écrire dans l’arbre livré.
        avec_env = os.path.join(hors, 'espace-env')
        ancien = os.environ.get('PS_ESPACE_RACINE')
        os.environ['PS_ESPACE_RACINE'] = avec_env
        try:
            verif(et.racine_defaut() == avec_env,
                  'PS_ESPACE_RACINE n’est pas honoré : %r' % et.racine_defaut())
            et.espace = None
            reel = et.espace_defaut()
            verif(reel.racine == os.path.realpath(avec_env),
                  'l’espace par défaut n’emploie pas PS_ESPACE_RACINE : %r' % reel.racine)
            fiche = reel.ecrire('projenv', 'note.txt', 'déposé via la racine réelle')
            verif(os.path.isfile(os.path.join(avec_env, 'projenv', 'note.txt')),
                  'un dépôt via l’espace par défaut n’atteint pas le disque : %r' % fiche)
            verif(reel.lire('projenv', 'note.txt').decode('utf-8')
                  == 'déposé via la racine réelle',
                  'le contenu déposé via l’espace par défaut est altéré')
            verif(et.espace_defaut() is reel,
                  'le singleton est reconstruit à chaque appel : l’index serait relu sans cesse')
        finally:
            if ancien is None:
                os.environ.pop('PS_ESPACE_RACINE', None)
            else:
                os.environ['PS_ESPACE_RACINE'] = ancien
            et.espace = None
        print('espace réel : racine déduite du module, PS_ESPACE_RACINE honoré')
    finally:
        shutil.rmtree(racine, ignore_errors=True)
        shutil.rmtree(hors, ignore_errors=True)

    if passe_avant is not None and os.path.exists(passe_reel):
        verif(os.stat(passe_reel).st_mtime == passe_avant,
              'le vrai /etc/passwd a été modifié pendant le banc')

    if echecs:
        print('\n%d assertion(s) sur %d en échec :' % (len(echecs), compte[0]))
        for probleme in echecs:
            print('  - ' + probleme)
        return 1
    print('\nBanc de l’espace de travail : %d assertions, toutes conformes.' % compte[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
