# -*- coding: utf-8 -*-
"""Tests de la façade publique de langages_esoteriques.py.

Les APERÇUS sont des promesses : ce sont les programmes que le bouton
« essayer » de l'aide exécute devant l'utilisateur. Chacun doit donc se
terminer sur « success », et non sur une limite de pas.

Lancer :  python3 tests/smoke_facade.py
"""
import sys, os, base64
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import langages_esoteriques as E   # noqa: E402

OK = 0; N = 0
def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    bon = obtenu == attendu
    OK += bon
    print('  %-56s %s' % (titre, 'CONFORME' if bon else 'DIFFERENT'))
    if not bon:
        print('      obtenu  : %r' % (str(obtenu)[:120],))
        print('      attendu : %r' % (str(attendu)[:120],))

print('=== catalogue ===')
verifier('dix moteurs déclarés', len(E.MOTEURS), 10)
verifier('dix langages dans l’ordre d’affichage', len(E.ORDRE_ESOTERIQUES), 10)
verifier('tout id de MOTEURS figure dans ORDRE_ESOTERIQUES',
         set(E.MOTEURS) == set(E.ORDRE_ESOTERIQUES), True)
verifier('est_esoterique accepte la casse et les espaces',
         (E.est_esoterique('Brainfuck'), E.est_esoterique('  PIET '),
          E.est_esoterique('python'), E.est_esoterique(None)),
         (True, True, False, False))
verifier('moteur() renvoie la classe', E.moteur('chef') is E.Chef, True)
verifier('moteur() renvoie None pour un inconnu', E.moteur('cobol'), None)
infos = E.liste_moteurs()
verifier('liste_moteurs() expose les métadonnées', len(infos), 10)
verifier('seul Piet est graphique',
         sorted(i['langage'] for i in infos if i['graphique']), ['piet'])
verifier('chaque moteur a une extension commençant par un point',
         all(i['extension'].startswith('.') for i in infos), True)
verifier('les libellés sont uniques', len({i['libelle'] for i in infos}), 10)

print()
print('=== les dix aperçus doivent se TERMINER sur « success » ===')
for identifiant in E.ORDRE_ESOTERIQUES:
    code = E.apercu_programme(identifiant)
    r = E.executer(code, identifiant, limite=200000)
    verifier('aperçu %-12s -> %s' % (identifiant, r['state']),
             (r['state'], r['sortie'][:20] if r['sortie'] else ''),
             ('success', {'brainfuck': 'Hello World!\n', 'whitespace': 'Hi',
                          'piet': 'A', 'lolcode': 'Hello, world!\n',
                          'arnoldc': 'Hello, world!', 'chef': 'Hello world!',
                          'shakespeare': 'A', 'intercal': 'LXXII\nXXXIII\n',
                          'fractran': '', 'malbolge': 'Hello World!'}[identifiant][:20]
              if r['sortie'] else ''))

print()
print('=== façade analyser / pas_a_pas ===')
verifier('analyser() sur un programme sain ne remonte rien',
         E.analyser(E.apercu_programme('arnoldc'), 'arnoldc'), [])
# L'analyse statique remonte les erreurs STRUCTURELLES. Une variable jamais
# déclarée est un diagnostic d'EXÉCUTION (ArnoldC n'a pas de phase de noms) :
# c'est assumé et documenté, le débogueur la remonte à l'exécution.
diags = E.analyser("IT'S SHOWTIME\nDANCER\nYOU HAVE BEEN TERMINATED", 'arnoldc')
verifier('analyser() remonte un mot-clé inconnu sans exécuter',
         any(d['severity'] == 'error' for d in diags), True)
diags = E.analyser('TALK TO THE HAND "a"', 'arnoldc')
verifier('analyser() remonte l’absence de IT\'S SHOWTIME',
         any('SHOWTIME' in d['message'] for d in diags), True)
diags = E.analyser("IT'S SHOWTIME\nTALK TO THE HAND \"a\"", 'arnoldc')
verifier('terminateur manquant -> avertissement, pas erreur',
         [d['severity'] for d in diags], ['warning'])
verifier('analyser() ne produit aucune sortie',
         E.analyser(E.apercu_programme('brainfuck'), 'brainfuck'), [])
verifier('analyser() sur un langage inconnu renvoie []',
         E.analyser('x', 'cobol'), [])
m = E.pas_a_pas(E.apercu_programme('brainfuck'), 'brainfuck')
verifier('pas_a_pas() charge sans exécuter', (m.pas_fait, m.sortie), (0, ''))
verifier('pas_a_pas() avance d’une instruction', m.pas(), True)
verifier('un pas a bien été compté', m.pas_fait, 1)
verifier('variables() et frames() sont disponibles',
         (isinstance(m.variables(), list), isinstance(m.frames(), list)),
         (True, True))
verifier('pas_a_pas() renvoie None pour un langage inconnu',
         E.pas_a_pas('x', 'cobol'), None)

print()
print('=== Piet : sortie d’image et data URI ===')
# Un programme qui sort de l'image doit se terminer PROPREMENT. Traiter la
# sortie d'image comme un simple obstacle fait rebondir le DP vers la gauche et
# réexécuter des commandes parasites (subtract sur une pile vide, ici).
v = E.APERCUS_ESOTERIQUES['piet']
r = E.executer(v, 'piet', limite=100)
verifier('sortir de l’image termine sans commande parasite',
         (r['state'], r['sortie']), ('success', 'A'))
octets = base64.b64decode(v.split(',', 1)[1], validate=True)
verifier('le data URI d’aperçu est un PNG valide',
         octets[:8], b'\x89PNG\r\n\x1a\n')
l, h, px = E.decoder_png(octets)
verifier('géométrie de l’aperçu', (l, h, px[0][0], px[0][65], px[0][66]),
         (67, 1, (255, 0, 0), (192, 0, 0), (255, 0, 255)))

print()
print('=== contrat de débogage : les DIX moteurs, pas seulement Brainfuck ===')
# Ce contrôle était limité à Brainfuck, ce qui a laissé passer un défaut réel :
# Lolcode et ArnoldC rangeaient leurs variables de programme dans self.variables,
# un DICTIONNAIRE qui masquait la méthode variables() du contrat de débogage. La
# méthode était du code mort et tout appel levait « 'dict' object is not
# callable », alors que debogueur_universel.capacites() annonçait variables=True
# pour ces deux langages. Le pas à pas de l'IDE aurait répondu 500.
CLES_COMPTE = ('ok', 'state', 'diagnostics', 'message', 'output', 'sortie',
               'erreur', 'pas', 'termine', 'langage')
for ident in E.ORDRE_ESOTERIQUES:
    m = E.pas_a_pas(E.APERCUS_ESOTERIQUES[ident], ident)
    depart = (m is not None,
              callable(getattr(m, 'variables', None)),
              isinstance(m.variables(), list),
              isinstance(m.frames(), list),
              isinstance(m.position, tuple) and len(m.position) == 2,
              isinstance(m.pas(), bool))
    while not m.termine and m.pas_fait < 200000:
        m.pas()
    compte = m.compte_rendu()
    # variables() doit rester utilisable APRÈS la fin : c'est ce que l'inspecteur
    # affiche à l'arrêt, et pour FRACTRAN le résultat est justement l'état final.
    fin = (m.termine,
           all(cle in compte for cle in CLES_COMPTE),
           isinstance(m.variables(), list))
    verifier('contrat de débogage de %s' % ident, depart + fin, (True,) * 9)

print()
print('%d/%d vérifications conformes' % (OK, N))
sys.exit(0 if OK == N else 1)
