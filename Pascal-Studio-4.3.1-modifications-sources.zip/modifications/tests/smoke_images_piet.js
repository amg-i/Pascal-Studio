/* Banc de la visionneuse d'images et de l'éditeur Piet (4.3.0).
 *
 * CE QUE CE BANC VÉRIFIE, ET POURQUOI CHAQUE CONTRÔLE EXISTE
 *
 *  VISIONNEUSE
 *   - Elle rend dans `.ps-image-host[data-path]`, l'hôte que le bundle crée pour
 *     un VRAI onglet. Sans `data-path`, elle ne saurait pas quoi afficher.
 *   - Le refus du serveur est AFFICHÉ avec sa raison : une visionneuse muette
 *     sur une image trop grande fait croire qu'elle est cassée.
 *   - Le zoom « ajuster » et le zoom « taille réelle » sont deux modes distincts,
 *     et l'état est conservé PAR CHEMIN : ouvrir une seconde image ne doit pas
 *     réinitialiser la première.
 *   - Le fond damier/sombre/clair existe : une image transparente sur un fond de
 *     la même couleur est invisible, et l'utilisateur croit le fichier vide.
 *   - Le voisinage permet « précédente » et « suivante » sans repasser par
 *     l'arborescence.
 *   - Un PNG reconnu comme programme Piet propose la conversion en `.piett`.
 *   - Le SVG n'est PAS accaparé : c'est du texte, il reste dans Monaco.
 *   - Sans hôte, `PSImages.ouvrir()` passe par les vues déléguées : la
 *     fonctionnalité ne disparaît pas sur une base non patchée.
 *
 *  ÉDITEUR PIET
 *   - Il rend dans `.ps-piet-host[data-path]`.
 *   - La palette vient DU SERVEUR, jamais recopiée dans le script : les couleurs
 *     de Piet sont imposées par la spécification, et une palette recopiée à la
 *     main finirait par diverger de `piet_texte.py`.
 *   - Peindre une case met l'état à jour, pousse l'historique, et le rappel
 *     pédagogique nomme la commande produite par le changement de couleur.
 *   - Le texte et la grille sont synchronisés dans les DEUX sens.
 *   - Un texte refusé par le décodeur n'est PAS jeté : il est conservé et le
 *     diagnostic est affiché. Jeter ce que l'utilisateur vient d'écrire est la
 *     pire des réponses.
 *   - L'exécution passe par le serveur, donc par le moteur Piet existant.
 *
 * Lancer :  node tests/smoke_images_piet.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const MOD = path.join(ICI, '..');

let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 240)
    + '\n      attendu : ' + serie(attendu).slice(0, 240));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* ---------------------------------------------------------------- fixtures -- */

const PALETTE = [
  { code: 'rc', nom: 'rouge claire', teinte: 0, luminosite: 0, hexa: '#ffc0c0', rvb: [255, 192, 192] },
  { code: 'rn', nom: 'rouge normale', teinte: 0, luminosite: 1, hexa: '#ff0000', rvb: [255, 0, 0] },
  { code: 'ms', nom: 'magenta sombre', teinte: 5, luminosite: 2, hexa: '#c000c0', rvb: [192, 0, 192] },
  { code: 'bl', nom: 'blanc', teinte: null, luminosite: null, hexa: '#ffffff', rvb: [255, 255, 255] },
  { code: 'no', nom: 'noir', teinte: null, luminosite: null, hexa: '#000000', rvb: [0, 0, 0] },
];
/* Les transitions utiles au banc, dont (5,2) = out(char), celle que produit le
 * passage « rouge claire » -> « magenta sombre ». */
const COMMANDES = [
  { delta_teinte: 0, delta_luminosite: 1, commande: 'push', libelle: 'push (empile la taille du bloc)' },
  { delta_teinte: 5, delta_luminosite: 1, commande: 'out_nombre', libelle: 'out(number)' },
  { delta_teinte: 5, delta_luminosite: 2, commande: 'out_caractere', libelle: 'out(char)' },
  { delta_teinte: 0, delta_luminosite: 0, commande: 'rien', libelle: 'aucune (même couleur)' },
];
const TEXTE_EXEMPLE = 'piet 1\ncodel 4\ngrille 3 1\nrc rn ms\n';
const IMAGE_URI = 'data:image/png;base64,iVBORw0KGgo=';

function banc(script, opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const document = harnais.document;
  const source = fs.readFileSync(path.join(MOD, script), 'utf8');

  const principal = document.createElement('main');
  principal.className = 'studio-main';
  const wrap = document.createElement('div');
  wrap.className = 'editor-wrap';
  let hote = null;
  if (opts.hote) {
    hote = document.createElement('div');
    hote.className = opts.hote.replace('.', '');
    if (opts.chemin) hote.setAttribute('data-path', opts.chemin);
    wrap.appendChild(hote);
  }
  principal.appendChild(wrap);
  document.body.appendChild(principal);

  const zone = document.createElement('div');
  zone.className = 'ps-vues-zone';
  principal.appendChild(zone);
  harnais.rafraichir();

  const appels = [];
  const journal = [];
  const erreurs = [];
  const minuteurs = [];

  function repondre(url, corps) {
    const action = String(url).split('?')[0];
    if (action === '/api/image') {
      switch (corps.action) {
        case 'lire':
          if (/absent/.test(corps.chemin || '')) {
            return { ok: false, erreur: 'Fichier introuvable : ' + corps.chemin };
          }
          if (/gros/.test(corps.chemin || '')) {
            return { ok: false, erreur: 'Image de 40,0 Mo : la borne de la '
              + 'visionneuse est de 32 Mo.', taille: 41943040, nom: 'gros.png' };
          }
          return { ok: true, chemin: corps.chemin, nom: 'programme.png',
            mime: 'image/png', format: 'PNG', taille: 4096, uri: IMAGE_URI,
            largeur: 12, hauteur: 4, dimensions_connues: true,
            modifie: '2026-11-11 20:00:00',
            piet: opts.piet === false ? { est_piet: false,
              raison: '16 pixel(s) hors de la palette Piet : c’est une image, '
                + 'pas un programme.' } : { est_piet: true, couleurs: 3,
              hors_palette: 0, codel: 4, largeur: 12, hauteur: 4 },
            voisins: { ok: true, images: ['a.png', 'programme.png', 'z.gif'],
              position: 1, total: 3 } };
        case 'voisins': return { ok: true, images: ['a.png', 'programme.png'],
          position: 1, total: 2 };
        case 'convertir-piet': return { ok: true,
          destination: '/projet/programme.piett', chemin: 'programme.piett',
          texte: TEXTE_EXEMPLE, codel: 4 };
        case 'capacites': return { ok: true, formats: ['.png', '.jpg'],
          redimensionnement_serveur: false };
        default: return { ok: false, erreur: 'Action d’image inconnue.' };
      }
    }
    if (action === '/api/piet') {
      switch (corps.action) {
        case 'catalogue': return { ok: true, palette: PALETTE,
          commandes: COMMANDES, extension: '.piett', version: 1 };
        case 'exemple': return { ok: true, texte: TEXTE_EXEMPLE };
        case 'lire': return { ok: true, chemin: corps.chemin,
          texte: TEXTE_EXEMPLE };
        case 'decoder': {
          const texte = String(corps.texte || '');
          if (/zz/.test(texte)) {
            return { ok: false, cellules: [], largeur: 0, hauteur: 0, codel: 1,
              diagnostics: [{ severity: 'error', message: 'Couleur « zz » '
                + 'inconnue.', ligne: 1, colonne: 1 }] };
          }
          const lignes = texte.split('\n').filter(function (l) {
            return l.trim() && l.trim()[0] !== '#' && !/^(piet|codel|grille)/.test(l.trim());
          });
          return { ok: true, version: 1, codel: 4, largeur: 3,
            hauteur: lignes.length || 1,
            cellules: lignes.length ? [lignes[0].trim().split(/\s+/)]
              : [['rc', 'rn', 'ms']], diagnostics: [] };
        }
        case 'encoder': return { ok: true, texte: TEXTE_EXEMPLE };
        case 'analyser': return { ok: true, nombre_blocs: 3, blocs: [],
          largeur: 3, hauteur: 1, codel: 4, commandes: COMMANDES };
        case 'png': return { ok: true, uri: IMAGE_URI };
        case 'executer': return { ok: true, sortie: '1', output: '1', pas: 12,
          termine: true, langage: 'piet', message: '', diagnostics: [],
          piet_texte: { codel: 4 } };
        case 'ecrire': return { ok: true, chemin: corps.chemin, octets: 96 };
        case 'exporter-png': return { ok: true,
          destination: '/projet/programme.png', octets: 128 };
        default: return { ok: false, erreur: 'Action Piet inconnue.' };
      }
    }
    return { ok: true };
  }

  const fetchStub = function (url, init) {
    let corps = {};
    try { corps = JSON.parse((init && init.body) || '{}'); } catch (e) { corps = {}; }
    journal.push({ url: String(url).split('?')[0], action: corps.action });
    const reponse = repondre(url, corps);
    /* server.py : un module qui ne lève jamais (images.lire, piet_texte.decoder,
     * l'exécution) répond HTTP 200 avec `ok:false` et sa raison ; seul un
     * `raise ValueError` sort en HTTP 400 avec la clé `error`. Un banc qui
     * renverrait 400 partout mesurerait un autre serveur que le vrai. */
    const statut = reponse.error === undefined ? 200 : 400;
    return Promise.resolve({ ok: statut === 200, status: statut,
      json: function () { return Promise.resolve(reponse); } });
  };

  const Vues = opts.sansPSVues ? null : {
    zone: zone, appels: appels,
    ouvrir: function (o) {
      appels.push({ methode: 'ouvrir', id: o.id, titre: o.titre, noeud: !!o.noeud });
      if (o.noeud && o.noeud.parentNode !== zone) zone.appendChild(o.noeud);
      return true;
    },
    fermer: function (id) { appels.push({ methode: 'fermer', id: id }); return true; },
    activer: function (id) { appels.push({ methode: 'activer', id: id }); return true; },
    mode: function () { return { mode: 'plein', largeur: 55 }; },
    disposition: function () { return { mode: 'plein', colonnes: [] }; },
    garanties: function () { return {}; },
    synchroniser: function () {},
    vues: function () { return []; },
  };

  const hotesEnregistres = [];
  const sandbox = {
    document: document,
    console: { error: function () { erreurs.push([].map(String).call(arguments).join(' ')); },
      log: function () {}, warn: function () {} },
    setTimeout: function (fn) { minuteurs.push(fn); return minuteurs.length; },
    clearTimeout: function () {},
    setInterval: function () { return 0; }, clearInterval: function () {},
    fetch: fetchStub,
    localStorage: { getItem: function () { return null; },
      setItem: function () {}, removeItem: function () {} },
    navigator: { clipboard: null, userAgent: 'banc' },
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise, RegExp: RegExp,
    parseInt: parseInt, parseFloat: parseFloat, isFinite: isFinite, isNaN: isNaN,
    encodeURIComponent: encodeURIComponent, Map: Map, Set: Set,
    TypeError: TypeError, Error: Error,
    MutationObserver: H.MutationObserverStub,
    requestAnimationFrame: function (fn) { fn(); return 1; },
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.window.addEventListener = function () {};
  if (Vues) sandbox.PSVues = Vues;
  const onglets = [];
  sandbox.PSFMOpenTabs = function (liste) { onglets.push(liste); return true; };
  if (opts.sansPSFM) delete sandbox.PSFMOpenTabs;
  sandbox.PSHotes = {
    suivre: function (selecteur, rappel) {
      hotesEnregistres.push({ selecteur: selecteur, rappel: rappel });
      return function () {};
    },
    forcer: function () { hotesEnregistres.forEach(function (h) { h.rappel(); }); },
    statistiques: function () { return { observateurs: 1 }; },
  };

  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: script });

  return { sandbox: sandbox, document: document, harnais: harnais, Vues: Vues,
    journal: journal, erreurs: erreurs, hotes: hotesEnregistres, onglets: onglets,
    source: source, hote: hote, principal: principal, zone: zone,
    rappeler: function () {
      hotesEnregistres.slice().forEach(function (h) { h.rappel(); });
      minuteurs.splice(0, minuteurs.length).forEach(function (fn) {
        try { fn(); } catch (e) { /* joué */ }
      });
    },
    ticks: function (n) {
      const attendre = function () {
        return new Promise(function (resoudre) {
          if (typeof setImmediate === 'function') setImmediate(resoudre);
          else setTimeout(resoudre, 0);
        });
      };
      let chaine = attendre();
      for (let i = 1; i < (n || 3); i += 1) chaine = chaine.then(attendre);
      return chaine;
    } };
}

async function joue() {
  /* ================================================================== */
  /* VISIONNEUSE                                                         */
  /* ================================================================== */
  const sourceImages = fs.readFileSync(path.join(MOD, 'images-studio.js'), 'utf8');
  const feuilleImages = fs.readFileSync(path.join(MOD, 'images-studio.css'), 'utf8');

  vrai('visionneuse : aucune ressource externe dans la feuille',
    !/url\(\s*['"]?https?:/.test(feuilleImages) && !/@import/.test(feuilleImages));
  vrai('visionneuse : le damier est fait en dégradés, pas en image',
    /linear-gradient/.test(feuilleImages));
  vrai('visionneuse : trois fonds sont prévus',
    ['psim-fond-damier', 'psim-fond-sombre', 'psim-fond-clair'].every(function (c) {
      return feuilleImages.indexOf(c) >= 0;
    }));
  vrai('visionneuse : le mode taille réelle ne ré-échantillonne pas',
    /image-rendering:pixelated/.test(feuilleImages));
  vrai('visionneuse : le script ne redimensionne rien côté client non plus',
    !/drawImage|toDataURL|createImageBitmap/.test(sourceImages));
  vrai('visionneuse : le SVG n’est pas accaparé',
    !/\.svg/i.test(sourceImages));

  let b = banc('images-studio.js', { hote: '.ps-image-host',
    chemin: '/projet/programme.png' });
  b.rappeler();
  await b.ticks(6);
  vrai('visionneuse : l’hôte est trouvé et rempli',
    !!b.hote.querySelector('.psim'));
  vrai('visionneuse : la lecture est demandée au serveur',
    b.journal.some(function (j) { return j.action === 'lire'; }));
  vrai('visionneuse : l’image est affichée', !!b.hote.querySelector('.psim-img'));
  verifier('visionneuse : l’image porte la data URI du serveur',
    b.hote.querySelector('.psim-img').getAttribute('src'), IMAGE_URI);
  vrai('visionneuse : les dimensions sont affichées',
    /12 × 4/.test(b.hote.textContent));
  vrai('visionneuse : le format est affiché', /PNG/.test(b.hote.textContent));
  vrai('visionneuse : la taille est affichée en unités lisibles',
    /4\.0 Ko|4 Ko/.test(b.hote.textContent));
  vrai('visionneuse : la date de modification est affichée',
    /2026-11-11/.test(b.hote.textContent));
  vrai('visionneuse : le PNG Piet est signalé',
    /programme Piet/.test(b.hote.textContent));
  vrai('visionneuse : la conversion en .piett est proposée',
    !!b.hote.querySelector('.psim-piet .psim-btn'));
  vrai('visionneuse : le voisinage donne précédente et suivante',
    b.hote.querySelectorAll('.psim-nav .psim-btn').length === 2);
  vrai('visionneuse : la position dans le dossier est affichée',
    /2\/3/.test(b.hote.textContent));

  /* L'état par chemin. */
  verifier('visionneuse : le zoom par défaut ajuste à la fenêtre',
    b.sandbox.PSImages.etat().zoom, 'ajuster');
  b.sandbox.PSImages.zoom(2);
  await b.ticks(3);
  verifier('visionneuse : le zoom demandé est conservé',
    b.sandbox.PSImages.etat().zoom, 2);
  /* Le harnais garde `style` comme objet simple (getAttribute('style') n'y est
   * pas branché) : le contrôle lit donc l'objet, qui est ce que le script pose. */
  const imgReelle = b.hote.querySelector('.psim-img');
  vrai('visionneuse : en taille réelle, l’image porte des dimensions en pixels',
    /px$/.test(String(imgReelle.style.width)) && /px$/.test(String(imgReelle.style.height)));
  verifier('visionneuse : le zoom 2 double la largeur',
    imgReelle.style.width, '24px');
  vrai('visionneuse : en taille réelle, l’image n’est plus « ajustée »',
    !(imgReelle.className || '').split(' ').some(function (c) { return c === 'psim-ajustee'; }));
  b.sandbox.PSImages.zoom('ajuster');
  await b.ticks(3);
  vrai('visionneuse : « ajuster » enlève les dimensions en pixels',
    !b.hote.querySelector('.psim-img').style.width);
  b.sandbox.PSImages.fond('sombre');
  await b.ticks(3);
  verifier('visionneuse : le fond demandé est appliqué',
    b.sandbox.PSImages.etat().fond, 'sombre');
  vrai('visionneuse : la classe de fond suit le réglage',
    !!b.hote.querySelector('.psim-corps.psim-fond-sombre'));
  b.sandbox.PSImages.fond('inconnu');
  verifier('visionneuse : un fond inconnu est ignoré',
    b.sandbox.PSImages.etat().fond, 'sombre');

  /* La conversion ouvre le fichier produit. */
  const boutonConvertir = b.hote.querySelector('.psim-piet .psim-btn');
  boutonConvertir.dispatchEvent({ type: 'click', target: boutonConvertir });
  await b.ticks(6);
  vrai('visionneuse : la conversion demande le serveur',
    b.journal.some(function (j) { return j.action === 'convertir-piet'; }));
  vrai('visionneuse : le fichier converti est ouvert dans un onglet',
    b.onglets.some(function (l) {
      return l.indexOf('/projet/programme.piett') >= 0;
    }));
  vrai('visionneuse : la conversion est annoncée',
    /Source Piet écrite/.test(b.hote.textContent));

  /* Un refus du serveur est affiché avec sa raison. */
  b = banc('images-studio.js', { hote: '.ps-image-host', chemin: '/projet/gros.png' });
  b.rappeler();
  await b.ticks(6);
  vrai('visionneuse : une image trop grande est refusée AVEC la borne',
    /borne/.test(b.hote.textContent));
  vrai('visionneuse : le refus n’affiche pas d’image',
    !b.hote.querySelector('.psim-img'));
  vrai('visionneuse : le refus dit pourquoi', /32 Mo/.test(b.hote.textContent));
  verifier('visionneuse : un refus est un refus', b.sandbox.PSImages.etat().image.ok, false);

  b = banc('images-studio.js', { hote: '.ps-image-host', chemin: '/projet/logo.jpg',
    piet: false });
  b.rappeler();
  await b.ticks(6);
  vrai('visionneuse : un JPEG n’est pas annoncé comme programme Piet',
    !/est un programme Piet/.test(b.hote.textContent));

  /* Sans hôte : le repli passe par les vues. */
  b = banc('images-studio.js', { hote: null, sansPSFM: true });
  b.sandbox.PSImages.ouvrir('/projet/autre.png');
  await b.ticks(6);
  vrai('visionneuse : sans hôte, PSImages.ouvrir passe par les vues',
    b.Vues.appels.some(function (a) { return a.methode === 'ouvrir'; }));
  vrai('visionneuse : la vue est rendue dans la zone',
    !!b.zone.querySelector('.psim'));
  b = banc('images-studio.js', { hote: null, sansPSFM: true, sansPSVues: true });
  verifier('visionneuse : sans hôte, sans vues et sans onglets, ouvrir rend faux',
    b.sandbox.PSImages.ouvrir('/projet/x.png'), false);

  /* Les garanties annoncées. */
  b = banc('images-studio.js', { hote: '.ps-image-host', chemin: '/projet/a.png' });
  const garanties = b.sandbox.PSImages.garanties();
  verifier('visionneuse : les garanties disent que le SVG reste à Monaco',
    garanties.svg_laisse_a_monaco, true);
  verifier('visionneuse : les garanties disent qu’aucun redimensionnement serveur',
    garanties.redimensionnement_serveur, false);
  verifier('visionneuse : les trois fonds sont annoncés', garanties.fond_transparence,
    ['damier', 'sombre', 'clair']);

  /* ================================================================== */
  /* ÉDITEUR PIET                                                        */
  /* ================================================================== */
  const sourcePiet = fs.readFileSync(path.join(MOD, 'piet-studio.js'), 'utf8');
  const feuillePiet = fs.readFileSync(path.join(MOD, 'piet-studio.css'), 'utf8');

  vrai('piet : la palette n’est PAS recopiée dans le script',
    !/#ffc0c0|#c000c0/i.test(sourcePiet));
  vrai('piet : la palette est demandée au serveur',
    /action: 'catalogue'|'catalogue'/.test(sourcePiet));
  vrai('piet : les couleurs sont posées en style, donc jamais surchargées',
    /style: 'background:'/.test(sourcePiet) || /style:'background:'/.test(sourcePiet));
  vrai('piet : la feuille ne redéfinit pas la couleur des cases',
    !/\.pspi-case\{[^}]*background/.test(feuillePiet));
  vrai('piet : aucune ressource externe',
    !/url\(\s*['"]?https?:/.test(feuillePiet) && !/@import/.test(feuillePiet));
  /* Une bordure PAR CASE dessinerait des traits doubles et épaissirait la
   * grille ; `border-radius` n'a rien à voir avec ça, d'où le motif précis. */
  vrai('piet : la grille utilise un gap et non une bordure par case',
    /\.pspi-grille\{[^}]*gap:1px/.test(feuillePiet)
      && !/\.pspi-case\{[^}]*border(-\w+)?:[^;}]*solid/.test(feuillePiet));

  b = banc('piet-studio.js', { hote: '.ps-piet-host', chemin: '/projet/programme.piett' });
  b.rappeler();
  await b.ticks(8);
  vrai('piet : le catalogue est demandé', b.journal.some(function (j) {
    return j.action === 'catalogue';
  }));
  vrai('piet : le fichier est lu', b.journal.some(function (j) {
    return j.action === 'lire';
  }));
  vrai('piet : l’éditeur est rendu', !!b.hote.querySelector('.pspi'));
  verifier('piet : la grille a les trois cases de l’exemple',
    b.hote.querySelectorAll('.pspi-case').length, 3);
  verifier('piet : la palette a les cinq couleurs de la fixture',
    b.hote.querySelectorAll('.pspi-couleur').length, PALETTE.length);
  vrai('piet : la table des commandes est affichée',
    b.hote.querySelectorAll('.pspi-commande').length === COMMANDES.length);
  vrai('piet : la source texte est affichée', !!b.hote.querySelector('.pspi-texte'));
  vrai('piet : la source affichée contient la grille',
    /rc rn ms/.test(b.hote.querySelector('.pspi-texte').value));
  vrai('piet : le rappel pédagogique explique la règle du langage',
    /CHANGEMENT de couleur/.test(b.hote.textContent));

  /* La peinture. */
  verifier('piet : l’état initial n’est pas modifié', b.sandbox.PSPiet.etat().modifie, false);
  const tableau = b.hote.querySelector('.pspi-grille');
  const premiere = b.hote.querySelector('.pspi-case');
  /* La peinture est DÉLÉGUÉE sur la grille : c'est donc la grille qui reçoit
   * l'événement, la case n'étant que la cible. Le harnais ne propage pas, et
   * c'est justement ce que le banc doit reproduire fidèlement. */
  tableau.dispatchEvent({ type: 'pointerdown', target: premiere });
  await b.ticks(4);
  verifier('piet : peindre avec la couleur déjà en place ne change rien',
    b.sandbox.PSPiet.etat().historique, 0);
  b.sandbox.PSPiet.pinceau('no');
  await b.ticks(2);
  tableau.dispatchEvent({ type: 'pointerdown', target: premiere });
  await b.ticks(4);
  vrai('piet : peindre passe le fichier en « modifié »',
    b.sandbox.PSPiet.etat().modifie === true);
  verifier('piet : la case peinte prend la couleur du pinceau',
    b.sandbox.PSPiet.grille()[0][0], 'no');
  verifier('piet : l’historique a une entrée', b.sandbox.PSPiet.etat().historique, 1);
  b.sandbox.PSPiet.annuler();
  await b.ticks(3);
  verifier('piet : annuler restaure la case', b.sandbox.PSPiet.grille()[0][0], 'rc');
  verifier('piet : annuler vide l’historique', b.sandbox.PSPiet.etat().historique, 0);
  b.sandbox.PSPiet.retablir();
  await b.ticks(3);
  verifier('piet : rétablir remet la modification', b.sandbox.PSPiet.grille()[0][0], 'no');
  /* Le glissé peint plusieurs cases d'un seul geste. */
  const deuxieme = b.hote.querySelectorAll('.pspi-case')[1];
  tableau.dispatchEvent({ type: 'pointerover', target: deuxieme });
  await b.ticks(3);
  verifier('piet : glisser peint la case survolée', b.sandbox.PSPiet.grille()[0][1], 'no');

  /* Le rappel pédagogique : il parle du CHANGEMENT de couleur, pas de la
   * couleur elle-même, et il dit la vérité sur le noir et le blanc. */
  b.sandbox.PSPiet.pinceau('ms');
  await b.ticks(2);
  vrai('piet : depuis le noir, le rappel dit qu’aucune commande n’est produite',
    /aucune commande/.test(b.hote.querySelector('.pspi-rappel').textContent));
  b.sandbox.PSPiet.pinceau('rc');
  await b.ticks(2);
  b.sandbox.PSPiet.pinceau('ms');
  await b.ticks(2);
  vrai('piet : le rappel nomme la commande produite par le changement',
    /out\(char\)/.test(b.hote.querySelector('.pspi-rappel').textContent));
  vrai('piet : le rappel nomme les deux couleurs en jeu',
    /rouge claire/.test(b.hote.querySelector('.pspi-rappel').textContent)
      && /magenta sombre/.test(b.hote.querySelector('.pspi-rappel').textContent));

  /* Le texte -> la grille, et la grille -> le texte. */
  await b.sandbox.PSPiet.appliquerTexte('piet 1\ncodel 8\ngrille 2 1\nbl no\n');
  await b.ticks(4);
  verifier('piet : le texte appliqué remplace la grille',
    b.sandbox.PSPiet.grille()[0], ['bl', 'no']);
  vrai('piet : le texte appliqué est réécrit dans la zone',
    /bl no/.test(b.hote.querySelector('.pspi-texte').value));

  /* Un texte refusé n'est PAS jeté. */
  await b.sandbox.PSPiet.appliquerTexte('piet 1\ncodel 4\nzz yy\n');
  if (process.env.BANC_BAVARD) {
    console.log('DEBUG refus : journal=%j', b.journal.slice(-4));
    console.log('DEBUG refus : texte=%j', b.sandbox.PSPiet.texte().slice(0,80));
    console.log('DEBUG refus : statut=%j', b.hote.querySelector('.pspi-statut')
      ? b.hote.querySelector('.pspi-statut').textContent : null);
    console.log('DEBUG refus : erreurs=%j', b.erreurs.slice(0,3));
  }
  await b.ticks(4);
  vrai('piet : un texte refusé affiche son diagnostic',
    /inconnue/.test(b.hote.textContent));
  vrai('piet : un texte refusé n’est pas perdu',
    /zz yy/.test(b.sandbox.PSPiet.texte()));

  /* L'exécution et l'enregistrement. */
  await b.sandbox.PSPiet.appliquerTexte(TEXTE_EXEMPLE);
  await b.ticks(4);
  b.sandbox.PSPiet.executer();
  await b.ticks(6);
  vrai('piet : l’exécution passe par le serveur', b.journal.some(function (j) {
    return j.action === 'executer';
  }));
  vrai('piet : la sortie est affichée', /1/.test(b.hote.querySelector('.pspi-sortie').textContent));
  b.sandbox.PSPiet.enregistrer();
  await b.ticks(6);
  vrai('piet : l’enregistrement passe par le serveur', b.journal.some(function (j) {
    return j.action === 'ecrire';
  }));
  verifier('piet : un enregistrement réussi lève l’état « modifié »',
    b.sandbox.PSPiet.etat().modifie, false);

  /* Le redimensionnement et le codel. */
  b.sandbox.PSPiet.peindre(0, 0, 'no');
  await b.ticks(3);
  vrai('piet : peindre une case précise fonctionne',
    b.sandbox.PSPiet.grille()[0][0] === 'no');
  verifier('piet : peindre une case hors grille rend faux',
    b.sandbox.PSPiet.peindre(99, 99, 'no'), false);

  /* Sans hôte : le repli passe par les vues. */
  b = banc('piet-studio.js', { hote: null, sansPSFM: true });
  b.sandbox.PSPiet.ouvrir('/projet/autre.piett');
  await b.ticks(8);
  vrai('piet : sans hôte, ouvrir passe par les vues',
    b.Vues.appels.some(function (a) { return a.methode === 'ouvrir'; }));
  vrai('piet : la vue est rendue dans la zone', !!b.zone.querySelector('.pspi'));

  /* Les garanties annoncées. */
  b = banc('piet-studio.js', { hote: '.ps-piet-host', chemin: '/projet/a.piett' });
  const garantiesPiet = b.sandbox.PSPiet.garanties();
  verifier('piet : les garanties nomment le moteur utilisé',
    garantiesPiet.moteur, 'langages_esoteriques.Piet (inchangé)');
  verifier('piet : les garanties nomment le format', garantiesPiet.format, '.piett');
  verifier('piet : les garanties disent que l’exécution est réelle',
    garantiesPiet.execution_reelle, true);
}

joue().then(function () {
  console.log('smoke_images_piet : ' + OK + '/' + N + ' contrôles');
  if (echecs.length) {
    console.log('ÉCHECS (' + echecs.length + ') :');
    echecs.forEach(function (e) { console.log('  - ' + e); });
    process.exit(1);
  }
  console.log('Aucun échec.');
}).catch(function (e) {
  console.log('smoke_images_piet : ' + OK + '/' + N + ' contrôles');
  console.log('EXCEPTION du banc : ' + (e && e.stack ? e.stack : String(e)));
  process.exit(1);
});
