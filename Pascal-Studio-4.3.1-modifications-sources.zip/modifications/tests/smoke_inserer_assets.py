#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de l'inséreur d'assets face aux formes RÉELLES d'un index.html de base.

POURQUOI CE BANC EXISTE
    Une base 3.9.0 d'origine référence déjà data-studio.js : le panneau des
    bases de données existait avant la 4.0.0, qui l'a étendu, et aucun
    reconditionneur 3.x ne l'injecte. Aucun banc ne le voyait, parce que la
    fixture de base est reconstruite en retirant les injections de l'index de
    référence : elle retirait data-studio.js aussi, et portait donc la même
    croyance fausse que le code testé. Un banc dont la référence est fabriquée
    par la même hypothèse que le code ne peut pas la contredire.

    Or la forme exacte de la balise dans une base réelle n'est pas connue : elle
    peut porter « defer » ou non, ses attributs dans un autre ordre. Ce banc joue
    les formes, et l'invariant qu'il vérifie est le seul qui compte vraiment :
    CHAQUE FICHIER EST RÉFÉRENCÉ EXACTEMENT UNE FOIS. Un panneau chargé deux
    fois s'observe lui-même le DOM et le second exemplaire écrase l'état du
    premier — sans erreur nulle part.

LES CAS JOUÉS
    1. index vierge            : les six injections sont posées, dans l'ordre ;
    2. data-studio canonique   : rien n'est réinjecté ;
    3. data-studio sans defer  : rien n'est ajouté, et c'est ANNONCÉ ;
    4. data-studio.js seul     : la feuille manquante est ajoutée, et elle seule ;
    5. data-studio.js en double: le vérificateur REFUSE — un doublon ne passe
                                 pas, même s'il vient de la base ;
    6. index vierge            : le vérificateur ne dit pas « conforme ».

Lancer :  python3 tests/smoke_inserer_assets.py
"""

import io
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
INSEREUR = MODIFICATIONS / 'inserer-assets-4.2.0.py'
REFERENCE = MODIFICATIONS.parent / 'interface-compilee'

OK = 0
ECHECS = []

ENTETE = ('<!doctype html><html lang="fr"><head><meta charset="UTF-8">'
          '<link rel="stylesheet" crossorigin href="/assets/index-BCuLwkpg.css">'
          '<script src="/assets/aide-latex.js"></script>')
QUEUE = ('<script type="module" crossorigin '
         'src="/assets/index-BA4XgQVD.js"></script></head><body>'
         '<div id="root"></div></body></html>')

PAIRES = ('data-studio', 'navigateur-studio', 'devweb-studio', 're-studio',
          'outils-studio')


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def index_vierge(aide=True):
    """Un index.html de base 3.9.0 : les aides 3.x, aucune paire de panneau."""
    aides = ('<script src="/assets/aide-esoteriques.js"></script>'
             '<link rel="stylesheet" href="/assets/aide-index.css">'
             '<script defer src="/assets/aide-index.js"></script>')
    return ENTETE + (aides if aide else '') + QUEUE


def jouer(insereur, index, *args):
    essai = subprocess.run([sys.executable, str(insereur), str(index)]
                           + list(args), capture_output=True, text=True)
    return essai.returncode, (essai.stdout + essai.stderr)


def contexte(dossier, contenu):
    """Un index.html et le dossier d'assets qui va avec, dans un dossier temporaire."""
    statiques = Path(dossier)
    (statiques / 'assets').mkdir(parents=True, exist_ok=True)
    index = statiques / 'index.html'
    io.open(index, 'w', encoding='utf8').write(contenu)
    # Les assets doivent exister : l'inséreur vérifie qu'une balise ne pointe
    # pas vers un fichier absent.
    for nom in PAIRES:
        for ext in ('.css', '.js'):
            (statiques / 'assets' / (nom + ext)).write_text('/* x */', 'utf8')
    for nom in ('aide-assembleur.js', 'asm-studio.js', 'ps-hotes.js'):
        (statiques / 'assets' / nom).write_text('// x', 'utf8')
    return index


def comptes(texte):
    return {nom: (texte.count('/assets/%s.css' % nom),
                  texte.count('/assets/%s.js' % nom)) for nom in PAIRES}


def principal():
    if not INSEREUR.is_file():
        ECHECS.append('inséreur absent : %s' % INSEREUR)
        return

    with tempfile.TemporaryDirectory() as temporaire:
        # ---- 1. index vierge : les six injections -----------------------
        dossier = Path(temporaire) / 'vierge'
        index = contexte(dossier, index_vierge())
        code, sortie = jouer(INSEREUR, index)
        verif(code == 0, '1. l’injection sur un index vierge doit réussir '
                         '(%d) : %s' % (code, sortie[-300:]))
        texte = io.open(index, encoding='utf8').read()
        c = comptes(texte)
        verif(all(v == (1, 1) for v in c.values()),
              '1. chaque paire doit être référencée une fois : %r' % c)
        verif(texte.count('/assets/aide-assembleur.js') == 1,
              '1. le catalogue d’aide doit être injecté une fois')
        verif(texte.index('aide-assembleur.js') < texte.index('index-BA4XgQVD.js'),
              '1. le catalogue d’aide doit précéder le bundle')
        verif('defer src="/assets/aide-assembleur.js"' not in texte,
              '1. le catalogue d’aide ne doit PAS être différé : le bundle lit '
              'window.PS_LANG_HELP à son évaluation')
        positions = [texte.index('/assets/%s.js' % n) for n in PAIRES]
        verif(positions == sorted(positions),
              '1. l’ordre des panneaux doit être canonique : %r' % positions)
        # ps-hotes.js doit précéder TOUS les panneaux : c'est lui qui remplace
        # leurs cinq observateurs. Inséré après, chaque panneau retombe sur son
        # repli et l'application redevient lente — sans aucune erreur nulle part.
        verif(texte.count('/assets/ps-hotes.js') == 1,
              '1. ps-hotes.js doit être injecté exactement une fois (%d)'
              % texte.count('/assets/ps-hotes.js'))
        verif(texte.index('/assets/ps-hotes.js') < min(positions),
              '1. ps-hotes.js doit PRÉCÉDER les panneaux sur un index vierge : '
              'position %d, premier panneau %d'
              % (texte.index('/assets/ps-hotes.js'), min(positions)))
        for nom in PAIRES:
            verif(texte.index('/assets/%s.css' % nom)
                  < texte.index('/assets/%s.js' % nom),
                  '1. %s : la feuille de style doit précéder le script' % nom)
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code == 0, '1. après injection, --verifier doit être conforme '
                         '(%d) : %s' % (code, sortie[-300:]))
        # Et l'idempotence : rejouer ne change rien.
        avant = texte
        code, sortie = jouer(INSEREUR, index)
        verif(code == 0 and io.open(index, encoding='utf8').read() == avant,
              '1. rejouer l’injection ne doit rien changer')

        # ---- 2. data-studio déjà canonique : rien n'est réinjecté -------
        dossier = Path(temporaire) / 'canonique'
        canonique = ('<link rel="stylesheet" href="/assets/data-studio.css">'
                     '<script defer src="/assets/data-studio.js"></script>')
        base = index_vierge().replace(
            '</head>', canonique + '</head>')
        index = contexte(dossier, base)
        code, sortie = jouer(INSEREUR, index)
        texte = io.open(index, encoding='utf8').read()
        verif(code == 0, '2. l’injection sur une base portant déjà data-studio '
                         'doit réussir (%d) : %s' % (code, sortie[-300:]))
        verif(comptes(texte)['data-studio'] == (1, 1),
              '2. data-studio ne doit pas être chargé deux fois : %r'
              % (comptes(texte)['data-studio'],))
        verif(all(v == (1, 1) for v in comptes(texte).values()),
              '2. toutes les paires doivent être référencées une fois : %r'
              % comptes(texte))
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code == 0, '2. --verifier doit être conforme (%d) : %s'
              % (code, sortie[-300:]))

        # ---- 3. data-studio sans « defer » : rien n'est ajouté ----------
        dossier = Path(temporaire) / 'sansdefer'
        autre = ('<link rel="stylesheet" href="/assets/data-studio.css">'
                 '<script src="/assets/data-studio.js"></script>')
        index = contexte(dossier, index_vierge().replace('</head>',
                                                         autre + '</head>'))
        code, sortie = jouer(INSEREUR, index)
        texte = io.open(index, encoding='utf8').read()
        verif(code == 0, '3. une paire référencée sous une autre forme ne doit '
                         'pas arrêter la construction (%d) : %s'
              % (code, sortie[-400:]))
        verif(comptes(texte)['data-studio'] == (1, 1),
              '3. data-studio ne doit PAS être chargé deux fois quand la base '
              'le référence déjà autrement : %r' % (comptes(texte)['data-studio'],))
        verif(texte.count('<script src="/assets/data-studio.js"></script>') == 1,
              '3. la balise de la base doit être laissée telle quelle')
        verif(all(v == (1, 1) for k, v in comptes(texte).items()),
              '3. les quatre autres paires doivent être injectées : %r'
              % comptes(texte))
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code == 0, '3. --verifier doit accepter une paire référencée '
                         'autrement (%d) : %s' % (code, sortie[-400:]))
        verif('autre forme' in sortie,
              '3. la forme non canonique doit être ANNONCÉE, pas passée sous '
              'silence : %s' % sortie[-300:])

        # ---- 4. data-studio.js seul : la feuille manquante est ajoutée --
        dossier = Path(temporaire) / 'partiel'
        index = contexte(dossier, index_vierge().replace(
            '</head>',
            '<script defer src="/assets/data-studio.js"></script></head>'))
        code, sortie = jouer(INSEREUR, index)
        texte = io.open(index, encoding='utf8').read()
        verif(code == 0, '4. une paire partiellement référencée ne doit pas '
                         'arrêter la construction (%d) : %s'
              % (code, sortie[-400:]))
        verif(comptes(texte)['data-studio'] == (1, 1),
              '4. la feuille manquante doit être ajoutée, et le script ne doit '
              'pas être dupliqué : %r' % (comptes(texte)['data-studio'],))
        verif(texte.count('defer src="/assets/data-studio.js"') == 1,
              '4. le script de la base ne doit pas être réinjecté')
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code == 0, '4. --verifier doit être conforme après complément '
                         '(%d) : %s' % (code, sortie[-400:]))

        # ---- 5. un doublon venu de la base est REFUSÉ -------------------
        dossier = Path(temporaire) / 'double'
        double = ('<script defer src="/assets/data-studio.js"></script>'
                  '<script src="/assets/data-studio.js"></script>')
        index = contexte(dossier, index_vierge().replace('</head>',
                                                         double + '</head>'))
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code != 0, '5. un fichier chargé deux fois doit être REFUSÉ par '
                         '--verifier, même si le doublon vient de la base '
                         '(%d) : %s' % (code, sortie[-300:]))
        verif('deux fois' in sortie or '1 et 1 attendues' in sortie,
              '5. le refus doit nommer le doublon : %s' % sortie[-300:])

        # ---- 6. un index vierge n'est pas « conforme » ------------------
        dossier = Path(temporaire) / 'nonconforme'
        index = contexte(dossier, index_vierge())
        code, sortie = jouer(INSEREUR, index, '--verifier')
        verif(code != 0, '6. --verifier sur un index vierge doit dire que ce '
                         'n’est pas conforme (%d)' % code)

        # ---- 7. l'index de référence reste conforme --------------------
        reference = REFERENCE / 'index.html'
        if reference.is_file():
            code, sortie = jouer(INSEREUR, reference, '--verifier')
            verif(code == 0, '7. l’index.html de référence doit être conforme '
                             '(%d) : %s' % (code, sortie[-300:]))
        else:
            ECHECS.append('7. index.html de référence absent : %s' % reference)


def main():
    try:
        principal()
    except Exception as exc:
        import traceback
        traceback.print_exc()
        ECHECS.append('le banc a levé %s : %s' % (type(exc).__name__, exc))
    print('smoke_inserer_assets : %d contrôles, %d échec(s)'
          % (OK + len(ECHECS), len(ECHECS)))
    for echec in ECHECS:
        print('  ÉCHEC : ' + echec)
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
