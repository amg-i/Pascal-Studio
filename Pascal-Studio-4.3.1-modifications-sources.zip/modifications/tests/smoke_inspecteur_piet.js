'use strict';
/* Banc de la surcouche Piet de l'inspecteur visuel.
 *
 * inspecteur_visuel.SCRIPT est du JavaScript embarqué dans un module Python :
 * il est extrait ici, puis exécuté dans un contexte minimal qui imite le DOM.
 * Ce banc vérifie ce qui ne peut pas l'être depuis Python : le tracé des blocs
 * de couleur, leur mise à l'échelle quand l'image est affichée agrandie, le
 * surlignage du bloc actif publié par la session de pas à pas, la légende, le
 * survol, et le rafraîchissement périodique.
 *
 *   node tests/smoke_inspecteur_piet.js
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let passes = 0;
const echecs = [];
function verif(condition, message) {
  if (condition) passes++;
  else echecs.push(message);
}

// ---------------------------------------------------------------- extraction --
const source = fs.readFileSync(
  path.join(__dirname, '..', 'inspecteur_visuel.py'), 'utf8');
const debut = source.indexOf('SCRIPT = r"""');
verif(debut > 0, 'SCRIPT introuvable dans inspecteur_visuel.py');
const corps = source.slice(debut + 'SCRIPT = r"""'.length);
const fin = corps.indexOf('\n"""\n');
verif(fin > 0, 'fin du bloc SCRIPT introuvable');
const SCRIPT = corps.slice(0, fin);
verif(SCRIPT.includes('echelleCodel'), 'le script ne définit pas echelleCodel');

// ------------------------------------------------------------ stub du DOM ----
function creerNoeud(tagName, id) {
  const noeud = {
    nodeType: 1,
    tagName: String(tagName || 'div').toUpperCase(),
    id: id || '',
    className: '',
    style: {},
    textContent: '',
    innerHTML: '',
    attributes: [],
    enfants: [],
    _ecouteurs: {},
    __ps_piet_branche: false,
  };
  noeud.classList = {
    add(c) { if (!noeud.classList.contains(c)) noeud.className += (noeud.className ? ' ' : '') + c; },
    remove(c) {
      noeud.className = noeud.className.split(' ').filter(x => x && x !== c).join(' ');
    },
    contains(c) { return noeud.className.split(' ').includes(c); },
    get length() { return noeud.className ? noeud.className.split(' ').length : 0; },
  };
  noeud.appendChild = function (enfant) { noeud.enfants.push(enfant); return enfant; };
  noeud.remove = function () { noeud.retire = true; };
  noeud.setAttribute = function (nom, valeur) { noeud['attr_' + nom] = String(valeur); };
  noeud.getAttribute = function (nom) { return noeud['attr_' + nom] === undefined ? null : noeud['attr_' + nom]; };
  noeud.addEventListener = function (type, fn) {
    (noeud._ecouteurs[type] = noeud._ecouteurs[type] || []).push(fn);
  };
  noeud.scrollIntoView = function () { noeud.scrolle = true; };
  // querySelector rend toujours le même objet pour un même sélecteur : le
  // script range ces noeuds dans EL et les réutilise d'un appel à l'autre.
  noeud._parSelecteur = {};
  noeud.querySelector = function (selecteur) {
    if (!noeud._parSelecteur[selecteur]) {
      noeud._parSelecteur[selecteur] = creerNoeud(
        selecteur.startsWith('img') ? 'img' : 'div', selecteur.replace(/^#/, ''));
    }
    return noeud._parSelecteur[selecteur];
  };
  noeud.querySelectorAll = function () { return []; };
  noeud.getBoundingClientRect = function () {
    return noeud._rect || { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
  };
  return noeud;
}

const ecouteurs = { document: {}, window: {} };
const intervalles = [];
const requetes = [];
let reponseFetch = null;   // objet à rendre, ou null pour faire échouer fetch
let echecFetch = false;

const documentStub = {
  readyState: 'complete',
  body: creerNoeud('body'),
  createElement: creerNoeud,
  addEventListener(type, fn) { (ecouteurs.document[type] = ecouteurs.document[type] || []).push(fn); },
  querySelector(selecteur) { return documentStub.body.querySelector(selecteur); },
  querySelectorAll() { return []; },
};

// L'image du programme : 5 codels de large sur 2 de haut, affichée 100 x 40.
const IMAGE = creerNoeud('img', '__ps_piet_image');
IMAGE.id = '__ps_piet_image';
IMAGE._rect = { left: 20, top: 30, right: 120, bottom: 70, width: 100, height: 40 };
documentStub.body._parSelecteur = documentStub.body._parSelecteur || {};
documentStub.body._parSelecteur['img#__ps_piet_image'] = IMAGE;

const contexte = {
  console,
  document: documentStub,
  getComputedStyle() { return { getPropertyValue: () => '' }; },
  WeakMap,
  Math,
  JSON,
  String,
  Array,
  Object,
  Number,
  Promise,
  parseInt, isNaN, Date, RegExp, Error, Set, Map, encodeURIComponent,
  setInterval(fn, delai) { intervalles.push({ fn, delai }); return intervalles.length; },
  clearInterval() {},
  setTimeout(fn) { return setTimeout(fn, 0); },
  fetch(url) {
    requetes.push(url);
    if (echecFetch) return Promise.reject(new Error('serveur injoignable'));
    const corps = reponseFetch;
    return Promise.resolve({ json: () => Promise.resolve(corps) });
  },
  scrollX: 0,
  scrollY: 0,
};
contexte.window = contexte;
contexte.addEventListener = function (type, fn) {
  (ecouteurs.window[type] = ecouteurs.window[type] || []).push(fn);
};
contexte.requestAnimationFrame = function (fn) { return setTimeout(fn, 0); };

vm.createContext(contexte);
try {
  vm.runInContext(SCRIPT, contexte, { filename: 'inspecteur_visuel.SCRIPT' });
  passes++;
} catch (erreur) {
  echecs.push('le script lève au chargement : ' + erreur.message);
}

// Le script se termine par un fetch initial : on le laisse échouer pour rester
// maître de l'ordre des initialisations.
function noeudDe(id) {
  return documentStub.body.enfants.filter(n => n.id === id)[0] || null;
}
function initialiser(carte) {
  (ecouteurs.window.message || []).forEach(fn => fn({ data: { type: 'ps-inspecteur-init', carte } }));
}
function tick() { return new Promise(resoudre => setTimeout(resoudre, 0)); }

// ------------------------------------------------------------- les données ---
function codels() {
  return [
    { index: 0, taille: 3, rvb: '#FF0000', teinte: 'rouge', luminosite: 'normale',
      classe: 'rouge normale', rectangle: [0, 0, 3, 1] },
    { index: 1, taille: 3, rvb: '#C00000', teinte: 'rouge', luminosite: 'sombre',
      classe: 'rouge sombre', rectangle: [0, 1, 3, 2] },
    { index: 2, taille: 2, rvb: '#FF00FF', teinte: 'magenta', luminosite: 'normale',
      classe: 'magenta normale', rectangle: [3, 0, 5, 1] },
  ];
}
function carte(actif) {
  const geometrie = { largeur: 5, hauteur: 2, taille_codel: 1, blocs: 3 };
  if (actif) geometrie.actif = actif;
  return { langage: 'piet', path: '/projet/programme.png', diagnostics: [],
    elements: [], regles: [], blocs: [], environnements: [],
    codels: codels(), geometrie, message: '' };
}
const ACTIF = { index: 1, taille: 3, rvb: [192, 0, 0], classe: [2, 0],
  commande: 'push', libelle: 'push', dp: 0, cc: 0, rectangle: [0, 1, 3, 2] };

(async function principal() {
  await tick();   // le fetch initial échoue et ne fait rien

  // --------------------------------------------- un autre langage : rien -----
  initialiser({ langage: 'html', path: '/p.html', diagnostics: [], elements: [],
    regles: [], blocs: [], environnements: [], codels: [], geometrie: {}, message: '' });
  verif(noeudDe('__ps_inspecteur_piet') === null,
    'un aperçu HTML ne doit pas créer la couche Piet');

  // ------------------------------------------------ Piet sans bloc actif -----
  initialiser(carte(null));
  let couche = noeudDe('__ps_inspecteur_piet');
  verif(couche !== null, 'la couche Piet doit être créée');
  const occurrences = (couche.innerHTML.match(/class="ps-codel/g) || []).length;
  verif(occurrences === 3, 'trois blocs attendus, ' + occurrences + ' tracés');
  verif(!couche.innerHTML.includes('ps-codel-actif'),
    'sans session, aucun bloc ne doit être surligné');
  // Image de 5 x 2 affichée en 100 x 40 : un codel vaut 20 x 20 pixels.
  verif(couche.innerHTML.includes('left:0px;top:20px;width:60px;height:20px'),
    'le bloc 1 doit être mis à l’échelle de l’image affichée : ' + couche.innerHTML);
  verif(couche.innerHTML.includes('data-index="2"'), 'le bloc 2 doit être tracé');
  const legende = noeudDe('__ps_inspecteur_legende');
  verif(legende !== null, 'la légende doit exister');
  verif(legende && legende.style.display === 'none',
    'sans bloc actif, la légende doit rester cachée');

  // -------------------------------------------------- Piet avec bloc actif ---
  initialiser(carte(ACTIF));
  couche = noeudDe('__ps_inspecteur_piet');
  const actifs = (couche.innerHTML.match(/ps-codel-actif/g) || []).length;
  verif(actifs === 1, 'un seul bloc actif attendu, ' + actifs + ' trouvés');
  verif(/class="ps-codel ps-codel-actif" data-index="1"/.test(couche.innerHTML),
    'le bloc actif doit être celui d’indice 1 : ' + couche.innerHTML);
  verif(legende.style.display === 'block', 'la légende doit s’afficher');
  verif(legende.innerHTML.includes('bloc 1'), 'la légende doit nommer le bloc');
  verif(legende.innerHTML.includes('push'), 'la légende doit nommer la commande');
  verif(legende.innerHTML.includes('rouge sombre'),
    'la légende doit donner la nuance du bloc');
  verif(legende.innerHTML.includes('3 codels'),
    'la légende doit donner la taille du bloc');
  verif(legende.innerHTML.includes('DP 0 CC 0'),
    'la légende doit donner le pointeur et le changeur de cap');

  // --------------------------------------------- un seul minuteur, jamais deux _
  const avant = intervalles.length;
  initialiser(carte(ACTIF));
  verif(intervalles.length === avant,
    'le rafraîchissement périodique ne doit pas être doublé');
  verif(avant === 1, 'un rafraîchissement périodique doit être armé');

  // ------------------------------------------------------------ le survol ----
  const survol = noeudDe('__ps_inspecteur_survol');
  const cadre = noeudDe('__ps_inspecteur_cadre');
  // L'image commence à (20, 30) et fait 100 x 40 : (50, 55) tombe dans le bloc 1.
  (ecouteurs.document.mouseover || []).forEach(fn => fn({
    target: IMAGE, clientX: 50, clientY: 55, preventDefault() {}, stopPropagation() {},
  }));
  verif(survol && survol.style.display === 'block', 'le survol doit s’afficher');
  verif(survol && survol.textContent.includes('bloc 1'),
    'le survol doit nommer le bloc : ' + (survol ? survol.textContent : 'absent'));
  verif(survol && survol.textContent.includes('rouge sombre'),
    'le survol doit donner la nuance');
  verif(survol && survol.textContent.includes('3 codels'),
    'le survol doit donner la taille');
  verif(survol && survol.textContent.includes('#C00000'),
    'le survol doit donner la couleur');
  verif(cadre && cadre.style.width === '60px' && cadre.style.height === '20px',
    'le cadre doit épouser le bloc survolé');

  // Un survol dans le bloc 0 (au-dessus) change de bloc.
  (ecouteurs.document.mouseover || []).forEach(fn => fn({
    target: IMAGE, clientX: 30, clientY: 35, preventDefault() {}, stopPropagation() {},
  }));
  verif(survol.textContent.includes('bloc 0'),
    'le survol doit suivre la position : ' + survol.textContent);

  // Hors de l'image, le survol Piet rend la main au survol ordinaire, qui
  // étiquette l'élément survolé au lieu d'un bloc de couleur.
  (ecouteurs.document.mouseover || []).forEach(fn => fn({
    target: IMAGE, clientX: 5, clientY: 5, preventDefault() {}, stopPropagation() {},
  }));
  verif(survol.textContent.indexOf('img#__ps_piet_image') === 0,
    'hors de l’image, le survol ordinaire doit reprendre la main : '
    + survol.textContent);
  verif(!survol.textContent.includes('bloc'),
    'hors de l’image, aucune information de bloc ne doit subsister');

  // -------------------------------------------------- changement d'échelle ---
  IMAGE._rect = { left: 0, top: 0, right: 200, bottom: 80, width: 200, height: 80 };
  (ecouteurs.window.resize || []).forEach(fn => fn({}));
  couche = noeudDe('__ps_inspecteur_piet');
  verif(couche.innerHTML.includes('left:0px;top:40px;width:120px;height:40px'),
    'un redimensionnement doit recalculer les rectangles : ' + couche.innerHTML);
  IMAGE._rect = { left: 20, top: 30, right: 120, bottom: 70, width: 100, height: 40 };

  // ------------------------------------------------ le rafraîchissement ------
  const suivant = carte({ index: 2, taille: 2, commande: 'out(char)',
    libelle: 'out(char)', dp: 1, cc: 1, rectangle: [3, 0, 5, 1] });
  reponseFetch = suivant;
  intervalles[0].fn();
  await tick(); await tick();
  couche = noeudDe('__ps_inspecteur_piet');
  verif(/data-index="2"/.test(couche.innerHTML) &&
        /ps-codel-actif" data-index="2"/.test(couche.innerHTML),
    'le rafraîchissement doit déplacer le surlignage : ' + couche.innerHTML);
  verif(!/ps-codel-actif" data-index="1"/.test(couche.innerHTML),
    'l’ancien bloc actif ne doit plus être surligné');
  verif(legende.innerHTML.includes('bloc 2') && legende.innerHTML.includes('out(char)'),
    'la légende doit suivre le bloc actif : ' + legende.innerHTML);
  verif(requetes.includes('/__ps_inspecteur_data'),
    'le rafraîchissement doit interroger /__ps_inspecteur_data');

  // Un rafraîchissement sans bloc actif (session terminée) efface la légende.
  reponseFetch = carte(null);
  intervalles[0].fn();
  await tick(); await tick();
  verif(legende.style.display === 'none',
    'session terminée : la légende doit se cacher');
  couche = noeudDe('__ps_inspecteur_piet');
  verif(!couche.innerHTML.includes('ps-codel-actif'),
    'session terminée : plus aucun bloc surligné');

  // Un serveur muet ne doit rien casser : la tentative a bien lieu, l'état
  // affiché reste celui du dernier rafraîchissement réussi.
  echecFetch = true;
  const tentatives = requetes.length;
  intervalles[0].fn();
  await tick(); await tick();
  verif(requetes.length === tentatives + 1,
    'un rafraîchissement doit être tenté même après un échec');
  verif(legende.style.display === 'none',
    'un échec du serveur ne doit pas rallumer la légende');
  verif(!noeudDe('__ps_inspecteur_piet').innerHTML.includes('ps-codel-actif'),
    'un échec du serveur ne doit pas inventer de bloc actif');

  // ---------------------------------------------------------- le rapport -----
  const total = passes + echecs.length;
  if (echecs.length) {
    console.log('ÉCHECS (' + echecs.length + ') :');
    echecs.slice(0, 20).forEach(e => console.log('  - ' + e));
  }
  console.log(passes + '/' + total + ' vérifications conformes');
  process.exit(echecs.length ? 1 : 0);
})();
