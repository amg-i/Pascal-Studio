# -*- coding: utf-8 -*-
"""Tests INTERCAL. Les valeurs attendues sont DERIVEES de la spécification,
jamais recopiées d'une sortie observée.

Lancer :  python3 tests/smoke_intercal.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import langages_esoteriques as E   # noqa: E402

OK = 0; N = 0
def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    bon = obtenu == attendu
    OK += bon
    print('  %-52s %s' % (titre, 'CONFORME' if bon else 'DIFFERENT'))
    if not bon:
        print('      obtenu  : %r' % (obtenu,))
        print('      attendu : %r' % (attendu,))

def lancer(code, entree='', limite=20000):
    return E.Intercal(code, entree=entree).executer(limite=limite)

print('=== operateurs : valeurs derivees de la specification ===')
# La spec dit textuellement : « #12 ~ #5 (1100 et 101 en binaire) vaut 10 »
# — 10 en BINAIRE, soit 2 en décimal : les bits 2^2 (=1) et 2^0 (=0) de #12.
verifier('select : #12 ~ #5 = 10 en binaire, donc 2',
         E._select(12, 5), 2)
# mingle : « le bit de poids faible de DROITE devient celui du résultat »,
# bits entrelacés. #1 $ #2 -> droite=2 (bit1), gauche=1 (bit0)
# résultat : bit0=droite0=0, bit1=gauche0=1, bit2=droite1=1, bit3=gauche1=0
# soit 0b0110 = 6.
verifier('mingle : #1 $ #2 = 6', E._mingle(1, 2), 6)
verifier('mingle : #0 $ #0 = 0', E._mingle(0, 0), 0)
verifier('mingle : #65535 $ #0 = 0xAAAAAAAA',
         E._mingle(0xFFFF, 0), 0xAAAAAAAA)
# unaire : « les bits 2^0 et 2^1 donnent le bit 2^0 du résultat », et le bit de
# poids fort combine le plus et le moins significatif. Sur 16 bits, #12 = 1100 :
# bit0=0|0=0, bit1=0|1=1, bit2=1|1=1, bit3=1|0=1, reste 0 -> 0b1110 = 14.
verifier('unaire V (OR) de #12 sur 16 bits = 14', E._unaire('V', 12, 16), 14)
# ? = XOR : bit0=0^0=0, bit1=0^1=1, bit2=1^1=0, bit3=1^0=1 -> 0b1010 = 10
verifier('unaire ? (XOR) de #12 sur 16 bits = 10', E._unaire('?', 12, 16), 10)
# & = AND : bit0=0&0=0, bit1=0&1=0, bit2=1&1=1, bit3=1&0=0 -> 0b0100 = 4
verifier('unaire & (AND) de #12 sur 16 bits = 4', E._unaire('&', 12, 16), 4)
# Le bit de poids fort combine le plus et le moins significatif : sur 4 bits,
# #12 = 1100 -> bit3 = in3|in0 = 1|0 = 1, bit2 = 1|1 = 1, bit1 = 0|1 = 1,
# bit0 = 0|0 = 0 -> 1110 = 14 ; avec & : bit3 = 1&0 = 0 -> 0100 = 4.
verifier('le bit fort reboucle sur le bit faible (& sur 4 bits de 1100) = 4',
         E._unaire('&', 12, 4), 4)

print()
print('=== READ OUT : chiffres romains « abimés » ===')
verifier('0 -> « O »', E.romain_intercal(0, 16), 'O')
verifier('1 -> I', E.romain_intercal(1, 16), 'I')
verifier('42 -> XLII', E.romain_intercal(42, 16), 'XLII')
verifier('1999 -> MCMXCIX', E.romain_intercal(1999, 16), 'MCMXCIX')
verifier('4000 répète M (convention 16 bits documentée)',
         E.romain_intercal(4000, 16), 'MMMM')
verifier('3999 -> MMMCMXCIX', E.romain_intercal(3999, 16), 'MMMCMXCIX')
verifier('1000000 sur 32 bits -> R', E.romain_intercal(1000000, 32), 'R')

print()
print('=== instructions, via de vrais programmes ===')
r = lancer('DO .1 <- #42\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('affectation puis READ OUT', r['sortie'], 'XLII\n')
r = lancer("DO .1 <- '#12 ~ #5'\nPLEASE READ OUT .1\nDO GIVE UP")
verifier('expression groupée par sparks', r['sortie'], 'II\n')
r = lancer("DO .2 <- #12\nDO .1 <- '&.2'\nPLEASE READ OUT .1\nDO GIVE UP")
verifier('unaire placé APRÈS le point : &.2', r['sortie'], 'IV\n')
r = lancer("DO :1 <- '#1 $ #2'\nPLEASE READ OUT :1\nDO GIVE UP")
verifier('valeur 32 bits (:1) lue comme 32 bits', r['sortie'], 'VI\n')
r = lancer('DO ,1 <- #3\nPLEASE DO ,1 SUB #1 <- #10\nDO ,1 SUB #2 <- #20\n'
           'DO ,1 SUB #3 <- #30\nPLEASE READ OUT ,1\nDO GIVE UP')
verifier('tableau basé à 1, dimensionné puis rempli via SUB',
         r['sortie'], 'X\nXX\nXXX\n')
r = lancer('DO .1 <- #7\nPLEASE DO STASH .1\nDO .1 <- #99\n'
           'DO RETRIEVE .1\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('STASH puis RETRIEVE restaure la valeur', r['sortie'], 'VII\n')
r = lancer('DO .1 <- #5\nDO IGNORE .1\nDO .1 <- #6\nPLEASE READ OUT .1\n'
           'DO REMEMBER .1\nDO .1 <- #8\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('IGNORE rend la variable insensible, REMEMBER annule',
         r['sortie'], 'V\nVIII\n')
r = lancer('DO .1 <- #1\nPLEASE READ OUT .1\nDO (20) NEXT\nDO GIVE UP\n'
           '(20) DO .1 <- #2\nPLEASE READ OUT .1\nDO RESUME #1')
verifier('NEXT saute à l’étiquette, RESUME revient', r['sortie'], 'I\nII\n')
r = lancer('DO .1 <- #1\n(7) DO COME FROM (7)\nDO .1 <- #2\n'
           'PLEASE READ OUT .1\nDO GIVE UP')
verifier('COME FROM détourne le contrôle après la ligne visée',
         r['sortie'], 'II\n')
r = lancer('DO .1 <- #4\nDON\'T READ OUT .1\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('DON\'T rend la ligne sans effet', r['sortie'], 'IV\n')
r = lancer('PLEASE NOTE ceci est un commentaire\nDO .1 <- #3\n'
           'PLEASE READ OUT .1\nDO GIVE UP')
verifier('PLEASE NOTE est un commentaire irrécupérable', r['sortie'], 'III\n')
r = lancer('DO .1 <- #6\nDO ABSTAIN FROM READING OUT\nPLEASE READ OUT .1\n'
           'DO GIVE UP')
verifier('ABSTAIN FROM par nom de commande', r['sortie'], '')
r = lancer('DO .1 <- #6\nDO ABSTAIN FROM READING OUT\nPLEASE READ OUT .1\n'
           'DO REINSTATE READING OUT\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('REINSTATE annule l’ABSTAIN', r['sortie'], 'VI\n')
r = lancer('DO WRITE IN .1\nPLEASE READ OUT .1\nDO GIVE UP', entree='ONE TWO\n')
verifier('WRITE IN lit des chiffres épelés (« ONE TWO » = 12)',
         r['sortie'], 'XII\n')
r = lancer('DO WRITE IN .1\nPLEASE READ OUT .1\nDO GIVE UP', entree='OH\n')
verifier('WRITE IN accepte OH pour zéro', r['sortie'], 'O\n')
r = lancer('DO .1 <- #0\nDO %0 .1 <- #9\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('%0 ne s’exécute jamais', r['sortie'], 'O\n')
r = lancer('DO .1 <- #0\nDO %100 .1 <- #9\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('%100 s’exécute toujours', r['sortie'], 'IX\n')
r = lancer('DO .1 <- #2\nDO FORGET #0\nPLEASE READ OUT .1\nDO GIVE UP')
verifier('FORGET #0 ne casse rien', r['sortie'], 'II\n')

print()
print('=== politesse : entre un cinquième et un tiers ===')
impoli = '\n'.join(['DO .1 <- #%d' % i for i in range(10)] + ['DO GIVE UP'])
r = lancer(impoli)
verifier('aucun PLEASE sur 11 instructions -> refus', r['state'], 'error')
verifier('message de politesse',
         'impoli' in (r['message'] + ' '.join(d['message'] for d in r['diagnostics'])).lower(),
         True)
trop_poli = '\n'.join(['PLEASE DO .1 <- #%d' % i for i in range(10)] +
                      ['DO GIVE UP'])
r = lancer(trop_poli)
verifier('tous PLEASE sur 11 instructions -> refus', r['state'], 'error')
equilibre = '\n'.join(['DO .1 <- #%d' % i for i in range(8)] +
                      ['PLEASE DO .1 <- #1', 'PLEASE DO .1 <- #2',
                       'PLEASE DO .1 <- #3', 'DO GIVE UP'])
r = lancer(equilibre)
verifier('3 PLEASE sur 12 (1/5=2,4 ; 1/3=4) -> accepté', r['state'], 'success')
juste_dessous = '\n'.join(['DO .1 <- #%d' % i for i in range(9)] +
                           ['PLEASE DO .1 <- #1', 'PLEASE DO .1 <- #2',
                            'DO GIVE UP'])
verifier('2 PLEASE sur 12 (sous 1/5) -> refus', lancer(juste_dessous)['state'],
         'error')
juste_dessus = '\n'.join(['PLEASE DO .1 <- #%d' % i for i in range(4)] +
                          ['DO .1 <- #1', 'DO GIVE UP'])
verifier('4 PLEASE sur 6 (au-dessus de 1/3) -> refus',
         lancer(juste_dessus)['state'], 'error')

print()
print('=== detection d erreurs ===')
cas = [('commande inconnue', 'DO DANCER .1 <- #1'),
       ('NEXT vers une étiquette absente', 'DO (99) NEXT\nDO GIVE UP'),
       ('RESUME avec une pile vide', 'DO RESUME #1\nDO GIVE UP'),
       ('RETRIEVE sans STASH', 'DO RETRIEVE .1\nDO GIVE UP'),
       ('tableau non dimensionné', 'DO .1 <- ,1 SUB #1\nDO GIVE UP'),
       ('indice hors tableau', 'DO ,1 <- #2\nDO .2 <- ,1 SUB #9\nDO GIVE UP'),
       ('mingle en débordement', 'DO :1 <- "#65536 $ #1"\nDO GIVE UP'),
       ('WRITE IN sans entrée', 'DO WRITE IN .1\nDO GIVE UP'),
       ('ligne sans DO ni PLEASE', '.1 <- #1'),
       ('ABSTAIN FROM un nom invalide', 'DO ABSTAIN FROM DANSENT\nDO GIVE UP')]
detectes = 0
for titre, code in cas:
    r = lancer(code)
    msgs = [d['message'] for d in r['diagnostics'] if d['severity'] == 'error']
    if msgs: detectes += 1
    print('  %-34s etat=%-7s %s' % (titre, r['state'], (msgs[:1] or ['AUCUN'])[0][:64]))

print()
print('%d/%d verifications conformes ; %d/%d erreurs detectees'
      % (OK, N, detectes, len(cas)))
sys.exit(0 if OK == N and detectes == len(cas) else 1)
