#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de la locale imposée aux outils externes, et de l'outil qui avertit.

LA PANNE QUE CE BANC PROTÈGE
  Une construction s'est arrêtée sur une machine Debian 13 en français, sur
  l'autocontrôle de retro_binaires.py :

      ÉCHEC : readelf annonce un point d'entrée ?, Pascal Studio 0x400100
      ÉCHEC : readelf -h doit rendre l'en-tête ("readelf: ERREUR\\xa0: le segment
              PHDR n'est pas couvert par un segment LOAD\\n")
      ÉCHEC : le nombre de sections diffère de readelf (30 contre ?)

  Le message de readelf est EN FRANÇAIS. binutils est traduit : sur une machine
  française, readelf répond « En-tête ELF : », « Nombre d'en-têtes de section : »,
  « Adresse du point d'entrée : ». Les expressions régulières du module cherchent
  les formes anglaises, donc elles ne trouvent rien, et le croisement rend « ? »
  partout — alors que l'analyse de Pascal Studio, elle, est exacte. Un second
  défaut s'y ajoutait : readelf signale l'anomalie du binaire lié à la main puis
  CONTINUE et rend l'en-tête, avec un code de retour non nul ; ce code était
  traité comme un échec et la sortie jetée.

POURQUOI UN FAUX readelf
  La panne dépend de la locale de la machine : sur une machine anglophone, ou
  sans les fichiers de traduction de binutils, elle n'existe pas. Le banc ne peut
  donc pas attendre d'être joué sur une machine française pour être utile. Il
  installe un FAUX readelf qui se comporte comme le vrai — il regarde LC_ALL et
  répond dans la langue demandée — et il vérifie que le module obtient la réponse
  anglaise. Sans la correction, ce faux readelf répond en français et le banc
  échoue : la mutation est tuée ici, et pas seulement chez l'utilisateur.

  Le faux readelf émet AUSSI l'avertissement « PHDR non couvert » sur stderr avec
  un code de retour 1, dans les deux langues : c'est la seconde moitié de la
  panne, et elle est indépendante de la locale.

CE QUI EST CONTRÔLÉ
  1. la locale imposée : le faux readelf rend l'en-tête en ANGLAIS quand il est
     appelé par retro_binaires, alors qu'il rendrait du français si la locale de
     l'utilisateur était transmise ;
  2. la contre-épreuve : appelé SANS imposer la locale, avec LC_ALL=fr_FR.UTF-8
     dans l'environnement, le même outil répond en français — donc le contrôle 1
     n'est pas vide ;
  3. un outil qui avertit puis répond est retenu, son code reste fidèle, et son
     avis remonte pour être annoncé ;
  4. un outil muet reste un échec ;
  5. le croisement réel du module — les regex sur l'en-tête — fonctionne sur la
     sortie du faux readelf : ce sont ces regex qui rendaient « ? ».

Aucun binaire analysé n'est exécuté : le faux readelf est un script qui n'ouvre
même pas le fichier qu'on lui donne.

Usage : python3 tests/smoke_locale_outils.py
"""

import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RACINE))

CONTROLES = [0]
ERREURS = []


def verif(condition, message):
    CONTROLES[0] += 1
    if not condition:
        ERREURS.append(message)


# Le faux readelf : il se comporte comme le vrai, c'est-à-dire qu'il regarde la
# locale avant de choisir sa langue, et il avertit puis répond avec un code non
# nul, comme readelf le fait sur un binaire dont le PHDR n'est pas couvert par un
# segment LOAD.
FAUX_READELF = r'''#!/bin/sh
case "$LC_ALL" in
  C*|POSIX*)
    echo "ELF Header:"
    echo "  Class:                             ELF32"
    echo "  Type:                              EXEC (Executable file)"
    echo "  Machine:                           MIPS R3000"
    echo "  Entry point address:               0x400100"
    echo "  Number of program headers:         14"
    echo "  Number of section headers:         30"
    echo "readelf: Error: the PHDR segment is not covered by a LOAD segment" >&2
    exit 1
    ;;
esac
echo "En-tête ELF :"
echo "  Classe :                           ELF32"
echo "  Type :                             EXEC (fichier exécutable)"
echo "  Machine :                          MIPS R3000"
echo "  Adresse du point d'entrée :        0x400100"
echo "  Nombre d'en-têtes de programme :   14"
echo "  Nombre d'en-têtes de section :     30"
echo "readelf: ERREUR : le segment PHDR n'est pas couvert par un segment LOAD" >&2
exit 1
'''


def installer(dossier):
    """Pose un faux readelf exécutable et rend le PATH qui le trouve en premier."""
    outil = dossier / 'readelf'
    outil.write_text(FAUX_READELF, encoding='utf8')
    outil.chmod(outil.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return '%s:%s' % (dossier, os.environ.get('PATH', ''))


def main():
    import retro_binaires as rb

    with tempfile.TemporaryDirectory() as temporaire:
        dossier = Path(temporaire)
        chemin = dossier / 'binaire.bin'
        chemin.write_bytes(b'\x7fELF' + b'\x00' * 60)
        chemin_dossier = installer(dossier)
        ancien_path = os.environ.get('PATH', '')
        ancienne_locale = os.environ.get('LC_ALL')
        os.environ['PATH'] = str(chemin_dossier)
        os.environ['LC_ALL'] = 'fr_FR.UTF-8'
        try:
            # ---- 0. le faux readelf est bien celui qui est trouvé ----------
            trouve = shutil.which('readelf')
            verif(trouve and str(dossier) in trouve,
                  'le faux readelf n’est pas en tête de PATH (%r)' % trouve)

            # ---- 1. la locale imposée --------------------------------------
            resultat = rb.readelf(chemin, ('-h', '-W'))
            sortie = resultat.get('sortie', '')
            verif('ELF Header' in sortie,
                  'readelf doit répondre en ANGLAIS quand le module l’appelle, '
                  'donc LC_ALL doit être imposé ; reçu %r' % sortie[:120])
            verif('En-tête ELF' not in sortie,
                  'la réponse est encore localisée : la locale de '
                  'l’utilisateur est transmise à l’outil')

            # ---- 2. la contre-épreuve : le faux outil répond bien en
            # ---- français si la locale n'est pas imposée. Sans elle, le
            # ---- contrôle 1 pourrait passer parce que l'outil ne traduit pas.
            brut = subprocess.run([trouve, '-h', '-W', '--', str(chemin)],
                                  capture_output=True, text=True,
                                  env={**os.environ, 'LC_ALL': 'fr_FR.UTF-8'})
            verif('En-tête ELF' in brut.stdout and 'ELF Header' not in brut.stdout,
                  'le faux readelf ne reproduit pas la localisation : la '
                  'contre-épreuve est vide')

            # ---- 3. l'outil qui avertit puis répond ------------------------
            verif(resultat['ok'] and resultat.get('averti'),
                  'un outil qui avertit puis répond doit être retenu ET marqué '
                  'comme ayant averti (ok=%r averti=%r)'
                  % (resultat['ok'], resultat.get('averti')))
            verif(resultat.get('code') == 1,
                  'le code de retour doit rester fidèle, reçu %r'
                  % resultat.get('code'))
            verif(any('PHDR' in a for a in resultat.get('avertissements', [])),
                  'l’avis de l’outil doit remonter dans avertissements (%r)'
                  % resultat.get('avertissements'))

            # ---- 4. un outil muet reste un échec ---------------------------
            muet = dossier / 'muet'
            muet.write_text('#!/bin/sh\nexit 3\n', encoding='utf8')
            muet.chmod(muet.stat().st_mode | stat.S_IXUSR)
            lance = rb._lancer([str(muet)])
            verif(not rb._normaliser_outil(lance)['ok']
                  and lance['code'] == 3,
                  'un outil qui n’a rien écrit doit rester un échec')

            # ---- 5. les regex du croisement, sur la sortie obtenue ---------
            # Ce sont elles qui rendaient « ? » dans la panne signalée.
            for motif, attendu, quoi in (
                    (r'Number of section headers:\s+(\d+)', 30, 'sections'),
                    (r'Number of program headers:\s+(\d+)', 14, 'segments'),
                    (r'Entry point address:\s+(0x[0-9a-f]+)', 0x400100,
                     'point d’entrée')):
                trouve_valeur = re.search(motif, sortie)
                verif(trouve_valeur is not None,
                      'le croisement ne trouve pas le nombre de %s dans la '
                      'sortie de readelf : c’est ce qui rendait « ? »' % quoi)
                if trouve_valeur:
                    lu = trouve_valeur.group(1)
                    attendu_txt = attendu if isinstance(attendu, int) else 0
                    if quoi == 'point d’entrée':
                        verif(int(lu, 16) == attendu_txt,
                              'le point d’entrée lu est %s, attendu 0x%x'
                              % (lu, attendu_txt))
                    else:
                        verif(int(lu) == attendu_txt,
                              'le nombre de %s lu est %s, attendu %d'
                              % (quoi, lu, attendu_txt))

            # ---- 6. les autres outils du module passent par la même règle --
            pour_objdump = rb.desassembler(chemin)
            verif('ok' in pour_objdump,
                  'desassembler doit rendre un verdict, même sans objdump')
            nm = rb.symboles_nm(chemin)
            verif('symboles' in nm and 'ok' in nm,
                  'symboles_nm doit rendre ses symboles et un verdict')
        finally:
            os.environ['PATH'] = ancien_path
            if ancienne_locale is None:
                os.environ.pop('LC_ALL', None)
            else:
                os.environ['LC_ALL'] = ancienne_locale

    # ---- 7. la règle est écrite une fois, et appliquée ---------------------
    texte = (RACINE / 'retro_binaires.py').read_text(encoding='utf8')
    verif("environnement['LC_ALL'] = 'C.UTF-8'" in texte,
          'retro_binaires.py n’impose plus LC_ALL=C.UTF-8')
    verif(texte.count('_normaliser_outil(') >= 4,
          'la normalisation doit être appliquée par readelf, objdump et nm '
          '(%d appels trouvés)' % texte.count('_normaliser_outil('))

    print('Banc de la locale et des outils qui avertissent : %d contrôles, '
          '%d échec(s)' % (CONTROLES[0], len(ERREURS)))
    for e in ERREURS:
        print('  ÉCHEC : ' + e)
    return 1 if ERREURS else 0


if __name__ == '__main__':
    sys.exit(main())
