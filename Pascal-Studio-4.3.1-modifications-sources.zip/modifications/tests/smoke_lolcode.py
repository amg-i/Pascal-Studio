import sys
sys.path.insert(0, '/home/user/work/modifications')
import langages_esoteriques as E

def essai(titre, code, attendu, entree='', limite=200000):
    m = E.Lolcode(code, entree=entree)
    r = m.executer(limite=limite)
    ok = r['sortie'] == attendu
    print('  %-46s %s' % (titre, 'CONFORME' if ok else 'DIFFERENT'))
    if not ok:
        print('      sortie  : %r' % r['sortie'][:110])
        print('      attendu : %r' % attendu[:110])
        print('      etat    : %s | %s' % (r['state'], r['message'][:80]))
        print('      diags   : %s' % [d['message'][:70] for d in r['diagnostics']][:3])
    return ok

total = 0; n = 0
print('=== exemples de la specification ===')
n+=1; total+=essai('Hello World','HAI 1.3\nVISIBLE "Hai world!"\nKTHXBYE','Hai world!\n')
n+=1; total+=essai('Loops (0..9 sur une ligne)',
"""HAI 1.3
IM IN YR loop UPPIN YR var TIL BOTH SAEM var AN 10
\tVISIBLE SMOOSH var AN " " MKAY!
IM OUTTA YR loop
KTHXBYE""", '0 1 2 3 4 5 6 7 8 9 ')
n+=1; total+=essai('Truth-Machine entree 0',
"""HAI 1.3
I HAS A input ITZ A TROOF
GIMMEH input
input, O RLY?
\tYA RLY
\t\tIM IN YR loop
\t\t\tVISIBLE "1"!
\t\tIM OUTTA YR loop
\tNO WAI
\t\tVISIBLE "0"
OIC
KTHXBYE""", '0\n', entree='0\n')
m = E.Lolcode("""HAI 1.3
I HAS A input ITZ A TROOF
GIMMEH input
input, O RLY?
\tYA RLY
\t\tIM IN YR loop
\t\t\tVISIBLE "1"!
\t\tIM OUTTA YR loop
\tNO WAI
\t\tVISIBLE "0"
OIC
KTHXBYE""", entree='1\n')
r = m.executer(limite=2000); n+=1
ok = r['sortie'].startswith('1111')
total += ok
print('  %-46s %s' % ('Truth-Machine entree 1 -> boucle infinie',
      'CONFORME' if ok else 'DIFFERENT %r/%s' % (r['sortie'][:20], r['state'])))

print()
print('=== types, conversions, arithmetique ===')
n+=1; total+=essai('NUMBR/NUMBAR/YARN/TROOF','HAI\nI HAS A n ITZ A NUMBR\nI HAS A f ITZ 3.5\nI HAS A s ITZ "chat"\nI HAS A b ITZ WIN\nVISIBLE n\nVISIBLE f\nVISIBLE s\nVISIBLE b\nKTHXBYE','0\n3.5\nchat\nWIN\n')
n+=1; total+=essai('SUM/DIFF/PRODUKT/QUOSHUNT/MOD','HAI\nI HAS A a ITZ 17\nI HAS A b ITZ 5\nVISIBLE SUM OF a AN b\nVISIBLE DIFF OF a AN b\nVISIBLE PRODUKT OF a AN b\nVISIBLE QUOSHUNT OF a AN b\nVISIBLE MOD OF a AN b\nKTHXBYE','22\n12\n85\n3\n2\n')
n+=1; total+=essai('BIGGR/SMALLR/DIFFRINT','HAI\nVISIBLE BIGGR OF 3 AN 9\nVISIBLE SMALLR OF 3 AN 9\nVISIBLE DIFFRINT 3 AN 9\nVISIBLE BOTH SAEM 3 AN 3\nKTHXBYE','9\n3\nWIN\nWIN\n')
n+=1; total+=essai('MAEK et IS NOW A','HAI\nI HAS A x ITZ "42"\nx IS NOW A NUMBR\nVISIBLE SUM OF x AN 8\nI HAS A y ITZ 3.9\nVISIBLE MAEK y A NUMBR\nKTHXBYE','50\n3\n')
n+=1; total+=essai('echappements :) :> ::','HAI\nVISIBLE "l1:)l2:>tab::dp"\nKTHXBYE','l1\nl2\ttab:dp\n')
n+=1; total+=essai('interpolation :{var}','HAI\nI HAS A nom ITZ "minou"\nVISIBLE "bonjour :{nom} !"\nKTHXBYE','bonjour minou !\n')
n+=1; total+=essai('SMOOSH multi-morceaux','HAI\nVISIBLE SMOOSH "a" AN "b" AN 3 AN "c" MKAY\nKTHXBYE','ab3c\n')
n+=1; total+=essai(':(hex) -> codepoint','HAI\nVISIBLE ":(41)"\nKTHXBYE','A\n')

print()
print('=== controle et fonctions ===')
n+=1; total+=essai('O RLY?/NO WAI','HAI\nI HAS A t ITZ FAIL\nt, O RLY?\n\tYA RLY\n\t\tVISIBLE "vrai"\n\tNO WAI\n\t\tVISIBLE "faux"\nOIC\nKTHXBYE','faux\n')
n+=1; total+=essai('WTF?/OMG/GTFO','HAI\nI HAS A c ITZ 2\nc, WTF?\n\tOMG 1\n\t\tVISIBLE "un"\n\t\tGTFO\n\tOMG 2\n\t\tVISIBLE "deux"\n\t\tGTFO\n\tOMGWTF\n\t\tVISIBLE "autre"\nOIC\nKTHXBYE','deux\n')
n+=1; total+=essai('WTF? fall-through sans GTFO','HAI\nI HAS A c ITZ 1\nc, WTF?\n\tOMG 1\n\t\tVISIBLE "un"\n\tOMG 2\n\t\tVISIBLE "deux"\nOIC\nKTHXBYE','un\ndeux\n')
n+=1; total+=essai('OMGWTF par defaut','HAI\nI HAS A c ITZ 9\nc, WTF?\n\tOMG 1\n\t\tVISIBLE "un"\n\tOMGWTF\n\t\tVISIBLE "autre"\nOIC\nKTHXBYE','autre\n')
n+=1; total+=essai('NERFIN + WILE','HAI\nI HAS A v ITZ 3\nIM IN YR dec NERFIN YR v WILE DIFFRINT v AN 0\n\tVISIBLE v\nIM OUTTA YR dec\nKTHXBYE','3\n2\n1\n')
n+=1; total+=essai('boucle infinie + GTFO','HAI\nI HAS A v ITZ 0\nIM IN YR infini\n\tVISIBLE v!\n\tv R SUM OF v AN 1\n\tBOTH SAEM v AN 5, O RLY?\n\t\tYA RLY\n\t\t\tGTFO\n\tOIC\nIM OUTTA YR infini\nKTHXBYE','01234')
n+=1; total+=essai('fonction FOUND YR','HAI\nHOW IZ I double YR x\n\tFOUND YR PRODUKT OF x AN 2\nIF U SAY SO\nVISIBLE I IZ double YR 21 MKAY\nKTHXBYE','42\n')
n+=1; total+=essai('fonction 2 arguments','HAI\nHOW IZ I somme YR a AN YR b\n\tFOUND YR SUM OF a AN b\nIF U SAY SO\nI HAS A r ITZ 0\nr R I IZ somme YR 20 AN YR 22 MKAY\nVISIBLE r\nKTHXBYE','42\n')
n+=1; total+=essai('commentaires BTW et OBTW/TLDR','HAI\nBTW commentaire\nOBTW\nmulti\nTLDR\nVISIBLE "ok"\nKTHXBYE','ok\n')
n+=1; total+=essai('CAN HAS STDIO?','HAI\nCAN HAS STDIO?\nVISIBLE "ok"\nKTHXBYE','ok\n')
# Le compteur interne est REDECLARE a chaque tour : en LOLCODE une variable de
# boucle n'est pas remise a zero par la seule re-entree dans IM IN YR.
n+=1; total+=essai('boucles imbriquees','HAI\nI HAS A t ITZ 0\nIM IN YR ext UPPIN YR i TIL BOTH SAEM i AN 3\n\tI HAS A j ITZ 0\n\tIM IN YR int UPPIN YR j TIL BOTH SAEM j AN 2\n\t\tt R SUM OF t AN 1\n\tIM OUTTA YR int\nIM OUTTA YR ext\nVISIBLE t\nKTHXBYE','6\n')
n+=1; total+=essai('GIMMEH lit une ligne','HAI\nI HAS A s ITZ ""\nGIMMEH s\nVISIBLE SMOOSH "lu=" AN s MKAY\nKTHXBYE','lu=bonjour\n', entree='bonjour\n')

print()
print('=== detection d erreurs ===')
cas = [('YARN non ferme','HAI\nVISIBLE "pas ferme\nKTHXBYE'),
       ('division par zero','HAI\nI HAS A a ITZ 1\nVISIBLE QUOSHUNT OF a AN 0\nKTHXBYE'),
       ('fonction inconnue','HAI\nVISIBLE I IZ absente MKAY\nKTHXBYE'),
       ('mauvais nb arguments','HAI\nHOW IZ I f YR a\n\tFOUND YR a\nIF U SAY SO\nVISIBLE I IZ f YR 1 AN YR 2 MKAY\nKTHXBYE'),
       ('OBTW sans TLDR','HAI\nOBTW\njamais fini'),
       ('boucle sans IM OUTTA YR','HAI\nIM IN YR x UPPIN YR i TIL BOTH SAEM i AN 3\nVISIBLE i\nKTHXBYE'),
       ('OIC orphelin','HAI\nOIC\nKTHXBYE'),
       ('type inconnu','HAI\nI HAS A x ITZ A TRUC\nKTHXBYE'),
       ('BUKKIT non pris en charge','HAI\nI HAS A o ITZ A BUKKIT\nKTHXBYE'),
       ('modulo par zero','HAI\nVISIBLE MOD OF 5 AN 0\nKTHXBYE')]
detectes = 0
for titre, code in cas:
    m = E.Lolcode(code); r = m.executer(limite=2000)
    msgs = [d['message'] for d in r['diagnostics'] if d['severity']=='error']
    if msgs: detectes += 1
    print('  %-30s etat=%-7s %s' % (titre, r['state'], (msgs[:1] or ['AUCUN'])[0][:72]))
print()
print('%d/%d executions conformes ; %d/%d erreurs detectees' % (total, n, detectes, len(cas)))
