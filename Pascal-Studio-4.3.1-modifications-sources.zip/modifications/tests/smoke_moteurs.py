# -*- coding: utf-8 -*-
"""Tests de fumée des moteurs Brainfuck, FRACTRAN, Whitespace, Malbolge, ArnoldC.

LOLCODE et Chef ont leur propre fichier (smoke_lolcode.py, smoke_chef.py).
Chaque assertion s'appuie sur un résultat publié ou dérivable, jamais sur une
sortie observée puis recopiée : c'est ce qui fait la valeur de ces tests.

Lancer :  python3 tests/smoke_moteurs.py
"""
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import langages_esoteriques as E   # noqa: E402

CONFORMES = 0
TOTAL = 0


def verifier(titre, obtenu, attendu):
    global CONFORMES, TOTAL
    TOTAL += 1
    ok = obtenu == attendu
    if ok:
        CONFORMES += 1
    print('  %-48s %s' % (titre, 'CONFORME' if ok else 'DIFFERENT'))
    if not ok:
        print('      obtenu  : %r' % (obtenu,))
        print('      attendu : %r' % (attendu,))


# ---------------------------------------------------------------- Brainfuck
print('=== BRAINFUCK ===')
HELLO_BF = ('++++++++[>++++[>++>+++>+++>+<<<<-]>+>+>->>+[<]<-]'
            '>>.>---.+++++++..+++.>>.<-.<.+++.------.--------.>>+.>++.')
verifier('Hello World! canonique',
         E.Brainfuck(HELLO_BF).executer(limite=200000)['sortie'],
         'Hello World!\n')
verifier('cat : ,[.,] avec « bonjour »',
         E.Brainfuck(',[.,]', entree='bonjour').executer(limite=20000)['sortie'],
         'bonjour')
verifier('pas exécutés pour Hello World! (publié : 906)',
         E.Brainfuck(HELLO_BF).executer(limite=200000)['pas'], 906)
r = E.Brainfuck('++[>+++').executer(limite=1000)
verifier('[ non refermé détecté', r['state'], 'error')
r = E.Brainfuck('+++]').executer(limite=1000)
verifier('] orphelin détecté', r['state'], 'error')

# ----------------------------------------------------------------- FRACTRAN
print()
print('=== FRACTRAN (PRIMEGAME de Conway) ===')
# Une fraction par ligne : c'est la syntaxe acceptée par le moteur.
PRIMEGAME = '\n'.join(['n = 2'] + [
    '17/91', '78/85', '19/51', '23/38', '29/33', '77/29', '95/23',
    '77/19', '1/17', '11/13', '13/11', '15/14', '15/2', '55/1'])


def puissances_de_deux(code, limite):
    """Relance pas à pas et récolte les exposants des puissances de 2 vues."""
    m = E.Fractran(code)
    erreurs = m.charger()          # sans cela m.etat reste None et pas() abandonne
    assert not [d for d in erreurs if d['severity'] == 'error'], erreurs
    vus = []
    while not m.termine and m.pas_fait < limite:
        if not m.pas():
            break
        n = m.etat
        if n and n > 1 and (n & (n - 1)) == 0:
            exposant = n.bit_length() - 1
            if not vus or vus[-1] != exposant:
                vus.append(exposant)
    return vus


def _premiers(n):
    suite, candidat = [], 2
    while len(suite) < n:
        if all(candidat % p for p in suite if p * p <= candidat):
            suite.append(candidat)
        candidat += 1
    return suite


_obtenus = puissances_de_deux(PRIMEGAME, 200000)
verifier('PRIMEGAME engendre bien la suite des nombres premiers',
         _obtenus, _premiers(len(_obtenus)))
verifier('au moins 12 nombres premiers produits (publié)',
         len(_obtenus) >= 12, True)
verifier('aucune fraction -> erreur',
         E.Fractran('n = 2').executer(limite=100)['state'], 'error')
verifier('dénominateur nul détecté',
         E.Fractran('n = 2\n3/0').executer(limite=100)['state'], 'error')

# --------------------------------------------------------------- Whitespace
print()
print('=== WHITESPACE ===')
ESP, TAB, LF = ' ', '\t', '\n'


def encoder(lignes):
    """Assembleur mnémonique -> Space/Tab/LF, comme dans la spécification."""
    sortie = []
    for element in lignes:
        opcode, reste = (element, '') if isinstance(element, str) \
            else (element[0], element[1:])
        if opcode == 'push':
            n = reste[0]
            signe = ESP if n >= 0 else TAB
            binaire = format(abs(n), 'b')
            corps = ''.join(TAB if c == '1' else ESP for c in binaire)
            sortie.append(ESP + ESP + signe + corps + LF)
        elif opcode == 'out':
            sortie.append(TAB + LF + ESP + ESP)
        elif opcode == 'end':
            sortie.append(LF + LF + LF)
        elif opcode == 'add':
            # L'IMP arithmétique EST « Tab + Espace » (2 caractères), suivi de la
            # commande sur 2 caractères. Il n'y a PAS d'IMP de pile en préfixe :
            # c'est le tableau des IMP de la spécification qui le dit.
            sortie.append(TAB + ESP + ESP + ESP)
        elif opcode == 'sub':
            sortie.append(TAB + ESP + ESP + TAB)
        elif opcode == 'label':
            sortie.append(LF + ESP + ESP +
                          ''.join(TAB if c == '1' else ESP
                                  for c in format(reste[0], 'b')) + LF)
        elif opcode == 'jmp':
            sortie.append(LF + TAB + ESP +
                          ''.join(TAB if c == '1' else ESP
                                  for c in format(reste[0], 'b')) + LF)
    return ''.join(sortie)


# « out » (Tab LF Space Space) imprime un CARACTÈRE, pas un nombre décimal :
# 12+7=19 donne chr(19). On vérifie donc 65 -> « A » et 12+7 -> chr(19).
verifier('push 65 puis out -> « A »',
         E.Whitespace(encoder([('push', 65), 'out', 'end'])).executer(
             limite=1000)['sortie'], 'A')
verifier('12 + 7 = 19 -> chr(19)',
         E.Whitespace(encoder([('push', 12), ('push', 7), 'add', 'out',
                               'end'])).executer(limite=1000)['sortie'], chr(19))
# Le premier élément poussé est l'opérande de GAUCHE : 20 - 8 = 12, pas -12.
verifier('le premier poussé est l’opérande de gauche (20-8=12)',
         E.Whitespace(encoder([('push', 20), ('push', 8), 'sub', 'out',
                               'end'])).executer(limite=1000)['sortie'], chr(12))
# Du bruit non blanc entre les instructions doit être ignoré.
propre = encoder([('push', 66), 'out', 'end'])
bruissant = 'x'.join(list(propre))
verifier('caractères non blancs ignorés entre les instructions',
         E.Whitespace(bruissant).executer(limite=1000)['sortie'], 'B')
verifier('programme vide -> avertissement',
         any(d['severity'] == 'warning'
             for d in E.Whitespace('').charger()), True)

# ----------------------------------------------------------------- Malbolge
print()
print('=== MALBOLGE ===')
verifier('table originale = chr(33)..chr(126)',
         E.MALBOLGE_ORIGINE, ''.join(chr(i) for i in range(33, 127)))
verifier('les deux tables font 94 caractères',
         (len(E.MALBOLGE_ORIGINE), len(E.MALBOLGE_TRADUCTION)), (94, 94))
verifier('chiffrement de « ! » donne « 5 » (exemple de la spec)',
         E.MALBOLGE_TRADUCTION[0], '5')
verifier('crazy(A=0,[D]=40)=29524 (trace publiée)', E.crazy(0, 40), 29524)
verifier('crazy(A=29524,[D]=75)=72=« H » (trace publiée)',
         E.crazy(29524, 75), 72)
verifier('rotation droite : 0002111112 -> 2000211111 (exemple de la spec)',
         E.Malbolge._en_base3(E.rotation_droite(int('0002111112', 3))),
         '2000211111')
CHAT = '(=BA#9"=<;:3y7x54-21q/p-,+*)"!h%B0/.~P< <:(8&66#"!~}|{zyxwvugJ%'
_m = E.Malbolge(CHAT)
_erreurs = _m.charger()
verifier('« cat » de la spec : aucun diagnostic au chargement', _erreurs, [])
verifier('« cat » de la spec : les 62 opérations décodées',
         ''.join(E.MALBOLGE_LETTRES.get((ord(c) + i) % 94, '?')
                 for i, (_x, c) in enumerate(_m._programme)),
         'jpoo*pjoooop*ojoopoo*ojoooooppjoivvvo/i<ivivi<vvvvvvvvvvvvvoji')
r = E.Malbolge(CHAT, entree='abc').executer(limite=20000)
verifier('« cat » recopie l’entrée puis émet chr(168) en fin d’entrée',
         r['sortie'][:5], 'abc' + chr(168) * 2)

# ------------------------------------------------------------------ ArnoldC
print()
print('=== ARNOLDC ===')
verifier('Hello, world! de la spécification',
         E.ArnoldC('IT\'S SHOWTIME\n  TALK TO THE HAND "Hello, world!"\n'
                   'YOU HAVE BEEN TERMINATED').executer(limite=1000)['sortie'],
         'Hello, world!')
verifier('@NO PROBLEMO vaut 1 et @I LIED vaut 0',
         E.ArnoldC('IT\'S SHOWTIME\nHEY CHRISTMAS TREE a\nYOU SET US UP '
                   '@NO PROBLEMO\nHEY CHRISTMAS TREE b\nYOU SET US UP @I LIED\n'
                   'TALK TO THE HAND a\nTALK TO THE HAND b\n'
                   'YOU HAVE BEEN TERMINATED').executer(limite=1000)['sortie'],
         '10')
verifier('arithmétique en bloc : (10+3)*2 = 26',
         E.ArnoldC('IT\'S SHOWTIME\nHEY CHRISTMAS TREE a\nYOU SET US UP 10\n'
                   'GET TO THE CHOPPER a\nHERE IS MY INVITATION a\nGET UP 3\n'
                   'YOU\'RE FIRED 2\nENOUGH TALK\nTALK TO THE HAND a\n'
                   'YOU HAVE BEEN TERMINATED').executer(limite=1000)['sortie'],
         '26')
verifier('méthode à valeur de retour : double(21) = 42',
         E.ArnoldC('IT\'S SHOWTIME\nHEY CHRISTMAS TREE r\nYOU SET US UP 0\n'
                   'GET YOUR ASS TO MARS r double 21\nTALK TO THE HAND r\n'
                   'YOU HAVE BEEN TERMINATED\n'
                   'GIVE THESE PEOPLE AIR double\n'
                   'I NEED YOUR CLOTHES YOUR BOOTS AND YOUR MOTORCYCLE x\n'
                   'HEY CHRISTMAS TREE y\nYOU SET US UP 0\n'
                   'GET TO THE CHOPPER y\nHERE IS MY INVITATION x\nGET UP x\n'
                   'ENOUGH TALK\nI\'LL BE BACK y\n'
                   'HASTA LA VISTA, BABY').executer(limite=1000)['sortie'],
         '42')
verifier('variable non déclarée détectée',
         E.ArnoldC('IT\'S SHOWTIME\nTALK TO THE HAND zzz\n'
                   'YOU HAVE BEEN TERMINATED').executer(limite=1000)['state'],
         'error')

print()
print('%d/%d vérifications conformes' % (CONFORMES, TOTAL))
sys.exit(0 if CONFORMES == TOTAL else 1)
