/* Banc du panneau navigateur intégré (4.0.0).
 *
 * Ce banc exécute réellement navigateur-studio.js dans le harnais DOM partagé,
 * dans TROIS scénarios, parce que le panneau a trois états d'indisponibilité
 * distincts et qu'un seul d'entre eux est silencieux :
 *
 *   A. hors application de bureau  -> la balise <webview> n'existe pas ;
 *   B. application Electron SANS webviewTag -> la balise existe et ne fait
 *      RIEN, sans erreur nulle part. C'est le cas dangereux : sans ce banc, un
 *      correctif oublié se traduirait par un panneau blanc chez l'utilisateur
 *      et par aucun signal pendant la construction. Le banc vérifie que le
 *      panneau NOMME ce qui manque (webviewTag, patch_desktop_navigateur.py).
 *   C. webview opérationnel -> tout le panneau est exercé.
 *
 * Le scénario B est le seul qui justifie à lui seul l'existence de ce banc :
 * un test qui ne couvre que le cas fonctionnel ne protège rien contre l'oubli
 * le plus probable.
 *
 * Lancer :  node tests/smoke_navigateur.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'navigateur-studio.js');
const source = fs.readFileSync(SCRIPT, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  else {
    echecs.push(titre + '\n      obtenu  : ' + JSON.stringify(obtenu).slice(0, 240)
      + '\n      attendu : ' + JSON.stringify(attendu).slice(0, 240));
  }
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }
function texte(noeud) { return noeud ? noeud.textContent : ''; }

/* ------------------------------------------------- élément <webview> ----- */
function creerWebview(operationnel) {
  const w = new H.Noeud('webview');
  if (!operationnel) return w;          // Electron sans webviewTag : inerte
  w.__src = '';
  w.__url = 'about:blank';
  w.__zoom = 1;
  w.__devtools = false;
  w.__appels = [];
  w.__arriere = false;
  w.__avant = false;
  w.loadURL = u => { w.__appels.push(['loadURL', u]); w.__url = u; return Promise.resolve(); };
  w.getURL = () => w.__url;
  w.getTitle = () => 'titre';
  w.canGoBack = () => w.__arriere;
  w.canGoForward = () => w.__avant;
  w.goBack = () => w.__appels.push(['goBack']);
  w.goForward = () => w.__appels.push(['goForward']);
  w.reload = () => w.__appels.push(['reload']);
  w.reloadIgnoringCache = () => w.__appels.push(['reloadIgnoringCache']);
  w.stop = () => w.__appels.push(['stop']);
  w.getZoomFactor = () => w.__zoom;
  w.setZoomFactor = z => { w.__zoom = z; w.__appels.push(['setZoomFactor', z]); };
  w.findInPage = (t, o) => w.__appels.push(['findInPage', t, o]);
  w.stopFindInPage = a => w.__appels.push(['stopFindInPage', a]);
  w.openDevTools = o => { w.__devtools = true; w.__appels.push(['openDevTools', o]); };
  w.closeDevTools = () => { w.__devtools = false; w.__appels.push(['closeDevTools']); };
  w.isDevToolsOpened = () => w.__devtools;
  const poser = w.setAttribute.bind(w);
  w.setAttribute = (k, v) => { if (k === 'src') { w.__src = v; w.__url = v; } poser(k, v); };
  return w;
}

/* ------------------------------------------------------------ scénario ---- */
function monter(opts) {
  H.reinitialiserObservateurs();
  const ctx = H.creerDocument();
  const barre = new H.Noeud('div');
  barre.className = 'activitybar';
  ctx.body.append(barre);
  ctx.rafraichir();

  const appels = [];
  let etatServeur = {
    historique: [{ url: 'https://exemple.fr/a', titre: 'Page A', visites: 3, vu: 1700000000 }],
    signets: [{ url: 'https://doc.fr', titre: 'Documentation', groupe: 'docs', ajoute: 1700000000 }],
    onglets: [],
    geometrie: { x: 40, y: 50, largeur: 900, hauteur: 600, plein: false },
    capacites: { persistant: opts.persistant !== false, chemin: '/x/navigateur.json',
      max_historique: 500, max_signets: 500, max_onglets: 24, chiffre: false },
    version: 1,
  };

  function fetchStub(url, o) {
    const u = String(url);
    const methode = (o && o.method) || 'GET';
    let corps = null;
    try { corps = o && o.body ? JSON.parse(o.body) : null; } catch (e) { corps = null; }
    appels.push({ url: u, methode, corps });
    if (u.indexOf('/api/navigateur') !== 0) {
      return Promise.resolve({ ok: false, status: 404, json: () => Promise.resolve({ error: 'inconnu' }) });
    }
    if (methode === 'GET') {
      return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(JSON.parse(JSON.stringify(etatServeur))) });
    }
    const action = corps && corps.action;
    if (action === 'visite') {
      const url2 = String(corps.url || '');
      const deja = etatServeur.historique.find(h => h.url === url2);
      if (deja) deja.visites += 1;
      else etatServeur.historique.unshift({ url: url2, titre: corps.titre || url2, visites: 1, vu: 1700000001 });
    } else if (action === 'signet') {
      etatServeur.signets = etatServeur.signets.filter(s => s.url !== corps.url);
      etatServeur.signets.unshift({ url: corps.url, titre: corps.titre || corps.url, groupe: corps.groupe || '' });
    } else if (action === 'signet-supprimer') {
      etatServeur.signets = etatServeur.signets.filter(s => s.url !== corps.url);
    } else if (action === 'historique-effacer') {
      etatServeur.historique = [];
    } else if (action === 'onglets') {
      etatServeur.onglets = (corps.onglets || []).slice();
    } else if (action === 'geometrie') {
      etatServeur.geometrie = corps.geometrie || {};
    } else if (action === 'purge') {
      etatServeur = { historique: [], signets: [], onglets: [], geometrie: {}, capacites: etatServeur.capacites, version: 1 };
    } else if (action && action !== 'lire' && action !== 'capacites') {
      return Promise.resolve({ ok: false, status: 400, json: () => Promise.resolve({ error: 'Action de navigateur inconnue : ' + action }) });
    }
    return Promise.resolve({ ok: true, status: 200, json: () => Promise.resolve(JSON.parse(JSON.stringify(etatServeur))) });
  }

  const relais = {};
  /* Le panneau déplace et redimensionne sa fenêtre en écoutant pointermove et
   * pointerup sur `window` : sans ces relais, un glisser lève au lieu de
   * déplacer, et le banc échouerait sur son propre oubli. */
  const fenetreEcouteurs = {};
  const fenetre = {
    addEventListener(type, fn) { (fenetreEcouteurs[type] = fenetreEcouteurs[type] || []).push(fn); },
    removeEventListener(type, fn) {
      const l = fenetreEcouteurs[type] || [];
      const i = l.indexOf(fn);
      if (i >= 0) l.splice(i, 1);
    },
    innerWidth: 1600, innerHeight: 1000,
    location: { origin: 'http://127.0.0.1:8765', href: 'http://127.0.0.1:8765/' },
    open: (u, cible) => { fenetre.__ouverts = (fenetre.__ouverts || []).concat([{ url: u, cible }]); return null; },
  };
  fenetre.window = fenetre;
  if (opts.bureau) {
    fenetre.pascalDesktop = {
      clipboardWrite: t => { fenetre.__presse = t; return Promise.resolve(); },
      onNavigateurPopup: cb => { relais.popup = cb; return () => { relais.popup = null; }; },
      onNavigateurDownload: cb => { relais.download = cb; return () => { relais.download = null; }; },
      onNavigateurPermission: cb => { relais.permission = cb; return () => { relais.permission = null; }; },
    };
  }

  const intervalles = [];
  const timeouts = [];
  const sandbox = {
    window: fenetre,
    document: ctx.document,
    navigator: {
      userAgent: opts.bureau ? 'Mozilla/5.0 (X11; Linux x86_64) Electron/33.4.11 PascalStudio/4.0.0'
        : 'Mozilla/5.0 (X11; Linux x86_64) Firefox/140.0',
      clipboard: { writeText: t => { fenetre.__presse = t; return Promise.resolve(); } },
    },
    fetch: fetchStub,
    console,
    setTimeout: (fn, ms) => { timeouts.push({ fn, ms }); return timeouts.length; },
    setInterval: (fn, ms) => { intervalles.push({ fn, ms }); return intervalles.length; },
    clearInterval: () => {}, clearTimeout: () => {},
    MutationObserver: H.MutationObserverStub,
    confirm: m => { fenetre.__confirmes = (fenetre.__confirmes || []).concat([String(m)]); return true; },
    alert: () => {},
    Promise, Map, Set, JSON, Math, Date, Object, Array, String, Number, Boolean, Error, RegExp,
    encodeURIComponent, decodeURIComponent, parseInt, parseFloat, isNaN,
  };
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;

  const createElement = ctx.document.createElement;
  ctx.document.createElement = tag => (String(tag).toLowerCase() === 'webview'
    ? creerWebview(opts.webview) : createElement(tag));

  vm.createContext(sandbox);
  let erreur = null;
  try { vm.runInContext(source, sandbox, { filename: 'navigateur-studio.js' }); }
  catch (e) { erreur = e; }
  ctx.rafraichir();

  function viderTimeouts() {
    /* La sonde de disponibilité attend 120 ms : le banc doit la laisser aboutir,
     * sinon il testerait un panneau encore en cours de sondage. */
    let garde = 0;
    while (timeouts.length && garde < 40) {
      const t = timeouts.shift();
      garde += 1;
      try { t.fn(); } catch (e) { /* le panneau attrape déjà ses erreurs */ }
      ctx.rafraichir();
    }
  }
  function ticks(n) {
    let p = Promise.resolve();
    for (let i = 0; i < (n || 20); i++) {
      p = p.then(() => { viderTimeouts(); ctx.rafraichir(); });
    }
    return p;
  }

  function emettreFenetre(type, champs) {
    const ev = Object.assign({ type }, champs || {});
    if (typeof ev.preventDefault !== 'function') ev.preventDefault = () => {};
    if (typeof ev.stopPropagation !== 'function') ev.stopPropagation = () => {};
    for (const fn of (fenetreEcouteurs[type] || []).slice()) fn(ev);
    ctx.rafraichir();
    return ev;
  }

  return { ctx, barre, fenetre, sandbox, appels, relais, erreur, intervalles, ticks, viderTimeouts,
    emettreFenetre, ecouteursFenetre: () => fenetreEcouteurs,
    etat: () => etatServeur };
}

/* ------------------------------------------------------------------------ */
async function scenarioA() {
  const s = monter({ bureau: false, webview: false });
  vrai('A : le script se charge hors application de bureau', s.erreur === null);
  if (s.erreur) { console.error(s.erreur.stack); return; }

  verifier('A : un seul bouton posé dans la barre d’activité',
    s.barre.querySelectorAll('.psnav-launch').length, 1);
  const avant = s.barre.querySelectorAll('.psnav-launch').length;
  if (s.intervalles.length) { s.intervalles[0].fn(); s.ctx.rafraichir(); }
  verifier('A : le rappel périodique ne duplique pas le bouton',
    s.barre.querySelectorAll('.psnav-launch').length, avant);

  s.barre.querySelector('.psnav-launch').dispatchEvent({ type: 'click' });
  await s.ticks(24);

  const panneau = s.ctx.body.querySelector('.psnav-panel');
  vrai('A : le panneau s’ouvre même sans <webview>', !!panneau);
  const zone = panneau && panneau.querySelector('.psnav-indisponible');
  vrai('A : un message d’indisponibilité est affiché, pas une zone blanche', !!zone);
  vrai('A : il nomme l’application de bureau',
    /application de bureau/.test(texte(zone)));
  vrai('A : il explique pourquoi la balise n’existe pas',
    /navigateur classique/.test(texte(zone)) && /Electron/.test(texte(zone)));
  vrai('A : il ne blame pas l’utilisateur',
    !/erreur|impossible de/i.test(texte(zone)));
  vrai('A : une alternative est proposée',
    !!zone && zone.querySelectorAll('button').some(b => /navigateur du système/.test(b.textContent)));

  const champ = zone && zone.querySelector('input');
  vrai('A : un champ d’adresse de secours existe', !!champ);
  if (champ) {
    champ.value = 'https://exemple.fr';
    const bouton = zone.querySelectorAll('button').find(b => /navigateur du système/.test(b.textContent));
    bouton.dispatchEvent({ type: 'click' });
    await s.ticks(6);
    verifier('A : l’adresse de secours est transmise au navigateur du système',
      (s.fenetre.__ouverts || []).map(o => o.url), ['https://exemple.fr']);
  }
  /* La sonde de disponibilité crée un <webview> éphémère puis le retire : ce
   * qui compte, c'est qu'aucune VUE d'onglet ne soit montée sur un élément
   * qui ne peut rien charger. */
  verifier('A : aucune vue d’onglet n’est montée hors application',
    s.ctx.document.querySelectorAll('.psnav-vue').length, 0);
  verifier('A : la sonde de disponibilité est retirée du document',
    s.ctx.document.querySelectorAll('webview').length, 0);
}

async function scenarioB() {
  const s = monter({ bureau: true, webview: false });
  vrai('B : le script se charge dans une application sans webviewTag', s.erreur === null);
  if (s.erreur) { console.error(s.erreur.stack); return; }

  s.barre.querySelector('.psnav-launch').dispatchEvent({ type: 'click' });
  await s.ticks(24);

  const panneau = s.ctx.body.querySelector('.psnav-panel');
  vrai('B : le panneau s’ouvre', !!panneau);
  const zone = panneau && panneau.querySelector('.psnav-indisponible');
  vrai('B : l’indisponibilité est affichée', !!zone);
  vrai('B : elle dit que l’application est bien Electron',
    /bien Electron/.test(texte(zone)));
  /* Le cœur du banc : le cas silencieux doit NOMMER son correctif. */
  vrai('B : elle nomme webviewTag', /webviewTag/.test(texte(zone)));
  vrai('B : elle nomme le fichier à corriger', /desktop\/main\.cjs/.test(texte(zone)));
  vrai('B : elle nomme le correctif à appliquer', /patch_desktop_navigateur\.py/.test(texte(zone)));
  vrai('B : elle explique que rien ne signale l’échec sinon',
    /muette|sans erreur/.test(texte(zone)));
  vrai('B : elle ne prétend pas que le navigateur fonctionne',
    !/prêt|chargé avec succès/.test(texte(panneau.querySelector('.psnav-status'))));
  verifier('B : aucun onglet n’est créé sur un webview inerte',
    panneau.querySelectorAll('.psnav-tab').length, 0);
}

async function scenarioC() {
  const s = monter({ bureau: true, webview: true });
  vrai('C : le script se charge', s.erreur === null);
  if (s.erreur) { console.error(s.erreur.stack); return; }

  s.barre.querySelector('.psnav-launch').dispatchEvent({ type: 'click' });
  await s.ticks(26);
  const panneau = s.ctx.body.querySelector('.psnav-panel');
  vrai('C : le panneau s’ouvre', !!panneau);
  vrai('C : aucun message d’indisponibilité', !panneau.querySelector('.psnav-indisponible'));

  /* ---- structure ---- */
  vrai('C : une barre d’onglets existe', !!panneau.querySelector('.psnav-tabs'));
  vrai('C : une barre d’outils existe', !!panneau.querySelector('.psnav-toolbar'));
  vrai('C : un champ d’adresse existe', !!panneau.querySelector('.psnav-url'));
  vrai('C : une barre d’état existe', !!panneau.querySelector('.psnav-statusbar'));
  vrai('C : une pastille de sécurité existe', !!panneau.querySelector('.psnav-securite'));
  vrai('C : la géométrie enregistrée est restaurée',
    panneau.style.width === '900px' && panneau.style.height === '600px');

  /* ---- un onglet est créé par défaut ---- */
  verifier('C : un onglet est ouvert au démarrage', panneau.querySelectorAll('.psnav-tab').length, 1);
  const vues = () => panneau.querySelectorAll('.psnav-vue');
  verifier('C : un <webview> est créé pour l’onglet', vues().length, 1);
  vrai('C : le webview utilise la partition dédiée',
    vues()[0] && vues()[0].getAttribute('partition') === 'persist:pascal-navigateur');
  vrai('C : le webview ne demande pas allowpopups',
    vues()[0] && vues()[0].getAttribute('allowpopups') === null);

  /* ---- navigation depuis le champ d'adresse ---- */
  const champ = panneau.querySelector('.psnav-url');
  champ.value = 'exemple.fr';
  champ.dispatchEvent({ type: 'keydown', key: 'Enter', preventDefault() {} });
  await s.ticks(8);
  vrai('C : un nom de domaine est complété en https://',
    vues()[0].__url === 'https://exemple.fr' || vues()[0].__src === 'https://exemple.fr');

  champ.value = 'bonjour';
  champ.dispatchEvent({ type: 'keydown', key: 'Enter', preventDefault() {} });
  await s.ticks(4);
  /* Le contrat a changé en 4.2.0 : un mot qui n’est pas une adresse part
   * chez Qwant, à la demande explicite de l’utilisateur. Ce qui était
   * vérifié avant — le refus, et l’annonce qu’aucun moteur n’était
   * branché — décrivait un comportement voulu à l’époque ; le garder ici
   * figerait l’ancien état et refuserait la nouveauté. */
  const urlMoteur = vues()[0].__url || vues()[0].__src || '';
  vrai('C : un mot sans point part chez le moteur de recherche',
    urlMoteur.indexOf('https://www.qwant.com/?q=bonjour') === 0);
  /* Le nom du moteur est lu dans les ATTRIBUTS : le harnais DOM ne sérialise
   * pas les attributs dans innerHTML, et dans un vrai navigateur c'est bien le
   * texte d'invite et l'infobulle que l'utilisateur lit. */
  vrai('C : le moteur est NOMMÉ dans l’interface, pas branché en cachette',
    /Qwant/.test(champ.placeholder || '')
      || /Qwant/.test((panneau.querySelector('.psnav-home') || {}).title || ''));

  champ.value = 'a & b # c';
  champ.dispatchEvent({ type: 'keydown', key: 'Enter', preventDefault() {} });
  await s.ticks(4);
  vrai('C : une saisie contenant « & » et « # » est encodée',
    (vues()[0].__url || vues()[0].__src || '')
      .indexOf('?q=a%20%26%20b%20%23%20c') >= 0);

  const accueil = panneau.querySelector('.psnav-home');
  vrai('C : le bouton d’accueil annonce la page du moteur',
    accueil && /qwant\.com/.test(accueil.title)
      && !/projet/i.test(accueil.title));
  accueil.dispatchEvent({ type: 'click' });
  await s.ticks(4);
  vrai('C : le bouton d’accueil mène à la page d’accueil du moteur',
    (vues()[0].__url || vues()[0].__src || '') === 'https://www.qwant.com/');
  /* 4.3.0 : l'attente précédente était « l'aperçu du projet a gardé SON PROPRE
   * bouton ». Elle est inversée VOLONTAIREMENT, sur demande explicite : deux
   * boutons maison identiques côte à côte, dont un menant à l'origine de
   * l'application (http://localhost:PORT), ne se distinguaient pas. L'aperçu du
   * projet servi par Pascal Studio garde son vrai point d'entrée — le panneau
   * dev web, qui le démarre et l'arrête — donc aucune fonctionnalité n'est
   * perdue, seulement un doublon. */
  vrai('D : le second bouton « maison » (celui du localhost) a DISPARU',
    !panneau.querySelector('.psnav-projet'));
  verifier('D : il ne reste qu’UN seul bouton d’accueil',
    panneau.querySelectorAll('.psnav-home').length, 1);
  vrai('D : aucun bouton de la barre ne mène à l’origine locale',
    !Array.prototype.slice.call(panneau.querySelectorAll('.psnav-btn'))
      .some(function (b) {
        return /localhost|127\.0\.0\.1|origine|projet servi/i.test(b.title || '');
      }));
  vrai('D : la source ne construit plus le bouton local',
    !/psnav-projet/.test(source));
  /* Supprimer un bouton sans supprimer le message qui y renvoie laisse
   * l'utilisateur chercher un bouton qui n'existe plus. Le texte est contrôlé,
   * pas seulement le DOM : ce message-là n'apparaît que dans une branche rare
   * (aucun onglet enregistré), qu'aucun clic du banc ne déclenche. */
  vrai('D : le message de session vide ne renvoie plus vers un bouton supprimé',
    source.indexOf('Utilisez le bouton') < 0);
  vrai('D : le message de session vide renvoie vers le panneau dev web',
    /panneau dev web/.test(source));

  champ.value = 'javascript:alert(1)';
  champ.dispatchEvent({ type: 'keydown', key: 'Enter', preventDefault() {} });
  await s.ticks(4);
  vrai('C : un schéma javascript: n’est jamais chargé',
    vues()[0].__url !== 'javascript:alert(1)' && vues()[0].__src !== 'javascript:alert(1)');

  champ.value = 'http://127.0.0.1:8765/';
  champ.dispatchEvent({ type: 'keydown', key: 'Enter', preventDefault() {} });
  await s.ticks(6);

  /* ---- pastille de sécurité ---- */
  const sec = () => panneau.querySelector('.psnav-securite');
  vrai('C : une adresse locale non chiffrée est signalée comme locale',
    /local/.test(texte(sec())) && /non chiffré/.test(texte(sec())));
  const vue = vues()[0];
  vue.dispatchEvent({ type: 'did-navigate', url: 'https://exemple.fr/' });
  await s.ticks(4);
  vrai('C : une adresse https est annoncée chiffrée', /chiffrée/.test(texte(sec())));
  vue.dispatchEvent({ type: 'did-navigate', url: 'http://exemple.fr/' });
  await s.ticks(4);
  vrai('C : une adresse http est annoncée NON chiffrée', /NON chiffré/.test(texte(sec())));
  vrai('C : l’avertissement explique ce que ça change', /lisible/.test(texte(sec())));

  /* ---- échec de chargement : la raison doit être donnée ---- */
  vue.dispatchEvent({ type: 'did-fail-load', errorCode: -105,
    errorDescription: 'ERR_NAME_NOT_RESOLVED', validatedURL: 'https://inconnu.invalid/' });
  await s.ticks(4);
  const statutEl = panneau.querySelector('.psnav-status');
  vrai('C : un échec de chargement donne le code et la raison',
    /-105/.test(texte(statutEl)) && /ERR_NAME_NOT_RESOLVED/.test(texte(statutEl)));
  vrai('C : un échec de chargement donne l’URL en cause',
    /inconnu\.invalid/.test(texte(statutEl)));
  /* -3 = ERR_ABORTED, interruption normale : ne doit pas alarmer */
  vue.dispatchEvent({ type: 'did-fail-load', errorCode: -3, errorDescription: 'ERR_ABORTED',
    validatedURL: 'https://exemple.fr/' });
  await s.ticks(4);
  vrai('C : une navigation interrompue (-3) n’est pas annoncée comme une erreur',
    !/-3/.test(texte(statutEl)));

  /* ---- titre d'onglet ---- */
  vue.dispatchEvent({ type: 'page-title-updated', title: 'Ma page' });
  await s.ticks(4);
  vrai('C : le titre de la page remplace l’URL dans l’onglet',
    /Ma page/.test(texte(panneau.querySelector('.psnav-tab'))));

  /* ---- zoom ---- */
  const zoomAvant = texte(panneau.querySelector('.psnav-zoom-val'));
  const plus = panneau.querySelectorAll('.psnav-zoom button')[1];
  plus.dispatchEvent({ type: 'click' });
  await s.ticks(4);
  vrai('C : le zoom est appliqué au webview', vue.__zoom > 1);
  vrai('C : le zoom affiché change', texte(panneau.querySelector('.psnav-zoom-val')) !== zoomAvant);

  /* ---- recherche dans la page ---- */
  panneau.querySelectorAll('.psnav-toolbar button').find(b => /Chercher dans la page/.test(b.title))
    .dispatchEvent({ type: 'click' });
  await s.ticks(4);
  const find = panneau.querySelector('.psnav-find');
  vrai('C : la barre de recherche s’affiche', find && !find.classList.contains('cachee'));
  const findInput = find.querySelector('input');
  findInput.value = 'motif';
  findInput.dispatchEvent({ type: 'input' });
  await s.ticks(4);
  vrai('C : findInPage est appelé avec le motif',
    vue.__appels.some(a => a[0] === 'findInPage' && a[1] === 'motif'));
  findInput.value = '';
  findInput.dispatchEvent({ type: 'input' });
  await s.ticks(4);
  vrai('C : vider le champ arrête la recherche',
    vue.__appels.some(a => a[0] === 'stopFindInPage'));

  /* ---- menu : outils de développement ---- */
  panneau.querySelectorAll('.psnav-toolbar button')
    .find(b => /Outils du navigateur/.test(b.title)).dispatchEvent({ type: 'click' });
  await s.ticks(4);
  const menu = s.ctx.body.querySelector('.psnav-menu');
  vrai('C : le menu s’ouvre', !!menu);
  vrai('C : le menu dit que les outils inspectent la page, pas l’interface',
    /PAGE/.test(texte(menu)) || /page/.test(texte(menu)));
  vrai('C : le menu annonce l’isolement du contenu tiers',
    /partition séparée/.test(texte(menu)) && / Node/.test(texte(menu)));
  const devtools = menu.querySelectorAll('.psnav-menu-item').find(b => /Outils de développement/.test(b.textContent));
  devtools.dispatchEvent({ type: 'click' });
  await s.ticks(4);
  vrai('C : openDevTools est appelé en fenêtre séparée',
    vue.__appels.some(a => a[0] === 'openDevTools' && a[1] && a[1].mode === 'detach'));

  /* ---- signets ---- */
  panneau.querySelector('.psnav-toolbar .psnav-favori').dispatchEvent({ type: 'click' });
  await s.ticks(6);
  vrai('C : l’étoile enregistre un signet côté serveur',
    s.appels.some(a => a.corps && a.corps.action === 'signet'));
  vrai('C : le signet porte l’URL courante',
    s.etat().signets.some(x => x.url === 'http://exemple.fr/'));

  /* ---- tiroirs ---- */
  panneau.querySelectorAll('.psnav-toolbar button')
    .find(b => /Outils du navigateur/.test(b.title)).dispatchEvent({ type: 'click' });
  await s.ticks(3);
  s.ctx.body.querySelector('.psnav-menu').querySelectorAll('.psnav-menu-item')
    .find(b => /^Historique$/.test(b.textContent)).dispatchEvent({ type: 'click' });
  await s.ticks(4);
  const tiroir = panneau.querySelector('.psnav-drawer');
  vrai('C : le tiroir historique s’affiche', tiroir && !tiroir.classList.contains('cachee'));
  vrai('C : l’historique du serveur est rendu', /exemple\.fr\/a/.test(texte(tiroir)));
  vrai('C : le nombre de visites est affiché', /3×/.test(texte(tiroir)));

  /* ---- relais du processus principal ---- */
  vrai('C : les trois relais sont branchés',
    typeof s.relais.popup === 'function' && typeof s.relais.download === 'function'
    && typeof s.relais.permission === 'function');
  s.relais.popup('https://popup.exemple.fr/');
  await s.ticks(6);
  vrai('C : un popup bloqué ouvre un onglet',
    panneau.querySelectorAll('.psnav-tab').length >= 2);
  vrai('C : un popup bloqué est signalé comme bloqué',
    /popup bloquée/.test(texte(panneau.querySelector('.psnav-status'))));
  s.relais.permission({ permission: 'geolocation', accordee: false });
  await s.ticks(4);
  vrai('C : une permission refusée est nommée',
    /geolocation/.test(texte(panneau.querySelector('.psnav-status'))));
  s.relais.download({ nom: 'rapport.pdf', chemin: '/tmp/rapport.pdf', state: 'completed' });
  await s.ticks(4);
  vrai('C : un téléchargement terminé donne son chemin',
    /rapport\.pdf/.test(texte(panneau.querySelector('.psnav-status'))));

  /* ---- onglets : création, bascule, fermeture ---- */
  panneau.querySelector('.psnav-tab-new').dispatchEvent({ type: 'click' });
  await s.ticks(6);
  const nbOnglets = panneau.querySelectorAll('.psnav-tab').length;
  vrai('C : un nouvel onglet est créé', nbOnglets >= 3);
  verifier('C : les vues inactives restent attachées (pas de rechargement)',
    panneau.querySelectorAll('.psnav-vue').length, nbOnglets);
  const premier = panneau.querySelectorAll('.psnav-tab')[0];
  premier.dispatchEvent({ type: 'click' });
  await s.ticks(4);
  /* La barre d'onglets est RECONSTRUITE à chaque activation : le nœud cliqué
   * est donc détaché, et tester sa classe reviendrait à lire un rendu périmé.
   * Il faut re-interroger le document. */
  vrai('C : l’onglet cliqué devient actif',
    panneau.querySelectorAll('.psnav-tab')[0].classList.contains('active'));
  verifier('C : une seule vue reste visible',
    panneau.querySelectorAll('.psnav-vue:not(.cachee)').length, 1);
  verifier('C : les autres vues sont masquées, pas supprimées',
    panneau.querySelectorAll('.psnav-vue.cachee').length, nbOnglets - 1);
  premier.querySelector('.psnav-tab-x').dispatchEvent({ type: 'click' });
  await s.ticks(4);
  verifier('C : fermer un onglet retire sa vue',
    panneau.querySelectorAll('.psnav-tab').length, nbOnglets - 1);

  /* ---- persistance ---- */
  vrai('C : les onglets sont persistés côté serveur',
    s.appels.some(a => a.corps && a.corps.action === 'onglets'));
  vrai('C : une visite est persistée côté serveur',
    s.appels.some(a => a.corps && a.corps.action === 'visite'));

  /* ---- déplacement : la géométrie doit être persistée ---- */
  const poignee = panneau.querySelector('.psnav-titlebar');
  panneau.style.left = '40px';
  panneau.style.top = '50px';
  poignee.dispatchEvent({ type: 'pointerdown', clientX: 100, clientY: 100 });
  await s.ticks(2);
  s.emettreFenetre('pointermove', { clientX: 160, clientY: 130 });
  await s.ticks(2);
  /* Le déplacement est RELATIF : 40 + (160-100) = 100 en x, 50 + (130-100) = 80
   * en y. Attendre la coordonnée absolue du pointeur serait une autre politique,
   * et celle-ci ne saute pas quand on saisit la barre loin de son coin. */
  vrai('C : glisser la barre de titre déplace le panneau',
    panneau.style.left === '100px' && panneau.style.top === '80px');
  s.emettreFenetre('pointerup', {});
  await s.ticks(2);
  vrai('C : relâcher retire les écouteurs de déplacement',
    (s.ecouteursFenetre().pointermove || []).length === 0);
  /* Un clic sur un bouton de la barre de titre ne doit PAS lancer un glisser. */
  const boutonTitre = poignee.querySelectorAll('button')[0];
  poignee.dispatchEvent({ type: 'pointerdown', clientX: 5, clientY: 5, target: boutonTitre });
  await s.ticks(2);
  verifier('C : cliquer un bouton du titre ne lance pas un glisser',
    (s.ecouteursFenetre().pointermove || []).length, 0);

  /* Redimensionnement par le bord droit. */
  const poigneeEst = panneau.querySelectorAll('.psnav-resize').find(p => p.getAttribute('data-cote') === 'e');
  vrai('C : une poignée de redimensionnement existe', !!poigneeEst);
  poigneeEst.dispatchEvent({ type: 'pointerdown', clientX: 900, clientY: 300 });
  await s.ticks(2);
  s.emettreFenetre('pointermove', { clientX: 1000, clientY: 300 });
  s.emettreFenetre('pointerup', {});
  await s.ticks(2);
  vrai('C : le bord droit élargit le panneau',
    parseFloat(panneau.style.width) > 900);
  vrai('C : la géométrie est persistée côté serveur',
    s.appels.some(a => a.corps && a.corps.action === 'geometrie'));

  /* ---- fermeture : les relais sont retirés ---- */
  panneau.querySelector('.psnav-titlebar').querySelectorAll('button')
    .find(b => /Fermer le panneau/.test(b.title)).dispatchEvent({ type: 'click' });
  await s.ticks(4);
  verifier('C : le panneau est retiré du document',
    s.ctx.body.querySelectorAll('.psnav-panel').length, 0);
  vrai('C : les relais sont débranchés à la fermeture',
    s.relais.popup === null && s.relais.download === null && s.relais.permission === null);
  vrai('C : les onglets sont enregistrés avant de fermer',
    s.appels.some(a => a.corps && a.corps.action === 'onglets'));

  /* ---- réouverture : les onglets reviennent ---- */
  s.barre.querySelector('.psnav-launch').dispatchEvent({ type: 'click' });
  await s.ticks(26);
  const panneau2 = s.ctx.body.querySelector('.psnav-panel');
  vrai('C : le panneau se rouvre', !!panneau2);
  vrai('C : les onglets enregistrés sont retrouvés',
    panneau2.querySelectorAll('.psnav-tab').length >= 1);
}

async function scenarioD() {
  /* Persistance désactivée : le panneau doit le dire, pas le taire. */
  const s = monter({ bureau: true, webview: true, persistant: false });
  s.barre.querySelector('.psnav-launch').dispatchEvent({ type: 'click' });
  await s.ticks(26);
  const panneau = s.ctx.body.querySelector('.psnav-panel');
  vrai('D : le panneau s’ouvre sans persistance', !!panneau && !panneau.querySelector('.psnav-indisponible'));
  vrai('D : la perte de l’historique au prochain lancement est annoncée',
    /PS_NAVIGATEUR_PERSIST/.test(texte(panneau.querySelector('.psnav-status')))
    || /ne survivront pas/.test(texte(panneau.querySelector('.psnav-status'))));
}

async function main() {
  await scenarioA();
  await scenarioB();
  await scenarioC();
  await scenarioD();
  console.log('smoke_navigateur.js : ' + OK + ' / ' + N + ' contrôles OK');
  if (echecs.length) {
    console.log('\nÉCHECS (' + echecs.length + ') :');
    for (const e of echecs) console.log('  - ' + e);
  }
  process.exit(echecs.length ? 1 : 0);
}

main().catch(e => {
  console.error('Le banc a levé : ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
