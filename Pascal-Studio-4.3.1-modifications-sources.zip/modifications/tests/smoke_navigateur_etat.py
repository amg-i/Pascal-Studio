#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de l'état du panneau navigateur : module ET routes (4.0.0).

Deux niveaux, parce qu'ils ne protègent pas la même chose :

  1. `navigateur_etat` appelé directement — les bornes, la politique de schémas,
     la dégradation sur fichier corrompu, les droits du fichier écrit.
  2. Les routes `/api/navigateur` servies par le VRAI server.py — ce que
     l'interface appelle réellement, y compris les gardes d'origine.

Le contrôle le plus important est le premier du niveau 2 : chaque action de la
route doit correspondre à une fonction du module avec la BONNE ARITÉ. Un
dispatch générique passerait un argument à historique_effacer() qui n'en prend
aucun, et l'échec n'apparaîtrait que le jour où l'utilisateur clique sur
« Effacer l'historique ».

Lancer :  python3 tests/smoke_navigateur_etat.py
"""

import io
import json
import os
import shutil
import sys
import tempfile

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
sys.path.insert(0, MODIFICATIONS)
sys.path.insert(0, ICI)

OK = 0
ECHECS = 0


def verif(condition, titre):
    global OK, ECHECS
    if condition:
        OK += 1
    else:
        ECHECS += 1
        print('  ECHEC : %s' % titre)


def egal(titre, obtenu, attendu):
    if obtenu == attendu:
        verif(True, titre)
    else:
        verif(False, '%s\n        obtenu  : %r\n        attendu : %r'
              % (titre, obtenu, attendu))


def module_tests():
    """Le module dans un répertoire de configuration isolé."""
    dossier = tempfile.mkdtemp(prefix='ps-nav-etat-')
    precedent = os.environ.get('PS_NAVIGATEUR_DIR')
    os.environ['PS_NAVIGATEUR_DIR'] = dossier
    import importlib
    import navigateur_etat
    importlib.reload(navigateur_etat)
    navigateur_etat._cache = None
    try:
        print('-- Capacité et chemin')
        capacites = navigateur_etat.capacites()
        verif(capacites['persistant'] is True, 'la persistance est active par défaut')
        verif(capacites['chiffre'] is False,
              'le module ne prétend pas chiffrer ce qu’il ne chiffre pas')
        verif(os.path.dirname(capacites['chemin']).endswith('pascal-studio'),
              'l’état va dans le répertoire de configuration de l’application')

        print('-- Visites')
        navigateur_etat.visiter('https://a.fr/1', 'Page 1')
        navigateur_etat.visiter('https://a.fr/2', 'Page 2')
        navigateur_etat.visiter('https://a.fr/1', 'Page 1 revue')
        historique = navigateur_etat.lire()['historique']
        egal('une URL revisitée ne fait pas deux entrées', len(historique), 2)
        egal('l’entrée revisitée est remontée en tête', historique[0]['url'], 'https://a.fr/1')
        egal('le nombre de visites est cumulé', historique[0]['visites'], 2)
        egal('le titre le plus récent est conservé', historique[0]['titre'], 'Page 1 revue')
        verif(historique[1]['visites'] == 1, 'une URL vue une fois compte 1')

        print('-- Politique de schémas (identique à celle du correctif Electron)')
        for url, attendu in (('https://ok.fr', True), ('http://ok.fr', True),
                             ('about:blank', True), ('HTTP://MAJUSCULE.FR', True),
                             ('file:///etc/passwd', False), ('data:text/html,x', False),
                             ('javascript:alert(1)', False), ('ftp://x', False),
                             ('chrome://settings', False), ('', False)):
            navigateur_etat.onglets_enregistrer([{'url': url}])
            obtenu = bool(navigateur_etat.lire()['onglets'])
            egal('schéma %r -> %s' % (url, 'accepté' if attendu else 'refusé'),
                 obtenu, attendu)

        print('-- Bornes')
        # Une URL trop longue est REFUSÉE, pas tronquée : tronquer produirait
        # une autre adresse, et le signet ouvrirait autre chose que ce qui a
        # été enregistré.
        avant = len(navigateur_etat.lire()['historique'])
        navigateur_etat.visiter('https://' + 'x' * 9000, 'titre')
        egal('une URL au-delà de MAX_URL est refusée',
             len(navigateur_etat.lire()['historique']), avant)
        navigateur_etat.visiter('https://ok.fr/t', 't' * 900)
        visite = [v for v in navigateur_etat.lire()['historique']
                  if v['url'] == 'https://ok.fr/t'][0]
        egal('un titre trop long est raccourci (il ne sert qu’à l’affichage)',
             len(visite['titre']), navigateur_etat.MAX_TITRE)
        navigateur_etat.onglets_enregistrer([{'url': 'https://n%d.fr' % i}
                                             for i in range(navigateur_etat.MAX_ONGLETS + 40)])
        egal('le nombre d’onglets est plafonné',
             len(navigateur_etat.lire()['onglets']), navigateur_etat.MAX_ONGLETS)
        for i in range(navigateur_etat.MAX_HISTORIQUE + 30):
            navigateur_etat.visiter('https://h%d.fr' % i, 'H%d' % i)
        egal('l’historique est plafonné',
             len(navigateur_etat.lire()['historique']), navigateur_etat.MAX_HISTORIQUE)

        print('-- Signets')
        navigateur_etat.signet_ajouter('https://doc.fr', 'Doc', 'docs')
        navigateur_etat.signet_ajouter('https://doc.fr', 'Doc renommée', 'docs')
        signets = navigateur_etat.lire()['signets']
        egal('un signet existe une seule fois par URL', len(signets), 1)
        egal('le dernier titre l’emporte', signets[0]['titre'], 'Doc renommée')
        egal('le groupe est conservé', signets[0]['groupe'], 'docs')
        navigateur_etat.signet_supprimer('https://doc.fr')
        egal('un signet se retire', navigateur_etat.lire()['signets'], [])
        navigateur_etat.signet_ajouter('javascript:alert(1)', 'piège')
        egal('un signet au schéma refusé n’est pas enregistré',
             navigateur_etat.lire()['signets'], [])

        print('-- Géométrie')
        navigateur_etat.geometrie_enregistrer({'x': 40, 'y': 50, 'largeur': 900,
                                               'hauteur': 600, 'plein': True})
        egal('une géométrie valide est conservée',
             navigateur_etat.lire()['geometrie'],
             {'x': 40, 'y': 50, 'largeur': 900, 'hauteur': 600, 'plein': True})
        navigateur_etat.geometrie_enregistrer({'x': 1, 'y': 2, 'largeur': 999999,
                                               'hauteur': 600, 'plein': False})
        egal('une largeur hors bornes fait REJETER toute la géométrie',
             navigateur_etat.lire()['geometrie']['largeur'], 900)
        navigateur_etat.geometrie_enregistrer({'x': 'abc', 'y': None})
        egal('une géométrie incomplète ne remplace pas la précédente',
             navigateur_etat.lire()['geometrie']['largeur'], 900)
        navigateur_etat.geometrie_enregistrer({'x': 40, 'y': 50, 'largeur': 900,
                                               'hauteur': 600, 'plein': 'oui'})
        verif(navigateur_etat.lire()['geometrie']['plein'] is True,
              '« plein » est un booléen, pas la chaîne reçue')

        print('-- Fichier écrit')
        fichier = navigateur_etat.chemin()
        verif(fichier.is_file(), 'l’état est écrit sur le disque')
        mode = os.stat(fichier).st_mode & 0o777
        egal('le fichier n’est lisible que par son propriétaire', oct(mode), '0o600')
        verif(json.loads(io.open(fichier, encoding='utf-8').read()).get('version') == 1,
              'l’état porte une version')

        print('-- Fichier corrompu : dégrader, pas bloquer')
        io.open(fichier, 'w', encoding='utf-8').write('{ ceci n’est pas du JSON')
        navigateur_etat._cache = None
        etat = navigateur_etat.lire()
        egal('un état illisible repart à vide', etat['historique'], [])
        verif(bool(etat.get('degrade')), 'et il LE DIT plutôt que de se taire')
        verif('illisible' in etat['degrade'], 'la raison est compréhensible : %r'
              % etat.get('degrade'))

        print('-- Purge et désactivation')
        navigateur_etat.visiter('https://avant-purge.fr', 'X')
        navigateur_etat.purge()
        egal('la purge vide l’historique', navigateur_etat.lire()['historique'], [])
        verif(not navigateur_etat.chemin().is_file(), 'et supprime le fichier')

        os.environ['PS_NAVIGATEUR_PERSIST'] = '0'
        navigateur_etat._cache = None
        verif(navigateur_etat.capacites()['persistant'] is False,
              'PS_NAVIGATEUR_PERSIST=0 désactive la persistance')
        navigateur_etat.visiter('https://memoire.fr', 'M')
        egal('l’état reste utilisable en mémoire',
             [v['url'] for v in navigateur_etat.lire()['historique']],
             ['https://memoire.fr'])
        verif(not navigateur_etat.chemin().is_file(),
              'et rien n’est écrit sur le disque')
        del os.environ['PS_NAVIGATEUR_PERSIST']

        print('-- Cohérence entre le module et la route')
        # La route écrit une branche par action ; ACTIONS sert aux bancs et à la
        # documentation. Les deux doivent décrire le même jeu d'actions.
        egal('ACTIONS couvre exactement ce que la route accepte',
             sorted(navigateur_etat.ACTIONS),
             sorted(['visite', 'signet', 'signet-supprimer', 'onglets',
                     'geometrie', 'historique-effacer', 'purge']))
        for nom, fonction in navigateur_etat.ACTIONS.items():
            verif(callable(fonction), 'ACTIONS[%r] est appelable' % nom)
            # Appeler pour de vrai : « appelable » est décoratif sinon.
            try:
                if nom == 'visite':
                    fonction('https://arite.fr', 't')
                elif nom == 'signet':
                    fonction('https://arite.fr', 't', 'g')
                elif nom == 'signet-supprimer':
                    fonction('https://arite.fr')
                elif nom == 'onglets':
                    fonction([{'url': 'https://arite.fr'}])
                elif nom == 'geometrie':
                    fonction({'x': 1, 'y': 2, 'largeur': 800, 'hauteur': 600})
                else:
                    fonction()
                verif(True, 'ACTIONS[%r] s’exécute avec l’arité de la route' % nom)
            except TypeError as erreur:
                verif(False, 'ACTIONS[%r] ne s’exécute pas : %s' % (nom, erreur))
    finally:
        if precedent is None:
            os.environ.pop('PS_NAVIGATEUR_DIR', None)
        else:
            os.environ['PS_NAVIGATEUR_DIR'] = precedent
        navigateur_etat._cache = None
        shutil.rmtree(dossier, ignore_errors=True)


def routes_tests():
    """Les routes, sur le vrai serveur."""
    from serveur_de_test import ServeurDeTest
    dossier = tempfile.mkdtemp(prefix='ps-nav-routes-')
    try:
        with ServeurDeTest(variables={'PS_NAVIGATEUR_DIR': dossier}) as srv:
            client = srv.client

            statut, corps = client.get('/api/navigateur')
            egal('GET /api/navigateur répond 200', statut, 200)
            for cle in ('historique', 'signets', 'onglets', 'geometrie', 'capacites'):
                verif(cle in corps, 'GET rend la clef %r' % cle)
            verif(corps['capacites']['persistant'] is True,
                  'GET annonce que la persistance est active')

            egal('POST visite', client.post('/api/navigateur', action='visite',
                                            url='https://a.fr', titre='A')[0], 200)
            statut, corps = client.post('/api/navigateur', action='visite',
                                        url='https://a.fr', titre='A2')
            egal('une seconde visite incrémente le compteur',
                 corps['historique'][0]['visites'], 2)

            statut, corps = client.post('/api/navigateur', action='signet',
                                        url='javascript:alert(1)', titre='piège')
            egal('un signet au schéma refusé n’apparaît pas', corps['signets'], [])
            statut, corps = client.post('/api/navigateur', action='signet',
                                        url='https://b.fr', titre='B', groupe='docs')
            egal('un signet valide est enregistré',
                 [s['url'] for s in corps['signets']], ['https://b.fr'])

            statut, corps = client.post('/api/navigateur', action='onglets',
                                        onglets=[{'url': 'https://a.fr'}, {'url': 'ftp://x'}])
            egal('les onglets sont filtrés par schéma',
                 [o['url'] for o in corps['onglets']], ['https://a.fr'])

            statut, corps = client.post('/api/navigateur', action='geometrie',
                                        geometrie={'x': 5, 'y': 6, 'largeur': 1000,
                                                   'hauteur': 700, 'plein': True})
            egal('la géométrie est enregistrée', corps['geometrie']['largeur'], 1000)

            statut, corps = client.post('/api/navigateur', action='inconnue')
            egal('une action inconnue est refusée', statut, 400)
            verif('inconnue' in (corps.get('error') or ''),
                  'et le refus nomme l’action : %r' % corps.get('error'))

            statut, corps = client.post('/api/navigateur', action='historique-effacer')
            egal('l’historique s’efface', [statut, len(corps['historique'])], [200, 0])

            # Garde d'origine : un historique de navigation est une donnée
            # personnelle, la route ne doit pas répondre à un site tiers.
            statut, corps = client.post('/api/navigateur',
                                        entetes={'Origin': 'http://evil.example'},
                                        action='lire')
            egal('une origine étrangère est refusée', statut, 400)
            verif('Origine' in (corps.get('error') or ''),
                  'le refus explique l’origine : %r' % corps.get('error'))
            statut, corps = client.get('/api/navigateur',
                                       entetes={'Origin': 'http://evil.example'})
            egal('une origine étrangère est refusée aussi en lecture', statut, 400)

            statut, corps = client.post('/api/navigateur', action='purge')
            egal('la purge passe par la route', statut, 200)
            egal('la purge vide les signets', corps['signets'], [])
    finally:
        shutil.rmtree(dossier, ignore_errors=True)


def main():
    module_tests()
    routes_tests()
    print('\nBanc de l’état du navigateur : %d contrôles OK, %d échec(s)'
          % (OK, ECHECS))
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
