/* Banc de test de nouveau-fichier.js, sans navigateur.
 *
 * Un DOM minimal suffit : ce qui a changé en 3.8.0 est la LOGIQUE des onglets
 * (filtrage, sélection repérée par identifiant, bascule automatique quand le
 * nom saisi désigne un type d'un autre onglet). Ces comportements sont testables
 * sans rendu réel, et c'est ce que fait ce fichier.
 *
 * Lancer :  node tests/smoke_nouveau_fichier.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

let OK = 0;
let N = 0;
function vrai(titre, condition) { verifier(titre, !!condition, true); }

function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  console.log('  ' + titre.padEnd(58) + (bon ? 'CONFORME' : 'DIFFERENT'));
  if (!bon) {
    console.log('      obtenu  : ' + JSON.stringify(obtenu).slice(0, 140));
    console.log('      attendu : ' + JSON.stringify(attendu).slice(0, 140));
  }
}

/* ------------------------------------------------------------------ DOM --- */
class Noeud {
  constructor(tag) {
    this.tagName = String(tag).toUpperCase();
    this.children = [];
    this.attributes = {};
    this.dataset = {};
    this.style = {};
    this.className = '';
    this.textContent = '';
    this.listeners = {};
    this.type = '';
    this.title = '';
    this.tabIndex = 0;
    this.disabled = false;
    this.parent = null;
    this.value = '';
  }
  append(...enfants) {
    for (const e of enfants) { e.parent = this; this.children.push(e); }
  }
  replaceChildren(...enfants) { this.children = []; this.append(...enfants); }
  remove() {
    if (this.parent) {
      this.parent.children = this.parent.children.filter(c => c !== this);
      this.parent = null;
    }
  }
  setAttribute(nom, valeur) {
    this.attributes[nom] = String(valeur);
    if (nom.indexOf('data-') === 0) {
      const cle = nom.slice(5).replace(/-([a-z])/g, (m, c) => c.toUpperCase());
      this.dataset[cle] = String(valeur);
    }
  }
  getAttribute(nom) { return this.attributes[nom]; }
  addEventListener(type, fn) {
    (this.listeners[type] = this.listeners[type] || []).push(fn);
  }
  removeEventListener(type, fn) {
    if (this.listeners[type]) {
      this.listeners[type] = this.listeners[type].filter(f => f !== fn);
    }
  }
  dispatch(type, event) {
    const ev = event || {};
    ev.target = ev.target || this;
    ev.preventDefault = ev.preventDefault || (() => {});
    ev.stopPropagation = ev.stopPropagation || (() => {});
    (this.listeners[type] || []).slice().forEach(f => f(ev));
  }
  focus() { this._focusCompte = (this._focusCompte || 0) + 1; }
  contains(n) {
    if (n === this) return true;
    return this.children.some(c => c.contains && c.contains(n));
  }
  /* Ne gère que les sélecteurs réellement utilisés par le fichier. */
  querySelector(sel) {
    const tous = [];
    (function marche(n) { n.children.forEach(c => { tous.push(c); marche(c); }); })(this);
    for (const n of tous) {
      const m = /^([a-z]+)\[([a-z-]+)=([^\]]+)\]$/.exec(sel);
      if (m) {
        if (n.tagName === m[1].toUpperCase() &&
            (n.attributes[m[2]] || n[m[2]]) === m[3]) return n;
      } else if (sel[0] === '.' && n.className.split(' ').indexOf(sel.slice(1)) >= 0) {
        return n;
      }
    }
    return null;
  }
}

const document = {
  activeElement: null,
  body: new Noeud('body'),
  listeners: {},
  createElement: tag => new Noeud(tag),
  addEventListener(type, fn) {
    (this.listeners[type] = this.listeners[type] || []).push(fn);
  },
  removeEventListener(type, fn) {
    if (this.listeners[type]) {
      this.listeners[type] = this.listeners[type].filter(f => f !== fn);
    }
  },
  contains(n) { return this.body.contains(n); },
};

const sandbox = {
  document,
  window: {},
  Promise, Set, Array, Object, String, Number, JSON, RegExp, Math,
  console,
};
sandbox.globalThis = sandbox;

const source = fs.readFileSync(
  path.join(__dirname, '..', 'nouveau-fichier.js'), 'utf8');
vm.createContext(sandbox);
new vm.Script(source).runInContext(sandbox);
const win = sandbox.window;

/* ------------------------------------------------------------ vérifications */
console.log('=== API exposée au bundle ===');
const types = win.PSNewFileTypes;
/* Un PLANCHER, pas un compte figé : chaque nouveau type casserait le banc
 * sans rien dire de lui. L'appartenance des deux types de la 4.2.0 est
 * vérifiée juste après, par leur nom. */
vrai('PSNewFileTypes expose au moins 37 types (27 classiques + 10 ésotériques)',
     types.length >= 37);
const asm = types.find(x => x.id === 'asm');
const sansExtension = types.find(x => x.id === 'texte');
vrai('le type « Assembleur x86-64 » existe', !!asm);
vrai('le type « Texte sans extension » existe', !!sansExtension);
if (asm) {
  verifier('l’assembleur propose l’extension .asm', asm.ext, '.asm');
  vrai('le modèle d’assembleur est un programme, pas une page vide',
       /\.globl\s+main/.test(asm.modele) && /syscall/.test(asm.modele));
  vrai('le modèle d’assembleur écrit sur la sortie standard',
       /movq\s+\$1,\s*%rdi/.test(asm.modele));
}
if (sansExtension) {
  verifier('le type sans extension n’a PAS d’extension', sansExtension.ext, '');
}
verifier('PSNewFileCategories = tous, classique, esoterique',
         win.PSNewFileCategories, ['tous', 'classique', 'esoterique']);
const classiques = types.filter(t => t.categorie === 'classique');
const esoteriques = types.filter(t => t.categorie === 'esoterique');
vrai('au moins 27 types classiques (25 historiques + 2 en 4.2.0)',
     classiques.length >= 27);
verifier('10 types ésotériques', esoteriques.length, 10);
verifier('les dix langages attendus sont présents',
         esoteriques.map(t => t.id).sort(),
         ['arnoldc', 'brainfuck', 'chef', 'fractran', 'intercal', 'lolcode',
          'malbolge', 'piet', 'shakespeare', 'whitespace']);
verifier('chaque type expose un modèle', types.every(t => typeof t.modele === 'string'),
         true);

/* Rien d'historique ne doit avoir disparu : c'est la garantie demandée. */
const HISTORIQUES = ['pascal', 'swift', 'kotlin', 'python', 'c', 'cpp', 'csharp',
  'javascript', 'html', 'css', 'php', 'rust', 'go', 'ruby', 'fortran', 'perl',
  'basic', 'ocaml', 'lua', 'latex', 'markdown', 'xml', 'makefile', 'cmake',
  'plaintext'];
verifier('les 25 types historiques sont toujours là',
         HISTORIQUES.every(id => types.some(t => t.id === id)), true);
verifier('les historiques restent dans l’onglet « Classiques »',
         HISTORIQUES.every(id =>
           types.find(t => t.id === id).categorie === 'classique'), true);

console.log();
console.log('=== rendu du dialogue ===');
win.PSNewFileDialog({});                     // ouvre sans attendre la résolution
const overlay = document.body.children[0];
const form = overlay.children[0];
const parClasse = c => form.querySelector('.' + c);
const tabs = parClasse('ps-newfile-tabs');
const grid = parClasse('ps-newfile-grid');

verifier('trois onglets sont rendus', tabs.children.length, 3);
verifier('libellés des onglets',
         tabs.children.map(b => b.children[0].textContent),
         ['Tous', 'Classiques', 'Ésotériques']);
verifier('compte affiché par onglet',
         tabs.children.map(b => b.children[1].textContent).map(Number)
           .map(n => String(n)), [String(types.length),
             String(types.filter(x => x.categorie === 'classique').length),
             '10']);
verifier('rôles ARIA des onglets',
         tabs.attributes.role + '/' + tabs.children[0].getAttribute('role'),
         'tablist/tab');
verifier('l’onglet « Tous » est actif par défaut',
         tabs.children.map(b => b.getAttribute('aria-selected')),
         ['true', 'false', 'false']);
verifier('la grille contient tous les types par défaut',
         grid.children.length, types.length);

console.log();
console.log('=== filtrage par onglet ===');
tabs.children[2].dispatch('click');          // Ésotériques
verifier('onglet « Ésotériques » : 10 boutons', grid.children.length, 10);
verifier('tous appartiennent à la catégorie ésotérique',
         grid.children.map(b => b.dataset.id).sort(),
         esoteriques.map(t => t.id).sort());
verifier('aria-selected suivi sur les onglets',
         tabs.children.map(b => b.getAttribute('aria-selected')),
         ['false', 'false', 'true']);
verifier('un seul bouton de type est atteignable au clavier',
         grid.children.filter(b => b.tabIndex === 0).length, 1);

tabs.children[1].dispatch('click');          // Classiques
verifier('onglet « Classiques » : les types classiques seulement',
         grid.children.length,
         types.filter(x => x.categorie === 'classique').length);
verifier('aucun ésotérique dans « Classiques »',
         grid.children.some(b => esoteriques.some(t => t.id === b.dataset.id)),
         false);

tabs.children[0].dispatch('click');          // Tous
verifier('retour à « Tous » : tous les types', grid.children.length,
         types.length);

console.log();
console.log('=== la sélection survit au changement d’onglet ===');
/* Sélectionner un type classique, puis passer sur « Ésotériques » : la sélection
 * n'est plus visible, donc le dialogue doit en choisir une qui l'est. */
const boutonPascal = grid.children.find(b => b.dataset.id === 'pascal');
boutonPascal.dispatch('click');
verifier('Pascal sélectionné dans « Tous »',
         boutonPascal.getAttribute('aria-checked'), 'true');
tabs.children[2].dispatch('click');
verifier('après bascule, exactement une sélection visible',
         grid.children.filter(b => b.getAttribute('aria-checked') === 'true').length,
         1);
verifier('la sélection basculée est bien un type ésotérique',
         esoteriques.some(t => t.id ===
           grid.children.find(b => b.getAttribute('aria-checked') === 'true').dataset.id),
         true);

console.log();
console.log('=== le nom saisi resynchronise le type ET l’onglet ===');
tabs.children[0].dispatch('click');          // retour à « Tous »
const input = form.querySelector('input') ||
              form.children.find(c => c.tagName === 'INPUT');
input.value = 'programme.spl';
input.dispatch('change');
verifier('« .spl » désigne Shakespeare',
         grid.children.find(b => b.getAttribute('aria-checked') === 'true').dataset.id,
         'shakespeare');
input.value = 'recette.chef';
input.dispatch('change');
verifier('« .chef » désigne Chef',
         grid.children.find(b => b.getAttribute('aria-checked') === 'true').dataset.id,
         'chef');
/* En onglet filtré, saisir un type d'une autre catégorie doit basculer l'onglet. */
tabs.children[1].dispatch('click');          // Classiques
input.value = 'hello.bf';
input.dispatch('change');
verifier('saisir « .bf » depuis « Classiques » bascule l’onglet',
         tabs.children.map(b => b.getAttribute('aria-selected')),
         ['false', 'false', 'true']);
verifier('et la grille montre alors les ésotériques', grid.children.length, 10);

console.log();
console.log('=== modèles et gabarits ===');
verifier('PSNewFileTemplate reconnaît .bf',
         win.PSNewFileTemplate('essai.bf').slice(0, 8), '++++++++');
verifier('PSNewFileTemplate reconnaît .arnoldc',
         win.PSNewFileTemplate('x.arnoldc').slice(0, 13), "IT'S SHOWTIME");
verifier('PSNewFileTemplate reconnaît .spl',
         win.PSNewFileTemplate('x.spl').indexOf('Romeo') > 0, true);
verifier('PSNewFileTemplate reconnaît .i',
         win.PSNewFileTemplate('x.i').indexOf('GIVE UP') > 0, true);
verifier('PSNewFileTemplate : le Piet commence par un data URI PNG',
         win.PSNewFileTemplate('x.png').slice(0, 22), 'data:image/png;base64,');
verifier('PSNewFileTemplate : .lol',
         win.PSNewFileTemplate('x.lol').slice(0, 7), 'HAI 1.2');
const fra = win.PSNewFileTemplate('x.fra');
verifier('PSNewFileTemplate : .fra explique l’absence de sortie',
         fra.indexOf("n'imprime rien") > 0, true);
verifier('PSNewFileTemplate : .fra contient un état et deux fractions',
         [fra.indexOf('n = 2') > 0, fra.indexOf('3/2') > 0, fra.indexOf('1/3') > 0],
         [true, true, true]);
verifier('PSNewFileTemplate : .ws ne contient que des blancs',
         /^[\s]*$/.test(win.PSNewFileTemplate('x.ws')), true);
verifier('le Whitespace n’est pas vide pour autant',
         win.PSNewFileTemplate('x.ws').length > 0, true);
verifier('PSNewFileTemplate : .mal fait 131 caractères',
         win.PSNewFileTemplate('x.mal').length, 131);
verifier('les types historiques gardent leur modèle',
         win.PSNewFileTemplate('x.py').indexOf('Bonjour Python') > 0, true);

console.log();
console.log(OK + '/' + N + ' vérifications conformes');
process.exit(OK === N ? 0 : 1);
