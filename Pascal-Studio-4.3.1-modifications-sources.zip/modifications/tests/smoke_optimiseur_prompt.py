#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : le filtre qui réécrit la demande avant l’IA agentique (3.9.0).

Ce module est le premier maillon de la chaîne : c’est lui qui décide si une
demande part enrichie ou part telle quelle. Un défaut ici est invisible pour
l’utilisateur, qui ne voit que sa propre formulation à l’écran. Le banc vérifie
donc surtout les refus, pas les succès.

Trois familles de contrôles.

  1. L’autonomie. Le module doit se charger sans requests, sans core, sans
     Starlette ni Ollama : c’est ce qui permet de le tester et ce qui garantit
     qu’un assistant sans modèle local installé ne casse pas à l’import.
  2. Les gardes de validation. Chaque refus est une régression évitée : un
     produit plus pauvre que la demande serait envoyé à l’agent à la place de la
     demande. Sont exercés le produit vide, trop long, disproportionné, traduit,
     porteur d’un secret, récitant la consigne, et identique à l’original.
  3. Le comportement de bout en bout avec un appel modèle injecté : désactivation
     par réglage, demande trop courte, chaîne de repli entre modèles, réponse
     hors format, dépassement du délai plafond en arrière-plan, nature daemon du
     fil lancé, et exception capturée au niveau du fil.

Aucun test n’appelle Ollama. Le poster est toujours injecté.
"""

import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
ASSISTANT = MODIFICATIONS / 'assistant-ia'
CIBLE = ASSISTANT / 'optimiseur_prompt.py'

DEMANDE = ('Écris un script python qui renomme les photos de vacances selon leur '
           'date de prise de vue, sans écraser les fichiers existants')

echecs = []
compte = [0]


def verif(condition, message):
    """Une assertion qui compte vraiment : le message n’est affiché qu’en cas d’échec."""
    compte[0] += 1
    if not condition:
        echecs.append(message)


def charger():
    """Charge le module depuis un dossier dont le nom contient un tiret."""
    if not CIBLE.is_file():
        echecs.append('optimiseur_prompt.py introuvable : %s' % CIBLE)
        return None
    spec = importlib.util.spec_from_file_location('optimiseur_prompt', str(CIBLE))
    module = importlib.util.module_from_spec(spec)
    sys.modules['optimiseur_prompt'] = module
    spec.loader.exec_module(module)
    return module


SONDE = '\n'.join([
    'import importlib.util, sys',
    'spec = importlib.util.spec_from_file_location("op", sys.argv[1])',
    'm = importlib.util.module_from_spec(spec)',
    'spec.loader.exec_module(m)',
    'lourdes = [x for x in ("requests", "core", "starlette", "uvicorn", "urllib3")'
    ' if x in sys.modules]',
    'print("LOURDES:" + (",".join(lourdes) if lourdes else "aucune"))',
    'print("MARQUEUR:" + m.MARQUEUR)',
    'noms = ("poster_ollama", "optimiser", "optimiser_en_arriere_plan", "valider",',
    '        "nettoyer_reponse", "est_utile", "construire_meta_prompt", "bloc_contexte")',
    'print("API:" + str(all(hasattr(m, n) for n in noms)))',
])


def sonder_autonomie():
    """Importe le module dans un interprète vierge et liste les modules lourds chargés."""
    with tempfile.TemporaryDirectory() as dossier:
        sonde = os.path.join(dossier, 'sonde.py')
        with open(sonde, 'w', encoding='utf-8') as flux:
            flux.write(SONDE)
        processus = subprocess.run([sys.executable, sonde, str(CIBLE)],
                                   capture_output=True, text=True, timeout=120)
        return processus, processus.stdout


def bon_poster(op, produit, notes='précisions ajoutées', modele_attendu=None):
    """Un poster qui renvoie un produit donné, au format attendu."""
    appels = []

    def poster(modele, consigne, delai=None):
        appels.append((modele, consigne, delai))
        if produit is None:
            return ''
        return ('{"prompt": %s, "notes": %s, "langue": "fr"}'
                % (_json(produit), _json(notes)))

    return poster, appels


def _json(texte):
    import json
    return json.dumps(str(texte), ensure_ascii=False)


def bon_produit(demande, ajout=' Objectif explicite, contraintes, résultat attendu et critères de réussite.'):
    """Un produit qui passe toutes les gardes : mots conservés, plus long, sans secret."""
    return demande + ajout


class FauxThreading:
    """Intercepte threading.Thread pour vérifier que le fil lancé est daemon.

    Un fil non daemon retient le processus à la fermeture : dans une AppImage,
    l’application ne s’éteindrait pas tant qu’une réécriture est en cours.
    """

    def __init__(self, vrai):
        self.vrai = vrai
        self.daemons = []

    def Thread(self, target=None, daemon=None, **reste):
        self.daemons.append(daemon)
        return self.vrai.Thread(target=target, daemon=daemon, **reste)


def main():
    if str(ASSISTANT) not in sys.path:
        sys.path.insert(0, str(ASSISTANT))
    op = charger()
    if op is None:
        return 1

    # --- 1. Autonomie : le module se charge seul --------------------------------
    processus, sortie = sonder_autonomie()
    verif(processus.returncode == 0,
          'la sonde d’autonomie a échoué : %s' % (processus.stderr.strip()[:400]))
    verif('LOURDES:aucune' in sortie,
          'le module entraîne des dépendances lourdes à l’import : %s'
          % [l for l in sortie.splitlines() if l.startswith('LOURDES')])
    verif('MARQUEUR:ps-3.9.0-optimiseur' in sortie,
          'marqueur de version absent ou erroné dans la sonde')
    verif('API:True' in sortie, 'une fonction publique manque à l’API du module')
    verif(op.MARQUEUR == 'ps-3.9.0-optimiseur',
          'MARQUEUR inattendu : %r' % op.MARQUEUR)
    print('autonomie : aucune dépendance lourde à l’import, API complète')

    # --- 2. Utilité de la demande ------------------------------------------------
    utile, pourquoi = op.est_utile(DEMANDE)
    verif(utile is True and pourquoi == '',
          'une demande normale est jugée inutile : %s' % pourquoi)
    verif(op.est_utile('ok')[0] is False, '« ok » est accepté à tort')
    verif(op.est_utile('ok')[1] != '', 'le refus de « ok » n’est pas motivé')
    verif(op.est_utile('merci beaucoup')[0] is False,
          'une formule de politesse est acceptée à tort')
    verif(op.est_utile(None)[0] is False, 'None est accepté à tort')
    verif(op.est_utile('     ')[0] is False, 'une demande blanche est acceptée à tort')
    verif(op.LONGUEUR_MINIMALE > 0, 'LONGUEUR_MINIMALE doit rester positive')
    print('utilité : %d contrôles sur les demandes non réécrivables' % 7)

    porteurs = op.mots_porteurs('Écrire un SCRIPT python en Python')
    verif('ecrire' in porteurs and 'script' in porteurs and 'python' in porteurs,
          'mots_porteurs ne normalise ni les accents ni la casse : %r' % porteurs)
    verif(len([m for m in porteurs if m == 'python']) == 1,
          'mots_porteurs ne dédoublonne pas')
    verif(op.mots_porteurs('le la de un') == set(),
          'les mots de moins de quatre lettres comptent comme porteurs')
    verif(op.recouvrement(DEMANDE, DEMANDE) == 1.0,
          'le recouvrement d’un texte avec lui-même n’est pas 1.0')
    verif(op.recouvrement(DEMANDE, 'Write a python script renaming holiday photos')
          < op.RECOUVREMENT_MINIMAL,
          'une traduction passe au-dessus du seuil de recouvrement')

    # --- 3. Nettoyage de la réponse du modèle ------------------------------------
    verif(op.nettoyer_reponse('{"prompt": "abc", "notes": "n"}')['prompt'] == 'abc',
          'un JSON propre n’est pas décodé')
    verif(op.nettoyer_reponse('```json\n{"prompt": "abc"}\n```')['prompt'] == 'abc',
          'un JSON en bloc de code n’est pas décodé')
    verif(op.nettoyer_reponse('<think>x</think>\n{"prompt": "abc"}')['prompt'] == 'abc',
          'un bloc de réflexion empêche le décodage')
    verif(op.nettoyer_reponse('Voici : {"prompt": "abc"}')['prompt'] == 'abc',
          'une prose avant le JSON empêche le décodage')
    verif(op.nettoyer_reponse('rien du tout') == {},
          'un texte sans accolade devrait donner un dictionnaire vide')
    verif(op.nettoyer_reponse('[1, 2]') == {}, 'un tableau JSON est accepté à tort')
    verif(op.nettoyer_reponse('{"prompt": "abc"') == {},
          'un JSON tronqué est accepté à tort')
    verif(op.nettoyer_reponse(None) == {}, 'None provoque une exception ou un objet')
    verif(op.nettoyer_reponse('{"prompt": "utilise {x} ici"}')['prompt'] == 'utilise {x} ici',
          'les accolades littérales d’une valeur sont abîmées')

    # --- 4. Gardes de validation -------------------------------------------------
    ok, raison = op.valider(DEMANDE, '')
    verif(ok is False and 'rien produit' in raison, 'un produit vide est accepté')
    ok, raison = op.valider(DEMANDE, 'python ' * 2000)
    verif(ok is False and 'trop long' in raison,
          'un produit au-dessus du plafond absolu est accepté : %s' % raison)
    ok, raison = op.valider(DEMANDE[:100], DEMANDE[:100] + ' python' * 500)
    verif(ok is False and 'disproportionné' in raison,
          'un produit disproportionné est accepté : %s' % raison)
    ok, raison = op.valider(DEMANDE, 'Write a python script renaming holiday photos by date')
    verif(ok is False and 'trop éloigné' in raison,
          'une traduction est acceptée : %s' % raison)
    ok, raison = op.valider(DEMANDE, DEMANDE + ' Le mot de passe est hunter2.')
    verif(ok is False and 'secret' in raison,
          'un secret ajouté par le modèle est accepté : %s' % raison)
    secret = 'Mon mot de passe est hunter2, écris un script python qui teste la connexion'
    ok, raison = op.valider(secret, secret + ' en détaillant chaque étape du script')
    verif(ok is True, 'un secret déjà présent dans la demande est refusé à tort : %s' % raison)
    ok, raison = op.valider(DEMANDE, DEMANDE + ' Tu es un optimiseur de demandes.')
    verif(ok is False and 'consigne' in raison,
          'un produit qui récite la consigne est accepté : %s' % raison)
    ok, raison = op.valider(DEMANDE, DEMANDE)
    verif(ok is False and 'telle quelle' in raison,
          'un produit identique à la demande est accepté : %s' % raison)
    ok, raison = op.valider(DEMANDE, bon_produit(DEMANDE))
    verif(ok is True, 'un bon produit est refusé : %s' % raison)
    print('validation : les neuf motifs de refus sont exercés')

    # --- 5. Consigne et contexte -------------------------------------------------
    meta = op.construire_meta_prompt(DEMANDE, None, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(DEMANDE in meta, 'la demande ne figure pas dans la consigne envoyée')
    verif('Contexte réel' not in meta,
          'un bloc de contexte vide est quand même inséré')
    verif('{"prompt"' in meta,
          'l’exemple de réponse JSON a disparu : les accolades ont été interprétées')
    contexte = {'projet_nom': 'Photos 2026', 'categorie': 'code', 'mode': 'local',
                'outils': 'lecture', 'fichiers': ['a.jpg', 'b.jpg'],
                'projet_consignes': 'c' * 3000, 'inconnu': 'ignoré'}
    meta = op.construire_meta_prompt(DEMANDE, contexte, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif('Projet ouvert : Photos 2026' in meta, 'le nom du projet n’est pas transmis')
    verif('a.jpg, b.jpg' in meta, 'les documents joints ne sont pas listés')
    verif('c' * 1200 in meta and 'c' * 1201 not in meta,
          'les consignes du projet ne sont pas tronquées à 1200 caractères')
    verif('ignoré' not in meta, 'une clé inconnue du contexte est injectée')
    verif(op.bloc_contexte({}) == '', 'un contexte vide produit un bloc')
    verif(op.bloc_contexte(None) == '', 'un contexte absent provoque une erreur')
    sans_marqueur = 'Réécris ceci proprement.'
    meta = op.construire_meta_prompt(DEMANDE, None, consigne=sans_marqueur)
    verif(meta.endswith(DEMANDE),
          'une consigne sans marqueur {demande} perd la demande de l’utilisateur')
    verif(op.construire_meta_prompt(DEMANDE, None, consigne='') != '',
          'une consigne vide produit une consigne vide')
    print('consigne : substitutions par replace, marqueur manquant compensé')

    # --- 6. Choix des modèles ----------------------------------------------------
    # core est peut-être importable (requests présent) : le modèle de routage
    # s’ajoute alors comme candidat implicite. Les assertions en tiennent compte
    # au lieu de supposer une liste exacte.
    routeur = ''
    try:
        import core
        routeur = str(getattr(core, 'ROUTER_MODEL', '') or '').strip()
    except Exception:
        routeur = ''
    defaut = op.MODELE_PAR_DEFAUT
    op.MODELE_PAR_DEFAUT = ''
    try:
        liste = op.modeles_essayes({'prompt_model': 'mistral:7b'})
        verif(liste and liste[0] == 'mistral:7b',
              'le modèle choisi dans les réglages n’est pas essayé en premier : %r' % liste)
        verif(op.modeles_essayes({'prompt_model': 'mistral:7b'},
                                'mistral:7b')[0] == 'mistral:7b',
              'un modèle explicitement demandé n’est pas respecté quand il répond aussi')
        if routeur:
            verif(op.modeles_essayes({}, routeur) == [],
                  'le modèle de routage qui répond aussi à l’utilisateur n’est pas écarté : %r'
                  % op.modeles_essayes({}, routeur))
        else:
            print('  (core indisponible : l’écart du modèle de routage n’est pas vérifié)')
        doubles = op.modeles_essayes({'prompt_model': 'a'}, modele_repondant=None)
        op.MODELE_PAR_DEFAUT = 'a'
        verif(op.modeles_essayes({'prompt_model': 'a'}).count('a') == 1,
              'la liste des modèles n’est pas dédoublonnée : %r'
              % op.modeles_essayes({'prompt_model': 'a'}))
        op.MODELE_PAR_DEFAUT = ''
        blancs = op.modeles_essayes({'prompt_model': '  '})
        verif(all(m.strip() for m in blancs),
              'un modèle vide ou blanc est essayé : %r' % blancs)
        verif(len(doubles) == len(set(doubles)), 'doublon dans la liste des modèles')
        op.MODELE_PAR_DEFAUT = 'qwen3:1.7b'
        verif('qwen3:1.7b' in op.modeles_essayes({}),
              'PS_PROMPT_MODEL n’est pas pris en compte')
    finally:
        op.MODELE_PAR_DEFAUT = defaut
    print('modèles : ordre, dédoublonnage et exclusion du modèle répondant')

    # --- 7. optimiser() avec un poster injecté -----------------------------------
    poster, appels = bon_poster(op, bon_produit(DEMANDE))
    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'mistral:7b'},
                            poster, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'optimise',
          'un bon produit n’est pas retenu : %r' % resultat['raison'])
    verif(resultat['optimise'] == bon_produit(DEMANDE), 'le produit retenu est altéré')
    verif(resultat['original'] == DEMANDE, 'la demande d’origine n’est pas conservée')
    verif(resultat['modele'] == 'mistral:7b', 'le modèle employé n’est pas tracé')
    verif(resultat['modifie'] is True, 'le résultat ne signale pas la modification')
    verif(resultat['notes'] == 'précisions ajoutées', 'les notes du modèle sont perdues')
    verif(isinstance(resultat['ms'], int) and resultat['ms'] >= 0,
          'la durée n’est pas un entier positif')
    verif(resultat['marqueur'] == op.MARQUEUR, 'le marqueur manque au résultat')
    verif(len(appels) == 1 and appels[0][0] == 'mistral:7b',
          'le poster n’est pas appelé exactement une fois avec le bon modèle')
    verif(DEMANDE in appels[0][1], 'la consigne transmise au poster ne contient pas la demande')

    resultat = op.optimiser(DEMANDE, None, {'prompt_optimiser': '0'}, poster,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'desactive' and resultat['optimise'] == DEMANDE
          and resultat['modifie'] is False,
          'le réglage désactivé n’empêche pas la réécriture')
    verif(resultat['statut'] == 'desactive'
          and op.optimiser(DEMANDE, None, {'prompt_optimiser': 'false'}, poster,
                           consigne=op.CONSIGNE_PAR_DEFAUT)['statut'] == 'desactive',
          'la valeur « false » ne désactive pas le filtre')

    resultat = op.optimiser('', None, {}, poster, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'repli', 'une demande vide n’est pas repliée')
    avant = len(appels)
    resultat = op.optimiser('ok', None, {}, poster, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'inutile' and len(appels) == avant,
          'une demande trop courte déclenche quand même un appel modèle')

    def poster_laisse(modele, consigne, delai=None):
        if modele == 'mauvais':
            raise RuntimeError('modèle injoignable')
        return json.dumps({'prompt': bon_produit(DEMANDE), 'notes': 'second'},
                          ensure_ascii=False)

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'mauvais'},
                            poster_laisse, consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'optimise' and resultat['notes'] == 'second',
          'la chaîne de repli entre modèles ne fonctionne pas : %r' % resultat)
    verif(resultat['modele'] != 'mauvais',
          'un modèle en panne est tracé comme celui qui a produit le prompt')

    def poster_enveloppe(modele, consigne, delai=None):
        # Chaîne JSON contenant la représentation d’un dictionnaire : aucun champ
        # prompt décodable. Le texte brut n’est pas un prompt, il ne doit pas
        # partir vers l’agent.
        return json.dumps(str({'prompt': bon_produit(DEMANDE)}), ensure_ascii=False)

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'a'}, poster_enveloppe,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'repli',
          'une enveloppe JSON sans champ prompt est envoyée comme prompt : %r' % resultat)
    verif('inexploitable' in resultat['raison'],
          'le motif du format inexploitable n’est pas tracé : %r' % resultat['raison'])

    def poster_encadre(modele, consigne, delai=None):
        # Un prompt en texte libre, encadré d’un bloc de code : exploitable.
        return '```\n' + bon_produit(DEMANDE, ' Réponse encadrée mais exploitable.') + '\n```'

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'a'}, poster_encadre,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'optimise',
          'un prompt en texte libre encadré est rejeté : %r' % resultat['raison'])
    verif('```' not in resultat['optimise'],
          'le bloc de code reste collé au prompt envoyé à l’agent')

    def poster_muet(modele, consigne, delai=None):
        raise OSError('ollama absent')

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'a'}, poster_muet,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'repli' and 'ollama absent' in resultat['raison'],
          'une panne du modèle n’est pas repliée avec son motif : %r' % resultat)
    verif(resultat['optimise'] == DEMANDE, 'après une panne, la demande est altérée')

    def poster_brut(modele, consigne, delai=None):
        return bon_produit(DEMANDE, ' Réponse hors format mais exploitable.')

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'a'}, poster_brut,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'optimise',
          'une réponse hors JSON mais valide est rejetée : %r' % resultat['raison'])

    def poster_sans_champ(modele, consigne, delai=None):
        return '{"notes": "rien"}'

    resultat = op.optimiser(DEMANDE, None, {'prompt_model': 'a'}, poster_sans_champ,
                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'repli',
          'un JSON sans champ prompt est retenu à tort')

    # --- 8. optimiser_en_arriere_plan() ------------------------------------------
    poster, appels = bon_poster(op, bon_produit(DEMANDE))
    resultat = op.optimiser_en_arriere_plan(DEMANDE, None, {'prompt_model': 'a'},
                                            poster, delai=5,
                                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'optimise',
          'le chemin en arrière-plan ne produit pas le même résultat : %r' % resultat)

    def poster_lent(modele, consigne, delai=None):
        time.sleep(2.0)
        return _json({'prompt': bon_produit(DEMANDE)})

    depart = time.time()
    resultat = op.optimiser_en_arriere_plan(DEMANDE, None, {'prompt_model': 'a'},
                                            poster_lent, delai=0.3,
                                            consigne=op.CONSIGNE_PAR_DEFAUT)
    duree = time.time() - depart
    verif(resultat['statut'] == 'repli',
          'un modèle trop lent n’est pas replié : %r' % resultat)
    verif('délai plafond' in resultat['raison'],
          'le motif du dépassement de délai est absent : %r' % resultat['raison'])
    verif(resultat['optimise'] == DEMANDE,
          'après un dépassement de délai, la demande est altérée')
    verif(duree < 1.5, 'l’attente du délai plafond bloque au-delà du plafond : %.2f s' % duree)

    faux = FauxThreading(threading)
    vrai_threading = op.threading
    op.threading = faux
    try:
        op.optimiser_en_arriere_plan(DEMANDE, None, {'prompt_model': 'a'},
                                     bon_poster(op, bon_produit(DEMANDE))[0],
                                     delai=5, consigne=op.CONSIGNE_PAR_DEFAUT)
    finally:
        op.threading = vrai_threading
    verif(faux.daemons == [True],
          'le fil de réécriture n’est pas daemon : %r' % faux.daemons)

    avant = len(appels)
    resultat = op.optimiser_en_arriere_plan('ok', None, {}, poster, delai=5,
                                            consigne=op.CONSIGNE_PAR_DEFAUT)
    verif(resultat['statut'] == 'inutile' and len(appels) == avant,
          'une demande inutile réveille un fil pour rien')

    vraie_liste = op.modeles_essayes

    def liste_cassee(*arguments, **reste):
        raise RuntimeError('panne hors de la boucle des modèles')

    op.modeles_essayes = liste_cassee
    try:
        resultat = op.optimiser_en_arriere_plan(DEMANDE, None, {}, poster, delai=5,
                                                consigne=op.CONSIGNE_PAR_DEFAUT)
    finally:
        op.modeles_essayes = vraie_liste
    verif(resultat['statut'] == 'erreur' and 'panne hors' in resultat['raison'],
          'une exception hors de la boucle des modèles n’est pas capturée : %r' % resultat)
    verif(resultat['optimise'] == DEMANDE,
          'après une erreur interne, la demande d’origine n’est pas rendue')

    # --- 9. Cohérence avec la consigne livrée ------------------------------------
    fichier = ASSISTANT / 'prompts' / 'optimiseur.md'
    verif(fichier.is_file(), 'prompts/optimiseur.md manque : la consigne n’est plus modifiable')
    if fichier.is_file():
        texte = fichier.read_text(encoding='utf-8')
        verif('{demande}' in texte, 'prompts/optimiseur.md a perdu le marqueur {demande}')
        verif('{contexte}' in texte, 'prompts/optimiseur.md a perdu le marqueur {contexte}')
        verif('"prompt"' in texte, 'prompts/optimiseur.md n’impose plus le champ JSON prompt')
        meta = op.construire_meta_prompt(DEMANDE, None, consigne=texte)
        verif(DEMANDE in meta, 'la consigne livrée ne transmet pas la demande')
        ok, raison = op.valider(DEMANDE, bon_produit(DEMANDE))
        verif(ok is True, 'garde finale : un bon produit doit rester accepté (%s)' % raison)

    if echecs:
        print('\n%d assertion(s) sur %d en échec :' % (len(echecs), compte[0]))
        for probleme in echecs:
            print('  - ' + probleme)
        return 1
    print('\nBanc de l’optimiseur de demande : %d assertions, toutes conformes.'
          % compte[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
