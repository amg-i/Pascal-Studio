/* Banc de la section « Outils et dépendances » des paramètres (4.1.0).
 *
 * Ce banc exécute réellement outils-studio.js dans le harnais DOM partagé, avec
 * un serveur simulé qui rend les vraies formes de réponse de /api/outils —
 * formes relevées en exécutant outils_manquants.py, pas inventées.
 *
 * Trois scénarios, parce que cette section a trois façons de mal se comporter :
 *
 *   A. l'hôte .ps-outils-host n'existe pas (la fenêtre des paramètres est
 *      fermée) : le script doit charger sans erreur, ne rien écrire dans le DOM
 *      et NE RIEN DEMANDER au serveur ;
 *   B. l'inventaire arrive : la section doit dire ce qui manque, pourquoi un
 *      outil ne peut pas être installé d'ici, et donner la commande exacte. Un
 *      panneau qui affiche seulement « manquant » sans la raison laisse
 *      l'utilisateur devant une impasse — c'était l'état avant cette version ;
 *   C. les actions : rien qui demande les droits root ne part sans une
 *      confirmation qui AFFICHE la commande, et « Tout installer » passe par le
 *      plan (étapes, tailles, remarques) avant de lancer quoi que ce soit.
 *
 * Ce que le banc cherche en priorité, parce que ce sont les défauts déjà
 * rencontrés dans ce projet :
 *   - une requête envoyée avec un champ que le serveur ignore ;
 *   - racine_autorisee parti tout seul, sans case cochée ni confirmation ;
 *   - une réponse d'échec lue comme un succès ;
 *   - un panneau qui se reconstruit en boucle via son propre MutationObserver ;
 *   - une remarque du serveur (notes) perdue en route : c'est elle qui dit
 *     POURQUOI Ghidra pèse 570 Mo ou pourquoi pasls ne se télécharge pas ;
 *   - une tâche sans bouton d'arrêt.
 *
 * Lancer :  node tests/smoke_outils_studio.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'outils-studio.js');
const source = fs.readFileSync(SCRIPT, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 300)
    + '\n      attendu : ' + serie(attendu).slice(0, 300));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }
function faux(titre, condition) { verifier(titre, !!condition, false); }
function contient(titre, texte, morceau) {
  N += 1;
  if (String(texte || '').indexOf(morceau) >= 0) OK += 1;
  else echecs.push(titre + '\n      « ' + morceau + ' » absent de : '
    + String(texte || '').slice(0, 400));
}
function absent(titre, texte, morceau) {
  N += 1;
  if (String(texte || '').indexOf(morceau) < 0) OK += 1;
  else echecs.push(titre + '\n      « ' + morceau + ' » ne devrait pas être là');
}

/* ------------------------------------------------- les formes de réponse ---- */
/* Relevées en exécutant outils_manquants.py sur cette machine. */

function outil(id, nom, famille, voie, champs) {
  return Object.assign({
    id: id, nom: nom, famille: famille, role: 'Rôle de ' + nom + '.',
    langage: '', present: false, binaires: [nom], manquants: [nom],
    voie: voie, racine: voie === 'apt', paquets: [nom],
    commande: 'sudo apt-get install -y ' + nom,
    telechargeable: true, gestionnaire: 'apt-get', depot: '', url: '',
    notes: [], detection: [{ nom: nom, present: false, chemin: '', version: '' }]
  }, champs || {});
}

function inventaire() {
  return {
    ok: true, marqueur: 'ps-4.1.0-outils', version: '4.1.0',
    avec_versions: false, total: 8, presents: 1, manquants: 7,
    installables: 5, manuels: 2,
    resume: '8 outil(s) inventoriés, 1 présent(s), 7 manquant(s) dont 5 '
      + 'installable(s) d’ici et 2 à la main.',
    chemins: { dossier: '/home/essai/.local/share/pascal-studio/outils',
      bin: '/home/essai/.local/share/pascal-studio/outils/bin',
      existe: true, dans_path: true, libre_octets: 42 * 1024 * 1024 * 1024,
      variable: 'PS_OUTILS_DIR' },
    gestionnaires: { npm: true, pkexec: true, 'apt-get': true, python3: true },
    familles: {
      'compilateurs': { total: 2, manquants: 1 },
      'serveurs de langage': { total: 2, manquants: 2 },
      'débogage': { total: 1, manquants: 1 },
      'rétro-ingénierie': { total: 1, manquants: 1 },
      'analyse avancée': { total: 2, manquants: 0 }
    },
    liste: [
      outil('apt:gdb', 'gdb', 'débogage', 'apt',
        { role: 'Débogage pas à pas d’un binaire natif.' }),
      outil('apt:binutils', 'binutils', 'rétro-ingénierie', 'apt',
        { binaires: ['objdump', 'readelf', 'nm'],
          manquants: ['readelf'], present: false,
          commande: 'sudo apt-get install -y binutils' }),
      outil('npm:vscode-langservers-extracted', 'vscode-langservers-extracted',
        'serveurs de langage', 'npm',
        { racine: false, gestionnaire: 'npm',
          commande: 'sudo npm install -g vscode-langservers-extracted',
          binaires: ['vscode-html-language-server', 'vscode-css-language-server'],
          notes: ['La commande déclarée installe en root. Ici l’installation '
            + 'se fait sans droits root.'] }),
      outil('amont:pasls', 'pasls', 'serveurs de langage', 'amont',
        { racine: false, gestionnaire: 'python3', paquets: [],
          depot: 'genericptr/pasls', telechargeable: false,
          commande: 'voir https://github.com/genericptr/pasls',
          notes: ['Ce dépôt ne publie AUCUNE archive : vérifié le 2026-11-11. '
            + 'Il faut le compiler (Nim).'] }),
      outil('amont:ghidraRun', 'ghidraRun', 'analyse avancée', 'amont',
        { racine: false, gestionnaire: 'python3', paquets: [],
          depot: 'NationalSecurityAgency/ghidra',
          commande: 'voir https://github.com/NationalSecurityAgency/ghidra/releases',
          role: 'Décompilation, références croisées et graphe d’appels.' }),
      outil('adoptium:jdk-temurin-21', 'jdk-temurin-21', 'analyse avancée',
        'adoptium',
        { racine: false, gestionnaire: 'python3', paquets: ['21'],
          commande: 'voir https://adoptium.net/ (JDK 21)' }),
      outil('apt:gcc', 'build-essential', 'compilateurs', 'apt',
        { present: true, manquants: [],
          detection: [{ nom: 'gcc', present: true, chemin: '/usr/bin/gcc',
            version: '14.2.0' }] }),
      outil('inconnue:dotnet', 'dotnet', 'compilateurs', 'inconnue',
        { telechargeable: false, commande: '', racine: false,
          notes: ['Le SDK .NET n’est pas dans Debian : il vient de son '
            + 'éditeur.'] })
    ]
  };
}

function capacites() {
  return {
    marqueur: 'ps-4.1.0-outils', version: '4.1.0',
    resume: 'Inventaire des outils externes et installation de ce qui manque.',
    dossier: inventaire().chemins,
    gestionnaires: inventaire().gestionnaires,
    installe_en_root_apres_confirmation: true, root_par_defaut: false,
    telecharge_depuis: ['api.github.com', 'api.adoptium.net'],
    invente_des_urls: false, modifie_des_paquets_installes: false,
    commandes_interdites: ['remove', 'purge', 'autoremove', 'upgrade'],
    familles: Object.keys(inventaire().familles),
    sources: ['langages.LANGAGES'], ok: true,
    etat: inventaire(), taches: []
  };
}

function plan() {
  return {
    ok: true, racine: true, racine_autorisee: false, taille_totale: 806912000,
    outils: 5, resolu: true,
    identifiants: ['apt:gdb', 'apt:binutils', 'npm:vscode-langservers-extracted',
      'amont:ghidraRun', 'adoptium:jdk-temurin-21'],
    resume: '4 étape(s) pour 5 outil(s), dont 806.9 Mo de téléchargement et '
      + 'une demande de droits root.',
    gestionnaires_manquants: [],
    etapes: [
      { voie: 'apt', outils: ['apt:gdb', 'apt:binutils'],
        paquets: ['gdb', 'binutils'], racine: true, executable: false,
        commande: ['pkexec', 'env', 'DEBIAN_FRONTEND=noninteractive',
          'apt-get', 'install', '-y', '--no-install-recommends', 'gdb',
          'binutils'],
        commande_texte: 'pkexec env DEBIAN_FRONTEND=noninteractive apt-get '
          + 'install -y --no-install-recommends gdb binutils',
        commande_manuelle: 'sudo apt-get install -y gdb binutils',
        taille_attendue: 0,
        notes: ['Une seule demande de mot de passe pour 2 paquet(s).',
          'Les droits root ne sont pas autorisés par cet appel.'] },
      { voie: 'npm', outils: ['npm:vscode-langservers-extracted'],
        paquets: ['vscode-langservers-extracted'], racine: false,
        executable: true, commande: ['npm', 'install', '--prefix', '/x'],
        commande_texte: 'npm install --prefix /x vscode-langservers-extracted',
        commande_manuelle: 'sudo npm install -g vscode-langservers-extracted',
        taille_attendue: 0, notes: ['Installé sans droits root.'] },
      { voie: 'adoptium', outils: ['adoptium:jdk-temurin-21'], paquets: ['21'],
        racine: false, executable: true,
        commande: ['télécharger', 'https://example.invalid/jdk.tar.gz'],
        commande_texte: 'télécharger https://example.invalid/jdk.tar.gz puis '
          + 'l’extraire dans /x/extraits/jdk-temurin-21',
        commande_manuelle: 'voir https://adoptium.net/',
        taille_attendue: 207858352,
        notes: ['Publication jdk-21.0.13+9, archive OpenJDK21U…, 198.2 Mo.',
          'Somme SHA-256 publiée par l’origine : elle sera vérifiée.'] },
      { voie: 'amont', outils: ['amont:ghidraRun'], paquets: [], racine: false,
        executable: true, commande: ['télécharger', 'https://example.invalid/g.zip'],
        commande_texte: 'télécharger https://example.invalid/g.zip puis '
          + 'l’extraire dans /x/extraits/ghidra',
        commande_manuelle: 'voir https://github.com/NationalSecurityAgency/ghidra/releases',
        taille_attendue: 569712708,
        notes: ['Publication Ghidra_12.2_build, 543.3 Mo.',
          'Aucune somme de contrôle n’est publiée avec cette archive.'] }
    ],
    notes: ['pasls : aucune voie automatisable. Ce dépôt ne publie AUCUNE '
      + 'archive.', 'dotnet : aucune voie automatisable. Le SDK .NET n’est pas '
      + 'dans Debian.']
  };
}

function suiviDe(sid, etatTache) {
  return {
    ok: true, sid: sid, etat: etatTache || 'en cours',
    identifiants: ['amont:ghidraRun'], etape: 1, etapes: 2,
    progression: { octets: 285000000, total: 569712708, pourcentage: 50.0,
      vitesse: 8400000, reste: 34 },
    resultats: [], depuis: 3, journal_tronque: 12, arrete: false, duree: 21.4,
    lignes: [
      { t: 1, niveau: 'etape', texte: 'Étape 1/2 — voie amont, 1 outil(s).' },
      { t: 2, niveau: 'commande', texte: '$ télécharger ghidra_12.2.zip' },
      { t: 3, niveau: 'progression', texte: '285.0 Mo / 543.3 Mo — 50.0 %' }
    ]
  };
}

/* ------------------------------------------------------------- le harnais ---- */

function banc(opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const document = harnais.document;
  const body = harnais.body;
  const requetes = [];
  const reponses = opts.reponses || {};

  const repondre = (action, corps) => {
    if (reponses[action]) return reponses[action](corps);
    switch (action) {
      case 'versions': { const e = inventaire(); e.avec_versions = true; return e; }
      case 'etat': return inventaire();
      case 'plan': return plan();
      case 'installer': return opts.installerRefuse
        ? { ok: false, erreur: 'Rien à installer : aucune voie automatisable.' }
        : { ok: true, sid: 'abc123', resume: 'Installation démarrée : '
          + plan().resume, plan: plan() };
      case 'suivre': return suiviDe(corps.sid || 'abc123', corps.etatForce);
      case 'arreter': return { ok: true, sid: corps.sid, processus_tue: true,
        etat: 'arrêté' };
      case 'taches': return { ok: true, taches: [] };
      case 'dossier': return Object.assign({ ok: true }, inventaire().chemins);
      default: return { error: 'Action d’outils inconnue : ' + action };
    }
  };

  const fetchStub = (url, init) => {
    let corps = {};
    try { corps = JSON.parse((init && init.body) || '{}'); } catch (e) { corps = {}; }
    const methode = (init && init.method) || 'GET';
    requetes.push({ url: url, methode: methode, corps: corps });
    if (opts.serveurKo) {
      return Promise.resolve({ ok: false, status: 500,
        json: () => Promise.resolve({ error: 'Le serveur a cassé.' }) });
    }
    if (methode === 'GET') {
      return Promise.resolve({ ok: true, status: 200,
        json: () => Promise.resolve(capacites()) });
    }
    const reponse = repondre(corps.action || '', corps);
    /* `error` vient d'une branche qui lève : 400. `ok:false` avec `erreur` est
     * un refus métier : 200. Confondre les deux ferait tester au panneau un
     * serveur qui n'existe pas. */
    const leve = !!reponse.error;
    return Promise.resolve({ ok: !leve, status: leve ? 400 : 200,
      json: () => Promise.resolve(reponse) });
  };

  const intervalles = [];
  const sandbox = {
    document: document, console: console, setTimeout: setTimeout,
    clearTimeout: clearTimeout,
    setInterval: (fn) => { intervalles.push(fn); return intervalles.length; },
    clearInterval: () => {},
    fetch: fetchStub,
    navigator: { clipboard: null, userAgent: 'banc' },
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise,
    TypeError: TypeError, Error: Error,
    MutationObserver: H.MutationObserverStub,
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 'outils-studio.js' });

  function insererHote() {
    const hote = document.createElement('div');
    hote.className = 'ps-outils-host';
    body.appendChild(hote);
    harnais.rafraichir();
    H.declencherObservateurs();
    return hote;
  }
  async function ticks(n) {
    for (let i = 0; i < (n || 10); i++) {
      await Promise.resolve();
      await new Promise(r => setTimeout(r, 0));
    }
    H.declencherObservateurs();
    harnais.rafraichir();
  }
  function section() { return document.querySelector('.psoutils'); }
  function texte(sel) {
    const n = document.querySelector(sel);
    return n ? n.textContent : '';
  }
  function tous(sel) { return document.querySelectorAll(sel); }
  function boutons() {
    return Array.prototype.slice.call(tous('.psoutils button'));
  }
  function bouton(texteCherche) {
    return boutons().filter(function (b) {
      return String(b.textContent || '').indexOf(texteCherche) >= 0;
    })[0] || null;
  }
  function lignes() { return tous('.psoutils-ligne'); }

  return {
    document: document, body: body, sandbox: sandbox, requetes: requetes,
    insererHote: insererHote, ticks: ticks, section: section, texte: texte,
    tous: tous, boutons: boutons, bouton: bouton, lignes: lignes,
    api: () => sandbox.PSOutils, intervalles: intervalles,
    harnais: harnais
  };
}

/* ---------------------------------------------------------------- scénarios -- */

async function scenarioA() {
  const b = banc();
  await b.ticks(4);
  faux('A. sans hôte, rien n’est écrit dans le DOM', b.section());
  verifier('A. sans hôte, aucune requête n’est envoyée', b.requetes.length, 0);
  vrai('A. le script publie PSOutils', b.api() && b.api().marqueur);
  verifier('A. le marqueur publié est celui de la version',
    b.api().marqueur, 'ps-4.1.0-outils');
  verifier('A. l’API publiée est /api/outils', b.api().api, '/api/outils');
  b.api().rendre();
  faux('A. rendre() sans hôte n’écrit toujours rien', b.section());
}

async function scenarioB() {
  const b = banc();
  b.insererHote();
  await b.ticks(12);
  vrai('B. la section est rendue dans l’hôte', b.section());
  verifier('B. une seule requête GET a été envoyée',
    b.requetes.filter(r => r.methode === 'GET').length, 1);
  verifier('B. la requête porte sur /api/outils', b.requetes[0].url,
    '/api/outils');
  contient('B. le résumé du module est affiché', b.texte('.psoutils-resume'),
    '8 outil(s) inventoriés');
  contient('B. le titre dit ce que fait la section', b.texte('.psoutils-titre'),
    'Ce qui manque');
  contient('B. le dossier d’outils est affiché', b.texte('.psoutils-dossier'),
    '/home/essai/.local/share/pascal-studio/outils');
  contient('B. l’état du PATH est affiché', b.texte('.psoutils-dossier'),
    'dans PATH');
  contient('B. la place libre est lisible', b.texte('.psoutils-dossier'),
    '42.0 Go');
  /* Le filtre par défaut est « manquants » : 5 outils sur 8. */
  verifier('B. le filtre par défaut ne montre que les manquants',
    b.lignes().length, 7);
  const ids = Array.prototype.map.call(b.lignes(), function (l) {
    return l.getAttribute('data-id');
  });
  vrai('B. gdb est listé', ids.indexOf('apt:gdb') >= 0);
  faux('B. un outil présent n’est pas listé par défaut',
    ids.indexOf('apt:gcc') >= 0);
  const texteSection = b.section().textContent;
  contient('B. la raison d’un outil non téléchargeable est affichée',
    texteSection, 'ne publie AUCUNE archive');
  contient('B. la raison du SDK .NET est affichée', texteSection,
    'n’est pas dans Debian');
  contient('B. la commande exacte est affichée', texteSection,
    'sudo apt-get install -y gdb');
  contient('B. l’écart avec la commande déclarée est annoncé', texteSection,
    'sans droits root');
  /* Les boutons. */
  vrai('B. il y a un bouton « Tout installer… »',
    !!b.bouton('Tout installer'));
  vrai('B. il y a un bouton « Vérifier les versions »',
    !!b.bouton('Vérifier les versions'));
  vrai('B. il y a un bouton « Actualiser »', !!b.bouton('Actualiser'));
  vrai('B. la case d’autorisation des droits root existe',
    !!b.tous('#psoutils-racine').length);
  faux('B. les droits root ne sont pas autorisés par défaut',
    b.api().etat().autoriseRacine);
  /* Un outil non téléchargeable n’a PAS de bouton Installer. */
  const pasls = b.tous('.psoutils-ligne').length;
  vrai('B. des lignes sont rendues', pasls > 0);
  const lignePasls = Array.prototype.filter.call(b.lignes(), function (l) {
    return l.getAttribute('data-id') === 'amont:pasls';
  })[0];
  vrai('B. la ligne de pasls existe', lignePasls);
  if (lignePasls) {
    const installer = Array.prototype.filter.call(
      lignePasls.querySelectorAll('button'), function (x) {
        return String(x.textContent).indexOf('Installer') >= 0;
      });
    verifier('B. un outil non téléchargeable n’a pas de bouton Installer',
      installer.length, 0);
    contient('B. sa commande de repli est la page amont',
      lignePasls.textContent, 'github.com/genericptr/pasls');
  }
  /* Un outil en root dit qu'il demande root. */
  const ligneGdb = Array.prototype.filter.call(b.lignes(), function (l) {
    return l.getAttribute('data-id') === 'apt:gdb';
  })[0];
  vrai('B. la ligne de gdb existe', ligneGdb);
  if (ligneGdb) {
    contient('B. le bouton d’un paquet Debian annonce les droits root',
      ligneGdb.textContent, 'Installer (root)');
    verifier('B. la ligne porte son état', ligneGdb.getAttribute('data-present'),
      'false');
  }
  /* Les familles. */
  contient('B. les familles sont affichées', texteSection, 'rétro-ingénierie');
  vrai('B. un sélecteur de famille existe', !!b.tous('select').length);
  /* Pas de boucle de rendu. */
  const avant = H.compteurMutations();
  await b.ticks(6);
  b.api().rendre();
  await b.ticks(2);
  vrai('B. rendre() ne déclenche pas une cascade infinie',
    H.compteurMutations() - avant < 400);
}

async function scenarioC() {
  const b = banc();
  b.insererHote();
  await b.ticks(12);
  const depart = b.requetes.length;

  /* C1. Un outil en root, sans autorisation : confirmation, pas de requête. */
  await b.api().installerUn('apt:gdb');
  await b.ticks(4);
  verifier('C1. aucune requête installer n’est partie sans confirmation',
    b.requetes.filter(r => r.corps.action === 'installer').length, 0);
  vrai('C1. un bloc de confirmation est affiché',
    !!b.tous('.psoutils-confirm').length);
  contient('C1. la confirmation dit que les droits root sont demandés',
    b.texte('.psoutils-confirm'), 'demande les droits root');
  contient('C1. la commande exacte est affichée AVANT',
    b.texte('.psoutils-confirm'), 'sudo apt-get install -y gdb');
  contient('C1. il est dit que le système demande le mot de passe',
    b.texte('.psoutils-confirm'), 'mot de passe');
  contient('C1. les verbes destructeurs sont annoncés comme absents',
    b.texte('.psoutils-confirm'), 'jamais remove');
  vrai('C1. un bouton Confirmer existe', !!b.bouton('Confirmer'));
  vrai('C1. un bouton Annuler existe', !!b.bouton('Annuler'));
  contient('C1. sans la case cochée, l’étape sera sautée et c’est dit',
    b.texte('.psoutils-confirm'), 'sera sautée');

  /* C2. Annuler ne lance rien. Le clic passe par la DÉLÉGATION : un seul
   * écouteur sur la racine, les boutons portent data-acte. Un écouteur posé
   * sur un bouton disparaît quand la section est reconstruite, et c'est
   * précisément ce qui faisait qu'un clic pouvait ne rien produire. */
  const actes = Array.prototype.map.call(b.boutons(), function (x) {
    return x.getAttribute('data-acte');
  }).filter(function (a) { return !!a; });
  vrai('C2. chaque bouton porte son action pour la délégation',
    actes.indexOf('annuler') >= 0 && actes.indexOf('confirmer') >= 0
    && actes.indexOf('installer') >= 0 && actes.indexOf('verifier') >= 0
    && actes.indexOf('tout') >= 0 && actes.indexOf('actualiser') >= 0);
  verifier('C2. aucun bouton ne repose sur un écouteur propre',
    b.boutons().length, actes.length);
  await b.api().dispatch('annuler');
  await b.ticks(2);
  faux('C2. après annulation, plus de bloc de confirmation',
    !!b.tous('.psoutils-confirm').length);
  verifier('C2. aucune requête installer n’est partie',
    b.requetes.filter(r => r.corps.action === 'installer').length, 0);

  /* C3. Avec l'autorisation, installer envoie racine_autorisee. */
  b.api().autoriserRacine(true);
  await b.ticks(2);
  vrai('C3. l’autorisation est enregistrée', b.api().etat().autoriseRacine);
  await b.api().installerUn('apt:gdb');
  await b.ticks(8);
  const inst = b.requetes.filter(r => r.corps.action === 'installer');
  verifier('C3. une requête installer est partie', inst.length, 1);
  if (inst.length) {
    verifier('C3. elle porte l’identifiant demandé',
      inst[0].corps.identifiants, ['apt:gdb']);
    verifier('C3. elle porte racine_autorisee à true',
      inst[0].corps.racine_autorisee, true);
    verifier('C3. elle nomme l’agent', inst[0].corps.agent, 'parametres');
    verifier('C3. tout est faux pour un seul outil', inst[0].corps.tout, false);
  }
  vrai('C3. le journal de la tâche est affiché',
    !!b.tous('.psoutils-journal').length);
  vrai('C3. un bouton Arrêter existe', !!b.bouton('Arrêter'));
  contient('C3. la progression est affichée', b.texte('.psoutils-journal-tete'),
    '50.0 %');
  contient('C3. la vitesse est affichée', b.texte('.psoutils-journal-tete'),
    'Mo/s');
  contient('C3. le temps restant est affiché', b.texte('.psoutils-journal-tete'),
    'reste 34 s');
  contient('C3. les lignes du journal sont rendues',
    b.texte('.psoutils-lignes'), 'Étape 1/2');
  contient('C3. la troncature du journal est annoncée',
    b.texte('.psoutils-journal'), '12 ligne(s) plus ancienne(s)');

  /* C4. Sans autorisation, la requête ne porte PAS racine_autorisee. */
  const b2 = banc();
  b2.insererHote();
  await b2.ticks(12);
  await b2.api().lancer(['apt:gdb'], false, false);
  await b2.ticks(6);
  const inst2 = b2.requetes.filter(r => r.corps.action === 'installer');
  verifier('C4. une requête est partie', inst2.length, 1);
  if (inst2.length) {
    verifier('C4. racine_autorisee est faux quand la case n’est pas cochée',
      inst2[0].corps.racine_autorisee, false);
  }

  /* C5. « Tout installer » passe par le plan, puis par un second clic. */
  const b3 = banc();
  b3.insererHote();
  await b3.ticks(12);
  await b3.api().preparerTout();
  await b3.ticks(8);
  const plans = b3.requetes.filter(r => r.corps.action === 'plan');
  verifier('C5. une requête plan est partie', plans.length, 1);
  if (plans.length) {
    verifier('C5. elle demande tout', plans[0].corps.tout, true);
    verifier('C5. elle demande la résolution des tailles',
      plans[0].corps.resoudre, true);
    verifier('C5. racine_autorisee suit la case, pas autre chose',
      plans[0].corps.racine_autorisee, false);
  }
  vrai('C5. le plan est affiché', !!b3.tous('.psoutils-etapes').length);
  verifier('C5. aucune requête installer n’est partie avant le clic',
    b3.requetes.filter(r => r.corps.action === 'installer').length, 0);
  const textePlan = b3.texte('.psoutils-etapes');
  contient('C5. le résumé du plan est affiché', textePlan, '806.9 Mo');
  contient('C5. la commande apt exacte est affichée', textePlan,
    'pkexec env DEBIAN_FRONTEND=noninteractive apt-get install -y');
  contient('C5. l’étape apt est marquée root', textePlan, 'root · apt');
  contient('C5. la taille de Ghidra est affichée', textePlan, '543.3 Mo');
  contient('C5. la publication résolue est nommée', textePlan,
    'Ghidra_12.2_build');
  contient('C5. l’absence de somme de contrôle est DITE', textePlan,
    'Aucune somme de contrôle');
  contient('C5. la présence d’une somme pour le JDK est DITE', textePlan,
    'Somme SHA-256 publiée');
  contient('C5. une étape non exécutable donne la commande manuelle',
    textePlan, 'sudo apt-get install -y gdb binutils');
  absent('C5. aucun verbe destructeur n’apparaît dans le plan', textePlan,
    'apt-get remove');
  absent('C5. aucune purge dans le plan', textePlan, 'purge');
  contient('C5. les remarques du plan sont affichées', textePlan,
    'ne publie AUCUNE archive');
  vrai('C5. un bouton « Lancer ce plan » existe', !!b3.bouton('Lancer ce plan'));
  await b3.api().lancer(b3.api().etat().planification.identifiants, true, false);
  await b3.ticks(8);
  const inst3 = b3.requetes.filter(r => r.corps.action === 'installer');
  verifier('C5. après le second clic, une requête installer est partie',
    inst3.length, 1);
  if (inst3.length) {
    verifier('C5. elle porte tout=true', inst3[0].corps.tout, true);
    verifier('C5. elle porte les cinq identifiants du plan',
      inst3[0].corps.identifiants.length, 5);
    verifier('C5. racine_autorisee reste faux sans la case',
      inst3[0].corps.racine_autorisee, false);
  }

  /* C6. Vérifier les versions envoie l'action attendue. */
  const b4 = banc();
  b4.insererHote();
  await b4.ticks(12);
  await b4.api().verifierVersions();
  await b4.ticks(6);
  const versions = b4.requetes.filter(r => r.corps.action === 'versions');
  verifier('C6. une requête versions est partie', versions.length, 1);

  /* C7. Arrêter une tâche envoie l'identifiant. */
  await b4.api().demarrerSuivi('abc123');
  await b4.ticks(6);
  await b4.api().arreterTache();
  await b4.ticks(6);
  const arrets = b4.requetes.filter(r => r.corps.action === 'arreter');
  verifier('C7. une requête arreter est partie', arrets.length, 1);
  if (arrets.length) {
    verifier('C7. elle porte l’identifiant de la tâche', arrets[0].corps.sid,
      'abc123');
  }

  /* C8. Un refus du serveur est affiché, pas avalé. */
  const b5 = banc({ installerRefuse: true });
  b5.insererHote();
  await b5.ticks(12);
  await b5.api().lancer(['amont:pasls'], false, false);
  await b5.ticks(8);
  contient('C8. le refus est affiché avec sa raison', b5.texte('.psoutils'),
    'aucune voie automatisable');

  /* C9. Un serveur en panne est annoncé. */
  const b6 = banc({ serveurKo: true });
  b6.insererHote();
  await b6.ticks(10);
  contient('C9. une panne du serveur est annoncée', b6.texte('.psoutils'),
    'Le serveur a cassé');
  faux('C9. une panne ne produit pas de liste d’outils',
    !!b6.tous('.psoutils-ligne').length);

  /* C10. Le filtrage. */
  const b7 = banc();
  b7.insererHote();
  await b7.ticks(12);
  verifier('C10. sept manquants par défaut', b7.lignes().length, 7);
  b7.api().filtrer('filtre', 'tous');
  await b7.ticks(2);
  verifier('C10. huit outils avec le filtre « tous »', b7.lignes().length, 8);
  b7.api().filtrer('filtre', 'installables');
  await b7.ticks(2);
  verifier('C10. cinq installables', b7.lignes().length, 5);
  b7.api().filtrer('famille', 'analyse avancée');
  b7.api().filtrer('filtre', 'tous');
  await b7.ticks(2);
  verifier('C10. le filtre par famille ne garde que la famille',
    b7.lignes().length, 2);
  verifier('C10. le départ est correct', depart > 0, true);
}

async function principal() {
  await scenarioA();
  await scenarioB();
  await scenarioC();
}

principal().then(function () {
  process.stdout.write('smoke_outils_studio : ' + N + ' contrôles, '
    + echecs.length + ' échec(s)\n');
  echecs.forEach(function (e) { process.stdout.write('  ÉCHEC : ' + e + '\n'); });
  process.exit(echecs.length ? 1 : 0);
}).catch(function (exc) {
  process.stdout.write('smoke_outils_studio : le banc a levé ' + exc + '\n');
  process.stdout.write((exc && exc.stack ? exc.stack : '') + '\n');
  process.exit(1);
});
