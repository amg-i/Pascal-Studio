/* Banc de la page de l'assistant : espace de travail et filtre de demande (3.9.0).
 *
 * La page est un seul fichier, avec un script en ligne qui s'exécute au
 * chargement. Trois niveaux de contrôle, du plus large au plus précis.
 *
 *   1. La syntaxe de TOUS les scripts en ligne est compilée sans être exécutée.
 *      Une page cassée ne se voit pas à la lecture : elle s'ouvre sur un écran
 *      vide, et l'utilisateur croit que l'assistant est en panne.
 *   2. Chaque identifiant visé par $('#…') existe vraiment dans le HTML. Un
 *      bouton ajouté sans son id ne casse rien au chargement : il lève au
 *      premier clic, donc jamais pendant un essai rapide.
 *   3. Le code de l'espace est extrait de la page livrée — pas recopié ici —
 *      puis exécuté dans un DOM suffisant, avec des collaborateurs injectés.
 *      Sont exercés le rendu, les dépôts (avec un FileReader qui encode
 *      réellement en base64), les refus, les téléchargements, l'aperçu et la
 *      comparaison « ta demande / prompt envoyé ».
 *
 * Lancer :  node tests/smoke_page_ia.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ICI = __dirname;
const PAGE = path.join(ICI, '..', 'assistant-ia', 'static', 'index.html');

let OK = 0;
let N = 0;
const echecs = [];
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  if (bon) OK += 1;
  else {
    echecs.push(titre + '\n      obtenu  : ' + JSON.stringify(obtenu).slice(0, 220)
      + '\n      attendu : ' + JSON.stringify(attendu).slice(0, 220));
  }
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* ------------------------------------------------------------------- DOM --- */
class Classe {
  constructor(noeud) { this.noeud = noeud; }
  get liste() { return String(this.noeud._className || '').split(/\s+/).filter(Boolean); }
  contains(c) { return this.liste.indexOf(c) >= 0; }
  add(...cs) { const l = this.liste; for (const c of cs) if (l.indexOf(c) < 0) l.push(c);
    this.noeud._className = l.join(' '); }
  remove(...cs) { this.noeud._className = this.liste.filter(c => cs.indexOf(c) < 0).join(' '); }
  toggle(c, force) { const v = force === undefined ? !this.contains(c) : !!force;
    if (v) this.add(c); else this.remove(c); return v; }
}

class Noeud {
  constructor(tag, id) {
    this.tagName = String(tag || 'div').toUpperCase();
    this.id = id || '';
    this.children = [];
    this.parentNode = null;
    this.dataset = {};
    this.style = {};
    this._className = '';
    this._html = '';
    this.textContent = '';
    this.title = '';
    this.value = '';
    this.hidden = false;
    this.disabled = false;
    this.open = false;
    this.options = [];
    this.onclick = null;
    this.onchange = null;
    this.classList = new Classe(this);
  }
  get className() { return this._className; }
  set className(v) { this._className = String(v); }
  get innerHTML() { return this._html; }
  set innerHTML(v) { this._html = String(v); this.children = []; }
  get firstChild() { return this.children[0] || null; }
  get lastChild() { return this.children[this.children.length - 1] || null; }
  appendChild(n) { n.parentNode = this; this.children.push(n); return n; }
  append(...ns) { for (const n of ns) this.appendChild(n); }
  insertBefore(n, ref) {
    const i = ref ? this.children.indexOf(ref) : -1;
    n.parentNode = this;
    if (i < 0) this.children.push(n); else this.children.splice(i, 0, n);
    return n;
  }
  /* beforebegin sur un enfant : le HTML arrive avant lui dans le parent. */
  insertAdjacentHTML(pos, html) {
    if (pos === 'beforebegin' && this.parentNode) {
      this.parentNode._html = String(html) + this.parentNode._html;
      const marque = new Noeud('div');
      marque._className = 'promptopt';
      marque._html = String(html);
      const i = this.parentNode.children.indexOf(this);
      this.parentNode.children.splice(i < 0 ? 0 : i, 0, marque);
      marque.parentNode = this.parentNode;
      return;
    }
    this._html = pos === 'afterbegin' ? String(html) + this._html : this._html + String(html);
  }
  remove() {
    if (!this.parentNode) return;
    this.parentNode.children = this.parentNode.children.filter(c => c !== this);
  }
  replaceChildren(...ns) { this.children = []; for (const n of ns) this.appendChild(n); }
  add(o) { this.options.push(o); }
  click() { if (this.onclick) this.onclick({target: this}); }
  showModal() { this.open = true; }
  close() { this.open = false; }
  querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }
  querySelectorAll(sel) {
    const tous = [];
    const visite = n => { for (const c of n.children) { if (c._match(sel)) tous.push(c); visite(c); } };
    visite(this);
    return tous;
  }
  _match(sel) {
    if (sel[0] === '#') return this.id === sel.slice(1);
    if (sel[0] === '.') return this.classList.contains(sel.slice(1));
    const attr = /^\[([A-Za-z-]+)(?:=["']?([^\]"']*)["']?)?\]$/.exec(sel);
    if (attr) {
      const brut = attr[1];
      const cle = brut.indexOf('data-') === 0 ? brut.slice(5) : brut;
      const dansDataset = Object.prototype.hasOwnProperty.call(this.dataset, cle);
      if (!dansDataset && !Object.prototype.hasOwnProperty.call(this, brut)) return false;
      const valeur = dansDataset ? this.dataset[cle] : this[brut];
      return attr[2] === undefined ? true : String(valeur) === attr[2];
    }
    return this.tagName === sel.toUpperCase();
  }
  closest(sel) {
    let n = this;
    while (n) { if (n._match(sel)) return n; n = n.parentNode; }
    return null;
  }
  /* Utilisé par les assertions : le texte rendu, balises comprises. */
  get texteComplet() {
    return this._html + this.children.map(c => c.texteComplet).join('');
  }
}

function Option(texte, valeur) { this.textContent = texte; this.value = valeur; }

/* Un téléchargement d'espace passe par une ancre, pas par download() : le banc
 * doit donc enregistrer les clics d'ancre, sinon il ne voit rien. */
class Ancre extends Noeud {
  constructor() { super('a'); this.href = ''; this.download = ''; }
  click() { telecharges.push({nom: this.download, href: this.href}); }
}

/* FileReader réel pour le banc : il encode vraiment le contenu en base64, comme
 * le navigateur. Un lecteur factice qui renverrait une constante laisserait
 * passer un dépôt corrompu. */
class FileReader {
  readAsDataURL(fichier) {
    const contenu = Buffer.isBuffer(fichier._octets)
      ? fichier._octets : Buffer.from(String(fichier._octets || ''), 'utf8');
    this.result = 'data:' + (fichier.type || 'application/octet-stream')
      + ';base64,' + contenu.toString('base64');
    setTimeout(() => { if (this.onload) this.onload(); }, 0);
  }
  readAsText(fichier) {
    this.result = String(fichier._octets || '');
    setTimeout(() => { if (this.onload) this.onload(); }, 0);
  }
}
function Fichier(nom, contenu, taille) {
  return {name: nom, type: '', _octets: contenu, size: taille === undefined
    ? Buffer.byteLength(String(contenu)) : taille};
}

/* ------------------------------------------------------------ extraction --- */
const page = fs.readFileSync(PAGE, 'utf8');

function scriptsEnLigne(html) {
  const rx = /<script\b([^>]*)>([\s\S]*?)<\/script>/gi;
  const sortis = [];
  let m;
  while ((m = rx.exec(html)) !== null) {
    if (/\bsrc\s*=/i.test(m[1])) continue;
    sortis.push(m[2]);
  }
  return sortis;
}

const MARQUEUR_ESPACE = '/* ---------- espace de travail par projet (3.9.0) ----------';
const MARQUEUR_MEMOIRE = '/* ---------- mémoire inter-conversations ---------- */';

/* ---------------------------------------------------------------- 1. syntaxe */
const scripts = scriptsEnLigne(page);
verifier('nombre de scripts en ligne dans la page', scripts.length >= 1, true);
let syntaxe = 'conforme';
for (let i = 0; i < scripts.length; i += 1) {
  try { new vm.Script(scripts[i], {filename: 'index.html#script' + i}); }
  catch (e) { syntaxe = 'script ' + i + ' : ' + e.message; }
}
verifier('compilation de tous les scripts en ligne', syntaxe, 'conforme');

/* --------------------------------------------------- 2. cohérence des ids --- */
const code = scripts.join('\n');
const idsVus = new Set();
const rxIds = /\$\(\s*['"]#([A-Za-z0-9_-]+)['"]\s*\)/g;
let m2;
while ((m2 = rxIds.exec(code)) !== null) idsVus.add(m2[1]);
const idsPage = new Set();
const rxHtml = /\bid="([A-Za-z0-9_-]+)"/g;
while ((m2 = rxHtml.exec(page)) !== null) idsPage.add(m2[1]);
const manquants = [...idsVus].filter(id => !idsPage.has(id)).sort();
verifier('identifiants visés par $(\'#…\') absents de la page', manquants, []);

const idNouveaux = ['espbtn', 'espdlg', 'espclose', 'espproj', 'espadd', 'espfile',
  'espdir', 'esprefresh', 'espvol', 'esplist', 'prompt', 'prompt_model'];
verifier('identifiants 3.9.0 absents de la page',
  idNouveaux.filter(id => !idsPage.has(id)), []);

/* ------------------------------------------- 3. marquages de la page livrée */
const MARQUEUR_BOUTON = '<div class="promptopt"><button data-a="prompt" '
  + 'title="Voir le prompt réellement envoyé à l’IA">⚙ demande optimisée · voir</button></div>';
verifier('occurrences du marqueur « demande optimisée · voir »',
  page.split(MARQUEUR_BOUTON).length - 1, 2);
vrai('le marqueur est posé au rechargement (branche meta.prompt)',
  /meta\.prompt\.envoye !== content/.test(page));
vrai('le marqueur est posé pendant le flux (branche ev.modifie)',
  /ev\.modifie && ev\.prompt && !uEl\.querySelector\('\.promptopt'\)/.test(page));
vrai('l’événement ndjson du filtre est géré', /ev\.type === 'optimise'/.test(page));
for (const champ of ['ev.statut', 'ev.modifie', 'ev.prompt', 'ev.modele', 'ev.ms',
  'ev.notes', 'ev.raison']) {
  vrai('le gestionnaire emploie ' + champ,
    new RegExp('optimise[\\s\\S]{0,900}' + champ.replace('.', '\\.')).test(page));
}
vrai('UI_IDS persiste le réglage du filtre',
  /UI_IDS = \[[^\]]*'prompt'[^\]]*'prompt_model'[^\]]*\]/.test(page));
vrai('l’export transmet le projet pour la capture',
  /JSON\.stringify\(\{name, content, fmt, project_id: espProjetCourant\(\)\}\)/.test(page));
vrai('download() accepte une capture explicite',
  /function download\(name, content, mime, capturer\)/.test(page));
vrai('le téléchargement d’un bloc de code est capturé',
  /download\('code\.' \+ ext, blk\.querySelector\('code'\)\.textContent, MIME\[ext\], true\)/.test(page));
vrai('le téléchargement depuis la visionneuse n’est pas capturé',
  /a === 'dl'\) download\(f\.name, f\.content, MIME\[ext\]\);/.test(page));
vrai('le suivi d’étapes réserve une place au filtre',
  /stp = \{route: null, think: null, write: null, prompt: null\}/.test(page));
vrai('le bouton « Espace » est dans la barre latérale',
  /class="sidebtns"[\s\S]{0,200}id="espbtn"/.test(page));
vrai('la fenêtre de l’espace est une grande fenêtre',
  /<dialog id="espdlg" class="big">/.test(page));
vrai('le clic sur le marqueur ouvre la comparaison',
  /closest\('\.promptopt button'\)[\s\S]{0,80}voirPrompt/.test(page));

/* ------------------------------------------------- 4. comportement réel --- */
const debut = page.indexOf(MARQUEUR_ESPACE);
const fin = page.indexOf(MARQUEUR_MEMOIRE);
vrai('le code de l’espace est borné par ses deux marqueurs', debut > 0 && fin > debut);
const blocEspace = page.slice(debut, fin);

const registre = new Map();
function $(sel) {
  const id = sel[0] === '#' ? sel.slice(1) : sel;
  if (!registre.has(id)) registre.set(id, new Noeud('div', id));
  return registre.get(id);
}
const appels = [];
const alertes = [];
let reponses = {confirm: true, prompt: null};
let vues = [];
let telecharges = [];
let presse = [];

function fabriqueContexte() {
  const document = {
    createElement: tag => (String(tag).toLowerCase() === 'a' ? new Ancre() : new Noeud(tag)),
    body: new Noeud('body'),
    querySelector: $,
    querySelectorAll: sel => [$(sel)],
  };
  const sandbox = {
    console,
    setTimeout, clearTimeout, Promise, Buffer,
    encodeURIComponent, decodeURIComponent, Number, String, Boolean, Date, Math,
    JSON, isNaN, Object, Array, Error, RegExp, Set, Map,
    document,
    Option,
    FileReader,
    navigator: {clipboard: {writeText: async t => { presse.push(t); }}},
    URL: {createObjectURL: () => 'blob:essai', revokeObjectURL: () => {}},
    Blob: function (parts) { this.parts = parts; },
    $,
    esc: t => String(t === undefined || t === null ? '' : t)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;'),
    alert: m => alertes.push(String(m)),
    confirm: () => reponses.confirm,
    prompt: () => reponses.prompt,
    openViewer: f => vues.push(f),
    download: (nom, contenu) => telecharges.push({nom, contenu}),
    j: async (chemin, methode, corps) => {
      appels.push({chemin, methode: methode || 'GET', corps});
      const reponse = reponses.j && reponses.j[chemin.split('?')[0]];
      if (reponse instanceof Error) throw reponse;
      return reponse === undefined ? {} : reponse;
    },
    curProj: '',
    projects: [],
    loadProjects: async () => { appels.push({chemin: '/projects', methode: 'GET'}); },
  };
  sandbox.globalThis = sandbox;
  const ctx = vm.createContext(sandbox);
  vm.runInContext(blocEspace, ctx, {filename: 'index.html#espace'});
  return {ctx, sandbox};
}

async function tour() { await new Promise(r => setTimeout(r, 0)); await new Promise(r => setTimeout(r, 0)); }

(async function main() {
  const {ctx, sandbox} = fabriqueContexte();
  const exec = code2 => vm.runInContext('(async () => {' + code2 + '})()', ctx);

  /* --- fonctions utilitaires --- */
  verifier('espTaille(0)', vm.runInContext('espTaille(0)', ctx), '0 o');
  verifier('espTaille(1023)', vm.runInContext('espTaille(1023)', ctx), '1023 o');
  verifier('espTaille(2048)', vm.runInContext('espTaille(2048)', ctx), '2,0 Ko');
  verifier('espTaille(5242880)', vm.runInContext('espTaille(5242880)', ctx), '5,0 Mo');
  vrai('espDate(0) rend une date lisible', vm.runInContext('espDate(0)', ctx).length > 8);
  verifier('espProjetCourant() sans projet', vm.runInContext('espProjetCourant()', ctx), '');
  vm.runInContext('curProj = "__none"', ctx);
  verifier('espProjetCourant() sur « sans projet »',
    vm.runInContext('espProjetCourant()', ctx), '');
  vm.runInContext('curProj = "abc123"', ctx);
  verifier('espProjetCourant() avec un projet',
    vm.runInContext('espProjetCourant()', ctx), 'abc123');

  /* --- espaceCapturer : silencieux sans projet, jamais bloquant --- */
  appels.length = 0;
  vm.runInContext('curProj = ""', ctx);
  vm.runInContext('espaceCapturer("code.py", "print(1)", "essai")', ctx);
  verifier('espaceCapturer sans projet n’appelle rien', appels.length, 0);
  vm.runInContext('curProj = "abc123"', ctx);
  vm.runInContext('espaceCapturer("code.py", "print(1)", "essai")', ctx);
  await tour();
  verifier('espaceCapturer vise la bonne route',
    appels.map(a => a.chemin), ['/espace/enregistrer']);
  verifier('espaceCapturer transmet le projet et le contenu',
    [appels[0].corps.project_id, appels[0].corps.name, appels[0].corps.contenu],
    ['abc123', 'code.py', 'print(1)']);
  appels.length = 0;
  reponses.j = {'/espace/enregistrer': new Error('espace indisponible')};
  let levee = 'aucune';
  try { vm.runInContext('espaceCapturer("x.py", "x", "")', ctx); await tour(); }
  catch (e) { levee = e.message; }
  verifier('un échec de capture ne remonte jamais', levee, 'aucune');
  reponses.j = {};

  /* --- espCharge sans projet : le message explique --- */
  vm.runInContext('curProj = ""', ctx);
  await exec('await espCharge();');
  vrai('sans projet, l’espace explique qu’il faut un projet',
    /propre à chaque projet/.test($('esplist').innerHTML));
  verifier('sans projet, le volume reste vide', $('espvol').textContent, '');

  /* --- espCharge avec projet : listage et rendu --- */
  /* La liste des projets doit exister : espProjets() choisit le projet courant
   * dans le sélecteur, et un sélecteur vide ramène l'espace à « aucun projet ». */
  sandbox.projects = [{id: 'abc123', name: 'Photos 2026'}];
  vm.runInContext('curProj = "abc123"', ctx);
  reponses.j = {'/espace': {
    projet: 'abc123',
    dossiers: [{chemin: 'livrables', nom: 'livrables'}],
    fichiers: [
      {chemin: 'notes.txt', nom: 'notes.txt', dossier: '', octets: 2048,
       modifie: 1794300000, categorie: 'texte', mime: 'text/plain', texte: true,
       origine: 'depot', detail: ''},
      {chemin: 'tableau.xlsx', nom: 'tableau.xlsx', dossier: '', octets: 5242880,
       modifie: 1794300000, categorie: 'tableaux', mime: 'x', texte: false,
       origine: 'export', detail: 'export xlsx'},
    ],
    volume: {octets: 5244928, nombre: 2, quota: 536870912, max_fichier: 33554432},
  }};
  await exec('await espProjets(); await espCharge();');
  verifier('le listage demande le bon projet',
    appels.filter(a => a.chemin.indexOf('/espace?') === 0).map(a => a.chemin),
    ['/espace?project_id=abc123']);
  const lignes = $('esplist').children;
  verifier('une ligne par dossier et par document', lignes.length, 3);
  verifier('les dossiers sont rendus avant les documents',
    lignes.map(l => l.classList.contains('dir')), [true, false, false]);
  vrai('le nom du document figure dans sa ligne', /notes\.txt/.test(lignes[1].innerHTML));
  vrai('la taille est convertie, pas brute', /2,0 Ko/.test(lignes[1].innerHTML));
  vrai('l’origine du document est libellée en français', /déposé/.test(lignes[1].innerHTML));
  vrai('l’origine d’un export est libellée', /export/.test(lignes[2].innerHTML));
  vrai('l’icône suit la famille du document', /📊/.test(lignes[2].innerHTML));
  verifier('un dossier n’a qu’un bouton', lignes[0].children.length, 1);
  verifier('un document a quatre actions', lignes[2].children.length, 4);
  vrai('le volume annoncé est lisible',
    /2 document\(s\) · 1 dossier\(s\) · 5,0 Mo sur 512,0 Mo/.test($('espvol').textContent));

  /* --- réponse incomplète : le projet affiché ne doit pas se perdre --- */
  reponses.j = {'/espace': {}};
  await exec('await espCharge();');
  verifier('une réponse incomplète ne fait pas perdre le projet affiché',
    vm.runInContext('espVue.projet', ctx), 'abc123');
  vrai('une réponse incomplète ne casse pas le rendu',
    $('esplist').innerHTML.length > 0);

  /* --- espace vide --- */
  reponses.j = {'/espace': {projet: 'abc123', dossiers: [], fichiers: [],
    volume: {octets: 0, nombre: 0, quota: 536870912}}};
  await exec('await espCharge();');
  vrai('un espace vide le dit et explique comment le remplir',
    /Espace vide/.test($('esplist').innerHTML));

  /* --- espace inaccessible --- */
  reponses.j = {'/espace': new Error('400 identifiant de projet invalide')};
  await exec('await espCharge();');
  vrai('un espace inaccessible affiche le motif au lieu de rester vide',
    /inaccessible/.test($('esplist').innerHTML));
  reponses.j = {};

  /* --- url de téléchargement : le chemin est encodé --- */
  vm.runInContext('espVue = {projet: "abc123", dossiers: [], fichiers: [], volume: null}', ctx);
  verifier('espUrl encode le projet et le chemin',
    vm.runInContext('espUrl({chemin: "livrables/mon rapport é.txt"})', ctx),
    '/api/espace/fichier?project_id=abc123&chemin=livrables%2Fmon%20rapport%20%C3%A9.txt');

  /* --- aperçu : binaire et texte --- */
  vues = []; telecharges = [];
  reponses.j = {'/espace/apercu': {binaire: true, texte: '', tronque: false}};
  await exec('await espApercu({chemin: "a.zip", nom: "a.zip", texte: true});');
  verifier('un contenu binaire retombe sur le téléchargement', vues.length, 0);
  verifier('un contenu binaire est téléchargé', telecharges.length, 1);
  vues = []; telecharges = [];
  reponses.j = {'/espace/apercu': {binaire: false, texte: '# Titre', tronque: false}};
  await exec('await espApercu({chemin: "n.md", nom: "n.md", texte: true});');
  verifier('un texte s’ouvre dans la visionneuse', vues.map(v => v.name), ['n.md']);
  verifier('le texte aperçu est celui du serveur', vues.map(v => v.content), ['# Titre']);
  vues = []; telecharges = [];
  reponses.j = {'/espace/apercu': {binaire: false, texte: 'coupé', tronque: true}};
  await exec('await espApercu({chemin: "g.txt", nom: "g.txt", texte: true});');
  vrai('un aperçu tronqué le signale dans la visionneuse',
    /tronqué/.test(vues[0].content));
  vues = []; telecharges = [];
  await exec('await espApercu({chemin: "b.png", nom: "b.png", texte: false});');
  verifier('un document non texte ne demande pas d’aperçu', vues.length, 0);
  verifier('un document non texte est téléchargé directement', telecharges.length, 1);
  reponses.j = {};

  /* --- dépôt : encodage réel, refus de taille, échec isolé --- */
  appels.length = 0; alertes.length = 0;
  sandbox.__fichiers = [Fichier('photo.txt', 'contenu de la photo')];
  await exec('await espDepot(globalThis.__fichiers);');
  const depot = appels.filter(a => a.chemin === '/espace/depot');
  verifier('un dépôt vise la bonne route', depot.length, 1);
  verifier('un dépôt est annoncé en base64', depot[0].corps.base64, true);
  verifier('un dépôt transmet le contenu encodé à l’identique',
    depot[0].corps.data, Buffer.from('contenu de la photo', 'utf8').toString('base64'));
  verifier('un dépôt conserve le nom choisi', depot[0].corps.name, 'photo.txt');

  appels.length = 0; alertes.length = 0;
  sandbox.__fichiers = [Fichier('enorme.bin', 'x', 40 * 1024 * 1024)];
  await exec('await espDepot(globalThis.__fichiers);');
  verifier('un fichier au-dessus de 32 Mo n’est pas envoyé',
    appels.filter(a => a.chemin === '/espace/depot').length, 0);
  vrai('un fichier trop lourd est signalé à l’utilisateur',
    alertes.some(a => /32 Mo/.test(a)));

  appels.length = 0; alertes.length = 0;
  sandbox.__fichiers = [Fichier('bon.txt', 'ok'), Fichier('mauvais.txt', 'ko')];
  reponses.j = {'/espace/depot': new Error('quota dépassé')};
  await exec('await espDepot(globalThis.__fichiers);');
  reponses.j = {};
  vrai('un échec de dépôt est nommé avec son motif',
    alertes.some(a => /mauvais\.txt/.test(a) && /bon\.txt/.test(a) && /quota/.test(a)));

  /* --- renommer, supprimer, dossier : les confirmations comptent --- */
  appels.length = 0; reponses.prompt = null;
  await exec('await espRenommer({chemin: "a.txt", nom: "a.txt"});');
  verifier('un renommage annelé n’appelle rien', appels.length, 0);
  reponses.prompt = 'b.txt';
  await exec('await espRenommer({chemin: "a.txt", nom: "a.txt"});');
  verifier('un renommage confirmé vise la bonne route puis actualise',
    appels.map(a => a.chemin), ['/espace/renommer', '/espace?project_id=abc123']);
  verifier('un renommage transmet l’ancien et le nouveau chemin',
    [appels[0].corps.chemin, appels[0].corps.nouveau], ['a.txt', 'b.txt']);

  appels.length = 0; reponses.confirm = false;
  await exec('await espSupprimer({chemin: "b.txt", nom: "b.txt"});');
  verifier('une suppression refusée n’appelle rien', appels.length, 0);
  reponses.confirm = true;
  await exec('await espSupprimer({chemin: "b.txt", nom: "b.txt"});');
  verifier('une suppression confirmée vise la bonne route puis actualise',
    appels.map(a => a.chemin), ['/espace/supprimer', '/espace?project_id=abc123']);
  appels.length = 0;
  await exec('await espSupprimer({chemin: "livrables", nom: "livrables", dossier: true});');
  verifier('la suppression d’un dossier passe par la même route',
    appels.map(a => a.chemin), ['/espace/supprimer', '/espace?project_id=abc123']);

  appels.length = 0; reponses.prompt = '   ';
  await exec('await espDossier();');
  verifier('un dossier au nom vide n’est pas créé', appels.length, 0);
  reponses.prompt = 'livrables/2026';
  await exec('await espDossier();');
  verifier('un dossier est créé avec son chemin',
    [appels[0].chemin, appels[0].corps.chemin], ['/espace/dossier', 'livrables/2026']);

  /* --- voirPrompt : la comparaison, et l’échappement --- */
  const dlg = $('viewdlg');
  const msg = new Noeud('div');
  msg._className = 'msg user';
  msg.dataset.text = 'ma demande';
  vm.runInContext('globalThis.__msg = null', ctx);
  sandbox.__msg = msg;
  dlg.innerHTML = ''; dlg.open = false;
  vm.runInContext('voirPrompt(globalThis.__msg)', ctx);
  verifier('sans prompt enregistré, la comparaison ne s’ouvre pas', dlg.open, false);

  msg.dataset.prompt = 'prompt <b>envoyé</b> & enrichi';
  msg.dataset.text = 'demande <script>alerte</script>';
  dlg.innerHTML = ''; dlg.open = false;
  vm.runInContext('voirPrompt(globalThis.__msg)', ctx);
  verifier('la comparaison s’ouvre', dlg.open, true);
  vrai('les deux textes sont affichés',
    /Ta demande/.test(dlg.innerHTML) && /Prompt réellement envoyé/.test(dlg.innerHTML));
  vrai('la demande est échappée, pas injectée',
    /&lt;script&gt;/.test(dlg.innerHTML) && !/<script>alerte/.test(dlg.innerHTML));
  vrai('le prompt envoyé est échappé',
    /prompt &lt;b&gt;envoyé&lt;\/b&gt; &amp; enrichi/.test(dlg.innerHTML));

  presse = []; telecharges = [];
  const copie = new Noeud('button'); copie.dataset.a = 'copyp';
  dlg.innerHTML = '';
  dlg.appendChild(copie);
  vm.runInContext('globalThis.__dlg = null', ctx);
  sandbox.__dlg = dlg;
  /* Le gestionnaire posé par voirPrompt est réinstallé pour l’essai de clic. */
  vm.runInContext('voirPrompt(globalThis.__msg)', ctx);
  const boutonCopie = new Noeud('button');
  boutonCopie.dataset.a = 'copyp';
  dlg.onclick({target: boutonCopie, closest: () => boutonCopie});
  await tour();
  verifier('copier transmet le prompt réellement envoyé', presse, [msg.dataset.prompt]);
  const boutonDl = new Noeud('button');
  boutonDl.dataset.a = 'dl';
  dlg.onclick({target: boutonDl, closest: () => boutonDl});
  verifier('télécharger propose le prompt envoyé',
    telecharges.map(t => t.contenu), [msg.dataset.prompt]);
  const boutonFermer = new Noeud('button');
  boutonFermer.dataset.a = 'close';
  dlg.onclick({target: boutonFermer, closest: () => boutonFermer});
  verifier('fermer referme la comparaison', dlg.open, false);

  /* --- câblage des boutons --- */
  for (const id of ['espbtn', 'espclose', 'espproj', 'esprefresh', 'espdir',
    'espadd', 'espfile']) {
    const el = $(id);
    vrai('le bouton #' + id + ' est câblé',
      typeof el.onclick === 'function' || typeof el.onchange === 'function');
  }
  vrai('le bouton de dépôt ouvre le sélecteur de fichiers',
    typeof $('espadd').onclick === 'function');

  /* Le sélecteur de fichiers doit se vider, sinon redéposer le même document
   * ne déclenche plus aucun événement. */
  const champ = $('espfile');
  champ.value = 'C:\\essai\\photo.txt';
  champ.files = [Fichier('photo.txt', 'x')];
  appels.length = 0;
  champ.onchange({target: champ});
  for (let i = 0; i < 8; i += 1) { await tour(); }
  verifier('le sélecteur de fichiers est vidé après un dépôt', champ.value, '');
  verifier('le changement de fichier déclenche bien le dépôt',
    appels.filter(a => a.chemin === '/espace/depot').length, 1);

  console.log('');
  if (echecs.length) {
    console.log(echecs.length + ' assertion(s) sur ' + N + ' en échec :');
    for (const e of echecs) console.log('  - ' + e);
    process.exit(1);
  }
  console.log('Banc de la page 3.9.0 : ' + OK + ' assertions sur ' + N
    + ', toutes conformes.');
  process.exit(0);
})().catch(e => {
  console.log('Banc interrompu : ' + (e && e.stack ? e.stack : e));
  process.exit(1);
});
