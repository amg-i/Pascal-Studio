/* Banc de la délégation des panneaux aux vues (4.3.0).
 *
 * CE QUE CE BANC VÉRIFIE, ET POURQUOI CHAQUE CONTRÔLE EXISTE
 *
 *   - LES TROIS PANNEAUX RENDENT DANS UNE VUE, plus dans la barre latérale ni
 *     dans une fenêtre flottante. C'est l'objet de la demande : « que l'onglet
 *     rétro-ingénierie ne soit pas juste un bandeau mais quelque chose qui passe
 *     devant les fichiers ouverts », et pour le navigateur « un onglet, plus de
 *     fenêtre ».
 *   - LA BARRE LATÉRALE REÇOIT UN QUAI, pas le panneau et pas rien. Un hôte vide
 *     laisserait une colonne de 238 pixels muette — le « bandeau » reproché, en
 *     pire. Le quai dit où est le panneau et comment le replier.
 *   - LE REPLI SANS window.PSVues : chaque panneau reprend son comportement
 *     antérieur. Une fonctionnalité ne doit pas disparaître parce qu'un autre
 *     morceau manque (base non patchée, patch refusé).
 *   - LA FERMETURE SUIT L'HÔTE : quand le bundle retire l'hôte latéral — donc
 *     quand l'utilisateur clique une seconde fois sur le bouton de la barre
 *     d'activité — la vue doit être fermée. Sans ça, le panneau resterait affiché
 *     devant les fichiers alors qu'on vient de le refermer.
 *   - LE GARDE DE RECONSTRUCTION de re-studio accepte une racine attachée
 *     AILLEURS. Avant la 4.3.0 il testait `contient(hote, racine)` ; avec une
 *     vue la racine n'est plus dans l'hôte, donc ce garde ne se déclenchait
 *     jamais et le panneau était reconstruit à chaque passage de l'observateur,
 *     en perdant son état toutes les deux secondes.
 *   - LE NAVIGATEUR N'A PLUS QU'UN SEUL BOUTON « MAISON ». Le second menait à
 *     l'origine de l'application, donc à http://localhost:PORT : supprimé sur
 *     demande explicite.
 *
 * Lancer :  node tests/smoke_panneaux_vues.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const MOD = path.join(ICI, '..');

let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 240)
    + '\n      attendu : ' + serie(attendu).slice(0, 240));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* Un PSVues qui enregistre : le banc vérifie ce que les panneaux LUI DEMANDENT,
 * pas ce que vues-studio.js en fait — ça, c'est smoke_vues_studio.js. */
function enregistreur(document) {
  const appels = [];
  const vues = Object.create(null);
  /* La zone est RÉELLE : vues-studio.js attache les noeuds qu'on lui donne. Un
   * enregistreur qui se contente de noter les appels laisserait les panneaux
   * croire que leur noeud n'est attaché nulle part — et ils le reconstruiraient
   * à chaque passage. Le banc mesurerait alors un comportement que le produit
   * n'a pas. */
  const zone = document.createElement('div');
  zone.className = 'ps-vues-zone';
  document.body.appendChild(zone);
  /* isConnected, dans le harnais, remonte jusqu'à `ownerDocumentRoot` : un noeud
   * ajouté APRÈS la fabrication du document ne l'a pas. Sans ce marquage, les
   * panneaux croyaient leur racine détachée et la reconstruisaient à chaque
   * passage — le banc aurait mesuré un défaut du harnais. */
  function marquer(noeud) {
    noeud.ownerDocumentRoot = document.documentElement;
    noeud._ownerDocument = document;
    (noeud.children || []).forEach(marquer);
  }
  marquer(zone);
  return {
    zone: zone,
    appels: appels,
    vues: vues,
    marqueur: 'ps-4.3.0-vues',
    ouvrir: function (opts) {
      appels.push({ methode: 'ouvrir', id: opts.id, titre: opts.titre,
        icone: opts.icone, noeud: !!opts.noeud,
        surFermeture: typeof opts.surFermeture === 'function' });
      vues[opts.id] = opts;
      if (opts.noeud && opts.noeud.parentNode !== zone) {
        zone.appendChild(opts.noeud);
        marquer(opts.noeud);
      }
      return true;
    },
    fermer: function (id) {
      appels.push({ methode: 'fermer', id: id });
      const vue = vues[id];
      delete vues[id];
      if (vue && vue.noeud && vue.noeud.parentNode === zone) vue.noeud.remove();
      if (vue && typeof vue.surFermeture === 'function') vue.surFermeture();
      return true;
    },
    activer: function (id) { appels.push({ methode: 'activer', id: id }); return true; },
    scinder: function (id) { appels.push({ methode: 'scinder', id: id }); return true; },
    masquer: function () { appels.push({ methode: 'masquer' }); return true; },
    mode: function (m) { appels.push({ methode: 'mode', mode: m }); return { mode: m, largeur: 55 }; },
    vues_: function () { return Object.keys(vues); },
    disposition: function () { return { mode: 'plein', largeur: 55, colonnes: [] }; },
    garanties: function () { return {}; },
    synchroniser: function () {},
  };
}

function repondre(action, corps) {
  /* Des réponses minimales mais de la BONNE FORME : un panneau qui reçoit une
   * réponse vide se comporte autrement, et le banc mesurerait autre chose. */
  if (action === '/api/re') {
    switch (corps.action) {
      case 'capacites': return { ok: true, capacites: {
        analyseurs: [], binutils: { presents: [], manquants: [] },
        ghidra: { present: false }, fiches: 0, widgets: 0 } };
      case 'etat': return { ok: true, taches: [] };
      case 'fiches': return { ok: true, fiches: [] };
      case 'widgets': return { ok: true, widgets: [] };
      case 'categories': return { ok: true, categories: [] };
      default: return { ok: true };
    }
  }
  if (action === '/api/tree') return { ok: true, tree: [] };
  if (action === '/api/devweb') {
    /* Le GET de capacités rend l'objet AU NIVEAU RACINE, `viewports` compris :
     * une réponse sans viewports fait lever le panneau (« Cannot read
     * properties of undefined (reading 'id') ») et il affiche son message
     * d'indisponibilité au lieu de se rendre. Le banc mesurerait alors un
     * panneau cassé par sa propre stub. */
    if (!corps.action) {
      return { ok: true, serveur: false, journaux: [], audits: [],
        generateurs: [], inventaire: false, pages: [], extraits: [],
        requetes: [], modeles: [],
        viewports: [{ id: 'portable', largeur: 390, hauteur: 844 },
          { id: 'tablette', largeur: 834, hauteur: 1112 },
          { id: 'bureau', largeur: 1440, hauteur: 900 }] };
    }
    switch (corps.action) {
      case 'capacites': return { ok: true };
      default: return { ok: true };
    }
  }
  if (action === '/api/navigateur') {
    switch (corps.action) {
      case 'etat': return { ok: true, historique: [], signets: [], onglets: [],
        geometrie: {}, capacites: { persistant: true } };
      default: return { ok: true };
    }
  }
  return { ok: true };
}

function bancPanneau(script, opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const document = harnais.document;
  const source = fs.readFileSync(path.join(MOD, script), 'utf8');

  /* L'application telle que le bundle la rend. */
  const corps = document.createElement('div');
  corps.className = 'body';
  const activite = document.createElement('nav');
  activite.className = 'activitybar';
  const laterale = document.createElement('aside');
  laterale.className = 'sidebar';
  if (opts.hote) {
    const hote = document.createElement('div');
    hote.className = opts.hote.replace('.', '');
    laterale.appendChild(hote);
  }
  const principal = document.createElement('main');
  principal.className = 'studio-main';
  corps.append(activite, laterale, principal);
  document.body.appendChild(corps);
  harnais.rafraichir();

  const journal = [];
  const erreursConsole = [];
  /* Les minuteurs sont conservés et joués par le banc : dev web anti-rebondit
   * son rappel d'hôte (`differe('hote', attach, 120)`), donc un setTimeout qui
   * ne rappelle jamais empêcherait attach() de voir l'hôte disparaître. Ce
   * serait un défaut du banc pris pour un défaut du produit. */
  const minuteurs = [];
  const fetchStub = function (url, init) {
    let donnees = {};
    try { donnees = JSON.parse((init && init.body) || '{}'); } catch (e) { donnees = {}; }
    const action = String(url).split('?')[0];
    journal.push({ url: action, action: donnees.action });
    const reponse = repondre(action, donnees);
    return Promise.resolve({ ok: true, status: 200,
      json: function () { return Promise.resolve(reponse); } });
  };

  const Vues = opts.sansPSVues ? null : enregistreur(document);
  const hotesEnregistres = [];
  const sandbox = {
    document: document,
    console: { error: function () { erreursConsole.push([].map(String)
        .call(arguments).join(' ')); }, log: function () {}, warn: function () {} },
    setTimeout: function (fn) { minuteurs.push(fn); return minuteurs.length; },
    clearTimeout: function () {},
    setInterval: function () { return 0; }, clearInterval: function () {},
    fetch: fetchStub,
    localStorage: { getItem: function () { return null; },
      setItem: function () {}, removeItem: function () {} },
    navigator: { clipboard: null, userAgent: 'banc', language: 'fr-FR' },
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise,
    RegExp: RegExp, parseInt: parseInt, parseFloat: parseFloat,
    isFinite: isFinite, encodeURIComponent: encodeURIComponent,
    decodeURIComponent: decodeURIComponent, Map: Map, Set: Set,
    TypeError: TypeError, Error: Error, Uint8Array: Uint8Array,
    MutationObserver: H.MutationObserverStub,
    requestAnimationFrame: function (fn) { fn(); return 1; },
    getSelection: function () { return { removeAllRanges: function () {},
      addRange: function () {} }; },
    location: { origin: 'http://localhost:8765', href: 'http://localhost:8765/' },
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.window.addEventListener = function () {};
  if (Vues) sandbox.PSVues = Vues;
  sandbox.PSHotes = {
    suivre: function (selecteur, rappel) {
      hotesEnregistres.push({ selecteur: selecteur, rappel: rappel });
      return function () {};
    },
    forcer: function () { hotesEnregistres.forEach(function (h) { h.rappel(); }); },
    statistiques: function () { return { observateurs: 1 }; },
  };

  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: script });
  return { sandbox: sandbox, document: document, harnais: harnais, Vues: Vues,
    journal: journal, erreurs: erreursConsole, hotes: hotesEnregistres,
    source: source,
    /* Joue les rappels d'hôte puis les minuteurs qu'ils ont armés. */
    rappeler: function () {
      hotesEnregistres.slice().forEach(function (h) { h.rappel(); });
      const dus = minuteurs.splice(0, minuteurs.length);
      dus.forEach(function (fn) { try { fn(); } catch (e) { /* joué */ } });
    },
    laterale: laterale, activite: activite, principal: principal,
    hote: opts.hote ? laterale.querySelector(opts.hote) : null,
    /* Une macrotâche, pas `Promise.all([Promise.resolve(), …])` : attendre six
     * promesses déjà résolues ne fait passer que deux tours de file de
     * microtâches, alors que la chaîne du panneau est fetch -> json -> then ->
     * rendre. Le banc aurait mesuré un panneau « qui ne rend jamais » pour une
     * histoire d'ordonnancement, et non pour un défaut du produit. */
    ticks: function (n) {
      const attendre = function () {
        return new Promise(function (resoudre) {
          if (typeof setImmediate === 'function') setImmediate(resoudre);
          else setTimeout(resoudre, 0);
        });
      };
      let chaine = attendre();
      for (let i = 1; i < (n || 3); i += 1) chaine = chaine.then(attendre);
      return chaine;
    } };
}

async function joue() {
  /* ==================================================================== */
  /* 1. rétro-ingénierie                                                   */
  /* ==================================================================== */
  let b = bancPanneau('re-studio.js', { hote: '.ps-re-host' });
  b.rappeler();
  await b.ticks(6);
  b.rappeler();
  await b.ticks(6);

  const ouverturesRe = b.Vues.appels.filter(function (a) {
    return a.methode === 'ouvrir';
  });
  vrai('rétro : une vue est ouverte', ouverturesRe.length >= 1);
  verifier('rétro : l’identifiant de la vue', ouverturesRe[0] && ouverturesRe[0].id,
    'retro');
  verifier('rétro : le titre de la vue',
    ouverturesRe[0] && ouverturesRe[0].titre, 'Rétro-ingénierie');
  vrai('rétro : un noeud est fourni', ouverturesRe[0] && ouverturesRe[0].noeud);
  verifier('rétro : la vue n’est ouverte qu’UNE fois malgré plusieurs passages',
    ouverturesRe.length, 1);

  const quaiRe = b.hote.querySelector('.ps-vues-quai');
  vrai('rétro : la barre latérale reçoit un QUAI', !!quaiRe);
  vrai('rétro : le quai explique où est le panneau',
    quaiRe && /devant les fichiers ouverts/.test(quaiRe.textContent));
  vrai('rétro : le quai propose de replier',
    !!(quaiRe && quaiRe.querySelector('[data-acte="replier"]')));
  vrai('rétro : le quai propose de garder l’éditeur à gauche',
    !!(quaiRe && quaiRe.querySelector('[data-acte="basculer"]')));
  vrai('rétro : le PANNEAU N’EST PLUS dans la barre latérale',
    !b.hote.querySelector('.ps-re'));

  /* La fermeture suit l'hôte. */
  b.hote.remove();
  b.harnais.rafraichir();
  b.rappeler();
  await b.ticks(3);
  vrai('rétro : la vue est fermée quand l’hôte disparaît',
    b.Vues.appels.some(function (a) {
      return a.methode === 'fermer' && a.id === 'retro';
    }));

  /* Le repli sans PSVues. */
  b = bancPanneau('re-studio.js', { hote: '.ps-re-host', sansPSVues: true });
  b.rappeler();
  await b.ticks(6);
  vrai('rétro : SANS PSVues, le panneau revient dans la barre latérale',
    !!b.hote.querySelector('.ps-re'));
  vrai('rétro : sans PSVues, aucun quai n’est rendu',
    !b.hote.querySelector('.ps-vues-quai'));

  /* ==================================================================== */
  /* 2. dev web                                                            */
  /* ==================================================================== */
  b = bancPanneau('devweb-studio.js', { hote: '.ps-devweb-host' });
  b.rappeler();
  await b.ticks(6);
  b.rappeler();
  await b.ticks(6);

  const ouverturesDw = b.Vues.appels.filter(function (a) {
    return a.methode === 'ouvrir';
  });
  if (process.env.BANC_BAVARD) {
    console.log('DEBUG devweb : appels=%j hote=%j texte=%j erreurs=%j journal=%j',
      b.Vues.appels, b.hote.children.map(function (c) { return c.className; }),
      b.hote.textContent.slice(0, 200), b.erreurs.slice(0, 3), b.journal.slice(0, 6));
  }
  vrai('dev web : une vue est ouverte (erreurs console : '
    + b.erreurs.slice(0, 2).join(' | ') + ')', ouverturesDw.length >= 1);
  verifier('dev web : l’identifiant de la vue',
    ouverturesDw[0] && ouverturesDw[0].id, 'devweb');
  verifier('dev web : le titre de la vue', ouverturesDw[0] && ouverturesDw[0].titre,
    'Dev web');
  vrai('dev web : un noeud est fourni', ouverturesDw[0] && ouverturesDw[0].noeud);
  const quaiDw = b.hote.querySelector('.ps-vues-quai');
  vrai('dev web : la barre latérale reçoit un QUAI', !!quaiDw);
  vrai('dev web : le quai affiche l’état du panneau',
    quaiDw && /statut/.test(quaiDw.textContent));
  vrai('dev web : le PANNEAU N’EST PLUS dans la barre latérale',
    !b.hote.querySelector('.psdw-panneau'));

  b.hote.remove();
  b.harnais.rafraichir();
  b.rappeler();
  await b.ticks(3);
  vrai('dev web : la vue est fermée quand l’hôte disparaît',
    b.Vues.appels.some(function (a) {
      return a.methode === 'fermer' && a.id === 'devweb';
    }));

  b = bancPanneau('devweb-studio.js', { hote: '.ps-devweb-host', sansPSVues: true });
  b.rappeler();
  await b.ticks(6);
  vrai('dev web : SANS PSVues, le panneau revient dans la barre latérale',
    !!b.hote.querySelector('.psdw-panneau'));

  /* ==================================================================== */
  /* 3. navigateur                                                         */
  /* ==================================================================== */
  const sourceNav = fs.readFileSync(path.join(MOD, 'navigateur-studio.js'), 'utf8');
  vrai('navigateur : la source ne construit plus le bouton « localhost »',
    !/psnav-projet/.test(sourceNav));
  vrai('navigateur : la source explique la suppression',
    /second bouton « maison » est supprimé/.test(sourceNav));
  vrai('navigateur : un seul bouton maison subsiste dans la barre',
    sourceNav.indexOf('psnav-home') > 0
      && sourceNav.split('psnav-home').length - 1 >= 1);
  vrai('navigateur : la source monte une vue déléguée',
    /monterVue\(panneau\)/.test(sourceNav));
  vrai('navigateur : la fermeture est protégée contre la récursion',
    /fermetureEnCours/.test(sourceNav));
  vrai('navigateur : rouvrir met au premier plan au lieu de reconstruire',
    /activerVue\(\)/.test(sourceNav));
  vrai('navigateur : la fenêtre flottante reste le REPLI, pas le défaut',
    /if \(monterVue\(panneau\)\) return panneau;/.test(sourceNav));

  b = bancPanneau('navigateur-studio.js', { hote: null });
  await b.ticks(4);
  const ouvNav = b.Vues.appels.filter(function (a) { return a.methode === 'ouvrir'; });
  vrai('navigateur : cliquer le bouton de la barre d’activité ouvre une vue',
    b.sandbox.PSNavigateur && typeof b.sandbox.PSNavigateur.ouvrir === 'function');
  b.sandbox.PSNavigateur.ouvrir();
  await b.ticks(6);
  const ouvNav2 = b.Vues.appels.filter(function (a) { return a.methode === 'ouvrir'; });
  vrai('navigateur : PSNavigateur.ouvrir() passe par les vues', ouvNav2.length >= 1);
  verifier('navigateur : l’identifiant de la vue',
    ouvNav2[0] && ouvNav2[0].id, 'navigateur');
  verifier('navigateur : le titre de la vue', ouvNav2[0] && ouvNav2[0].titre,
    'Navigateur');
  vrai('navigateur : la fermeture de la vignette est câblée',
    ouvNav2[0] && ouvNav2[0].surFermeture);
  /* La zone du banc est elle-même dans body : le contrôle porte donc sur le
   * PARENT DIRECT, qui est ce que `document.body.append(panneau)` produisait. */
  vrai('navigateur : LE PANNEAU N’EST PLUS UN ENFANT DIRECT DE document.body',
    !Array.prototype.slice.call(b.document.body.children)
      .some(function (n) { return n.className === 'psnav-panel'; }));
  vrai('navigateur : le panneau est dans la zone des vues',
    !!b.Vues.zone.querySelector('.psnav-panel'));
  /* Rouvrir ne reconstruit pas : la page en cours serait perdue. */
  const avant = b.Vues.appels.length;
  b.sandbox.PSNavigateur.ouvrir();
  await b.ticks(4);
  vrai('navigateur : rouvrir appelle activer() et non ouvrir()',
    b.Vues.appels.slice(avant).some(function (a) { return a.methode === 'activer'; })
      || b.Vues.appels.filter(function (a) { return a.methode === 'ouvrir'; }).length === 1);

  /* Fermer depuis la vignette doit persister et couper le relais. */
  b.sandbox.PSNavigateur.fermer();
  await b.ticks(4);
  vrai('navigateur : fermer ne lève pas et détache le panneau',
    !b.Vues.zone.querySelector('.psnav-panel'));

  /* Sans PSVues, la fenêtre flottante revient. */
  b = bancPanneau('navigateur-studio.js', { hote: null, sansPSVues: true });
  b.sandbox.PSNavigateur.ouvrir();
  await b.ticks(6);
  vrai('navigateur : SANS PSVues, la fenêtre flottante est le repli',
    !!b.document.body.querySelector('.psnav-panel'));

  /* ==================================================================== */
  /* 4. les trois panneaux ne posent pas d'observateur en propre            */
  /* ==================================================================== */
  ['re-studio.js', 'devweb-studio.js', 'navigateur-studio.js'].forEach(function (s) {
    const texte = fs.readFileSync(path.join(MOD, s), 'utf8');
    vrai(s + ' : délègue son observation à ps-hotes.js',
      /window\.PSHotes && window\.PSHotes\.suivre/.test(texte));
    vrai(s + ' : aucune sonde à 2 s', !/setInterval\([^)]*,\s*2000\)/.test(texte));
    vrai(s + ' : le repli pose UN seul observateur',
      texte.split('new MutationObserver').length - 1 <= 1);
  });

  /* ==================================================================== */
  /* 5. ce que les sources ne doivent plus contenir                         */
  /* ==================================================================== */
  const re = fs.readFileSync(path.join(MOD, 're-studio.js'), 'utf8');
  const dw = fs.readFileSync(path.join(MOD, 'devweb-studio.js'), 'utf8');
  vrai('rétro : le garde de reconstruction accepte une racine attachée ailleurs',
    /racineAttachee\(\)/.test(re));
  vrai('rétro : le quai est rendu par une fonction nommée',
    /function rendreQuai/.test(re));
  vrai('dev web : le quai est rendu par une fonction nommée',
    /function rendreQuai/.test(dw));
  vrai('rétro : la fermeture de la vue est appelée quand l’hôte disparaît',
    /fermerVue\(\);/.test(re));
  vrai('dev web : la fermeture de la vue est appelée quand l’hôte disparaît',
    /fermerVue\(\)/.test(dw));
}

joue().then(function () {
  console.log('smoke_panneaux_vues : ' + OK + '/' + N + ' contrôles');
  if (echecs.length) {
    console.log('ÉCHECS (' + echecs.length + ') :');
    echecs.forEach(function (e) { console.log('  - ' + e); });
    process.exit(1);
  }
  console.log('Aucun échec.');
}).catch(function (e) {
  console.log('smoke_panneaux_vues : ' + OK + '/' + N + ' contrôles');
  console.log('EXCEPTION du banc : ' + (e && e.stack ? e.stack : String(e)));
  process.exit(1);
});
