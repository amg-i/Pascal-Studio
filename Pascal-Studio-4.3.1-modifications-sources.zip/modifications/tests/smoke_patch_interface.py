#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : les patches du bundle pour les dix langages ésotériques.

Le bundle minifié ne se teste pas comme du code Python, et la suite unittest ne
peut pas en dépendre : il vit dans interface-compilee/, hors de modifications/.
Ce banc est donc un script autonome, comme les huit autres, et il se contente de
signaler son absence s'il ne trouve pas de bundle.

Il vérifie trois choses :

  1. le patcheur reconnaît le bundle comme patché, et plus AUCUNE ancienne ancre
     n'y subsiste — sinon un reconditionnement rejouerait un remplacement sur un
     texte déjà remplacé ;
  2. les fonctions que le patche a modifiées se comportent correctement, en
     extrayant leur source du bundle et en l'exécutant sous node : résolution des
     onze extensions, non-régression sur les 38 fichiers déjà reconnus,
     appartenance aux fichiers source, libellés et badges ;
  3. les droits du bundle restent lisibles par tous. C'est un piège réel :
     tempfile.mkstemp crée en 0600 et os.replace conserve ce mode, donc un
     patcheur qui n'y prend pas garde livre un bundle illisible dans l'AppImage ;
  4. aucune ancienne ancre ne subsiste, y compris celle de l'aperçu web : Piet
     doit figurer dans la liste des langages dont le bouton ouvre la page servie
     par web_preview.py. Sans lui, un programme Piet partirait vers la
     compilation au lieu de s'afficher avec l'inspecteur visuel par-dessus — et
     rien, dans l'interface, ne signalerait l'erreur.
"""

import io
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
RACINE = MODIFICATIONS.parent

ESOTERIQUES = [
    ('apercu.bf', 'brainfuck'), ('x.b', 'brainfuck'),
    ('p.ws', 'whitespace'), ('prog.png', 'piet'), ('a.lol', 'lolcode'),
    ('a.arnoldc', 'arnoldc'), ('a.chef', 'chef'), ('a.spl', 'shakespeare'),
    ('a.i', 'intercal'), ('a.fra', 'fractran'), ('a.mal', 'malbolge'),
]

EXISTANTS = [
    ('a.pas', 'pascal'), ('a.pp', 'pascal'), ('a.inc', 'pascal'),
    ('a.c', 'c'), ('a.h', 'c'), ('a.cpp', 'cpp'), ('a.C', 'cpp'),
    ('a.hpp', 'cpp'), ('a.cs', 'csharp'), ('a.csproj', 'xml'),
    ('Makefile', 'makefile'), ('makefile', 'makefile'), ('GNUmakefile', 'makefile'),
    ('a.mk', 'makefile'), ('CMakeLists.txt', 'cmake'), ('a.cmake', 'cmake'),
    ('a.tex', 'latex'), ('a.sty', 'latex'), ('a.rs', 'rust'), ('a.go', 'go'),
    ('a.rb', 'ruby'), ('a.py', 'python'), ('a.js', 'javascript'),
    ('a.mjs', 'javascript'), ('a.cjs', 'javascript'), ('a.php', 'php'),
    ('a.html', 'html'), ('a.htm', 'html'), ('a.css', 'css'),
    ('a.md', 'markdown'), ('a.f90', 'fortran'), ('a.pl', 'perl'),
    ('a.pm', 'perl'), ('a.bas', 'basic'), ('a.yab', 'basic'), ('a.ml', 'ocaml'),
    ('a.mli', 'ocaml'), ('a.lua', 'lua'), ('a.swift', 'swift'), ('a.kt', 'kotlin'),
    ('a.kts', 'kotlin'), ('notes.txt', 'plaintext'), ('photo.jpg', 'plaintext'),
    ('donnees.csv', 'plaintext'), ('', 'plaintext'),
]

SOURCE = [f for f, _ in ESOTERIQUES] + ['a.pas', 'a.py', 'Makefile', 'a.tex']
PAS_SOURCE = ['notes.txt', 'photo.jpg', 'archive.zip', 'donnees.csv', '']

HARNAIS = """
import { vr, MN, oUe, Fe } from '%s';
let ok = 0, ko = 0;
function verifie(nom, obtenu, attendu) {
  const bon = JSON.stringify(obtenu) === JSON.stringify(attendu);
  bon ? ok++ : ko++;
  // console.log de node ne connaît pas les largeurs de champ à la printf :
  // un gabarit littéral rend le même service sans laisser « %%-28s » à l'écran.
  if (!bon) console.log(`  ECHEC ${nom.padEnd(28)} obtenu=${JSON.stringify(obtenu)} attendu=${JSON.stringify(attendu)}`);
}
const esoteriques = %s;
const existants = %s;
const source = %s;
const pasSource = %s;
for (const [f, id] of esoteriques) verifie('vr ' + f, vr(f), id);
for (const [f, id] of existants) verifie('vr ' + f, vr(f), id);
verifie('vr majuscules', vr('dossier/PROJET.BF'), 'brainfuck');
verifie('vr chemin profond', vr('a/b/c/recette.Chef'), 'chef');
verifie('vr nul', vr(null), 'plaintext');
for (const f of source) verifie('MN ' + f, MN(f), true);
for (const f of pasSource) verifie('MN ' + f, MN(f), false);
for (const [, id] of esoteriques) {
  verifie('oUe ' + id, typeof oUe[id], 'string');
  verifie('Fe ' + id, Array.isArray(Fe[id]) && Fe[id].length, 2);
}
verifie('oUe plaintext conserve', oUe['plaintext'], 'Texte');
verifie('Fe markdown conserve', Fe['markdown'], ['M↓', 'Markdown']);
console.log(`  ${ok}/${ok + ko} vérifications conformes`);
process.exit(ko ? 1 : 0);
"""


def trouver_bundle():
    candidats = sorted((RACINE / 'interface-compilee' / 'assets').glob('index-*.js'))
    return candidats[0] if candidats else None


def extraire(bundle, temporaire):
    """Tire du bundle la source des quatre tables modifiées par le patcheur."""
    texte = io.open(bundle, encoding='utf8', errors='replace').read()
    depart = texte.index('const vr=o=>{')
    fin = texte.index('},sUe=o=>{', depart)
    vr_mn = texte[depart:fin + 1]
    depart = texte.index('oUe={')
    fin = texte.index('};Object.assign(eUe', depart)
    libelles = 'const ' + texte[depart:fin + 1]
    depart = texte.index('Fe={pdf:')
    fin = texte.index('}[Q]', depart)
    # La table seule, sans l'indexation [Q] qui dépend d'une variable locale.
    icones = 'const Fe=' + texte[depart + 3:fin + 1]
    chemin = temporaire / 'extrait.mjs'
    io.open(chemin, 'w', encoding='utf8').write(
        vr_mn + '\n' + libelles + '\n' + icones + ';\nexport {vr,MN,oUe,Fe};\n')
    return chemin


def json_js(valeur):
    """Écrit une valeur Python en littéral JavaScript lisible par node."""
    return json.dumps(valeur, ensure_ascii=False)


def main():
    bundle = trouver_bundle()
    if bundle is None:
        print('Aucun bundle dans interface-compilee/assets : banc ignoré.')
        return 0
    echecs = []

    # 1. le patcheur reconnaît son travail et ne laisserait rien à refaire
    patcheur = MODIFICATIONS / 'patch_interface_3.8.py'
    if not patcheur.is_file():
        print('patch_interface_3.8.py introuvable : banc ignoré.')
        return 0
    resultat = subprocess.run(
        [sys.executable, str(patcheur), '--verifier', str(bundle)],
        capture_output=True, text=True)
    rapport = resultat.stdout.strip()
    if resultat.returncode != 0:
        echecs.append('le bundle n’est pas patché 3.8.0 :\n' + rapport)
    else:
        print('patcheur --verifier : bundle reconnu comme patché')
        for ligne in rapport.splitlines():
            print('  ' + ligne.strip())

    # 1bis. le correctif 4.0.0 (l'assembleur) est appliqué, et le tokenizer
    # qu'il référence existe vraiment à côté du bundle. Sans ce second contrôle,
    # le bundle chargerait un module absent : Monaco retomberait sur une
    # configuration par défaut, sans erreur nulle part.
    patcheur40 = MODIFICATIONS / 'patch_interface_4.0.py'
    if not patcheur40.is_file():
        echecs.append('patch_interface_4.0.py introuvable')
    else:
        resultat = subprocess.run(
            [sys.executable, str(patcheur40), '--verifier', str(bundle)],
            capture_output=True, text=True)
        rapport = resultat.stdout.strip()
        if resultat.returncode != 0:
            echecs.append('le bundle n’est pas patché 4.0.0 :\n' + rapport)
        else:
            print('patcheur 4.0.0 --verifier : assembleur reconnu')
            for ligne in rapport.splitlines():
                print('  ' + ligne.strip())
        tokenizer = bundle.parent / 'asm-studio.js'
        if not tokenizer.is_file():
            echecs.append('asm-studio.js absent à côté du bundle : le chargeur '
                          'du tokenizer importé par le correctif 4.0.0 ne '
                          'trouverait rien')
        else:
            source = MODIFICATIONS / 'monaco-additions' / 'asm-studio.js'
            if source.is_file():
                if tokenizer.read_bytes() != source.read_bytes():
                    echecs.append('asm-studio.js installé diffère de sa source : '
                                  'la coloration livrée ne serait pas celle qui a '
                                  'été engendrée et vérifiée')
                else:
                    print('asm-studio.js : présent et identique à sa source '
                          '(%d octets)' % tokenizer.stat().st_size)
            else:
                echecs.append('monaco-additions/asm-studio.js absent des sources')

    # 2. les droits doivent rester lisibles par tous
    droits = os.stat(bundle).st_mode & 0o777
    if not droits & 0o044:
        echecs.append('bundle en mode %o : illisible pour le groupe et les '
                      'autres, l’AppImage ne pourra pas le charger' % droits)
    else:
        print('droits du bundle : %o' % droits)

    # 3. exécution des tables modifiées, sous node
    if not shutil.which('node'):
        print('node absent : les tables du bundle ne sont pas exécutées.')
    else:
        with tempfile.TemporaryDirectory(prefix='ps-bundle-') as brut:
            temporaire = Path(brut)
            try:
                extrait = extraire(bundle, temporaire)
            except ValueError as erreur:
                echecs.append('extraction impossible, une ancre a disparu du '
                              'bundle : %s' % erreur)
                extrait = None
            if extrait is not None:
                syntaxe = subprocess.run(['node', '--check', str(extrait)],
                                         capture_output=True, text=True)
                if syntaxe.returncode != 0:
                    echecs.append('extrait invalide : ' + syntaxe.stderr[-300:])
                else:
                    script = temporaire / 'harnais.mjs'
                    io.open(script, 'w', encoding='utf8').write(HARNAIS % (
                        extrait, json_js(ESOTERIQUES), json_js(EXISTANTS),
                        json_js(SOURCE), json_js(PAS_SOURCE)))
                    execution = subprocess.run(['node', str(script)],
                                               capture_output=True, text=True)
                    print(execution.stdout.strip())
                    if execution.returncode != 0:
                        # Les premières lignes suffisent à identifier le
                        # problème ; recopier les centaines d'échecs noierait le
                        # reste du rapport.
                        lignes = execution.stdout.strip().splitlines()
                        echecs.append(
                            'tables du bundle :\n      '
                            + '\n      '.join(lignes[:6])
                            + ('\n      … (%d lignes au total)' % len(lignes)
                               if len(lignes) > 6 else ''))

    # 4. aucune ancienne ancre ne subsiste, sinon un reconditionnement
    #    rejouerait un remplacement sur un texte déjà remplacé
    texte = io.open(bundle, encoding='utf8', errors='replace').read()
    for motif in ('/\\.md$/i.test(e)?"markdown":"plaintext"}',
                  '|css|php)$/i.test(e)',
                  'markdown:"Markdown",xml:"XML",plaintext:"Texte"}',
                  'markdown:["M↓","Markdown"]}[Q]',
                  'function iUe(o){const e=["pascal"',
                  '["html","css","php"]'):
        if motif in texte:
            echecs.append('ancienne ancre encore présente : %s' % motif[:52])
    # L'aperçu web doit s'ouvrir pour Piet, en plus des trois langages déjà
    # admis. Le motif est vérifié dans son contexte : un remplacement fait au
    # mauvais endroit ne doit pas pouvoir passer pour conforme.
    apercu = '["html","css","php","piet"].includes(vr('
    if texte.count(apercu) != 1:
        echecs.append('liste de l’aperçu web attendue une fois, trouvée %d : %s'
                      % (texte.count(apercu), apercu))
    else:
        print('aperçu web : Piet admis par le bouton d’aperçu')
    if 'ps-3.8.0-interface' not in texte:
        echecs.append('marqueur ps-3.8.0-interface absent du bundle')
    if not echecs:
        print('aucune ancienne ancre ne subsiste, marqueur présent')

    if echecs:
        print('\n%d problème(s) :' % len(echecs))
        for probleme in echecs:
            print('  - ' + probleme)
        return 1
    print('\nBanc de fumée du bundle : tous les contrôles sont conformes.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
