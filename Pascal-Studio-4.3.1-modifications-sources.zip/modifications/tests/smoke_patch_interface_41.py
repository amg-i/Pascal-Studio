#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc du patcheur d'interface 4.1.0 : l'hôte de la fenêtre Paramètres.

Pourquoi ce banc existe à côté de `patch_interface_4.1.py --verifier`
--------------------------------------------------------------------
    Le vérificateur du patcheur répond sur UN fichier. Ce banc joue la CHAÎNE :
    bundle vierge de la 3.9.0 → patcheur 4.0.0 → patcheur 4.1.0 → assets →
    injections d'index.html, et compare le résultat à l'état de référence de
    cette chaîne. C'est la seule façon de voir trois défauts déjà rencontrés
    ici :

      * une référence produite par N passes n'est pas le produit d'UNE passe.
        Le banc rejoue la chaîne dans un dossier temporaire et compare octet à
        octet avec l'état sauvegardé ;

    QUEL ÉTAT, ET POURQUOI CELUI-LÀ (4.3.0)
        `interface-compilee/` suit la DERNIÈRE livraison : depuis la 4.3.0 son
        bundle porte aussi les substitutions de `patch_interface_4.3.py` et son
        index.html dix injections. Les comparer à une chaîne qui s'arrête en 4.1
        ferait échouer ce banc pour une raison qui n'a rien à voir avec les
        patcheurs 4.0 et 4.1 — et un banc qui échoue pour rien finit par ne plus
        être lu. La cible est donc l'état 4.2.0, conservé dans
        `work/sauvegardes/*.avant-4.3.0`, qui est EXACTEMENT le produit de la
        chaîne 4.0 → 4.1 → inserer-assets-4.2.0. La référence courante, elle,
        est rejouée et comparée par `tests/smoke_patch_interface_43.py`.
      * un patcheur appliqué DEUX fois. L'ancre est consommée par la
        substitution : si le second passage réussissait, il poserait un second
        hôte, et la section des paramètres serait rendue deux fois ;
      * une ancre qui disparaît après une recompilation du bundle. Le banc
        vérifie que le vérificateur rend 2 — « problème » — et pas 1
        (« patchable ») ni 0 (« conforme »), sur un bundle dont l'ancre a été
        retirée. Un vérificateur qui répond « tout va bien » sur un fichier qui
        n'est pas le bon est pire qu'aucun vérificateur.

    Le banc vérifie aussi que le patcheur 4.1.0 ne CASS PAS la 4.0.0 : les seize
    substitutions précédentes et leurs marqueurs doivent survivre.

Lancer :  python3 tests/smoke_patch_interface_41.py
"""

import io
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
WORK = MODIFICATIONS.parent
REFERENCE = WORK / 'interface-compilee'


def _inserer_de_la_chaine():
    """L'inséreur qui produit l'état comparé, jamais « le plus récent ».

    « Le plus récent » était juste tant que la référence courante était le
    produit de cette chaîne. Depuis la 4.3.0, le plus récent injecte dix unités
    et le bundle de référence porte un patcheur de plus : comparer les deux
    ferait échouer le banc sur un écart de VERSION, pas sur un défaut. L'inséreur
    est donc choisi pour aller avec l'état sauvegardé ci-dessous, et son absence
    est une erreur explicite — pas un repli silencieux sur un autre.
    """
    nom = 'inserer-assets-4.2.0.py'
    chemin = MODIFICATIONS / nom
    if not chemin.is_file():
        raise SystemExit('inséreur attendu par ce banc introuvable : %s' % chemin)
    return chemin


INSEREUR = _inserer_de_la_chaine()
VIERGE = WORK / 'sauvegardes' / 'index-BA4XgQVD.js.avant-4.0.0'
# L'état 4.2.0 : produit exact de la chaîne 4.0 → 4.1 → inserer-assets-4.2.0.
ETAT_BUNDLE = WORK / 'sauvegardes' / 'index-BA4XgQVD.js.avant-4.3.0'
ETAT_INDEX = WORK / 'sauvegardes' / 'index.html.avant-4.3.0'
# Les unités que cet inséreur ajoute : le banc les retire pour retrouver un
# index.html vierge de 3.9.0, celui de la base.
INJECTIONS_42 = ('ps-hotes', 'data-studio', 'navigateur-studio', 'devweb-studio',
                 're-studio', 'outils-studio')

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def jouer(commande):
    essai = subprocess.run(commande, capture_output=True, text=True)
    return essai.returncode, (essai.stdout + essai.stderr)


def bundle_de(dossier):
    trouves = [n for n in os.listdir(Path(dossier) / 'assets')
               if n.startswith('index-') and n.endswith('.js')]
    assert len(trouves) == 1, trouves
    return Path(dossier) / 'assets' / trouves[0]


def principal():
    if not VIERGE.is_file():
        ECHECS.append('le bundle vierge de référence est absent : %s' % VIERGE)
        return
    if not REFERENCE.is_dir():
        ECHECS.append('l’arbre de référence est absent : %s' % REFERENCE)
        return
    for chemin in (ETAT_BUNDLE, ETAT_INDEX):
        if not chemin.is_file():
            ECHECS.append('l’état 4.2.0 de référence est absent : %s' % chemin)
            return

    with tempfile.TemporaryDirectory() as temporaire:
        dossier = Path(temporaire)
        shutil.copytree(REFERENCE, dossier / 'ref')
        assets = dossier / 'ref' / 'assets'
        # Repartir du bundle VIERGE, pour rejouer la chaîne entière.
        for nom in os.listdir(assets):
            if nom.startswith('index-') and nom.endswith('.js'):
                (assets / nom).unlink()
        shutil.copy2(VIERGE, assets / 'index-BA4XgQVD.js')
        cible = bundle_de(dossier / 'ref')
        index = dossier / 'ref' / 'index.html'
        # Un index.html vierge de 3.9.0 : celui de l'état 4.2.0 porte déjà les
        # injections, et les rejouer ne prouverait rien. Le banc retire TOUTES
        # les unités que l'inséreur ajoute — y compris ps-hotes.js, seul script
        # sans feuille de style — pour retrouver l'état de départ. En laisser une
        # ferait comparer un index.html à moitié rejoué avec la référence.
        texte_index = io.open(ETAT_INDEX, encoding='utf8').read()
        for nom in INJECTIONS_42:
            texte_index = texte_index.replace(
                '<link rel="stylesheet" href="/assets/%s.css">' % nom, '')
            texte_index = texte_index.replace(
                '<script defer src="/assets/%s.js"></script>' % nom, '')
        texte_index = texte_index.replace(
            '<script src="/assets/aide-assembleur.js"></script>', '')
        io.open(index, 'w', encoding='utf8').write(texte_index)
        verif(all(('/assets/%s.' % nom) not in texte_index
                  for nom in INJECTIONS_42),
              'le banc n’a pas su retirer les injections de l’état 4.2.0 : la '
              'comparaison finale serait vide')

        # ---- 1. le vérificateur a trois états -----------------------------
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              '--verifier', str(cible)])
        verif(code == 1, 'sur le bundle vierge, --verifier doit rendre 1 '
                         '(patchable), reçu %d : %s' % (code, sortie[-200:]))

        # ---- 2. la chaîne : 4.0.0 puis 4.1.0 ------------------------------
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.0.py'),
                              str(cible)])
        verif(code == 0, 'le patcheur 4.0.0 doit s’appliquer sur le bundle '
                         'vierge (%d) : %s' % (code, sortie[-300:]))
        taille_40 = cible.stat().st_size
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              str(cible)])
        verif(code == 0, 'le patcheur 4.1.0 doit s’appliquer après celui de la '
                         '4.0.0 (%d) : %s' % (code, sortie[-300:]))
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              '--verifier', str(cible)])
        verif(code == 0, 'après application, --verifier doit rendre 0 '
                         '(conforme), reçu %d : %s' % (code, sortie[-200:]))

        texte = io.open(cible, encoding='utf8').read()
        verif(texte.count('className:"ps-outils-host"') == 1,
              'l’hôte des paramètres doit être posé EXACTEMENT une fois (%d)'
              % texte.count('className:"ps-outils-host"'))
        verif('"data-marqueur":"ps-4.1.0-interface"' in texte,
              'l’hôte doit porter le marqueur de la version, avec la clef '
              'ENTRE GUILLEMETS : sans eux le bundle entier cesse de se '
              'charger')
        verif('"data-role":"parametres"' in texte,
              'l’hôte doit dire où il vit, pour que le panneau le sache')
        verif('ps-4.1.0-interface' in texte,
              'le marqueur 4.1.0 doit être présent dans le bundle')
        # La 4.0.0 doit avoir survécu.
        verif('ps-4.0.0-interface' in texte,
              'le marqueur 4.0.0 doit survivre au patcheur 4.1.0')
        for hote in ('ps-data-host', 'ps-devweb-host', 'ps-re-host'):
            verif(hote in texte,
                  'l’hôte %s de la 4.0.0 doit survivre' % hote)
        verif(cible.stat().st_size > taille_40,
              'le bundle doit avoir grandi : %d puis %d octets'
              % (taille_40, cible.stat().st_size))

        # ---- 3. l'application est idempotente -----------------------------
        avant = io.open(cible, encoding='utf8').read()
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              str(cible)])
        verif(code == 0 and io.open(cible, encoding='utf8').read() == avant,
              'un second passage ne doit rien changer (%d)' % code)
        verif(io.open(cible, encoding='utf8').read().count(
            'className:"ps-outils-host"') == 1,
              'un second passage ne doit pas poser un second hôte')

        # ---- 3 bis. le bundle entier doit rester du JavaScript valable ----
        # Une clef d'attribut sans guillemets ({data-marqueur:"…"}) casse le
        # bundle COMPLET : un trait d'union n'est pas un identificateur. Aucun
        # contrôle textuel ne le voit, et l'application ne démarrerait plus.
        # node --check valide les 4,4 Mo en une passe ; l'extension .mjs dit à
        # node de lire le fichier comme un module, ce qu'il est.
        module = dossier / 'verifie.mjs'
        shutil.copy2(cible, module)
        code, sortie = jouer(['node', '--check', str(module)])
        verif(code == 0, 'le bundle patché doit rester du JavaScript valable '
                         '(%d) : %s' % (code, sortie[-400:]))
        for cle in ('"data-marqueur":', '"data-role":', 'className:'):
            verif(cle in texte,
                  'la clef %s doit être entre guillemets dans le bundle' % cle)

        # ---- 4. le résultat doit être celui de l'état de référence --------
        reference = ETAT_BUNDLE
        shutil.copy2(reference, dossier / 'reference.mjs')
        code, sortie = jouer(['node', '--check', str(dossier / 'reference.mjs')])
        verif(code == 0, 'le bundle de RÉFÉRENCE doit être du JavaScript '
                         'valable (%d) : %s' % (code, sortie[-400:]))
        verif(io.open(cible, 'rb').read() == io.open(reference, 'rb').read(),
              'le bundle rejoué (4.0 puis 4.1) doit être IDENTIQUE octet à '
              'octet à l’état 4.2.0 sauvegardé : une référence produite en '
              'plusieurs passes ne vaut rien')

        # ---- 5. les six injections ---------------------------------------
        code, sortie = jouer([sys.executable,
                              str(INSEREUR),
                              str(index)])
        verif(code == 0, 'l’injection des assets doit réussir (%d) : %s'
              % (code, sortie[-300:]))
        code, sortie = jouer([sys.executable,
                              str(INSEREUR),
                              str(index), '--verifier'])
        verif(code == 0, 'après injection, --verifier doit être conforme '
                         '(%d) : %s' % (code, sortie[-300:]))
        texte_index = io.open(index, encoding='utf8').read()
        for nom in ('data-studio', 'navigateur-studio', 'devweb-studio',
                    're-studio', 'outils-studio'):
            verif(texte_index.count('/assets/%s.css' % nom) == 1
                  and texte_index.count('/assets/%s.js' % nom) == 1,
                  'la paire %s doit être injectée exactement une fois' % nom)
            verif(texte_index.index('/assets/%s.css' % nom)
                  < texte_index.index('/assets/%s.js' % nom),
                  'pour %s, la feuille de style doit précéder le script' % nom)
        verif('/assets/asm-studio.js' not in texte_index,
              'asm-studio.js est chargé par import() : une balise le chargerait '
              'une seconde fois')
        verif(io.open(index, 'rb').read() == io.open(ETAT_INDEX, 'rb').read(),
              'index.html rejoué doit être IDENTIQUE à celui de l’état 4.2.0 '
              'sauvegardé (%d octets rejoués, %d attendus)'
              % (len(io.open(index, 'rb').read()), ETAT_INDEX.stat().st_size))

        # ---- 6. une ancre disparue est un PROBLÈME, pas un « patchable » --
        casse = dossier / 'casse.js'
        sans_ancre = avant.replace(
            'onChange:O=>Oe({...Ce,wordWrap:O.target.checked})',
            'onChange:O=>Oe({WORDWRAP:O.target.checked})')
        verif(sans_ancre != avant,
              'le banc n’a pas su retirer l’ancre : le contrôle suivant serait '
              'vide')
        io.open(casse, 'w', encoding='utf8').write(sans_ancre)
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              '--verifier', str(casse)])
        verif(code == 0, 'un bundle dont l’hôte est posé doit être dit '
                         'CONFORME même si l’ancre a disparu : c’est '
                         'l’idempotence par signature, reçu %d' % code)
        # Le même, sans l'hôte : l'ancre a disparu, rien ne peut être posé.
        nu = sans_ancre.replace('className:"ps-outils-host"', 'className:"x"')
        io.open(casse, 'w', encoding='utf8').write(nu)
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              '--verifier', str(casse)])
        verif(code == 2, 'une ancre introuvable doit rendre 2 (problème), reçu '
                         '%d : %s' % (code, sortie[-160:]))
        code, sortie = jouer([sys.executable,
                              str(MODIFICATIONS / 'patch_interface_4.1.py'),
                              str(casse)])
        verif(code == 2, 'appliquer sur un bundle sans ancre doit échouer sans '
                         'écrire (%d)' % code)
        verif(io.open(casse, encoding='utf8').read() == nu,
              'un échec ne doit rien écrire')
        code, _sortie = jouer([sys.executable,
                               str(MODIFICATIONS / 'patch_interface_4.1.py'),
                               '--verifier', str(dossier / 'absent.js')])
        verif(code == 2, 'un fichier absent doit rendre 2, reçu %d' % code)


def main():
    try:
        principal()
    except Exception as exc:
        import traceback
        traceback.print_exc()
        ECHECS.append('le banc a levé %s : %s' % (type(exc).__name__, exc))
    print('smoke_patch_interface_41 : %d contrôles, %d échec(s)'
          % (OK + len(ECHECS), len(ECHECS)))
    for echec in ECHECS:
        print('  ÉCHEC : ' + echec)
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
