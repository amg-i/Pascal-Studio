#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de patch_interface_4.3.py — les trois ancrages dans le bundle.

CE QUE CE BANC COUVRE, ET POURQUOI IL EXISTE À CÔTÉ DU VÉRIFICATEUR
  Le vérificateur du patcheur rend trois états sur UN fichier. Ce banc joue les
  choses que le vérificateur ne peut pas voir :

    * le patcheur appliqué à une COPIE, puis `node --check` sur les 4,4 Mo du
      résultat. Une clé d'attribut JSX non quotée (`{data-marqueur:"…"}` au lieu
      de `{"data-marqueur":"…"}`) casse tout le bundle et AUCUN contrôle
      textuel ne le voit : c'est ce qui est arrivé en 4.1.0.
    * l'IDEMPOTENCE réelle : appliquer deux fois ne change pas un octet. Un
      patcheur qui double une injection produit deux hôtes, et le second est
      invisible.
    * le REJEU depuis la sauvegarde vierge donne exactement le même fichier que
      l'arbre de référence. Une référence produite par N passes n'est pas le
      produit d'UNE pass : ce contrôle est celui qui a révélé l'écart en 4.0.0.
    * les TROIS ÉTATS du vérificateur, sur un bundle vierge, un bundle patché,
      un bundle où l'ancre a disparu et un bundle où l'ancre est ambiguë.
      Confondre 0 (conforme) et 1 (patchable) ferait sauter l'application du
      correctif et livrerait une interface sans aucune nouveauté, sans erreur.
    * le SVG N'EST PAS ROUTÉ VERS LA VISIONNEUSE. Il reste du texte éditable
      dans Monaco ; le lui voler serait une régression invisible.
    * les images et les .piett ne sont PAS lus comme du texte à l'ouverture
      d'onglet : sans ça, ouvrir un PNG ferait lire des octets binaires et
      l'onglet ne s'ouvrirait même pas.

Lancer :  python3 tests/smoke_patch_interface_43.py
"""

import io
import os
import shutil
import subprocess
import sys
import tempfile

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
WORK = os.path.abspath(os.path.join(MODIFICATIONS, '..'))
PATCH = os.path.join(MODIFICATIONS, 'patch_interface_4.3.py')
REFERENCE = os.path.join(WORK, 'interface-compilee', 'assets', 'index-BA4XgQVD.js')
VIERGE = os.path.join(WORK, 'sauvegardes', 'index-BA4XgQVD.js.avant-4.3.0')

sys.path.insert(0, MODIFICATIONS)

# Le nom du module porte un POINT (patch_interface_4.3.py) : un `import` normal
# le lirait comme un paquet. Le charger par son chemin est la seule forme qui
# fonctionne, et c'est déjà ce que font les autres bancs pour les modules au nom
# à tirets.
import importlib.util as _util  # noqa: E402

_spec = _util.spec_from_file_location('patch_interface_43', PATCH)
P = _util.module_from_spec(_spec)
_spec.loader.exec_module(P)

OK = 0
N = 0
ECHecs = []


def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    if obtenu == attendu:
        OK += 1
    else:
        ECHecs.append('%s\n      obtenu  : %r\n      attendu : %r'
                      % (titre, obtenu, attendu))


def vrai(titre, condition):
    verifier(titre, bool(condition), True)


def jouer(argv, entree=None):
    essai = subprocess.run([sys.executable, PATCH] + argv,
                           capture_output=True, text=True, input=entree)
    return essai.returncode, (essai.stdout + essai.stderr)


def node_check(chemin):
    if shutil.which('node') is None:
        return None
    copie = chemin + '.mjs'
    shutil.copy2(chemin, copie)
    try:
        essai = subprocess.run(['node', '--check', copie],
                               capture_output=True, text=True)
        return essai.returncode, essai.stderr.strip()[:400]
    finally:
        os.unlink(copie)


def main():
    if not os.path.isfile(PATCH):
        print('ÉCHEC : patch_interface_4.3.py est absent.')
        return 1
    if not os.path.isfile(REFERENCE):
        print('ÉCHEC : le bundle de référence est absent (%s).' % REFERENCE)
        return 1
    if not os.path.isfile(VIERGE):
        print('ÉCHEC : la sauvegarde vierge est absente (%s).' % VIERGE)
        return 1

    dossier = tempfile.mkdtemp(prefix='banc-patch-43-')
    try:
        copie = os.path.join(dossier, 'index.js')
        shutil.copy2(VIERGE, copie)

        # ---- 1. l'état patchable ---------------------------------------
        code, sortie = jouer(['--verifier', copie])
        verifier('un bundle vierge est PATCHABLE (1) et non conforme (0)', code, 1)
        vrai('le rapport nomme les trois substitutions',
             all(nom in sortie for nom in
                 ('hote-onglets', 'hôtes image et piet', 'ouverture sans lire')))

        # ---- 2. l'application ------------------------------------------
        code, sortie = jouer([copie])
        verifier('l’application rend 0', code, 0)
        vrai('l’application annonce les trois changements',
             'ps-onglets-host' in sortie and 'ps-image-host' in sortie
             and 'ps-piet-host' in sortie)

        taille_vierge = os.path.getsize(VIERGE)
        taille = os.path.getsize(copie)
        vrai('le bundle a grandi (%d -> %d)' % (taille_vierge, taille),
             taille > taille_vierge)

        code, sortie = jouer(['--verifier', copie])
        verifier('un bundle patché est CONFORME (0)', code, 0)
        vrai('le rapport dit conforme', 'conforme' in sortie)

        # ---- 3. la syntaxe du bundle -----------------------------------
        resultat = node_check(copie)
        if resultat is None:
            print('  (node absent : la vérification de syntaxe est sautée)')
        else:
            code, erreur = resultat
            verifier('node --check accepte le bundle patché : %s' % erreur, code, 0)

        # ---- 4. les traces ---------------------------------------------
        texte = io.open(copie, encoding='utf-8').read()
        for titre, trace in P.TRACES:
            if trace is None:
                continue
            vrai('trace « %s » présente' % titre, trace in texte)
        vrai('le marqueur de version est présent', P.MARQUEUR in texte)
        vrai('les clefs JSX ajoutées sont QUOTÉES',
             '"data-marqueur":"' + P.MARQUEUR + '"' in texte
             and '"data-role":"onglets-delegues"' in texte)
        vrai('aucune clef JSX nue n’a été introduite',
             '{data-marqueur:' not in texte and '{data-role:' not in texte)

        # ---- 5. l'hôte est DANS la barre d'onglets ---------------------
        position_hote = texte.index('className:"' + P.HOTE + '"')
        position_remplissage = texte.index('className:"tabbar-fill"')
        position_barre = texte.rindex('className:"tabbar"', 0, position_hote)
        vrai('l’hôte précède le remplissage de la barre',
             position_hote < position_remplissage)
        vrai('l’hôte est bien à l’intérieur de div.tabbar',
             position_barre < position_hote < position_remplissage)
        vrai('le remplissage existe toujours (l’ancre a été conservée)',
             texte.count('className:"tabbar-fill"') == 1)

        # ---- 6. les deux hôtes de contenu ------------------------------
        vrai('l’hôte de la visionneuse porte le chemin',
             '{className:"ps-image-host",key:Un.path,"data-path":Un.path}' in texte)
        vrai('l’hôte de l’éditeur Piet porte le chemin',
             '{className:"ps-piet-host",key:Un.path,"data-path":Un.path}' in texte)
        vrai('les deux hôtes sont dans la chaîne de choix du contenu',
             texte.index('ps-piet-host') > texte.index('ps-document-host')
             and texte.index('ps-image-host') > texte.index('ps-data-host') - 10 ** 9)
        # Le SVG reste du texte : la visionneuse ne doit pas le lui voler.
        segment_image = texte[texte.index('ps-image-host') - 320:
                              texte.index('ps-image-host')]
        vrai('LE SVG N’EST PAS ROUTÉ VERS LA VISIONNEUSE',
             'svg' not in segment_image.lower())
        vrai('les extensions routées vers la visionneuse sont nommées',
             'png|jpe?g|gif|bmp|webp|ico|tif?f' in texte)

        # ---- 7. l'ouverture sans lecture texte -------------------------
        vrai('les images ne sont pas lues comme du texte à l’ouverture',
             'piett|png|jpe?g|gif|bmp|webp|ico|tif?f|' in texte
             and 'sqlite3?|db3?|csv|tsv|sql|xlsx|ods)$/i.test(O)?{content:""}' in texte)
        vrai('les PDF et les bases gardent leur comportement',
             'pdf|psnote|piett|png' in texte)
        vrai('le .piett est ouvert sans lecture',
             texte.count('piett') >= 2)

        # ---- 8. l'idempotence ------------------------------------------
        avant = io.open(copie, encoding='utf-8').read()
        code, sortie = jouer([copie])
        verifier('réappliquer rend 0', code, 0)
        vrai('réappliquer annonce « déjà patché »', 'déjà patché' in sortie)
        apres = io.open(copie, encoding='utf-8').read()
        verifier('réappliquer ne change pas un octet', apres, avant)
        verifier('l’hôte n’est pas doublé', apres.count('className:"' + P.HOTE + '"'), 1)
        verifier('la visionneuse n’est pas doublée', apres.count('ps-image-host'), 1)
        verifier('l’éditeur Piet n’est pas doublé', apres.count('ps-piet-host'), 1)

        # ---- 9. le rejeu donne l'arbre de référence --------------------
        code, sortie = jouer(['--verifier', REFERENCE])
        verifier('l’arbre de référence est conforme', code, 0)
        if os.path.getsize(VIERGE) != os.path.getsize(REFERENCE):
            rejoue = os.path.join(dossier, 'rejoue.js')
            shutil.copy2(VIERGE, rejoue)
            jouer([rejoue])
            verifier('le REJEU depuis la sauvegarde vierge donne l’arbre de '
                     'référence octet pour octet',
                     io.open(rejoue, encoding='utf-8').read(),
                     io.open(REFERENCE, encoding='utf-8').read())

        # ---- 10. les refus ---------------------------------------------
        code, sortie = jouer(['--verifier', os.path.join(dossier, 'absent.js')])
        verifier('un fichier absent rend 2', code, 2)
        code, sortie = jouer([])
        verifier('sans argument le patcheur rend 2 et affiche son aide', code, 2)
        vrai('l’aide est affichée sur la sortie d’erreur', 'Usage' in sortie)

        # Une ancre qui a disparu : le patcheur doit refuser, pas deviner. Le
        # fichier de départ est le bundle VIERGE — partir du bundle déjà patché
        # ne retirerait aucune signature et le refus viendrait d'ailleurs, donc
        # le contrôle ne mesurerait pas ce qu'il annonce.
        vierge = io.open(VIERGE, encoding='utf-8').read()
        casse = os.path.join(dossier, 'casse.js')
        io.open(casse, 'w', encoding='utf-8').write(vierge.replace(
            'T.createElement("div",{className:"tabbar-fill"})',
            'T.createElement("div",{className:"autre-chose"})'))
        code, sortie = jouer(['--verifier', casse])
        verifier('une ancre disparue rend 2', code, 2)
        vrai('le rapport nomme la substitution en cause',
             'hote-onglets' in sortie and 'INTROUVABLE' in sortie)
        code, sortie = jouer([casse])
        verifier('rien n’est écrit quand une ancre manque', code, 2)
        verifier('le fichier refusé n’a pas été modifié',
                 io.open(casse, encoding='utf-8').read(),
                 vierge.replace('T.createElement("div",{className:"tabbar-fill"})',
                                'T.createElement("div",{className:"autre-chose"})'))

        # Une ancre ambiguë : deux occurrences, donc un remplacement douteux.
        ambigu = os.path.join(dossier, 'ambigu.js')
        texte_ambigu = vierge.replace(
            'T.createElement("div",{className:"tabbar-fill"})',
            'T.createElement("div",{className:"tabbar-fill"}),'
            'T.createElement("div",{className:"tabbar-fill"})')
        io.open(ambigu, 'w', encoding='utf-8').write(texte_ambigu)
        code, sortie = jouer(['--verifier', ambigu])
        verifier('une ancre ambiguë rend 2', code, 2)
        vrai('le rapport dit combien de fois l’ancre apparaît', '2 fois' in sortie)
        code, sortie = jouer([ambigu])
        verifier('une ancre ambiguë n’est pas appliquée', code, 2)

        # ---- 11. le vérificateur de texte, en direct --------------------
        code, rapport = P.verifier_texte('', 'vide.js')
        verifier('un texte vide rend 2', code, 2)
        code, rapport = P.verifier_texte(avant, 'patche.js')
        verifier('verifier_texte reconnaît un texte conforme', code, 0)
        # Un bundle où une SEULE des trois ancres subsiste n'est pas patchable :
        # accepter de n'en poser qu'une livrerait une visionneuse sans onglet, ou
        # une barre d'onglets sans visionneuse. Le refus est le bon comportement.
        code, rapport = P.verifier_texte(
            'T.createElement("div",{className:"tabbar-fill"})', 'ancre-seule.js')
        verifier('un bundle dont deux ancres manquent est refusé', code, 2)
        vrai('le refus nomme l’ancre manquante',
             any('INTROUVABLE' in ligne for ligne in rapport))
    finally:
        shutil.rmtree(dossier, ignore_errors=True)

    print('smoke_patch_interface_43 : %d/%d contrôles' % (OK, N))
    if ECHecs:
        print('ÉCHECS (%d) :' % len(ECHecs))
        for echec in ECHecs:
            print('  - ' + echec)
        return 1
    print('Aucun échec.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
