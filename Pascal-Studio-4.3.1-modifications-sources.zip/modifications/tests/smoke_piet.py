# -*- coding: utf-8 -*-
"""Tests Piet. Les programmes sont CONSTRUITS ici à partir de la table des
commandes de la spécification, donc leur sortie attendue se dérive à la main.

Table (changement de teinte, changement de luminosité), les deux mesurés dans le
sens DIRECT et cyclique :
    (0,1) push   (0,2) pop    (1,0) add    (1,1) subtract  (1,2) multiply
    (2,0) divide (2,1) mod    (2,2) not    (3,0) greater   (3,1) pointer
    (3,2) switch (4,0) dup    (4,1) roll   (4,2) in(num)
    (5,0) in(ch) (5,1) out(num)            (5,2) out(char)

Les programmes sont des BANDES HORIZONTALES de 1 codel de haut. C'est délibéré :
sans zone blanche résiduelle, le DP n'a nulle part où errer et le programme se
termine dès qu'il dépasse le bord droit, ce qui rend la sortie déterministe.

Lancer :  python3 tests/smoke_piet.py
"""
import sys, os, struct, zlib
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import langages_esoteriques as E   # noqa: E402

OK = 0
N = 0


def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    bon = obtenu == attendu
    OK += bon
    print('  %-56s %s' % (titre, 'CONFORME' if bon else 'DIFFERENT'))
    if not bon:
        print('      obtenu  : %r' % (str(obtenu)[:120],))
        print('      attendu : %r' % (str(attendu)[:120],))


def ecrire_png(largeur, hauteur, pixels):
    """pixels : dict (x, y) -> (r, g, b). Ce qui manque est blanc."""
    brut = bytearray()
    for y in range(hauteur):
        brut.append(0)                              # filtre « None »
        for x in range(largeur):
            brut.extend(pixels.get((x, y), (255, 255, 255)))

    def chunk(type_bloc, donnees):
        corps = type_bloc + donnees
        return (struct.pack('>I', len(donnees)) + corps
                + struct.pack('>I', zlib.crc32(corps) & 0xFFFFFFFF))

    ihdr = struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0)
    return (b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr)
            + chunk(b'IDAT', zlib.compress(bytes(brut), 9))
            + chunk(b'IEND', b''))


def bande(*segments):
    """segments = (couleur, largeur_en_codels). Renvoie un PNG haut de 1 codel."""
    pixels = {}
    x = 0
    for couleur, largeur in segments:
        for k in range(largeur):
            pixels[(x + k, 0)] = couleur
        x += largeur
    return ecrire_png(x, 1, pixels)


# Les 20 couleurs de la spécification, avec leur (teinte, luminosité).
ROUGE = (0xFF, 0x00, 0x00)              # 0,1
ROUGE_CLAIR = (0xFF, 0xC0, 0xC0)        # 0,0
ROUGE_FONCE = (0xC0, 0x00, 0x00)        # 0,2
JAUNE = (0xFF, 0xFF, 0x00)              # 1,1
JAUNE_FONCE = (0xC0, 0xC0, 0x00)        # 1,2
VERT_FONCE = (0x00, 0xC0, 0x00)         # 2,2
MAGENTA = (0xFF, 0x00, 0xFF)            # 5,1
MAGENTA_CLAIR = (0xFF, 0xC0, 0xFF)      # 5,0
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)


def lancer(png, entree='', limite=2000):
    return E.Piet(png, entree=entree).executer(limite=limite)


print('=== décodage PNG ===')
png = ecrire_png(3, 2, {(0, 0): ROUGE, (1, 0): ROUGE_FONCE, (2, 0): MAGENTA})
largeur, hauteur, pixels = E.decoder_png(png)
verifier('dimensions lues', (largeur, hauteur), (3, 2))
verifier('pixels décodés', (pixels[0][0], pixels[0][1], pixels[0][2],
                            pixels[1][0]),
         (ROUGE, ROUGE_FONCE, MAGENTA, BLANC))


def chunk(t, d):
    c = t + d
    return (struct.pack('>I', len(d)) + c
            + struct.pack('>I', zlib.crc32(c) & 0xFFFFFFFF))


# PNG filtré « Sub » : vérifie le dé-filtrage, pas seulement le chemin trivial.
brut = bytearray()
for y in range(2):
    brut.append(1 if y == 0 else 0)
    precedent = 0
    for x in range(3):
        brut.append(((ROUGE if x == 0 else MAGENTA)[0] - precedent) & 0xFF)
        precedent = (ROUGE if x == 0 else MAGENTA)[0]
    brut.extend(b'\x00\x00' * 3 if y == 0 else b'\x00\x00\x00' * 3)
png_filtre = (b'\x89PNG\r\n\x1a\n'
              + chunk(b'IHDR', struct.pack('>IIBBBBB', 3, 2, 8, 2, 0, 0, 0))
              + chunk(b'IDAT', zlib.compress(bytes(brut), 9))
              + chunk(b'IEND', b''))
_l, _h, pix = E.decoder_png(png_filtre)
verifier('dé-filtrage « Sub » sur la ligne 0',
         [pix[0][x][0] for x in range(3)], [0xFF, 0xFF, 0xFF])

print()
print('=== table des commandes, vérifiée par construction ===')
# PRINCIPE : la transition depuis le PREMIER bloc exécute déjà une commande.
# Pour empiler deux valeurs il faut donc DEUX transitions (0,1) successives :
#   rouge(0,1) --(0,1)--> rouge foncé(0,2) --(0,1)--> rouge clair(0,0)
# Chaque push empile la TAILLE du bloc quitté. Ensuite, depuis rouge clair(0,0)
# on choisit la commande par le couple (teinte, luminosité) visé, et on termine
# par out(number) = (5,1).
VERT = (0x00, 0xFF, 0x00)            # teinte 2, luminosité 1
VERT_CLAIR = (0xC0, 0xFF, 0xC0)      # teinte 2, luminosité 0
JAUNE_CLAIR = (0xFF, 0xFF, 0xC0)     # teinte 1, luminosité 0
BLEU_FONCE = (0x00, 0x00, 0xC0)      # teinte 4, luminosité 2

# rouge(0,1) 65 -> rouge foncé(0,2) : (0,1) push 65.
# rouge foncé -> magenta(5,1) : teinte 5, luminosité (1-2)%3=2 -> (5,2) out(char).
r = lancer(bande((ROUGE, 65), (ROUGE_FONCE, 1), (MAGENTA, 1)))
verifier('push 65 puis out(char) -> « A »', r['sortie'], 'A')
r = lancer(bande((ROUGE, 65), (ROUGE_FONCE, 1), (MAGENTA_CLAIR, 1)))
verifier('push 65 puis out(number) -> « 65 »', r['sortie'], '65')

# Deux push puis add (1,0) : depuis rouge clair(0,0) -> jaune clair(1,0).
# Puis out(number) (5,1) : depuis (1,0) -> teinte 0, luminosité 1 -> rouge.
r = lancer(bande((ROUGE, 40), (ROUGE_FONCE, 2), (ROUGE_CLAIR, 1),
                 (JAUNE_CLAIR, 1), (ROUGE, 1)))
verifier('push 40, push 2, add, out(number) -> « 42 »', r['sortie'], '42')

# subtract (1,1) : depuis rouge clair(0,0) -> jaune(1,1).
# out(number) (5,1) depuis (1,1) -> teinte 0, luminosité 2 -> rouge foncé.
r = lancer(bande((ROUGE, 40), (ROUGE_FONCE, 2), (ROUGE_CLAIR, 1),
                 (JAUNE, 1), (ROUGE_FONCE, 1)))
verifier('subtract donne 40-2 et non 2-40', r['sortie'], '38')

# multiply (1,2) : depuis rouge clair(0,0) -> jaune foncé(1,2).
# out(number) (5,1) depuis (1,2) -> teinte 0, luminosité 0 -> rouge clair.
r = lancer(bande((ROUGE, 21), (ROUGE_FONCE, 2), (ROUGE_CLAIR, 1),
                 (JAUNE_FONCE, 1), (ROUGE_CLAIR, 1)))
verifier('push 21, push 2, multiply -> « 42 »', r['sortie'], '42')

# divide (2,0) : depuis rouge clair(0,0) -> vert clair(2,0).
# out(number) (5,1) depuis (2,0) -> teinte 1, luminosité 1 -> jaune.
r = lancer(bande((ROUGE, 84), (ROUGE_FONCE, 2), (ROUGE_CLAIR, 1),
                 (VERT_CLAIR, 1), (JAUNE, 1)))
verifier('push 84, push 2, divide -> « 42 »', r['sortie'], '42')

# mod (2,1) : depuis rouge clair(0,0) -> vert(2,1).
# out(number) (5,1) depuis (2,1) -> teinte 1, luminosité 2 -> jaune foncé.
r = lancer(bande((ROUGE, 7), (ROUGE_FONCE, 5), (ROUGE_CLAIR, 1),
                 (VERT, 1), (JAUNE_FONCE, 1)))
verifier('push 7, push 5, mod -> « 2 »', r['sortie'], '2')

# greater (3,0) : depuis rouge clair(0,0) -> teinte 3, luminosité 0 -> cyan clair.
CYAN_CLAIR = (0xC0, 0xFF, 0xFF)
m = E.Piet(bande((ROUGE, 7), (ROUGE_FONCE, 5), (ROUGE_CLAIR, 1),
                 (CYAN_CLAIR, 1)))
m.executer(limite=50)
verifier('push 7, push 5, greater -> 1 (7 > 5)', m.pile, [1])
m = E.Piet(bande((ROUGE, 5), (ROUGE_FONCE, 7), (ROUGE_CLAIR, 1),
                 (CYAN_CLAIR, 1)))
m.executer(limite=50)
verifier('push 5, push 7, greater -> 0 (5 < 7)', m.pile, [0])

# not (2,2) : depuis rouge foncé(0,2) -> teinte 2, luminosité (2+2)%3=1 -> vert.
m = E.Piet(bande((ROUGE, 1), (ROUGE_FONCE, 1), (VERT, 1)))
m.executer(limite=50)
verifier('push 1 puis not -> 0', m.pile, [0])
m = E.Piet(bande((ROUGE, 0 + 1), (ROUGE_FONCE, 1), (VERT, 1)))
m.executer(limite=50)
verifier('not est bien (2,2) et non un autre couple', m.pile, [0])

# duplicate (4,0) : depuis rouge foncé(0,2) -> teinte 4, luminosité 2 -> bleu foncé.
m = E.Piet(bande((ROUGE, 6), (ROUGE_FONCE, 1), (BLEU_FONCE, 1)))
m.executer(limite=50)
verifier('push 6 puis duplicate -> [6, 6]', m.pile, [6, 6])

# pop (0,2) : depuis rouge foncé(0,2) -> teinte 0, luminosité (2+2)%3=1 -> rouge.
m = E.Piet(bande((ROUGE, 4), (ROUGE_FONCE, 1), (ROUGE, 1)))
m.executer(limite=50)
verifier('push 4 puis pop -> pile vide', m.pile, [])

# switch (3,2) : depuis rouge foncé(0,2) -> teinte 3, luminosité (2+2)%3=1 -> cyan.
CYAN = (0x00, 0xFF, 0xFF)
def stepper(*segments):
    """Charge puis avance d'un pas à la demande, sans la danse de fin."""
    m = E.Piet(bande(*segments))
    m.charger()
    return m


m = stepper((ROUGE, 3), (ROUGE_FONCE, 1), (CYAN, 1))
m.pas(); m.pas()          # push 3, puis switch
verifier('push 3 puis switch(3,2) : CC basculé 3 fois -> droite',
         (m.pile, m.cc), ([], 1))

# pointer (3,1) : depuis rouge foncé(0,2) -> teinte 3, luminosité 0 -> cyan clair.
m = stepper((ROUGE, 1), (ROUGE_FONCE, 1), (CYAN_CLAIR, 1))
m.pas(); m.pas()          # push 1, puis pointer
verifier('push 1 puis pointer(3,1) : DP tourné d’un cran -> bas',
         (m.pile, m.dp), ([], 1))

# roll (4,1) : pile 1,2,3 puis push 3 et push 1, roll -> rotation du haut.
# roll : X est le SOMMET (premier dépilé), Y la profondeur à rouler, et les DEUX
# sont CONSOMMÉS — la pile perd donc deux valeurs. C'est ce détail qui fait que
# l'exemple de la spécification retombe juste : « pile 1,2,3 puis push 3 puis
# push 1 puis roll -> la nouvelle pile est 3,1,2 ». Avec 5 valeurs au départ,
# roll en dépile 2 (il reste 1,2,3) puis fait tourner les 3 du haut d'un cran.
m = stepper((ROUGE, 1))
m.pile = [1, 2, 3, 3, 1]        # 1,2,3 puis push 3 puis push 1
m._executer('roll', {'taille': 1})
verifier('roll : EXEMPLE TEXTUEL de la spécification -> 3,1,2',
         m.pile, [3, 1, 2])
m = stepper((ROUGE, 1))
m.pile = [9, 8, 7, 2, 1]        # X=1, Y=2 : reste [9,8,7], portion [8,7] tourne
m._executer('roll', {'taille': 1})
verifier('roll X=1 Y=2 sur 9,8,7,2,1 -> 9,7,8', m.pile, [9, 7, 8])
m = stepper((ROUGE, 1))
m.pile = [5, 3, 1]              # Y trop grand pour la pile restante -> erreur
m._executer('roll', {'taille': 1})
verifier('roll avec une profondeur excessive -> erreur', m.termine, True)

print()
print('=== déplacement, blancs et noirs ===')
r = lancer(bande((ROUGE, 65), (ROUGE_FONCE, 1), (BLANC, 1),
                 (MAGENTA_CLAIR, 1)))
verifier('un blanc traversé n’exécute aucune commande', r['sortie'], '')
r = lancer(bande((ROUGE, 1), (NOIR, 1)))
verifier('un noir bloque et termine proprement', (r['state'], r['sortie']),
         ('success', ''))
r = lancer(ecrire_png(4, 4, {}))
verifier('image blanche : terminaison propre', r['state'], 'success')

print()
print('=== inspecteur visuel (accroche pour l’aperçu) ===')
png = bande((ROUGE, 65), (ROUGE_FONCE, 1), (MAGENTA, 1))
m = E.Piet(png)
m.charger()
verifier('trois blocs de couleur reconnus', len(m.blocs), 3)
info = m.bloc_actif()
verifier('bloc_actif() expose la couleur et le rectangle en pixels',
         (info['rvb'], info['rectangle'], info['dp'], info['cc']),
         ('#FF0000', [0, 0, 65, 1], 'droite', 'gauche'))
m.executer(limite=1)
info = m.bloc_actif()
verifier('après un pas, la commande est identifiée',
         (info['commande'], info['libelle'], m.pile),
         ('push', 'push (empile la taille du bloc)', [65]))
verifier('codel size deviné à 1', m.taille_codel, 1)

print()
print('=== détection d’erreurs ===')
verifier('PNG invalide', E.Piet(b'pas un png').executer(limite=10)['state'],
         'error')
verifier('source vide', E.Piet(b'').executer(limite=10)['state'], 'error')
r = lancer(bande((ROUGE, 1), (MAGENTA, 1)))
verifier('out(char) sur une pile vide -> erreur', r['state'], 'error')

print()
print('%d/%d vérifications conformes' % (OK, N))
sys.exit(0 if OK == N else 1)
