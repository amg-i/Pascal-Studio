# -*- coding: utf-8 -*-
"""Banc de la source texte Piet (.piett) dans le reste de l'application — 4.3.0.

POURQUOI CE BANC EXISTE
-----------------------
`piet_texte.py` a son propre banc (116 contrôles) et l'éditeur Piet a le sien
(`tests/smoke_images_piet.js`). Ni l'un ni l'autre ne peut voir ce qui se passe
QUAND UN FICHIER .piett EST OUVERT DANS L'IDE : le registre des langages, la
détection par extension, l'analyse en direct, le bouton « Exécuter », le
débogueur pas à pas et l'index de l'aide. C'est exactement là que se logent les
intégrations cassées : un fichier reconnu par l'éditeur mais « langage inconnu »
partout ailleurs, ou l'inverse.

LES TROIS PIÈGES QUE CE BANC GARDE FERMÉS
-----------------------------------------
1. UNE ENTRÉE DISTINCTE, PAS UNE EXTENSION DE PLUS. Ajouter '.piett' à l'entrée
   « piet » aurait suffi pour la détection, mais `server.analyser_en_direct()`
   convertit le contenu en BINAIRE dès que `resoudre(kind) == 'piet'` — juste
   pour un PNG, destructeur pour une source texte. Le banc contrôle donc que
   `.piett` résout en `piet_texte` et que la garde binaire de server.py porte
   toujours sur le seul identifiant « piet ».
2. PAS UN ONZIÈME LANGAGE ÉSOTÉRIQUE. `piet_texte` n'est ni dans `MOTEURS` ni
   dans `ORDRE_ESOTERIQUES` : les bancs des dix langages itèrent ces deux
   tableaux, et un onzième élément y ferait lever des KeyError en cascade. Son
   pas à pas passe par `piet_texte.pas_a_pas()`, qui rend une instance du moteur
   Piet EXISTANT. Le banc vérifie les deux côtés : absent des tableaux, présent
   dans le routage du multiplexeur.
3. AUCUN REFUS SILENCIEUX. `test_debogueur_universel` exige qu'aucun langage du
   registre ne tombe en MODE_AUCUN. Un `.piett` sans mode aurait cassé ce
   contrat ; avec `graphique=True` il est en mode visuel, et le banc contrôle que
   la liste des langages sans débogage n'a pas bougé.

Lancer :  cd work/modifications && export PYTHONPATH=$PWD \\
          && python3 tests/smoke_piett_langage.py
"""
import io
import os
import sys
import tempfile
from pathlib import Path

RACINE = Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, str(RACINE))

import bac_a_sable                                  # noqa: E402
import capacites_aide                               # noqa: E402
import debogueur_universel as D                     # noqa: E402
import debug_mux                                    # noqa: E402
import langages                                     # noqa: E402
import langages_esoteriques as E                    # noqa: E402
import piet_texte                                   # noqa: E402
import polyglot                                     # noqa: E402
import verificateurs_statiques as VS                # noqa: E402

OK = 0
N = 0
ECHOUES = []


def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    bon = obtenu == attendu
    OK += bon
    print('  %-62s %s' % (titre, 'CONFORME' if bon else 'DIFFERENT'))
    if not bon:
        detail = ('      obtenu  : %r\n      attendu : %r'
                  % (str(obtenu)[:200], str(attendu)[:200]))
        print(detail)
        ECHOUES.append(titre)


def lire(nom):
    return io.open(RACINE / nom, encoding='utf8').read()


EXEMPLE = piet_texte.exemple()
INVALIDE = 'piet 1\ncodel 4\ngrille 2 1\nzz yy\n'

print()
print('=== 1. le registre des langages ===')
verifier('le registre compte 41 langages', len(langages.tous()), 41)
verifier('« piet_texte » est dans le registre', 'piet_texte' in langages.tous(), True)
verifier('« piet » est toujours dans le registre', 'piet' in langages.tous(), True)
entree = langages.langage('piet_texte')
verifier('le libellé distingue la source du PNG', entree.libelle,
         'Piet (source texte)')
verifier('l’extension reconnue est .piett', tuple(entree.extensions), ('.piett',))
verifier('le PNG reste l’extension de « piet »',
         tuple(langages.langage('piet').extensions), ('.png',))
verifier('le vérificateur est celui de l’analyse en direct',
         tuple(entree.verificateur), ('verificateurs_statiques', 'analyze'))
verifier('le langage est déclaré graphique (donc jamais MODE_AUCUN)',
         entree.graphique, True)
verifier('la bibliothèque de complétions est celle de Piet', entree.bibliotheque,
         'piet')
verifier('la remarque dit que le PNG est la forme COMPILÉE',
         'COMPILÉE' in entree.remarque, True)
verifier('la remarque dit qu’aucun second moteur n’est introduit',
         'aucun second moteur' in entree.remarque, True)

print()
print('=== 2. la résolution et la détection par extension ===')
verifier('resoudre(".piett")', langages.resoudre('.piett'), 'piet_texte')
verifier('resoudre("piett")', langages.resoudre('piett'), 'piet_texte')
verifier('resoudre(".PIETT") — la casse ne compte pas',
         langages.resoudre('.PIETT'), 'piet_texte')
verifier('resoudre(".png") reste Piet', langages.resoudre('.png'), 'piet')
verifier('polyglot.kind("projet/programme.piett")',
         polyglot.kind('projet/programme.piett'), 'piet_texte')
verifier('polyglot.kind("projet/PROGRAMME.PIETT")',
         polyglot.kind('projet/PROGRAMME.PIETT'), 'piet_texte')
verifier('polyglot.kind("projet/programme.png")',
         polyglot.kind('projet/programme.png'), 'piet')
# kind() ne rend la branche ésotérique que si debogueur == 'esoterique' ; la
# source texte Piet a une branche explicite, sans quoi elle rendrait None et un
# .piett n'aurait aucune analyse en direct.
verifier('la branche explicite existe dans polyglot.kind()',
         "if piet_texte=='piet_texte':return piet_texte" in lire('polyglot.py'), True)

print()
print('=== 3. l’analyse en direct ===')
analyse = VS.analyze('piet_texte', 'projet/p.piett', 'p.piett', EXEMPLE)
verifier('un programme valide est analysé', analyse['state'], 'ready')
verifier('un programme valide ne rend aucune erreur', analyse['ok'], True)
verifier('le libellé de l’analyse est celui de la source texte',
         'Piet (source texte)' in analyse['message'], True)
verifier('une remarque de structure est ajoutée (blocs, codel, grille)',
         any('bloc(s) de couleur' in d['message'] for d in analyse['diagnostics']),
         True)
verifier('la remarque de structure est une info, pas une erreur',
         [d['severity'] for d in analyse['diagnostics']], ['info'])
invalide = VS.analyze('piet_texte', 'projet/p.piett', 'p.piett', INVALIDE)
verifier('une couleur inconnue rend ok=False', invalide['ok'], False)
# Deux erreurs, et c'est juste : la couleur « zz » est refusée ligne 4, et comme
# c'était la seule ligne de grille, le décodeur annonce aussi qu'il ne reste
# aucune grille. Ne contrôler que la première cacherait la seconde.
verifier('les erreurs portent leurs lignes, dans l’ordre du décodage',
         [d['line'] for d in invalide['diagnostics'] if d['severity'] == 'error'],
         [4, 1])
verifier('la couleur refusée est localisée précisément',
         [(d['line'], d['column']) for d in invalide['diagnostics']
          if 'zz' in d['message']], [(4, 1)])
verifier('le diagnostic nomme la couleur refusée',
         any('zz' in d['message'] for d in invalide['diagnostics']), True)
verifier('l’absence de grille restante est annoncée elle aussi',
         any('Aucune ligne de grille' in d['message'] for d in invalide['diagnostics']),
         True)
vide = VS.analyze('piet_texte', 'projet/p.piett', 'p.piett', '')
verifier('une source vide est refusée avec une raison', vide['ok'], False)
verifier('une source vide dit quoi faire',
         any('grille' in d['message'] for d in vide['diagnostics']), True)
verifier('l’analyse ne lève jamais, même sur du bruit',
         VS.analyze('piet_texte', 'p.piett', 'p.piett', '\x00\x01\xff')['state'],
         'ready')
# Le PNG n'a pas changé de comportement : l'analyseur dit que c'est une image.
png_vide = VS.analyze('piet', 'projet/p.png', 'p.png', '')
verifier('« piet » (PNG) garde son analyse d’image',
         any('image PNG' in d['message'] for d in png_vide['diagnostics']), True)
# La garde binaire de server.py : c'est elle qui rend l'entrée distincte
# nécessaire. Si un jour elle porte sur autre chose que 'piet', une source
# .piett serait convertie en binaire avant analyse.
source_server = lire('server.py')
verifier('server.py ne convertit en binaire que pour « piet »',
         "if langages.resoudre(kind)=='piet':" in source_server, True)
verifier('server.py ne convertit jamais « piet_texte » en binaire',
         "resoudre(kind)=='piet_texte'" in source_server, False)

print()
print('=== 4. le débogueur pas à pas ===')
verifier('le mode de débogage est visuel', D.mode('piet_texte'), D.MODE_VISUEL)
verifier('le mode se résout aussi depuis l’extension', D.mode('.piett'),
         D.MODE_VISUEL)
capacites = D.capacites('piet_texte')
verifier('le pas à pas est annoncé', capacites['pas_a_pas'], True)
verifier('les variables sont annoncées', capacites['variables'], True)
verifier('la pile est annoncée', capacites['pile'], True)
verifier('le débogage est annoncé disponible', capacites['disponible'], True)
verifier('l’explication dit que le fichier est la SOURCE',
         'SOURCE' in capacites['explication'], True)
verifier('l’explication nomme l’éditeur Piet',
         'éditeur Piet' in capacites['explication'], True)
verifier('aucun langage du registre n’est retombé en MODE_AUCUN',
         sorted(i for i in langages.tous() if D.mode(i) == D.MODE_AUCUN),
         ['csproj', 'json', 'plaintext'])

dossier = Path(tempfile.mkdtemp(prefix='ps-banc-piett-'))
(dossier / 'bon.piett').write_text(EXEMPLE, encoding='utf8')
(dossier / 'mauvais.piett').write_text(INVALIDE, encoding='utf8')

verifier('le multiplexeur route .piett vers la session intégrée',
         debug_mux.esoterique('piet_texte'), True)
verifier('le routage accepte aussi l’extension', debug_mux.esoterique('.piett'),
         True)
verifier('le routage ne prend pas un langage ordinaire',
         debug_mux.esoterique('python'), False)
verifier('le routage laisse Piet (PNG) passer par la même session',
         debug_mux.esoterique('piet'), True)

multiplexe = debug_mux.DebuggerMux(str(dossier), {})
multiplexe.select('piet_texte')
verifier('la session choisie est bien celle des moteurs intégrés',
         type(multiplexe.current).__name__, 'DebogueurEsoterique')
multiplexe.demarrer('piet_texte', 'bon.piett', [])
instantane = multiplexe.snapshot()
verifier('la session s’ouvre avant la première commande', instantane['state'],
         'paused')
verifier('le moteur est celui de Piet, inchangé',
         type(multiplexe.current.moteur).__name__, 'Piet')
verifier('le moteur vient de langages_esoteriques',
         type(multiplexe.current.moteur).__module__, 'langages_esoteriques')
verifier('aucune commande n’a encore été exécutée',
         multiplexe.current.moteur.pas_fait, 0)
multiplexe.action('finish')
fini = multiplexe.snapshot()
verifier('l’exécution pas à pas produit la sortie du programme',
         fini.get('output', ''), '1')
verifier('la session se termine proprement', fini['state'], 'exited')
multiplexe.stop()

refus = None
try:
    mauvais = debug_mux.DebuggerMux(str(dossier), {})
    mauvais.select('piet_texte')      # sans select(), c'est le débogueur par
    mauvais.demarrer('piet_texte', 'mauvais.piett', [])   # défaut qui répond
except ValueError as exc:
    refus = str(exc)
verifier('une source invalide est refusée', refus is not None, True)
verifier('le refus dit « Programme refusé »', 'Programme refusé' in (refus or ''),
         True)
verifier('le refus nomme la couleur inconnue', 'zz' in (refus or ''), True)
verifier('le refus donne la ligne fautive', 'ligne 4' in (refus or ''), True)
verifier('le refus cite au plus trois erreurs, pas tout le fichier',
         (refus or '').count('(ligne'), 2)

print()
print('=== 5. le bouton « Exécuter » (bac à sable) ===')
verifier('rien à installer pour exécuter un .piett',
         bac_a_sable.disponible('piet_texte'), (True, ''))
etat = bac_a_sable.etat('piet_texte')
verifier('l’état annonce le langage disponible', etat['disponible'], True)
verifier('l’état annonce le moteur local intégré, pas un dossier temporaire',
         'moteur local intégré' in etat['message'], True)
verifier('le libellé affiché est celui de la source texte', etat['libelle'],
         'Piet (source texte)')
essai = bac_a_sable.essayer('piet_texte', EXEMPLE)
verifier('l’exemple s’exécute', essai['etat'], 'succes')
verifier('l’exemple écrit « 1 »', essai['sortie'], '1')
verifier('le compte rendu dit par quoi il est exécuté', essai['commande'],
         'moteur local intégré')
verifier('le compte rendu donne le nombre d’instructions',
         'instruction(s)' in essai['message'], True)
verifier('la durée est mesurée', essai['duree_ms'] >= 0, True)
echec = bac_a_sable.essayer('piet_texte', INVALIDE)
verifier('une source invalide échoue sans lever', echec['etat'], 'echec')
verifier('l’échec porte les diagnostics dans « erreur »',
         'zz' in echec['erreur'], True)
verifier('un .piett vide est refusé avec une raison',
         bac_a_sable.essayer('piet_texte', '')['message'], 'Aucun code à tester.')

print()
print('=== 6. l’index de l’aide ===')
fiche = capacites_aide.capacites('piet_texte')
verifier('la fiche existe', fiche is not None, True)
verifier('la catégorie reste « classique » : ce n’est pas un 11e ésotérique',
         fiche['categorie'], 'classique')
verifier('la facette « analyse » est annoncée', 'analyse' in fiche['facettes'], True)
verifier('la facette « débogage » est annoncée', 'debogage' in fiche['facettes'],
         True)
verifier('la facette « aperçu » est annoncée', 'apercu' in fiche['facettes'], True)
verifier('la facette « exécution » est annoncée', 'execution' in fiche['facettes'],
         True)
verifier('« piet_texte » n’est pas dans l’ordre d’affichage des dix',
         'piet_texte' in E.ORDRE_ESOTERIQUES, False)
verifier('« piet_texte » n’a pas de moteur propre dans MOTEURS',
         'piet_texte' in E.MOTEURS, False)
verifier('les dix langages ésotériques sont toujours dix',
         len(E.ORDRE_ESOTERIQUES), 10)
verifier('est_esoterique("piet_texte") reste faux (c’est une source, pas un '
         'langage de plus)', E.est_esoterique('piet_texte'), False)

print()
print('=== 7. la cohérence avec l’interface ===')
nouveau = lire('nouveau-fichier.js')
verifier('le dialogue « nouveau fichier » propose .piett',
         "ext: '.piett'" in nouveau, True)
verifier('l’extension du dialogue est celle du registre',
         ".piett" in nouveau and '.piett' in entree.extensions, True)
verifier('l’éditeur Piet vise le bon hôte',
         "'.ps-piet-host" in lire('piet-studio.js')
         or '".ps-piet-host' in lire('piet-studio.js'), True)
correctif = lire('patch_interface_4.3.py')
verifier('le bundle route .piett vers l’hôte Piet',
         'ps-piet-host' in correctif, True)
verifier('le test d’extension du bundle porte sur .piett',
         '/\\\\.(piett)$/i.test(Un.path)' in correctif, True)
# L'ordre compte : `.ps-piet-host` est testé AVANT `.ps-image-host`, donc un
# PNG reste une image et un .piett reste un programme.
position_piet = correctif.index('ps-piet-host')
position_image = correctif.index('ps-image-host', position_piet)
verifier('l’hôte Piet est choisi avant la visionneuse',
         position_piet < position_image, True)
verifier('le SVG reste à Monaco dans le correctif du bundle',
         'svg' not in correctif.split('NOUVEAU_CONTENU = ')[1]
         .split('ANCRE_OUVERTURE')[0].lower(), True)

print()
print('%d/%d vérifications conformes' % (OK, N))
if ECHOUES:
    print('ÉCHECS (%d) :' % len(ECHOUES))
    for titre in ECHOUES:
        print('  - ' + titre)
sys.exit(0 if OK == N else 1)
