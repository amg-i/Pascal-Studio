/* Banc du registre partagé des hôtes (4.2.0).
 *
 * Ce que ce banc vérifie, et pourquoi chaque contrôle existe :
 *
 *   - UN SEUL observateur pour N enregistrements. C'est tout l'objet du
 *     fichier : avant, cinq scripts posaient cinq observateurs sur
 *     document.documentElement et cinq sondes à 2 s, et un bouton latéral
 *     mettait plusieurs secondes à changer l'affichage.
 *   - AU PLUS UN PASSAGE PAR LOT de mutations. Sans regroupement, N mutations
 *     produiraient N passages, ce qui est exactement ce que faisaient les cinq
 *     observateurs chacun de leur côté.
 *   - Un rappel qui LÈVE ne coupe pas les autres, et il est mis en veille après
 *     un nombre borné d'erreurs — un panneau cassé ne doit pas rendre les quatre
 *     autres inutilisables, ni boucler indéfiniment.
 *   - `takeRecords()` est appelé avant de jouer les rappels : sans cela, les
 *     écritures d'un panneau réveillent l'observateur et chaque mutation coûte
 *     deux passages.
 *   - Le repli : sans PSHotes, chaque script posé par corriger-hotes-partages.py
 *     doit observer lui-même, sinon les bancs d'interface ne mesureraient plus
 *     rien et un panneau livré sans ps-hotes.js serait mort.
 *
 * Lancer :  node tests/smoke_ps_hotes.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'ps-hotes.js');
const source = fs.readFileSync(SCRIPT, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 240)
    + '\n      attendu : ' + serie(attendu).slice(0, 240));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

function banc(opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const observateurs = [];
  const sondes = [];
  const frames = [];
  const Origine = H.MutationObserverStub;
  function ObservateurCompte(cb) {
    const instance = new Origine(cb);
    observateurs.push(instance);
    return instance;
  }
  ObservateurCompte.prototype = Origine.prototype;
  const erreurs = [];
  const sandbox = {
    document: harnais.document,
    console: { error: (...a) => erreurs.push(a.map(String).join(' ')),
      log: () => {}, warn: () => {} },
    setTimeout: (fn) => { sondes.push(fn); return sondes.length; },
    clearTimeout: () => {},
    setInterval: (fn, delai) => { sondes.push({ fn: fn, delai: delai });
      return sondes.length; },
    clearInterval: () => {},
    requestAnimationFrame: opts.sansRaf ? undefined
      : (fn) => { frames.push(fn); return frames.length; },
    Date: Date, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, TypeError: TypeError, Error: Error,
    JSON: JSON, Promise: Promise,
    MutationObserver: ObservateurCompte,
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 'ps-hotes.js' });
  return {
    api: sandbox.PSHotes, observateurs: observateurs, sondes: sondes,
    frames: frames, erreurs: erreurs, harnais: harnais,
    jouerFrames: () => { const lot = frames.splice(0, frames.length);
      lot.forEach(f => f()); },
    declencher: () => H.declencherObservateurs(),
    /* Un lot complet : jouer ce qui est en attente (ce qui remet `demande` à
     * faux), vider les compteurs, déclencher les observateurs, jouer. */
    lot: function (raz) {
      const lot = frames.splice(0, frames.length);
      lot.forEach(f => f());
      frames.length = 0;
      /* Les compteurs sont remis à zéro APRÈS le passage en attente et AVANT
       * le déclenchement : sinon le banc compterait deux passages pour un. */
      if (typeof raz === 'function') raz();
      H.declencherObservateurs();
      const suivant = frames.splice(0, frames.length);
      suivant.forEach(f => f());
      return suivant.length;
    }
  };
}

/* ---------------------------------------------------------------- scénarios -- */

function principal() {
  /* 1. Un observateur, une sonde, quel que soit le nombre de panneaux. */
  const b = banc();
  vrai('1. PSHotes est publié', b.api && b.api.marqueur);
  verifier('1. le marqueur est celui de la version', b.api.marqueur,
    'ps-4.2.0-hotes');
  verifier('1. un seul observateur au démarrage', b.observateurs.length, 1);
  const rappels = [];
  const arrets = [];
  for (let i = 0; i < 5; i += 1) {
    const indice = i;
    arrets.push(b.api.suivre('.hote-' + i, () => { rappels.push(indice); }));
  }
  verifier('1. cinq enregistrements, toujours UN seul observateur',
    b.observateurs.length, 1);
  verifier('1. une seule sonde de secours', b.sondes.filter(s => s && s.delai)
    .length, 1);
  verifier('1. la sonde de secours est à 5 s, pas à 2 s',
    b.sondes.filter(s => s && s.delai)[0].delai, 5000);
  /* À l'enregistrement, un passage est DEMANDÉ, pas joué : le banc vérifie
   * donc qu'il est en attente, puis le joue. */
  verifier('1. un passage est en attente après les enregistrements',
    b.frames.length, 1);
  b.jouerFrames();
  verifier('1. les cinq rappels ont été joués une fois chacun',
    rappels.slice().sort(), [0, 1, 2, 3, 4]);

  /* 2. Au plus un passage par lot de mutations. */
  const deja = rappels.length;
  b.declencher();
  b.declencher();
  b.declencher();
  verifier('2. trois mutations ne demandent qu’un seul passage',
    b.frames.length, 1);
  b.jouerFrames();
  verifier('2. un passage joue les cinq rappels une fois chacun',
    rappels.length - deja, 5);
  verifier('2. les cinq panneaux sont prévenus',
    rappels.slice(deja).sort(), [0, 1, 2, 3, 4]);

  /* 3. Un rappel qui lève ne coupe pas les autres. */
  const b2 = banc();
  const ordre = [];
  b2.api.suivre('.a', () => { ordre.push('a'); });
  b2.api.suivre('.casse', () => { ordre.push('casse');
    throw new Error('panneau cassé'); });
  b2.api.suivre('.b', () => { ordre.push('b'); });
  b2.lot(() => { ordre.length = 0; });
  verifier('3. les trois rappels ont été tentés malgré l’exception',
    ordre, ['a', 'casse', 'b']);
  vrai('3. l’erreur est écrite sur la console, pas avalée',
    b2.erreurs.some(e => e.indexOf('.casse') >= 0));
  const stats = b2.api.statistiques();
  /* Au moins une : un lot joue le passage en attente à l'enregistrement PUIS
   * le passage déclenché, donc le compte dépend du nombre de passages, pas de
   * la présence de l'erreur. Ce qui est vérifié, c'est que l'erreur est
   * COMPTEE — un rappel qui lève en silence ne serait jamais mis en veille. */
  vrai('3. la statistique compte l’erreur',
    stats.enregistrements.filter(e => e.selecteur === '.casse')[0].erreurs >= 1);

  /* 4. Un rappel fautif est mis en veille, borné. */
  for (let i = 0; i < 20; i += 1) b2.lot();
  const casse = b2.api.statistiques().enregistrements.filter(
    e => e.selecteur === '.casse')[0];
  vrai('4. le rappel fautif finit par être mis en veille', casse.endormi);
  verifier('4. ses erreurs sont bornées par la mise en veille',
    casse.erreurs >= 12 && casse.erreurs <= 13, true);
  const avant = [];
  b2.api.suivre('.apres', () => avant.push(1));
  b2.lot(() => { avant.length = 0; });
  verifier('4. les autres panneaux continuent d’être prévenus', avant.length, 1);

  /* 5. L'arrêt d'un enregistrement. */
  const b3 = banc();
  const vus = [];
  const arret = b3.api.suivre('.x', () => vus.push(1));
  b3.lot(() => { vus.length = 0; });
  verifier('5. le rappel est joué', vus.length, 1);
  vrai('5. l’arrêt est une fonction', typeof arret === 'function');
  arret();
  b3.lot(() => { vus.length = 0; });
  verifier('5. après arrêt, le rappel n’est plus joué', vus.length, 0);
  verifier('5. l’enregistrement a bien été retiré',
    b3.api.statistiques().enregistrements.length, 0);

  /* 6. Sans requestAnimationFrame, le repli setTimeout est utilisé. */
  const b4 = banc({ sansRaf: true });
  const vus4 = [];
  b4.api.suivre('.y', () => vus4.push(1));
  const differe = b4.sondes.filter(s => typeof s === 'function');
  vrai('6. sans rAF, un repli différé est enregistré', differe.length >= 1);
  differe.forEach(f => f());
  vrai('6. le repli joue les rappels', vus4.length >= 1);

  /* 7. Les statistiques décrivent l'architecture d'avant, pour la comparaison. */
  verifier('7. l’architecture précédente est documentée',
    b.api.avant, { observateurs: 5, sondes: 5, delai_sonde: 2000 });
  verifier('7. un seul observateur maintenant',
    b.api.statistiques().observateurs, 1);
  verifier('7. une seule sonde maintenant', b.api.statistiques().sondes, 1);

  /* 8. Le relais des cinq scripts : repli sans PSHotes. */
  const fichiers = ['data-studio.js', 'navigateur-studio.js',
    'devweb-studio.js', 're-studio.js', 'outils-studio.js'];
  fichiers.forEach(function (nom) {
    const texte = fs.readFileSync(path.join(ICI, '..', nom), 'utf8');
    vrai('8. ' + nom + ' délègue à PSHotes',
      texte.indexOf('window.PSHotes') >= 0
      && texte.indexOf('suivreHote(') >= 0);
    vrai('8. ' + nom + ' n’a plus de sonde à 2 s',
      texte.indexOf('setInterval(attach, 2000)') < 0
      && texte.indexOf('setInterval(attacher, 2000)') < 0);
    verifier('8. ' + nom + ' ne pose plus qu’un seul observateur, dans le repli',
      (texte.match(/new MutationObserver/g) || []).length, 1);
    vrai('8. ' + nom + ' rend un objet à .disconnect(), pas une fonction',
      texte.indexOf('arret.disconnect') >= 0);
  });

  /* 9. ps-hotes.js doit être injecté AVANT les cinq panneaux. */
  const insereur = fs.readFileSync(path.join(ICI, '..',
    'inserer-assets-4.2.0.py'), 'utf8');
  vrai('9. l’inséreur 4.2.0 connaît ps-hotes.js',
    insereur.indexOf('ps-hotes.js') >= 0);
  vrai('9. ps-hotes.js est déclaré seul, sans feuille de style',
    insereur.indexOf('SOLOS') >= 0);
}

try {
  principal();
} catch (exc) {
  echecs.push('le banc a levé ' + exc + '\n' + (exc.stack || ''));
}
process.stdout.write('smoke_ps_hotes : ' + N + ' contrôles, ' + echecs.length
  + ' échec(s)\n');
echecs.forEach(function (e) { process.stdout.write('  ÉCHEC : ' + e + '\n'); });
process.exit(echecs.length ? 1 : 0);
