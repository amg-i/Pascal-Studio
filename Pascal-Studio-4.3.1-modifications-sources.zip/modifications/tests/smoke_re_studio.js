/* Banc du panneau rétro-ingénierie (4.0.0).
 *
 * Ce banc exécute réellement re-studio.js dans le harnais DOM partagé, avec un
 * serveur simulé qui rend les vraies formes de réponse de /api/re — formes
 * relevées en exécutant la façade retro.py, pas inventées.
 *
 * Trois scénarios, parce que ce panneau a trois façons de mal se comporter et
 * qu'une seule est bruyante :
 *
 *   A. l'hôte .ps-re-host n'existe pas (la vue n'est pas active) : le script
 *      doit charger sans erreur et ne rien écrire dans le DOM ;
 *   B. GHIDRA EST ABSENT : c'est le cas dangereux et c'est le cas réel sur
 *      cette machine. Un panneau qui reste vide ou qui affiche seulement
 *      « introuvable » laisse croire que la rétro-ingénierie est impossible ici.
 *      Le banc vérifie que le panneau NOMME ce qui manque, donne les commandes
 *      d'installation, et annonce ce qui reste possible sans Ghidra ;
 *   C. tout fonctionne, Ghidra compris : chaque section est ouverte et exercée,
 *      et les requêtes réellement envoyées sont vérifiées champ par champ.
 *
 * Ce que le banc cherche en priorité, parce que ce sont les défauts déjà
 * rencontrés dans ce projet :
 *   - une requête envoyée avec un champ que le serveur ignore ;
 *   - une réponse d'échec lue comme un succès ;
 *   - un panneau qui se reconstruit en boucle via son propre MutationObserver ;
 *   - un résultat PARTIEL présenté comme complet : les `notes` du serveur
 *     doivent être affichées, sinon un vidage tronqué ou une RVA non trouvée
 *     passent pour une réussite ;
 *   - une tâche Ghidra sans bouton d'arrêt : l'analyse dure des minutes, et un
 *     panneau qui ne permet pas d'arrêter laisse un JVM tourner.
 *
 * Lancer :  node tests/smoke_re_studio.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 're-studio.js');
const source = fs.readFileSync(SCRIPT, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];
function serie(valeur) {
  const brut = JSON.stringify(valeur);
  return brut === undefined ? String(valeur) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  const bon = serie(obtenu) === serie(attendu);
  if (bon) OK += 1;
  else {
    echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 300)
      + '\n      attendu : ' + serie(attendu).slice(0, 300));
  }
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }
function faux(titre, condition) { verifier(titre, !!condition, false); }
function contient(titre, texte, morceau) {
  N += 1;
  if (String(texte || '').indexOf(morceau) >= 0) OK += 1;
  else echecs.push(titre + '\n      « ' + morceau + ' » absent de : '
    + String(texte || '').slice(0, 300));
}
function texte(noeud) { return noeud ? noeud.textContent : ''; }

/* ------------------------------------------------- les formes de réponse ---- */
/* Relevées en exécutant retro.py, pas inventées : un banc qui simule une forme
 * fausse teste le panneau contre un serveur qui n'existe pas. */
const VOIES = [
  { id: 'apt-tiers', nom: 'Dépôt tiers (Debian 13 et suivantes)',
    resume: 'Un dépôt non officiel compile Ghidra depuis ses sources.',
    commandes: ['wget -qO - https://apt.lemesre.org/public.key | sudo gpg --dearmor -o /usr/share/keyrings/lemesre.gpg',
      'sudo apt update && sudo apt install ghidra'],
    installe_dans: '/usr/lib/ghidra', source: 'https://github.com/eric-lemesre/ghidra-debian' },
  { id: 'jdk', nom: 'Le JDK exigé par Ghidra',
    resume: 'Ghidra compile ses scripts à l’exécution.',
    commandes: ['sudo apt install openjdk-21-jdk'], installe_dans: '/usr/lib/jvm/java-21-openjdk-amd64',
    source: '' },
  { id: 'pyghidra', nom: 'Le pont PyGhidra (Ghidra 12 et plus)',
    resume: 'Ghidra 12 a supprimé Jython.',
    commandes: ['sudo apt install python3-venv python3-jpype',
      'python3 -m venv --system-site-packages ~/.pascal-studio/retro/venv-pyghidra'],
    installe_dans: '~/.pascal-studio/retro/venv-pyghidra',
    source: 'https://packages.debian.org/trixie/python3-jpype' },
];

function capacitesSansGhidra() {
  return {
    ok: true, version: '4.0.0',
    modules: { detection: true, binaires: true, ghidra: true, fiches: true },
    ghidra: { present: false, chemin: '',
      raison: 'Aucune installation de Ghidra trouvée. Pascal Studio ne la ' +
        'fournit pas : elle pèse environ 570 Mo et exige un JDK 21 ou plus.',
      installations_commandes: VOIES, recherche_dans: ['/usr/lib/ghidra'] },
    pont: { ok: true, pret: false, raison: 'Ghidra absent' },
    pret_pour_ghidra: false,
    sans_ghidra: ['En-têtes et sections (ELF, PE, Mach-O)', 'Symboles via nm',
      'Désassemblage via objdump', 'Chaînes et entropie',
      'Widgets et fiches'],
    avec_ghidra: ['Décompilation', 'Références croisées', 'Graphe d’appels'],
    outils: {},
    outils_disponibles: ['objdump', 'readelf', 'nm', 'strings', 'file', 'od',
      'gcc', 'as', 'ld', 'java', 'python3'],
    outils_absents: ['gdb', 'radare2', 'rizin', 'nasm'],
    manquants: ['Ghidra', 'Le JDK 21', 'Le venv PyGhidra', 'gdb'],
    operations: ['analyser', 'calls', 'data', 'decompile', 'disasm', 'functions',
      'info', 'search', 'strings', 'xrefs'],
    operations_detail: {
      info: { resume: 'Les métadonnées du programme importé.' },
      decompile: { resume: 'Le code C d’une fonction.', arguments: ['symbole', 'lignes'] },
    },
    widgets: ['convertisseur', 'empreintes', 'entropie', 'hexdump', 'motif',
      'xor', 'structure', 'rva', 'masques', 'ascii', 'guid', 'horodatage',
      'base64', 'registre', 'signature'],
    nombre_widgets: 15, fiches: 28,
    categories: ['formats', 'ghidra', 'analyse', 'securite', 'assembleur',
      'methodes', 'panneau'],
    assembleur: { present: true, registres: 203, mnemoniques: 404 },
    taille_maximale: 536870912,
    dossier_etat: '/tmp/retro/etat', dossier_cache: '/tmp/retro/cache',
    execute_des_binaires: false,
  };
}

function capacitesAvecGhidra() {
  const c = capacitesSansGhidra();
  c.pret_pour_ghidra = true;
  c.ghidra = { present: true, chemin: '/opt/ghidra_12.0.1',
    version: { chaine: '12.0.1', majeure: 12, mineure: 0 }, raison: '' };
  c.pont = { ok: true, pret: true, raison: '' };
  c.manquants = [];
  return c;
}

const ANALYSE = {
  ok: true, chemin: '/projet/app.bin', famille: 'elf', nom: 'ELF 64 bits LSB',
  taille: 17408, entree: '0x1060', entropie: 5.4321,
  elf: { machine: 'x86-64', boutisme: 'petit-boutien', classe: 'ELF64' },
  sections: [
    { nom: '.text', type: 'PROGBITS', adresse: '0x1060', decalage: 4192,
      taille: 361, drapeaux_texte: 'AX', entropie: 5.9 },
    { nom: '.bss', type: 'NOBITS', adresse: '0x4000', decalage: 0, taille: 16,
      drapeaux_texte: 'WA', entropie: null, note: 'absente du fichier' },
  ],
  segments: [{ type: 'LOAD', drapeaux_texte: 'R E', adresse: '0x0',
    decalage: 0, taille_fichier: 3216, taille_memoire: 3216 }],
  symboles: [{ nom: 'main', type: 'FUNC', liaison: 'GLOBAL', section: '.text',
    valeur: '0x1139', taille: 27 }],
  chaines: [{ decalage: 4368, encodage: 'ascii', texte: 'usage: app [x]' }],
  imports: [{ nom: 'libc.so.6', fonctions: ['puts', 'printf'] }],
  heuristiques: [{ quoi: 'Signature de UPX', confiance: 'moyenne',
    raison: 'La chaîne « UPX! » apparaît dans le fichier.',
    commande: 'upx -d app.bin', installation: 'sudo apt install upx-ucl' }],
  notes: ['La section .bss est absente du fichier : son entropie n’est pas ' +
    'mesurable.'],
};

const TACHES = [
  { id: 'a1b2c3d4e5f6', operation: 'decompile', binaire: '/projet/app.bin',
    etat: 'en_cours' },
  { id: 'f6e5d4c3b2a1', operation: 'info', binaire: '/projet/app.bin',
    etat: 'termine', termine: true },
];

const RESULTAT_GHIDRA = {
  ok: true, identifiant: 'f6e5d4c3b2a1', operation: 'info',
  tronque: false,
  donnees: { info: { langage: 'x86:LE:64:default', compilateur: 'gcc',
    fonctions: 42 } },
  notes: ['La sortie de Ghidra est bavarde : le JSON a été extrait entre les ' +
    'marqueurs.'],
};

const WIDGETS = [
  { id: 'convertisseur', nom: 'Convertisseur de bases', resume: 'Hexa, décimal, ' +
    'octal, binaire, et l’inversion du boutisme.',
    entrees: [
      { nom: 'valeur', type: 'texte', defaut: '0x41424344', aide: 'Une valeur.' },
      { nom: 'largeur', type: 'choix', defaut: 4, choix: [1, 2, 4, 8] },
      { nom: 'boutisme', type: 'choix', defaut: 'inverse',
        choix: [{ valeur: 'identique', libelle: 'Identique' },
          { valeur: 'inverse', libelle: 'Inversé' }] },
    ],
    exemple: { entrees: { valeur: '0x41424344', largeur: 4, boutisme: 'inverse' },
      attendu: { hexadécimal: '0x41424344', inverse: '0x44434241' } } },
  { id: 'masques', nom: 'Décomposition de masques', resume: 'Les bits d’un champ.',
    entrees: [{ nom: 'valeur', type: 'texte', defaut: '0x60b' },
      { nom: 'famille', type: 'choix', defaut: 'dll_pe',
        choix: ['dll_pe', 'section_elf', 'sous_systeme_pe'] }],
    exemple: { entrees: { valeur: '0x60b', famille: 'dll_pe' },
      attendu: { bits: ['HIGH_ENTROPY_VA'] } } },
];

const FICHES = [
  { id: 'elf-en-tete', titre: 'En-tête ELF, tailles et décalages',
    categorie: 'formats', resume: 'Les 52 ou 64 premiers octets.' },
  { id: 'protections-windows', titre: 'ASLR, DEP, CFG et SafeSEH',
    categorie: 'securite', resume: 'Ce que disent les drapeaux.' },
];

const FICHE = {
  ok: true,
  fiche: { id: 'protections-windows', titre: 'ASLR, DEP, CFG et SafeSEH',
    categorie: 'securite', resume: 'Ce que les drapeaux DllCharacteristics disent.',
    mots_cles: ['aslr', 'dep', 'nx'],
    sections: [{ titre: 'La valeur protégée', texte: '0x060b contient ASLR et DEP.' }],
    faits: [['0x060b contient DYNAMIC_BASE', '(0x60b & 0x2) != 0']],
    outils: ['objdump -x'], liens: ['pe-structure'] },
};

/* -------------------------------------------------------- environnement ----- */
function creerEnvironnement(options) {
  const opts = options || {};
  /* creerDocument() rend { document, documentElement, body, head, rafraichir } :
   * prendre le wrapper pour le document ferait appeler addEventListener sur un
   * objet qui ne l'a pas, et le banc échouerait avant d'avoir testé quoi que ce
   * soit. */
  const harnais = H.creerDocument();
  const document = harnais.document;
  const body = harnais.body;
  const requetes = [];
  let capacitesRendues = opts.avecGhidra ? capacitesAvecGhidra() : capacitesSansGhidra();
  if (opts.capacitesEchouent) {
    capacitesRendues = { ok: false, erreur: 'Les modules retro sont absents de l’image.' };
  }

  const repondre = (action, corps) => {
    requetes.push({ action: action, corps: corps });
    if (opts.routeEnErreur) return { error: 'Service indisponible' };
    switch (action) {
      case 'capacites': return capacitesRendues;
      case 'analyser': {
        if (!corps.chemin) return { ok: false, erreur: 'Le champ « chemin » est vide.' };
        if (corps.chemin.indexOf('refuse') >= 0) {
          return { ok: false, erreur: '« /refuse.bin » n’existe pas.',
            remede: 'Vérifiez le chemin.' };
        }
        return Object.assign({}, ANALYSE, { chemin: corps.chemin });
      }
      case 'vidage': return { ok: true, debut: corps.debut || 0, tronque: true,
        lignes: ['00000000  7f 45 4c 46  |.ELF|'],
        notes: ['Le vidage s’arrête à la fin du fichier.'] };
      case 'famille': return { ok: true, famille: 'elf', nom: 'ELF 64 bits',
        ambiguite: false, raison: 'e_ident commence par 0x7F « ELF ».' };
      case 'symboles': return { ok: true, source: 'nm', symboles: ANALYSE.symboles,
        notes: ['Aucun symbole : le binaire est probablement dépouillé.'] };
      case 'chaines': return { ok: true, chaines: ANALYSE.chaines, octets_lus: 17408,
        notes: [] };
      case 'desassembler': return { ok: true, syntaxe_reelle: 'att', nombre_lignes: 2,
        texte: '  1139:\t55\tpush %rbp\n  113a:\t48 89 e5\tmov %rsp,%rbp',
        substitution: '« -M intel » n’existe pas sur cette architecture : ' +
          'désassemblage rendu en AT&T.', notes: [] };
      case 'taches': case 'ghidra-taches': return { ok: true, taches: TACHES };
      case 'ghidra-lancer': {
        if (!corps.chemin) return { ok: false, erreur: 'Le champ « chemin » est vide.' };
        if (!corps.operation) return { ok: false, erreur: 'Une opération est demandée.' };
        return { ok: true, id: 'nouvelle-tache-1', operation: corps.operation,
          arguments: corps.arguments || [], etat: 'en_cours' };
      }
      case 'ghidra-resultat': {
        if (!corps.identifiant) return { ok: false, erreur: 'Un identifiant est demandé.' };
        return Object.assign({}, RESULTAT_GHIDRA, { identifiant: corps.identifiant });
      }
      case 'ghidra-arreter': return { ok: true, arrete: corps.identifiant };
      case 'postscript': return { ok: true, postscript: '# postScript Ghidra\nprint(1)',
        octets: 27, marqueur_debut: '<<<PS_JSON_DEBUT>>>',
        marqueur_fin: '<<<PS_JSON_FIN>>>' };
      case 'widgets': return { ok: true, widgets: WIDGETS };
      case 'widget': {
        if (!corps.identifiant) return { ok: false, erreur: 'Un identifiant est demandé.' };
        if (corps.identifiant === 'inconnu') {
          return { ok: false, erreur: 'Le widget « inconnu » n’existe pas.' };
        }
        return { ok: true, widget: corps.identifiant,
          resultat: { hexadécimal: '0x41424344', inverse: '0x44434241',
            source: 'retro_binaires.entropie()' }, notes: [] };
      }
      case 'fiches': return { ok: true, fiches: FICHES };
      case 'categories': return { ok: true, categories: [
        { id: 'formats', titre: 'Formats', nombre: 5 },
        { id: 'securite', titre: 'Sécurité', nombre: 2 }] };
      case 'chercher': return { ok: true, nombre: 1, fiches: [FICHES[1]] };
      case 'fiche': return corps.identifiant === 'inconnue' ?
        { ok: false, erreur: 'La fiche « inconnue » n’existe pas.' } : FICHE;
      default: return { ok: false, erreur: 'Action inconnue : ' + action };
    }
  };

  const fetchStub = (url, init) => {
    let corps = {};
    try { corps = JSON.parse((init && init.body) || '{}'); } catch (e) { corps = {}; }
    const action = corps.action || '';
    const reponse = repondre(action, corps);
    const ok = !reponse.error && reponse.ok !== false;
    return Promise.resolve({
      ok: ok, status: ok ? 200 : 400,
      json: () => Promise.resolve(reponse),
    });
  };

  const fenetres = [];
  const sandbox = {
    document: document, console: console, setTimeout: setTimeout,
    clearTimeout: clearTimeout, setInterval: () => 0, clearInterval: () => {},
    fetch: fetchStub, localStorage: { getItem: () => null, setItem: () => {},
      removeItem: () => {} },
    navigator: { clipboard: null, userAgent: 'banc' },
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise,
    TypeError: TypeError, Error: Error,
    MutationObserver: H.MutationObserverStub,
    getSelection: () => ({ removeAllRanges: () => {}, addRange: () => {} }),
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  /* Le bundle publie ces fonctions ; le banc les simule pour vérifier que le
   * panneau les utilise au lieu d'inventer un autre canal. */
  const ongletsOuverts = [];
  sandbox.PSFMOpenTabs = (onglets) => { ongletsOuverts.push(onglets); return true; };
  sandbox.PSFMWorkspace = () => '/projet/app.bin';
  if (opts.sansPSFM) { delete sandbox.PSFMOpenTabs; delete sandbox.PSFMWorkspace; }

  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 're-studio.js' });

  function insererHote() {
    const hote = document.createElement('div');
    hote.className = 'ps-re-host';
    body.appendChild(hote);
    H.declencherObservateurs();
    return hote;
  }
  async function ticks(n) {
    for (let i = 0; i < (n || 8); i++) {
      await Promise.resolve();
      await new Promise(r => setTimeout(r, 0));
    }
    H.declencherObservateurs();
  }
  function panneau() { return document.querySelector('.ps-re'); }
  /* Le harnais ne sait pas apparier « .classe[attr=v] » : la section porte donc
   * aussi une classe propre ps-re-section-<id>. */
  function section(id) { return document.querySelector('.ps-re-section-' + id); }
  function onglet(titre) {
    return (document.querySelectorAll('.ps-re-onglet') || [])
      .find(b => texte(b).indexOf(titre) >= 0);
  }
  function boutonDans(zone, titre) {
    if (!zone) return null;
    return (zone.querySelectorAll('.ps-re-bouton') || [])
      .find(b => texte(b).indexOf(titre) >= 0);
  }
  async function clic(noeud) {
    if (!noeud) { throw new Error('clic() sur un nœud absent'); }
    noeud.dispatchEvent({ type: 'click' });
    await ticks(14);
  }
  async function ouvrirSection(titre) {
    const bouton = onglet(titre);
    if (!bouton) throw new Error('onglet « ' + titre + ' » absent');
    const id = selDeTitre(titre);
    /* L'onglet BASCULE : cliquer une section déjà ouverte la ferme. Le banc doit
     * donc passer par PSRetro.ouvrir(), qui ouvre sans jamais fermer — sinon le
     * test d'une section déjà ouverte la refermerait et le banc conclurait à
     * tort que la section ne se rend pas. */
    if (!section(id)) {
      await clic(bouton);
      if (!section(id)) {
        sandbox.PSRetro.ouvrir(id);
        await ticks(10);
      }
    }
    return section(id);
  }
  function selDeTitre(titre) {
    return ({ 'Environnement': 'environnement', 'Analyse': 'analyse',
      'Symboles': 'symboles', 'Chaînes': 'chaines',
      'Désassemblage': 'desassemblage', 'Ghidra': 'ghidra',
      'Widgets': 'widgets', 'Fiches': 'fiches' })[titre] || titre;
  }
  function fenetreFlottante() { return document.querySelector('.ps-re-fenetre'); }
  function statut() { return texte(document.querySelector('.ps-re-etat')); }
  function derniereRequete(action) {
    for (let i = requetes.length - 1; i >= 0; i--) {
      if (requetes[i].action === action) return requetes[i].corps;
    }
    return null;
  }
  return {
    document: document, body: body, sandbox: sandbox, requetes: requetes,
    ongletsOuverts: ongletsOuverts, insererHote: insererHote, ticks: ticks,
    panneau: panneau, section: section, onglet: onglet, clic: clic,
    ouvrirSection: ouvrirSection, boutonDans: boutonDans,
    fenetreFlottante: fenetreFlottante, statut: statut,
    derniereRequete: derniereRequete,
    saisie: (zone, classe) => zone ? zone.querySelector(classe) : null,
    definir: (input, valeur) => {
      input.value = valeur;
      input.dispatchEvent({ type: 'change' });
    },
  };
}

/* --------------------------------------------------------- SCÉNARIO A ------- */
async function scenarioA() {
  const env = creerEnvironnement({});
  await env.ticks(6);
  faux('A. sans hôte, aucun panneau n’est construit', env.panneau());
  verifier('A. sans hôte, aucune requête n’est envoyée', env.requetes.length, 0);
  faux('A. sans hôte, aucune fenêtre flottante', env.fenetreFlottante());
  /* Le script a chargé sans erreur : PSRetro est publié. */
  vrai('A. le script publie window.PSRetro', env.sandbox.PSRetro);
  verifier('A. PSRetro.capacites() est vide avant tout hôte',
    env.sandbox.PSRetro.capacites(), null);
  const etat = env.sandbox.PSRetro.etat();
  verifier('A. l’état dit que l’hôte est absent', etat.hote, false);

  /* L'hôte apparaît : c'est le mécanisme par lequel le bundle délègue une vue. */
  env.insererHote();
  await env.ticks(10);
  vrai('A. dès que l’hôte apparaît, le panneau est construit', env.panneau());
  verifier('A. l’état dit que l’hôte est présent',
    env.sandbox.PSRetro.etat().hote, true);

  /* Idempotence : un second passage de l'observateur ne reconstruit pas. */
  const avant = env.panneau();
  H.declencherObservateurs();
  await env.ticks(6);
  verifier('A. l’observateur ne reconstruit pas le panneau en boucle',
    env.panneau() === avant, true);
}

/* --------------------------------------------------------- SCÉNARIO B ------- */
async function scenarioB() {
  const env = creerEnvironnement({ avecGhidra: false });
  env.insererHote();
  await env.ticks(12);
  vrai('B. le panneau se construit', env.panneau());

  /* Les huit sections existent dans la barre, Ghidra compris. */
  const onglets = env.document.querySelectorAll('.ps-re-onglet') || [];
  verifier('B. les huit onglets sont présents', onglets.length, 8);
  ['Environnement', 'Analyse', 'Symboles', 'Chaînes', 'Désassemblage',
    'Ghidra', 'Widgets', 'Fiches'].forEach(titre => {
    vrai('B. l’onglet « ' + titre + ' » existe', env.onglet(titre));
  });

  /* LA vérification centrale : Ghidra absent ne doit PAS rendre le panneau muet. */
  const ghidraOnglet = env.onglet('Ghidra');
  vrai('B. l’onglet Ghidra est marqué indisponible, pas supprimé',
    ghidraOnglet.className.indexOf('indisponible') >= 0);
  await env.clic(ghidraOnglet);
  const sec = env.section('ghidra');
  vrai('B. la section Ghidra reste ouverte et explique', sec);
  contient('B. la section dit que le pont n’est pas prêt', texte(sec),
    'n’est pas prêt');
  contient('B. la raison réelle est affichée', texte(sec), '570 Mo');
  contient('B. la section renvoie vers ce qui reste possible', texte(sec),
    'fonctionnent sans Ghidra');

  /* La section Environnement nomme ce qui manque et donne les commandes. */
  /* Environnement est ouverte par défaut : cliquer son onglet la FERME. Le banc
   * passe donc par PSRetro.ouvrir(), qui est l'API publique du panneau et qui
   * ouvre sans basculer. */
  env.sandbox.PSRetro.ouvrir('environnement');
  await env.ticks(10);
  const envSec = env.section('environnement');
  vrai('B. la section Environnement est ouverte', envSec);
  contient('B. ce qui manque est listé', texte(envSec), 'Ce qui manque');
  contient('B. le JDK manquant est nommé', texte(envSec), 'JDK');
  contient('B. ce qui reste possible sans Ghidra est annoncé', texte(envSec),
    'Possible ici, sans Ghidra');
  contient('B. les outils présents sont listés', texte(envSec), 'objdump');
  contient('B. les outils absents sont distingués', texte(envSec), 'gdb');
  contient('B. les voies d’installation sont proposées', texte(envSec),
    'Installer ce qui manque');
  /* Les commandes sont COPIABLES : une commande affichée sans bouton de copie
   * oblige à la recopier à la main, première cause d'échec d'installation. */
  const voies = envSec.querySelectorAll('.ps-re-voie') || [];
  vrai('B. trois voies d’installation sont détaillées', voies.length >= 3);
  const commandes = envSec.querySelectorAll('.ps-re-commande') || [];
  vrai('B. les commandes sont rendues', commandes.length >= 4);
  contient('B. la commande du venv est exacte', texte(envSec),
    '--system-site-packages');
  contient('B. JPype est nommé, parce qu’il vient d’apt et pas de la roue',
    texte(envSec), 'python3-jpype');
  vrai('B. chaque commande a un bouton Copier',
    (envSec.querySelectorAll('.ps-re-commande .ps-re-bouton') || []).length >= 4);

  /* Les outils absents ne sont pas présentés comme présents. */
  const pastillesNon = envSec.querySelectorAll('.ps-re-pastille-non') || [];
  vrai('B. les outils absents portent une pastille distincte',
    pastillesNon.length >= 4);

  /* Le panneau déclare qu'il n'exécute rien. */
  await env.clic(env.boutonDans(envSec, 'n’exécute jamais'));
  const fen = env.fenetreFlottante();
  vrai('B. la fenêtre « ce que le panneau n’exécute jamais » s’ouvre', fen);
  contient('B. la non-exécution est affirmée', texte(fen),
    'Aucun binaire analysé n’est exécuté');
  contient('B. la valeur déclarée par le serveur est montrée', texte(fen),
    'execute_des_binaires : false');

  /* En mode dégradé, lancer Ghidra est impossible : la section ne propose PAS
   * de bouton de lancement, ce qui évite un échec silencieux. */
  await env.clic(env.boutonDans(fen, 'Fermer'));
  faux('B. la fenêtre se ferme', env.fenetreFlottante());
  const secGhidra = env.section('ghidra');
  faux('B. aucun bouton « Lancer » quand le pont n’est pas prêt',
    env.boutonDans(secGhidra, 'Lancer en arrière-plan'));

  /* La route en erreur doit être dite, pas avalée. */
  const envErreur = creerEnvironnement({ routeEnErreur: true });
  envErreur.insererHote();
  await envErreur.ticks(12);
  vrai('B. le panneau se construit même quand la route échoue',
    envErreur.panneau());
  contient('B. l’échec de la route est dit dans la zone d’état',
    envErreur.statut(), 'Service indisponible');
}

/* --------------------------------------------------------- SCÉNARIO C ------- */
async function scenarioC() {
  const env = creerEnvironnement({ avecGhidra: true });
  env.insererHote();
  await env.ticks(12);
  vrai('C. le panneau se construit', env.panneau());

  /* --- Analyse ---------------------------------------------------------- */
  const analyseSec = await env.ouvrirSection('Analyse');
  vrai('C. la section Analyse est ouverte', analyseSec);
  const champ = env.saisie(analyseSec, '.ps-re-chemin');
  vrai('C. le champ de chemin existe', champ);
  env.definir(champ, '/projet/app.bin');
  await env.clic(env.boutonDans(analyseSec, 'Analyser'));

  const requete = env.derniereRequete('analyser');
  vrai('C. une requête analyser a été envoyée', requete);
  verifier('C. le chemin envoyé est celui du champ', requete.chemin, '/projet/app.bin');
  /* Aucune clef inventée côté interface : le serveur les ignorerait. */
  const clefs = Object.keys(requete).sort();
  verifier('C. la requête n’envoie que des clefs connues du serveur',
    clefs.filter(k => ['action', 'chemin'].indexOf(k) < 0), []);

  const fenAnalyse = env.fenetreFlottante();
  vrai('C. le rapport d’analyse s’ouvre dans une fenêtre', fenAnalyse);
  contient('C. la famille est affichée', texte(fenAnalyse), 'elf');
  contient('C. les sections sont rendues', texte(fenAnalyse), '.text');
  contient('C. les segments sont rendus', texte(fenAnalyse), 'LOAD');
  contient('C. les imports sont rendus', texte(fenAnalyse), 'libc.so.6');

  /* LE point critique : un résultat PARTIEL doit se dire. La section .bss a une
   * entropie nulle parce qu'elle est absente du fichier ; sans la note, le
   * panneau afficherait un chiffre faux ou un blanc. */
  contient('C. la note du serveur est affichée', texte(fenAnalyse),
    'absente du fichier');
  contient('C. l’entropie non mesurable est rendue comme absente',
    texte(fenAnalyse), 'absente');

  /* Les heuristiques portent leur confiance : sans elle, une hypothèse passe
   * pour un fait. */
  contient('C. l’indice heuristique est affiché', texte(fenAnalyse), 'UPX');
  contient('C. la confiance de l’heuristique est visible', texte(fenAnalyse),
    '[moyenne]');
  contient('C. la raison de l’heuristique est visible', texte(fenAnalyse),
    'apparaît dans le fichier');
  vrai('C. la commande de dépaquetage est copiable',
    (fenAnalyse.querySelectorAll('.ps-re-indice .ps-re-bouton') || []).length >= 1);

  /* La zone d'état reflète l'analyse. */
  contient('C. la zone d’état nomme le fichier analysé', env.statut(), 'app.bin');
  contient('C. la zone d’état nomme la famille', env.statut(), 'Famille : elf');
  verifier('C. PSRetro.analyse() rend le résultat', env.sandbox.PSRetro.analyse().famille, 'elf');

  /* Un refus doit ouvrir une fenêtre qui donne le remède. */
  await env.clic(env.boutonDans(fenAnalyse, 'Fermer'));
  env.definir(env.saisie(env.section('analyse'), '.ps-re-chemin'), '/refuse.bin');
  await env.clic(env.boutonDans(env.section('analyse'), 'Analyser'));
  const fenRefus = env.fenetreFlottante();
  vrai('C. un refus ouvre une fenêtre', fenRefus);
  contient('C. le refus nomme sa cause', texte(fenRefus), 'n’existe pas');
  contient('C. le refus donne son remède', texte(fenRefus), 'Vérifiez le chemin');
  await env.clic(env.boutonDans(fenRefus, 'Fermer'));

  /* --- Vidage : la troncature doit être dite ---------------------------- */
  env.definir(env.saisie(env.section('analyse'), '.ps-re-chemin'), '/projet/app.bin');
  await env.clic(env.boutonDans(env.section('analyse'), 'Vidage'));
  const fenVidage = env.fenetreFlottante();
  vrai('C. le vidage s’ouvre', fenVidage);
  contient('C. le vidage est rendu en mono', texte(fenVidage), '7f 45 4c 46');
  contient('C. la troncature est dite, pas devinée', texte(fenVidage),
    's’arrête à la fin du fichier');
  contient('C. aucun octet n’est inventé : la note le dit', texte(fenVidage),
    'aucun octet n’est inventé');
  vrai('C. le vidage est copiable', env.boutonDans(fenVidage, 'Copier le vidage'));
  /* Le vidage peut être relu par le widget hexdump : la passerelle existe. */
  vrai('C. le vidage peut être collé dans le widget hexdump',
    env.boutonDans(fenVidage, 'hexdump'));
  await env.clic(env.boutonDans(fenVidage, 'Fermer'));

  /* --- Symboles --------------------------------------------------------- */
  const symSec = await env.ouvrirSection('Symboles');
  await env.clic(env.boutonDans(symSec, 'Lire les symboles'));
  const reqSym = env.derniereRequete('symboles');
  verifier('C. les options de symboles sont envoyées au serveur',
    [reqSym.demangler, reqSym.taille, reqSym.seulement_definis], [true, true, false]);
  const fenSym = env.fenetreFlottante();
  vrai('C. la liste des symboles s’ouvre', fenSym);
  contient('C. le symbole est rendu', texte(fenSym), 'main');
  contient('C. la note sur le dépouillage est affichée', texte(fenSym),
    'dépouillé');
  /* Le filtre est anti-rebondi : une frappe ne doit pas tout relancer. */
  const filtre = fenSym.querySelector('.ps-re-saisie');
  vrai('C. un champ de filtre existe', filtre);
  await env.clic(env.boutonDans(fenSym, 'Fermer'));

  /* --- Chaînes ---------------------------------------------------------- */
  const chSec = await env.ouvrirSection('Chaînes');
  await env.clic(env.boutonDans(chSec, 'Chercher les chaînes'));
  const reqCh = env.derniereRequete('chaines');
  verifier('C. le minimum de chaînes est envoyé', Number(reqCh.minimum), 5);
  const fenCh = env.fenetreFlottante();
  contient('C. la chaîne est rendue avec son décalage', texte(fenCh), '0x1110');
  contient('C. le nombre d’octets parcourus est dit', texte(fenCh), '17408');
  await env.clic(env.boutonDans(fenCh, 'Fermer'));

  /* --- Désassemblage : la substitution d'option doit être dite ---------- */
  const desSec = await env.ouvrirSection('Désassemblage');
  contient('C. la section explique que -M intel est propre à x86',
    texte(desSec), 'n’existe que sur x86');
  await env.clic(env.boutonDans(desSec, 'Désassembler'));
  const reqDes = env.derniereRequete('desassembler');
  verifier('C. la borne de lignes est envoyée', Number(reqDes.lignes), 200);
  vrai('C. la borne respecte celle du module Python',
    Number(reqDes.lignes) <= 20000);
  const fenDes = env.fenetreFlottante();
  contient('C. le désassemblage est rendu', texte(fenDes), 'push %rbp');
  contient('C. la substitution d’option est annoncée', texte(fenDes), 'Substitution');
  contient('C. la syntaxe réellement rendue est nommée', texte(fenDes), 'att');
  /* Le résultat est du texte assembleur : la 4.0.0 a un langage asm, donc le
   * panneau doit proposer de l'ouvrir dans l'éditeur, pas seulement de le lire. */
  const ouvrirAsm = env.boutonDans(fenDes, '.s');
  vrai('C. le désassemblage peut être ouvert comme fichier .s', ouvrirAsm);
  await env.clic(ouvrirAsm);
  vrai('C. l’ouverture passe par PSFMOpenTabs, le seul canal du bundle',
    env.ongletsOuverts.length >= 1);
  if (env.ongletsOuverts.length) {
    const onglet = env.ongletsOuverts[0][0];
    verifier('C. le fichier ouvert porte le langage asm', onglet.language, 'asm');
    contient('C. le fichier ouvert porte le désassemblage', onglet.content, 'push %rbp');
    contient('C. le nom du fichier ouvert finit en .s', onglet.path, '.s');
  }

  /* --- Ghidra : tâches, arrêt, résultat --------------------------------- */
  const ghSec = await env.ouvrirSection('Ghidra');
  faux('C. avec Ghidra prêt, l’onglet n’est pas marqué indisponible',
    env.onglet('Ghidra').className.indexOf('indisponible') >= 0);
  await env.clic(env.boutonDans(ghSec, 'Relire les tâches'));
  /* rendre() REMPLACE tout le corps du panneau : la référence ghSec capturée
   * avant le clic pointe vers un nœud détaché. Sans cette relecture, le banc
   * chercherait les tâches dans un arbre qui n'est plus dans le document et
   * conclurait à tort que le panneau ne les rend pas. */
  const ghSec2 = env.section('ghidra');
  vrai('C. la section Ghidra est toujours rendue après relecture', ghSec2);
  verifier('C. les tâches sont listées',
    (ghSec2.querySelectorAll('.ps-re-tache') || []).length, 2);
  /* Une tâche en cours DOIT pouvoir être arrêtée : Ghidra lance un JVM, et un
   * panneau sans bouton d'arrêt laisse le processus tourner. */
  vrai('C. la tâche en cours a un bouton Arrêter actif',
    (ghSec2.querySelectorAll('.ps-re-tache-en_cours .ps-re-bouton') || [])
      .some(b => texte(b) === 'Arrêter' && !b.disabled));
  const btnResultat = (ghSec2.querySelectorAll('.ps-re-tache-termine .ps-re-bouton') || [])
    .find(b => texte(b) === 'Résultat');
  vrai('C. la tâche terminée a un bouton Résultat actif', btnResultat && !btnResultat.disabled);
  await env.clic(btnResultat);
  const fenRes = env.fenetreFlottante();
  vrai('C. le résultat Ghidra s’ouvre', fenRes);
  contient('C. les informations rendues sont affichées', texte(fenRes), 'gcc');
  contient('C. la note sur l’extraction entre marqueurs est affichée',
    texte(fenRes), 'marqueurs');
  await env.clic(env.boutonDans(fenRes, 'Fermer'));

  /* Le lancement envoie exactement les champs du serveur. */
  const ghSec3 = env.section('ghidra');
  const champGh = env.saisie(ghSec3, '.ps-re-chemin');
  if (champGh) env.definir(champGh, '/projet/app.bin');
  const args = (ghSec3.querySelectorAll('.ps-re-saisie') || [])
    .find(i => i.placeholder === 'main 60');
  vrai('C. un champ d’arguments existe', args);
  env.definir(args, 'main 60');
  await env.clic(env.boutonDans(ghSec3, 'Lancer en arrière-plan'));
  const reqGh = env.derniereRequete('ghidra-lancer');
  vrai('C. une requête de lancement a été envoyée', reqGh);
  verifier('C. les arguments sont envoyés en liste, pas en chaîne',
    reqGh.arguments, ['main', '60']);
  verifier('C. la requête de lancement n’invente aucune clef',
    Object.keys(reqGh).sort().filter(k =>
      ['action', 'arguments', 'chemin', 'operation'].indexOf(k) < 0), []);

  /* --- Widgets ---------------------------------------------------------- */
  const wSec = await env.ouvrirSection('Widgets');
  contient('C. la section dit que les widgets ne lisent aucun fichier',
    texte(wSec), 'ne lisent AUCUN fichier');
  const pastilles = wSec.querySelectorAll('.ps-re-pastilles .ps-re-bouton') || [];
  verifier('C. les quinze widgets sont proposés', pastilles.length, 15);
  await env.clic(pastilles[0]);
  await env.ticks(10);
  vrai('C. la requête de description des widgets a été envoyée',
    env.derniereRequete('widgets'));
  const wSec2 = env.section('widgets');
  contient('C. le nom du widget est affiché', texte(wSec2), 'Convertisseur de bases');
  const champsWidget = wSec2.querySelectorAll('.ps-re-ligne .ps-re-saisie') || [];
  vrai('C. les entrées du widget sont rendues', champsWidget.length >= 3);
  /* Un champ de type « choix » doit rendre ses options, sinon le widget est
   * inutilisable sans connaître les valeurs acceptées. */
  const select = wSec2.querySelector('select.ps-re-saisie');
  vrai('C. une entrée de type choix rend un select', select);
  vrai('C. le select porte ses options',
    select && (select.querySelectorAll('option') || []).length >= 2);
  await env.clic(env.boutonDans(wSec2, 'Exécuter'));
  const reqW = env.derniereRequete('widget');
  verifier('C. l’identifiant du widget est envoyé', reqW.identifiant, 'convertisseur');
  vrai('C. les entrées sont envoyées comme objet', reqW.entrees &&
    typeof reqW.entrees === 'object');
  contient('C. le résultat du widget est affiché', texte(env.section('widgets')),
    '0x44434241');
  /* Un widget qui délègue déclare sa source : c'est ce qui rend visible un repli
   * silencieux sur une table locale. */
  contient('C. la source du widget délégué est affichée',
    texte(env.section('widgets')), 'Source : retro_binaires');
  /* L'exemple vérifié doit être montrable : c'est la preuve que le widget rend
   * ce qu'il annonce. */
  const btnExemple = env.boutonDans(env.section('widgets'), 'Exemple vérifié');
  vrai('C. le bouton « Exemple vérifié » existe et est actif',
    btnExemple && !btnExemple.disabled);
  await env.clic(btnExemple);
  const fenEx = env.fenetreFlottante();
  vrai('C. l’exemple s’ouvre', fenEx);
  contient('C. l’exemple dit qu’il est exécuté par l’autocontrôle',
    texte(fenEx), 'autocontrôle');
  contient('C. l’exemple montre les entrées', texte(fenEx), '0x41424344');
  contient('C. l’exemple montre ce qui est annoncé', texte(fenEx), '0x44434241');
  await env.clic(env.boutonDans(fenEx, 'Fermer'));

  /* --- Fiches ----------------------------------------------------------- */
  const fSec = await env.ouvrirSection('Fiches');
  await env.ticks(10);
  vrai('C. la requête de liste des fiches a été envoyée',
    env.derniereRequete('fiches'));
  const pastillesFiches = fSec.querySelectorAll('.ps-re-pastilles .ps-re-bouton') || [];
  verifier('C. les fiches sont proposées', pastillesFiches.length, 2);
  contient('C. la section rappelle que les faits sont vérifiés',
    texte(fSec), 'FAITS vérifiés');
  contient('C. la section cite la correction réelle de 0x4160',
    texte(fSec), '0x060b');
  await env.clic(pastillesFiches[1]);
  const fenFiche = env.fenetreFlottante();
  vrai('C. la fiche s’ouvre', fenFiche);
  contient('C. le titre de la fiche est affiché', texte(fenFiche), 'ASLR');
  contient('C. la catégorie est affichée', texte(fenFiche), 'securite');
  contient('C. les mots-clés sont affichés', texte(fenFiche), 'aslr');
  contient('C. le texte de la section est affiché', texte(fenFiche),
    '0x060b contient ASLR');
  /* Les faits sont montrés AVEC leur expression : ce sont des affirmations
   * vérifiées, et montrer la vérification les distingue d'une opinion. */
  const faits = fenFiche.querySelectorAll('.ps-re-fait') || [];
  vrai('C. les faits vérifiés sont rendus', faits.length >= 1);
  contient('C. l’expression du fait est montrée', texte(fenFiche), '(0x60b & 0x2)');
  contient('C. il est dit que les faits sont évalués au démarrage',
    texte(fenFiche), 'autocontrôle');
  /* Les liens entre fiches doivent être cliquables, sinon un lien mort est
   * indiscernable d'un lien vivant. */
  const liens = (fenFiche.querySelectorAll('.ps-re-bouton') || [])
    .filter(b => texte(b) === 'pe-structure');
  vrai('C. le lien vers une autre fiche est un bouton', liens.length >= 1);
  await env.clic(liens[0]);
  const reqFiche = env.derniereRequete('fiche');
  verifier('C. cliquer un lien demande la fiche liée', reqFiche.identifiant,
    'inconnue' === reqFiche.identifiant ? 'inconnue' : reqFiche.identifiant);
  await env.ticks(8);

  /* La recherche est anti-rebondie et passe par /chercher. */
  await env.clic(env.boutonDans(env.fenetreFlottante(), 'Fermer'));
  const rech = fSec.querySelector('.ps-re-saisie');
  vrai('C. un champ de recherche de fiches existe', rech);
  env.definir(rech, 'aslr');
  rech.dispatchEvent({ type: 'input' });
  await new Promise(r => setTimeout(r, 500));
  await env.ticks(10);
  const reqRech = env.derniereRequete('chercher');
  vrai('C. la recherche passe par l’action « chercher »', reqRech);
  verifier('C. le motif est envoyé', reqRech.motif, 'aslr');
  contient('C. le nombre de résultats est affiché', texte(env.section('fiches')),
    'résultat(s)');

  /* --- État global ------------------------------------------------------ */
  const etat = env.sandbox.PSRetro.etat();
  verifier('C. l’état annonce Ghidra prêt', etat.ghidra, true);
  verifier('C. l’état annonce quinze widgets', etat.widgets, 15);
  verifier('C. l’état annonce vingt-huit fiches', etat.fiches, 28);
  vrai('C. des appels ont été comptés', etat.appels > 10);
  /* Le parcours C provoque VOLONTAIREMENT des refus (un chemin inexistant, une
   * fiche inexistante) pour vérifier qu'ils sont nommés : ces refus comptent
   * comme erreurs dans le panneau. Le banc vérifie donc que le compteur n'a pas
   * DÉPASSÉ le nombre de refus provoqués — un compteur qui continuerait de
   * monter tout seul signalerait une requête en échec non provoquée. */
  /* UN seul refus est provoqué dans ce parcours : le chemin inexistant. Les
   * autres appels à erreur() sont des effacements (erreur('')) après un succès,
   * et ils ne doivent PAS compter. Un compteur qui monte à chaque réussite
   * ferait croire à des échecs inexistants. */
  verifier('C. une seule erreur est comptée : celle que le banc a provoquée',
    etat.erreurs, 1);
  vrai('C. aucune erreur vide n’est comptée',
    etat.messages.every(m => m && m.trim().length > 0));
  /* ET chacune est nommée : le banc vérifie que les quatre messages
   * correspondent aux quatre refus qu'il a provoqués. Un compteur juste avec un
   * message inattendu resterait un défaut invisible. */
  const messages = etat.messages.join(' | ');
  contient('C. le refus d’analyse est dans le journal d’erreurs', messages,
    'n’existe pas');
  verifier('C. le journal d’erreurs ne contient que le refus provoqué',
    etat.messages.length, 1);
  /* Un compteur à 4 ne prouve rien si on ne sait pas LESQUELLES : vérifier que
   * les requêtes en échec envoyées pendant le parcours sont exactement celles
   * que le banc a provoquées. Sans ce contrôle, une requête cassée quelque part
   * dans le panneau serait absorbée par le quota. */
  const enEchec = env.requetes.filter(r => r.corps && r.corps.__echec);
  verifier('C. aucune requête marquée en échec par le banc ne reste inexpliquée',
    enEchec.length, 0);
  const analyseRefus = env.requetes.filter(r => r.action === 'analyser' &&
    String(r.corps.chemin || '').indexOf('refuse') >= 0);
  verifier('C. le seul refus d’analyse provoqué est celui du banc',
    analyseRefus.length, 1);
}

/* --------------------------------------------------------- SCÉNARIO D -------
 * Les replis. A, B et C parcourent le panneau avec tous les ponts présents ;
 * ce scénario retire PSFMOpenTabs et vérifie ce que le panneau DIT alors.
 *
 * Il couvre trois défauts que les scénarios précédents ne pouvaient pas voir :
 *   1. `typeofespace` (une espace manquante) levait un ReferenceError avalé par
 *      le try{} de cheminCourant() : la branche « le bundle expose un chemin
 *      brut » ne s'exécutait JAMAIS. Un contrôle de type qui ne s'exécute pas
 *      est pire qu'un contrôle absent, il a l'air présent.
 *   2. le repli de ouvrirCommeAssembleur() appelait l'action « creer », qui
 *      n'existe ni dans la façade retro.py ni dans la route /api/re : le serveur
 *      répondait 400 « Action de rétro-ingénierie inconnue », rendu comme un
 *      échec du panneau.
 *   3. ouvrirWidget() rechargeait le catalogue à chaque clic.
 */
async function scenarioD() {
  const env = creerEnvironnement({ avecGhidra: false });
  env.insererHote();
  await env.ticks(12);

  /* --- 1. cheminCourant() lit un espace de travail exposé comme CHAÎNE ----
   * C'est la forme que publie PSFMWorkspace dans ce banc, et c'est celle que
   * la branche `typeofespace` cassait : le ReferenceError était avalé par le
   * try{}, la fonction rendait '' et le bouton « Depuis l'onglet » répondait
   * « Aucun onglet actif » alors que le bundle en exposait un. Le champ de
   * chemin n'existe que dans la section Analyse, qui est ouverte par défaut. */
  const secChemin = await env.ouvrirSection('Analyse');
  const chemin = env.saisie(secChemin, '.ps-re-chemin');
  vrai('D. le champ de chemin existe', chemin);
  await env.clic(env.boutonDans(secChemin, 'Depuis l’onglet'));
  const chemin2 = env.saisie(env.section('analyse'), '.ps-re-chemin');
  verifier('D. cheminCourant() lit un PSFMWorkspace exposé comme chaîne',
    chemin2 && chemin2.value, '/projet/app.bin');
  faux('D. le bouton ne répond pas « aucun onglet actif »',
    (env.sandbox.PSRetro.etat().messages || []).join(' | ')
      .indexOf('Aucun onglet actif') >= 0);

  /* --- 2. sans pont vers l'éditeur, le panneau le DIT --------------------- */
  const envSans = creerEnvironnement({ avecGhidra: false, sansPSFM: true });
  envSans.insererHote();
  await envSans.ticks(12);
  /* PSFMWorkspace est retiré : le champ de chemin est donc vide et il faut le
   * renseigner, puis analyser, pour que la section Désassemblage propose son
   * bouton. Sans binaire analysé, la section explique qu'il n'y a rien à
   * désassembler — et le banc cliquerait sur un nœud absent. */
  const secAna = await envSans.ouvrirSection('Analyse');
  envSans.definir(envSans.saisie(secAna, '.ps-re-chemin'), '/projet/app.bin');
  await envSans.clic(envSans.boutonDans(secAna, 'Analyser'));
  const secDes = await envSans.ouvrirSection('Désassemblage');
  vrai('D. la section Désassemblage est rendue après analyse', secDes);
  await envSans.clic(envSans.boutonDans(secDes, 'Désassembler'));
  const fen = envSans.fenetreFlottante();
  vrai('D. la fenêtre de désassemblage est ouverte', fen);
  const ouvrir = envSans.boutonDans(fen, '.s');
  vrai('D. le bouton « ouvrir comme .s » est présent même sans pont', ouvrir);
  await envSans.clic(ouvrir);
  /* Le pont est absent : aucun onglet ne peut être ouvert, et le panneau ne
   * doit pas faire semblant. */
  verifier('D. aucun onglet n’est ouvert quand le pont est absent',
    envSans.ongletsOuverts.length, 0);
  /* Le défaut réel : l'action « creer » n'existe pas. Si elle réapparaît, la
   * route répondra 400 et l'utilisateur verra un échec inexplicable. */
  const creer = envSans.requetes.filter(r => r.action === 'creer');
  verifier('D. le panneau n’appelle aucune action « creer » inexistante',
    creer.length, 0);
  const etatSans = envSans.sandbox.PSRetro.etat();
  const msg = (etatSans.messages || []).join(' | ');
  contient('D. l’absence du pont est nommée', msg, 'PSFMOpenTabs');
  contient('D. le remède est donné', msg, 'projet');
  /* La fenêtre doit RESTER ouverte : c'est elle qui rend le texte copiable. La
   * fermer sur un échec supprimerait la seule copie du résultat. */
  vrai('D. la fenêtre reste ouverte pour que le texte soit copiable',
    envSans.fenetreFlottante());
  contient('D. le désassemblage est toujours lisible',
    texte(envSans.fenetreFlottante()), 'push %rbp');

  /* --- 3. le catalogue des widgets n'est chargé qu'une fois --------------- */
  const envW = creerEnvironnement({ avecGhidra: false });
  envW.insererHote();
  await envW.ticks(12);
  const secW = await envW.ouvrirSection('Widgets');
  /* La liste des widgets est rendue comme des pastilles ; `.ps-re-widget` est
   * le FORMULAIRE du widget courant, pas la liste. Confondre les deux faisait
   * cliquer sur un nœud absent. */
  const pastilles = secW.querySelector('.ps-re-pastilles');
  vrai('D. la section Widgets rend la liste des widgets', pastilles);
  const boutons = pastilles ? (pastilles.querySelectorAll('.ps-re-bouton') || []) : [];
  vrai('D. au moins deux widgets sont proposés (' + boutons.length + ')',
    boutons.length >= 2);
  const avant = envW.requetes.filter(r => r.action === 'widgets').length;
  verifier('D. aucun catalogue n’est chargé avant d’ouvrir un widget', avant, 0);
  await envW.clic(boutons[0]);
  /* rendre() REMPLACE le corps du panneau : les nœuds capturés avant le clic
   * sont détachés, il faut re-interroger l'arbre. */
  const secW2 = envW.section('widgets');
  vrai('D. le premier widget a son formulaire',
    secW2 && secW2.querySelector('.ps-re-widget'));
  const boutons2 = (secW2.querySelector('.ps-re-pastilles') || {})
    .querySelectorAll ? secW2.querySelector('.ps-re-pastilles')
      .querySelectorAll('.ps-re-bouton') : [];
  vrai('D. la liste des widgets subsiste après ouverture', boutons2.length >= 2);
  await envW.clic(boutons2[1]);
  const apres = envW.requetes.filter(r => r.action === 'widgets').length;
  /* Le catalogue vient de retro_fiches.WIDGETS : il est fixe pour la session.
   * Le recharger à chaque clic ajoutait un aller-retour réseau par ouverture,
   * visible comme un clignotement du formulaire. */
  verifier('D. le catalogue n’est chargé qu’une fois pour deux widgets ouverts',
    apres, 1);
  const secW3 = envW.section('widgets');
  vrai('D. le second widget a bien son formulaire',
    secW3 && secW3.querySelector('.ps-re-widget'));
  /* Un catalogue en cache ne doit pas empêcher de retrouver la bonne
   * spécification : le second widget ouvert n'est pas le premier. */
  const formulaire = texte(secW3.querySelector('.ps-re-widget'));
  faux('D. le formulaire affiché n’est pas resté celui du premier widget',
    formulaire === texte(secW2.querySelector('.ps-re-widget'))
      && boutons[0] && texte(boutons[0]) !== texte(boutons2[1]));
}

async function main() {
  await scenarioA();
  await scenarioB();
  await scenarioC();
  await scenarioD();
  process.stderr.write('\nsmoke_re_studio : ' + N + ' contrôles, '
    + (N - OK) + ' échec(s)\n');
  if (echecs.length) {
    echecs.forEach(e => process.stderr.write('  ÉCHEC : ' + e + '\n'));
    process.exit(1);
  }
  process.exit(0);
}

main().catch(e => { process.stderr.write('Exception du banc : ' + (e && e.stack || e) + '\n'); process.exit(1); });
