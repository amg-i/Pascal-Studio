#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : /api/completion, /api/file et la garde d'origine.

POURQUOI CE BANC EXISTE
    La console de l'utilisateur affichait deux lignes, et aucune ne disait la
    même chose :

        GET  http://127.0.0.1:44381/api/file?path=main.pas   400 (Bad Request)
        POST http://127.0.0.1:44381/api/completion           400 (Bad Request)

    Ce banc sépare les trois causes possibles d'un 400 sur ces routes, pour
    qu'on ne les confonde plus :

      1. UN CHEMIN RELATIF RÉSOLU CONTRE LE MAUVAIS RÉFÉRENTIEL. `/api/
         completion` faisait `Path(d.get('path','')).resolve()`, qui rattache un
         chemin relatif au répertoire de lancement du PROCESSUS. Dans l'AppImage
         le serveur Python ne démarre pas dans l'espace de travail : `main.pas`
         se résolvait hors de ROOT, la garde répondait « Fichier non autorisé. »
         et la complétion ne fonctionnait jamais. Corrigé en 4.3.1 par
         corriger-chemin-completion-4.3.1.py. Ce banc est construit pour que le
         défaut soit VISIBLE : `ServeurDeTest` lance server.py avec
         cwd=modifications/ et PASCAL_WORKSPACE=<tmp>, donc cwd != ROOT,
         exactement comme dans l'AppImage.

      2. UN FICHIER QUI N'EXISTE PAS. `/api/file` lit le fichier : si `main.pas`
         n'est pas dans le projet, la réponse est 400 avec
         `[Errno 2] No such file or directory`. C'est le comportement attendu de
         l'interface, qui ouvre un document par défaut avant qu'il existe. Le
         banc le fixe pour qu'on ne le prenne plus pour une régression.

      3. LA GARDE D'ORIGINE. `local_auth_allowed()` refuse une requête dont
         l'en-tête `Origin` ne reprend pas exactement `Host`. Elle protège les
         routes qui touchent aux comptes, à l'identité Git, à l'état du
         navigateur et au démarrage du serveur web — une page ouverte dans le
         navigateur intégré ne doit pas pouvoir les appeler. Elle n'est en
         revanche JAMAIS consultée par `/api/file` ni `/api/completion` : les
         deux derniers contrôles le vérifient, pour qu'un futur 400 sur ces
         routes ne reparte pas dans la mauvaise direction.

    Le banc photographie aussi l'arborescence du projet avant et après : une
    route de lecture qui écrirait quelque chose est un défaut, pas un détail.

Lancer :  cd work/modifications && export PYTHONPATH=$PWD \\
          && python3 tests/smoke_routes_completion.py
"""

import io
import os
import shutil
import sys
import tempfile
import urllib.parse

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
sys.path.insert(0, ICI)
sys.path.insert(0, MODIFICATIONS)

from serveur_de_test import ServeurDeTest          # noqa: E402  (après le path)

OK = 0
N = 0
ECHECS = []


def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    if obtenu == attendu:
        OK += 1
    else:
        ECHECS.append('%s\n      obtenu  : %r\n      attendu : %r'
                      % (titre, obtenu, attendu))


def vrai(titre, condition):
    verifier(titre, bool(condition), True)


def arborescence(racine):
    """L'arborescence du projet, pour comparer avant et après."""
    vu = []
    for dossier, sous, fichiers in os.walk(racine):
        sous.sort()
        for nom in sorted(fichiers):
            vu.append(os.path.relpath(os.path.join(dossier, nom), racine))
    return vu


PASCAL = ('program Demo;\n'
          'var\n'
          '  compteur: Integer;\n'
          'begin\n'
          '  comp\n'
          'end.\n')


def completion(client, **corps):
    """POST brut sur /api/completion.

    `client.post(chemin, entetes=None, **corps)` entre en collision avec une
    clef `chemin` du corps ; `/api/completion` attend `path`, donc pas de
    collision ici, mais le POST reste explicite pour que le banc ne dépende pas
    de la signature du harnais.
    """
    return client.post('/api/completion', **corps)


def main():
    dehors = tempfile.mkdtemp(prefix='ps-test-ext-')
    try:
        with ServeurDeTest() as srv:
            espace = srv.espace()
            client = srv.client
            avant = arborescence(espace)
            vrai('le projet démarre vide (sinon le 400 « fichier absent » '
                 'serait un artefact du banc)', avant == [])
            # Le banc ne prouve quelque chose que si le répertoire de lancement
            # du serveur n'est PAS le projet : c'est la condition du défaut.
            vrai('le serveur ne tourne pas dans le projet (cwd != ROOT)',
                 MODIFICATIONS != espace)

            port = urllib.parse.urlsplit(client.base).port

            # ---------------------------------------------- 1. chemin relatif --
            statut, corps = completion(client, path='main.pas', content=PASCAL,
                                       line=5, column=7)
            verifier('un chemin RELATIF du projet est accepté : c’est le défaut '
                     'de la 4.3.0, la complétion répondait 400 « Fichier non '
                     'autorisé. » à chaque frappe', statut, 200)
            vrai('la réponse porte une liste de propositions',
                 isinstance(corps.get('items'), list))
            items = corps.get('items') or []
            vrai('les propositions ne sont pas vides', len(items) > 0)
            vrai('une proposition est un CompletionItem du protocole',
                 all(isinstance(i, dict) and 'label' in i and 'insertText' in i
                     for i in items[:8]))
            etiquette = ' '.join(str(i.get('label', '')) for i in items)
            vrai('les propositions parlent du tampon envoyé (marqueur positif, '
                 'pas seulement « pas d’erreur »)',
                 'compteur' in etiquette)

            srv.ecrire('main.pas', PASCAL)
            statut_rel, corps_rel = completion(client, path='main.pas',
                                               content=PASCAL, line=5, column=7)
            statut_abs, corps_abs = completion(
                client, path=os.path.join(espace, 'main.pas'), content=PASCAL,
                line=5, column=7)
            verifier('le fichier existe désormais : le chemin relatif donne 200',
                     statut_rel, 200)
            verifier('le chemin ABSOLU du même fichier donne 200', statut_abs, 200)
            # `.get(...) or []` et jamais `corps['items']` : sur le serveur non
            # corrigé la réponse est {'error': ...}, et une KeyError ici
            # masquerait les échecs déjà enregistrés au lieu de les imprimer.
            verifier('les deux écritures du même chemin donnent les mêmes '
                     'propositions',
                     [i.get('label') for i in (corps_rel.get('items') or [])],
                     [i.get('label') for i in (corps_abs.get('items') or [])])

            os.makedirs(os.path.join(espace, 'src'))
            srv.ecrire(os.path.join('src', 'outil.pas'), PASCAL)
            statut, _c = completion(client, path='src/outil.pas',
                                    content=PASCAL, line=5, column=7)
            verifier('un chemin relatif dans un sous-dossier est accepté',
                     statut, 200)

            statut, _c = completion(client, path='introuvable.pas',
                                    content=PASCAL, line=5, column=7)
            verifier('un fichier pas encore enregistré reste complété : c’est le '
                     'TAMPON qui est complété, le chemin ne donne que le langage',
                     statut, 200)

            # ------------------------------------------------------ 2. refus --
            statut, corps = completion(client, path='/etc/passwd',
                                       content='x', line=1, column=2)
            verifier('un chemin absolu hors du projet est refusé', statut, 400)
            verifier('le refus nomme la raison',
                     corps.get('error'), 'Fichier non autorisé.')

            statut, corps = completion(client, path='../../etc/passwd',
                                       content='x', line=1, column=2)
            verifier('une remontée relative hors du projet est refusée',
                     statut, 400)
            verifier('la remontée est refusée pour la même raison',
                     corps.get('error'), 'Fichier non autorisé.')

            statut, corps = completion(client, path='mai\x00n.pas',
                                       content='x', line=1, column=2)
            verifier('un octet nul dans le chemin est refusé', statut, 400)
            verifier('l’octet nul est nommé', corps.get('error'), 'Chemin invalide')

            statut, corps = completion(client, path=42, content='x',
                                       line=1, column=2)
            verifier('un chemin qui n’est pas une chaîne est refusé', statut, 400)
            verifier('le type invalide est nommé',
                     corps.get('error'), 'Chemin invalide')

            statut, corps = completion(client, path='main.pas', line=5, column=7)
            verifier('un tampon absent est refusé', statut, 400)
            verifier('le tampon absent est nommé',
                     corps.get('error'), 'Tampon manquant.')

            statut, corps = completion(client, path='main.pas', content=PASCAL,
                                       line=0, column=7)
            verifier('une position invalide est refusée', statut, 400)
            verifier('la position invalide est nommée',
                     corps.get('error'), 'Position invalide.')

            # ------------------------------------- 3. fichier externe ouvert --
            externe = os.path.join(dehors, 'note.md')
            io.open(externe, 'w', encoding='utf8').write('# Titre\n\nmot\n')
            statut, corps = client.post('/api/external/open', path=externe)
            verifier('un fichier hors du projet peut être ouvert explicitement',
                     statut, 200)
            statut, _c = completion(client, path=externe, content='# Titre\n\nmo',
                                    line=3, column=3)
            verifier('un fichier externe OUVERT reste autorisé par la garde '
                     '(sinon la seconde branche de la garde ne servirait à rien)',
                     statut, 200)
            statut, corps = completion(client, path=os.path.join(dehors, 'autre.md'),
                                       content='x', line=1, column=2)
            verifier('un fichier externe NON ouvert reste refusé', statut, 400)
            verifier('le refus est le même',
                     corps.get('error'), 'Fichier non autorisé.')

            # ------------------------------------- 4. /api/file et son 400 ----
            statut, corps = client.get('/api/file?path=absent.pas')
            verifier('lire un fichier absent répond 400', statut, 400)
            vrai('le 400 de /api/file NOMME le fichier manquant : c’est la ligne '
                 'de la console de l’utilisateur, et elle est normale tant que '
                 'le document par défaut n’existe pas',
                 'absent.pas' in str(corps.get('error', ''))
                 and 'No such file' in str(corps.get('error', '')))
            statut, corps = client.get('/api/file?path=main.pas')
            verifier('lire un fichier présent répond 200', statut, 200)
            verifier('le contenu est rendu tel quel',
                     corps.get('content'), PASCAL)
            statut, corps = client.get('/api/file?path=../server.py')
            verifier('une remontée hors du projet est refusée par resolve()',
                     statut, 400)
            verifier('resolve() nomme son refus',
                     corps.get('error'), 'Chemin interdit')

            # ------------------------------- 5. la garde d’origine, pour mémoire --
            statut, _c = client.get('/api/navigateur',
                                    entetes={'Origin': 'http://127.0.0.1:%d' % port})
            verifier('une origine qui reprend exactement Host est acceptée sur '
                     'une route gardée', statut, 200)
            statut, corps = client.get('/api/navigateur',
                                       entetes={'Origin': 'http://exemple.test'})
            verifier('une origine étrangère est refusée sur une route gardée',
                     statut, 400)
            verifier('le refus d’origine est nommé comme tel',
                     corps.get('error'), 'Origine non autorisée.')
            statut, corps = client.get('/api/navigateur',
                                       entetes={'Origin': 'http://localhost:%d' % port})
            verifier('la garde compare Host et Origin LITTÉRALEMENT : une page '
                     'servie sous localhost interrogeant 127.0.0.1 est refusée. '
                     'Ce n’est pas le cas de l’application, dont l’origine et '
                     'l’hôte concordent — ce contrôle existe pour qu’on ne '
                     'cherche plus de ce côté', statut, 400)
            statut, _c = client.get('/api/file?path=main.pas',
                                    entetes={'Origin': 'http://exemple.test'})
            verifier('/api/file ne consulte JAMAIS la garde d’origine : une '
                     'origine étrangère ne change pas sa réponse', statut, 200)
            statut, _c = completion(client, path='main.pas', content=PASCAL,
                                    line=5, column=7)
            verifier('/api/completion ne consulte pas non plus la garde',
                     statut, 200)

            apres = arborescence(espace)
            verifier('rien n’a été écrit dans le projet en dehors des fixtures '
                     'du banc',
                     apres, ['main.pas', os.path.join('src', 'outil.pas')])
    finally:
        shutil.rmtree(dehors, ignore_errors=True)

    if ECHECS:
        print('ECHEC smoke_routes_completion : %d contrôle(s) en échec sur %d'
              % (len(ECHECS), N))
        for e in ECHECS:
            print('   - ' + e)
        return 1
    print('smoke_routes_completion : %d contrôles, aucun échec' % N)
    return 0


if __name__ == '__main__':
    sys.exit(main())
