#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : les routes /api/devweb servies par le VRAI serveur.

Pourquoi ce banc existe à côté de l'autocontrôle de devweb.py
------------------------------------------------------------
    `python3 devweb.py` exerce la façade en appelant ses fonctions. Ce n'est pas
    ce que fait l'interface : elle envoie `POST /api/devweb` avec un chemin
    RELATIF au projet, et lit une réponse JSON. Trois choses ne sont visibles
    qu'ici :

      * le confinement passe par `resolve()` du serveur, pas seulement par celui
        de la façade — les deux doivent refuser, avec des messages différents,
        et le banc vérifie lequel arrive ;
      * la garde `local_auth_allowed()` doit rejeter un Origin étranger sur ces
        routes comme sur celles des comptes, parce que `requeter` fait sortir du
        trafic de la machine et que le journal contient des messages console ;
      * le dispatch est écrit à la main, branche par branche : une action mal
        orthographiée ici renverrait « Action dev web inconnue » à
        l'utilisateur alors que le module, lui, fonctionne.

    Ce banc vérifie aussi une propriété de conception : les routes dev web ne
    créent AUCUN fichier. Un fichier généré est rendu en texte, et son
    enregistrement passe par /api/create et /api/save.

Lancer :  python3 tests/smoke_routes_devweb.py
"""

import json
import os
import struct
import sys
import time
import zlib

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serveur_de_test import ServeurDeTest, dependance

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def png(largeur=8, hauteur=8):
    """Un vrai PNG, pas un fichier d'extension .png : l'audit de poids lit ses
    dimensions, et un faux PNG ferait échouer le banc sans faute du produit."""
    def morceau(type_, donnees):
        return (struct.pack('>I', len(donnees)) + type_ + donnees
                + struct.pack('>I', zlib.crc32(type_ + donnees) & 0xffffffff))

    ihdr = struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0)
    brut = b''.join(b'\x00' + b'\x20\x40\x80' * largeur for _ in range(hauteur))
    return (b'\x89PNG\r\n\x1a\n' + morceau(b'IHDR', ihdr)
            + morceau(b'IDAT', zlib.compress(brut)) + morceau(b'IEND', b''))


INDEX = """<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Page de banc pour l'audit dev web</title>
<meta name="description" content="Une description assez longue pour passer le contrôle de longueur des moteurs de recherche, entre 70 et 160 caractères.">
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<a href="#contenu">Aller au contenu</a>
<div id="contenu"></div>
<div id="contenu"></div>
<h1>Titre</h1>
<img src="img/Hero.png" alt="Image dont la casse diffère du fichier">
<img src="manquant.png" alt="Image absente du projet">
<img src="img/hero.png" alt="Image présente" width="8" height="8">
<a href="#inconnu">Ancre cassée</a>
<a href="https://exemple.fr/" target="_blank">Lien externe sans noopener</a>
<form action="/envoyer" method="post">
  <input type="text" name="sans-etiquette">
</form>
<script src="app.js" defer></script>
</body>
</html>
"""

STYLE = """body { color: #111; background: #fff }
.titre { font-size: 2rem
.pied { margin-top: 2rem; }
"""

APP = """document.write('<b>bonjour</b>');
eval('1 + 1');
var x = 1;
"""

HTACCESS = """<IfModule mod_headers.c>
  Header always set X-Content-Type-Options "nosniff"
  Header always set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
"""


def construire(srv):
    # srv.ecrire ne crée pas les dossiers parents : dirname('site/img') est
    # 'site', donc passer par dirname créerait 'site' et non 'site/img'.
    os.makedirs(srv.chemin('site/img'), exist_ok=True)
    os.makedirs(srv.chemin('site/css'), exist_ok=True)
    srv.ecrire('site/index.html', INDEX)
    srv.ecrire('site/css/style.css', STYLE)
    srv.ecrire('site/app.js', APP)
    srv.ecrire('site/.htaccess', HTACCESS)
    srv.ecrire('site/img/hero.png', png(8, 8), mode='wb')
    srv.ecrire('site/page2.html',
               '<!DOCTYPE html><html lang="fr"><head><title>Seconde</title>'
               '</head><body><a href="index.html">Retour</a></body></html>')


def codes(rapport, audit=None):
    """L'ensemble des codes de constat, tous audits confondus ou un seul."""
    sortie = set()
    audits = rapport.get('audits') or {}
    cibles = ([audit] if audit else list(audits))
    for nom in cibles:
        for constat in audits.get(nom, []):
            sortie.add(constat['code'])
    return sortie


def messages(rapport, code):
    return [c['message'] for c in sum(rapport.get('audits', {}).values(), [])
            if c['code'] == code]


def principal():
    if not dependance('urllib.request'):
        sys.stderr.write('urllib indisponible.\n')
        return 1

    with ServeurDeTest() as srv:
        construire(srv)
        client = srv.client

        # ------------------------------------------------------ 1. capacités --
        statut, corps = client.get('/api/devweb')
        verif(statut == 200, 'GET /api/devweb répond 200 (%s)' % statut)
        verif(corps.get('ok') is True, 'GET /api/devweb répond ok')
        verif(corps.get('version') == '4.0.0',
              'GET /api/devweb annonce la version 4.0.0 (%r)'
              % corps.get('version'))
        audits = corps.get('audits') or []
        verif([a['id'] for a in audits] == ['accessibilite', 'securite',
                                            'liens', 'poids', 'metadonnees',
                                            'validation'],
              'les six audits sont annoncés, dans l’ordre : %r'
              % [a['id'] for a in audits])
        verif(all(a.get('nom') and a.get('resume') for a in audits),
              'chaque audit annonce un nom et un résumé')
        generateurs = corps.get('generateurs') or []
        verif(len(generateurs) >= 15,
              'au moins 15 générateurs annoncés (%d)' % len(generateurs))
        verif(all(set(g) >= {'id', 'nom', 'groupe', 'langage', 'fichier',
                             'description', 'parametres'}
                  for g in generateurs),
              'chaque générateur annonce ses champs, paramètres compris')
        verif(all(p.get('nom') and p.get('libelle') and p.get('type')
                  for g in generateurs for p in g['parametres']),
              'chaque paramètre annonce un nom, un libellé et un type')
        verif(len(corps.get('extraits') or []) >= 25,
              'au moins 25 extraits annoncés (%d)'
              % len(corps.get('extraits') or []))
        verif(len(corps.get('viewports') or []) == 11,
              'les 11 viewports sont annoncés (%d)'
              % len(corps.get('viewports') or []))
        verif(all(v.get('largeur') and v.get('hauteur') and v.get('dpr')
                  for v in corps.get('viewports') or []),
              'chaque viewport annonce largeur, hauteur et densité')
        verif(len(corps.get('en_tetes_securite') or []) == 8,
              'les 8 en-têtes de sécurité sont annoncés')
        verif(all(e.get('role') and e.get('conseil')
                  for e in corps.get('en_tetes_securite') or []),
              'chaque en-tête de sécurité explique son rôle et son conseil')
        verif(len(corps.get('motifs_dangereux') or []) == 8,
              'les 8 motifs dangereux sont annoncés (%d)'
              % len(corps.get('motifs_dangereux') or []))
        verif(isinstance(corps.get('etat'), dict)
              and corps['etat'].get('journal') is not None,
              'GET /api/devweb rend aussi l’état et le journal')
        verif(isinstance(corps.get('journal'), dict)
              and 'entrees' in corps['journal'],
              'GET /api/devweb rend le début du journal')

        # ------------------------------------------------------------ 2. audit --
        statut, rapport = client.post('/api/devweb', action='auditer',
                                      path='site/index.html')
        verif(statut == 200, 'auditer répond 200 (%s : %r)'
              % (statut, rapport.get('error')))
        verif(rapport.get('ok') is True, 'auditer rend ok')
        verif(set(rapport.get('audits', {})) == {'accessibilite', 'securite',
                                                 'liens', 'poids',
                                                 'metadonnees', 'validation'},
              'les six audits sont rendus : %r'
              % sorted(rapport.get('audits', {})))
        verif('audit-interrompu' not in codes(rapport),
              'aucun audit n’est interrompu : %r'
              % messages(rapport, 'audit-interrompu'))
        verif(rapport.get('encodage') == 'utf-8',
              'auditer rend l’encodage utilisé (%r)' % rapport.get('encodage'))
        note = rapport.get('note_globale')
        verif(isinstance(note, int) and 0 <= note <= 100,
              'la note globale est un entier entre 0 et 100 (%r)' % note)
        verif(note < 90, 'une page volontairement cassée n’obtient pas une '
              'note presque parfaite (%s)' % note)
        # resume() rend le compte par gravité et la note : ce sont les clefs
        # réelles, pas un champ « nombre » inventé par le banc.
        for nom, resume in (rapport.get('resume') or {}).items():
            # « _global » additionne les constats de tous les audits : sa note
            # est rendue à part, dans note_globale, et non dans le résumé.
            verif((nom == '_global' or isinstance(resume.get('note'), int))
                  and all(g in resume for g in
                          ('erreur', 'avertissement', 'info', 'ok')),
                  'le résumé de l’audit « %s » porte une note et les quatre '
                  'gravités (%r)' % (nom, sorted(resume)))
            verif(sum(resume[g] for g in ('erreur', 'avertissement', 'info',
                                          'ok'))
                  == len(rapport['audits'].get(nom, []))
                  or nom == '_global',
                  'le résumé de « %s » compte exactement ses constats' % nom)

        # Les défauts PLANTÉS dans la fixture doivent être trouvés, un par un.
        for attendu, pourquoi in (
                ('casse-differente', 'img/Hero.png contre img/hero.png'),
                ('fichier-introuvable', 'manquant.png'),
                ('fragment-casse', '#inconnu'),
                ('id-duplique', 'deux id="contenu"'),
                ('noopener-manquant', 'target=_blank sans rel'),
                ('champ-sans-etiquette', 'input sans étiquette'),
                ('css-accolade-ouverte', 'accolade non fermée dans la feuille'),
                ('eval', 'eval dans app.js'),
                ('document-write', 'document.write dans app.js'),
                ('og-incomplet', 'aucune balise Open Graph'),
                ('img-sans-dimensions', 'images sans width ni height'),
        ):
            verif(attendu in codes(rapport),
                  'le défaut planté « %s » est trouvé (%s)' % (attendu, pourquoi))

        # L'erreur CSS doit NOMMER la feuille liée : un numéro de ligne seul
        # pointerait dans le document HTML, qui n'a rien à voir.
        css = messages(rapport, 'css-accolade-ouverte')
        verif(css and 'css/style.css' in css[0],
              'l’erreur de CSS nomme la feuille liée (%r)' % css[:1])
        verif(all(c.get('ligne') is None
                  for a in rapport['audits'].values() for c in a
                  if c['code'] == 'css-accolade-ouverte'),
              'une erreur de feuille liée ne porte pas une ligne du document')

        # Les motifs JavaScript doivent dire d'où ils viennent.
        evaluation = [c for a in rapport['audits'].values() for c in a
                      if c['code'] == 'eval']
        verif(evaluation and 'app.js' in evaluation[0]['message'],
              'un motif dangereux nommé dans un script externe cite ce script '
              '(%r)' % (evaluation[0]['message'][:120] if evaluation else None))

        # Cohérence entre règles : le .htaccess déclare Referrer-Policy, donc
        # l'audit doit le dire ici ET ne pas se plaindre de son absence.
        verif('en-tete-declare' in codes(rapport, 'securite'),
              'un en-tête déclaré dans .htaccess est vu comme déclaré')
        verif(any('referrer-policy' in m.lower()
                  for m in messages(rapport, 'en-tete-declare')),
              'Referrer-Policy du .htaccess est nommément déclaré')
        verif('referrer-non-defini' not in codes(rapport),
              'aucune règle ne contredit la déclaration du .htaccess')
        verif('en-tete-non-declare' in codes(rapport, 'securite'),
              'un en-tête absent de toute configuration est signalé')

        # Poids : le transféré ne peut pas dépasser le total.
        poids = rapport.get('donnees', {}).get('poids') or {}
        verif(poids.get('transfere', 0) <= poids.get('total', 0),
              'le poids transféré (%s) ne dépasse pas le total (%s)'
              % (poids.get('transfere'), poids.get('total')))
        verif(poids.get('total', 0) > 0, 'le poids total est mesuré')
        verif(poids.get('requetes', 0) >= 3,
              'les requêtes sont comptées (%s)' % poids.get('requetes'))

        # Un audit partiel ne rend que ce qui est demandé.
        statut, partiel = client.post('/api/devweb', action='auditer',
                                      path='site/index.html',
                                      seulement=['liens', 'poids'])
        verif(statut == 200 and set(partiel.get('audits', {})) ==
              {'liens', 'poids'},
              'seulement=[…] limite les audits rendus : %r'
              % sorted(partiel.get('audits', {})))

        # Un contenu fourni directement, sans chemin : c'est ce que l'aperçu
        # envoie, pour auditer exactement ce qui est servi.
        statut, direct = client.post('/api/devweb', action='auditer', contenu=(
            '<!DOCTYPE html><html lang="fr"><head><meta charset="utf-8">'
            '<title>Contenu direct</title></head><body><h1>x</h1>'
            '</body></html>'))
        verif(statut == 200 and direct.get('ok')
              and 'metadonnees' in direct.get('audits', {}),
              'auditer accepte un contenu sans chemin')

        # -------------------------------------------------- 3. confinements --
        statut, refuse = client.post('/api/devweb', action='auditer',
                                     path='../../etc/passwd')
        verif(statut == 400 and 'interdit' in str(refuse.get('error', '')).lower(),
              'un chemin qui sort du projet est refusé (%s : %r)'
              % (statut, refuse))
        statut, refuse = client.post('/api/devweb', action='auditer',
                                     path='site/inexistant.html')
        verif(statut != 200 or refuse.get('ok') is False,
              'un fichier inexistant est refusé (%s : %r)' % (statut, refuse))
        verif('introuvable' in str(refuse.get('error') or refuse.get('erreur')
                                   or '').lower(),
              'un fichier inexistant est dit introuvable (%r)' % refuse)
        statut, refuse = client.post('/api/devweb', action='auditer',
                                     path='site')
        verif(refuse.get('ok') is False
              and 'dossier' in str(refuse.get('erreur') or '').lower(),
              'un dossier n’est pas audité comme un document (%r)' % refuse)
        statut, refuse = client.post('/api/devweb', action='auditer',
                                     contenu='   ')
        verif(refuse.get('ok') is False, 'un document vide n’est pas audité')

        # ------------------------------------------------- 4. inventaire ------
        statut, inv = client.post('/api/devweb', action='inventaire',
                                  path='site')
        verif(statut == 200 and inv.get('ok'), 'inventaire répond ok')
        verif(inv.get('nombre_pages') == 2,
              'l’inventaire compte les deux pages HTML (%s)'
              % inv.get('nombre_pages'))
        verif(inv.get('page_accueil') == 'index.html',
              'l’inventaire de site/ désigne index.html comme accueil, en '
              'chemin relatif au dossier demandé (%r)' % inv.get('page_accueil'))
        verif(inv.get('racine', '').endswith('site'),
              'l’inventaire porte sur le dossier demandé, pas sur le projet '
              'entier (%r)' % inv.get('racine'))
        groupes = {c['groupe'] for c in inv.get('categories') or []}
        verif({'html', 'css', 'javascript', 'images'} <= groupes,
              'l’inventaire classe par catégorie (%r)' % sorted(groupes))
        verif(inv.get('octets', 0) > 0, 'l’inventaire mesure le poids')
        statut, inv = client.post('/api/devweb', action='inventaire')
        # .htaccess fait partie du projet (c'est lui que lit l'audit de
        # sécurité) ; .git et ses contenus, non.
        verif(statut == 200 and inv.get('ok')
              and inv.get('nombre_fichiers', 0) == 6,
              'l’inventaire du projet entier compte 6 fichiers, .htaccess '
              'compris (%s)' % inv.get('nombre_fichiers'))
        verif(any(c['groupe'] == 'serveur' for c in inv.get('categories') or []),
              '.htaccess est classé comme fichier de serveur (%r)'
              % [c['groupe'] for c in inv.get('categories') or []])

        # ---------------------------------------------------- 5. analyse -----
        statut, ana = client.post('/api/devweb', action='analyser',
                                  path='site/index.html')
        verif(statut == 200 and ana.get('ok'), 'analyser répond ok')
        verif(ana.get('titre') == 'Page de banc pour l’audit dev web'
              or ana.get('titre') == "Page de banc pour l'audit dev web",
              'analyser rend le titre exact (%r)' % ana.get('titre'))
        verif(ana.get('langue') == 'fr', 'analyser rend la langue')
        verif([f['href'] for f in ana.get('feuilles') or []] == ['css/style.css'],
              'analyser rend les feuilles liées (%r)' % ana.get('feuilles'))
        verif(len(ana.get('images') or []) == 3,
              'analyser rend les trois images (%d)'
              % len(ana.get('images') or []))
        verif(ana.get('encodage') == 'utf-8',
              'analyser rend l’encodage de lecture (%r)' % ana.get('encodage'))
        verif(not ana.get('notes'),
              'analyser ne signale rien sur un document UTF-8 sain (%r)'
              % ana.get('notes'))
        statut, ana = client.post('/api/devweb', action='analyser')
        verif(ana.get('ok') is False,
              'analyser sans contenu ni chemin est refusé (%r)' % ana)

        # ------------------------------------------------- 6. génération -----
        statut, gen = client.post('/api/devweb', action='generer',
                                  generateur='page-html5',
                                  parametres={'titre': 'Titre du banc',
                                              'site': 'Banc'})
        verif(statut == 200 and gen.get('ok'), 'generer répond ok')
        verif('<title>Titre du banc</title>' in (gen.get('contenu') or ''),
              'le paramètre titre est appliqué')
        verif(gen.get('fichier') == 'index.html'
              and gen.get('langage') == 'html',
              'generer annonce le fichier et le langage (%r, %r)'
              % (gen.get('fichier'), gen.get('langage')))
        verif(gen.get('octets') == len((gen.get('contenu') or '')
                                       .encode('utf8')),
              'generer annonce le poids réel du fichier')
        verif(isinstance(gen.get('notes'), list) and gen['notes'],
              'generer rend des notes sur ce qui reste à personnaliser')
        verif('{{' not in (gen.get('contenu') or ''),
              'aucun gabarit {{…}} ne subsiste dans le fichier généré')

        statut, gen = client.post('/api/devweb', action='generer',
                                  generateur='sri', parametres={})
        verif(gen.get('ok') is False
              and 'empreinte' in str(gen.get('erreur') or '').lower(),
              'SRI sans entrée échoue en le disant, plutôt que de rendre une '
              'balise sans integrity (%r)' % gen.get('erreur'))

        statut, gen = client.post('/api/devweb', action='generer',
                                  generateur='inexistant')
        verif(gen.get('ok') is False
              and 'page-html5' in str(gen.get('erreur') or ''),
              'un générateur inconnu est refusé en nommant les disponibles')

        statut, gen = client.post('/api/devweb', action='generer',
                                  generateur='entetes-htaccess',
                                  parametres={'hsts': True,
                                              'encadrement': 'PAS_UNE_OPTION'})
        verif(gen.get('ok') and 'PAS_UNE_OPTION' not in gen['contenu'],
              'un choix hors liste retombe sur la valeur par défaut')

        # --------------------------------------------------- 7. extraits -----
        statut, ext = client.post('/api/devweb', action='extraits',
                                  recherche='clamp')
        verif(statut == 200 and ext.get('ok')
              and [e['id'] for e in ext['extraits']] == ['typographie-fluide'],
              'la recherche porte aussi sur le CODE des extraits (%r)'
              % [e['id'] for e in ext.get('extraits') or []])
        statut, ext = client.post('/api/devweb', action='extraits',
                                  groupe='Accessibilité')
        verif(len(ext.get('extraits') or []) == 4,
              'le filtre par groupe rend les 4 extraits d’accessibilité (%d)'
              % len(ext.get('extraits') or []))
        statut, ext = client.post('/api/devweb', action='extraits',
                                  extrait='fetch-propre')
        verif(ext.get('ok')
              and ('response.ok' in ext['extrait']['code']
                   or 'reponse.ok' in ext['extrait']['code']),
              'un extrait demandé par identifiant est rendu avec son code')
        statut, ext = client.post('/api/devweb', action='extraits',
                                  extrait='inexistant')
        verif(ext.get('ok') is False, 'un extrait inconnu est refusé')

        # -------------------------------------------------- 8. viewports -----
        statut, vp = client.post('/api/devweb', action='viewports')
        verif(statut == 200 and vp.get('ok') and len(vp['viewports']) == 11,
              'viewports rend les 11 tailles')
        verif(any(v['id'] == 'mobile-s' and v['largeur'] == 320
                  for v in vp['viewports']),
              'le plus petit viewport est 320 px')
        verif(vp.get('points_rupture'), 'les points de rupture sont rendus')

        # --------------------------------------------------- 9. requêtes -----
        statut, req = client.post('/api/devweb', action='requeter',
                                  url='ftp://exemple.fr/x')
        verif(statut == 200 and req.get('ok') is False
              and 'schéma' in str(req.get('erreur') or '').lower(),
              'un schéma non HTTP est refusé en le disant (%r)'
              % req.get('erreur'))
        statut, req = client.post('/api/devweb', action='requeter')
        verif(statut != 200 or req.get('ok') is False,
              'requeter sans adresse est refusé (%r)' % req)
        # Une requête RÉELLE contre le serveur de test lui-même : elle prouve
        # que le client fonctionne de bout en bout, depuis le processus du
        # serveur, sans dépendre d'Internet.
        statut, req = client.post('/api/devweb', action='requeter',
                                  url='http://127.0.0.1:%d/api/status' % srv.port)
        verif(req.get('ok') and req.get('statut') == 200,
              'une requête locale réelle aboutit (%r, %r)'
              % (req.get('statut'), req.get('erreur')))
        verif(req.get('locale') is True,
              'une adresse 127.0.0.1 est dite locale')
        verif('content-type' in (req.get('entetes') or {}),
              'les en-têtes de la réponse sont rendus en minuscules (%r)'
              % sorted((req.get('entetes') or {}))[:4])
        verif(json.loads(req.get('corps') or '{}').get('workspace'),
              'le corps de la réponse est décodé en JSON utilisable')
        verif(isinstance(req.get('duree_ms'), float),
              'la durée de la requête est mesurée')
        verif('apercu' in req, 'un aperçu texte de la réponse est rendu')

        # --------------------------------------------------- 10. journal -----
        statut, vide = client.post('/api/devweb', action='journal-vider',
                                   raison='Banc de test dev web')
        verif(statut == 200 and vide.get('ok'), 'journal-vider répond ok')
        verif(vide.get('total') == 1,
              'journal-vider laisse la seule entrée système (%s)'
              % vide.get('total'))
        statut, jour = client.post('/api/devweb', action='journal', depuis=0,
                                   limite=50)
        verif(jour.get('total') == 1
              and jour['entrees'][0]['message'] == 'Banc de test dev web',
              'le journal rend l’entrée système avec son message (%r)'
              % jour.get('entrees'))
        verif(jour.get('suivant') == 1,
              'le journal rend l’identifiant à rappeler (%r)'
              % jour.get('suivant'))
        statut, stats = client.post('/api/devweb', action='statistiques')
        verif(stats.get('ok') and stats['statistiques']['total'] == 1,
              'statistiques rend le compte du journal (%r)' % stats)

        # ------------------------------------------------ 11. action inconnue --
        statut, faux = client.post('/api/devweb', action='detruire')
        verif(statut == 400 and 'detruire' in str(faux.get('error') or ''),
              'une action inconnue est refusée en nommant l’action (%r)' % faux)

        # ---------------------------------------------------- 12. gardes -----
        statut, garde = client.get('/api/devweb',
                                   entetes={'Origin': 'http://evil.example'})
        verif(statut == 400
              and 'origine' in str(garde.get('error') or '').lower(),
              'un Origin étranger est refusé sur GET (%s : %r)'
              % (statut, garde))
        statut, garde = client.post('/api/devweb',
                                    entetes={'Origin': 'http://evil.example'},
                                    action='capacites')
        verif(statut == 400
              and 'origine' in str(garde.get('error') or '').lower(),
              'un Origin étranger est refusé sur POST (%s : %r)'
              % (statut, garde))
        statut, garde = client.get('/api/devweb',
                                   entetes={'Host': 'exemple.fr'})
        verif(statut == 400, 'un Host non local est refusé (%s)' % statut)

        # ------------------------------------- 13. aucune écriture de fichier --
        # Propriété de conception : les routes dev web sont en lecture seule.
        time.sleep(0.9)                      # le cache de /api/tree dure 0,75 s
        statut, arbre = client.get('/api/tree')
        noms = set()

        def parcourir(noeuds, prefixe=''):
            for noeud in noeuds or []:
                chemin = (prefixe + '/' + noeud['name']).lstrip('/')
                noms.add(chemin)
                parcourir(noeud.get('children'), chemin)

        parcourir(arbre.get('tree') if isinstance(arbre, dict) else arbre)
        verif(statut == 200, 'l’arbre est relisible après les actions (%s)'
              % statut)
        verif('site/index.html' in noms,
              'les fixtures sont toujours présentes (%r)' % sorted(noms)[:8])
        verif(not any(nom.endswith(('.html', '.css', '.js', '.txt', '.conf'))
                      and nom not in ('site/index.html', 'site/page2.html',
                                      'site/css/style.css', 'site/app.js')
                      for nom in noms),
              'aucun fichier généré n’a été écrit par les routes dev web (%r)'
              % sorted(noms))

    return 0 if not ECHECS else 1


def main():
    depart = time.monotonic()
    code = principal()
    sys.stderr.write('\nsmoke_routes_devweb : %d contrôles, %d échec(s), %.1f s\n'
                     % (OK + len(ECHECS), len(ECHECS),
                        time.monotonic() - depart))
    if ECHECS:
        for echec in ECHECS:
            sys.stderr.write('  - %s\n' % echec)
    return code


if __name__ == '__main__':
    sys.exit(main())
