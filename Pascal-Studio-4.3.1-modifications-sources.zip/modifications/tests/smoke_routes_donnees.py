#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : les routes /api/data/* servies par le VRAI serveur.

Pourquoi ce banc existe à côté de smoke_donnees_etendues.py
----------------------------------------------------------
    smoke_donnees_etendues.py appelle les modules Python directement. C'est
    nécessaire mais pas suffisant : l'interface n'appelle jamais
    `donnees_etendues.lire()`, elle fait `POST /api/data/open` avec un chemin
    RELATIF au projet, puis `/api/data/tables`, `/api/data/query`, et pour le
    repli texte `GET /api/file` et `POST /api/save`.

    Ce banc démarre donc `server.py` comme le fait l'application, sur un port
    libre et un espace de travail temporaire, et lui parle en HTTP. C'est lui
    qui a révélé que les attributs XML ne devenaient pas des colonnes : le banc
    module passait, parce qu'il n'essayait que la forme « enfants », et
    `SELECT nom FROM contact` échouait sur un fichier qui contient bien un nom.

    Deux pièges rencontrés en l'écrivant, à ne pas réapprendre :
      * `server.py` n'est PAS une application Starlette — `TestClient` ne sert
        à rien ici, il faut un vrai socket. L'app Starlette est celle de
        l'assistant IA, un autre serveur.
      * `/api/tree` a un cache partagé de 0,75 s. Une sonde de disponibilité
        qui l'interroge avant la création des fixtures le remplit à vide, et le
        banc accuse alors le produit pour son propre artefact. La sonde utilise
        donc une route sans cache, et le contrôle de l'arbre attend le TTL.

Lancer :  python3 tests/smoke_routes_donnees.py
"""

import io
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serveur_de_test import ServeurDeTest, dependance

OK = 0
ECHECS = 0


def verif(condition, titre):
    global OK, ECHECS
    if condition:
        OK += 1
    else:
        ECHECS += 1
        print('  ECHEC : %s' % titre)


def egal(titre, obtenu, attendu):
    if obtenu == attendu:
        verif(True, titre)
    else:
        verif(False, '%s\n        obtenu  : %r\n        attendu : %r'
              % (titre, obtenu, attendu))


def preparer(racine):
    import openpyxl
    classeur = openpyxl.Workbook()
    feuille = classeur.active
    feuille.title = 'Clients'
    feuille.append(['id', 'nom', 'ville'])
    feuille.append([1, 'Ada', 'Londres'])
    feuille.append([2, 'Grace', 'New York'])
    classeur.save(os.path.join(racine, 'clients.xlsx'))

    io.open(os.path.join(racine, 'notes.xml'), 'w', encoding='utf-8').write(
        '<?xml version="1.0"?>\n<carnet>\n'
        '  <contact id="1" nom="Ada"/><contact id="2" nom="Grace"/>\n</carnet>\n')
    io.open(os.path.join(racine, 'enfants.xml'), 'w', encoding='utf-8').write(
        '<?xml version="1.0"?>\n<biblio>\n'
        '  <livre><titre>Dune</titre><annee>1965</annee></livre>\n'
        '  <livre><titre>Fondation</titre><annee>1951</annee></livre>\n'
        '</biblio>\n')
    io.open(os.path.join(racine, 'faux.sqlite'), 'w', encoding='utf-8').write(
        'pas une base\ndeux lignes\n')
    io.open(os.path.join(racine, 'donnees.csv'), 'w', encoding='utf-8').write(
        'id;nom\n1;Ada\n2;Grace\n')
    io.open(os.path.join(racine, 'notes.txt'), 'w', encoding='utf-8').write(
        'texte simple\n')
    io.open(os.path.join(racine, 'plat.xml'), 'w', encoding='utf-8').write(
        '<?xml version="1.0"?><r><a>1</a><b>2</b></r>')


def main():
    if not dependance('openpyxl'):
        print('openpyxl absent : ce banc ne peut pas fabriquer un XLSX réel.')
        return 2

    with ServeurDeTest() as srv:
        racine = srv.espace()
        preparer(racine)
        client = srv.client

        # ---- L'arbre du projet, dont le sélecteur de fichiers se nourrit ----
        # Le cache de 0,75 s peut contenir un instantané d'avant les fixtures.
        time.sleep(0.9)
        statut, arbre = client.get('/api/tree')
        egal('/api/tree répond 200', statut, 200)
        noms = sorted(n.get('name') for n in (arbre.get('tree') or []))
        egal('l’arbre liste les fichiers du projet', noms,
             ['clients.xlsx', 'donnees.csv', 'enfants.xml', 'faux.sqlite',
              'notes.txt', 'notes.xml', 'plat.xml'])

        # ---- XLSX : ouverture, tables, lecture, refus d'écriture -----------
        statut, ouverts = client.data('open', path='clients.xlsx')
        egal('xlsx : open -> 200', statut, 200)
        egal('xlsx : kind', ouverts.get('kind'), 'xlsx')
        egal('xlsx : le miroir est annoncé', ouverts.get('miroir'), True)
        egal('xlsx : label', ouverts.get('label'), 'clients.xlsx')
        verif(isinstance(ouverts.get('id'), str) and len(ouverts['id']) > 8,
              'xlsx : un identifiant de session est rendu')
        verif(isinstance(ouverts.get('revision'), str),
              'xlsx : une révision est rendue')
        session = ouverts.get('id')

        statut, tables = client.data('tables', id=session)
        egal('xlsx : tables -> 200', statut, 200)
        egal('xlsx : la feuille devient une table',
             [t['name'] for t in tables.get('tables') or []], ['Clients'])

        statut, res = client.data('query', id=session,
                                  sql='SELECT nom FROM Clients WHERE id=2',
                                  commit=False)
        egal('xlsx : query -> 200', statut, 200)
        egal('xlsx : la requête rend la bonne valeur', res.get('rows'), [['Grace']])
        egal('xlsx : les colonnes sont nommées', res.get('columns'), ['nom'])
        egal('xlsx : la réponse rappelle le miroir', res.get('miroir'), True)

        statut, jointure = client.data(
            'query', id=session, commit=False,
            sql='SELECT c.nom, c.ville FROM Clients c WHERE c.ville LIKE \'Lond%\'')
        egal('xlsx : une requête avec alias et LIKE fonctionne', statut, 200)
        egal('xlsx : le filtrage est correct', jointure.get('rows'), [['Ada', 'Londres']])

        statut, refus = client.data('query', id=session,
                                    sql='DELETE FROM Clients', commit=True)
        egal('xlsx : DELETE est refusé', statut, 400)
        message = refus.get('error') or ''
        verif('COPIE' in message or 'copie' in message,
              'xlsx : le refus dit qu’il s’agit d’une copie en mémoire, pas '
              'seulement qu’il refuse : %r' % message)
        verif('écrite' in message or 'écrirait' in message,
              'xlsx : le refus explique que rien ne serait écrit : %r' % message)
        client.data('close', id=session)

        # ---- XML par attributs : le défaut trouvé par ce banc --------------
        statut, ouverts = client.data('open', path='notes.xml')
        egal('xml : open -> 200', statut, 200)
        egal('xml : kind', ouverts.get('kind'), 'xml')
        session = ouverts.get('id')
        statut, tables = client.data('tables', id=session)
        egal('xml : l’élément répété devient une table',
             [t['name'] for t in tables.get('tables') or []], ['contact'])
        statut, res = client.data('query', id=session, commit=False,
                                  sql='SELECT nom FROM contact WHERE id=1')
        egal('xml : query -> 200 sur une colonne d’attribut', statut, 200)
        egal('xml : la valeur de l’attribut est rendue', res.get('rows'), [['Ada']])
        client.data('close', id=session)

        # ---- XML par enfants : la forme déjà couverte ne doit pas régresser
        statut, ouverts = client.data('open', path='enfants.xml')
        egal('xml enfants : open -> 200', statut, 200)
        session = ouverts.get('id')
        statut, res = client.data('query', id=session, commit=False,
                                  sql='SELECT titre FROM livre WHERE annee=1951')
        egal('xml enfants : query -> 200', statut, 200)
        egal('xml enfants : la valeur est rendue', res.get('rows'), [['Fondation']])
        client.data('close', id=session)

        # ---- XML sans répétition : refus expliqué, jamais table devinée ----
        statut, refus = client.data('open', path='plat.xml')
        egal('xml plat : refusé', statut, 400)
        message = refus.get('error') or ''
        verif('répété au moins deux fois' in message,
              'xml plat : la règle appliquée est énoncée : %r' % message)
        verif('comme texte' in message,
              'xml plat : il est dit que le fichier s’ouvre comme texte : %r'
              % message)

        # ---- CSV : lecture et écriture réelles ----------------------------
        statut, ouverts = client.data('open', path='donnees.csv')
        egal('csv : open -> 200', statut, 200)
        egal('csv : kind', ouverts.get('kind'), 'csv')
        egal('csv : les lignes sont rendues', ouverts.get('rows'),
             [['id', 'nom'], ['1', 'Ada'], ['2', 'Grace']])
        session = ouverts.get('id')
        statut, enregistre = client.data(
            'save', id=session, revision=ouverts.get('revision'),
            rows=[['id', 'nom'], ['1', 'Ada'], ['2', 'Grace'], ['3', 'Alan']])
        egal('csv : save -> 200', statut, 200)
        ecrit = io.open(os.path.join(racine, 'donnees.csv'),
                        encoding='utf-8').read().strip().split('\n')[-1]
        egal('csv : la ligne ajoutée est écrite avec le séparateur d’origine',
             ecrit, '3;Alan')
        client.data('close', id=session)

        # ---- Repli texte : ce que l'interface affiche puis édite ----------
        statut, refus = client.data('open', path='faux.sqlite')
        egal('faux.sqlite : refusé', statut, 400)
        raison = refus.get('error') or ''
        verif('comme texte' in raison,
              'faux.sqlite : la raison dit qu’il s’ouvre comme texte : %r' % raison)
        egal('faux.sqlite : la raison n’est pas répétée deux fois',
             raison.count('comme texte'), 1)
        statut, fichier = client.get('/api/file?path=faux.sqlite')
        egal('/api/file rend le contenu', fichier.get('content'),
             'pas une base\ndeux lignes\n')
        statut, _ = client.post('/api/save', path='faux.sqlite',
                                content='ligne modifiée\n')
        egal('/api/save écrit le repli texte', statut, 200)
        egal('le repli texte est bien écrit sur le disque',
             io.open(os.path.join(racine, 'faux.sqlite'),
                     encoding='utf-8').read(), 'ligne modifiée\n')

        # ---- Une révision périmée doit être refusée, pas écrasée ----------
        statut, ouverts = client.data('open', path='donnees.csv')
        session = ouverts.get('id')
        avant = io.open(os.path.join(racine, 'donnees.csv'),
                        encoding='utf-8').read()
        statut, res = client.data('save', id=session, revision='revue-ailleurs',
                                  rows=[['id', 'nom'], ['9', 'Z']])
        egal('csv : une révision périmée est refusée', statut, 400)
        # Le comportement qui compte n'est pas la tournure du message mais
        # l'absence d'écrasement : un refus qui laisserait le fichier modifié
        # serait pire qu'un silence.
        egal('csv : le fichier n’est pas écrasé par une révision périmée',
             io.open(os.path.join(racine, 'donnees.csv'),
                     encoding='utf-8').read(), avant)
        verif(bool((res.get('error') or '').strip()),
              'csv : le refus est accompagné d’une raison, pas vide')
        client.data('close', id=session)

        # ---- Un chemin hors du projet doit être refusé --------------------
        statut, res = client.data('open', path='../etc/passwd')
        egal('un chemin qui sort du projet est refusé', statut, 400)

    print('\nBanc des routes de données : %d contrôles OK, %d échec(s)'
          % (OK, ECHECS))
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
