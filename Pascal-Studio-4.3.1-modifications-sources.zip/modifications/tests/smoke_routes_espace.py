#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de fumée : les routes de l’espace de travail et le filtre de demande (3.9.0).

Contrairement aux deux autres bancs 3.9.0, celui-ci importe le vrai server.py et
lui parle en HTTP : aucune route n’est bouchonnée, la base SQLite est réelle, les
documents touchent un vrai disque. Seuls les appels qui sortiraient du bac à
sable sont remplacés — le modèle qui réécrit la demande, le modèle qui répond, et
les trois tâches de fond — parce qu’ils ne font pas partie de ce qui est testé.

Ce banc vérifie trois choses que la lecture du code ne suffit pas à établir.

  1. Les huit routes de l’espace renvoient un 400 motivé sur un chemin hostile,
     jamais un 500 ni une trace d’appel, et rien n’est écrit hors du dossier du
     projet.
  2. L’export est réellement conservé dans l’espace du projet, et supprimer un
     projet supprime son espace : sans cela, les dossiers s’accumuleraient sans
     aucun moyen de les atteindre depuis l’interface.
  3. Le filtre envoie bien le prompt enrichi au modèle, pendant que la base et
     l’écran conservent la demande de l’utilisateur. C’est le cœur du choix
     « envoi direct » : si les deux se confondaient, l’utilisateur verrait sa
     demande réécrite à la place de la sienne.
"""

import base64
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import warnings
from pathlib import Path

warnings.filterwarnings('ignore')

ICI = Path(__file__).resolve().parent
MODIFICATIONS = ICI.parent
ASSISTANT = MODIFICATIONS / 'assistant-ia'

# L’environnement doit précéder l’import : server.py crée ses tables au niveau
# module, et l’espace de travail lit sa racine à la première utilisation.
TMP = tempfile.mkdtemp(prefix='ps-routes-390-')
os.environ['DB_PATH'] = os.path.join(TMP, 'history.db')
os.environ['PS_ESPACE_RACINE'] = os.path.join(TMP, 'espace')
os.environ['NO_BROWSER'] = '1'
sys.path.insert(0, str(ASSISTANT))

import server                                    # noqa : après l’environnement
import core                                      # noqa
import optimiseur_prompt                         # noqa
from starlette.testclient import TestClient      # noqa

RACINE_ESPACE = os.environ['PS_ESPACE_RACINE']
BASE_URL = 'http://127.0.0.1:7860'

DEMANDE = ('Écris un script python qui renomme les photos de vacances selon leur '
           'date de prise de vue, sans écraser les fichiers existants')
ENRICHI = (DEMANDE + '\n\nObjectif : renommer les photos selon leur date de prise '
                     'de vue.\nContraintes : aucun fichier existant ne doit être '
                     'écrasé, le script doit être exécutable sous Debian 13.'
                     '\nRésultat attendu : un script python unique, accompagné de '
                     'la commande pour le lancer.\nCritères de réussite : deux '
                     'exécutions successives donnent le même résultat, et un '
                     'doublon de nom ne perd aucune photo.')

echecs = []
compte = [0]


def verif(condition, message):
    compte[0] += 1
    if not condition:
        echecs.append(message)


def base(sql, args=()):
    with sqlite3.connect(os.environ['DB_PATH']) as connexion:
        connexion.row_factory = sqlite3.Row
        return [dict(l) for l in connexion.execute(sql, args).fetchall()]


def evenement(flux, type_, **attendus):
    """Le premier événement ndjson d’un type donné, éventuellement filtré."""
    for ligne in flux.strip().splitlines():
        try:
            objet = json.loads(ligne)
        except ValueError:
            continue
        if objet.get('type') != type_:
            continue
        if all(objet.get(cle) == valeur for cle, valeur in attendus.items()):
            return objet
    return None


def types_du(flux):
    sortis = []
    for ligne in flux.strip().splitlines():
        try:
            sortis.append(json.loads(ligne).get('type'))
        except ValueError:
            continue
    return sortis


def main():
    client = TestClient(server.app, base_url=BASE_URL)

    # --- 1. Projet et listage ----------------------------------------------------
    projet = client.post('/api/projects', json={'name': 'Photos 2026',
                                                'instructions': 'Toujours dater les fichiers.'})
    verif(projet.status_code == 200, 'la création du projet échoue : %s' % projet.status_code)
    pid = projet.json().get('id')
    verif(bool(pid), 'aucun identifiant de projet renvoyé')

    sans = client.get('/api/espace')
    verif(sans.status_code == 400 and 'Projet requis' in sans.json()['detail'],
          'un listage sans projet ne renvoie pas un 400 motivé : %s %s'
          % (sans.status_code, sans.text[:120]))
    hostile = client.get('/api/espace', params={'project_id': '../../x'})
    verif(hostile.status_code == 400,
          'un identifiant de projet hostile ne renvoie pas 400 : %s' % hostile.status_code)
    verif(hostile.status_code < 500, 'un identifiant hostile provoque une erreur serveur')

    listing = client.get('/api/espace', params={'project_id': pid})
    verif(listing.status_code == 200, 'le listage initial échoue : %s' % listing.status_code)
    corps = listing.json()
    verif(corps['projet'] == pid and corps['fichiers'] == [] and corps['dossiers'] == [],
          'le listage initial n’est pas vide : %s' % json.dumps(corps)[:200])
    verif(corps['volume']['quota'] > 0 and corps['volume']['nombre'] == 0,
          'le volume initial est incohérent : %r' % corps['volume'])
    verif(corps['marqueur'] == 'ps-3.9.0-espace', 'le marqueur manque au listage')
    print('espace : projet créé, listage initial conforme')

    # --- 2. Dépôts ---------------------------------------------------------------
    depot = client.post('/api/espace/depot', json={'project_id': pid, 'name': 'notes.txt',
                                                   'data': 'première note'})
    verif(depot.status_code == 200, 'un dépôt texte échoue : %s %s'
          % (depot.status_code, depot.text[:200]))
    fiche = depot.json().get('fiche') or {}
    verif(fiche.get('chemin') == 'notes.txt' and fiche.get('origine') == 'depot',
          'la fiche du dépôt est fausse : %r' % fiche)
    verif(os.path.isfile(os.path.join(RACINE_ESPACE, pid, 'notes.txt')),
          'le document déposé n’est pas sur le disque')

    brut = b'\x00\x01\x02PK\x03\x04contenu binaire'
    depot = client.post('/api/espace/depot', json={'project_id': pid, 'name': 'archive.zip',
                                                   'data': base64.b64encode(brut).decode(),
                                                   'base64': True})
    verif(depot.status_code == 200, 'un dépôt base64 échoue : %s' % depot.status_code)
    with open(os.path.join(RACINE_ESPACE, pid, 'archive.zip'), 'rb') as flux:
        verif(flux.read() == brut, 'un dépôt base64 n’est pas décodé à l’identique')

    avant = sorted(os.listdir(TMP))
    hostile = client.post('/api/espace/depot', json={'project_id': pid,
                                                     'name': '../../dehors.txt',
                                                     'data': 'sortie'})
    verif(hostile.status_code in (200, 400),
          'un nom de dépôt hostile provoque une erreur serveur : %s' % hostile.status_code)
    verif(not os.path.exists(os.path.join(TMP, 'dehors.txt')),
          'un dépôt au nom hostile a écrit hors de l’espace du projet')
    verif(not os.path.exists(os.path.join(os.path.dirname(RACINE_ESPACE), 'dehors.txt')),
          'un dépôt au nom hostile a écrit à côté de la racine de l’espace')
    verif(sorted(os.listdir(TMP)) == avant,
          'un dépôt hostile a créé quelque chose à la racine du banc')
    if hostile.status_code == 200:
        verif(hostile.json()['fiche']['chemin'].startswith(pid) is False
              and '..' not in hostile.json()['fiche']['chemin'],
              'le chemin renvoyé pour un nom hostile contient une remontée : %r'
              % hostile.json()['fiche'])

    for cas, corps_manquant, attendu in (
            ('sans projet', {'name': 'x.txt', 'data': 'x'}, 400),
            ('sans nom', {'project_id': pid, 'data': 'x'}, 400),
            ('sans contenu', {'project_id': pid, 'name': 'x.txt'}, 400),
            ('contenu non texte', {'project_id': pid, 'name': 'x.txt', 'data': 12345}, 400)):
        reponse = client.post('/api/espace/depot', json=corps_manquant)
        verif(reponse.status_code == attendu,
              'un dépôt %s renvoie %s au lieu de %s' % (cas, reponse.status_code, attendu))

    entree_max = server.ESPACE_ENTREE_MAX
    server.ESPACE_ENTREE_MAX = 10
    try:
        gros = client.post('/api/espace/depot', json={'project_id': pid, 'name': 'gros.txt',
                                                      'data': 'x' * 40})
        verif(gros.status_code == 413,
              'un dépôt au-dessus de la borne d’entrée ne renvoie pas 413 : %s'
              % gros.status_code)
    finally:
        server.ESPACE_ENTREE_MAX = entree_max

    doublon = client.post('/api/espace/depot', json={'project_id': pid, 'name': 'notes.txt',
                                                     'data': 'seconde note'})
    verif(doublon.json()['fiche']['chemin'] == 'notes (2).txt',
          'une collision de nom n’est pas numérotée : %r' % doublon.json()['fiche']['chemin'])
    telecharge = client.get('/api/espace/fichier', params={'project_id': pid,
                                                           'chemin': 'notes.txt'})
    verif(telecharge.content.decode('utf-8') == 'première note',
          'le premier dépôt a été écrasé par le second')

    imbrique = client.post('/api/espace/depot', json={'project_id': pid, 'dossier': 'livrables',
                                                      'name': 'rapport.txt', 'data': 'profond'})
    verif(imbrique.json()['fiche']['chemin'] == 'livrables/rapport.txt',
          'un dépôt dans un sous-dossier n’est pas placé : %r' % imbrique.json()['fiche'])
    print('dépôts : texte, base64, collision, sous-dossier et %d refus conformes' % 5)

    # --- 3. Téléchargement et aperçu ---------------------------------------------
    telecharge = client.get('/api/espace/fichier', params={'project_id': pid,
                                                           'chemin': 'notes.txt'})
    verif(telecharge.status_code == 200, 'un téléchargement échoue : %s' % telecharge.status_code)
    verif(telecharge.content.decode('utf-8') == 'première note',
          'le contenu téléchargé est altéré')
    disposition = telecharge.headers.get('content-disposition', '')
    verif('attachment' in disposition and 'filename=' in disposition,
          'l’en-tête de téléchargement est absent : %r' % disposition)
    verif("filename*=UTF-8''" in disposition,
          'un nom accentué ne passerait pas : filename* manque')

    for chemin in ('../../../etc/passwd', 'absent.txt', 'livrables', ''):
        reponse = client.get('/api/espace/fichier', params={'project_id': pid,
                                                            'chemin': chemin})
        verif(reponse.status_code == 400,
              'le téléchargement de %r renvoie %s au lieu de 400' % (chemin, reponse.status_code))

    apercu = client.get('/api/espace/apercu', params={'project_id': pid, 'chemin': 'notes.txt'})
    verif(apercu.status_code == 200 and apercu.json()['binaire'] is False
          and apercu.json()['texte'] == 'première note',
          'l’aperçu d’un texte est faux : %s' % apercu.text[:200])
    apercu = client.get('/api/espace/apercu', params={'project_id': pid, 'chemin': 'archive.zip'})
    verif(apercu.status_code == 200 and apercu.json()['binaire'] is True,
          'un document binaire n’est pas signalé comme tel en aperçu : %s' % apercu.text[:200])
    apercu = client.get('/api/espace/apercu', params={'project_id': pid, 'chemin': '../x'})
    verif(apercu.status_code == 400, 'un aperçu hostile ne renvoie pas 400')
    print('téléchargement et aperçu : contenus fidèles, %d chemins refusés' % 5)

    # --- 4. Renommer, supprimer, créer un dossier --------------------------------
    dossier = client.post('/api/espace/dossier', json={'project_id': pid, 'chemin': 'archives'})
    verif(dossier.status_code == 200, 'la création d’un dossier échoue : %s' % dossier.text[:160])
    verif(os.path.isdir(os.path.join(RACINE_ESPACE, pid, 'archives')),
          'le dossier créé n’est pas sur le disque')
    verif(client.post('/api/espace/dossier', json={'project_id': pid,
                                                   'chemin': 'archives'}).status_code == 400,
          'créer un dossier déjà présent n’est pas refusé')
    verif(client.post('/api/espace/dossier', json={'project_id': pid,
                                                   'chemin': '../dehors'}).status_code == 400,
          'créer un dossier hors de l’espace n’est pas refusé')

    renomme = client.post('/api/espace/renommer', json={'project_id': pid,
                                                        'chemin': 'notes (2).txt',
                                                        'nouveau': 'archives/notes (2).txt'})
    verif(renomme.status_code == 200, 'un renommage échoue : %s' % renomme.text[:200])
    verif(renomme.json()['fiche']['chemin'] == 'archives/notes (2).txt',
          'le renommage ne rend pas le nouveau chemin : %r' % renomme.json().get('fiche'))
    verif(not os.path.exists(os.path.join(RACINE_ESPACE, pid, 'notes (2).txt')),
          'l’ancien nom subsiste après le renommage')
    verif(client.post('/api/espace/renommer', json={'project_id': pid, 'chemin': 'notes.txt',
                                                    'nouveau': 'archives/notes (2).txt'}
                      ).status_code == 400,
          'renommer par-dessus un document existant n’est pas refusé')
    verif(client.post('/api/espace/renommer', json={'project_id': pid, 'chemin': 'notes.txt',
                                                    'nouveau': '../dehors.txt'}).status_code == 400,
          'renommer hors de l’espace n’est pas refusé')

    supprime = client.post('/api/espace/supprimer', json={'project_id': pid,
                                                          'chemin': 'archives/notes (2).txt'})
    verif(supprime.status_code == 200, 'une suppression échoue : %s' % supprime.text[:200])
    verif(not os.path.exists(os.path.join(RACINE_ESPACE, pid, 'archives', 'notes (2).txt')),
          'un document supprimé est encore sur le disque')
    verif(client.post('/api/espace/supprimer', json={'project_id': pid,
                                                     'chemin': 'absent.txt'}).status_code == 400,
          'supprimer un document absent n’est pas refusé')
    verif(client.post('/api/espace/supprimer', json={'project_id': pid,
                                                     'chemin': '.'}).status_code == 400,
          'supprimer la racine de l’espace n’est pas refusé')
    verif(os.path.isdir(os.path.join(RACINE_ESPACE, pid)),
          'la racine de l’espace a disparu après une suppression')

    enregistre = client.post('/api/espace/enregistrer', json={'project_id': pid,
                                                              'name': 'reponse.md',
                                                              'contenu': '# Réponse de l’IA',
                                                              'detail': 'réponse du message 12'})
    verif(enregistre.status_code == 200, 'l’enregistrement d’une réponse échoue : %s'
          % enregistre.text[:200])
    verif(enregistre.json()['fiche']['origine'] == 'reponse',
          'l’origine d’un document enregistré n’est pas « reponse » : %r'
          % enregistre.json()['fiche'])
    verif(client.post('/api/espace/enregistrer', json={'project_id': pid, 'name': 'vide.md',
                                                       'contenu': '   '}).status_code == 400,
          'enregistrer un contenu vide n’est pas refusé')
    verif(client.post('/api/espace/enregistrer', json={'name': 'x.md',
                                                       'contenu': 'x'}).status_code == 400,
          'enregistrer sans projet n’est pas refusé')
    print('modifications : dossier, renommage, suppression et enregistrement contrôlés')

    # --- 5. Export capturé dans l’espace -----------------------------------------
    export = client.post('/api/export', json={'content': 'nom,quantité\npomme,3\npoire,5\n',
                                              'fmt': 'xlsx', 'name': 'tableau',
                                              'project_id': pid})
    verif(export.status_code == 200, 'l’export xlsx échoue : %s %s'
          % (export.status_code, export.text[:200]))
    verif(bool(export.headers.get('x-ps-espace')),
          'l’export ne signale pas sa capture dans l’espace (en-tête X-PS-Espace absent)')
    verif(export.headers.get('x-ps-espace') == 'tableau.xlsx',
          'le chemin capturé est faux : %r' % export.headers.get('x-ps-espace'))
    listing = client.get('/api/espace', params={'project_id': pid}).json()
    captures = [f for f in listing['fichiers'] if f['nom'] == 'tableau.xlsx']
    verif(len(captures) == 1, 'l’export n’apparaît pas dans l’espace du projet : %r'
          % [f['nom'] for f in listing['fichiers']])
    verif(captures and captures[0]['origine'] == 'export',
          'l’origine d’un export capturé n’est pas « export »')
    verif(captures and captures[0]['octets'] > 0, 'l’export capturé est vide')
    verif(captures and captures[0]['detail'].startswith('export xlsx'),
          'le détail d’un export capturé est absent : %r' % captures[0].get('detail'))

    avant_export = len(client.get('/api/espace', params={'project_id': pid}).json()['fichiers'])
    sans_projet = client.post('/api/export', json={'content': 'a,b\n1,2\n', 'fmt': 'xlsx',
                                                   'name': 'orphelin'})
    verif(sans_projet.status_code == 200, 'un export sans projet échoue : %s'
          % sans_projet.status_code)
    verif(not sans_projet.headers.get('x-ps-espace'),
          'un export sans projet annonce une capture inexistante')
    apres_export = len(client.get('/api/espace', params={'project_id': pid}).json()['fichiers'])
    verif(avant_export == apres_export,
          'un export sans projet a quand même été capturé quelque part')
    verif(client.post('/api/export', json={'content': 'x', 'fmt': 'pdf'}).status_code == 400,
          'un format d’export inconnu n’est pas refusé')
    print('export : capturé dans l’espace du projet, ignoré sans projet')

    # --- 6. Supprimer un projet vide son espace ----------------------------------
    second = client.post('/api/projects', json={'name': 'À jeter'}).json()
    pid2 = second['id']
    client.post('/api/espace/depot', json={'project_id': pid2, 'name': 'a-garder.txt',
                                           'data': 'document'})
    verif(os.path.isdir(os.path.join(RACINE_ESPACE, pid2)),
          'l’espace du second projet n’existe pas avant sa suppression')
    verif(client.delete('/api/projects/%s' % pid2).status_code == 200,
          'la suppression du projet échoue')
    verif(not os.path.exists(os.path.join(RACINE_ESPACE, pid2)),
          'l’espace d’un projet supprimé subsiste sur le disque : il deviendrait inaccessible')
    verif(os.path.isdir(os.path.join(RACINE_ESPACE, pid)),
          'la suppression d’un projet a emporté l’espace d’un autre projet')
    print('projets : l’espace suit le projet dans sa suppression')

    # --- 7. Réglages du filtre ---------------------------------------------------
    reglages = client.patch('/api/settings', json={'ui': {'prompt': 'off',
                                                          'prompt_model': 'qwen3:1.7b',
                                                          'inconnu': 'x'}})
    ui = reglages.json().get('ui') or {}
    verif(ui.get('prompt') == 'off', 'le réglage d’activation du filtre n’est pas conservé : %r' % ui)
    verif(ui.get('prompt_model') == 'qwen3:1.7b',
          'le modèle séparé choisi n’est pas conservé : %r' % ui.get('prompt_model'))
    verif('inconnu' not in ui, 'une clé de réglage inconnue est conservée')
    ui = client.patch('/api/settings', json={'ui': {'prompt': 'peut-être',
                                                    'prompt_model': 'mauvais modèle; rm -rf'}}
                      ).json().get('ui') or {}
    verif(ui.get('prompt') == 'off',
          'une valeur d’activation invalide est acceptée : %r' % ui.get('prompt'))
    verif(ui.get('prompt_model') == 'qwen3:1.7b',
          'un nom de modèle invalide a écrasé le réglage précédent : %r' % ui.get('prompt_model'))
    client.patch('/api/settings', json={'ui': {'prompt': 'on', 'prompt_model': 'modele-test'}})
    print('réglages : activation et modèle séparé enregistrés, valeurs invalides refusées')

    # --- 8. Le filtre dans chat(), de bout en bout -------------------------------
    appels_modele = []
    appels_poster = []

    def run_faux(history, user_msg, mode='auto', category='auto', prev_cat=None,
                 memory='', custom='', summary='', images=None, model=None, web=False):
        appels_modele.append({'user_msg': user_msg, 'history': list(history),
                              'custom': custom, 'mode': mode, 'model': model})
        yield {'type': 'meta', 'category': 'chat', 'label': '💬 Discussion',
               'engine': 'local', 'provider': 'ollama', 'model': 'modele-test'}
        yield {'type': 'text', 't': 'Voici la réponse de test, sans bloc de code.'}

    def poster_faux(modele, consigne, delai=None):
        appels_poster.append({'modele': modele, 'consigne': consigne, 'delai': delai})
        return json.dumps({'prompt': ENRICHI, 'notes': 'Objectif et critères ajoutés.',
                           'langue': 'fr'}, ensure_ascii=False)

    conversation = client.post('/api/conversations', json={'title': 'Banc du filtre',
                                                           'project_id': pid}).json()
    cid = conversation['id']

    sauvegardes = (core.run, optimiseur_prompt.poster_ollama, server.bg_memory,
                   server.bg_skill, server.bg_compress, server.skills_mod.select,
                   server.skills_mod.block)
    core.run = run_faux
    optimiseur_prompt.poster_ollama = poster_faux
    server.bg_memory = server.bg_skill = server.bg_compress = lambda *a, **k: None
    # Aucune compétence ne doit intercepter la demande du banc : le catalogue
    # livré en reconnaît des très ordinaires (« script python » déclenche
    # python-script), et le banc testerait alors ce catalogue au lieu du filtre.
    server.skills_mod.select = lambda texte, actifs: ([], texte)
    server.skills_mod.block = lambda choisi: ''
    try:
        reponse = client.post('/api/conversations/%s/chat' % cid,
                              json={'message': DEMANDE, 'mode': 'local', 'tools': 'off',
                                    'web': 'off', 'team': 'off', 'category': 'chat',
                                    'model': ''})
        verif(reponse.status_code == 200, 'l’envoi échoue : %s %s'
              % (reponse.status_code, reponse.text[:300]))
        flux = reponse.text
        opt = evenement(flux, 'optimise')
        verif(opt is not None, 'aucun événement « optimise » dans le flux : %r'
              % types_du(flux))
        verif(opt and opt.get('statut') == 'optimise',
              'le statut du filtre est faux : %r' % opt)
        verif(opt and opt.get('modifie') is True, 'le filtre n’annonce pas la modification')
        verif(opt and opt.get('original') == DEMANDE,
              'la demande d’origine n’est pas renvoyée à l’écran : %r'
              % (opt or {}).get('original'))
        verif(opt and opt.get('prompt') == ENRICHI,
              'le prompt envoyé n’est pas celui du modèle séparé')
        verif(opt and opt.get('modele') == 'modele-test',
              'le modèle de réécriture n’est pas tracé : %r' % (opt or {}).get('modele'))
        verif(opt and opt.get('notes') == 'Objectif et critères ajoutés.',
              'les notes du modèle séparé sont perdues')
        verif(appels_poster and appels_poster[0]['modele'] == 'modele-test',
              'le modèle séparé configuré n’est pas celui qui a été appelé : %r' % appels_poster)
        verif(appels_poster and DEMANDE in appels_poster[0]['consigne'],
              'la consigne envoyée au modèle séparé ne contient pas la demande')
        verif(appels_poster and 'Photos 2026' in appels_poster[0]['consigne'],
              'le contexte du projet n’est pas transmis au modèle séparé')
        verif(appels_poster and 'Toujours dater les fichiers.' in appels_poster[0]['consigne'],
              'les consignes du projet ne sont pas transmises au modèle séparé')

        verif(len(appels_modele) == 1, 'le modèle de réponse a été appelé %d fois'
              % len(appels_modele))
        verif(appels_modele and appels_modele[0]['user_msg'] == ENRICHI,
              'le modèle de réponse n’a pas reçu le prompt enrichi : %r'
              % (appels_modele or [{}])[0].get('user_msg', '')[:120])

        ligne = base('SELECT content, meta FROM messages WHERE conv_id=? AND role=? '
                     'ORDER BY id', (cid, 'user'))
        verif(len(ligne) == 1, 'le message utilisateur n’est pas enregistré une fois : %d'
              % len(ligne))
        verif(ligne and ligne[0]['content'] == DEMANDE,
              'la base conserve le prompt enrichi au lieu de la demande de l’utilisateur')
        meta = json.loads(ligne[0]['meta']) if ligne and ligne[0]['meta'] else {}
        verif(meta.get('prompt', {}).get('envoye') == ENRICHI,
              'le prompt envoyé n’est pas conservé dans les métadonnées : %r'
              % meta.get('prompt'))
        verif(meta.get('prompt', {}).get('modele') == 'modele-test',
              'le modèle de réécriture n’est pas conservé avec le message')

        relu = client.get('/api/conversations/%s' % cid).json()
        utilisateur = [m for m in relu['messages'] if m['role'] == 'user']
        verif(utilisateur and utilisateur[0]['content'] == DEMANDE,
              'au rechargement, la demande affichée n’est pas celle de l’utilisateur')
        verif(utilisateur and (utilisateur[0].get('meta') or {}).get('prompt', {}).get('envoye')
              == ENRICHI,
              'au rechargement, le prompt envoyé est introuvable : « voir le prompt » '
              'ne fonctionnerait pas sur une conversation rouverte')
        texte_reponse = evenement(flux, 'text')
        verif(texte_reponse is not None and 'réponse de test' in texte_reponse.get('t', ''),
              'la réponse du modèle n’est pas diffusée : %r' % types_du(flux))
        verif('Optimisation de la demande' in flux,
              'aucun état n’annonce l’optimisation pendant l’attente')
        verif(types_du(flux).index('status') < types_du(flux).index('optimise'),
              'l’annonce de l’optimisation arrive après son résultat')

        # --- Filtre désactivé -----------------------------------------------------
        client.patch('/api/settings', json={'ui': {'prompt': 'off'}})
        del appels_modele[:], appels_poster[:]
        flux = client.post('/api/conversations/%s/chat' % cid,
                           json={'message': DEMANDE, 'mode': 'local', 'tools': 'off',
                                 'web': 'off', 'team': 'off', 'category': 'chat'}).text
        opt = evenement(flux, 'optimise')
        verif(opt and opt.get('statut') == 'desactive' and opt.get('modifie') is False,
              'un filtre désactivé réécrit quand même : %r' % opt)
        verif(not appels_poster, 'un filtre désactivé appelle le modèle séparé')
        verif(appels_modele and appels_modele[0]['user_msg'] == DEMANDE,
              'un filtre désactivé modifie la demande envoyée au modèle')
        client.patch('/api/settings', json={'ui': {'prompt': 'on'}})

        # --- Modèle de réécriture en panne ----------------------------------------
        def poster_en_panne(modele, consigne, delai=None):
            appels_poster.append({'modele': modele})
            raise OSError('ollama injoignable')

        optimiseur_prompt.poster_ollama = poster_en_panne
        del appels_modele[:]
        flux = client.post('/api/conversations/%s/chat' % cid,
                           json={'message': DEMANDE, 'mode': 'local', 'tools': 'off',
                                 'web': 'off', 'team': 'off', 'category': 'chat'}).text
        opt = evenement(flux, 'optimise')
        verif(opt and opt.get('statut') == 'repli' and opt.get('modifie') is False,
              'une panne du modèle séparé n’est pas repliée : %r' % opt)
        verif(appels_modele and appels_modele[0]['user_msg'] == DEMANDE,
              'après une panne du filtre, la demande envoyée au modèle est altérée')
        verif(evenement(flux, 'text') is not None,
              'une panne du filtre empêche la réponse : l’envoi ne doit jamais être bloqué')

        # --- Demande trop courte --------------------------------------------------
        def poster_interdit(modele, consigne, delai=None):
            appels_poster.append({'modele': modele})
            return json.dumps({'prompt': ENRICHI}, ensure_ascii=False)

        optimiseur_prompt.poster_ollama = poster_interdit
        del appels_poster[:], appels_modele[:]
        flux = client.post('/api/conversations/%s/chat' % cid,
                           json={'message': 'ok merci', 'mode': 'local', 'tools': 'off',
                                 'web': 'off', 'team': 'off', 'category': 'chat'}).text
        opt = evenement(flux, 'optimise')
        verif(opt and opt.get('statut') == 'inutile',
              'une demande trop courte déclenche une réécriture : %r' % opt)
        verif(not appels_poster, 'une demande trop courte appelle le modèle séparé')
        verif(appels_modele and appels_modele[0]['user_msg'] == 'ok merci',
              'une demande trop courte est modifiée avant l’envoi')

        # --- Une compétence qui ajoute seulement ses consignes ---------------------
        # La plupart des compétences livrées renvoient la demande telle quelle et
        # n'ajoutent que leur méthode au bloc système. Le filtre doit alors rester
        # actif : les deux effets se cumulent, et écarter l'optimisation ferait
        # perdre le bénéfice sans rien protéger.
        optimiseur_prompt.poster_ollama = poster_faux
        server.skills_mod.select = lambda texte, actifs: ([{'name': 'consigne-test'}], texte)
        server.skills_mod.block = lambda choisi: 'CONSIGNE DE LA COMPÉTENCE'
        del appels_modele[:]
        flux = client.post('/api/conversations/%s/chat' % cid,
                           json={'message': DEMANDE, 'mode': 'local', 'tools': 'off',
                                 'web': 'off', 'team': 'off', 'category': 'chat'}).text
        opt = evenement(flux, 'optimise')
        verif(opt and opt.get('modifie') is True,
              'une compétence qui ne réécrit pas la demande écarte le filtre : %r' % opt)
        verif(appels_modele and appels_modele[0]['user_msg'] == ENRICHI,
              'le prompt enrichi n’est pas envoyé quand une compétence ajoute ses consignes')
        verif(appels_modele and 'CONSIGNE DE LA COMPÉTENCE' in appels_modele[0]['custom'],
              'la consigne de la compétence est perdue quand le filtre reste actif : %r'
              % (appels_modele or [{}])[0].get('custom', '')[:120])

        # --- Une compétence qui réécrit vraiment la demande -----------------------
        server.skills_mod.select = lambda texte, actifs: ([{'name': 'routage-test'}],
                                                          'DEMANDE ROUTÉE ' + texte)
        del appels_modele[:]
        flux = client.post('/api/conversations/%s/chat' % cid,
                           json={'message': DEMANDE, 'mode': 'local', 'tools': 'off',
                                 'web': 'off', 'team': 'off', 'category': 'chat'}).text
        opt = evenement(flux, 'optimise')
        verif(opt and opt.get('modifie') is False,
              'une compétence qui réécrit la demande est écartée au profit du filtre : %r'
              % opt)
        verif(opt and 'compétence' in opt.get('raison', ''),
              'le motif d’écartement n’est pas expliqué : %r' % (opt or {}).get('raison'))
        verif(appels_modele and appels_modele[0]['user_msg'].startswith('DEMANDE ROUTÉE'),
              'le routage de compétence a été écrasé par le filtre : %r'
              % (appels_modele or [{}])[0].get('user_msg', '')[:60])
    finally:
        (core.run, optimiseur_prompt.poster_ollama, server.bg_memory, server.bg_skill,
         server.bg_compress, server.skills_mod.select,
         server.skills_mod.block) = sauvegardes
    print('filtre : prompt enrichi au modèle, demande d’origine à l’écran et en base')

    shutil.rmtree(TMP, ignore_errors=True)

    if echecs:
        print('\n%d assertion(s) sur %d en échec :' % (len(echecs), compte[0]))
        for probleme in echecs:
            print('  - ' + probleme)
        return 1
    print('\nBanc des routes 3.9.0 : %d assertions, toutes conformes.' % compte[0])
    return 0


if __name__ == '__main__':
    sys.exit(main())
