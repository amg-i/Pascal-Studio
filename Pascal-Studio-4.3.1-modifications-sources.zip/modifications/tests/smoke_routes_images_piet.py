#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : les routes /api/image et /api/piet du VRAI serveur.

Pourquoi ce banc existe à côté des autocontrôles de modules
-----------------------------------------------------------
    `python3 images.py` (125 contrôles) et `python3 piet_texte.py` (116)
    exercent les modules en appelant leurs fonctions. Ce n'est pas ce que fait
    l'interface : elle envoie `POST /api/image` ou `POST /api/piet` avec un JSON
    et lit une réponse JSON. Six choses ne sont visibles qu'ici :

      * `resolve()` est le SEUL juge des chemins. Une route qui laisserait lire
        `/etc/passwd` ou écrire hors du projet serait une faille, et aucun
        autocontrôle de module ne peut la voir puisque le module reçoit un
        chemin déjà autorisé ;
      * un REFUS MÉTIER doit arriver intact. `server.py` répond 400 quand une
        branche LÈVE, et 200 avec `ok: false` quand le module rend un état. La
        visionneuse affiche la raison d'un refus de lecture : si la route levait
        à sa place, le panneau n'aurait plus qu'un « HTTP 400 » à montrer ;
      * à l'inverse, une écriture dangereuse DOIT lever : `ecrire` sur un texte
        invalide, `convertir-piet` sur une destination existante, `exporter-png`
        idem. Un 200 là-dessus écrirait silencieusement un fichier cassé ;
      * la garde `local_auth_allowed()` : une page web ouverte dans le
        navigateur intégré ne doit pas pouvoir faire écrire un fichier dans le
        projet ;
      * les verbes annoncés par les modules doivent être les verbes servis. Une
        action inconnue répond 400 en nommant l'action, pas 500 ni un JSON vide ;
      * rien n'est écrit là où rien n'est demandé : le banc photographie
        l'arborescence du projet avant et après.

    Ce banc n'utilise PAS `client.post()` du harnais : sa signature
    `post(chemin, entetes=None, **corps)` entre en collision avec la clef
    `chemin` du corps, qui est justement celle que `/api/piet` exige (`/api/image`
    accepte `chemin` ou `path`, `/api/piet` seulement `chemin`). D'où le POST brut
    ci-dessous, comme dans smoke_routes_outils.py.

Lancer :  cd work/modifications && export PYTHONPATH=$PWD \\
          && python3 tests/smoke_routes_images_piet.py
"""

import base64
import io
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

ICI = os.path.dirname(os.path.abspath(__file__))
MODIFICATIONS = os.path.abspath(os.path.join(ICI, '..'))
sys.path.insert(0, MODIFICATIONS)
sys.path.insert(0, ICI)

from serveur_de_test import ServeurDeTest      # noqa: E402
import images                                  # noqa: E402
import piet_texte                              # noqa: E402

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def egal(titre, obtenu, attendu):
    verif(obtenu == attendu, '%s — obtenu %r, attendu %r'
          % (titre, str(obtenu)[:160], str(attendu)[:160]))


EXEMPLE = piet_texte.exemple()
PNG_EXEMPLE = piet_texte.vers_png(EXEMPLE)
INVALIDE = 'piet 1\ncodel 4\ngrille 2 1\nzz yy\n'


def principal():
    with ServeurDeTest() as srv:
        client = srv.client
        projet = Path(srv.espace())

        def poster(route, entetes=None, **corps):
            requete = urllib.request.Request(
                client.base + route, data=json.dumps(corps).encode('utf-8'),
                headers=dict({'Content-Type': 'application/json'},
                             **(entetes or {})))
            try:
                with urllib.request.urlopen(requete, timeout=120) as rep:
                    statut, brut = rep.status, rep.read().decode('utf-8')
            except urllib.error.HTTPError as erreur_http:
                statut, brut = erreur_http.code, erreur_http.read().decode('utf-8')
            except (urllib.error.URLError, TimeoutError) as exc:
                return 0, {'erreur': str(exc)}
            try:
                return statut, json.loads(brut)
            except ValueError:
                return statut, {'brut': brut[:400]}

        # Fixtures : un PNG qui EST un programme Piet, un texte, une source.
        srv.ecrire('programme.png', PNG_EXEMPLE, mode='wb')
        srv.ecrire('notes.txt', 'ceci n’est pas une image')
        srv.ecrire('programme.piett', EXEMPLE)
        # Un PNG qui n'est PAS un programme Piet : deux couleurs hors palette.
        hors_palette = bytearray()
        for _y in range(2):
            hors_palette += b'\x01\x02\x03\x04'      # RVB quelconque + alpha
        import struct
        import zlib

        def png_brut(largeur, hauteur, rvb):
            def morceau(nom, donnees):
                return (struct.pack('>I', len(donnees)) + nom + donnees
                        + struct.pack('>I', zlib.crc32(nom + donnees)))
            brut = b'\x89PNG\r\n\x1a\n'
            brut += morceau(b'IHDR', struct.pack('>IIBBBBB', largeur, hauteur,
                                                 8, 2, 0, 0, 0))
            lignes = b''.join(b'\x00' + bytes(rvb) * largeur
                              for _ in range(hauteur))
            brut += morceau(b'IDAT', zlib.compress(lignes))
            brut += morceau(b'IEND', b'')
            return brut

        srv.ecrire('logo.png', png_brut(2, 2, (1, 2, 3)), mode='wb')
        # Une seconde copie du programme, dont le .piett n'existe pas encore :
        # c'est elle qui sert à la conversion réussie.
        srv.ecrire('copie.png', PNG_EXEMPLE, mode='wb')
        # Un PNG sans extension, et un texte qui en porte une : les deux cas où
        # le contenu et le nom se contredisent.
        srv.ecrire('image_sans_extension', images._png_test(3, 2), mode='wb')
        srv.ecrire('deguise.png', 'pas une image du tout')
        # Un SVG dont la balise n'est pas dans les premiers octets : c'est le cas
        # où l'extension DOIT être crue, parce qu'aucune signature n'est fiable.
        srv.ecrire('puzzle.svg', '<!-- aucune balise svg ici -->\n')
        avant = sorted(str(q.relative_to(projet)) for q in projet.rglob('*'))

        # =============================================== /api/image =========
        print('\n=== /api/image : ce que la visionneuse peut savoir ===')
        statut, corps = poster('/api/image', action='capacites')
        egal('GET capacités répond 200', statut, 200)
        # La route trie pour l'affichage ; le module garde l'ordre de sa table.
        # Comparer les listes brutes ferait échouer le banc sur un tri.
        egal('les capacités annoncent les 12 extensions du module',
             sorted(corps.get('formats') or []), sorted(images.FORMATS))
        egal('les douze extensions sont annoncées',
             len(corps.get('formats') or []), 12)
        egal('la borne de taille est celle du module', corps.get('octets_max'),
             images.OCTETS_MAX)
        egal('la borne annoncée est 32 Mo', corps.get('octets_max'), 33554432)
        verif(corps.get('redimensionnement_serveur') is False,
              'la route doit affirmer qu’elle ne redimensionne PAS côté serveur')
        verif(bool(corps.get('raison_redimensionnement')),
              'le refus du redimensionnement serveur doit être EXPLIQUÉ, pas '
              'seulement affirmé')
        verif('.svg' not in (corps.get('formats_avec_dimensions') or [])
              or '.svg' in (corps.get('formats') or []),
              'les formats annoncés doivent venir du module, pas d’une liste '
              'recopiée')
        # Le SVG est lu comme image par le module mais il n'est PAS accaparé par
        # la visionneuse : c'est du texte, il reste dans Monaco.
        verif('.svg' not in images.EXTENSIONS_VISIONNEUSE,
              'le SVG ne doit pas être routé vers la visionneuse')
        verif(corps.get('piet') is True and corps.get('conversion_piet_texte')
              is True, 'la reconnaissance Piet et sa conversion doivent être '
              'annoncées')
        verif(corps.get('voisinage') is True,
              'le voisinage (précédente/suivante) doit être annoncé')

        print('\n=== /api/image : lire une image ===')
        statut, corps = poster('/api/image', action='lire',
                               chemin='programme.png')
        egal('la lecture d’un PNG répond 200', statut, 200)
        egal('la lecture réussit', corps.get('ok'), True)
        egal('le format est reconnu', corps.get('format'), 'PNG')
        egal('le type MIME est reconnu', corps.get('mime'), 'image/png')
        egal('la largeur vient de l’en-tête', corps.get('largeur'), 12)
        egal('la hauteur vient de l’en-tête', corps.get('hauteur'), 4)
        egal('les dimensions sont dites connues', corps.get('dimensions_connues'),
             True)
        egal('la taille en octets est celle du fichier', corps.get('taille'),
             len(PNG_EXEMPLE))
        verif(str(corps.get('uri', '')).startswith('data:image/png;base64,'),
              'l’image doit arriver en data URI, prête à afficher')
        octets_uri = base64.b64decode(str(corps.get('uri', '')).split(',', 1)[1])
        egal('le data URI porte exactement les octets du fichier', octets_uri,
             PNG_EXEMPLE)
        egal('le PNG est reconnu comme programme Piet',
             (corps.get('piet') or {}).get('est_piet'), True)
        egal('le codel deviné est 4', (corps.get('piet') or {}).get('codel'), 4)
        verif((corps.get('piet') or {}).get('hors_palette') == 0,
              'un programme Piet n’a aucune couleur hors palette')
        verif(isinstance(corps.get('voisins'), dict),
              'le voisinage doit accompagner la lecture : sans lui, chaque '
              'image suivante coûterait un aller-retour de plus')

        print('\n=== /api/image : un refus de lecture reste un RÉSULTAT ===')
        statut, corps = poster('/api/image', action='lire', chemin='absent.png')
        egal('un fichier absent répond 200, pas 400', statut, 200)
        egal('un fichier absent est un échec métier', corps.get('ok'), False)
        verif(bool(corps.get('erreur')), 'le refus doit donner sa raison')
        statut, corps = poster('/api/image', action='lire', chemin='notes.txt')
        egal('un fichier texte répond 200 : c’est un résultat, pas une panne',
             statut, 200)
        egal('un fichier texte n’est pas une image', corps.get('ok'), False)
        verif('n’est pas une image' in str(corps.get('erreur', '')),
              'un fichier non image doit dire pourquoi il est refusé (%r)'
              % str(corps.get('erreur'))[:140])
        egal('un refus ne porte pas de data URI', corps.get('uri'), '')
        # Le contenu prime sur le nom : un PNG SANS EXTENSION reste affichable.
        # C'est ce que la visionneuse doit à un utilisateur qui renomme ou
        # télécharge un fichier dont le nom a perdu son suffixe.
        statut, corps = poster('/api/image', action='lire',
                               chemin='image_sans_extension')
        egal('un PNG sans extension répond 200', statut, 200)
        egal('un PNG sans extension est lisible', corps.get('ok'), True)
        egal('son mime vient du contenu', corps.get('mime'), 'image/png')
        egal('son format est nommé d’après le contenu', corps.get('format'), 'PNG')
        egal('ses dimensions sont lues', (corps.get('largeur'),
                                         corps.get('hauteur')), (3, 2))
        # Le contenu prime sur le nom, dans les DEUX sens. Une extension connue
        # n'est plus tolérée que pour les formats dont la signature n'est pas
        # fiable : le SVG est du XML (sa balise peut être repoussée par une
        # déclaration, un commentaire ou un DOCTYPE) et un AVIF peut porter une
        # boîte inconnue de la table. Pour les autres, un texte nommé .png était
        # servi avec une data URI de texte : la visionneuse affichait une image
        # cassée et le message « le navigateur n'a pas pu afficher cette image »,
        # qui accusait l'application pour un fichier qui n'est pas une image.
        statut, corps = poster('/api/image', action='lire', chemin='deguise.png')
        egal('un texte nommé .png répond 200 : c’est un résultat', statut, 200)
        egal('un texte nommé .png est refusé', corps.get('ok'), False)
        verif('signature' in str(corps.get('erreur', '')),
              'le refus doit nommer la signature absente (%r)'
              % str(corps.get('erreur'))[:160])
        verif('PNG' in str(corps.get('erreur', '')),
              'le refus doit rappeler le format annoncé par le nom (%r)'
              % str(corps.get('erreur'))[:160])
        egal('un refus ne porte pas de data URI', corps.get('uri'), '')
        egal('le format annoncé reste celui du nom, pour un refus lisible',
             corps.get('format'), 'PNG')
        # La tolérance qui reste : un SVG dont la balise n'est pas dans l'en-tête.
        statut, corps = poster('/api/image', action='lire', chemin='puzzle.svg')
        egal('un SVG sans balise dans l’en-tête répond 200', statut, 200)
        egal('un SVG sans balise dans l’en-tête reste toléré',
             corps.get('ok'), True)
        egal('son mime vient de l’extension', corps.get('mime'), 'image/svg+xml')
        egal('il n’invente pas de dimensions', corps.get('dimensions_connues'),
             False)
        # Un PNG trop petit pour être lu ne doit pas faire lever la route.
        srv.ecrire('minuscule.png', b'\x89PNG\r\n\x1a\n', mode='wb')
        statut, corps = poster('/api/image', action='lire', chemin='minuscule.png')
        egal('un PNG tronqué répond 200', statut, 200)
        verif(corps.get('ok') in (True, False),
              'un PNG tronqué doit rendre un état, pas une exception')

        print('\n=== /api/image : les chemins sont jugés par resolve() ===')
        statut, corps = poster('/api/image', action='lire', chemin='/etc/passwd')
        verif(statut in (400, 200) and (statut == 400 or corps.get('ok') is False),
              'lire /etc/passwd doit être refusé (%d, %r)'
              % (statut, str(corps)[:120]))
        statut, corps = poster('/api/image', action='lire',
                               chemin='../hors-projet.png')
        verif(statut == 400 or corps.get('ok') is False,
              'une échappée hors du projet doit être refusée (%d)' % statut)

        print('\n=== /api/image : voisinage, analyse Piet, conversion ===')
        statut, corps = poster('/api/image', action='voisins',
                               chemin='programme.png')
        egal('le voisinage répond 200', statut, 200)
        verif('programme.png' in (corps.get('images') or []),
              'l’image demandée doit figurer dans son propre voisinage')
        verif('logo.png' in (corps.get('images') or []),
              'les autres images du dossier doivent être listées')
        verif('notes.txt' not in (corps.get('images') or []),
              'un fichier texte ne doit pas être proposé comme image voisine')
        egal('la position est cohérente avec la liste',
             (corps.get('images') or [])[corps.get('position', -1)],
             'programme.png')

        statut, corps = poster('/api/image', action='piet', chemin='programme.png')
        egal('l’analyse Piet répond 200', statut, 200)
        egal('le PNG exemple est un programme Piet', corps.get('est_piet'), True)
        egal('trois couleurs sont lues', corps.get('couleurs'), 3)
        statut, corps = poster('/api/image', action='piet', chemin='logo.png')
        egal('un PNG ordinaire n’est pas un programme Piet', corps.get('est_piet'),
             False)
        verif(bool(corps.get('raison')),
              'le verdict « pas un programme Piet » doit être EXPLIQUÉ : sans '
              'raison, l’utilisateur croit que l’analyse est cassée')

        # programme.piett existe déjà (fixture) : la conversion DOIT refuser
        # d'écraser. Une route qui écraserait détruirait une source écrite à la
        # main sans jamais le dire.
        statut, corps = poster('/api/image', action='convertir-piet',
                               chemin='programme.png')
        egal('une destination existante est refusée', statut, 400)
        verif('existe déjà' in str(corps.get('error', '')),
              'le refus doit dire que la destination existe déjà (%r)'
              % str(corps.get('error'))[:140])
        egal('aucun fichier n’a été écrasé',
             io.open(projet / 'programme.piett', encoding='utf8').read(), EXEMPLE)

        # Sur une copie dont le .piett n'existe pas, la conversion écrit la
        # source — et la destination est IMPOSÉE par la route, jamais choisie par
        # l'appelant : sinon cette route pourrait écrire n'importe où.
        statut, corps = poster('/api/image', action='convertir-piet',
                               chemin='copie.png')
        egal('la conversion répond 200', statut, 200)
        egal('la conversion réussit', corps.get('ok'), True)
        egal('la destination est imposée : même nom, extension .piett',
             Path(str(corps.get('destination'))).name, 'copie.piett')
        egal('le codel retenu est celui deviné dans le PNG', corps.get('codel'), 4)
        verif((projet / 'copie.piett').is_file(),
              'la source convertie doit exister sur le disque')
        statut, redecodage = poster('/api/piet', action='decoder',
                                    texte=corps.get('texte') or '')
        egal('la source convertie se redécode', redecodage.get('ok'), True)
        egal('la grille convertie est celle du programme',
             redecodage.get('cellules'), [['rc', 'rn', 'ms']])
        statut, corps = poster('/api/image', action='convertir-piet',
                               chemin='notes.txt')
        egal('convertir un fichier qui n’est pas un PNG est refusé', statut, 400)
        verif('PNG' in str(corps.get('error', '')),
              'le refus doit dire qu’un seul PNG peut être un programme Piet')
        statut, corps = poster('/api/image', action='convertir-piet',
                               chemin='logo.png')
        egal('convertir un PNG ordinaire est refusé', statut, 400)
        verif('Piet' in str(corps.get('error', '')),
              'le refus doit nommer Piet et sa raison (%r)'
              % str(corps.get('error'))[:140])

        print('\n=== /api/piet : le catalogue vient du module ===')
        statut, corps = poster('/api/piet', action='capacites')
        egal('les capacités Piet répondent 200', statut, 200)
        egal('le format est nommé', corps.get('format'), 'piet-texte')
        egal('l’extension est .piett', corps.get('extension'), '.piett')
        egal('vingt couleurs', corps.get('couleurs'), 20)
        egal('dix-sept commandes', corps.get('commandes'), 17)
        egal('le moteur annoncé est celui de la 3.8.0, inchangé',
             corps.get('moteur'), 'langages_esoteriques.Piet (inchangé)')
        verif(corps.get('pas_a_pas') is True,
              'le pas à pas doit être annoncé : c’est lui qui rend le langage '
              'débogable')

        statut, corps = poster('/api/piet', action='catalogue')
        egal('le catalogue répond 200', statut, 200)
        palette = corps.get('palette') or []
        egal('la palette a les vingt couleurs du module', len(palette),
             len(piet_texte.COULEURS))
        verif(all(set(c) >= {'code', 'nom', 'hexa', 'rvb'} for c in palette),
              'chaque couleur doit porter son code, son nom, son hexa et son RVB')
        codes = {c['code'] for c in palette}
        verif({'rc', 'rn', 'ms', 'bl', 'no'} <= codes,
              'les codes attendus par l’éditeur doivent exister')
        verif(all(len(c['code']) == 2 for c in palette),
              'un code de couleur fait deux lettres : c’est ce que la grille '
              'texte affiche')
        commandes = corps.get('commandes') or []
        egal('les dix-sept commandes sont servies', len(commandes),
             len(piet_texte.transitions()))
        verif(all({'delta_teinte', 'delta_luminosite'} <= set(c)
                  for c in commandes),
              'chaque commande doit dire son changement de teinte et de '
              'luminosité : c’est la règle du langage')
        egal('la version du format est servie', corps.get('version'),
             piet_texte.VERSION_FORMAT)

        print('\n=== /api/piet : aller-retour texte, PNG, exécution ===')
        statut, corps = poster('/api/piet', action='exemple')
        egal('l’exemple répond 200', statut, 200)
        egal('l’exemple servi est celui du module', corps.get('texte'), EXEMPLE)

        statut, corps = poster('/api/piet', action='decoder', texte=EXEMPLE)
        egal('le décodage répond 200', statut, 200)
        egal('l’exemple se décode', corps.get('ok'), True)
        egal('la grille décodée', corps.get('cellules'), [['rc', 'rn', 'ms']])
        egal('le codel déclaré est lu', corps.get('codel'), 4)
        egal('la largeur en codels', corps.get('largeur'), 3)
        egal('la hauteur en codels', corps.get('hauteur'), 1)

        # Un texte refusé : HTTP 200 et ok:false, parce que decoder() ne lève
        # JAMAIS. C'est ce qui permet à l'éditeur de montrer la ligne fautive au
        # lieu de perdre le texte.
        statut, corps = poster('/api/piet', action='decoder', texte=INVALIDE)
        egal('un texte invalide répond 200, pas 400', statut, 200)
        egal('un texte invalide est refusé', corps.get('ok'), False)
        diagnostics = corps.get('diagnostics') or []
        verif(bool(diagnostics), 'un refus doit porter des diagnostics')
        verif(any(d.get('severity') == 'error' for d in diagnostics),
              'au moins un diagnostic doit être une erreur')
        verif(any('zz' in str(d.get('message', '')) for d in diagnostics),
              'le diagnostic doit nommer la couleur refusée')
        verif(any(d.get('line') == 4 for d in diagnostics),
              'le diagnostic doit donner la LIGNE fautive')

        statut, corps = poster('/api/piet', action='encoder',
                               cellules=[['rc', 'rn', 'ms']], codel=4)
        egal('l’encodage répond 200', statut, 200)
        texte_encode = corps.get('texte') or ''
        verif('rc rn ms' in texte_encode,
              'la grille encodée doit contenir ses cellules')
        verif('codel 4' in texte_encode, 'le codel doit être déclaré')
        statut, redecode = poster('/api/piet', action='decoder',
                                  texte=texte_encode)
        egal('l’aller-retour encoder puis decoder rend la même grille',
             redecode.get('cellules'), [['rc', 'rn', 'ms']])

        statut, corps = poster('/api/piet', action='analyser', texte=EXEMPLE)
        egal('l’analyse de structure répond 200', statut, 200)
        egal('trois blocs de couleur', corps.get('nombre_blocs'), 3)
        egal('le codel retenu', corps.get('codel'), 4)
        verif(isinstance(corps.get('blocs'), list) and corps['blocs'],
              'les blocs doivent être listés : c’est ce que surligne l’éditeur')

        statut, corps = poster('/api/piet', action='png', texte=EXEMPLE)
        egal('la compilation en PNG répond 200', statut, 200)
        uri = str(corps.get('uri', ''))
        verif(uri.startswith('data:image/png;base64,'),
              'le PNG compilé doit arriver en data URI')
        egal('le PNG compilé est celui du module',
             base64.b64decode(uri.split(',', 1)[1]), PNG_EXEMPLE)
        statut, corps = poster('/api/piet', action='png', texte=INVALIDE)
        verif(statut == 400 or corps.get('ok') is False,
              'compiler un texte invalide doit être refusé en le disant (%d)'
              % statut)

        statut, corps = poster('/api/piet', action='executer', texte=EXEMPLE)
        egal('l’exécution répond 200', statut, 200)
        egal('l’exemple écrit « 1 »', corps.get('sortie') or corps.get('output'),
             '1')
        verif(bool(corps.get('pas')), 'le nombre de pas doit être rendu')
        egal('le programme se termine', corps.get('termine'), True)
        verif('piet_texte' in corps,
              'le compte rendu doit dire la taille de la grille compilée')
        statut, corps = poster('/api/piet', action='executer', texte=INVALIDE)
        egal('exécuter un texte invalide répond 200 avec ok:false',
             (statut, corps.get('ok')), (200, False))
        verif(bool(corps.get('diagnostics')),
              'une exécution refusée doit rendre ses diagnostics : l’éditeur les '
              'affiche sous la sortie')
        statut, corps = poster('/api/piet', action='executer',
                               texte='piet 1\ncodel 4\ngrille 1 1\nrc\n',
                               limite=1)
        verif(statut == 200, 'la borne d’instructions est acceptée (%d)' % statut)

        print('\n=== /api/piet : lire et écrire des fichiers ===')
        statut, corps = poster('/api/piet', action='lire', chemin='programme.piett')
        egal('la lecture d’une source répond 200', statut, 200)
        egal('le texte lu est celui du fichier', corps.get('texte'), EXEMPLE)
        egal('le décodage accompagne la lecture',
             (corps.get('decode') or {}).get('ok'), True)
        statut, corps = poster('/api/piet', action='lire', chemin='notes.txt')
        egal('lire un fichier qui n’est pas .piett est refusé', statut, 400)
        verif('.piett' in str(corps.get('error', '')),
              'le refus doit nommer l’extension attendue (%r)'
              % str(corps.get('error'))[:120])

        # Une écriture valide : le fichier est créé, et rien d'autre.
        statut, corps = poster('/api/piet', action='ecrire', chemin='ecrit.piett',
                               texte=EXEMPLE)
        egal('l’écriture répond 200', statut, 200)
        egal('l’écriture réussit', corps.get('ok'), True)
        egal('les octets écrits sont comptés', corps.get('octets'),
             len(EXEMPLE.encode('utf8')))
        egal('le fichier est bien sur le disque',
             io.open(projet / 'ecrit.piett', encoding='utf8').read(), EXEMPLE)

        # Une écriture invalide : 400, et RIEN sur le disque. C'est le refus qui
        # empêche de laisser un fichier que l'éditeur ne saura plus rouvrir.
        statut, corps = poster('/api/piet', action='ecrire',
                               chemin='casse.piett', texte=INVALIDE)
        egal('écrire un texte invalide est refusé', statut, 400)
        verif('invalide' in str(corps.get('error', '')).lower(),
              'le refus doit dire que le programme est invalide (%r)'
              % str(corps.get('error'))[:140])
        verif(not (projet / 'casse.piett').exists(),
              'un texte refusé ne doit laisser AUCUN fichier sur le disque')
        statut, corps = poster('/api/piet', action='ecrire', chemin='ecrit.piett',
                               texte=INVALIDE)
        egal('un fichier existant n’est pas écrasé par un texte invalide',
             statut, 400)
        egal('le contenu précédent est intact',
             io.open(projet / 'ecrit.piett', encoding='utf8').read(), EXEMPLE)
        statut, corps = poster('/api/piet', action='ecrire', chemin='notes.txt',
                               texte=EXEMPLE)
        egal('écrire hors .piett est refusé', statut, 400)
        egal('le fichier visé n’a pas été touché',
             io.open(projet / 'notes.txt', encoding='utf8').read(),
             'ceci n’est pas une image')
        statut, corps = poster('/api/piet', action='ecrire',
                               chemin='/tmp/pirate.piett', texte=EXEMPLE)
        verif(statut == 400, 'écrire hors du projet doit être refusé (%d)' % statut)
        verif(not Path('/tmp/pirate.piett').exists(),
              'aucun fichier ne doit être écrit hors du projet')

        print('\n=== /api/piet : exporter en PNG, revenir d’un PNG ===')
        statut, corps = poster('/api/piet', action='exporter-png',
                               chemin='ecrit.piett', texte=EXEMPLE)
        egal('l’export PNG répond 200', statut, 200)
        egal('l’export écrit le PNG compilé à côté de la source',
             Path(str(corps.get('destination'))).name, 'ecrit.png')
        egal('les octets du PNG sont ceux du module',
             (projet / 'ecrit.png').read_bytes(), PNG_EXEMPLE)
        statut, corps = poster('/api/piet', action='exporter-png',
                               chemin='ecrit.piett', texte=EXEMPLE)
        egal('un second export est refusé : la destination existe', statut, 400)
        verif('existe déjà' in str(corps.get('error', '')),
              'le refus doit dire que le fichier existe déjà (%r)'
              % str(corps.get('error'))[:120])
        statut, corps = poster('/api/piet', action='exporter-png',
                               chemin='notes.txt', texte=EXEMPLE)
        egal('exporter depuis un fichier qui n’est pas .piett est refusé',
             statut, 400)

        statut, corps = poster('/api/piet', action='depuis-png',
                               chemin='programme.png')
        egal('le retour depuis un PNG répond 200', statut, 200)
        egal('le retour depuis un PNG réussit', corps.get('ok'), True)
        texte_depuis = corps.get('texte') or ''
        verif('rc' in texte_depuis and 'ms' in texte_depuis,
              'le texte revenu du PNG doit porter les couleurs lues')
        statut, redecodage = poster('/api/piet', action='decoder',
                                    texte=texte_depuis)
        egal('le texte revenu d’un PNG se redécode', redecodage.get('ok'), True)
        statut, corps = poster('/api/piet', action='depuis-png', chemin='logo.png')
        egal('revenir d’un PNG qui n’est pas un programme Piet est refusé',
             statut, 400)
        verif('Piet' in str(corps.get('error', '')),
              'le refus doit nommer Piet et donner la raison (%r)'
              % str(corps.get('error'))[:160])
        verif('hors' in str(corps.get('error', '')).lower()
              or 'palette' in str(corps.get('error', '')).lower(),
              'le refus doit dire que les couleurs sortent de la palette (%r)'
              % str(corps.get('error'))[:160])
        # Le même PNG, analysé sans conversion : le verdict doit être le même,
        # sinon les deux routes se contredisent devant l'utilisateur.
        statut, analyse = poster('/api/image', action='piet', chemin='logo.png')
        egal('l’analyse dit elle aussi que ce n’est pas un programme Piet',
             analyse.get('est_piet'), False)

        print('\n=== les deux routes : actions inconnues et garde locale ===')
        for route in ('/api/image', '/api/piet'):
            statut, corps = poster(route, action='bidule')
            egal('%s : une action inconnue répond 400' % route, statut, 400)
            verif('bidule' in str(corps.get('error', '')),
                  '%s : le refus doit nommer l’action inconnue (%r)'
                  % (route, str(corps.get('error'))[:120]))
            statut, corps = poster(route, action='capacites',
                                   entetes={'Origin': 'https://ailleurs.test'})
            verif(statut in (400, 403) or corps.get('error'),
                  '%s : un Origin étranger doit être refusé (%d, %r)'
                  % (route, statut, str(corps)[:120]))
        # La garde compte surtout sur les verbes qui ÉCRIVENT.
        statut, corps = poster('/api/piet', action='ecrire',
                               chemin='pirate.piett', texte=EXEMPLE,
                               entetes={'Origin': 'https://ailleurs.test'})
        verif(statut in (400, 403) or corps.get('error'),
              'un Origin étranger ne doit JAMAIS pouvoir écrire dans le projet '
              '(%d)' % statut)
        verif(not (projet / 'pirate.piett').exists(),
              'aucun fichier ne doit avoir été écrit depuis un Origin étranger')

        print('\n=== rien n’est écrit là où rien n’est demandé ===')
        apres = sorted(str(q.relative_to(projet)) for q in projet.rglob('*'))
        attends = sorted(avant + ['ecrit.piett', 'ecrit.png', 'minuscule.png',
                                  'copie.piett'])
        verif('programme.piett' in apres and 'notes.txt' in apres,
              'les fixtures de départ doivent être intactes')
        egal('l’arborescence du projet ne porte que les fichiers demandés',
             apres, attends)


def main():
    try:
        principal()
    except Exception as exc:                       # un banc doit dire pourquoi
        import traceback
        traceback.print_exc()
        ECHECS.append('exception du banc : %s' % exc)
    total = OK + len(ECHECS)
    print('\nsmoke_routes_images_piet : %d/%d contrôles' % (OK, total))
    if ECHECS:
        print('ÉCHECS (%d) :' % len(ECHECS))
        for titre in ECHECS:
            print('  - ' + titre)
        return 1
    print('Aucun échec.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
