#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : l'ÉCRITURE des miroirs et les opérations de structure.

Pourquoi ce banc existe à côté des deux autres
----------------------------------------------
    `smoke_donnees_etendues.py` appelle `donnees_etendues` directement, et
    `smoke_routes_donnees.py` vérifie que les formats s'OUVRENT par HTTP. Aucun
    des deux ne pouvait voir le défaut que ce banc cherche : une grille annoncée
    « modifiable » dont l'enregistrement renvoyait HTTP 400 avec, pour toute
    explication, `{'error': "'conn'"}` — le nom d'une variable Python, parce que
    `Manager.apply()` cherchait une connexion SQL qu'un classeur n'a pas.

    Ce banc démarre donc `server.py` comme le fait l'application et exerce toute
    la chaîne : ouvrir, lire la grille, modifier une case, ajouter et supprimer
    des lignes, ajouter et supprimer des colonnes, créer et supprimer une table,
    puis relire LE FICHIER pour vérifier que ce qui a été annoncé a bien été
    écrit. Trois familles de formats sont couvertes :

      * les miroirs (XLSX, ODS, XML), où les modifications sont reportées sur la
        copie en session puis le fichier est réécrit d'un coup ;
      * les bases (SQLite), où les mêmes boutons produisent de vraies
        instructions CREATE TABLE / ALTER TABLE / DROP TABLE ;
      * les formats texte (CSV, JSON, script SQL), où la même demande doit
        refuser en disant QUEL bouton utiliser à la place — un refus muet, ou un
        refus qui parle d'autre chose, laisse l'utilisateur sans issue.

    Sont vérifiées aussi les garanties dont la perte serait invisible : une
    feuille non mentionnée survit à l'écriture d'une autre, un commentaire XML
    placé hors de la racine est recopié, une ligne modifiée ailleurs produit un
    conflit au lieu d'un écrasement, un nom de colonne piégé est neutralisé et
    non exécuté, et un classeur à formules est annoncé NON modifiable dès
    l'ouverture plutôt qu'au moment d'enregistrer.

Lancer :  python3 tests/smoke_routes_miroirs.py
"""

import io
import os
import sys
import zipfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serveur_de_test import ServeurDeTest  # noqa: E402

OK = 0
ECHECS = 0


def verif(condition, titre):
    global OK, ECHECS
    if condition:
        OK += 1
    else:
        ECHECS += 1
        print('  ECHEC : %s' % titre)


def egal(titre, obtenu, attendu):
    if obtenu == attendu:
        verif(True, titre)
    else:
        verif(False, '%s\n        obtenu  : %r\n        attendu : %r'
              % (titre, obtenu, attendu))


def contient(titre, texte, morceau):
    verif(morceau in str(texte),
          '%s\n        attendu dans le message : %r\n        message : %r'
          % (titre, morceau, texte))


ODS_FIXTURE = '''<?xml version="1.0" encoding="UTF-8"?>
<office:document-content
 xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0"
 xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0"
 xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" office:version="1.2">
<office:body><office:spreadsheet>
<table:table table:name="Stock">
<table:table-row><table:table-cell><text:p>article</text:p></table:table-cell><table:table-cell><text:p>quantite</text:p></table:table-cell></table:table-row>
<table:table-row><table:table-cell><text:p>vis</text:p></table:table-cell><table:table-cell><text:p>120</text:p></table:table-cell></table:table-row>
<table:table-row><table:table-cell><text:p>écrou</text:p></table:table-cell><table:table-cell><text:p>340</text:p></table:table-cell></table:table-row>
</table:table>
</office:spreadsheet></office:body></office:document-content>'''

ODS_FORMULES = ODS_FIXTURE.replace(
    '<table:table-cell><text:p>vis</text:p></table:table-cell>',
    '<table:table-cell table:formula="of:=[.A1]+[.B1]" office:value-type="float"'
    ' office:value="5"><text:p>vis</text:p></table:table-cell>')

XML_FIXTURE = ('<?xml version="1.0" encoding="UTF-8"?>\n'
               '<!-- carnet de test -->\n'
               '<carnet>\n'
               '  <contact id="1" nom="Ada"/>\n'
               '  <contact id="2" nom="Grace"/>\n'
               '</carnet>\n')


def ecrire_ods(chemin, contenu):
    with zipfile.ZipFile(chemin, 'w', zipfile.ZIP_STORED) as archive:
        archive.writestr(
            'mimetype',
            b'application/vnd.oasis.opendocument.spreadsheet')
        archive.writestr('content.xml', contenu)


def preparer(racine):
    import openpyxl
    classeur = openpyxl.Workbook()
    feuille = classeur.active
    feuille.title = 'Clients'
    feuille.append(['id', 'nom', 'ville'])
    feuille.append(['1', 'Ada', 'Paris'])
    feuille.append(['2', 'Grace', 'Lyon'])
    seconde = classeur.create_sheet(title='Commandes')
    seconde.append(['ref', 'client'])
    seconde.append(['A1', 'Ada'])
    classeur.save(os.path.join(racine, 'clients.xlsx'))

    ecrire_ods(os.path.join(racine, 'stock.ods'), ODS_FIXTURE)
    ecrire_ods(os.path.join(racine, 'formules.ods'), ODS_FORMULES)
    io.open(os.path.join(racine, 'carnet.xml'), 'w', encoding='utf-8').write(XML_FIXTURE)
    io.open(os.path.join(racine, 'donnees.csv'), 'w', encoding='utf-8').write('a,b\n1,2\n')
    io.open(os.path.join(racine, 'donnees.json'), 'w', encoding='utf-8').write('[{"a": 1}]\n')
    io.open(os.path.join(racine, 'schema.sql'), 'w', encoding='utf-8').write(
        'CREATE TABLE t (a INTEGER);\n')


def lire(racine, nom):
    return io.open(os.path.join(racine, nom), encoding='utf-8').read()


def banc_xlsx(srv, client, racine):
    print('-- XLSX : grille modifiable, cases, lignes, fusion')
    statut, corps = client.data('open', path='clients.xlsx')
    egal('xlsx : ouverture', statut, 200)
    egal('xlsx : famille reconnue', corps.get('kind'), 'xlsx')
    session = corps['id']
    egal('xlsx : deux feuilles annoncées', len(corps['tables']), 2)
    verif(corps.get('editable') is True,
          'xlsx : la grille n’est pas annoncée modifiable à l’ouverture : %r' % corps)
    verif(corps.get('tables')[0].get('formules') is not True,
          'xlsx : un classeur sans formule est annoncé comme en portant')

    statut, rows = client.data('rows', id=session, schema='', table='Clients')
    egal('xlsx : lecture de la grille', statut, 200)
    verif(rows.get('editable') is True, 'xlsx : la grille se dit non modifiable : %r' % rows)
    egal('xlsx : colonnes rendues', [c['name'] for c in rows['columns']],
         ['id', 'nom', 'ville'])

    # LE DÉFAUT RECHERCHÉ : apply() mourait sur s['conn'] et rendait {'error': "'conn'"}.
    statut, res = client.data('apply', id=session, schema='', table='Clients', edits=[
        {'original': ['1', 'Ada', 'Paris'], 'changes': {'ville': 'Londres'}},
        {'insert': {'id': '3', 'nom': 'Katherine', 'ville': 'Berlin'}},
        {'original': ['2', 'Grace', 'Lyon'], 'delete': True},
    ])
    egal('xlsx : enregistrement accepté', statut, 200)
    egal('xlsx : trois modifications annoncées', res.get('changed'), 3)
    verif("'conn'" not in str(res), 'xlsx : la réponse cite encore une variable Python : %r' % res)
    statut, rows = client.data('rows', id=session, schema='', table='Clients')
    egal('xlsx : case modifiée relue', rows['rows'][0], ['1', 'Ada', 'Londres'])
    verif(['2', 'Grace', 'Lyon'] not in rows['rows'],
          'xlsx : la ligne supprimée est revenue : %r' % rows['rows'])
    verif(['3', 'Katherine', 'Berlin'] in rows['rows'],
          'xlsx : la ligne ajoutée est absente : %r' % rows['rows'])

    # La garantie la plus importante de l'écriture : ce qui n'est pas mentionné
    # survit. Sans la fusion, enregistrer une feuille vidait les autres.
    statut, tables = client.data('tables', id=session)
    egal('xlsx : la seconde feuille a survécu', len(tables['tables']), 2)
    statut, rows = client.data('rows', id=session, schema='', table='Commandes')
    egal('xlsx : données de la seconde feuille intactes', rows['rows'], [['A1', 'Ada']])

    import openpyxl
    feuille = openpyxl.load_workbook(os.path.join(racine, 'clients.xlsx'))['Clients']
    valeurs = [[('' if c is None else str(c)) for c in ligne]
               for ligne in feuille.iter_rows(values_only=True)]
    egal('xlsx : en-tête écrit une seule fois', valeurs[0], ['id', 'nom', 'ville'])
    egal('xlsx : aucun en-tête dupliqué', valeurs.count(['id', 'nom', 'ville']), 1)

    statut, res = client.data('apply', id=session, schema='', table='Clients', edits=[
        {'original': ['9', 'Inconnu', 'Nulle part'], 'changes': {'ville': 'X'}}])
    egal('xlsx : une ligne introuvable produit un conflit', statut, 400)
    contient('xlsx : le refus parle de conflit', res.get('error'), 'Conflit')
    statut, rows = client.data('rows', id=session, schema='', table='Clients')
    verif(['3', 'Katherine', 'Berlin'] in rows['rows'],
          'xlsx : un refus a tout de même modifié quelque chose : %r' % rows['rows'])

    statut, res = client.data('apply', id=session, schema='', table='Clients', edits=[
        {'insert': {'inexistante': 'x'}}])
    egal('xlsx : colonne inconnue refusée', statut, 400)
    contient('xlsx : le refus nomme la colonne', res.get('error'), 'inexistante')
    contient('xlsx : le refus dit quoi faire', res.get('error'), 'Ajoutez')

    statut, res = client.data('apply', id=session, schema='', table='Clients', edits=[
        {'original': ['1', 'Ada', 'Londres'], 'changes': {'ville': {'$kind': 'objet'}}}])
    egal('xlsx : une valeur non simple est refusée', statut, 400)

    # Enregistrer un classeur comme du texte doit dire quoi faire à la place.
    statut, res = client.data('save', id=session, revision='peuimporte', text='x')
    egal('xlsx : save est refusé', statut, 400)
    contient('xlsx : le refus de save explique la vraie voie', res.get('error'), 'classeur')
    verif("'conn'" not in str(res.get('error')),
          'xlsx : le refus de save cite une variable Python : %r' % res)
    client.data('close', id=session)


def banc_ods(srv, client, racine):
    print('-- ODS : structure (feuille, colonnes), écriture, refus')
    statut, corps = client.data('open', path='stock.ods')
    egal('ods : ouverture', statut, 200)
    session = corps['id']

    statut, res = client.data('structure', id=session, action='create_table',
                              name='Prix', columns=[{'name': 'article'}, {'name': 'euros'}])
    egal('ods : création d’une feuille', statut, 200)
    verif(res.get('ok') is True, 'ods : la création n’est pas annoncée réussie : %r' % res)
    contient('ods : l’instruction est rendue', res.get('instruction'), 'feuille')
    statut, tables = client.data('tables', id=session)
    egal('ods : deux feuilles après création', len(tables['tables']), 2)

    statut, res = client.data('structure', id=session, action='add_column',
                              name='Stock', column='prix', default='0')
    egal('ods : ajout d’une colonne', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='Stock')
    egal('ods : colonne ajoutée visible', [c['name'] for c in rows['columns']],
         ['article', 'quantite', 'prix'])
    verif(all(r[2] == '0' for r in rows['rows']),
          'ods : la valeur par défaut n’a pas été remplie : %r' % rows['rows'])

    statut, res = client.data('apply', id=session, schema='', table='Stock', edits=[
        {'original': ['vis', '120', '0'], 'changes': {'prix': '1,20'}}])
    egal('ods : case écrite', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='Stock')
    egal('ods : case relue', rows['rows'][0], ['vis', '120', '1,20'])
    # « 1,20 » n'est pas un nombre : il doit rester du texte et non devenir 1.2.
    contenu = zipfile.ZipFile(os.path.join(racine, 'stock.ods')).read(
        'content.xml').decode('utf-8')
    contient('ods : la valeur textuelle est écrite comme telle', contenu, '>1,20<')
    verif('office:value="1,2"' not in contenu and 'office:value="1.2"' not in contenu,
          'ods : une valeur textuelle a été convertie en nombre : %r' % contenu[:300])

    statut, res = client.data('structure', id=session, action='drop_column',
                              name='Stock', column='quantite')
    egal('ods : suppression d’une colonne', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='Stock')
    egal('ods : colonne supprimée absente', [c['name'] for c in rows['columns']],
         ['article', 'prix'])
    egal('ods : données réalignées', rows['rows'][0], ['vis', '1,20'])

    statut, res = client.data('structure', id=session, action='drop_table', name='Prix')
    egal('ods : suppression d’une feuille', statut, 200)
    statut, tables = client.data('tables', id=session)
    egal('ods : feuille supprimée absente', [t['name'] for t in tables['tables']], ['Stock'])

    statut, res = client.data('structure', id=session, action='drop_table', name='Stock')
    egal('ods : supprimer la dernière table est refusé', statut, 400)
    contient('ods : le refus dit quoi faire à la place', res.get('error'), 'texte')
    statut, tables = client.data('tables', id=session)
    egal('ods : le refus n’a rien supprimé', [t['name'] for t in tables['tables']], ['Stock'])

    statut, res = client.data('structure', id=session, action='drop_table', name='Absente')
    egal('ods : table inexistante refusée', statut, 400)
    contient('ods : le refus nomme la table', res.get('error'), 'Absente')

    statut, res = client.data('structure', id=session, action='detruire', name='Stock')
    egal('ods : action inconnue refusée', statut, 400)
    contient('ods : le refus nomme les actions prises en charge', res.get('error'), 'create_table')

    statut, res = client.data('structure', id=session, action='add_column',
                              name='Stock', column='article')
    egal('ods : colonne en double refusée', statut, 400)
    contient('ods : le refus dit qu’elle existe déjà', res.get('error'), 'existe déjà')

    statut, res = client.data('structure', id=session, action='add_column',
                              name='Stock', column='prix')
    egal('ods : nouvelle colonne en double refusée', statut, 400)

    # Un classeur à formules doit être annoncé NON modifiable dès l'ouverture.
    statut, corps = client.data('open', path='formules.ods')
    egal('ods à formules : ouverture', statut, 200)
    verif(corps.get('editable') is False,
          'ods à formules : annoncé modifiable alors que l’écriture est refusée : %r'
          % corps)
    contient('ods à formules : la raison est donnée', corps.get('raison_lecture_seule'),
             'formules')
    nom_table = corps['tables'][0]['name']
    statut, rows = client.data('rows', id=corps['id'], schema='', table=nom_table)
    verif(rows.get('editable') is False,
          'ods à formules : la grille se dit modifiable : %r' % rows.get('editable'))
    verif(bool((rows.get('raison_lecture_seule') or '').strip()),
          'ods à formules : la grille est en lecture seule sans dire pourquoi')
    statut, res = client.data('apply', id=corps['id'], schema='', table=nom_table,
                              edits=[{'insert': {'article': 'x'}}])
    egal('ods à formules : l’enregistrement est refusé', statut, 400)
    contient('ods à formules : le refus propose une issue', res.get('error'), 'CSV')
    client.data('close', id=corps['id'])

    # L'empreinte protège d'un fichier modifié ailleurs entre-temps.
    with zipfile.ZipFile(os.path.join(racine, 'stock.ods'), 'a') as archive:
        archive.writestr('meta.xml', '<x/>')
    statut, rows = client.data('rows', id=session, schema='', table='Stock')
    statut, res = client.data('apply', id=session, schema='', table='Stock', edits=[
        {'original': rows['rows'][0], 'changes': {'prix': '9'}}])
    egal('ods : un fichier modifié ailleurs est refusé', statut, 400)
    contient('ods : le refus parle du disque', res.get('error'), 'disque')
    client.data('close', id=session)


def banc_xml(srv, client, racine):
    print('-- XML : cases, lignes, colonnes, préambule, requêtes')
    statut, corps = client.data('open', path='carnet.xml')
    egal('xml : ouverture', statut, 200)
    session = corps['id']
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    egal('xml : lecture de la grille', statut, 200)
    verif(rows.get('editable') is True, 'xml : la grille se dit non modifiable')
    egal('xml : attributs devenus colonnes', [c['name'] for c in rows['columns']],
         ['id', 'nom'])

    statut, res = client.data('apply', id=session, schema='', table='contact', edits=[
        {'original': ['1', 'Ada'], 'changes': {'nom': 'Ada Lovelace'}},
        {'insert': {'id': '3', 'nom': 'Katherine'}},
    ])
    egal('xml : enregistrement accepté', statut, 200)
    egal('xml : deux modifications annoncées', res.get('changed'), 2)
    brut = lire(racine, 'carnet.xml')
    contient('xml : case écrite dans le fichier', brut, 'Ada Lovelace')
    contient('xml : ligne ajoutée dans le fichier', brut, 'Katherine')
    contient('xml : commentaire conservé', brut, '<!-- carnet de test -->')
    contient('xml : déclaration conservée', brut, 'encoding="UTF-8"')
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    egal('xml : trois lignes relues', len(rows['rows']), 3)

    statut, res = client.data('structure', id=session, action='add_column',
                              name='contact', column='ville', attribut=True)
    egal('xml : ajout d’une colonne attribut', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    verif('ville' in [c['name'] for c in rows['columns']],
          'xml : la colonne ajoutée est absente : %r' % rows['columns'])
    contient('xml : l’attribut est écrit dans le fichier', lire(racine, 'carnet.xml'),
             'ville=""')

    statut, res = client.data('structure', id=session, action='create_table',
                              name='Autres', columns=['x'])
    egal('xml : créer une table est refusé', statut, 400)
    contient('xml : le refus explique pourquoi', res.get('error'), 'éléments répétés')
    contient('xml : le refus donne la voie de recours', res.get('error'), 'texte')

    # La requête SQL sur le miroir doit refléter ce qui a été écrit. Elle est
    # faite AVANT les suppressions de colonnes, qui retirent justement ce que la
    # requête sélectionne.
    statut, res = client.data('query', id=session, sql="SELECT nom FROM contact WHERE id='3'")
    egal('xml : requête sur le miroir', statut, 200)
    egal('xml : résultat de la requête', res.get('rows'), [['Katherine']])
    statut, res = client.data('query', id=session, sql='SELECT COUNT(*) FROM contact')
    egal('xml : agrégat sur le miroir', statut, 200)
    egal('xml : résultat de l’agrégat', res.get('rows'), [['3']])
    statut, res = client.data('query', id=session, sql='DELETE FROM contact')
    egal('xml : une requête qui modifierait est refusée', statut, 400)
    contient('xml : le refus explique que rien ne serait écrit', res.get('error'), 'COPIE')
    contient('xml : le refus renvoie vers les boutons', res.get('error'), 'cases')
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    egal('xml : la requête refusée n’a rien changé', len(rows['rows']), 3)

    statut, res = client.data('structure', id=session, action='drop_column',
                              name='contact', column='ville')
    egal('xml : suppression d’une colonne', statut, 200)
    verif('ville=' not in lire(racine, 'carnet.xml'),
          'xml : l’attribut d’une colonne supprimée subsiste : %r'
          % lire(racine, 'carnet.xml'))
    statut, res = client.data('structure', id=session, action='drop_column',
                              name='contact', column='nom')
    egal('xml : suppression d’une seconde colonne', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    egal('xml : une seule colonne reste', [c['name'] for c in rows['columns']], ['id'])
    statut, res = client.data('structure', id=session, action='drop_column',
                              name='contact', column='id')
    egal('xml : supprimer la dernière colonne est refusé', statut, 400)
    contient('xml : le refus propose de supprimer la table', res.get('error'), 'table entière')
    statut, rows = client.data('rows', id=session, schema='', table='contact')
    egal('xml : le refus n’a rien supprimé', [c['name'] for c in rows['columns']], ['id'])
    client.data('close', id=session)


def banc_sqlite(srv, client, racine):
    print('-- SQLite : les mêmes boutons produisent de vraies instructions')
    statut, res = client.data('create-sqlite', path='base.sqlite')
    egal('sqlite : création de la base', statut, 200)
    statut, corps = client.data('open', path='base.sqlite')
    egal('sqlite : ouverture', statut, 200)
    session = corps['id']

    statut, res = client.data('structure', id=session, action='create_table',
                              name='personnes',
                              columns=[{'name': 'id', 'type': 'INTEGER'},
                                       {'name': 'nom', 'type': 'TEXT'}])
    egal('sqlite : CREATE TABLE exécuté', statut, 200)
    verif(str(res.get('instruction', '')).startswith('CREATE TABLE'),
          'sqlite : l’instruction exécutée n’est pas rendue : %r' % res)
    egal('sqlite : la table est annoncée', [t['name'] for t in res.get('tables', [])],
         ['personnes'])

    statut, res = client.data('structure', id=session, action='add_column',
                              name='personnes', column='ville', type='TEXT')
    egal('sqlite : ALTER TABLE ADD COLUMN exécuté', statut, 200)
    statut, rows = client.data('rows', id=session, schema='', table='personnes')
    egal('sqlite : trois colonnes après ajout', [c['name'] for c in rows['columns']],
         ['id', 'nom', 'ville'])

    statut, res = client.data('structure', id=session, action='add_column',
                              name='personnes', column='ville', type='TEXT')
    egal('sqlite : colonne en double refusée', statut, 400)
    contient('sqlite : le refus dit qu’elle existe déjà', res.get('error'), 'existe déjà')

    # Un nom piégé n'est pas exécuté : q() double le guillemet, donc la base crée
    # une colonne dont le NOM contient l'instruction. C'est le résultat attendu —
    # l'injection est neutralisée, pas refusée — et la table survit.
    piege = 'piège"; DROP TABLE personnes; --'
    statut, res = client.data('structure', id=session, action='add_column',
                              name='personnes', column=piege, type='TEXT')
    egal('sqlite : un nom piégé est accepté comme nom', statut, 200)
    contient('sqlite : le guillemet du nom piégé est doublé', res.get('instruction'), '""')
    statut, rows = client.data('rows', id=session, schema='', table='personnes')
    verif(piege in [c['name'] for c in rows['columns']],
          'sqlite : la colonne piégée ne porte pas son nom littéral : %r'
          % [c['name'] for c in rows['columns']])
    statut, res = client.data('structure', id=session, action='drop_column',
                              name='personnes', column=piege)
    egal('sqlite : la colonne piégée se supprime comme une autre', statut, 200)

    statut, res = client.data('structure', id=session, action='add_column',
                              name='personnes', column='mauvais',
                              type='TEXT; DROP TABLE personnes')
    egal('sqlite : un type piégé est refusé', statut, 400)
    contient('sqlite : le refus parle du type', res.get('error'), 'Type de colonne')
    statut, tables = client.data('tables', id=session)
    egal('sqlite : la table a survécu aux tentatives d’injection',
         [t['name'] for t in tables['tables']], ['personnes'])

    statut, res = client.data('structure', id=session, action='drop_column',
                              name='personnes', column='ville')
    egal('sqlite : ALTER TABLE DROP COLUMN exécuté', statut, 200)
    statut, res = client.data('structure', id=session, action='drop_column',
                              name='personnes', column='absente')
    egal('sqlite : colonne absente refusée', statut, 400)
    contient('sqlite : le refus nomme la colonne', res.get('error'), 'absente')
    statut, res = client.data('structure', id=session, action='drop_table',
                              name='inexistante')
    egal('sqlite : table absente refusée', statut, 400)
    contient('sqlite : le refus dit « introuvable »', res.get('error'), 'introuvable')
    statut, res = client.data('structure', id=session, action='drop_table',
                              name='personnes')
    egal('sqlite : DROP TABLE exécuté', statut, 200)
    statut, tables = client.data('tables', id=session)
    egal('sqlite : plus aucune table', tables['tables'], [])
    client.data('close', id=session)


def banc_texte(srv, client, racine):
    print('-- CSV, JSON, script SQL : le refus dit quoi faire à la place')
    for nom, action, attendu in (
            ('donnees.csv', 'create_table', '＋ Colonne'),
            ('donnees.csv', 'add_column', '＋ Colonne'),
            ('donnees.json', 'add_column', 'Propriété'),
            ('donnees.json', 'drop_table', 'Propriété'),
            ('schema.sql', 'create_table', 'script SQL'),
            ('schema.sql', 'add_column', 'script SQL')):
        statut, corps = client.data('open', path=nom)
        egal('%s : ouverture' % nom, statut, 200)
        payload = {'id': corps['id'], 'action': action, 'name': 'x',
                   'columns': ['a'], 'column': 'a'}
        statut, res = client.data('structure', **payload)
        egal('%s : %s est refusé' % (nom, action), statut, 400)
        contient('%s : le refus de %s nomme la voie réelle' % (nom, action),
                 res.get('error'), attendu)
        client.data('close', id=corps['id'])
    # Une session fermée doit le dire, et non échouer sur une clef manquante.
    statut, res = client.data('structure', id='inconnu', action='create_table', name='x')
    egal('une session inconnue est refusée', statut, 400)
    contient('le refus parle de la session', res.get('error'), 'Session')


def main():
    with ServeurDeTest() as srv:
        racine = srv.espace()
        preparer(racine)
        client = srv.client
        banc_xlsx(srv, client, racine)
        banc_ods(srv, client, racine)
        banc_xml(srv, client, racine)
        banc_sqlite(srv, client, racine)
        banc_texte(srv, client, racine)

    print('\nBanc des miroirs et de la structure : %d contrôles OK, %d échec(s)'
          % (OK, ECHECS))
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
