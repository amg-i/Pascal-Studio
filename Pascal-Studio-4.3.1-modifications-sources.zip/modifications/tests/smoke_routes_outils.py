#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : les routes /api/outils servies par le VRAI serveur.

Pourquoi ce banc existe à côté de l'autocontrôle d'outils_manquants.py
----------------------------------------------------------------------
    `python3 outils_manquants.py` exerce le module en appelant ses fonctions. Ce
    n'est pas ce que fait la fenêtre des paramètres : elle envoie
    `POST /api/outils` avec un JSON et lit une réponse JSON. Cinq choses ne sont
    visibles qu'ici :

      * `etendre_path()` et `etendre_syspath()` doivent avoir été appelés À
        L'IMPORTATION de server.py. Si le dossier des outils n'est pas dans PATH
        quand le serveur répond, un outil installé depuis les paramètres reste
        « manquant » jusqu'au redémarrage — et le panneau qui vient de
        l'installer annonce un échec. Le banc lit `etat.chemins.dans_path` ;
      * la garde `local_auth_allowed()` doit rejeter un Origin étranger. Ces
        routes sont les plus sensibles du produit : `installer` peut lancer
        `pkexec apt-get install`. Une page web ouverte dans le navigateur
        intégré ne doit pas pouvoir provoquer cette demande ;
      * `racine_autorisee` ne doit avoir d'effet que là où il est prévu. Le
        dispatch est écrit branche par branche précisément pour qu'un
        `getattr(module, nom)(**d)` ne transmette pas ce drapeau à une action
        qui ne le connaît pas ;
      * un refus métier (`ok: false` avec une raison) doit arriver au panneau
        INTACT : `server.py` répond 400 quand une branche LÈVE, et la raison
        serait perdue ;
      * aucune de ces routes ne doit créer, modifier ni supprimer de fichier du
        projet. Ce qui est téléchargé va dans le dossier d'état de
        l'utilisateur, jamais dans ses sources.

    Rien ici ne touche au réseau : les installations réelles sont jouées par
    l'autocontrôle du module (qui télécharge depuis un `file://`) et par les
    essais manuels. Un banc dont le résultat dépend de la connexion de la
    machine n'est pas un banc.

Lancer :  python3 tests/smoke_routes_outils.py
"""

import json
import os
import sys
import tempfile
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serveur_de_test import ServeurDeTest

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def poster(client, chemin='/api/outils', entetes=None, **corps):
    """POST brut, pour ne pas dépendre des noms de paramètres du harnais."""
    requete = urllib.request.Request(
        client.base + chemin, data=json.dumps(corps).encode('utf-8'),
        headers=dict({'Content-Type': 'application/json'}, **(entetes or {})))
    try:
        with urllib.request.urlopen(requete, timeout=120) as rep:
            statut, brut = rep.status, rep.read().decode('utf-8')
    except urllib.error.HTTPError as erreur_http:
        statut, brut = erreur_http.code, erreur_http.read().decode('utf-8')
    except (urllib.error.URLError, TimeoutError) as exc:
        return 0, {'erreur': str(exc)}
    try:
        return statut, json.loads(brut)
    except ValueError:
        return statut, {'brut': brut[:400]}


def principal():
    with tempfile.TemporaryDirectory() as outils:
        with ServeurDeTest(variables={'PS_OUTILS_DIR': outils}) as srv:
            client = srv.client
            projet = Path(srv.espace())
            srv.ecrire('programme.pas', 'program x; begin end.')
            avant = sorted(str(q.relative_to(projet)) for q in projet.rglob('*'))

            # ---------------------------------------------- 1. ouverture --
            statut, corps = client.get('/api/outils')
            verif(statut == 200, 'GET /api/outils répond 200 (%d)' % statut)
            verif(corps.get('marqueur') == 'ps-4.1.0-outils',
                  'GET /api/outils rend le marqueur du module (%r)'
                  % corps.get('marqueur'))
            verif(corps.get('installe_en_root_apres_confirmation') is True
                  and corps.get('root_par_defaut') is False,
                  'les droits root doivent être annoncés comme soumis à '
                  'confirmation, et jamais accordés par défaut')
            verif(corps.get('invente_des_urls') is False,
                  'le module doit affirmer qu’il n’invente aucune URL')
            verif(all(v in ('remove', 'purge', 'autoremove', 'upgrade',
                            'dist-upgrade')
                      for v in corps.get('commandes_interdites', ())),
                  'les verbes interdits annoncés doivent être les destructifs')
            etat = corps.get('etat') or {}
            verif(etat.get('total', 0) >= 40,
                  'l’inventaire rendu par la route est trop pauvre (%r)'
                  % etat.get('total'))
            verif(isinstance(etat.get('liste'), list) and etat['liste'],
                  'la route doit rendre la liste des outils')
            verif(isinstance(corps.get('taches'), list),
                  'la route doit rendre la liste des tâches, même vide')
            chemins = etat.get('chemins') or {}
            verif(chemins.get('dossier') == outils,
                  'PS_OUTILS_DIR doit déplacer le dossier d’outils (%r)'
                  % chemins.get('dossier'))
            verif(chemins.get('dans_path') is True,
                  'le dossier d’outils doit être dans PATH du SERVEUR : sans '
                  'cela un outil installé reste « manquant » jusqu’au '
                  'redémarrage')
            verif(chemins.get('variable') == 'PS_OUTILS_DIR',
                  'la variable qui déplace le dossier doit être nommée')
            verif(any(o.get('id') == 'amont:ghidraRun'
                      or 'ghidra' in str(o.get('depot', '')).lower()
                      for o in etat['liste']),
                  'Ghidra doit apparaître dans l’inventaire rendu par la route')
            familles = {o['famille'] for o in etat['liste']}
            for attendue in ('compilateurs', 'serveurs de langage',
                             'rétro-ingénierie', 'analyse avancée'):
                verif(attendue in familles,
                      'la famille %r doit apparaître dans l’inventaire'
                      % attendue)

            # ------------------------------------------------ 2. actions --
            statut, corps = poster(client, action='capacites')
            verif(statut == 200 and corps.get('version') == '4.1.0',
                  'action=capacites rend la version du module (%r)' % corps)
            statut, corps = poster(client, action='etat', rafraichir=True)
            verif(statut == 200 and corps.get('total', 0) >= 40
                  and isinstance(corps.get('resume'), str),
                  'action=etat rend un inventaire et un résumé (%r)'
                  % corps.get('resume'))
            verif(all(o.get('version', '') == '' for o in corps['liste']),
                  'action=etat ne doit PAS lire les versions : c’est lent, et '
                  'ouvrir les paramètres ne doit pas le payer')
            statut, corps = poster(client, action='dossier')
            verif(statut == 200 and corps.get('ok') is True
                  and corps.get('dossier') == outils,
                  'action=dossier rend les chemins (%r)' % corps.get('dossier'))
            statut, corps = poster(client, action='plan',
                                   identifiants=['amont:pasls'])
            verif(statut == 200 and corps.get('ok') is True
                  and not corps.get('etapes')
                  and any('archive' in n.lower() or 'publie' in n.lower()
                          for n in corps.get('notes', [])),
                  'un outil sans publication doit être refusé AVEC la raison, '
                  'pas silencieusement ignoré : %r' % corps.get('notes'))
            statut, corps = poster(client, action='plan',
                                   identifiants=['voix:inexistante'])
            verif(statut == 200 and not corps.get('etapes')
                  and any('inconnu' in n for n in corps.get('notes', [])),
                  'un identifiant inconnu doit être nommé par la route')
            statut, corps = poster(client, action='plan', tout=False,
                                   identifiants=[])
            verif(statut == 200 and corps.get('resume'),
                  'un plan vide doit rendre un résumé lisible (%r)'
                  % corps.get('resume'))

            # --------------------------- 3. installer sans rien télécharger --
            statut, corps = poster(client, action='installer',
                                   identifiants=['amont:pasls'])
            verif(statut == 200 and corps.get('ok') is False
                  and corps.get('erreur'),
                  'installer un outil non téléchargeable doit rendre un refus '
                  'nommé, pas une tâche vide : %r' % corps)
            statut, corps = poster(client, action='installer',
                                   identifiants=['voix:inexistante'])
            verif(statut == 200 and corps.get('ok') is False,
                  'installer un identifiant inconnu doit refuser')

            # -------------------------------------- 4. suivi et arrêt --
            statut, corps = poster(client, action='suivre', sid='inexistant')
            verif(statut == 200 and corps.get('ok') is False
                  and 'inconnue' in str(corps.get('erreur', '')),
                  'suivre une tâche inconnue doit le dire (%r)' % corps)
            statut, corps = poster(client, action='arreter', sid='inexistant')
            verif(statut == 200 and corps.get('ok') is False,
                  'arrêter une tâche inconnue doit le dire')
            statut, corps = poster(client, action='taches')
            verif(statut == 200 and isinstance(corps.get('taches'), list),
                  'action=taches rend une liste')

            # ------------------------- 5. racine_autorisee est cloisonné --
            statut, corps = poster(client, action='etat',
                                   racine_autorisee=True)
            verif('racine_autorisee' not in corps,
                  'racine_autorisee ne doit pas être transmis à une action qui '
                  'ne le connaît pas')
            statut, corps = poster(client, action='plan', tout=True,
                                   racine_autorisee=False, resoudre=False)
            verif(statut == 200 and corps.get('racine_autorisee') is False,
                  'le plan doit dire que les droits root ne sont pas autorisés')
            apt = [e for e in corps.get('etapes', []) if e.get('voie') == 'apt']
            verif(len(apt) <= 1,
                  'tous les paquets apt doivent tenir en une étape, donc une '
                  'seule demande de mot de passe (%d)' % len(apt))
            for etape in corps.get('etapes', []):
                verif(bool(etape.get('commande_texte'))
                      and bool(etape.get('commande_manuelle')),
                      'chaque étape doit porter sa commande exacte et son '
                      'équivalent manuel : %r' % etape.get('voie'))
                verif(not any(m in etape.get('commande', [])
                              for m in ('remove', 'purge', 'autoremove',
                                        'upgrade')),
                      'une étape du plan ne doit jamais contenir un verbe '
                      'destructeur : %r' % etape.get('commande'))
                if etape.get('voie') == 'apt':
                    verif(etape.get('racine') is True
                          and etape.get('executable') is False,
                          'une étape apt non autorisée doit être marquée non '
                          'exécutable : %r' % etape)

            # ------------------------------- 6. action inconnue : 400 nommé --
            statut, corps = poster(client, action='detruire_le_systeme')
            verif(statut == 400 and 'inconnue' in str(corps.get('error', '')),
                  'une action inconnue doit rendre 400 et nommer l’action '
                  '(%d, %r)' % (statut, corps))

            # -------------------------------------- 7. la garde locale --
            statut, corps = poster(client, action='etat',
                                   entetes={'Origin': 'https://ailleurs.test'})
            verif(statut in (403, 400) or corps.get('error'),
                  'un Origin étranger doit être refusé sur /api/outils : c’est '
                  'la seule garde d’une route qui peut lancer pkexec (%d, %r)'
                  % (statut, str(corps)[:120]))
            statut, corps = poster(client, action='installer', tout=True,
                                   racine_autorisee=True,
                                   entetes={'Origin': 'https://ailleurs.test'})
            verif(statut in (403, 400) or corps.get('error'),
                  'un Origin étranger ne doit JAMAIS pouvoir déclencher une '
                  'installation en root (%d, %r)' % (statut, str(corps)[:120]))

            # ------------------------- 8. le projet n'est pas touché --
            apres = sorted(str(q.relative_to(projet)) for q in projet.rglob('*'))
            verif(avant == apres,
                  'ces routes ne doivent rien écrire dans le projet : %r'
                  % [x for x in apres if x not in avant])
            verif(Path(outils).exists(),
                  'le dossier d’outils doit exister, hors du projet')


def main():
    try:
        principal()
    except Exception as exc:
        ECHECS.append('le banc a levé %s : %s' % (type(exc).__name__, exc))
        import traceback
        traceback.print_exc()
    print('smoke_routes_outils : %d contrôles, %d échec(s)'
          % (OK + len(ECHECS), len(ECHECS)))
    for echec in ECHECS:
        print('  ÉCHEC : ' + echec)
    return 1 if ECHECS else 0


if __name__ == '__main__':
    sys.exit(main())
