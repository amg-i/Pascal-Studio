#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Banc de bout en bout : les routes /api/re servies par le VRAI serveur.

Pourquoi ce banc existe à côté de l'autocontrôle de retro.py
------------------------------------------------------------
    `python3 retro.py` exerce la façade en appelant ses fonctions. Ce n'est pas
    ce que fait l'interface : elle envoie `POST /api/re` avec un JSON, et lit une
    réponse JSON. Quatre choses ne sont visibles qu'ici :

      * la garde `local_auth_allowed()` doit rejeter un Origin étranger sur ces
        routes. C'est la seule garde de ces routes : contrairement au panneau dev
        web, le confinement à la racine du projet ne s'applique PAS, parce qu'un
        binaire à analyser n'est presque jamais dans le projet. Si la garde
        locale saute, n'importe quelle page web ouverte dans un navigateur peut
        faire lire au serveur des octets arbitraires du disque ;
      * le dispatch est écrit à la main, branche par branche : une action mal
        orthographiée ici renverrait « Action de rétro-ingénierie inconnue »
        alors que la façade, elle, fonctionne ;
      * un refus métier de la façade (`ok: false`, avec `erreur` et `remede`)
        doit arriver au panneau INTACT. `server.py` répond 400 avec `{'error': …}`
        quand une branche LÈVE : si le dispatch levait au lieu de rendre le
        refus, le remède serait perdu ;
      * les bornes de la façade doivent tenir depuis la route : une requête qui
        demande 10**9 octets de vidage doit être bornée ET LE DIRE.

    Ce banc vérifie aussi deux propriétés de conception :
      * aucune route ne crée, ne modifie ni ne supprime de fichier du projet ;
      * aucun binaire analysé n'est exécuté. La fixture contient un script shell
      exécutable : si une route l'exécutait, il laisserait une trace.

Lancer :  python3 tests/smoke_routes_re.py
"""

import json
import os
import struct
import sys
from pathlib import Path
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from serveur_de_test import ServeurDeTest, dependance

OK = 0
ECHECS = []


def verif(condition, titre):
    global OK
    if condition:
        OK += 1
    else:
        ECHECS.append(titre)
        sys.stderr.write('ÉCHEC : %s\n' % titre)


def elf_minimal():
    """Un ELF64 petit-boutien minimal, synthétisé octet par octet.

    Pas un fichier « qui a l'extension .elf » : la façade lit e_ident et
    reconnaît la famille par signature, donc une fixture fausse ferait échouer le
    banc sans faute du produit.
    """
    entete = b'\x7fELF'                       # e_ident[0:4]
    entete += b'\x02'                         # EI_CLASS = ELFCLASS64
    entete += b'\x01'                         # EI_DATA = petit-boutien
    entete += b'\x01'                         # EI_VERSION
    entete += b'\x00' * 9                     # EI_OSABI … e_ident[15]
    entete += struct.pack('<HHIQQQIHHHHHH',
                          2,                    # e_type = ET_EXEC
                          0x3e,                 # e_machine = x86-64
                          1,                    # e_version
                          0x401000,             # e_entry
                          0,                    # e_phoff
                          0,                    # e_shoff
                          0,                    # e_flags
                          64,                   # e_ehsize
                          0, 0, 0, 0, 0)
    # Du contenu reconnaissable, dont une chaîne longue assez pour être rendue.
    corps = b'\x90' * 64 + b'PascalStudioRetroBancFixture\x00' + b'\xcc' * 64
    return entete + corps


def pe_minimal(dossier):
    """Un PE minimal, produit par le synthétiseur de retro_binaires.

    Écrire ici un en-tête PE à la main avec struct.pack serait une seconde
    source de vérité : la première tentative de ce banc a produit une chaîne de
    format de 38 champs pour 31 valeurs, et le banc a échoué sur sa propre
    fixture au lieu de tester le produit. Le synthétiseur du module est déjà
    vérifié par son propre autocontrôle, donc la fixture est juste par
    construction.
    """
    import retro_binaires
    chemin, _attendu = retro_binaires._synthese_pe64(Path(dossier))
    return chemin


def construire(srv):
    """Les fixtures du banc, dans l'espace de travail du serveur."""
    srv.ecrire('app.elf', elf_minimal(), mode='wb')
    chemin_pe = pe_minimal(srv.espace())
    with open(chemin_pe, 'rb') as fichier:
        srv.ecrire('app.exe', fichier.read(), mode='wb')
    srv.ecrire('vide.bin', b'', mode='wb')
    # Un script exécutable : si une route l'exécutait, marqueur.txt apparaîtrait.
    srv.ecrire('piege.sh', '#!/bin/sh\ntouch marqueur.txt\n', mode='w')
    os.chmod(os.path.join(srv.espace(), 'piege.sh'), 0o755)



def poster(client, **corps):
    """POST /api/re avec un corps quelconque.

    `Client.post(self, chemin, entetes=None, **corps)` lie son premier
    paramètre au nom « chemin » — qui est aussi une clef du corps de ces routes.
    Python refuse alors l'appel (« multiple values for argument 'chemin' »).
    Plutôt que de modifier un harnais partagé par trois autres bancs, celui-ci
    construit ses requêtes directement, et garde le même contrat de retour :
    (statut, corps_json).
    """
    import urllib.error
    import urllib.request
    requete = urllib.request.Request(
        client.base + '/api/re',
        data=json.dumps(corps).encode('utf-8'),
        headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(requete, timeout=60) as rep:
            statut, brut = rep.status, rep.read().decode('utf-8')
    except urllib.error.HTTPError as erreur_http:
        statut, brut = erreur_http.code, erreur_http.read().decode('utf-8')
    try:
        return statut, json.loads(brut)
    except ValueError:
        return statut, {'brut': brut[:400]}


def poster_avec_origin(client, origin, **corps):
    """Le même POST, avec un Origin étranger : la garde locale doit refuser."""
    import urllib.error
    import urllib.request
    requete = urllib.request.Request(
        client.base + '/api/re',
        data=json.dumps(corps).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'Origin': origin})
    try:
        with urllib.request.urlopen(requete, timeout=20) as rep:
            statut, brut = rep.status, rep.read().decode('utf-8')
    except urllib.error.HTTPError as erreur_http:
        statut, brut = erreur_http.code, erreur_http.read().decode('utf-8')
    try:
        return statut, json.loads(brut)
    except ValueError:
        return statut, {'brut': brut[:400]}

def principal():
    if not dependance('objdump'):
        sys.stderr.write('objdump absent : le désassemblage ne peut pas être '
                         'testé ici.\n')
    with ServeurDeTest() as srv:
        construire(srv)
        client = srv.client

        # ------------------------------------------------------ 1. capacités --
        statut, corps = client.get('/api/re')
        verif(statut == 200, 'GET /api/re répond 200 (%d)' % statut)
        verif(corps.get('ok') is True, 'GET /api/re rend ok=True')
        verif(isinstance(corps.get('operations'), list)
              and len(corps['operations']) >= 10,
              'GET /api/re annonce au moins dix opérations Ghidra (%r)'
              % (corps.get('operations') or [])[:4])
        verif(corps.get('nombre_widgets', 0) >= 15,
              'GET /api/re annonce au moins quinze widgets')
        verif(corps.get('fiches', 0) >= 25,
              'GET /api/re annonce au moins vingt-cinq fiches')
        verif(corps.get('execute_des_binaires') is False,
              'GET /api/re déclare qu’aucun binaire n’est exécuté')
        verif('etat' in corps, 'GET /api/re inclut l’état des tâches')
        # Sur cette machine Ghidra est absent : le panneau doit le dire ET dire
        # ce qui reste possible. C'est la propriété centrale de R6.
        if not corps.get('pret_pour_ghidra'):
            verif(bool(corps.get('manquants')),
                  'Ghidra absent mais rien ne nomme ce qui manque')
            verif(bool(corps.get('sans_ghidra')),
                  'Ghidra absent mais aucune capacité de repli n’est annoncée')
            ghidra = corps.get('ghidra') or {}
            verif(bool(ghidra.get('raison')),
                  'Ghidra absent mais la raison n’est pas donnée')
            verif(len(ghidra.get('installations_commandes') or ()) >= 5,
                  'Ghidra absent mais les voies d’installation ne sont pas '
                  'rendues (%d)' % len(ghidra.get('installations_commandes') or ()))

        # ------------------------------------------- 2. garde d'authentification
        # Une page web ouverte dans un navigateur peut envoyer un POST à
        # 127.0.0.1 : sans la garde d'Origin, elle ferait lire au serveur des
        # octets arbitraires du disque. Ces routes ne sont PAS confinées au
        # projet, donc la garde locale est la seule protection.
        # Un Origin étranger : ces routes ne sont PAS confinées au projet (un
        # binaire à analyser n'y est presque jamais), donc la garde locale est
        # la seule protection. Sans elle, n'importe quelle page web ouverte dans
        # un navigateur ferait lire au serveur des octets arbitraires du disque.
        statut, corps = poster_avec_origin(client, 'https://evil.example',
                                           action='analyser',
                                           chemin='/etc/passwd')
        verif(statut in (400, 403),
              'un Origin étranger est refusé sur /api/re (%d)' % statut)
        verif('passwd' not in json.dumps(corps)[:4000],
              'aucun contenu de /etc/passwd n’est rendu à un Origin étranger')

        # -------------------------------------------------------- 3. analyse --
        statut, corps = poster(client, action='analyser', chemin='app.elf')
        verif(statut == 200, 'analyser répond 200 (%d)' % statut)
        verif(corps.get('ok') is True, 'analyser rend ok=True (%r)'
              % corps.get('erreur'))
        verif(corps.get('famille') == 'elf',
              'analyser reconnaît un ELF (%r)' % corps.get('famille'))
        verif(bool(corps.get('sections')) or bool(corps.get('notes')),
              'analyser rend des sections ou dit pourquoi il n’y en a pas')

        # Le confinement au projet NE s'applique pas : un binaire hors du projet
        # doit être analysable. C'est voulu et c'est ce qui distingue ces routes
        # de celles du panneau dev web.
        statut, corps = poster(client, action='analyser', chemin=sys.executable)
        verif(statut == 200 and corps.get('ok') is True,
              'un binaire hors du projet est analysable (%r)' % corps.get('erreur'))
        verif(corps.get('famille') == 'elf',
              'l’interpréteur Python est reconnu comme ELF (%r)'
              % corps.get('famille'))

        # ---------------------------------------------------- 4. les refus ----
        statut, corps = poster(client, action='analyser', chemin='absent.bin')
        verif(corps.get('ok') is False, 'un fichier absent est refusé')
        verif('n’existe pas' in str(corps.get('erreur', '')),
              'le refus d’un fichier absent nomme sa cause (%r)' % corps.get('erreur'))
        # LE point critique : le refus doit arriver INTACT, avec son remède. Si
        # le dispatch levait, server.py répondrait {'error': …} sans remède.
        verif(bool(corps.get('remede')),
              'le refus d’un fichier absent donne un remède (%r)' % corps)

        statut, corps = poster(client, action='analyser', chemin='')
        verif(corps.get('ok') is False, 'un chemin vide est refusé')

        statut, corps = poster(client, action='analyser', chemin='.')
        verif(corps.get('ok') is False, 'un répertoire est refusé')
        verif('répertoire' in str(corps.get('erreur', '')),
              'le refus d’un répertoire le dit (%r)' % corps.get('erreur'))

        statut, corps = poster(client, action='analyser', chemin='vide.bin')
        verif(corps.get('ok') is False, 'un fichier vide est refusé')
        verif('vide' in str(corps.get('erreur', '')),
              'le refus d’un fichier vide le dit (%r)' % corps.get('erreur'))

        statut, corps = poster(client, action='action-inexistante')
        verif(statut == 400,
              'une action inconnue répond 400 (%d)' % statut)
        verif('inconnue' in json.dumps(corps, ensure_ascii=False),
              'une action inconnue est nommée dans l’erreur (%r)' % corps)

        # --------------------------------------------- 5. les bornes tiennent --
        statut, corps = poster(client, action='vidage', chemin='app.elf', longueur=10 ** 9)
        verif(statut == 200, 'un vidage démesuré répond 200 (%d)' % statut)
        verif(corps.get('ok') is not False,
              'un vidage démesuré est borné, pas refusé (%r)' % corps.get('erreur'))
        notes = ' '.join(str(n) for n in (corps.get('notes') or []))
        verif('longueur' in notes,
              'un vidage borné LE DIT dans ses notes (%r)' % notes)

        statut, corps = poster(client, action='chaines', chemin='app.elf', minimum='pas-un-nombre')
        verif(corps.get('ok') is not False,
              'un minimum invalide est remplacé, pas refusé')
        verif('entier' in ' '.join(str(n) for n in (corps.get('notes') or []))
              or 'minimum' in ' '.join(str(n) for n in (corps.get('notes') or [])),
              'un minimum invalide est annoncé dans les notes (%r)'
              % corps.get('notes'))

        # ------------------------------------------------- 6. famille et PE ----
        statut, corps = poster(client, action='famille', chemin='app.exe')
        verif(corps.get('famille') == 'pe',
              'famille reconnaît un PE (%r)' % corps.get('famille'))
        statut, corps = poster(client, action='famille', donnees='\\x7fELF\\x02\\x01\\x01\\x00')
        verif(corps.get('ok') is not False,
              'famille accepte des octets passés en ligne (%r)' % corps.get('erreur'))

        # --------------------------------------------------- 7. les chaînes ----
        statut, corps = poster(client, action='chaines', chemin='app.elf', minimum=8)
        verif(corps.get('ok') is True, 'chaines rend ok=True (%r)' % corps.get('erreur'))
        trouvees = corps.get('chaines') or []
        verif(any('PascalStudioRetro' in str(c) for c in trouvees),
              'la chaîne de la fixture est trouvée (%d chaînes)' % len(trouvees))
        verif(corps.get('octets_lus') is not None,
              'chaines rend le nombre d’octets parcourus : sans lui, une liste '
              'vide et une lecture arrêtée se ressemblent')

        # ---------------------------------------------------- 8. les symboles --
        statut, corps = poster(client, action='symboles', chemin='app.elf')
        verif(isinstance(corps, dict), 'symboles rend un objet JSON')
        if not (corps.get('symboles') or []):
            verif(bool(corps.get('notes')) or bool(corps.get('erreur'))
                  or corps.get('ok') is True,
                  'l’absence de symboles est expliquée, pas silencieuse')

        # ------------------------------------------------- 9. le désassemblage --
        if dependance('objdump'):
            statut, corps = poster(client, action='desassembler', chemin='app.elf', lignes=20, syntaxe='intel')
            verif(isinstance(corps, dict), 'desassembler rend un objet JSON')
            if corps.get('ok') is False:
                verif(bool(corps.get('erreur')),
                      'un échec de désassemblage est nommé')
            else:
                # « -M intel » n'existe que sur x86. Sur une autre architecture
                # le module réessaie sans l'option et LE DIT : la substitution
                # doit être visible, sinon un AT&T passe pour de l'Intel.
                rendu = json.dumps(corps, ensure_ascii=False)
                verif('syntaxe' in rendu,
                      'le désassemblage annonce la syntaxe réellement rendue')
        else:
            verif(True, 'objdump absent : désassemblage non testé')

        statut, corps = poster(client, action='desassembler', chemin='app.elf', syntaxe='mips')
        verif(corps.get('ok') is False,
              'une syntaxe inconnue est refusée (%r)' % corps)

        # --------------------------------------------- 10. Ghidra, absent ici --
        statut, corps = poster(client, action='ghidra-capacites')
        verif(isinstance(corps, dict) and 'ok' in corps,
              'ghidra-capacites rend un état')
        if not (corps.get('pret')):
            verif(bool(corps.get('raison')),
                  'le pont non prêt nomme sa raison')

        statut, corps = poster(client, action='ghidra-lancer', operation='operation-inexistante', chemin='app.elf')
        verif(corps.get('ok') is False,
              'une opération Ghidra inconnue est refusée')
        verif(bool(corps.get('remede')),
              'le refus d’une opération inconnue donne un remède')

        statut, corps = poster(client, action='ghidra-lancer', operation='info')
        verif(corps.get('ok') is False,
              'ghidra-lancer sans chemin est refusé')

        # L'identifiant sert à construire un chemin : « .. » doit être refusé.
        statut, corps = poster(client, action='ghidra-resultat', identifiant='../../etc/passwd')
        verif(corps.get('ok') is False,
              'un identifiant de tâche contenant « .. » est refusé')
        verif('interdits' in str(corps.get('erreur', '')),
              'le refus d’un identifiant nomme le problème (%r)' % corps.get('erreur'))

        statut, corps = poster(client, action='ghidra-taches')
        verif(corps.get('ok') is True and isinstance(corps.get('taches'), list),
              'ghidra-taches rend une liste')

        # --------------------------------------------------- 11. le postScript --
        statut, corps = poster(client, action='postscript')
        verif(corps.get('ok') is True, 'postscript rend ok=True')
        verif(corps.get('octets', 0) > 1000,
              'le postScript est complet (%d octets)' % corps.get('octets', 0))
        verif(bool(corps.get('marqueur_debut')) and bool(corps.get('marqueur_fin')),
              'le postScript rend ses deux marqueurs : sans eux, le lecteur ne '
              'peut pas isoler le JSON du bruit de Ghidra')

        # --------------------------------------------- 12. fiches et widgets ----
        statut, corps = poster(client, action='fiches')
        verif(isinstance(corps, (dict, list)), 'fiches rend du JSON')
        liste = corps.get('fiches') if isinstance(corps, dict) else corps
        verif(isinstance(liste, list) and len(liste) >= 25,
              'fiches rend au moins vingt-cinq fiches (%d)' % len(liste or []))

        statut, corps = poster(client, action='fiche', identifiant='elf-en-tete')
        verif(corps.get('ok') is True, 'la fiche elf-en-tete est rendue (%r)'
              % corps.get('erreur'))
        statut, corps = poster(client, action='fiche', identifiant='fiche-inexistante')
        verif(corps.get('ok') is False, 'une fiche inexistante est refusée')
        verif('n’existe pas' in str(corps.get('erreur', '')),
              'le refus d’une fiche inexistante la nomme')

        statut, corps = poster(client, action='chercher', motif='ghidra')
        verif(isinstance(corps, (dict, list)), 'chercher rend du JSON')

        statut, corps = poster(client, action='categories')
        verif(isinstance(corps, (dict, list)), 'categories rend du JSON')

        statut, corps = poster(client, action='widgets')
        verif(corps.get('ok') is True, 'widgets rend ok=True')
        verif(len(corps.get('widgets') or []) >= 15,
              'widgets rend les quinze widgets (%d)' % len(corps.get('widgets') or []))

        # Un widget s'exécute sans toucher au disque.
        statut, corps = poster(client, action='widget', identifiant='convertisseur', entrees={'valeur': '0x41424344', 'largeur': 4,
                                             'boutisme': 'inverse'})
        verif(corps.get('ok') is True,
              'le widget convertisseur s’exécute (%r)' % corps.get('erreur'))
        resultat = corps.get('resultat') or {}
        verif(resultat.get('boutisme_inverse') == '0x44434241',
              'l’inversion de boutisme est exacte (%r)'
              % resultat.get('boutisme_inverse'))
        # Le widget rend AUSSI les deux ordres d'octets : c'est ce qui permet de
        # vérifier l'inversion au lieu de la croire.
        verif(resultat.get('octets_petit_boutisme') == '44 43 42 41',
              'les octets petit-boutistes sont rendus (%r)'
              % resultat.get('octets_petit_boutisme'))

        # La valeur réellement protégée d'un PE : 0x60b contient ASLR et DEP,
        # 0x4160 ne contient NI l'un NI l'autre. C'est le fait faux que
        # l'autocontrôle de retro_fiches a contredit, donc il est vérifié ici
        # jusqu'au bout de la chaîne HTTP.
        statut, corps = poster(client, action='widget', identifiant='masques', entrees={'valeur': '0x60b', 'famille': 'dll_pe'})
        bits = (corps.get('resultat') or {}).get('bits') or []
        verif('DYNAMIC_BASE' in bits and 'NX_COMPAT' in bits,
              '0x60b contient ASLR et DEP (%r)' % bits)
        statut, corps = poster(client, action='widget', identifiant='masques', entrees={'valeur': '0x4160', 'famille': 'dll_pe'})
        bits = (corps.get('resultat') or {}).get('bits') or []
        verif('DYNAMIC_BASE' not in bits,
              '0x4160 ne contient PAS ASLR : l’affirmer était le fait faux (%r)'
              % bits)

        statut, corps = poster(client, action='widget', identifiant='widget-inexistant', entrees={})
        verif(corps.get('ok') is False, 'un widget inexistant est refusé')
        statut, corps = poster(client, action='widget', identifiant='convertisseur', entrees='pas-un-objet')
        verif(corps.get('ok') is False,
              'des entrées de widget non-objet sont refusées')

        # ------------------------------------- 13. aucune écriture, aucune exécution
        marqueur = os.path.join(srv.espace(), 'marqueur.txt')
        verif(not os.path.exists(marqueur),
              'aucun binaire analysé n’a été exécuté : le piège n’a pas laissé '
              'de trace')
        # Le piège lui-même doit être analysable sans être exécuté.
        statut, corps = poster(client, action='analyser', chemin='piege.sh')
        verif(isinstance(corps, dict), 'un script exécutable est analysable')
        verif(not os.path.exists(marqueur),
              'analyser un script exécutable ne l’exécute pas')
        noms = [n for n in os.listdir(srv.espace())]
        verif('marqueur.txt' not in noms,
              'aucune route n’a créé de fichier dans le projet (%r)' % sorted(noms))

    return 0 if not ECHECS else 1


def main():
    depart = time.monotonic()
    code = principal()
    sys.stderr.write('\nsmoke_routes_re : %d contrôles, %d échec(s), %.1f s\n'
                     % (OK + len(ECHECS), len(ECHECS), time.monotonic() - depart))
    if ECHECS:
        for echec in ECHECS:
            sys.stderr.write('  - %s\n' % echec)
    return code


if __name__ == '__main__':
    sys.exit(main())
