# -*- coding: utf-8 -*-
"""Tests Shakespeare. L'exemple travaillé de la spécification doit donner
exactement « -2<Hamlet+2> » : c'est la cible d'acceptation principale.

Lancer :  python3 tests/smoke_shakespeare.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import langages_esoteriques as E   # noqa: E402

OK = 0; N = 0
def verifier(titre, obtenu, attendu):
    global OK, N
    N += 1
    bon = obtenu == attendu
    OK += bon
    print('  %-54s %s' % (titre, 'CONFORME' if bon else 'DIFFERENT'))
    if not bon:
        print('      obtenu  : %r' % (obtenu,))
        print('      attendu : %r' % (attendu,))

def lancer(code, entree='', limite=20000):
    return E.Shakespeare(code, entree=entree).executer(limite=limite)

print('=== exemple travaille de la specification ===')
# « Thou art a vile coward! » -> l'INTERLOCUTEUR (Juliet) vaut -1 * 2^1 = -2.
# « Open thy heart! » imprime la valeur NUMERIQUE de l'interlocuteur : -2.
# Puis Juliet dit à Romeo : « as lovely as the sum of Hamlet and a brave tree »
# -> Romeo = Hamlet + (1 * 2^1) = Hamlet + 2. Hamlet n'a jamais été assigné,
# donc il vaut 0 et la sortie numérique est 2. La spec écrit « <Hamlet+2> »
# parce qu'elle laisse Hamlet symbolique.
SPEC = """Example Title.

Romeo, a young man with a remarkable patience.
Juliet, a likewise young woman of remarkable grace.
Hamlet, the flatterer of Andersen Insulting A/S.

Act I: Testing.

Scene I: The test.

[Enter Romeo and Juliet]

Romeo:
 Thou art a vile coward!  Open thy heart!
Juliet:
 You are as lovely as the sum of Hamlet and a brave tree.  Open thy heart.

[Exeunt]
"""
r = lancer(SPEC)
verifier('sortie exacte de l’exemple de la spec', r['sortie'], '-2\n2\n')

print()
print('=== constantes : le nom donne le signe, chaque adjectif double ===')
def constante(morceau):
    m = E.Shakespeare('')
    m.personnages = {'Hamlet': ''}; m.valeurs = {'Hamlet': 0}
    m.sur_scene = ['Romeo', 'Hamlet']; m._locuteur = 'Romeo'
    return m._constante(morceau, 1)

verifier('« a vile coward » = -2', constante('a vile coward'), -2)
verifier('« a brave tree » = +2', constante('a brave tree'), 2)
verifier('« a tree » = +1 (aucun adjectif)', constante('a tree'), 1)
verifier('« a coward » = -1', constante('a coward'), -1)
verifier('« your fat little stuffed codpiece » = -8 (3 adjectifs)',
         constante('your fat little stuffed codpiece'), -8)
verifier('« a huge green peaceful tree » = +8', constante('a huge green peaceful tree'), 8)
verifier('« the sweetest reddest rose » = +4 (superlatifs comptés)',
         constante('the sweetest reddest rose'), 4)
verifier('« his horse » = +1', constante('his horse'), 1)

print()
print('=== operations ===')
def operation(texte, valeurs=None):
    m = E.Shakespeare('')
    m.personnages = {'Romeo': '', 'Juliet': '', 'Hamlet': ''}
    m.valeurs = valeurs or {'Romeo': 0, 'Juliet': 0, 'Hamlet': 0}
    m.sur_scene = ['Romeo', 'Juliet']; m._locuteur = 'Romeo'
    return m._valeur_expression(texte, 1)

verifier('the sum of a tree and a horse = 1+1 = 2',
         operation('the sum of a tree and a horse'), 2)
verifier('the difference between a tree and a coward = 1-(-1) = 2',
         operation('the difference between a tree and a coward'), 2)
verifier('the product of a brave tree and a huge tree = 2*8 = 16',
         operation('the product of a brave tree and a huge green peaceful tree'), 16)
verifier('the square of a brave tree = 4', operation('the square of a brave tree'), 4)
verifier('the cube of a brave tree = 8', operation('the cube of a brave tree'), 8)
verifier('the quotient between a huge tree and a brave tree = 8/2 = 4',
         operation('the quotient between a huge green peaceful tree and a brave tree'), 4)
verifier('« yourself » vaut l’interlocuteur (Juliet=7)',
         operation('yourself', {'Romeo': 0, 'Juliet': 7, 'Hamlet': 0}), 7)
verifier('simile « as lovely as X » ne change rien',
         operation('as lovely as the sum of a tree and a horse'), 2)
verifier('opérations imbriquées : sum of a tree and the product of a tree and a horse',
         operation('the sum of a tree and the product of a tree and a horse'), 2)

print()
print('=== scene, entrees/sorties, E/S ===')
r = lancer("""Pièce.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Romeo:
 Thou art as good as a big big big tree! Speak thy mind!

[Exeunt]
""")
verifier('Speak your mind imprime l’interlocuteur en caractère (8 -> chr(8))',
         r['sortie'], chr(8))

r = lancer("""Pièce.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Juliet:
 Listen to thy heart!
Romeo:
 Thou art as good as the sum of myself and a brave tree! Open thy heart!

[Exeunt]
""", entree='40\n')
# Juliet lit 40 dans ROMEO, puis Romeo dit « myself » (= Romeo = 40) + 2 = 42,
# affecté à Juliet, qui est imprimée.
verifier('Listen to your heart lit un nombre, puis « myself » + 2', r['sortie'], '42\n')

r = lancer("""Pièce.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Juliet:
 Open thy mind!
Romeo:
 Thou art as good as the sum of myself and a tree! Speak thy mind!

[Exeunt]
""", entree='A')
verifier('Open your mind lit un caractère (A=65), « myself »+1 -> 66 = B',
         r['sortie'], 'B')

print()
print('=== boucle par saut de scene ===')
BOUCLE = """Compte.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Départ.

[Enter Romeo and Juliet]

Romeo:
 Thou art as good as a brave tree!

Scene II: Boucle.

Romeo:
 Open thy heart!
 Thou art as good as the difference between yourself and a tree!
Juliet:
 Am I better than you?
Romeo:
 If so, let us return to scene II.

[Exeunt]
"""
r = lancer(BOUCLE)
verifier('saut de scène : 2, 1 puis arrêt', r['sortie'], '2\n1\n')

verifier('« yourself » = l’interlocuteur, pas le locuteur',
         operation('the sum of yourself and a tree',
                   {'Romeo': 100, 'Juliet': 5, 'Hamlet': 0}), 6)

print()
print('=== pile Remember / Recall ===')
r = lancer("""Pile.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Romeo:
 Thou art as good as a big tree!
 Remember!
 Thou art as good as a big big big tree!
 Open thy heart!
 Recall!
 Open thy heart!

[Exeunt]
""")
verifier('Remember empile 2, puis 8, Recall restaure 2', r['sortie'], '8\n2\n')

print()
print('=== detection d erreurs ===')
cas = [('aucun personnage présenté', 'Titre.\n\nAct I: Un.\n\nScene I: Une.\n'),
       ('personnage jamais présenté', """Titre.

Romeo, a young man.

Act I: Un.

Scene I: Une.

[Enter Romeo and Hamlet]
"""),
       ('trois personnages sur scène', """Titre.

Romeo, a young man.
Juliet, a young woman.
Hamlet, a man.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]
[Enter Hamlet]
"""),
       ('réplique sans interlocuteur', """Titre.

Romeo, a young man.

Act I: Un.

Scene I: Une.

[Enter Romeo]

Romeo:
 Speak thy mind!
"""),
       ('nom hors lexique', """Titre.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Romeo:
 Thou art a zzzblork!
"""),
       ('scène introuvable', """Titre.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Romeo:
 Let us proceed to scene XVII.
"""),
       ('réplique non reconnue', """Titre.

Romeo, a young man.
Juliet, a young woman.

Act I: Un.

Scene I: Une.

[Enter Romeo and Juliet]

Romeo:
 Danse avec moi!
"""),
       ('aucune scène', 'Titre.\n\nRomeo, a young man.\n')]
detectes = 0
for titre, code in cas:
    r = lancer(code)
    msgs = [d['message'] for d in r['diagnostics'] if d['severity'] == 'error']
    if msgs: detectes += 1
    print('  %-32s etat=%-7s %s' % (titre, r['state'], (msgs[:1] or ['AUCUN'])[0][:64]))

print()
print('%d/%d verifications conformes ; %d/%d erreurs detectees'
      % (OK, N, detectes, len(cas)))
sys.exit(0 if OK == N and detectes == len(cas) else 1)
