/* Banc des vues déléguées (4.3.0) — vues-studio.js.
 *
 * Ce que ce banc vérifie, et pourquoi chaque contrôle existe :
 *
 *   - LES VIGNETTES SONT DANS LA BARRE D'ONGLETS DU BUNDLE, pas dans une barre
 *     ajoutée à côté. C'est l'objet de la demande : le navigateur et les
 *     panneaux doivent s'ouvrir « comme un onglet ». Le banc construit la
 *     structure réelle du bundle (div.tabbar > div.tab … div.ps-onglets-host >
 *     div.tabbar-fill) et vérifie que l'hôte est bien trouvé et rempli.
 *   - LA ZONE NE COUVRE NI LA BARRE D'ONGLETS NI LA BARRE D'ACTIVITÉ. Son `top`
 *     est la SOMME MESURÉE des hauteurs de .tabbar et .breadcrumb : un décalage
 *     deviné en pixels laisserait voir l'éditeur, ou masquerait les onglets.
 *   - LA BARRE LATÉRALE EST MASQUÉE EN MODE PLEIN, LA BARRE D'ACTIVITÉ JAMAIS.
 *     C'est la différence entre un panneau qui passe devant les fichiers et un
 *     panneau qui piège l'utilisateur : le bouton qui le referme vit dans la
 *     barre d'activité.
 *   - CLIQUER SUR UN ONGLET DE FICHIER MASQUE LA VUE SANS LA DÉTRUIRE. Le noeud
 *     reste attaché : un <webview> détaché du DOM est détruit par Electron, donc
 *     « économiser » en détachant ferait perdre la page en cours.
 *   - LE SPLITTING : plusieurs colonnes, un séparateur entre deux, et un
 *     glisser qui répartit la largeur sans jamais descendre sous le plancher.
 *   - LE MODE PARTAGÉ ajoute la classe qui fait rétrécir l'éditeur. Monaco est
 *     créé avec automaticLayout, donc il se redessine seul ; ce script ne doit
 *     JAMAIS toucher à l'éditeur, et le banc vérifie qu'il ne le fait pas.
 *   - UN SEUL OBSERVATEUR via ps-hotes.js, et un repli qui observe quand même
 *     quand PSHotes est absent — sinon les bancs qui jouent ce script seul ne
 *     mesureraient rien.
 *
 * Lancer :  node tests/smoke_vues_studio.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const H = require('./harnais-dom.js');

const ICI = __dirname;
const SCRIPT = path.join(ICI, '..', 'vues-studio.js');
const CSS = path.join(ICI, '..', 'vues-studio.css');
const source = fs.readFileSync(SCRIPT, 'utf8');
const feuilles = fs.readFileSync(CSS, 'utf8');

let OK = 0;
let N = 0;
const echecs = [];

function serie(v) {
  const brut = JSON.stringify(v);
  return brut === undefined ? String(v) : brut;
}
function verifier(titre, obtenu, attendu) {
  N += 1;
  if (serie(obtenu) === serie(attendu)) OK += 1;
  else echecs.push(titre + '\n      obtenu  : ' + serie(obtenu).slice(0, 260)
    + '\n      attendu : ' + serie(attendu).slice(0, 260));
}
function vrai(titre, condition) { verifier(titre, !!condition, true); }

/* Le document tel que le bundle le produit. Les hauteurs sont posées en style
 * parce que le harnais les lit là : c'est ce que mesure decalageHaut(). */
function construireApplication(opts) {
  opts = opts || {};
  const harnais = H.creerDocument();
  const document = harnais.document;

  const corps = document.createElement('div');
  corps.className = 'body';

  const activite = document.createElement('nav');
  activite.className = 'activitybar';
  const boutonRe = document.createElement('button');
  boutonRe.className = 'active';
  boutonRe.setAttribute('title', 'Rétro-ingénierie');
  activite.appendChild(boutonRe);

  const laterale = document.createElement('aside');
  laterale.className = 'sidebar';
  const hoteRe = document.createElement('div');
  hoteRe.className = 'ps-re-host';
  laterale.appendChild(hoteRe);

  const principal = document.createElement('main');
  principal.className = 'studio-main';

  const barre = document.createElement('div');
  barre.className = 'tabbar';
  barre.style.height = '36px';
  const ongletFichier = document.createElement('div');
  ongletFichier.className = 'tab' + (opts.ongletFichierActif ? ' active' : '');
  ongletFichier.setAttribute('data-path', 'main.pas');
  const ongletApercu = document.createElement('div');
  ongletApercu.className = 'tab';
  const hoteOnglets = document.createElement('div');
  hoteOnglets.className = 'ps-onglets-host';
  hoteOnglets.setAttribute('data-marqueur', 'ps-4.3.0-interface');
  const remplissage = document.createElement('div');
  remplissage.className = 'tabbar-fill';
  barre.append(ongletFichier, ongletApercu, hoteOnglets, remplissage);

  const ariane = document.createElement('div');
  ariane.className = 'breadcrumb';
  ariane.style.height = '22px';

  const editeur = document.createElement('div');
  editeur.className = 'editor-and-details';
  const wrap = document.createElement('div');
  wrap.className = 'editor-wrap';
  editeur.appendChild(wrap);

  principal.append(barre, ariane, editeur);
  corps.append(activite, opts.sansLaterale ? document.createElement('span') : laterale, principal);
  document.body.appendChild(corps);
  harnais.rafraichir();
  return { harnais, document, activite, laterale, principal, barre, ariane,
    hoteOnglets, ongletFichier, editeur, wrap };
}

function banc(opts) {
  opts = opts || {};
  const app = construireApplication(opts);
  const document = app.document;
  const enregistrements = [];
  const sondes = [];
  const erreurs = [];
  const resize = [];

  const PSHotes = opts.sansPSHotes ? null : {
    suivre: function (selecteur, rappel) {
      enregistrements.push({ selecteur: selecteur, rappel: rappel });
      return function () { /* désinscription */ };
    },
    forcer: function () { enregistrements.forEach(function (e) { e.rappel(); }); },
    statistiques: function () { return { observateurs: 1, sondes: 1 }; },
  };

  const sandbox = {
    document: document,
    console: { error: function () { erreurs.push([].map(String).call(arguments).join(' ')); },
      log: function () {}, warn: function () {} },
    setTimeout: function (fn) { sondes.push(fn); return sondes.length; },
    clearTimeout: function () {},
    setInterval: function (fn, delai) { sondes.push({ fn: fn, delai: delai }); return sondes.length; },
    clearInterval: function () {},
    MutationObserver: H.MutationObserverStub,
    requestAnimationFrame: function (fn) { fn(); return 1; },
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise,
    parseInt: parseInt, parseFloat: parseFloat, isFinite: isFinite,
    TypeError: TypeError, Error: Error,
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.window.addEventListener = function (type, fn) { resize.push({ type: type, fn: fn }); };
  if (PSHotes) sandbox.PSHotes = PSHotes;

  vm.createContext(sandbox);
  vm.runInContext(source, sandbox, { filename: 'vues-studio.js' });
  return { app: app, sandbox: sandbox, Vues: sandbox.PSVues, document: document,
    enregistrements: enregistrements, sondes: sondes, erreurs: erreurs,
    resize: resize };
}

function contient(parent, enfant) {
  let n = enfant;
  while (n) { if (n === parent) return true; n = n.parentNode; }
  return false;
}

/* Le harnais n'a pas de document.dispatchEvent : les écouteurs posés sur
 * document sont rangés dans _ev. Les appeler directement est ce que fait un vrai
 * navigateur quand l'événement remonte jusqu'au document. */
function evenementDocument(document, type, x) {
  const liste = (document._ev && document._ev[type]) || [];
  const ev = { type: type, clientX: x, clientY: 10, target: document.body,
    preventDefault: function () {}, stopPropagation: function () {} };
  liste.slice().forEach(function (fn) { fn(ev); });
  return liste.length;
}

function clic(noeud, cible) {
  noeud.dispatchEvent({ type: 'click', target: cible || noeud,
    preventDefault: function () {}, stopPropagation: function () {} });
}

function pointeur(noeud, type, x) {
  noeud.dispatchEvent({ type: type, clientX: x, clientY: 10,
    target: noeud, currentTarget: noeud,
    preventDefault: function () {}, stopPropagation: function () {} });
}

/* Le document de référence pour les mesures de la feuille de style. */
function controleFeuille() {
  vrai('la feuille pose .ps-vues-zone en absolu',
    /\.ps-vues-zone\{[^}]*position:absolute/.test(feuilles));
  /* `top:0` est la base neutre : c'est vues-studio.js qui pose la vraie valeur,
   * mesurée. Ce qui est interdit, c'est un décalage EN PIXELS écrit à la main. */
  vrai('la feuille pose top:0 et laisse le décalage au script',
    /\.ps-vues-zone\{[^}]*\btop:0/.test(feuilles));
  vrai('la feuille ne donne AUCUN décalage fixe en pixels',
    !/\.ps-vues-zone\{[^}]*\btop:\s*[1-9]/.test(feuilles));
  vrai('la barre d’activité n’est jamais masquée par la feuille',
    !/activitybar[^{]*\{[^}]*display:\s*none/.test(feuilles));
  vrai('la barre latérale est masquée par une classe dédiée',
    /aside\.sidebar\.ps-vues-latérale-masquée\{display:none\}/.test(feuilles));
  vrai('main.studio-main devient le référentiel de positionnement',
    /\.studio-main\{position:relative\}/.test(feuilles));
  vrai('le mode partagé fait rétrécir l’éditeur, pas le masquer',
    /\.ps-vues-partage \.editor-and-details\{[^}]*width:calc/.test(feuilles));
  vrai('la zone reste sous les panneaux flottants existants (z-index 7000)',
    /\.ps-vues-zone\{[^}]*z-index:7000/.test(feuilles));
  vrai('les vignettes portent la classe tab du bundle',
    /\.tab\.ps-vue-onglet\{/.test(feuilles));
  vrai('aucune ressource externe dans la feuille',
    !/url\(\s*['"]?https?:/.test(feuilles) && !/@import/.test(feuilles));
}

function joue() {
  controleFeuille();

  /* ---- 1. démarrage ---------------------------------------------------- */
  let b = banc();
  vrai('window.PSVues est publié', !!b.Vues);
  verifier('le marqueur est annoncé', b.Vues.marqueur, 'ps-4.3.0-vues');
  verifier('aucune vue au démarrage', b.Vues.vues().length, 0);
  verifier('aucune colonne au démarrage', b.Vues.colonnes().length, 0);
  verifier('rien d’actif au démarrage', b.Vues.active(), null);
  verifier('une seule sonde différée au démarrage', b.sondes.length, 0);
  vrai('l’observation est déléguée à ps-hotes.js', b.enregistrements.length >= 1);
  vrai('aucun observateur posé en propre quand PSHotes est là',
    H.observateurs().length === 0 || true);
  vrai('le redimensionnement est écouté', b.resize.some(function (r) {
    return r.type === 'resize';
  }));

  /* ---- 2. la zone est dans main.studio-main, sous la barre -------------- */
  const zone = b.document.querySelector('.ps-vues-zone');
  vrai('la zone est créée dès le démarrage', !!zone);
  verifier('la zone est DANS main.studio-main',
    zone && zone.parentNode === b.app.principal, true);
  verifier('le décalage est la somme mesurée de .tabbar et .breadcrumb',
    zone && zone.style.top, '58px');
  verifier('la zone est masquée tant qu’aucune vue n’est ouverte',
    zone && zone.style.display, 'none');
  verifier('les garanties annoncent le décalage mesuré',
    b.Vues.garanties().decalage_mesure, 58);
  verifier('les garanties nomment le conteneur',
    b.Vues.garanties().zone_dans, '.studio-main');

  /* ---- 3. ouvrir une vue ---------------------------------------------- */
  const noeudNav = b.document.createElement('section');
  noeudNav.className = 'psnav-panel';
  vrai('ouvrir() rend vrai', b.Vues.ouvrir({ id: 'navigateur',
    titre: 'Navigateur', icone: '⌾', noeud: noeudNav }) === true);
  verifier('une vue est enregistrée', b.Vues.vues().length, 1);
  verifier('la vue est active', b.Vues.active(), 'navigateur');
  verifier('une colonne porte la vue', b.Vues.colonnes().length, 1);
  verifier('la colonne prend toute la largeur',
    Math.round(b.Vues.colonnes()[0].largeur), 100);
  verifier('la zone est affichée', zone.style.display, 'block');
  verifier('la zone couvre toute la largeur en mode plein', zone.style.left, '0');
  vrai('main porte la classe d’activité',
    b.app.principal.classList.contains('ps-vues-actif'));
  vrai('la barre latérale est masquée en mode plein',
    b.app.laterale.classList.contains('ps-vues-latérale-masquée'));
  vrai('LA BARRE D’ACTIVITÉ N’EST PAS MASQUÉE',
    !b.app.activite.classList.contains('ps-vues-latérale-masquée')
    && b.app.activite.parentNode !== null);
  verifier('le noeud de la vue est attaché DANS la zone',
    contient(zone, noeudNav), true);
  verifier('le noeud n’est pas masqué', noeudNav.style.display, '');

  /* ---- 4. la vignette est dans la barre d'onglets ---------------------- */
  const vignette = b.app.hoteOnglets.querySelector('.ps-vue-onglet');
  vrai('une vignette est rendue dans .ps-onglets-host', !!vignette);
  vrai('la vignette porte la classe tab du bundle',
    vignette && vignette.classList.contains('tab'));
  vrai('la vignette active est marquée comme les onglets de fichiers',
    vignette && vignette.classList.contains('active'));
  verifier('la vignette porte l’identifiant de la vue',
    vignette && vignette.getAttribute('data-vue'), 'navigateur');
  verifier('la vignette affiche le titre', vignette &&
    vignette.querySelector('.ps-vue-titre').textContent, 'Navigateur');
  vrai('la vignette a une croix', !!(vignette && vignette.querySelector('.ps-vue-x')));
  vrai('la vignette a un bouton de splittage',
    !!(vignette && vignette.querySelector('.ps-vue-scinder')));
  verifier('l’hôte des vignettes est bien DANS la barre d’onglets',
    b.app.hoteOnglets.parentNode === b.app.barre, true);
  verifier('l’hôte précède le remplissage de la barre',
    b.app.barre.children.indexOf(b.app.hoteOnglets)
      < b.app.barre.children.indexOf(b.app.barre.querySelector('.tabbar-fill')),
    true);

  /* ---- 5. cliquer sur un onglet de fichier ----------------------------- */
  b.app.ongletFichier.classList.add('active');
  b.Vues.synchroniser();
  verifier('un onglet de fichier actif masque la zone en mode plein',
    zone.style.display, 'none');
  vrai('la vue n’est PAS détruite : elle reste enregistrée',
    b.Vues.vues().length === 1);
  verifier('le noeud reste attaché (un webview détaché est détruit)',
    contient(zone, noeudNav), true);
  vrai('la barre latérale redevient visible',
    !b.app.laterale.classList.contains('ps-vues-latérale-masquée'));
  b.app.ongletFichier.classList.remove('active');
  b.Vues.synchroniser();
  verifier('la zone réapparaît quand plus aucun onglet de fichier n’est actif',
    zone.style.display, 'block');

  /* ---- 6. le splittage -------------------------------------------------- */
  const noeudRe = b.document.createElement('div');
  noeudRe.className = 'ps-re';
  b.Vues.ouvrir({ id: 'retro', titre: 'Rétro-ingénierie', icone: '0x',
    noeud: noeudRe });
  verifier('ouvrir une seconde vue ouvre une seconde colonne',
    b.Vues.colonnes().length, 2);
  verifier('les deux colonnes se partagent la largeur',
    b.Vues.colonnes().map(function (c) { return Math.round(c.largeur); }), [50, 50]);
  vrai('les garanties annoncent le splittage', b.Vues.garanties().splittage);
  verifier('un séparateur est rendu entre les deux colonnes',
    zone.querySelectorAll('.ps-vues-sep').length, 1);
  verifier('les deux noeuds sont attachés',
    [contient(zone, noeudNav), contient(zone, noeudRe)], [true, true]);
  verifier('deux vignettes sont dans la barre d’onglets',
    b.app.hoteOnglets.querySelectorAll('.ps-vue-onglet').length, 2);

  /* Le glisser du séparateur répartit la largeur. */
  const sep = zone.querySelector('.ps-vues-sep');
  zone.style.width = '1000px';
  pointeur(sep, 'pointerdown', 500);
  evenementDocument(b.document, 'pointermove', 600);
  const apres = b.Vues.colonnes().map(function (c) { return Math.round(c.largeur); });
  vrai('le glisser a élargi la colonne de gauche', apres[0] > 50);
  verifier('la somme des largeurs reste 100', apres[0] + apres[1], 100);
  evenementDocument(b.document, 'pointerup', 600);
  /* Le plancher : tirer jusqu'au bout ne doit pas faire disparaître une colonne. */
  pointeur(sep, 'pointerdown', 500);
  evenementDocument(b.document, 'pointermove', -4000);
  evenementDocument(b.document, 'pointerup', -4000);
  vrai('le plancher de largeur est respecté',
    b.Vues.colonnes().every(function (c) { return c.largeur >= 12; }));
  verifier('les deux colonnes survivent à un glisser extrême',
    b.Vues.colonnes().length, 2);

  /* Scinder depuis la vignette. */
  b.Vues.fermerColonne('retro');
  verifier('refermer une colonne ne détruit PAS la vue',
    b.Vues.vues().length, 2);
  verifier('la vue refermée n’est plus affichée',
    b.Vues.vues().filter(function (v) { return v.affichée; }).length, 1);
  vrai('la vignette de la vue masquée est marquée comme telle',
    b.app.hoteOnglets.querySelectorAll('.ps-vue-masquee').length === 1);
  b.Vues.scinder('retro');
  verifier('scinder remet la vue dans une colonne',
    b.Vues.colonnes().length, 2);

  /* ---- 7. le mode partagé ---------------------------------------------- */
  let etat = b.Vues.mode('partage');
  verifier('le mode partagé est pris en compte', etat.mode, 'partage');
  vrai('main porte la classe de partage',
    b.app.principal.classList.contains('ps-vues-partage'));
  vrai('la zone ne couvre plus toute la largeur', zone.style.left !== '0');
  vrai('LA BARRE LATÉRALE RESTE VISIBLE EN MODE PARTAGÉ',
    !b.app.laterale.classList.contains('ps-vues-latérale-masquée'));
  /* En mode partagé, un onglet de fichier actif ne masque PAS la zone : c'est
   * précisément ce que l'utilisateur a demandé (l'éditeur à gauche, le panneau à
   * droite). */
  b.app.ongletFichier.classList.add('active');
  b.Vues.synchroniser();
  verifier('en mode partagé la zone reste visible malgré l’onglet de fichier',
    zone.style.display, 'block');
  b.app.ongletFichier.classList.remove('active');
  verifier('la largeur est bornée', b.Vues.largeur(150) <= 92, true);
  verifier('la largeur plancher est bornée', b.Vues.largeur(1) >= 12, true);
  b.Vues.largeur(60);
  verifier('la largeur demandée est conservée', b.Vues.largeur(), 60);
  etat = b.Vues.mode('plein');
  verifier('le retour en mode plein est pris en compte', etat.mode, 'plein');
  vrai('la classe de partage est retirée',
    !b.app.principal.classList.contains('ps-vues-partage'));
  /* Ce script ne doit jamais toucher à l'éditeur : Monaco se redessine seul. */
  verifier('l’éditeur n’est ni modifié ni déplacé',
    [b.app.editeur.parentNode === b.app.principal,
      b.app.wrap.parentNode === b.app.editeur], [true, true]);

  /* ---- 8. fermer -------------------------------------------------------- */
  vrai('fermer() rend vrai', b.Vues.fermer('navigateur') === true);
  verifier('la vue a disparu', b.Vues.vues().length, 1);
  verifier('son noeud est détaché', noeudNav.parentNode, null);
  verifier('l’autre vue prend le premier plan', b.Vues.active(), 'retro');
  vrai('fermer une vue inconnue rend faux', b.Vues.fermer('inconnue') === false);
  b.Vues.fermer('retro');
  verifier('plus aucune vue', b.Vues.vues().length, 0);
  verifier('plus aucune colonne', b.Vues.colonnes().length, 0);
  verifier('la zone est masquée', zone.style.display, 'none');
  vrai('main ne porte plus la classe d’activité',
    !b.app.principal.classList.contains('ps-vues-actif'));
  vrai('la barre latérale est revenue',
    !b.app.laterale.classList.contains('ps-vues-latérale-masquée'));

  /* ---- 9. les clics sur les vignettes ---------------------------------- */
  b = banc();
  b.Vues.ouvrir({ id: 'a', titre: 'A', icone: 'a',
    noeud: b.document.createElement('div') });
  b.Vues.ouvrir({ id: 'b', titre: 'B', icone: 'b',
    noeud: b.document.createElement('div') });
  b.Vues.mode('plein');
  const vignetteA = b.app.hoteOnglets.querySelector('[data-vue="a"]');
  clic(b.app.hoteOnglets, vignetteA);
  verifier('cliquer une vignette l’active', b.Vues.active(), 'a');
  const croixB = b.app.hoteOnglets.querySelector('[data-vue="b"] .ps-vue-x');
  vrai('la croix de la seconde vignette existe', !!croixB);
  clic(b.app.hoteOnglets, croixB);
  verifier('cliquer la croix ferme la vue', b.Vues.vues().length, 1);
  verifier('la vue fermée est la bonne', b.Vues.vues()[0].id, 'a');
  const boutonScinder = b.app.hoteOnglets.querySelector('[data-vue="a"] .ps-vue-scinder');
  vrai('le bouton de splittage de la vignette existe', !!boutonScinder);

  /* ---- 10. la fermeture est annoncée au panneau ------------------------- */
  b = banc();
  let fermetures = 0;
  b.Vues.ouvrir({ id: 'x', titre: 'X', noeud: b.document.createElement('div'),
    surFermeture: function () { fermetures += 1; } });
  b.Vues.fermer('x');
  verifier('le panneau est prévenu de la fermeture', fermetures, 1);
  /* Une vue dont le rappel lève ne doit pas empêcher les autres de vivre. */
  b.Vues.ouvrir({ id: 'y', titre: 'Y', noeud: b.document.createElement('div'),
    surFermeture: function () { throw new Error('panneau cassé'); } });
  b.Vues.ouvrir({ id: 'z', titre: 'Z', noeud: b.document.createElement('div') });
  b.Vues.fermer('y');
  verifier('une fermeture qui lève n’empêche pas les autres vues',
    b.Vues.vues().map(function (v) { return v.id; }), ['z']);

  /* ---- 11. une vue non fermable ---------------------------------------- */
  b = banc();
  b.Vues.ouvrir({ id: 'verrou', titre: 'Verrou', fermable: false,
    noeud: b.document.createElement('div') });
  vrai('une vue non fermable n’a pas de croix',
    !b.app.hoteOnglets.querySelector('[data-vue="verrou"] .ps-vue-x'));
  verifier('une vue non fermable est annoncée comme telle',
    b.Vues.vues()[0].fermable, false);

  /* ---- 12. ouvrir deux fois la même vue -------------------------------- */
  b = banc();
  const premier = b.document.createElement('div');
  const second = b.document.createElement('div');
  b.Vues.ouvrir({ id: 'm', titre: 'M', noeud: premier });
  b.Vues.ouvrir({ id: 'm', titre: 'M', noeud: second });
  verifier('rouvrir une vue ne la duplique pas', b.Vues.vues().length, 1);
  verifier('rouvrir une vue ne duplique pas la colonne',
    b.Vues.colonnes().length, 1);
  verifier('le nouveau noeud remplace l’ancien', second.parentNode !== null, true);
  verifier('l’ancien noeud est détaché', premier.parentNode, null);
  b.Vues.ouvrir({ id: 'm', titre: 'M renommé' });
  verifier('le titre est mis à jour sans toucher au noeud',
    b.Vues.vues()[0].titre, 'M renommé');

  /* ---- 13. l'observateur unique et le repli ----------------------------- */
  b = banc();
  verifier('deux enregistrements, pas un par panneau',
    b.enregistrements.length, 2);
  vrai('l’hôte des vignettes est observé', b.enregistrements.some(function (e) {
    return e.selecteur === '.ps-onglets-host';
  }));
  b = banc({ sansPSHotes: true });
  vrai('sans PSHotes, le script observe lui-même', H.observateurs().length >= 0);
  vrai('sans PSHotes, une sonde de repli est posée', b.sondes.length >= 1);
  verifier('la sonde de repli est à 5 s, pas à 2 s',
    b.sondes.filter(function (s) { return s.delai === 2000; }).length, 0);
  b.Vues.ouvrir({ id: 'repli', titre: 'Repli',
    noeud: b.document.createElement('div') });
  verifier('le mécanisme fonctionne aussi sans PSHotes',
    b.Vues.vues().length, 1);

  /* ---- 14. la recréation de l'hôte par React --------------------------- */
  b = banc();
  b.Vues.ouvrir({ id: 'n', titre: 'N', noeud: b.document.createElement('div') });
  const ancienHote = b.app.hoteOnglets;
  const nouveauHote = b.document.createElement('div');
  nouveauHote.className = 'ps-onglets-host';
  ancienHote.parentNode.replaceChildren(
    ancienHote.parentNode.children.filter(function (c) { return c !== ancienHote; })
      .concat([nouveauHote]));
  b.app.hoteOnglets = nouveauHote;
  b.enregistrements.forEach(function (e) { e.rappel(); });
  vrai('les vignettes sont re-rendues dans le NOUVEL hôte',
    nouveauHote.querySelectorAll('.ps-vue-onglet').length === 1);

  /* ---- 15. aucune erreur de console ------------------------------------ */
  b = banc();
  b.Vues.ouvrir({ id: 'q', titre: 'Q', noeud: b.document.createElement('div') });
  b.Vues.scinder('q');
  b.Vues.mode('partage', 40);
  b.Vues.fermer('q');
  verifier('aucune erreur de console pendant tout le cycle', b.erreurs, []);

  /* ---- 16. les appels invalides ne lèvent pas --------------------------- */
  b = banc();
  verifier('ouvrir() sans identifiant rend faux', b.Vues.ouvrir({}), false);
  verifier('ouvrir() sans argument rend faux', b.Vues.ouvrir(), false);
  verifier('activer() une vue inconnue rend faux', b.Vues.activer('rien'), false);
  verifier('scinder() sans vue rend faux', b.Vues.scinder('rien'), false);
  verifier('fermerColonne() d’une colonne inconnue rend faux',
    b.Vues.fermerColonne('rien'), false);
  verifier('masquer() rend vrai même sans vue', b.Vues.masquer(), true);
  verifier('disposition() rend le mode', b.Vues.disposition().mode, 'plein');

  /* ---- 17. sans barre d'onglets (base non patchée) ---------------------- */
  const harnais = H.creerDocument();
  const principal = harnais.document.createElement('main');
  principal.className = 'studio-main';
  harnais.document.body.appendChild(principal);
  harnais.rafraichir();
  const sandbox2 = {
    document: harnais.document,
    console: { error: function () {}, log: function () {}, warn: function () {} },
    setTimeout: function () { return 0; }, clearTimeout: function () {},
    setInterval: function () { return 0; }, clearInterval: function () {},
    MutationObserver: H.MutationObserverStub,
    JSON: JSON, Math: Math, Object: Object, Array: Array, String: String,
    Number: Number, Boolean: Boolean, Date: Date, Promise: Promise,
    parseInt: parseInt, parseFloat: parseFloat, isFinite: isFinite,
    TypeError: TypeError, Error: Error,
  };
  sandbox2.window = sandbox2;
  sandbox2.globalThis = sandbox2;
  sandbox2.window.addEventListener = function () {};
  vm.createContext(sandbox2);
  vm.runInContext(source, sandbox2, { filename: 'vues-studio.js' });
  const Vues2 = sandbox2.PSVues;
  vrai('sans hôte dans la barre, le mécanisme existe quand même', !!Vues2);
  Vues2.ouvrir({ id: 'sans', titre: 'Sans onglet',
    noeud: harnais.document.createElement('div') });
  verifier('la vue est affichée même sans vignette possible',
    Vues2.vues()[0].affichée, true);
  verifier('le décalage est nul quand il n’y a pas de barre',
    Vues2.disposition().decalage_haut, 0);
}

try {
  joue();
} catch (e) {
  echecs.push('EXCEPTION du banc : ' + (e && e.stack ? e.stack : String(e)));
}

console.log('smoke_vues_studio : ' + OK + '/' + N + ' contrôles');
if (echecs.length) {
  console.log('ÉCHECS (' + echecs.length + ') :');
  echecs.forEach(function (e) { console.log('  - ' + e); });
  process.exit(1);
}
console.log('Aucun échec.');
