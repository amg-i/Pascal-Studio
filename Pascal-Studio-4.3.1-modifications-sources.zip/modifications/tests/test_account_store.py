"""Persistance chiffrée des comptes GitHub/GitLab : aucun jeton en clair sur le disque."""
import json, os, stat, tempfile, unittest
from pathlib import Path
from unittest import mock
import account_store as st

SAMPLE = {
    'aaa111': {'id': 'aaa111', 'provider': 'github', 'login': 'alice', 'name': 'Alice',
               'email': 'alice@example.com', 'token': 'ghp_SECRET_1234567890',
               'refresh': None, 'client_id': None, 'expiry': None},
    'bbb222': {'id': 'bbb222', 'provider': 'gitlab', 'login': 'bob', 'name': 'Bob',
               'email': 'bob@example.com', 'token': 'glpat-SECRET-abcdefghij',
               'refresh': 'rt_SECRET', 'client_id': 'cid', 'expiry': 1893456000.0},
}


class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        env = mock.patch.dict(os.environ, {'PS_GIT_ACCOUNTS_DIR': str(self.dir),
                                           'PS_GIT_ACCOUNTS_PERSIST': '1'})
        env.start()
        self.addCleanup(env.stop)
        self.store = st.AccountStore()
        self.conf = self.dir / 'pascal-studio'

    def test_roundtrip_restores_accounts(self):
        self.assertEqual(self.store.save(SAMPLE)['ok'], True)
        other = st.AccountStore()
        self.assertEqual(other.load(), SAMPLE)

    def test_no_plaintext_token_on_disk(self):
        self.store.save(SAMPLE)
        blob = (self.conf / 'git-accounts.json').read_text('utf8')
        for secret in ('ghp_SECRET_1234567890', 'glpat-SECRET-abcdefghij', 'rt_SECRET', 'alice@example.com'):
            self.assertNotIn(secret, blob)
        obj = json.loads(blob)
        self.assertEqual(obj['cipher'], 'aes-256-gcm')
        self.assertEqual(obj['kdf'], 'scrypt-32768-8-1')

    def test_key_and_store_are_private_files(self):
        self.store.save(SAMPLE)
        for name in ('git-accounts.json', 'git-accounts-auto.key'):
            mode = (self.conf / name).stat().st_mode
            self.assertEqual(mode & 0o077, 0, name + ' ne doit être lisible que par son propriétaire')
        self.assertEqual(self.conf.stat().st_mode & 0o077, 0)

    def test_remove_deletes_a_single_account(self):
        self.store.save(SAMPLE)
        self.assertEqual(self.store.remove('aaa111')['ok'], True)
        left = st.AccountStore().load()
        self.assertEqual(list(left), ['bbb222'])

    def test_purge_removes_store_and_key(self):
        self.store.save(SAMPLE)
        self.store.purge()
        self.assertFalse((self.conf / 'git-accounts.json').exists())
        self.assertFalse((self.conf / 'git-accounts-auto.key').exists())
        self.assertEqual(st.AccountStore().load(), {})

    def test_tampered_ciphertext_is_refused_and_reported(self):
        self.store.save(SAMPLE)
        p = self.conf / 'git-accounts.json'
        obj = json.loads(p.read_text('utf8'))
        # GCM authentifie le chiffré : un seul caractère modifié doit tout faire refuser.
        tail = obj['ciphertext'][-4:]
        obj['ciphertext'] = obj['ciphertext'][:-4] + ('AAAA' if tail != 'AAAA' else 'BBBB')
        p.write_text(json.dumps(obj), encoding='utf8')
        other = st.AccountStore()
        self.assertEqual(other.load(), {})          # échec silencieux, pas de plantage
        self.assertTrue(other.status()['error'])

    def test_wrong_key_is_refused(self):
        self.store.save(SAMPLE)
        (self.conf / 'git-accounts-auto.key').unlink()
        other = st.AccountStore()                   # régénère une clé différente
        self.assertEqual(other.load(), {})
        self.assertTrue(other.status()['error'])

    def test_key_is_never_silently_replaced(self):
        self.store.save(SAMPLE)
        s2 = st.AccountStore()
        s2.key = os.urandom(32)
        s2.salt = os.urandom(16)
        with self.assertRaises(ValueError):
            s2._write_key(s2.salt, s2.key)

    def test_disabled_persistence_stays_in_memory(self):
        with mock.patch.dict(os.environ, {'PS_GIT_ACCOUNTS_PERSIST': '0'}):
            self.assertEqual(st.enabled(), False)
            self.assertEqual(self.store.save(SAMPLE), {'ok': False, 'reason': 'désactivée'})
            self.assertEqual(self.store.load(), {})
        self.assertFalse((self.conf / 'git-accounts.json').exists())

    def test_missing_store_returns_empty(self):
        self.assertEqual(st.AccountStore().load(), {})

    def test_corrupt_json_returns_empty_without_crash(self):
        self.conf.mkdir(parents=True, exist_ok=True)
        (self.conf / 'git-accounts.json').write_text('{ pas du json', encoding='utf8')
        other = st.AccountStore()
        self.assertEqual(other.load(), {})
        self.assertTrue(other.status()['error'])

    def test_symlinked_store_is_refused(self):
        self.store.save(SAMPLE)
        real = self.conf / 'git-accounts.json'
        target = self.dir / 'ailleurs.json'
        target.write_text('{}', encoding='utf8')
        real.unlink()
        real.symlink_to(target)
        other = st.AccountStore()
        self.assertEqual(other.load(), {})

    def test_unicode_login_survives_roundtrip(self):
        data = {'c': dict(SAMPLE['aaa111'], id='c', login='amélie', name='Amélie 😀')}
        self.store.save(data)
        self.assertEqual(st.AccountStore().load()['c']['name'], 'Amélie 😀')

    def test_world_writable_key_is_refused(self):
        self.store.save(SAMPLE)
        key = self.conf / 'git-accounts-auto.key'
        key.chmod(0o644)
        other = st.AccountStore()
        self.assertEqual(other.load(), {})
        self.assertIn('0600', other.status()['error'])


if __name__ == '__main__':
    unittest.main()
