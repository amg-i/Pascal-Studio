import os,shutil,subprocess,tempfile,unittest
from pathlib import Path
import additional_languages as a,polyglot,project_tools

class NewLanguageTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name);self.build=self.root/'cache';self.build.mkdir()
 def test_extensions(self):
  for x,k in [('x.F90','fortran'),('x.f','fortran'),('x.pl','perl'),('x.pm','perl'),('x.bas','basic'),('x.yab','basic'),('x.ml','ocaml'),('x.mli','ocaml'),('x.lua','lua')]:self.assertEqual(polyglot.kind(x),k)
 def test_execution_and_live_errors(self):
  cases=[('fortran','f90','program hello\n print *, "Bonjour Fortran"\nend program hello\n','program hello\n integer :: x\n x = \nend program hello\n','Bonjour Fortran'),('perl','pl','use strict;\nprint "Bonjour Perl\\n";\n','my $x = ;\n','Bonjour Perl'),('basic','bas','print "Bonjour BASIC"\nend\n','print "x"\nthis is invalid\n','Bonjour BASIC'),('ocaml','ml','print_endline "Bonjour OCaml";;\n','let x =\n','Bonjour OCaml'),('lua','lua','print("Bonjour Lua")\n','local =\n','Bonjour Lua')]
  for k,ext,valid,invalid,expected in cases:
   with self.subTest(kind=k):
    p=self.root/('main.'+ext);p.write_text(valid);l=a.analyze(k,p,p.name,valid);self.assertEqual(l['state'],'ready',l);self.assertTrue(l['ok'],l);bad=a.analyze(k,p,p.name,invalid);self.assertFalse(bad['ok'],bad);self.assertTrue(bad['diagnostics'],bad)
    r=a.build(self.root,self.build,p,p.name);self.assertTrue(r['ok'],r);out=subprocess.check_output(r.get('command') or [r['binary']],cwd=p.parent,text=True);self.assertIn(expected,out)
 def test_fortran_f77_extension(self):
  p=self.root/'legacy.f77';p.write_text('      program legacy\n      print *, 42\n      end\n');r=a.analyze('fortran',p,p.name,p.read_text());self.assertTrue(r['ok'],r);b=a.build(self.root,self.build,p,p.name);self.assertTrue(b['ok'],b);self.assertIn('42',subprocess.check_output([b['binary']],text=True))
  p=self.root/'legacy.F77';p.write_text('#define VALUE 42\n      program legacy\n      print *, VALUE\n      end\n');r=a.analyze('fortran',p,p.name,p.read_text());self.assertTrue(r['ok'],r);b=a.build(self.root,self.build,p,p.name);self.assertTrue(b['ok'],b);self.assertIn('42',subprocess.check_output([b['binary']],text=True))
 def test_no_perl_begin_execution_on_live_or_compile(self):
  p=self.root/'main.pl';p.write_text('BEGIN { open(my $f, ">", "danger"); print $f "ok"; close $f; }\nprint "ok\\n";\n')
  a.analyze('perl',p,p.name,p.read_text());self.assertFalse((self.root/'danger').exists());r=a.build(self.root,self.build,p,p.name);self.assertTrue(r['ok']);self.assertFalse((self.root/'danger').exists())
 def test_ocaml_and_fortran_never_create_intermediates_in_source(self):
  for name,text in [('one.ml','let x = 1\n'),('module.f90','module thing\ninteger :: i\nend module thing\nprogram a\nend program a\n')]:
   p=self.root/name;p.write_text(text);a.analyze(a.kind(p),p,name,text);r=a.build(self.root,self.build,p,name);self.assertTrue(r['ok'],r)
  self.assertFalse(list(self.root.glob('*.cmi')));self.assertFalse(list(self.root.glob('*.cmo')));self.assertFalse(list(self.root.glob('*.mod')))
 def test_yabasic_check_does_not_run_program(self):
  p=self.root/'main.bas';src='open #1, "danger", "w"\nprint #1, "WRITTEN"\nclose #1\nend\n';p.write_text(src);r=a.analyze('basic',p,p.name,src);self.assertTrue(r['ok'],r);self.assertFalse((self.root/'danger').exists())
 def test_yabasic_comment_forms(self):
  p=self.root/'x.bas';p.write_text('# TODO premier\n// FIXME second\nprint #1, "TODO chaine" rem TODO dernier\n')
  items=project_tools.todos(self.root)['items'];self.assertEqual(len(items),3,items)
  self.assertEqual([x['kind'] for x in items],['TODO','FIXME','TODO'])
 def test_todos_not_in_strings(self):
  cases={'x.f90':'print *, "TODO no" ! TODO Fortran\n','x.pl':'print "TODO no"; # TODO Perl\n','x.bas':'print "TODO no" : REM TODO BASIC\n','x.ml':'let f (x : \'a) = x (* TODO OCaml *)\n','x.lua':'print("TODO no") -- TODO Lua\n'}
  for name,text in cases.items():(self.root/name).write_text(text)
  items=project_tools.todos(self.root)['items'];self.assertEqual(len(items),5,items);self.assertEqual({x['path'] for x in items},set(cases))
