"""Qualité structurelle et exemples JSON des 22 rubriques supplémentaires."""
import json,subprocess,sys,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class TestHelp(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  subprocess.run([sys.executable,str(ROOT/'aide-complementaire.py')],check=True,capture_output=True)
  raw=(ROOT/'aide-complementaire.js').read_text(encoding='utf8').split('window.PS_EXTRA_HELP=',1)[1].strip().removesuffix(';');cls.articles=json.loads(raw)['articles']
 def test_all_families_and_examples(self):
  expected={'Pascal','C','C++','C#','Python','JavaScript','PHP','HTML','CSS','Markdown','Makefile','CMake','Rust','Go','Ruby','SQL','SQLite','PostgreSQL','MySQL / MariaDB','CSV / TSV','JSON','Données · Studio'}
  self.assertEqual({a['lang'] for a in self.articles},expected);self.assertEqual(len({a['id'] for a in self.articles}),len(self.articles))
  for a in self.articles:self.assertTrue(a['summary'] and a['blocks'][0]['text'] and a['blocks'][1]['code'],a['title'])
 def test_json_examples(self):
  for a in self.articles:
   if a['lang']=='JSON':json.loads(a['blocks'][1]['code'])
if __name__=='__main__':unittest.main()
