import json, unittest
from pathlib import Path

class AideGestionnaireTest(unittest.TestCase):
 def test_catalogue_contains_topics_and_examples(self):
  p=Path(__file__).parents[1]/'aide-latex.js'
  s=p.read_text(encoding='utf-8');raw=s.split('window.PS_LATEX_HELP=',1)[1].strip().removesuffix(';')
  d=json.loads(raw);self.assertIn('Gestionnaire de fichiers',d['languages'])
  items=[x for x in d['articles'] if x['lang']=='Gestionnaire de fichiers']
  self.assertGreaterEqual(len(items),18);self.assertEqual([x['group'] for x in items if x['intro']],['Introduction'])
  text=' '.join(x['title']+' '+b['text']+' '+b['code'] for x in items for b in x['blocks'])
  for term in ('FTP','SFTP','SMB','trousseau','empreinte','conflit','PSNote'):self.assertIn(term.lower(),text.lower())
  for group in ('Prise en main','Connexions','Transferts','Modification'):self.assertTrue(any(x['group']==group for x in items))

if __name__=='__main__':unittest.main()
