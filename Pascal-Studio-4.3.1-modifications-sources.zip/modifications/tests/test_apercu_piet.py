# -*- coding: utf-8 -*-
"""L'aperçu d'un programme Piet : la page, l'image et la surcouche.

Piet est le seul langage dont le programme est une image. Trois choses doivent
donc se produire quand l'utilisateur ouvre l'aperçu d'un .png reconnu comme un
programme Piet :

  1. l'aperçu démarre — alors que web_preview n'acceptait que HTML, CSS, SVG,
     XML et PHP ;
  2. le fichier est servi dans une PAGE qui porte la surcouche de l'inspecteur,
     et non comme une image nue sur laquelle rien ne peut être dessiné ;
  3. l'inspecteur reçoit les blocs de couleur, leurs rectangles en pixels, et le
     bloc en cours d'exécution quand une session de pas à pas est active.

Une photo ou une icône du projet ne doit déclencher rien de tout cela : elle
reste une image ordinaire. C'est le rôle du contrôle « aucun bloc hors palette ».

Les requêtes sont réelles : le serveur d'aperçu est démarré sur 127.0.0.1 et
interrogé avec son cookie d'autorisation, exactement comme le fait l'iframe de
l'interface.
"""

import base64
import http.client
import json
import os
import shutil
import sys
import tempfile
import unittest
import urllib.parse
from pathlib import Path
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import inspecteur_visuel
import web_preview
from test_inspecteur_visuel import (BLANC, INCONNUE, MAGENTA, ROUGE,
                                    ROUGE_SOMBRE, ecrire_png, uri)

# Un programme minimal : deux blocs de trois codels, rouge normal puis rouge
# sombre. Le changement de luminosité sans changement de teinte est « push ».
PROGRAMME = [[ROUGE] * 3, [ROUGE_SOMBRE] * 3]
# Une image qui n'est pas un programme : des couleurs hors des 20 de Piet, plus
# un rouge pur qui, seul, ne suffit pas à en faire un programme.
PHOTO = [[INCONNUE, ROUGE, (7, 8, 9)], [(11, 12, 13), (14, 15, 16), (17, 18, 19)]]
BLANC_PUR = [[BLANC] * 4] * 4

BLOC_ACTIF = {'index': 1, 'taille': 3, 'rvb': ROUGE_SOMBRE, 'classe': (2, 0),
              'commande': 'push', 'libelle': 'push', 'dp': 0, 'cc': 0,
              'rectangle': [0, 1, 3, 2]}


class BasePiet(unittest.TestCase):
    """Un projet temporaire, un serveur d'aperçu arrêté à chaque test."""

    def setUp(self):
        self.projet = Path(tempfile.mkdtemp(prefix='ps-piet-'))
        self.cache = Path(tempfile.mkdtemp(prefix='ps-cache-'))
        self.apercu = web_preview.Preview(self.cache)
        self.addCleanup(self.apercu.stop)
        self.addCleanup(shutil.rmtree, self.projet, True)
        self.addCleanup(shutil.rmtree, self.cache, True)

    def ecrire(self, nom, lignes):
        chemin = self.projet / nom
        chemin.write_bytes(ecrire_png(lignes))
        return chemin

    def requete(self, chemin, cookie=None):
        """Une requête sur le serveur d'aperçu, sans suivre les redirections."""
        connexion = http.client.HTTPConnection('127.0.0.1', self.apercu.port,
                                               timeout=10)
        entetes = {'Host': '127.0.0.1:%d' % self.apercu.port}
        if cookie:
            entetes['Cookie'] = cookie
        connexion.request('GET', chemin, headers=entetes)
        reponse = connexion.getresponse()
        corps = reponse.read()
        cookie_recu = reponse.getheader('Set-Cookie')
        emplacement = reponse.getheader('Location')
        connexion.close()
        return reponse.status, reponse.getheader('Content-Type'), corps, cookie_recu, emplacement

    def autoriser(self, url):
        """Suit l'URL d'aperçu et rend (chemin final, cookie d'autorisation)."""
        parts = urllib.parse.urlsplit(url)
        assert parts.path.startswith('/__ps_auth/'), url
        statut, _type, _corps, cookie, emplacement = self.requete(parts.path)
        self.assertEqual(statut, 302, 'l’URL d’aperçu doit rediriger')
        self.assertTrue(cookie and cookie.startswith('__ps_preview='),
                        'aucun cookie d’aperçu reçu')
        return emplacement, cookie.split(';')[0]


class TestReconnaissance(BasePiet):
    """Quel .png est un programme Piet, et lequel ne l'est pas."""

    def test_un_programme_est_reconnu(self):
        self.ecrire('programme.png', PROGRAMME)
        self.assertTrue(self.apercu._est_piet(self.projet, Path('programme.png')))

    def test_une_photo_n_est_pas_reconnue(self):
        self.ecrire('photo.png', PHOTO)
        self.assertFalse(self.apercu._est_piet(self.projet, Path('photo.png')),
                         'une image aux couleurs hors palette n’est pas un '
                         'programme Piet')

    def test_fichier_absent(self):
        self.assertFalse(self.apercu._est_piet(self.projet, Path('absent.png')))

    def test_le_verdict_est_mis_en_cache(self):
        chemin = self.ecrire('programme.png', PROGRAMME)
        self.assertFalse(self.apercu._piet_cache)
        self.assertTrue(self.apercu._est_piet(self.projet, Path('programme.png')))
        self.assertEqual(len(self.apercu._piet_cache), 1)
        # Le contenu change sans que la taille ne change : la date de
        # modification fait partie de la clef, le verdict est recalculé.
        avant = list(self.apercu._piet_cache)[0]
        chemin.write_bytes(ecrire_png(BLANC_PUR))
        os.utime(chemin, (avant[2] + 10, avant[2] + 10))
        self.assertTrue(self.apercu._est_piet(self.projet, Path('programme.png')))
        self.assertEqual(len(self.apercu._piet_cache), 2)

    def test_une_image_trop_grande_n_est_pas_decodee(self):
        """Au-delà de 4 Mo on ne décode pas : ce n'est pas un programme Piet.

        Décoder un PNG à la main coûte cher, et l'aperçu est relancé à chaque
        sélection de fichier. Une photo de quelques mégaoctets ne doit donc
        jamais entrer dans le moteur Piet.
        """
        self.ecrire('programme.png', PROGRAMME)
        vrai_stat = Path.stat

        def gros_stat(chemin, *args, **kwargs):
            etat = vrai_stat(chemin, *args, **kwargs)
            if Path(chemin).name == 'programme.png':
                return os.stat_result((etat.st_mode, etat.st_ino, etat.st_dev,
                                       etat.st_nlink, etat.st_uid, etat.st_gid,
                                       5_000_000, etat.st_atime, etat.st_mtime,
                                       etat.st_ctime))
            return etat

        with mock.patch.object(Path, 'stat', gros_stat):
            self.assertFalse(
                self.apercu._est_piet(self.projet, Path('programme.png')),
                'une image de 5 Mo ne doit pas être décodée')
        self.assertFalse(self.apercu._piet_cache,
                         'un refus lié à la taille ne doit pas être mis en cache')


class TestDemarrage(BasePiet):
    """Le bouton d'aperçu doit accepter un programme Piet et refuser une photo."""

    def test_apercu_demarre_sur_un_programme(self):
        chemin = self.ecrire('programme.png', PROGRAMME)
        resultat = self.apercu.start(self.projet, chemin)
        self.assertEqual(resultat['mode'], 'static')
        self.assertTrue(resultat['url'].endswith('/__ps_piet_demo'),
                        'l’aperçu d’un programme Piet doit passer par la page '
                        'dédiée : ' + resultat['url'])

    def test_apercu_refuse_une_photo(self):
        chemin = self.ecrire('photo.png', PHOTO)
        with self.assertRaises(ValueError) as contexte:
            self.apercu.start(self.projet, chemin)
        self.assertIn('Piet', str(contexte.exception))

    def test_apercu_refuse_une_extension_inconnue(self):
        chemin = self.projet / 'notes.txt'
        chemin.write_text('du texte', encoding='utf8')
        with self.assertRaises(ValueError):
            self.apercu.start(self.projet, chemin)

    def test_apercu_html_inchange(self):
        """Le comportement des autres langages ne doit pas bouger d'un iota."""
        chemin = self.projet / 'page.html'
        chemin.write_text('<p>bonjour</p>', encoding='utf8')
        resultat = self.apercu.start(self.projet, chemin)
        self.assertTrue(resultat['url'].endswith('/page.html'), resultat['url'])
        self.assertNotIn('__ps_piet_demo', resultat['url'])

    def test_apercu_css_passe_toujours_par_sa_page(self):
        chemin = self.projet / 'style.css'
        chemin.write_text('body{color:red}', encoding='utf8')
        resultat = self.apercu.start(self.projet, chemin)
        self.assertTrue(resultat['url'].endswith('/__ps_css_demo'), resultat['url'])


class TestPageServie(BasePiet):
    """Ce que l'iframe reçoit réellement."""

    def setUp(self):
        super().setUp()
        self.chemin = self.ecrire('programme.png', PROGRAMME)
        self.resultat = self.apercu.start(self.projet, self.chemin)
        self.final, self.cookie = self.autoriser(self.resultat['url'])

    def test_la_page_porte_l_image_et_la_surcouche(self):
        statut, type_mime, corps, _c, _e = self.requete(self.final, self.cookie)
        self.assertEqual(statut, 200)
        self.assertIn('text/html', type_mime)
        page = corps.decode('utf8')
        self.assertIn('id="__ps_piet_image"', page)
        self.assertIn('programme.png', page, 'la page doit nommer le fichier')
        self.assertIn('__ps_inspecteur_js', page,
                      'la surcouche de l’inspecteur doit être injectée')
        self.assertIn('__ps_inspecteur_css', page)
        self.assertIn('image-rendering:pixelated', page,
                      'les codels doivent rester nets quand l’image est agrandie')

    def test_l_image_reste_servie_a_son_adresse(self):
        """La page montre l'image : elle doit donc être servie telle quelle."""
        statut, type_mime, corps, _c, _e = self.requete('/programme.png',
                                                        self.cookie)
        self.assertEqual(statut, 200)
        self.assertEqual(type_mime, 'image/png')
        self.assertEqual(corps, self.chemin.read_bytes())

    def test_sans_cookie_l_acces_est_refuse(self):
        statut, _t, _c, _ck, _e = self.requete(self.final)
        self.assertEqual(statut, 403)

    def test_donnees_de_l_inspecteur(self):
        """Le JSON que la surcouche télécharge : blocs, rectangles, diagnostics."""
        def inspecteur(chemin):
            return uri(PROGRAMME), []

        self.apercu.inspecteur = inspecteur
        statut, type_mime, corps, _c, _e = self.requete('/__ps_inspecteur_data',
                                                        self.cookie)
        self.assertEqual(statut, 200)
        self.assertIn('application/json', type_mime)
        donnees = json.loads(corps.decode('utf8'))
        self.assertEqual(donnees['langage'], 'piet')
        self.assertEqual(donnees['path'], str(self.chemin))
        self.assertEqual(len(donnees['codels']), 2)
        self.assertEqual(donnees['codels'][0]['rectangle'], [0, 0, 3, 1])
        self.assertEqual(donnees['codels'][1]['rectangle'], [0, 1, 3, 2])
        self.assertEqual(donnees['geometrie']['blocs'], 2)
        self.assertNotIn('actif', donnees['geometrie'],
                         'sans session de pas à pas, aucun bloc n’est actif')

    def test_donnees_avec_le_bloc_actif(self):
        """Une session de pas à pas en cours publie le bloc à surligner."""
        def inspecteur(chemin):
            return uri(PROGRAMME), [], BLOC_ACTIF

        self.apercu.inspecteur = inspecteur
        _s, _t, corps, _c, _e = self.requete('/__ps_inspecteur_data', self.cookie)
        donnees = json.loads(corps.decode('utf8'))
        self.assertEqual(donnees['geometrie']['actif']['index'], 1)
        self.assertEqual(donnees['geometrie']['actif']['commande'], 'push')
        # La liste des clefs de premier niveau ne dépend pas du langage : c'est
        # ce qui permet à la surcouche de traiter tous les aperçus de la même
        # façon. Le bloc actif est porté DANS « geometrie » pour cette raison.
        self.assertEqual(
            sorted(donnees),
            sorted(inspecteur_visuel.payload('html', 'x.html', '<p>a</p>')))

    def test_un_inspecteur_muet_ne_detruit_pas_l_image(self):
        """Un inspecteur qui lève ne doit ni casser l'aperçu, ni effacer l'image.

        Le repli relit le fichier : pour Piet il doit rapporter les OCTETS. Une
        lecture en texte remplacerait les octets invalides du PNG et
        l'inspecteur ne verrait plus aucun bloc de couleur.
        """
        def inspecteur(chemin):
            raise RuntimeError('analyse indisponible')

        self.apercu.inspecteur = inspecteur
        _s, _t, corps, _c, _e = self.requete('/__ps_inspecteur_data', self.cookie)
        donnees = json.loads(corps.decode('utf8'))
        self.assertEqual(donnees['langage'], 'piet')
        self.assertEqual(len(donnees['codels']), 2,
                         'le repli doit rendre les blocs, pas une image détruite')
        self.assertEqual(donnees['geometrie']['blocs'], 2)
        self.assertNotIn('actif', donnees['geometrie'],
                         'un inspecteur muet n’a aucune session à publier')

    def test_le_repli_porte_les_octets_d_un_programme_piet(self):
        chemin = self.ecrire('programme.png', PROGRAMME)
        contenu = self.apercu._lire_repli(chemin, 'piet')
        self.assertTrue(contenu.startswith('data:image/png;base64,'), contenu[:40])
        self.assertEqual(base64.b64decode(contenu.split(',', 1)[1]),
                         chemin.read_bytes())

    def test_le_repli_lisit_le_texte_des_autres_langages(self):
        chemin = self.projet / 'page.html'
        chemin.write_text('<p>accentué</p>', encoding='utf8')
        self.assertEqual(self.apercu._lire_repli(chemin, 'html'),
                         '<p>accentué</p>')

    def test_le_repli_d_un_fichier_absent_ne_leve_pas(self):
        self.assertEqual(self.apercu._lire_repli(self.projet / 'rien.png', 'piet'),
                         '')
        self.assertEqual(self.apercu._lire_repli(self.projet / 'rien.html', 'html'),
                         '')

    def test_les_diagnostics_du_moteur_sont_publies(self):
        """Une couleur hors palette doit apparaître dans la page d'aperçu."""
        image = [[ROUGE, INCONNUE, MAGENTA]]

        def inspecteur(chemin):
            return uri(image), []

        self.apercu.inspecteur = inspecteur
        _s, _t, corps, _c, _e = self.requete('/__ps_inspecteur_data', self.cookie)
        donnees = json.loads(corps.decode('utf8'))
        self.assertTrue(donnees['diagnostics'],
                        'une couleur hors palette doit produire un diagnostic')
        self.assertIn('hors des 20 couleurs',
                      donnees['diagnostics'][0]['message'])


class TestPayloadActif(unittest.TestCase):
    """payload() et donnees_json() avec un bloc actif."""

    def test_actif_ignoré_pour_un_autre_langage(self):
        donnees = inspecteur_visuel.payload('html', 'x.html', '<p>a</p>',
                                            actif=BLOC_ACTIF)
        self.assertNotIn('actif', donnees['geometrie'])

    def test_actif_recopié_sans_alias(self):
        donnees = inspecteur_visuel.payload('piet', 'x.png', uri(PROGRAMME),
                                            actif=BLOC_ACTIF)
        self.assertEqual(donnees['geometrie']['actif'], BLOC_ACTIF)
        donnees['geometrie']['actif']['index'] = 99
        self.assertEqual(BLOC_ACTIF['index'], 1,
                         'le payload ne doit pas partager le dictionnaire reçu')

    def test_donnees_json_accepte_cinq_arguments(self):
        texte = inspecteur_visuel.donnees_json('piet', 'x.png', uri(PROGRAMME),
                                               [], BLOC_ACTIF)
        self.assertEqual(json.loads(texte)['geometrie']['actif']['commande'],
                         'push')

    def test_aucun_actif_ne_change_rien(self):
        sans = inspecteur_visuel.payload('piet', 'x.png', uri(PROGRAMME))
        avec = inspecteur_visuel.payload('piet', 'x.png', uri(PROGRAMME),
                                         actif=None)
        self.assertEqual(sans, avec)


class TestSurcouche(unittest.TestCase):
    """Ce que le script et la feuille de style de la surcouche doivent contenir.

    Le comportement lui-même est vérifié hors navigateur par
    tests/smoke_inspecteur_piet.js ; ici on s'assure que les deux moitiés (Python
    qui publie les données, JavaScript qui les dessine) parlent des mêmes clefs.
    """

    def test_le_script_connaît_les_codels(self):
        for attendu in ('echelleCodel', 'tracerPiet', 'installerPiet',
                        'legendePiet', 'survolPiet', '__ps_piet_image',
                        'ps-codel-actif', '__ps_inspecteur_data'):
            self.assertIn(attendu, inspecteur_visuel.SCRIPT,
                          'la surcouche ne trace pas les blocs Piet (%s)' % attendu)

    def test_le_script_lit_le_bloc_actif_dans_geometrie(self):
        self.assertIn('geometrie&&', inspecteur_visuel.SCRIPT)
        self.assertIn('.actif', inspecteur_visuel.SCRIPT)

    def test_la_feuille_de_style_couvre_les_codels(self):
        for attendu in ('#__ps_inspecteur_piet', '.ps-codel',
                        '.ps-codel-actif', '#__ps_inspecteur_legende'):
            self.assertIn(attendu, inspecteur_visuel.STYLE)

    def test_la_page_piet_se_formate(self):
        page = web_preview.PIET_PAGE.format(href='/programme.png',
                                            nom='programme.png')
        self.assertIn('src="/programme.png"', page)
        self.assertIn('id="__ps_piet_image"', page)
        self.assertIn('</body>', page)

    def test_la_page_piet_echappe_le_nom(self):
        import html
        page = web_preview.PIET_PAGE.format(href='/a.png',
                                            nom=html.escape('<script>.png'))
        self.assertNotIn('<script>.png', page)


if __name__ == '__main__':
    unittest.main(verbosity=2)
