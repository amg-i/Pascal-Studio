"""Targeted checks; a real Ollama/model is not needed."""
import sys,unittest,json
from pathlib import Path
from unittest.mock import patch
AI=Path(__file__).resolve().parents[1]/'assistant-ia'
sys.path.insert(0,str(AI));sys.path.insert(1,str(AI/'vendor-python'))
import core,agent,isolation,skills

class AssistantSecurityTests(unittest.TestCase):
 def test_actions_depend_on_user_selected_mode(self):
  for t in ('write_file','run_command'):
   self.assertTrue(agent.needs_approval(t,False));self.assertFalse(agent.needs_approval(t,True))
 def test_agent_fail_closed(self):
  with patch.object(isolation,'status',return_value=(False,'isolation absente')):
   with patch.object(agent,'_helper',side_effect=AssertionError('should not execute')):
    r=agent.execute('write_file',{'path':'/tmp/no','content':'test'});self.assertFalse(r['ok']);self.assertIn('isolation',r['text'])
 def test_local_does_not_check_internet_or_search_web(self):
  with patch.object(core,'is_online',side_effect=AssertionError('network check forbidden')):
   with patch.object(core,'web_search',side_effect=AssertionError('network forbidden')):
    with patch.object(core,'stream_local',return_value=iter([('text','réponse locale')])):
     events=list(core.run([],"cherche sur internet",'local','auto',model_override='dolphin3:8b',web_allowed=False))
     self.assertTrue(any(x.get('model')=='dolphin3:8b' for x in events));self.assertTrue(any(x.get('t')=='réponse locale' for x in events))
 def test_no_auto_fallback_cloud_in_local(self):
  p=core.plan('code','local',True,'dolphin3:8b');self.assertEqual(p,[('local','dolphin3:8b')])
 def test_distinct_account_is_not_overridable_by_env(self):
  self.assertEqual(agent.AGENT_USER,'ps-ia-agent');self.assertEqual(agent.AGENT_WRAPPER,['sudo','-n','-H','-u','ps-ia-agent','--'])
 def test_skills_exist(self):
  all=skills.all_skills();self.assertTrue(any(s['name']=='explication' for s in all))

if __name__=='__main__':unittest.main()
