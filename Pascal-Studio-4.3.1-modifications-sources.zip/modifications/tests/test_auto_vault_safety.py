import os,subprocess,sys,tempfile,unittest
from pathlib import Path

class AutoVaultConcurrency(unittest.TestCase):
 def test_multiple_instances_and_atomic_initialization(self):
  with tempfile.TemporaryDirectory() as d:
   env=os.environ.copy();env['XDG_CONFIG_HOME']=d;env['PYTHONPATH']=str(Path(__file__).resolve().parent.parent)
   script='''from remote_vault import Vault
import os
v=Vault();v.enable_auto();n=os.environ["IDX"];v.put("ftp://server/",n,"","secret-"+n)
'''
   ps=[]
   for i in range(6):
    e=env.copy();e['IDX']=str(i);ps.append(subprocess.Popen([sys.executable,'-c',script],env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE))
   for p in ps:
    out,err=p.communicate(timeout=20);self.assertEqual(p.returncode,0,err.decode())
   check='''from remote_vault import Vault
v=Vault();assert v.status()["unlocked"]
for i in range(6):assert v.get("ftp://server/",str(i),"")=="secret-"+str(i)
'''
   subprocess.run([sys.executable,'-c',check],env=env,check=True,timeout=15)
