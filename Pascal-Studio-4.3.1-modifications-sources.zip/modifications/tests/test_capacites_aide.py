# -*- coding: utf-8 -*-
"""Catalogue des fonctionnalités : /api/aide/capacites et capacites_aide.py.

L'index de l'aide permet de chercher « quels langages puis-je déboguer pas à
pas ? ». Une telle réponse ne doit pas être recopiée dans l'aide : elle existe
déjà dans le registre, dans les capacités de débogage et dans l'état du bac à
sable. Ce module les réunit, et ces tests vérifient qu'il ne ment jamais — ni
dans un sens (annoncer ce qui manque) ni dans l'autre (taire ce qui existe).
"""

import unittest

import bac_a_sable
import capacites_aide
import debogueur_universel
import langages
import langages_esoteriques


class TestCatalogue(unittest.TestCase):
    def setUp(self):
        self.catalogue = capacites_aide.catalogue()
        self.par_langage = {f['langage']: f for f in self.catalogue['langages']}

    def test_un_langage_du_registre_par_entree(self):
        self.assertEqual(self.catalogue['total'], len(langages.tous()))
        self.assertEqual(sorted(self.par_langage), sorted(langages.tous()))

    def test_les_facettes_suivent_les_modules_competents(self):
        # Chaque facette doit pouvoir se justifier par le module qui fait autorité
        # sur son domaine, pour tous les langages, sans exception.
        for identifiant, fiche in self.par_langage.items():
            with self.subTest(langage=identifiant):
                debogage = debogueur_universel.capacites(identifiant)
                essai = bac_a_sable.etat(identifiant)
                attendues = set()
                if debogage['pas_a_pas']:
                    attendues.add('debogage')
                if debogage['points_arret']:
                    attendues.add('points')
                if debogage['variables']:
                    attendues.add('variables')
                if debogage['evaluation']:
                    attendues.add('evaluation')
                if essai.get('disponible') or fiche['graphique']:
                    attendues.add('execution')
                if langages.bibliotheque(identifiant):
                    attendues.add('completions')
                if langages.verificateur(identifiant):
                    attendues.add('analyse')
                if fiche['graphique'] or debogage['visuel']:
                    attendues.add('apercu')
                self.assertEqual(set(fiche['facettes']), attendues)

    def test_aucune_facette_inconnue(self):
        connues = {f['id'] for f in self.catalogue['fonctionnalites']}
        for fiche in self.catalogue['langages']:
            with self.subTest(langage=fiche['langage']):
                self.assertTrue(set(fiche['facettes']) <= connues,
                                set(fiche['facettes']) - connues)

    def test_les_deux_categories_couvrent_tout_le_registre(self):
        categories = {c['id'] for c in self.catalogue['categories']}
        self.assertEqual(categories, {'classique', 'esoterique'})
        for fiche in self.catalogue['langages']:
            self.assertIn(fiche['categorie'], categories)
        esoteriques = {f['langage'] for f in self.catalogue['langages']
                       if f['categorie'] == 'esoterique'}
        self.assertEqual(esoteriques, set(langages_esoteriques.ORDRE_ESOTERIQUES))

    def test_les_dix_langages_esoteriques_sont_debogables(self):
        # C'est le cœur de la 3.8.0 : ces dix langages n'ont aucun interpréteur
        # installé, leurs moteurs sont écrits dans le projet, et le pas à pas doit
        # être annoncé — sinon l'index les écarterait de la facette « débogage ».
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                fiche = self.par_langage[identifiant]
                self.assertIn('debogage', fiche['facettes'])
                self.assertIn('variables', fiche['facettes'])
                self.assertIn('completions', fiche['facettes'])
                self.assertIn('analyse', fiche['facettes'])
                self.assertTrue(fiche['debogage']['disponible'])
                self.assertEqual(fiche['debogage']['mode'],
                                 'visuel' if identifiant == 'piet' else 'reel')

    def test_piet_est_le_seul_esoterique_a_donner_un_apercu(self):
        avec_apercu = [f['langage'] for f in self.catalogue['langages']
                       if f['categorie'] == 'esoterique' and 'apercu' in f['facettes']]
        self.assertEqual(avec_apercu, ['piet'])
        self.assertTrue(self.par_langage['piet']['graphique'])

    def test_les_modes_internes_sont_traduits(self):
        # « reel » et « instrumente » ne veulent rien dire pour un utilisateur.
        for fiche in self.catalogue['langages']:
            with self.subTest(langage=fiche['langage']):
                mode = fiche['debogage']['mode']
                self.assertIn(mode, capacites_aide.LIBELLES_MODES)
                self.assertEqual(fiche['debogage']['libelle'],
                                 capacites_aide.LIBELLES_MODES[mode])
                self.assertNotIn(fiche['debogage']['libelle'], ('', mode))

    def test_les_modes_d_execution_sont_traduits(self):
        for fiche in self.catalogue['langages']:
            with self.subTest(langage=fiche['langage']):
                mode = fiche['execution']['mode']
                self.assertIn(mode, capacites_aide.LIBELLES_EXECUTION)
                self.assertEqual(fiche['execution']['libelle'],
                                 capacites_aide.LIBELLES_EXECUTION[mode])

    def test_le_message_d_indisponibilite_est_repris(self):
        # Un outil absent doit dire quoi installer, pas seulement « non ».
        fiche = self.par_langage['html']
        self.assertFalse(fiche['execution']['disponible'])
        self.assertIn('aperçu', fiche['execution']['message'])

    def test_extensions_et_libelles_viennent_du_registre(self):
        for identifiant, fiche in self.par_langage.items():
            with self.subTest(langage=identifiant):
                self.assertEqual(fiche['libelle'], langages.libelle(identifiant))
                self.assertEqual(fiche['extensions'],
                                 list(langages.extensions(identifiant)))

    def test_capacites_resout_les_alias_et_rend_none_sinon(self):
        self.assertEqual(capacites_aide.capacites('bf')['langage'], 'brainfuck')
        self.assertEqual(capacites_aide.capacites('Brainfuck')['langage'], 'brainfuck')
        self.assertEqual(capacites_aide.capacites('csharp')['langage'], 'cs')
        self.assertIsNone(capacites_aide.capacites('inexistant'))
        self.assertIsNone(capacites_aide.capacites(''))

    def test_par_facette_rend_des_libelles(self):
        debogables = capacites_aide.par_facette('debogage')
        self.assertTrue(debogables)
        self.assertIn('Brainfuck', debogables)
        self.assertIn('Piet', debogables)
        self.assertNotIn('JSON', debogables)
        for fiche in self.catalogue['langages']:
            self.assertEqual(fiche['libelle'] in debogables,
                             'debogage' in fiche['facettes'])

    def test_par_facette_refuse_une_facette_inconnue(self):
        self.assertEqual(capacites_aide.par_facette('inexistant'), [])
        self.assertEqual(capacites_aide.par_facette(''), [])

    def test_le_catalogue_est_serialisable(self):
        # La route le rend tel quel en JSON : un type non sérialisable casserait
        # l'index sans que rien ne le signale côté serveur.
        import json
        texte = json.dumps(self.catalogue, ensure_ascii=False)
        relues = json.loads(texte)
        self.assertEqual(relues['total'], self.catalogue['total'])
        self.assertIn('Ésotériques', texte)


class TestSansModulesOptionnels(unittest.TestCase):
    def test_l_absence_du_bac_a_sable_ne_casse_rien(self):
        # Le catalogue est lu par l'index de l'aide : une panne d'un module ne
        # doit pas priver l'utilisateur de toute l'aide.
        import builtins
        importeur = builtins.__import__

        def refuser(nom, *args, **kwargs):
            if nom in ('bac_a_sable', 'debogueur_universel'):
                raise ImportError('module absent')
            return importeur(nom, *args, **kwargs)

        builtins.__import__ = refuser
        self.addCleanup(setattr, builtins, '__import__', importeur)
        fiche = capacites_aide.capacites('brainfuck')
        self.assertEqual(fiche['libelle'], 'Brainfuck')
        self.assertFalse(fiche['debogage']['disponible'])
        self.assertFalse(fiche['execution']['disponible'])
        self.assertEqual(fiche['execution']['libelle'], '')
        self.assertIn('completions', fiche['facettes'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
