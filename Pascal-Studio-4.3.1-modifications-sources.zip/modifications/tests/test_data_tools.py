import json, sqlite3, tempfile, unittest
from pathlib import Path
from database_tools import Manager,DataError

class DataTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.m=Manager()
 def tearDown(self):self.m.close_all();self.tmp.cleanup()
 def file(self,name,content):p=self.root/name;p.write_text(content,encoding='utf8');return p
 def db(self):
  p=self.root/'main.db';c=sqlite3.connect(p);c.executescript('CREATE TABLE t(id INTEGER PRIMARY KEY,nom TEXT,nombre INTEGER); INSERT INTO t VALUES(1,"Ada",10); INSERT INTO t VALUES(2,"Bob",20); CREATE TABLE aucun(x TEXT); CREATE TABLE "weird""table"(id INTEGER PRIMARY KEY, value TEXT); INSERT INTO "weird""table" VALUES(1,"x");');c.close();return p
 def test_csv_preserves_semicolon_and_refuses_conflicts(self):
  p=self.file('table.csv','id;nom\n1;Ada\n2;Bob\n');s=self.m.open_file(p);self.assertEqual(s['delimiter'],';');self.assertEqual(s['rows'][1][1],'Ada');s['rows'][1][1]='Éléonore';r=self.m.save_file(s['id'],s['revision'],{'rows':s['rows']});self.assertIn('1;Éléonore',p.read_text());p.write_text('changement extérieur');
  with self.assertRaisesRegex(DataError,'changé'):self.m.save_file(s['id'],r['revision'],{'rows':s['rows']})
  self.assertEqual(p.read_text(),'changement extérieur')
 def test_json_validation_and_sql_file(self):
  p=self.file('data.json','[{"nom":"Ada"}]');s=self.m.open_file(p)
  with self.assertRaisesRegex(DataError,'JSON invalide'):self.m.save_file(s['id'],s['revision'],{'text':'{invalide'})
  self.assertEqual(p.read_text(),'[{"nom":"Ada"}]');r=self.m.save_file(s['id'],s['revision'],{'text':'{"ok":true}'});self.assertEqual(json.loads(p.read_text()),{'ok':True});q=self.file('script.sql','select 1;');ss=self.m.open_file(q);self.m.save_file(ss['id'],ss['revision'],{'text':'select 2;'});self.assertEqual(q.read_text(),'select 2;')
 def test_sqlite_row_updates_inserts_deletes_and_conflict_rollback(self):
  p=self.db();s=self.m.open_file(p);sid=s['id'];tables=self.m.list_tables(sid)['tables'];self.assertIn('t',[t['name'] for t in tables]);data=self.m.rows(sid,'','t');self.assertTrue(data['editable']);one,two=data['rows'];self.m.apply(sid,'','t',[{'original':one,'changes':{'nom':'Eve'}},{'insert':{'id':3,'nom':'Zoe','nombre':30}}]);after=self.m.rows(sid,'','t');self.assertEqual(after['rows'][0],[1,'Eve',10]);self.assertEqual(len(after['rows']),3)
  with self.assertRaisesRegex(DataError,'Conflit'):self.m.apply(sid,'','t',[{'original':two,'changes':{'nombre':40}},{'original':one,'changes':{'nom':'BAD'}}])
  self.assertEqual(self.m.rows(sid,'','t')['rows'][1],[2,'Bob',20]);self.m.apply(sid,'','t',[{'original':two,'delete':True}]);self.assertEqual(len(self.m.rows(sid,'','t')['rows']),2)
  self.assertFalse(self.m.rows(sid,'','aucun')['editable']);w=self.m.rows(sid,'','weird"table');self.m.apply(sid,'','weird"table',[{'original':w['rows'][0],'changes':{'value':'ok'}}]);self.assertEqual(self.m.rows(sid,'','weird"table')['rows'][0][1],'ok')
 def test_sql_query_rollback_and_commit(self):
  sid=self.m.open_file(self.db())['id'];self.m.query(sid,"UPDATE t SET nombre=99 WHERE id=1",False);self.assertEqual(self.m.rows(sid,'','t')['rows'][0][2],10);self.m.query(sid,"UPDATE t SET nombre=99 WHERE id=1",True);self.assertEqual(self.m.rows(sid,'','t')['rows'][0][2],99);r=self.m.query(sid,'SELECT nom,nombre FROM t ORDER BY id');self.assertEqual(r['rows'][0],['Ada',99])
 def test_create_database_without_overwriting(self):
  p=self.root/'new.sqlite';s=self.m.create_sqlite(p);self.assertTrue(p.exists());self.assertEqual(self.m.list_tables(s['id'])['tables'],[])
  with self.assertRaisesRegex(DataError,'existe déjà'):self.m.create_sqlite(p)
 def test_reparse_csv_and_invalid_constant(self):
  p=self.file('ambiguous.csv','alpha|beta\n1|deux\n');s=self.m.open_file(p);r=self.m.reparse_csv(s['id'],'|');self.assertEqual(r['rows'][1],['1','deux'])
  with self.assertRaisesRegex(DataError,'séparateur|Séparateur'):self.m.reparse_csv(s['id'],'#')
  j=self.file('value.json','{}');obj=self.m.open_file(j)
  with self.assertRaises(DataError):self.m.save_file(obj['id'],obj['revision'],{'text':'{"x":NaN}'})
 def test_testmode_sqlite_ddl_is_rolled_back(self):
  sid=self.m.open_file(self.db())['id'];self.m.query(sid,'CREATE TABLE temporaire(x TEXT)',False);self.assertNotIn('temporaire',[x['name'] for x in self.m.list_tables(sid)['tables']])
 def test_reject_remote_without_tls(self):
  with self.assertRaisesRegex(DataError,'locales'):self.m.connect({'kind':'postgres','host':'example.com','database':'x','user':'x','password':'x','tls':False})
 def test_no_primary_key_is_read_only(self):
  sid=self.m.open_file(self.db())['id'];self.assertFalse(self.m.rows(sid,'','aucun')['editable']);
  with self.assertRaisesRegex(DataError,'lecture seule'):self.m.apply(sid,'','aucun',[{'insert':{'x':'no'}}])
if __name__=='__main__':unittest.main()
