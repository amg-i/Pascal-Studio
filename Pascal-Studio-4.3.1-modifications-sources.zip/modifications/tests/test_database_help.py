"""Vérifie la structure de l’aide et des exemples SQLite/JSON hors ligne."""
import json, runpy, sqlite3, unittest
from pathlib import Path
D=runpy.run_path(str(Path(__file__).resolve().parents[1]/'database-help-source.py'))
ARTICLES=D['articles'];LANGUAGES=D['languages']
class TestDatabaseHelp(unittest.TestCase):
 def test_catalogue_and_introductions(self):
  self.assertEqual(len(ARTICLES),292);self.assertEqual(len(set(a['id'] for a in ARTICLES)),len(ARTICLES))
  for lang in LANGUAGES:
   intro=[a for a in ARTICLES if a['lang']==lang and a['intro']]
   self.assertEqual(len(intro),1);self.assertIn('util',intro[0]['blocks'][0]['text'].lower())
  for a in ARTICLES:
   if not a['intro']:self.assertTrue(a['blocks'][0]['text'] and a['blocks'][1]['code'],a['title'])
 def test_json_data_examples(self):
  tests=[a for a in ARTICLES if a['lang']=='JSON' and a['group']=='Types et syntaxe']
  self.assertGreater(len(tests),10)
  for a in tests:
   with self.subTest(title=a['title']):json.loads(a['blocks'][1]['code'])
 def test_sqlite_select_examples(self):
  tests=[]
  for a in ARTICLES:
   if a['lang'] not in ('SQL','SQLite') or a['intro']:continue
   sql=a['blocks'][1]['code'].strip()
   if sql.upper().startswith(('SELECT ','WITH ','EXPLAIN QUERY PLAN ','PRAGMA ')):tests.append((a['title'],sql))
  self.assertGreater(len(tests),70)
  for title,sql in tests:
   with self.subTest(title=title):
    conn=sqlite3.connect(':memory:')
    try:
     conn.executescript("CREATE TABLE clients(id INTEGER PRIMARY KEY,nom TEXT,ville TEXT,age INT); INSERT INTO clients VALUES(1,'Alice','Paris',30),(2,'Bob','Lyon',20); CREATE TABLE commandes(id INTEGER PRIMARY KEY,client_id INT,montant NUMERIC); INSERT INTO commandes VALUES(1,1,12.4); CREATE TABLE archives_clients(id INT,nom TEXT);")
     conn.execute(sql).fetchmany(5)
    finally:conn.close()
if __name__=='__main__':unittest.main()
