# -*- coding: utf-8 -*-
"""Session de débogage des dix langages ésotériques (DebogueurEsoterique).

Ces moteurs sont des machines à pas natives : aucun processus enfant, aucune
sonde injectée, aucun interpréteur externe — ce qui compte, puisqu'aucun de ces
dix langages n'est paqueté pour Debian 13.

Ce banc couvre ce que tests/smoke_facade.py ne peut pas voir : le routage depuis
debug_mux.py, le protocole attendu par l'interface (snapshot/action/evaluate/
input/stop), la lecture d'un PNG binaire pour Piet, et la protection contre la
croissance non bornée des entiers.

Lancer :  cd modifications && PYTHONPATH=$PWD python3 -m unittest \
              tests.test_debogueur_esoterique -v
"""
import base64
import shutil
import tempfile
import unittest
from pathlib import Path

import debogueur_universel
import langages_esoteriques
from debug_mux import DebuggerMux
from debogueur_universel import DebogueurEsoterique

EXTENSIONS = {
    'brainfuck': '.bf', 'whitespace': '.ws', 'piet': '.png', 'lolcode': '.lol',
    'arnoldc': '.arnoldc', 'chef': '.chef', 'shakespeare': '.spl',
    'intercal': '.i', 'fractran': '.fra', 'malbolge': '.mal',
}

# Clefs de l'instantané que l'interface graphique consomme. Elles doivent être
# identiques à celles du débogueur instrumenté, sinon le panneau de débogage ne
# s'y retrouve plus.
CLEFS_INSTANTANE = {'active', 'state', 'reason', 'frame', 'frames', 'variables',
                    'output', 'message', 'breakpoints'}

ACTIONS = ('continue', 'next', 'step', 'finish', 'pause')


class BaseSession(unittest.TestCase):
    """Un projet temporaire, un fichier par langage, une session fraîche."""

    def setUp(self):
        self.racine = Path(tempfile.mkdtemp(prefix='ps-debog-eso-'))
        self.addCleanup(shutil.rmtree, self.racine, True)

    def ecrire(self, identifiant, code, nom=None):
        """Écrit un programme et rend sa clef relative au projet.

        Piet est écrit en OCTETS : son programme est un PNG binaire, et c'est
        précisément le cas que la session doit savoir lire.
        """
        cle = nom or ('programme_%s%s' % (identifiant, EXTENSIONS[identifiant]))
        chemin = self.racine / cle
        if identifiant == 'piet':
            chemin.write_bytes(base64.b64decode(code.split(',', 1)[1]))
        else:
            chemin.write_text(code, encoding='utf8')
        return cle

    def ouvrir(self, identifiant, code, nom, lignes=None):
        """Écrit le programme, puis ouvre une session avec des points d'arrêt.

        Les points d'arrêt sont donnés par NUMÉRO DE LIGNE : le fichier est écrit
        avant, donc la clef utilisée existe déjà. Construire la liste de points
        dans le même appel que celui qui rend la clef est le piège évident ici.
        """
        cle = self.ecrire(identifiant, code, nom)
        multiplexe = DebuggerMux(str(self.racine), {})
        multiplexe.select(identifiant)
        multiplexe.demarrer(identifiant, cle,
                            [{'path': cle, 'line': l} for l in (lignes or [])])
        return multiplexe, cle

    def session(self, identifiant, code, points=None, nom=None):
        cle = self.ecrire(identifiant, code, nom)
        multiplexe = DebuggerMux(str(self.racine), {})
        multiplexe.select(identifiant)
        multiplexe.demarrer(identifiant, cle, points if points is not None else [])
        return multiplexe, cle


class TestRoutage(BaseSession):
    def test_les_dix_langages_sont_routes_vers_la_session_integree(self):
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                multiplexe = DebuggerMux(str(self.racine), {})
                self.assertTrue(multiplexe._esoterique(identifiant))
                multiplexe.select(identifiant)
                self.assertIsInstance(multiplexe.current, DebogueurEsoterique)

    def test_le_libelle_affiche_resout_autant_que_l_identifiant(self):
        # L'interface envoie parfois le libellé (« Brainfuck ») plutôt que
        # l'identifiant du registre.
        multiplexe = DebuggerMux(str(self.racine), {})
        self.assertTrue(multiplexe._esoterique('Brainfuck'))
        self.assertTrue(multiplexe._esoterique('bf'))

    def test_un_langage_ordinaire_n_est_pas_route_ici(self):
        multiplexe = DebuggerMux(str(self.racine), {})
        self.assertFalse(multiplexe._esoterique('python'))
        self.assertFalse(multiplexe._esoterique('pascal'))
        multiplexe.select('python')
        self.assertNotIsInstance(multiplexe.current, DebogueurEsoterique)

    def test_piet_est_visuel_mais_debogable(self):
        # Piet est en mode visuel, pas en mode réel : le routage ne doit pas se
        # fonder sur le mode, sinon Piet serait le seul des dix à passer à côté.
        self.assertEqual(debogueur_universel.mode('piet'),
                         debogueur_universel.MODE_VISUEL)
        self.assertTrue(debogueur_universel.capacites('piet')['pas_a_pas'])
        multiplexe = DebuggerMux(str(self.racine), {})
        self.assertTrue(multiplexe._esoterique('piet'))


class TestDemarrage(BaseSession):
    def test_la_session_s_ouvre_avant_la_premiere_instruction(self):
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                multiplexe, _ = self.session(
                    identifiant, langages_esoteriques.apercu_programme(identifiant))
                instantane = multiplexe.snapshot()
                self.assertEqual(instantane['state'], 'paused')
                self.assertTrue(instantane['active'])
                self.assertEqual(multiplexe.current.moteur.pas_fait, 0)
                multiplexe.stop()

    def test_l_instantane_a_les_memes_clefs_que_le_debogueur_instrumente(self):
        multiplexe, _ = self.session('brainfuck', '++++++++[>+++++++++<-]>.')
        # L\'instantané ésotérique doit CONTENIR toutes les clefs de
        # l\'instrumenté : la surcouche n\'a pas à savoir quel débogueur répond.
        # « visuel » s\'y ajoute, pour surligner l\'image Piet.
        manque = CLEFS_INSTANTANE - set(multiplexe.snapshot())
        self.assertFalse(manque, 'clefs absentes : %s' % sorted(manque))
        self.assertIn('visuel', multiplexe.snapshot())
        reference = debogueur_universel.DebogueurInstrumente(str(self.racine), {})
        self.assertEqual(set(reference.snapshot()), CLEFS_INSTANTANE)
        multiplexe.stop()

    def test_piet_est_lu_comme_un_png_binaire(self):
        # read_text(..., 'replace') sur un PNG détruirait l'image : la session
        # doit lire des octets et les porter en data URI.
        code = langages_esoteriques.apercu_programme('piet')
        multiplexe, _ = self.session('piet', code)
        self.assertTrue(multiplexe.current.moteur.code.startswith('data:image/png;base64,'))
        multiplexe.action('finish')
        self.assertEqual(multiplexe.snapshot()['output'], 'A')
        multiplexe.stop()

    def test_un_programme_invalide_est_refuse_avec_les_lignes_fautives(self):
        cle = self.ecrire('brainfuck', '+++[')
        multiplexe = DebuggerMux(str(self.racine), {})
        multiplexe.select('brainfuck')
        with self.assertRaises(ValueError) as leve:
            multiplexe.demarrer('brainfuck', cle, [])
        self.assertIn('Programme refusé', str(leve.exception))
        self.assertIn('ligne', str(leve.exception))

    def test_fichier_absent(self):
        multiplexe = DebuggerMux(str(self.racine), {})
        multiplexe.select('brainfuck')
        with self.assertRaises(ValueError):
            multiplexe.demarrer('brainfuck', 'inexistant.bf', [])

    def test_langage_non_esoterique_refuse_par_la_session(self):
        with self.assertRaises(ValueError):
            DebogueurEsoterique(str(self.racine), {}).start('python', 'x.py', [])

    def test_deuxieme_demarrage_refuse_tant_que_la_session_est_active(self):
        multiplexe, cle = self.session('brainfuck', '+++++.')
        with self.assertRaises(ValueError):
            multiplexe.current.start('brainfuck', cle, [])
        multiplexe.stop()


class TestPasAPas(BaseSession):
    def test_le_pas_a_pas_termine_les_dix_apercus(self):
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                code = langages_esoteriques.apercu_programme(identifiant)
                multiplexe, _ = self.session(identifiant, code)
                tours = 0
                while multiplexe.snapshot()['state'] == 'paused' and tours < 5000:
                    multiplexe.action('step')
                    tours += 1
                instantane = multiplexe.snapshot()
                self.assertEqual(instantane['state'], 'exited', instantane['message'])
                self.assertEqual(instantane['reason'], 'exited')
                self.assertFalse(instantane['active'])
                # La sortie du pas à pas doit être celle de l'exécution directe.
                self.assertEqual(instantane['output'],
                                 langages_esoteriques.executer(code, identifiant)['sortie'])
                multiplexe.stop()

    def test_les_variables_restent_lisibles_apres_la_fin(self):
        # Pour FRACTRAN le résultat EST l'état final : l'effacer à la fin, comme
        # le fait le débogueur instrumenté, priverait l'utilisateur du seul
        # résultat qui compte.
        multiplexe, _ = self.session('fractran', 'n = 2\n3/2')
        multiplexe.action('finish')
        valeurs = {v['name']: v['value'] for v in multiplexe.snapshot()['variables']}
        self.assertEqual(valeurs.get('n (état)'), '3')
        multiplexe.stop()

    def test_visuel_suit_le_bloc_piet(self):
        """Piet est une image : chaque pas doit dire quel bloc s\'exécute.

        C\'est ce qui permet à la surcouche de surligner le rectangle actif. Le
        bloc #0 de l\'aperçu est rouge clair et ne fait rien ; le pas suivant
        entre dans le rouge foncé et empile la taille du bloc quitté.
        """
        multiplexe, _ = self.session('piet',
                                     langages_esoteriques.apercu_programme('piet'))
        visuel = multiplexe.snapshot()['visuel']
        self.assertIsNotNone(visuel)
        self.assertEqual(visuel['index'], 0)
        self.assertEqual(visuel['rectangle'], [0, 0, 65, 1])
        self.assertEqual(visuel['commande'], 'rien')
        self.assertEqual(visuel['rvb'], '#FF0000')
        multiplexe.action('step')
        suivant = multiplexe.snapshot()['visuel']
        self.assertEqual(suivant['index'], 1)
        self.assertEqual(suivant['commande'], 'push')
        self.assertEqual(suivant['rectangle'], [65, 0, 66, 1])
        multiplexe.stop()

    def test_visuel_vide_pour_les_neuf_moteurs_texte(self):
        """Aucun des neuf moteurs texte n\'a d\'image à surligner."""
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            if identifiant == 'piet':
                continue
            with self.subTest(langage=identifiant):
                multiplexe, _ = self.session(
                    identifiant, langages_esoteriques.apercu_programme(identifiant))
                self.assertIsNone(multiplexe.snapshot()['visuel'])
                multiplexe.stop()

    def test_visuel_reinitialise_a_l_arret(self):
        multiplexe, _ = self.session('piet',
                                     langages_esoteriques.apercu_programme('piet'))
        self.assertIsNotNone(multiplexe.snapshot()['visuel'])
        multiplexe.stop()
        self.assertIsNone(multiplexe.snapshot()['visuel'])

    def test_next_et_step_sont_equivalents(self):
        # Ces moteurs ne rendent qu'un seul cadre d'appel : il n'y a pas de pas
        # « par-dessus » à distinguer d'un pas « dedans ».
        code = '++++++++[>+++++++++<-]>.'
        premier, _ = self.session('brainfuck', code, nom='a.bf')
        second, _ = self.session('brainfuck', code, nom='b.bf')
        for _ in range(5):
            premier.action('step')
            second.action('next')
        self.assertEqual(premier.current.moteur.pas_fait,
                         second.current.moteur.pas_fait)
        premier.stop()
        second.stop()

    def test_pause_est_sans_effet_et_le_dit(self):
        multiplexe, _ = self.session('brainfuck', '+++++.')
        multiplexe.action('pause')
        self.assertEqual(multiplexe.snapshot()['state'], 'paused')
        self.assertIn('chaque instruction', multiplexe.snapshot()['message'])
        multiplexe.stop()

    def test_action_inconnue(self):
        multiplexe, _ = self.session('brainfuck', '+++++.')
        with self.assertRaises(ValueError):
            multiplexe.action('reculer')
        multiplexe.stop()

    def test_action_sans_session(self):
        for action in ACTIONS:
            with self.subTest(action=action):
                with self.assertRaises(ValueError):
                    DebogueurEsoterique(str(self.racine), {}).action(action)


class TestPointsArret(BaseSession):
    def test_un_point_d_arret_est_honore(self):
        # Un programme sur DEUX lignes : le point d'arrêt porte sur la seconde,
        # donc « continuer » doit s'y arrêter et non aller au bout.
        multiplexe, cle = self.ouvrir('brainfuck', '+++++.\n+++++>+++[<+>-]<.',
                                      'deux_lignes.bf', lignes=[2])
        self.assertEqual(len(multiplexe.snapshot()['breakpoints']), 1)
        self.assertEqual(multiplexe.snapshot()['breakpoints'][0]['path'], cle)
        multiplexe.action('continue')
        instantane = multiplexe.snapshot()
        self.assertEqual(instantane['state'], 'paused')
        self.assertEqual(instantane['reason'], 'breakpoint')
        self.assertEqual(instantane['frame']['line'], 2)
        self.assertEqual(instantane['output'], chr(5))
        multiplexe.stop()

    def test_sur_un_programme_d_une_seule_ligne_le_point_est_rejoue(self):
        # Cas réel et contre-intuitif : la plupart des programmes Brainfuck ou
        # Whitespace tiennent sur une ligne. Chaque pas y « repasse », donc
        # continuer ré-arrête aussitôt. Ce n'est pas une boucle infinie : le pas
        # est exécuté AVANT le contrôle, donc le programme avance bien.
        multiplexe, cle = self.ouvrir('brainfuck', '++++++++[>+++++++++<-]>.',
                                      'une_ligne.bf', lignes=[1])
        for attendu in (1, 2, 3):
            multiplexe.action('continue')
            self.assertEqual(multiplexe.snapshot()['reason'], 'breakpoint')
            self.assertEqual(multiplexe.current.moteur.pas_fait, attendu)
        multiplexe.action('finish')
        self.assertEqual(multiplexe.snapshot()['output'], 'H')
        multiplexe.stop()

    def test_ajouter_et_retirer_un_point_d_arret(self):
        multiplexe, cle = self.session('brainfuck', '+++++.\n+++++.', nom='ba.bf')
        multiplexe.add_breakpoint(cle, 2)
        self.assertEqual([b['line'] for b in multiplexe.snapshot()['breakpoints']], [2])
        multiplexe.remove_breakpoint(cle, 2)
        self.assertEqual(multiplexe.snapshot()['breakpoints'], [])
        multiplexe.stop()

    def test_aucun_point_d_arret_n_est_exige(self):
        # Contrairement au débogueur instrumenté, qui refuse de démarrer sans
        # point d'arrêt : ici la session s'ouvre arrêtée avant la première
        # instruction, ce qui montre l'état initial.
        multiplexe, _ = self.session('whitespace',
                                     langages_esoteriques.apercu_programme('whitespace'))
        self.assertEqual(multiplexe.snapshot()['breakpoints'], [])
        self.assertEqual(multiplexe.snapshot()['state'], 'paused')
        multiplexe.stop()

    def test_ligne_invalide(self):
        multiplexe, cle = self.session('brainfuck', '+++++.', nom='ligne.bf')
        with self.assertRaises(ValueError):
            multiplexe.add_breakpoint(cle, 0)
        with self.assertRaises(ValueError):
            multiplexe.add_breakpoint('', 1)
        multiplexe.stop()


class TestEvaluationEtEntree(BaseSession):
    def test_evaluate_rend_une_variable_par_nom_exact(self):
        multiplexe, _ = self.session('lolcode', 'HAI\nI HAS A x ITZ 5\nVISIBLE x\nKTHXBYE')
        multiplexe.action('step')
        multiplexe.action('step')
        self.assertEqual(multiplexe.evaluate('x'), '5')
        multiplexe.stop()

    def test_evaluate_accepte_un_nom_partiel(self):
        multiplexe, _ = self.session('whitespace',
                                     langages_esoteriques.apercu_programme('whitespace'))
        valeur = multiplexe.evaluate('pile')
        self.assertIsInstance(valeur, str)
        multiplexe.stop()

    def test_evaluate_inconnu_propose_les_noms_disponibles(self):
        multiplexe, _ = self.session('fractran', 'n = 2\n3/2')
        with self.assertRaises(ValueError) as leve:
            multiplexe.evaluate('inexistant')
        self.assertIn('n (état)', str(leve.exception))
        multiplexe.stop()

    def test_evaluate_sans_session(self):
        with self.assertRaises(ValueError):
            DebogueurEsoterique(str(self.racine), {}).evaluate('x')

    def test_input_alimente_un_programme_arrete_sur_une_lecture(self):
        multiplexe, _ = self.session(
            'lolcode',
            'HAI\nCAN HAS STDIO?\nI HAS A s ITZ ""\nGIMMEH s\nVISIBLE s\nKTHXBYE')
        multiplexe.input('bonjour')
        multiplexe.action('finish')
        self.assertEqual(multiplexe.snapshot()['output'], 'bonjour\n')
        multiplexe.stop()

    def test_input_ajoute_le_saut_de_ligne_manquant(self):
        # GIMMEH lit une LIGNE : sans saut de ligne il lirait jusqu'à la fin de
        # l'entrée. Le comportement est aligné sur les autres débogueurs.
        multiplexe, _ = self.session('brainfuck', ',.')
        multiplexe.input('A')
        entree = multiplexe.current.moteur.entree
        self.assertTrue(entree.texte.endswith('\n'))
        multiplexe.stop()

    def test_input_sans_session(self):
        with self.assertRaises(ValueError):
            DebogueurEsoterique(str(self.racine), {}).input('x')


class TestGardeFous(BaseSession):
    def test_la_capacite_maximale_arrete_la_session_sans_lever(self):
        # Le chemin du pas à pas n'est PAS protégé par executer() : sans cette
        # prise en charge, une boucle qui multiplie une valeur par elle-même
        # lèverait jusque dans la route HTTP.
        multiplexe, _ = self.session('fractran', 'n = 1\n2/1')
        multiplexe.action('continue')
        instantane = multiplexe.snapshot()
        self.assertEqual(instantane['state'], 'exited')
        self.assertIn('Capacité dépassée', instantane['message'])
        multiplexe.stop()

    def test_le_budget_d_une_action_est_borne(self):
        # Le « cat » publié de Malbolge ne se termine jamais : une action ne doit
        # pas pouvoir immobiliser le serveur.
        self.assertEqual(DebogueurEsoterique.PAS_PAR_ACTION, 200_000)
        self.assertLessEqual(DebogueurEsoterique.PAS_PAR_ACTION,
                             langages_esoteriques.LIMITE_PAS)

    def test_stop_remet_tout_au_repos(self):
        multiplexe, _ = self.session('brainfuck', '+++++.')
        multiplexe.action('step')
        multiplexe.stop()
        instantane = multiplexe.snapshot()
        self.assertEqual(instantane['state'], 'idle')
        self.assertFalse(instantane['active'])
        self.assertEqual(instantane['variables'], [])
        self.assertIsNone(multiplexe.current.moteur)
        # Une nouvelle session doit pouvoir démarrer aussitôt.
        multiplexe.select('brainfuck')
        cle = self.ecrire('brainfuck', '+++++.', nom='apres_stop.bf')
        multiplexe.demarrer('brainfuck', cle, [])
        self.assertEqual(multiplexe.snapshot()['state'], 'paused')
        multiplexe.stop()


if __name__ == '__main__':
    unittest.main(verbosity=2)
