"""Tests du débogage uniforme : modes, capacités, canal de contrôle, pilotes."""

import os
import shutil
import subprocess
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import debogueur_universel as D
import langages


def attendre(get, valeur, tentatives=100, pas=0.05):
    for _ in range(tentatives):
        if get() == valeur:
            return True
        time.sleep(pas)
    return False


class TestModesEtCapacites(unittest.TestCase):
    def test_chaque_langage_a_un_mode(self):
        modes = D.tous_les_modes()
        self.assertEqual(len(modes), len(langages.tous()))
        for identifiant, m in modes.items():
            self.assertIn(m, (D.MODE_REEL, D.MODE_INSTRUMENTE, D.MODE_VISUEL,
                              D.MODE_TRACE, D.MODE_AUCUN), identifiant)

    def test_langages_graphiques_en_mode_visuel(self):
        for identifiant in ('html', 'css', 'svg', 'latex', 'markdown', 'xml'):
            self.assertEqual(D.mode(identifiant), D.MODE_VISUEL, identifiant)
            self.assertTrue(D.capacites(identifiant)['visuel'], identifiant)

    def test_langages_à_moteur_réel(self):
        for identifiant in ('pascal', 'c', 'cpp', 'rust', 'fortran', 'python',
                            'javascript', 'php', 'go', 'ruby', 'swift', 'kotlin'):
            self.assertEqual(D.mode(identifiant), D.MODE_REEL, identifiant)

    def test_langages_instrumentés(self):
        for identifiant in ('shell', 'perl', 'basic', 'lua', 'ocaml'):
            self.assertEqual(D.mode(identifiant), D.MODE_INSTRUMENTE, identifiant)

    def test_langages_en_mode_tracé(self):
        for identifiant in ('cs', 'make', 'cmake'):
            self.assertEqual(D.mode(identifiant), D.MODE_TRACE, identifiant)

    def test_langages_sans_débogage(self):
        for identifiant in ('csproj', 'json', 'plaintext'):
            self.assertEqual(D.mode(identifiant), D.MODE_AUCUN, identifiant)
            self.assertFalse(D.capacites(identifiant)['disponible'], identifiant)

    def test_plus_aucun_langage_refusé_silencieusement(self):
        """La 3.6.0 refusait 19 langages sur 29 ; il ne doit plus en rester."""
        sans_mode = [i for i in langages.tous() if D.mode(i) == D.MODE_AUCUN]
        self.assertEqual(sorted(sans_mode), ['csproj', 'json', 'plaintext'])

    def test_capacites_du_mode_réel(self):
        c = D.capacites('pascal')
        self.assertTrue(c['pas_a_pas'])
        self.assertTrue(c['variables'])
        self.assertTrue(c['pile'])
        self.assertTrue(c['evaluation'])
        self.assertFalse(c['visuel'])
        self.assertEqual(c['moteur'], 'gdb')

    def test_capacites_du_mode_visuel(self):
        c = D.capacites('css')
        self.assertTrue(c['visuel'])
        self.assertFalse(c['pas_a_pas'])
        self.assertTrue(c['points_arret'])
        self.assertIn('inspecteur visuel', c['explication'])

    def test_capacites_du_mode_tracé(self):
        c = D.capacites('make')
        self.assertFalse(c['pas_a_pas'])
        self.assertTrue(c['execution'])
        self.assertIn('tracée', c['explication'])

    def test_capacites_langage_inconnu(self):
        c = D.capacites('inexistant')
        self.assertEqual(c['mode'], D.MODE_AUCUN)
        self.assertFalse(c['disponible'])

    def test_capacites_accepte_une_extension(self):
        self.assertEqual(D.mode('.sh'), D.mode('shell'))
        self.assertEqual(D.mode('.pl'), D.mode('perl'))

    def test_perl_annonce_sa_limite(self):
        if not shutil.which('perl'):
            self.skipTest('perl absent')
        self.assertIn('lexicales', D.capacites('perl')['explication'])

    def test_installation_proposée_quand_gdb_manque(self):
        with mock.patch.object(D.shutil, 'which', return_value=None):
            self.assertIn('gdb', D.capacites('pascal')['installation'])

    def test_chaque_capacite_a_une_explication(self):
        for identifiant in langages.tous():
            self.assertTrue(D.capacites(identifiant)['explication'], identifiant)


class TestCanalDeControle(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='ps-canal-')
        self.dossier = Path(self.temporary.name)
        self.canal = D.CanalDeControle(self.dossier)
        self.canal.ouvrir()

    def tearDown(self):
        self.canal.fermer()
        self.temporary.cleanup()

    def test_les_fifo_sont_créées(self):
        self.assertTrue(os.path.exists(self.canal.chemin_evenements))
        self.assertTrue(os.path.exists(self.canal.chemin_commandes))

    def test_ouvrir_ne_bloque_pas(self):
        """Sans O_RDWR des deux côtés, l'ouverture d'une FIFO bloque."""
        debut = time.monotonic()
        canal = D.CanalDeControle(Path(tempfile.mkdtemp()))
        canal.ouvrir()
        self.assertLess(time.monotonic() - debut, 2)
        canal.fermer()

    def test_lire_renvoie_none_à_l_échéance(self):
        debut = time.monotonic()
        self.assertIsNone(self.canal.lire(0.2))
        self.assertLess(time.monotonic() - debut, 1.5)

    def test_une_ligne_écrite_est_lue(self):
        os.write(self.canal.evenements, b'STOP 4 main\n')
        self.assertEqual(self.canal.lire(1), 'STOP 4 main')

    def test_plusieurs_lignes_d_un_seul_bloc_sont_toutes_lues(self):
        """Le défaut majeur : un tampon local perdait la fin du bloc."""
        os.write(self.canal.evenements, b'VAR a=1\nVAR b=2\nSTOP 4 main\n')
        recus = [self.canal.lire(1) for _ in range(3)]
        self.assertEqual(recus, ['VAR a=1', 'VAR b=2', 'STOP 4 main'])

    def test_une_ligne_arrivée_en_deux_morceaux(self):
        os.write(self.canal.evenements, b'STOP ')
        os.write(self.canal.evenements, b'4 main\n')
        self.assertEqual(self.canal.lire(1), 'STOP 4 main')

    def test_envoyer_écrit_une_ligne(self):
        self.canal.envoyer('continue')
        os.set_blocking(self.canal.commandes, True)
        self.assertEqual(os.read(self.canal.commandes, 64), b'continue\n')

    def test_envoyer_sur_canal_fermé(self):
        self.canal.fermer()
        with self.assertRaises(ValueError):
            self.canal.envoyer('continue')

    def test_lire_sur_canal_fermé(self):
        self.canal.fermer()
        self.assertIsNone(self.canal.lire(0.1))

    def test_fermer_est_idempotent(self):
        self.canal.fermer()
        self.canal.fermer()


class CasDebogueur(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='ps-deb-')
        self.racine = Path(self.temporary.name)
        self.debogueur = D.DebogueurInstrumente(self.racine)

    def tearDown(self):
        self.debogueur.stop()
        self.temporary.cleanup()

    def ecrire(self, nom, contenu):
        chemin = self.racine / nom
        chemin.parent.mkdir(parents=True, exist_ok=True)
        chemin.write_text(contenu, encoding='utf8')
        return chemin


class TestInterfaceCommune(CasDebogueur):
    def test_snapshot_initial(self):
        s = self.debogueur.snapshot()
        self.assertEqual(set(s), {'active', 'state', 'reason', 'frame', 'frames',
                                  'variables', 'output', 'message', 'breakpoints'})
        self.assertFalse(s['active'])
        self.assertEqual(s['state'], 'idle')

    def test_snapshot_identique_aux_autres_débogueurs(self):
        """L'interface ne doit pas avoir à distinguer les moteurs."""
        import script_debugger
        attendu = set(script_debugger.ScriptDebugger(
            self.racine, {}).snapshot())
        self.assertEqual(set(self.debogueur.snapshot()), attendu)

    def test_ajout_et_retrait_de_point_d_arret(self):
        self.ecrire('a.sh', 'x=1\n')
        self.debogueur.add_breakpoint('a.sh', 1)
        self.assertEqual(self.debogueur.snapshot()['breakpoints'],
                         [{'path': 'a.sh', 'line': 1, 'resolvedLine': 1}])
        self.debogueur.remove_breakpoint('a.sh', 1)
        self.assertEqual(self.debogueur.snapshot()['breakpoints'], [])

    def test_point_d_arret_hors_session_est_conservé(self):
        self.ecrire('a.sh', 'x=1\n')
        self.debogueur.add_breakpoint('a.sh', 1)
        self.assertTrue(self.debogueur.snapshot()['breakpoints'])

    def test_ligne_invalide(self):
        for ligne in (0, -1, 'x', None):
            with self.assertRaises(ValueError):
                self.debogueur.add_breakpoint('a.sh', ligne)

    def test_chemin_invalide(self):
        with self.assertRaises(ValueError):
            self.debogueur.add_breakpoint(42, 1)

    def test_action_sans_session(self):
        with self.assertRaises(ValueError):
            self.debogueur.action('continue')

    def test_evaluate_sans_session(self):
        with self.assertRaises(ValueError):
            self.debogueur.evaluate('1+1')

    def test_stop_sans_session(self):
        self.debogueur.stop()
        self.assertEqual(self.debogueur.snapshot()['state'], 'idle')

    def test_stop_idempotent(self):
        self.debogueur.stop()
        self.debogueur.stop()

    def test_langage_sans_pilote(self):
        self.ecrire('a.txt', 'x')
        with self.assertRaises(ValueError):
            self.debogueur.start('plaintext', self.racine / 'a.txt',
                                 [{'path': 'a.txt', 'line': 1}])

    def test_démarrage_sans_point_d_arret(self):
        self.ecrire('a.sh', 'x=1\n')
        with self.assertRaises(ValueError):
            self.debogueur.start('bash', self.racine / 'a.sh', [])

    def test_interpréteur_absent(self):
        self.ecrire('a.lua', 'x=1\n')
        with mock.patch.object(D.shutil, 'which', return_value=None):
            with self.assertRaises(ValueError) as contexte:
                self.debogueur.start('lua', self.racine / 'a.lua',
                                     [{'path': 'a.lua', 'line': 1}])
        self.assertIn('introuvable', str(contexte.exception))

    def test_fichier_inexistant(self):
        with self.assertRaises(ValueError):
            self.debogueur.start('bash', self.racine / 'absent.sh',
                                 [{'path': 'absent.sh', 'line': 1}])


class TestResolutionDesChemins(CasDebogueur):
    def test_chemin_relatif_au_projet(self):
        """L'interface envoie des clefs relatives au projet, pas au cwd."""
        self.ecrire('a.sh', 'x=1\n')
        self.assertEqual(self.debogueur.key('a.sh'), 'a.sh')

    def test_chemin_absolu(self):
        chemin = self.ecrire('a.sh', 'x=1\n')
        self.assertEqual(self.debogueur.key(str(chemin)), 'a.sh')

    def test_sous_dossier(self):
        self.ecrire('src/a.sh', 'x=1\n')
        self.assertEqual(self.debogueur.key('src/a.sh'), 'src/a.sh')

    def test_uri_file(self):
        chemin = self.ecrire('a.sh', 'x=1\n')
        self.assertEqual(self.debogueur.key(chemin.as_uri()), 'a.sh')

    def test_chemin_hors_projet(self):
        self.assertEqual(self.debogueur.key('/etc/passwd'), '')

    def test_file_retourne_un_chemin_absolu(self):
        chemin = self.ecrire('a.sh', 'x=1\n')
        self.assertEqual(self.debogueur.file('a.sh'), chemin.resolve())

    def test_file_refuse_hors_projet(self):
        with self.assertRaises(ValueError):
            self.debogueur.file('../../etc/passwd')


class TestSyntaxeDesPilotes(CasDebogueur):
    """Le code injecté doit être syntaxiquement valide, quoi qu'il arrive."""

    def preparer(self, pilote, nom, contenu):
        chemin = self.ecrire(nom, contenu)
        self.debogueur.dossier = self.racine / 'session'
        self.debogueur.dossier.mkdir()
        self.debogueur.canal = D.CanalDeControle(self.debogueur.dossier)
        self.debogueur.canal.ouvrir()
        self.addCleanup(self.debogueur.canal.fermer)
        self.debogueur.breakpoints = {(nom, 4)}
        return pilote.lancer(self.debogueur, chemin)

    def test_prélude_bash_valide(self):
        commande, _ = self.preparer(D.PiloteBash(), 'a.sh', 'a=1\nb=2\nc=3\nd=4\n')
        resultat = subprocess.run(['bash', '-n', commande[1]],
                                  capture_output=True, text=True)
        self.assertEqual(resultat.returncode, 0, resultat.stderr)

    def test_prélude_bash_décalage_exact(self):
        commande, _ = self.preparer(D.PiloteBash(), 'a.sh',
                                    'a=1\nb=2\nc=3\nCIBLE=4\n')
        lignes = Path(commande[1]).read_text(encoding='utf8').split('\n')
        reelle = next(i for i, l in enumerate(lignes, 1) if l.startswith('CIBLE='))
        decalage = int(next(l for l in lignes
                            if l.startswith('__PS_DECALAGE=')).split('=')[1])
        self.assertEqual(reelle - decalage, 4)

    def test_module_perl_valide(self):
        if not shutil.which('perl'):
            self.skipTest('perl absent')
        commande, _ = self.preparer(D.PilotePerl(), 'a.pl',
                                    'our $x = 1;\nprint "$x\\n";\n'
                                    'our $y = 2;\nprint "$y\\n";\n')
        resultat = subprocess.run(['perl', '-c', str(
            self.debogueur.dossier / 'lib' / 'Devel' / 'PS.pm')],
            capture_output=True, text=True)
        self.assertIn('syntax OK', resultat.stdout + resultat.stderr)
        self.assertIn('-d:PS', commande)

    def test_pilote_tracé(self):
        pilote = D.PiloteTrace('echo', '', ['--'])
        chemin = self.ecrire('a.lua', 'x=1\n')
        commande, _ = pilote.lancer(self.debogueur, chemin)
        self.assertEqual(commande[0], 'echo')
        self.assertEqual(commande[-1], str(chemin))

    def test_pilote_indisponible(self):
        self.assertFalse(D.PiloteTrace('binaire-inexistant-xyz', '', []).disponible())
        if shutil.which('bash'):
            self.assertTrue(D.PiloteBash().disponible())


class TestSessionBashReelle(CasDebogueur):
    def setUp(self):
        super().setUp()
        if not shutil.which('bash'):
            self.skipTest('bash absent')
        self.script = self.ecrire('calcul.sh',
                                  '#!/usr/bin/env bash\na=1\nb=2\n'
                                  'somme=$((a+b))\necho "somme=$somme"\n')

    def demarrer(self, ligne=4):
        self.debogueur.start('bash', self.script,
                             [{'path': 'calcul.sh', 'line': ligne}])
        self.assertTrue(attendre(lambda: self.debogueur.snapshot()['state'], 'paused'),
                        'arrêt non atteint : %s' % self.debogueur.snapshot())

    def test_arrêt_sur_le_point(self):
        self.demarrer()
        s = self.debogueur.snapshot()
        self.assertEqual(s['state'], 'paused')
        self.assertEqual(s['reason'], 'breakpoint')
        self.assertEqual(s['frame']['line'], 4)
        self.assertEqual(s['frame']['file'], 'calcul.sh')
        self.assertTrue(s['active'])

    def test_variables_avant_la_ligne(self):
        self.demarrer()
        noms = {v['name']: v['value']
                for v in self.debogueur.snapshot()['variables']}
        self.assertEqual(noms.get('a'), '1')
        self.assertEqual(noms.get('b'), '2')
        # « somme » n'est pas encore affectée : le piège précède la ligne.
        self.assertNotIn('somme', noms)

    def test_variables_d_environnement_exclues(self):
        self.demarrer()
        noms = {v['name'] for v in self.debogueur.snapshot()['variables']}
        for parasite in ('PATH', 'HOME', 'PWD', 'SHLVL', 'TERM', 'EPOCHSECONDS',
                         '__PS_BP', '__PS_ENV', '__n'):
            self.assertNotIn(parasite, noms)

    def test_evaluation(self):
        self.demarrer()
        self.assertEqual(self.debogueur.evaluate('echo $((a+b))'), '3')

    def test_evaluation_avec_espaces_dans_le_résultat(self):
        self.demarrer()
        self.assertEqual(self.debogueur.evaluate('echo "un deux trois"'),
                         'un deux trois')

    def test_pas_à_pas(self):
        self.demarrer()
        self.debogueur.action('next')
        self.assertTrue(attendre(lambda: (self.debogueur.snapshot()['frame'] or {}).get('line'), 5))
        noms = {v['name']: v['value']
                for v in self.debogueur.snapshot()['variables']}
        self.assertEqual(noms.get('somme'), '3')

    def test_reprise_jusqu_à_la_fin(self):
        self.demarrer()
        self.debogueur.action('continue')
        self.assertTrue(attendre(lambda: self.debogueur.snapshot()['state'], 'exited'))
        s = self.debogueur.snapshot()
        self.assertIn('somme=3', s['output'])
        self.assertFalse(s['active'])

    def test_arret_puis_stop(self):
        self.demarrer()
        self.debogueur.stop()
        self.assertEqual(self.debogueur.snapshot()['state'], 'idle')
        self.assertFalse(self.debogueur.snapshot()['active'])

    def test_action_inconnue(self):
        self.demarrer()
        with self.assertRaises(ValueError):
            self.debogueur.action('teleporter')

    def test_point_d_arret_hors_du_script_ignoré(self):
        """Un point portant sur un AUTRE fichier ne doit rien arrêter ici."""
        self.ecrire('autre.sh', 'z=9\n')
        self.debogueur.start('bash', self.script,
                             [{'path': 'autre.sh', 'line': 1}])
        self.assertTrue(attendre(lambda: self.debogueur.snapshot()['state'],
                                 'exited', tentatives=60),
                        'le script aurait dû s’exécuter jusqu’au bout')
        self.assertNotEqual(self.debogueur.snapshot()['state'], 'paused')

    def test_démarrage_double_refusé(self):
        self.demarrer()
        with self.assertRaises(ValueError):
            self.debogueur.start('bash', self.script,
                                 [{'path': 'calcul.sh', 'line': 4}])

    def test_fonction_et_trace(self):
        script = self.ecrire('fonctions.sh',
                             'saluer() {\n  local nom="$1"\n  echo "bonjour $nom"\n}\n'
                             'saluer monde\n')
        self.debogueur.start('bash', script, [{'path': 'fonctions.sh', 'line': 3}])
        atteint = attendre(lambda: self.debogueur.snapshot()['state'], 'paused')
        self.assertTrue(atteint, 'le pas à pas dans une fonction doit fonctionner')
        self.assertEqual(self.debogueur.snapshot()['frame']['function'], 'saluer')
        noms = {v['name']: v['value']
                for v in self.debogueur.snapshot()['variables']}
        self.assertEqual(noms.get('nom'), 'monde')


class TestSessionPerlReelle(CasDebogueur):
    def setUp(self):
        super().setUp()
        if not shutil.which('perl'):
            self.skipTest('perl absent')
        self.script = self.ecrire('calcul.pl',
                                  '#!/usr/bin/perl\nuse strict;\nuse warnings;\n'
                                  'our $prix = 12;\nour $quantite = 3;\n'
                                  'our @articles = ("pain","lait");\n'
                                  'my $total = $prix * $quantite;\n'
                                  'print "total=$total\\n";\n')

    def demarrer(self, ligne=7):
        self.debogueur.start('perl', self.script,
                             [{'path': 'calcul.pl', 'line': ligne}])
        self.assertTrue(attendre(lambda: self.debogueur.snapshot()['state'], 'paused'),
                        'arrêt non atteint : %s' % self.debogueur.snapshot())

    def test_arrêt(self):
        self.demarrer()
        self.assertEqual(self.debogueur.snapshot()['frame']['line'], 7)

    def test_scalaires_et_tableaux(self):
        self.demarrer()
        noms = {v['name']: v['value']
                for v in self.debogueur.snapshot()['variables']}
        self.assertEqual(noms.get('prix'), '12')
        self.assertEqual(noms.get('quantite'), '3')
        # Les valeurs contenant une espace ne doivent pas être tronquées.
        self.assertEqual(noms.get('articles'), '[pain, lait]')

    def test_internes_perl_exclus(self):
        self.demarrer()
        noms = {v['name'] for v in self.debogueur.snapshot()['variables']}
        for parasite in ('ENV', 'INC', 'SIG', 'ARGV', 'STDOUT', 'STDIN'):
            self.assertNotIn(parasite, noms)

    def test_evaluation_dans_le_paquetage_du_script(self):
        self.demarrer()
        self.assertEqual(self.debogueur.evaluate('$prix * 2'), '24')
        self.assertEqual(self.debogueur.evaluate('join "/", @articles'), 'pain/lait')

    def test_pas_à_pas(self):
        self.demarrer()
        self.debogueur.action('next')
        self.assertTrue(attendre(lambda: (self.debogueur.snapshot()['frame'] or {}).get('line'), 8))

    def test_reprise(self):
        self.demarrer()
        self.debogueur.action('continue')
        self.assertTrue(attendre(lambda: self.debogueur.snapshot()['state'], 'exited'))
        self.assertIn('total=36', self.debogueur.snapshot()['output'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
