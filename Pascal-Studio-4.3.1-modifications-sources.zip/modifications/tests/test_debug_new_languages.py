"""Real tools: debuggers, live analysis, safe stop, UTF-16 columns."""
import os,shutil,subprocess,sys,tempfile,time,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from dap_debugger import DapDebugger
from debugger import Debugger
import polyglot,live_new_languages

def wait(d,predicate,timeout=20):
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  s=d.snapshot()
  if predicate(s):return s
  time.sleep(.05)
 raise AssertionError('Timeout: '+str(d.snapshot()))
class TestLive(unittest.TestCase):
 def test_rust_identifier_and_no_target_execution(self):
  if not shutil.which('rustc'):self.skipTest('rustc absent')
  with tempfile.TemporaryDirectory() as d:
   marker=Path(d)/'interdit';src=f'fn main() {{ let texte = "😀"; let x = inconnue; std::fs::write({str(marker)!r}, "x"); }}\n'.replace("'",'"')
   result=live_new_languages.analyze('rust',Path(d)/'main.rs','main.rs',src);diags=result['diagnostics'];self.assertTrue(any('inconnue' in x['message'] for x in diags),result);self.assertFalse(marker.exists());issue=next(x for x in diags if 'inconnue' in x['message']);self.assertEqual(issue['column'],len(src.split('inconnue')[0].encode('utf-16-le'))//2+1)
 def test_go_syntax(self):
  if not shutil.which('gofmt'):self.skipTest('gofmt absent')
  result=live_new_languages.analyze('go','/tmp/fichier.go','fichier.go','package main\nfunc main() { x := }\n');self.assertTrue(result['diagnostics']);self.assertEqual(result['diagnostics'][0]['line'],2)

class TestDebug(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.debug=None
 def tearDown(self):
  if self.debug:self.debug.stop()
  self.tmp.cleanup()
 def test_rust_gdb(self):
  if not all(shutil.which(x) for x in ('rustc','gdb')):self.skipTest('rustc ou gdb absent')
  p=self.root/'main.rs';p.write_text('fn main() {\n let nombre = 41;\n println!("{}", nombre+1);\n}\n');b=self.root/'out';b.mkdir();r=polyglot.build(self.root,b,p,{},debug=True);self.assertTrue(r['ok'],r)
  self.debug=Debugger(self.root);self.debug.start(r['binary'],[{'path':'main.rs','line':3}],str(self.root));s=wait(self.debug,lambda s:s['state']=='paused' and s['frame'] is not None);self.assertEqual(s['frame']['line'],3);self.assertEqual(self.debug.evaluate('nombre'),'41');self.debug.action('continue');s=wait(self.debug,lambda s:not s['active']);self.assertIn('42',s['output'])
 def test_dap_go_and_ruby_interactive(self):
  for lang,tools,content,line in [('go',['go','dlv','setsid'],'package main\nimport "fmt"\nfunc main(){\n var nom string\n fmt.Scanln(&nom)\n nombre := 41\n fmt.Println("Salut",nom,nombre+1)\n}\n',6),('ruby',['ruby','rdbg','setsid'],'nom = gets\nnombre = 41\nputs "Salut #{nom.strip} #{nombre+1}"\n',2)]:
   if not all(shutil.which(x) for x in tools):continue
   with self.subTest(lang=lang):
    p=self.root/('main.go' if lang=='go' else 'main.rb');p.write_text(content);out=self.root/'build';out.mkdir(exist_ok=True)
    if lang=='go':
     r=polyglot.build(self.root,out,p,{},debug=True);self.assertTrue(r['ok'],r);target=r['binary']
    else:target=p.name
    self.debug=DapDebugger(self.root);self.debug.start(lang,target,[{'path':p.name,'line':line}],self.root);self.debug.input('Ada');s=wait(self.debug,lambda s:s['state']=='paused' and s['frame'] is not None);self.assertEqual(s['frame']['line'],line);self.assertIn('Ada',self.debug.evaluate('nom'))
    self.debug.action('next');s=wait(self.debug,lambda s:s['state']=='paused' and s['frame'] and s['frame']['line']!=line);self.assertEqual(self.debug.evaluate('nombre'),'41');self.debug.action('continue');s=wait(self.debug,lambda s:not s['active']);self.assertIn('Salut Ada 42',s['output']);self.debug.stop();self.debug=None
 def test_ruby_short_program_and_first_line(self):
  if not all(shutil.which(x) for x in ('rdbg','setsid')):self.skipTest('rdbg absent')
  p=self.root/'main.rb';p.write_text('nombre = 41\nputs nombre + 1\n')
  for line in (1,2):
   with self.subTest(line=line):
    self.debug=DapDebugger(self.root);self.debug.start('ruby','main.rb',[{'path':'main.rb','line':line}]);s=wait(self.debug,lambda s:s['state']=='paused' and s['frame']);self.assertEqual(s['frame']['line'],line);self.debug.action('continue');s=wait(self.debug,lambda s:not s['active']);self.assertIn('42',s['output']);self.debug.stop();self.debug=None
 def test_dap_stop_and_restart(self):
  if not all(shutil.which(x) for x in ('rdbg','setsid')):self.skipTest('rdbg absent')
  p=self.root/'main.rb';p.write_text('nom = gets\nputs nom\n');self.debug=DapDebugger(self.root)
  self.debug.start('ruby','main.rb',[{'path':'main.rb','line':2}]);self.debug.stop();self.assertFalse(self.debug.snapshot()['active']);self.debug.start('ruby','main.rb',[{'path':'main.rb','line':2}]);self.debug.input('ok');wait(self.debug,lambda s:s['state']=='paused' and s['frame']);self.debug.action('continue');s=wait(self.debug,lambda s:not s['active']);self.assertIn('ok',s['output'])
if __name__=='__main__':unittest.main()
