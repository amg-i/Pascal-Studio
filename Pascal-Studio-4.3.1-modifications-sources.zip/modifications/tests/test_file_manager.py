import json, os, tempfile, unittest
from pathlib import Path
import file_manager as fm

class FileManagerTest(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.m=fm.Manager();self.m.profile=self.root/'config'/'profiles.json'
 def tearDown(self):self.tmp.cleanup()
 def test_urls_and_credentials(self):
  for good in ('ftp://host/','ftps://user@example.org:21/dir','ftpis://example.org:990/dir','sftp://user@example.org:2222/dir','smb://server/share'):
   self.assertEqual(fm.checked_uri(good),good)
  for bad in ('http://host','ftp://user:secret@host/','sftp://','smb://server/','sftp://host/#frag'):
   with self.assertRaises(ValueError):fm.checked_uri(bad)
 def test_profiles_no_secret(self):
  self.m.remember_profile('sftp://a.example/','alice','WORKGROUP')
  self.assertEqual(self.m.profiles()[0]['username'],'alice');self.assertNotIn('password',self.m.profile.read_text());self.assertEqual(self.m.profile.stat().st_mode&0o777,0o600)
  self.m.forget_profile('sftp://a.example/');self.assertEqual(self.m.profiles(),[])
 def test_corrupt_profiles_are_not_overwritten(self):
  self.m.profile.parent.mkdir(parents=True);self.m.profile.write_text('{bad-json')
  with self.assertRaises(ValueError):self.m.remember_profile('ftp://host/','user','')
  self.assertEqual(self.m.profile.read_text(),'{bad-json')
 def test_local_operations_protect_existing(self):
  path=str(self.root);self.m.operation('local',None,path,'create','one.txt','file');(self.root/'one.txt').write_text('one');(self.root/'two.txt').write_text('two')
  with self.assertRaises(ValueError):self.m.operation('local',None,str(self.root/'one.txt'),'rename','two.txt')
  self.assertEqual((self.root/'one.txt').read_text(),'one');self.assertEqual((self.root/'two.txt').read_text(),'two')
  self.m.operation('local',None,str(self.root/'one.txt'),'rename','renamed.txt');self.assertTrue((self.root/'renamed.txt').exists())
  self.m.operation('local',None,path,'create','folder','folder');(self.root/'folder'/'item').touch()
  with self.assertRaises(OSError):self.m.operation('local',None,str(self.root/'folder'),'delete')
  self.assertTrue((self.root/'folder'/'item').exists())
 def test_links_not_followed_for_delete(self):
  (self.root/'real').write_text('protect');(self.root/'link').symlink_to('real');self.m.operation('local',None,str(self.root/'link'),'delete');self.assertEqual((self.root/'real').read_text(),'protect')
 def test_invalid_names_and_paths(self):
  for name in ('','..','.','hello/world','x\x00y'):
   with self.assertRaises(ValueError):fm.name_ok(name)
  for path in ('../etc','/absolute','a/../b','a//b'):
   with self.assertRaises(ValueError):fm.valid_relative(path)
  with self.assertRaises(ValueError):fm.local_path('relative/path')
 def test_listing_hidden_and_symlink(self):
  (self.root/'.hidden').write_text('a');(self.root/'folder').mkdir();(self.root/'link').symlink_to('folder')
  items=self.m.listing('local',None,str(self.root))['items'];types={x['name']:x['type'] for x in items};self.assertEqual(types,{'.hidden':'file','folder':'folder','link':'link'})


class FileManagerApiTest(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  import test_stop_and_save as support
  # Reuse only the temporary API process lifecycle, not inherited test cases.
  cls.support=support
 def setUp(self):
  self.server=self.support.ApiStopTests(methodName='test_stop_debug_and_restart');self.server.setUp();self.addCleanup(self.server.tearDown)
 def test_local_origin_and_operations(self):
  import urllib.request, urllib.error
  status,r=self.support.request(self.server.base,'fm/list',{'kind':'local','path':str(self.server.project)})
  self.assertEqual(status,200);self.assertIsInstance(r['items'],list)
  q=urllib.request.Request(self.server.base+'/api/fm/operation',data=json.dumps({'kind':'local','path':str(self.server.project),'action':'create','name':'attacker.txt','target':'file'}).encode(),headers={'Content-Type':'application/json','Origin':'https://evil.invalid'})
  with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(q)
  self.assertFalse((self.server.project/'attacker.txt').exists())
 def test_fake_remote_no_local_resolution(self):
  status,r=self.support.request(self.server.base,'save',{'path':'@remote:fake/file.txt','content':'test'})
  self.assertEqual(status,400);self.assertIn('distant',r['error'])

if __name__=='__main__':unittest.main()
