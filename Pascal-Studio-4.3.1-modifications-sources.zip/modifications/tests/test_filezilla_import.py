import base64,json,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import filezilla_import as f

class ImportTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.p=Path(self.tmp.name)/'sitemanager.xml';self.patch=patch.object(f,'paths',return_value=[self.p]);self.patch.start();self.addCleanup(self.patch.stop)
 def write(self,protocol='0',encoding='base64',password='test secret à'):
  value=base64.b64encode(password.encode()).decode()
  self.p.write_text(f'<FileZilla3><Servers><Folder><Server><Name>Site choisi</Name><Host>example.invalid</Host><Port>21</Port><Protocol>{protocol}</Protocol><User>test@user</User><Logontype>1</Logontype><Pass encoding="{encoding}">{value}</Pass></Server></Folder></Servers></FileZilla3>')
 def test_no_secret_in_listing_and_explicit_choice(self):
  self.write();out=f.list_sites();site=out['sites'][0];self.assertNotIn('test secret',json.dumps(out));self.assertEqual(site['protocol'],'FTP si TLS indisponible (FileZilla essaie TLS)');self.assertTrue(site['opportunistic']);self.assertEqual(site['uri'],'ftp://test%40user@example.invalid:21/');s,password=f.selected(site['token']);self.assertEqual(password,'test secret à')
 def test_no_password_read_for_encrypted(self):
  self.write(encoding='crypt');s=f.list_sites()['sites'][0];self.assertEqual(s['password_state'],'chiffre');self.assertEqual(f.selected(s['token'])[1],'')
 def test_detect_changes_and_never_fall_back_to_old_token(self):
  self.write();token=f.list_sites()['sites'][0]['token'];self.write(password='different')
  with self.assertRaises(ValueError):f.selected(token)
 def test_modes_and_invalid_xml(self):
  for num,scheme in [('6','ftp'),('1','sftp'),('3','ftpis'),('4','ftps')]:
   self.write(num);self.assertTrue(f.list_sites()['sites'][0]['uri'].startswith(scheme+'://'))
  self.p.write_text('<!DOCTYPE x [ <!ENTITY e "a">]><x>&e;</x>');out=f.list_sites();self.assertEqual(out['sites'],[]);self.assertTrue(out['warnings'])
