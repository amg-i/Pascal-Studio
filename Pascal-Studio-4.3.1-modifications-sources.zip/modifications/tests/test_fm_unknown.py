import unittest
from unittest.mock import patch
import file_manager
class Info:
 def __init__(self,name,t):self.name=name;self.t=t
 def get_name(self):return self.name
 def get_file_type(self):return self.t
 def get_size(self):return 0
 def has_attribute(self,x):return False
class Enum:
 def __init__(self):self.a=[Info('dossier',0),Info('mystere',0)]
 def next_file(self,x):return self.a.pop(0) if self.a else None
 def close(self,x):pass
class Child:
 def __init__(self,n):self.n=n
 def query_info(self,*args):
  if self.n=='dossier':return Info(self.n,2)
  raise RuntimeError('serveur ne dit pas')
class Root:
 def enumerate_children(self,*args):return Enum()
 def get_child(self,name):return Child(name)
class Gio:
 class FileType:UNKNOWN=0;REGULAR=1;DIRECTORY=2;SYMBOLIC_LINK=3
 class FileQueryInfoFlags:NOFOLLOW_SYMLINKS=1
class TestUnknown(unittest.TestCase):
 def test_unknown_entry_remains_visible_and_fallback_detects_folder(self):
  m=file_manager.Manager();m.remote=lambda *a:Root()
  with patch.object(file_manager,'gio',return_value=(Gio,None)):res=m.listing('remote','id','')
  self.assertEqual({v['name']:v['type'] for v in res['items']},{'dossier':'folder','mystere':'unknown'})
