import ftplib,ssl,unittest
from unittest.mock import patch
import ftp_diagnostic as d

class FTPDiagnosticTests(unittest.TestCase):
 def test_ftps_refusal_never_falls_back_and_never_sends_password(self):
  class Fake:
   def __init__(self,**kw):self.commands=[]
   def connect(self,*args,**kw):pass
   def auth(self):raise ftplib.error_perm('500 TLS unavailable')
   def sendcmd(self,command):raise AssertionError('No credential must be sent')
   def close(self):pass
  with patch.object(d.ftplib,'FTP_TLS',Fake):
   result=d.diagnostic('ftps://u@host/','u','secret')
   self.assertEqual(result['stage'],'TLS');self.assertNotIn('secret',str(result));self.assertIn('aucun repli',result['message'])
 def test_invalid_certificate_is_rejected(self):
  class Fake:
   def __init__(self,**kw):pass
   def connect(self,*a,**kw):raise ssl.SSLCertVerificationError('bad cert')
   def close(self):pass
  with patch.object(d.ftplib,'FTP_TLS',Fake):
   result=d.diagnostic('ftps://u@host/','u','secret');self.assertEqual(result['stage'],'certificat')
