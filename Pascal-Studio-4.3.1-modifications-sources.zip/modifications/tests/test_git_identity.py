"""Identité de commit déduite du compte associé au dépôt, sur de vrais dépôts Git."""
import os, shutil, subprocess, tempfile, unittest
from pathlib import Path
from unittest import mock
import git_identity as gi
import oauth_accounts

GIT = shutil.which('git')

GH = {'id': 'gh1', 'provider': 'github', 'login': 'alice', 'name': 'Alice Martin',
      'email': 'alice@example.com', 'emailSource': 'compte'}
GH_NOREPLY = {'id': 'gh2', 'provider': 'github', 'login': 'bob', 'name': 'Bob',
              'email': '42+bob@users.noreply.github.com', 'emailSource': 'noreply'}
GL = {'id': 'gl1', 'provider': 'gitlab', 'login': 'carol', 'name': 'Carol',
      'email': 'carol@users.noreply.gitlab.com', 'emailSource': 'noreply'}


class FakeManager:
    """Comptes connectés + identités, sans aucun appel réseau."""

    def __init__(self, accounts):
        self._accounts = {a['id']: a for a in accounts}

    def all(self):
        return [{k: a[k] for k in ('id', 'provider', 'login', 'name', 'email')}
                for a in self._accounts.values()]

    def identity(self, key):
        if key not in self._accounts:
            raise ValueError('Compte déconnecté ou session expirée.')
        a = self._accounts[key]
        return {'provider': a['provider'], 'login': a['login'], 'name': a['name'],
                'email': a['email'], 'emailSource': a.get('emailSource', ''), 'accountId': a['id']}


@unittest.skipUnless(GIT, 'git absent')
class GitIdentityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name) / 'depot'
        self.root.mkdir()
        # Configuration globale/systeme neutralisée : le dépôt part sans identité.
        # GitManager.call construit son env depuis os.environ, donc on patche ici.
        self.empty = Path(self.tmp.name) / 'vide-gitconfig'
        self.empty.write_text('', encoding='utf8')
        patcher = mock.patch.dict(os.environ, {
            'GIT_CONFIG_GLOBAL': str(self.empty),
            'GIT_CONFIG_SYSTEM': str(self.empty),
            'GIT_CONFIG_NOSYSTEM': '1',
        })
        patcher.start()
        self.addCleanup(patcher.stop)
        subprocess.run(['git', 'init', '-q', '-b', 'main'], cwd=self.root, check=True)

    def git(self, *args):
        return subprocess.run(['git', *args], cwd=self.root, capture_output=True, text=True)

    def local(self, key):
        return self.git('config', '--local', '--get', key).stdout.strip()

    def set_remote(self, url):
        self.git('remote', 'add', 'origin', url)

    def patch_accounts(self, accounts):
        p = mock.patch.object(oauth_accounts, 'manager', FakeManager(accounts))
        p.start()
        self.addCleanup(p.stop)

    # --- association dépôt / compte ---------------------------------------
    def test_connected_repo_takes_the_account_identity(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        r = gi.apply(self.root)
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.name'), 'Alice Martin')
        self.assertEqual(self.local('user.email'), 'alice@example.com')
        self.assertEqual(self.local(gi.MARKER), 'auto:gh1')

    def test_no_account_means_no_identity(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertEqual(self.local('user.name'), '')
        self.assertEqual(self.local('user.email'), '')

    def test_no_remote_means_no_identity(self):
        self.patch_accounts([GH])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertEqual(self.local('user.name'), '')

    def test_unmanaged_host_gets_no_identity(self):
        # GitLab auto-hébergé ou autre serveur : aucun compte n'est associé.
        self.set_remote('https://gitlab.maison.example/groupe/depot.git')
        self.patch_accounts([GH, GL])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertIn('non associé', r['reason'])

    def test_gitlab_subgroup_remote_is_matched(self):
        self.set_remote('git@gitlab.com:groupe/sous-groupe/depot.git')
        self.patch_accounts([GL])
        r = gi.apply(self.root)
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.email'), 'carol@users.noreply.gitlab.com')

    def test_noreply_address_is_used_when_email_is_private(self):
        self.set_remote('https://github.com/bob/projet.git')
        self.patch_accounts([GH_NOREPLY])
        r = gi.apply(self.root)
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.email'), '42+bob@users.noreply.github.com')

    # --- plusieurs comptes : on ne devine jamais ---------------------------
    def test_several_accounts_owner_match_wins(self):
        self.set_remote('https://github.com/bob/projet.git')
        self.patch_accounts([GH, GH_NOREPLY])
        r = gi.apply(self.root)
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.name'), 'Bob')

    def test_several_accounts_without_owner_match_sets_nothing(self):
        self.set_remote('https://github.com/autre-org/projet.git')
        self.patch_accounts([GH, GH_NOREPLY])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertIn('aucun ne correspond', r['reason'])
        self.assertEqual(self.local('user.email'), '')

    def test_other_provider_account_is_not_used(self):
        self.set_remote('https://github.com/carol/projet.git')
        self.patch_accounts([GL])                    # seul un compte GitLab est connecté
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertEqual(self.local('user.name'), '')

    # --- identité manuelle protégée ----------------------------------------
    def test_manual_identity_is_not_overwritten(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.git('config', '--local', 'user.name', 'Moi Même')
        self.git('config', '--local', 'user.email', 'moi@maison.fr')
        self.git('config', '--local', gi.MARKER, 'manual')
        self.patch_accounts([GH])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertTrue(r.get('manualIdentity'), r)
        self.assertEqual(self.local('user.name'), 'Moi Même')
        self.assertEqual(self.local('user.email'), 'moi@maison.fr')

    def test_identity_set_through_git_manager_is_protected(self):
        # Cas réel : l'utilisateur saisit son identité dans le panneau Git.
        from git_manager import GitManager, IDENTITY_MARKER
        self.assertEqual(IDENTITY_MARKER, gi.MARKER)
        GitManager(self.root).identity('Moi Même', 'moi@maison.fr')
        self.assertEqual(self.local(gi.MARKER), 'manual')
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertEqual(self.local('user.email'), 'moi@maison.fr')
        # Le panneau Git doit pouvoir dire d'où vient l'identité.
        self.assertEqual(gi.current(self.root)['source'], 'manual')

    def test_source_is_auto_after_automatic_application(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        gi.apply(self.root)
        self.assertEqual(gi.current(self.root)['source'], 'auto')
        self.assertEqual(gi.current(self.root)['accountId'], 'gh1')

    def test_source_is_none_for_a_fresh_repo(self):
        self.assertEqual(gi.current(self.root)['source'], 'none')

    def test_explicit_account_replaces_manual_identity(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.git('config', '--local', 'user.name', 'Moi Même')
        self.git('config', '--local', 'user.email', 'moi@maison.fr')
        self.git('config', '--local', gi.MARKER, 'manual')
        self.patch_accounts([GH])
        r = gi.apply(self.root, account_id='gh1')
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.name'), 'Alice Martin')

    def test_unknown_account_id_is_refused(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        with self.assertRaises(ValueError):
            gi.apply(self.root, account_id='inexistant')

    # --- suppression et remplacement ---------------------------------------
    def test_removing_the_account_clears_the_auto_identity(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        gi.apply(self.root)
        self.assertEqual(self.local('user.email'), 'alice@example.com')
        # Le compte disparaît : l'identité automatique doit suivre.
        self.patch_accounts([])
        r = gi.apply(self.root)
        self.assertFalse(r['applied'], r)
        self.assertTrue(r['cleared'], r)
        self.assertEqual(self.local('user.name'), '')
        self.assertEqual(self.local('user.email'), '')
        self.assertEqual(self.local(gi.MARKER), '')

    def test_clear_auto_never_touches_a_manual_identity(self):
        self.git('config', '--local', 'user.name', 'Moi')
        self.git('config', '--local', 'user.email', 'moi@maison.fr')
        self.git('config', '--local', gi.MARKER, 'manual')
        r = gi.clear_auto(self.root)
        self.assertFalse(r['changed'], r)
        self.assertEqual(self.local('user.name'), 'Moi')

    def test_switching_remote_switches_identity(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH, GL])
        gi.apply(self.root)
        self.assertEqual(self.local('user.email'), 'alice@example.com')
        self.git('remote', 'set-url', 'origin', 'https://gitlab.com/carol/depot.git')
        r = gi.apply(self.root)
        self.assertTrue(r['applied'], r)
        self.assertEqual(self.local('user.email'), 'carol@users.noreply.gitlab.com')

    # --- non-dépôt et description ------------------------------------------
    def test_not_a_repo_raises(self):
        autre = Path(self.tmp.name) / 'vide'
        autre.mkdir()
        with self.assertRaises(ValueError):
            gi.apply(autre)

    def test_is_repo_false_for_a_plain_folder(self):
        autre = Path(self.tmp.name) / 'vide2'
        autre.mkdir()
        self.assertFalse(gi.is_repo(autre))

    def test_describe_remote_does_not_modify_anything(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        info = gi.describe_remote(self.root)
        self.assertEqual(info['provider'], 'github')
        self.assertEqual(info['account']['login'], 'alice')
        self.assertEqual(self.local('user.name'), '', 'describe_remote ne doit rien écrire')

    def test_committed_author_matches_the_account(self):
        # Vérification de bout en bout : l'auteur du commit est bien le compte.
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        gi.apply(self.root)
        (self.root / 'f.txt').write_text('x', encoding='utf8')
        self.git('add', 'f.txt')
        self.git('commit', '-q', '-m', 'essai')
        show = self.git('show', '-s', '--format=%an|%ae').stdout.strip()
        self.assertEqual(show, 'Alice Martin|alice@example.com')

    # --- message affiché dans le panneau Git ---------------------------------
    def test_explain_follows_a_real_apply(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        texte = gi.explain(gi.apply(self.root))
        self.assertIn('Alice Martin', texte)
        self.assertIn('alice@example.com', texte)

    def test_explain_follows_a_real_refusal(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([])
        texte = gi.explain(gi.apply(self.root))
        self.assertIn('Aucune identité posée', texte)

    def test_explain_follows_a_real_manual_identity_kept(self):
        self.set_remote('https://github.com/alice/mon-projet.git')
        self.patch_accounts([GH])
        gi._git(self.root).call('config', '--local', 'user.name', 'Choisi à la main')
        gi._git(self.root).call('config', '--local', 'user.email', 'main@example.com')
        texte = gi.explain(gi.apply(self.root))
        self.assertIn('manuelle conservée', texte)
        self.assertEqual(self.local('user.email'), 'main@example.com')


@unittest.skipUnless(GIT, 'git absent')
class ParseRemoteTests(unittest.TestCase):
    def test_https_and_ssh_forms(self):
        for url, owner in [('https://github.com/alice/p.git', 'alice'),
                           ('https://github.com/alice/p', 'alice'),
                           ('git@github.com:alice/p.git', 'alice'),
                           ('https://gitlab.com/g/s/p.git', 'g')]:
            parsed = gi.parse_remote(url)
            self.assertIsNotNone(parsed, url)
            self.assertEqual(parsed['owner'], owner, url)

    def test_rejected_forms(self):
        for url in ['', None, 'ftp://github.com/a/b', 'github.com/a/b',
                    'https://github.com/onlyone', 'https://user:pass@github.com/a/b.git',
                    'https://github.com/../secret.git']:
            self.assertIsNone(gi.parse_remote(url), url)

    def test_credentials_in_url_do_not_produce_a_host(self):
        parsed = gi.parse_remote('https://user:token@github.com/alice/p.git')
        # Soit refusé, soit un hôte propre — jamais les identifiants.
        self.assertTrue(parsed is None or parsed['host'] == 'github.com', parsed)

    def test_provider_for_subdomain_and_unknown(self):
        self.assertEqual(gi.provider_for('github.com'), 'github')
        self.assertEqual(gi.provider_for('gitlab.com'), 'gitlab')
        self.assertIsNone(gi.provider_for('notgithub.com'))
        self.assertIsNone(gi.provider_for(''))


class ExplainTests(unittest.TestCase):
    """Le panneau Git affiche explain() : le message doit dire ce qui s'est passé."""

    def test_applied_mentions_the_account_and_email(self):
        texte = gi.explain({'ok': True, 'applied': True, 'reason': 'compte choisi',
                            'identity': {'name': 'Alice Martin', 'email': 'alice@example.com',
                                         'provider': 'github', 'login': 'alice',
                                         'accountId': 'gh1', 'emailSource': 'compte'}})
        self.assertIn('github · alice', texte)
        self.assertIn('Alice Martin', texte)
        self.assertIn('alice@example.com', texte)
        self.assertIn('adresse du compte', texte)

    def test_applied_with_a_noreply_address_says_so(self):
        texte = gi.explain({'ok': True, 'applied': True,
                            'identity': {'name': 'Alice', 'email': '1+alice@users.noreply.github.com',
                                         'provider': 'github', 'login': 'alice',
                                         'emailSource': 'noreply'}})
        self.assertIn('adresse privée du service', texte)

    def test_commit_email_source_is_named(self):
        texte = gi.explain({'ok': True, 'applied': True,
                            'identity': {'name': 'Alice', 'email': 'a@b.c', 'provider': 'gitlab',
                                         'login': 'alice', 'emailSource': 'commit'}})
        self.assertIn('adresse de commit', texte)

    def test_failure_gives_the_reason(self):
        texte = gi.explain({'ok': False, 'applied': False, 'reason': 'session expirée'})
        self.assertIn('Identité non posée', texte)
        self.assertIn('session expirée', texte)

    def test_manual_identity_is_announced_as_kept(self):
        texte = gi.explain({'ok': True, 'applied': False, 'manualIdentity': True,
                            'reason': 'une identité manuelle est déjà définie ; '
                                      'choisissez le compte pour la remplacer'})
        self.assertIn('manuelle conservée', texte)
        self.assertIn('choisissez le compte', texte)
        self.assertNotIn(' .', texte)

    def test_cleared_identity_is_announced(self):
        texte = gi.explain({'ok': True, 'applied': False, 'cleared': True,
                            'reason': 'dépôt non géré'})
        self.assertIn('retirée', texte)

    def test_nothing_applied_explains_why(self):
        texte = gi.explain({'ok': True, 'applied': False, 'cleared': False,
                            'reason': 'plusieurs comptes gitlab connectés'})
        self.assertIn('Aucune identité posée', texte)
        self.assertIn('plusieurs comptes gitlab', texte)

    def test_missing_reason_still_reads_well(self):
        texte = gi.explain({'ok': True, 'applied': False})
        self.assertIn('Aucune identité posée', texte)
        self.assertIn('aucun compte', texte)

    def test_unexpected_input_never_raises(self):
        for valeur in [None, '', 42, [], {}]:
            self.assertIsInstance(gi.explain(valeur), str)


if __name__ == '__main__':
    unittest.main()
