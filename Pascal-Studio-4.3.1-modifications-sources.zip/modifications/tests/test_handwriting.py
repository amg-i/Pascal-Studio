import json,tempfile,unittest,os,base64,urllib.request,urllib.error
from pathlib import Path
from handwriting import blank,create,load,save,validate
import test_stop_and_save as support

class HandwritingTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'note.psnote'
 def tearDown(self):self.tmp.cleanup()
 def test_roundtrip_and_revision(self):
  create(self.path);r=load(self.path);d=r['document'];d['pages'][0]['items'].append({'type':'stroke','points':[{'x':1,'y':2,'p':.25},{'x':3,'y':4,'p':.9}],'color':'#000000','width':2,'opacity':1});s=save(self.path,r['revision'],d);self.assertNotEqual(s['revision'],r['revision']);self.assertEqual(load(self.path)['document'],d)
 def test_conflict_preserves_external(self):
  create(self.path);r=load(self.path);self.path.write_text('autre');
  with self.assertRaisesRegex(ValueError,'Conflit'):save(self.path,r['revision'],r['document'])
  self.assertEqual(self.path.read_text(),'autre')
 def test_deleted_not_recreated(self):
  create(self.path);r=load(self.path);self.path.unlink()
  with self.assertRaisesRegex(ValueError,'supprimé'):save(self.path,r['revision'],r['document'])
  self.assertFalse(self.path.exists())
 def test_empty_new_file(self):self.path.write_text('');self.assertEqual(load(self.path)['document'],blank())
 def test_create_wont_overwrite(self):
  create(self.path)
  with self.assertRaises(FileExistsError):create(self.path)
 def test_invalid_annotations(self):
  for item in [{'type':'stroke','points':[{'x':1,'y':2,'p':2}],'color':'#000000','width':2},{'type':'text','x':0,'y':0,'text':'x','color':'bad','size':18},{'type':'text','x':float('nan'),'y':0,'text':'x','color':'#abcdef','size':18}]:
   d=blank();d['pages'][0]['items']=[item]
   with self.assertRaises(ValueError):validate(d)
 def test_pdf_background_embedded(self):
  create(self.path);r=load(self.path);d=r['document'];d['background']={'type':'pdf','data':base64.b64encode(b'%PDF demo').decode(),'name':'fond.pdf'};d['pages']=[{'items':[]},{'items':[]}];save(self.path,r['revision'],d);self.assertEqual(load(self.path)['document'],d)

class HandwritingApiTests(support.ApiStopTests):
 def test_routes_and_origin(self):
  status,r=support.request(self.base,'handwriting/create',{'path':'test.psnote'});self.assertEqual(status,200,r)
  status,r=support.request(self.base,'handwriting/open?path=test.psnote');self.assertEqual(status,200,r)
  revision=r['revision'];doc=r['document'];doc['pages'].append({'items':[]});status,r=support.request(self.base,'handwriting/save',{'path':'test.psnote','revision':revision,'document':doc});self.assertEqual(status,200,r)
  req=urllib.request.Request(self.base+'/api/handwriting/save',data=b'{}',headers={'Content-Type':'application/json','Origin':'https://malicious.example'})
  with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(req)
  self.assertEqual(e.exception.code,400)
 def test_pdf_external(self):
  p=self.dir/'external.pdf';p.write_bytes(b'%PDF-test');status,r=support.request(self.base,'external/open',{'path':str(p)});self.assertEqual(status,200,r);self.assertTrue(r['path'].startswith('@external:'))
  with urllib.request.urlopen(self.base+'/api/pdf/file?path='+urllib.parse.quote(r['path'])) as f:self.assertEqual(f.read(),b'%PDF-test')
if __name__=='__main__':unittest.main()
