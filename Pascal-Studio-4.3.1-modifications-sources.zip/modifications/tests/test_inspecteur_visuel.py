# -*- coding: utf-8 -*-
"""Inspecteur visuel : la carte des langages qui se rendent à l'écran.

Deux familles sont couvertes.

Les langages à balisage (HTML, CSS, SVG, XML, Markdown, LaTeX) dont
l'inspecteur relève les éléments, règles, blocs et environnements avec leur
numéro de ligne, pour qu'un diagnostic puisse être épinglé dans le rendu.

Piet, qui n'a rien de tout cela : son programme EST une image. L'inspecteur y
découpe les blocs de couleur et rend leur rectangle en PIXELS, seule information
qui permette de surligner le bloc en cours d'exécution.

Les tests fabriquent leurs PNG eux-mêmes : aucun encodeur tiers n'est installé,
et le moteur Piet en décode un écrit à la main de la même façon.
"""

import base64
import json
import struct
import unittest
import zlib

import inspecteur_visuel
import langages_esoteriques

ROUGE = (255, 0, 0)
ROUGE_SOMBRE = (192, 0, 0)
ROUGE_CLAIR = (255, 192, 192)
MAGENTA = (255, 0, 255)
BLANC = (255, 255, 255)
NOIR = (0, 0, 0)
INCONNUE = (1, 2, 3)


def ecrire_png(lignes):
    """Encode des lignes de triplets RVB en PNG 8 bits non entrelacé."""
    hauteur = len(lignes)
    largeur = len(lignes[0])
    brut = b''.join(b'\x00' + b''.join(bytes(couleur) for couleur in ligne)
                    for ligne in lignes)

    def morceau(type_, donnees):
        return (struct.pack('>I', len(donnees)) + type_ + donnees
                + struct.pack('>I', zlib.crc32(type_ + donnees)))

    return (b'\x89PNG\r\n\x1a\n'
            + morceau(b'IHDR',
                      struct.pack('>IIBBBBB', largeur, hauteur, 8, 2, 0, 0, 0))
            + morceau(b'IDAT', zlib.compress(brut))
            + morceau(b'IEND', b''))


def uri(lignes):
    return ('data:image/png;base64,'
            + base64.b64encode(ecrire_png(lignes)).decode('ascii'))


class TestCartePiet(unittest.TestCase):
    def test_l_apercu_est_decoupe_en_blocs(self):
        donnees = inspecteur_visuel.payload(
            'piet', 'programme.png', langages_esoteriques.apercu_programme('piet'))
        self.assertEqual(donnees['langage'], 'piet')
        self.assertEqual(donnees['geometrie'],
                         {'largeur': 67, 'hauteur': 1, 'taille_codel': 1,
                          'blocs': 3})
        self.assertEqual(len(donnees['codels']), 3)
        premier = donnees['codels'][0]
        self.assertEqual(premier['rvb'], '#FF0000')
        self.assertEqual(premier['taille'], 65)
        self.assertEqual(premier['rectangle'], [0, 0, 65, 1])
        self.assertEqual(premier['classe'], 'rouge normale')
        self.assertEqual(premier['teinte'], 'rouge')
        self.assertEqual(premier['luminosite'], 'normale')
        self.assertEqual(donnees['diagnostics'], [])

    def test_les_rectangles_sont_en_pixels_et_jointifs(self):
        # La surcouche pose ces rectangles sur l'image affichée : ils doivent
        # être en pixels (codel × taille) et se joindre sans trou ni recouvrement.
        donnees = inspecteur_visuel.payload(
            'piet', 'programme.png', langages_esoteriques.apercu_programme('piet'))
        rectangles = [c['rectangle'] for c in donnees['codels']]
        self.assertEqual(rectangles, [[0, 0, 65, 1], [65, 0, 66, 1], [66, 0, 67, 1]])
        for precedent, suivant in zip(rectangles, rectangles[1:]):
            self.assertEqual(precedent[2], suivant[0])
        self.assertEqual(rectangles[-1][2], donnees['geometrie']['largeur'])

    def test_la_taille_de_codel_est_repercutee(self):
        # Une même image avec des codels de 4 px : les rectangles quadruplent,
        # le nombre de blocs ne change pas.
        # Chaque bloc fait 4 codels de large et l'image 4 codels de haut. Il
        # faut répéter les PIXELS, pas la liste : [a, b] * 2 donne a, b, a, b et
        # le plus petit run devient 1, ce qui ferait deviner un codel de 1 px.
        lignes = [[ROUGE] * 24 + [ROUGE_SOMBRE] * 12 + [MAGENTA] * 8] * 4
        donnees = inspecteur_visuel.payload('piet', 'g.png', uri(lignes))
        self.assertEqual(donnees['geometrie'],
                         {'largeur': 44, 'hauteur': 4, 'taille_codel': 4,
                          'blocs': 3})
        # Les rectangles sont en PIXELS (codel × 4), les tailles en CODELS.
        self.assertEqual([c['rectangle'] for c in donnees['codels']],
                         [[0, 0, 24, 4], [24, 0, 36, 4], [36, 0, 44, 4]])
        self.assertEqual([c['taille'] for c in donnees['codels']], [6, 3, 2])
        self.assertEqual([c['classe'] for c in donnees['codels']],
                         ['rouge normale', 'rouge sombre', 'magenta normale'])

    def test_les_trois_luminosites_sont_distinguees(self):
        donnees = inspecteur_visuel.payload(
            'piet', 'l.png', uri([[ROUGE_CLAIR, ROUGE, ROUGE_SOMBRE]]))
        self.assertEqual([c['luminosite'] for c in donnees['codels']],
                         ['claire', 'normale', 'sombre'])
        self.assertEqual([c['rvb'] for c in donnees['codels']],
                         ['#FFC0C0', '#FF0000', '#C00000'])

    def test_le_blanc_et_le_noir_sont_cartographies(self):
        # Ils ne sont pas des codels exécutoires — le blanc se traverse sans
        # commande, le noir est infranchissable — mais la surcouche doit pouvoir
        # les dessiner pour que l'image inspectée ressemble à l'image affichée.
        donnees = inspecteur_visuel.payload(
            'piet', 'b.png', uri([[ROUGE] * 3 + [BLANC] * 2 + [NOIR] * 2]))
        self.assertEqual([c['classe'] for c in donnees['codels']],
                         ['rouge normale', 'blanc', 'noir'])
        self.assertEqual([c['rectangle'] for c in donnees['codels']],
                         [[0, 0, 3, 1], [3, 0, 5, 1], [5, 0, 7, 1]])
        self.assertEqual(donnees['diagnostics'], [])

    def test_une_couleur_hors_palette_est_signalee_et_traitee_comme_blanche(self):
        donnees = inspecteur_visuel.payload(
            'piet', 'i.png', uri([[ROUGE] * 2 + [INCONNUE]]))
        self.assertEqual(len(donnees['codels']), 2)
        self.assertEqual(donnees['codels'][1]['classe'], 'blanc')
        messages = [d.get('message', '') for d in donnees['diagnostics']]
        self.assertTrue(any('#010203' in m for m in messages), messages)

    def test_une_image_illisible_ne_leve_pas(self):
        donnees = inspecteur_visuel.payload(
            'piet', 'casse.png', 'data:image/png;base64,QUJD')
        self.assertEqual(donnees['codels'], [])
        self.assertEqual(donnees['geometrie']['blocs'], 0)
        messages = [d.get('message', '') for d in donnees['diagnostics']]
        self.assertTrue(any('Signature PNG' in m for m in messages), messages)

    def test_un_contenu_vide_ne_leve_pas(self):
        for contenu in ('', None, 'pas-une-image'):
            with self.subTest(contenu=contenu):
                donnees = inspecteur_visuel.payload('piet', 'x.png', contenu)
                self.assertEqual(donnees['codels'], [])

    def test_le_data_uri_n_est_pas_tronque(self):
        # payload() borne la taille du texte reçu. Un PNG porté en base64 n'est
        # pas du texte : le couper rendrait l'image illisible, donc le programme
        # inexplicable. La borne ne doit pas s'appliquer à Piet.
        programme = langages_esoteriques.apercu_programme('piet')
        self.assertGreater(len(programme), 100)
        ancien = inspecteur_visuel.LIMITE_TEXTE
        inspecteur_visuel.LIMITE_TEXTE = 64
        self.addCleanup(setattr, inspecteur_visuel, 'LIMITE_TEXTE', ancien)
        donnees = inspecteur_visuel.payload('piet', 'p.png', programme)
        self.assertEqual(donnees['geometrie']['blocs'], 3)
        # Et la borne continue de s'appliquer aux langages à balisage.
        borne = inspecteur_visuel.payload('html', 'p.html', '<div>' * 100)
        self.assertTrue(borne['elements'])

    def test_les_diagnostics_fournis_sont_conserves(self):
        deja = [{'severity': 'error', 'line': 1, 'message': 'Fichier absent.'}]
        donnees = inspecteur_visuel.payload(
            'piet', 'p.png', langages_esoteriques.apercu_programme('piet'), deja)
        self.assertEqual(donnees['diagnostics'][0], deja[0])

    def test_le_meme_bloc_que_celui_du_debogueur(self):
        # La surcouche joint l'instantané du débogueur à la carte par l'index du
        # bloc : les deux doivent parler de la même géométrie.
        moteur = langages_esoteriques.Piet(
            langages_esoteriques.apercu_programme('piet'))
        moteur.charger()
        donnees = inspecteur_visuel.payload(
            'piet', 'p.png', langages_esoteriques.apercu_programme('piet'))
        actif = moteur.bloc_actif()
        carte = next(c for c in donnees['codels'] if c['index'] == actif['index'])
        self.assertEqual(carte['rectangle'], actif['rectangle'])
        self.assertEqual(carte['rvb'], actif['rvb'])
        self.assertEqual(carte['taille'], actif['taille'])


class TestBalisage(unittest.TestCase):
    def test_html_releve_les_elements_avec_leur_ligne(self):
        donnees = inspecteur_visuel.payload(
            'html', 'p.html', '<div id="a">\n  <p class="x">t</p>\n</div>')
        # Les balises fermantes ne sont pas relevées : l'inspecteur épingle des
        # nœuds, pas des textes, et un nœud s'ouvre une fois.
        self.assertEqual([e['cle'] for e in donnees['elements']],
                         ['div#a', 'p'])
        self.assertEqual(donnees['elements'][1]['ligne'], 2)
        self.assertEqual(donnees['elements'][1]['classes'], 'x')

    def test_css_releve_les_regles(self):
        donnees = inspecteur_visuel.payload(
            'css', 'p.css', 'body { color: red; }\n.a .b { x: y; }')
        self.assertEqual([r['selecteur'] for r in donnees['regles']],
                         ['body', '.a .b'])
        self.assertEqual(donnees['regles'][0]['proprietes'], {'color': 'red'})
        self.assertEqual(donnees['regles'][1]['ligne'], 2)

    def test_svg_et_xml_passent_par_la_carte_xml(self):
        for langage in ('svg', 'xml', 'csproj'):
            with self.subTest(langage=langage):
                donnees = inspecteur_visuel.payload(langage, 'p.x', '<a><b/></a>')
                self.assertEqual([e['tag'] for e in donnees['elements']],
                                 ['a', 'b'])

    def test_markdown_releve_les_blocs(self):
        donnees = inspecteur_visuel.payload(
            'markdown', 'p.md', '# titre\n\ntexte\n\n```py\nx=1\n```')
        self.assertEqual(donnees['blocs'][0]['type'], 'titre')
        self.assertEqual(donnees['blocs'][0]['niveau'], 1)
        self.assertEqual(donnees['blocs'][0]['texte'], 'titre')
        self.assertEqual(len(donnees['blocs']), 3)

    def test_latex_releve_les_environnements(self):
        donnees = inspecteur_visuel.payload(
            'latex', 'p.tex', '\\begin{itemize}\n\\item a\n\\end{itemize}')
        self.assertEqual(donnees['environnements'], [{'nom': 'itemize',
                                                      'ligne': 1}])

    def test_les_clefs_sont_stables_quel_que_soit_le_langage(self):
        clefs = None
        for langage, contenu in (('html', '<div></div>'), ('css', 'a{b:c}'),
                                 ('svg', '<svg/>'), ('markdown', '# t'),
                                 ('latex', '\\begin{a}\\end{a}'),
                                 ('xml', '<a/>'), ('json', '{}'),
                                 ('piet', langages_esoteriques.apercu_programme('piet')),
                                 ('python', 'x = 1')):
            with self.subTest(langage=langage):
                donnees = inspecteur_visuel.payload(langage, 'p', contenu)
                actuelles = set(donnees)
                if clefs is None:
                    clefs = actuelles
                else:
                    self.assertEqual(actuelles, clefs, langage)

    def test_un_langage_sans_rendu_ne_releve_rien(self):
        donnees = inspecteur_visuel.payload('python', 'p.py', 'x = 1')
        self.assertEqual(donnees['elements'], [])
        self.assertEqual(donnees['regles'], [])
        self.assertEqual(donnees['blocs'], [])
        self.assertEqual(donnees['environnements'], [])
        self.assertEqual(donnees['codels'], [])
        self.assertFalse(inspecteur_visuel.est_graphique('python'))

    def test_est_graphique_reconnait_piet(self):
        for langage in ('piet', 'html', 'css', 'svg', 'latex', 'markdown'):
            with self.subTest(langage=langage):
                self.assertTrue(inspecteur_visuel.est_graphique(langage))


class TestInjectionEtSerialisation(unittest.TestCase):
    def test_injection_avant_la_fermeture_du_corps(self):
        document = '<html><body><p>x</p></body></html>'
        rendu = inspecteur_visuel.injecter(document)
        self.assertIn('__ps_inspecteur_css', rendu)
        self.assertIn('__ps_inspecteur_js', rendu)
        self.assertLess(rendu.index('__ps_inspecteur_js'), rendu.index('</body>'))
        # Le document d'origine est conservé intact, la surcouche s'y ajoute.
        self.assertIn('<p>x</p>', rendu)
        self.assertEqual(rendu.count('__ps_inspecteur_js'), 1)
        self.assertEqual(rendu.count('</body>'), 1)

    def test_injection_sans_corps(self):
        # Un rendu cassé doit malgré tout être inspectable.
        rendu = inspecteur_visuel.injecter('<p>document sans body</p>')
        self.assertIn('__ps_inspecteur_js', rendu)
        self.assertTrue(rendu.endswith('defer></script>'))

    def test_injection_idempotente(self):
        premier = inspecteur_visuel.injecter('<html><body>x</body></html>')
        self.assertEqual(inspecteur_visuel.injecter(premier), premier)

    def test_injection_en_octets(self):
        rendu = inspecteur_visuel.injecter(b'<html><body>x</body></html>')
        self.assertIsInstance(rendu, bytes)
        self.assertIn(b'__ps_inspecteur_css', rendu)

    def test_le_chemin_de_base_est_repercuté(self):
        rendu = inspecteur_visuel.injecter('<body>x</body>', base='/apercu/')
        self.assertIn('/apercu/__ps_inspecteur_css', rendu)

    def test_donnees_json_se_relit(self):
        texte = inspecteur_visuel.donnees_json(
            'piet', 'programme.png',
            langages_esoteriques.apercu_programme('piet'))
        relues = json.loads(texte)
        self.assertEqual(relues['geometrie']['largeur'], 67)
        self.assertEqual(relues['codels'][0]['rvb'], '#FF0000')

    def test_donnees_json_conserve_les_accentuations(self):
        texte = inspecteur_visuel.donnees_json(
            'piet', 'p.png', uri([[ROUGE, BLANC, NOIR]]))
        self.assertIn('blanc', texte)
        self.assertNotIn('\\u00e9', texte)


if __name__ == '__main__':
    unittest.main(verbosity=2)
