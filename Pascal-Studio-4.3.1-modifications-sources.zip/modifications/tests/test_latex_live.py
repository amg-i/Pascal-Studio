import unittest,tempfile
from pathlib import Path
from latex_live import analyze
from latex_tools import LatexManager

class LatexStructureTests(unittest.TestCase):
 def check(self,s):return analyze('a.tex',s)['diagnostics']
 def test_environment_mismatch_and_fix(self):
  d=self.check('\\begin{document}\n\\begin{itemize}\n\\end{document}\n');self.assertTrue(any('itemize' in x['message'] for x in d),d);self.assertEqual(self.check('\\begin{document}\n\\begin{itemize}\n\\end{itemize}\n\\end{document}\n'),[])
 def test_braces_utf16_and_math(self):
  d=self.check('😀texte }\n$ x\n');self.assertEqual(d[0]['column'],9);self.assertTrue(any('mathématique' in x['message'] for x in d))
 def test_comment_escapes_verbatim(self):
  content='\\% texte \\{ \\} \\$ % } $ \\end{foo}\n\\verb|{ $ \\end{x}|\n\\begin{verbatim}\n{ $ \\begin{foo}\n\\end{verbatim}\n\\begin{document}bien\\end{document}\n';self.assertEqual(self.check(content),[])
 def test_escaped_backslash_then_comment(self):
  self.assertEqual(self.check('texte \\\\% { \\begin{z}\n'),[])
 def test_verbatim_on_same_line(self):self.assertEqual(self.check('\\begin{verbatim} { \\end{verbatim}\n'),[])
 def test_style_fragment(self):self.assertEqual(analyze('style.sty','\\newcommand{\\salut}{Bonjour}\n')['diagnostics'],[])
 def test_buffer_size(self):
  with self.assertRaises(ValueError):self.check('a'*2_000_001)

class LatexCompileProblems(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.m=LatexManager();self.file=self.root/'main.tex'
 def tearDown(self):self.m.close();self.tmp.cleanup()
 def compile(self,text):self.file.write_text(text);return self.m.compile(self.root,self.root/'cache',self.file,'main.tex',{})
 def test_empty_document_warning(self):
  r=self.compile('\\documentclass{article}\n\\begin{document}\n\\end{document}\n');self.assertTrue(r['noPages']);self.assertFalse(r['ok']);self.assertIn('AUCUNE PAGE',r['output']);self.assertEqual(r['diagnostics'][0]['line'],3);self.assertEqual(r['diagnostics'][0]['severity'],'warning');self.assertTrue(r['diagnostics'][0]['sourceHash'])
 def test_missing_package(self):
  r=self.compile('\\documentclass{article}\n\\usepackage{paquetquidontexistepas}\n\\begin{document}bonjour\\end{document}\n');self.assertFalse(r['ok']);self.assertTrue(any('not found' in x['message'] and x['line']==2 for x in r['diagnostics']),r['diagnostics'])
 def test_undefined_control_in_sty(self):
  (self.root/'monstyle.sty').write_text('\\ProvidesPackage{monstyle}\n\\undefinitelymissing\n');r=self.compile('\\documentclass{article}\n\\usepackage{monstyle}\n\\begin{document}hi\\end{document}\n');self.assertFalse(r['ok']);self.assertTrue(any(x['file']=='monstyle.sty' and x['line']==2 and x.get('sourceHash') for x in r['diagnostics']),r['diagnostics'])
 def test_valid_pdf(self):
  r=self.compile('\\documentclass{article}\n\\begin{document}Texte\\end{document}\n');self.assertTrue(r['ok'],r['output']);self.assertTrue(self.m.get(r['pdfId']).is_file())
if __name__=='__main__':unittest.main()
