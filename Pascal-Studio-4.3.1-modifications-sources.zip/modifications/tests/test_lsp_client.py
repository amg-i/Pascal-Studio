"""Tests du client LSP générique contre un faux serveur qui parle le protocole.

Aucun vrai serveur de langage n'est nécessaire : le faux serveur ci-dessous
répond à initialize, pousse publishDiagnostics, sert textDocument/completion,
et initie lui-même une requête — les quatre comportements dont dépend le
client. Les cas de dégradation (binaire absent, serveur muet, serveur qui
meurt) sont couverts, car l'interface ne doit jamais voir d'exception.
"""

import stat
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import langages
import lsp_client

FAUX_SERVEUR = r'''#!/usr/bin/env python3
import json, sys

def envoyer(m):
    corps = json.dumps(m).encode("utf8")
    sys.stdout.buffer.write(b"Content-Length: %d\r\n\r\n" % len(corps) + corps)
    sys.stdout.buffer.flush()

def lire():
    entetes = b""
    while not entetes.endswith(b"\r\n\r\n"):
        c = sys.stdin.buffer.read(1)
        if not c:
            return None
        entetes += c
    longueur = 0
    for ligne in entetes.decode("ascii", "replace").split("\r\n"):
        if ligne.lower().startswith("content-length:"):
            longueur = int(ligne.split(":", 1)[1])
    corps = b""
    while len(corps) < longueur:
        bloc = sys.stdin.buffer.read(longueur - len(corps))
        if not bloc:
            return None
        corps += bloc
    try:
        return json.loads(corps)
    except ValueError:
        return None

MODE = "@@MODE@@"
if MODE == "muet":
    while True:
        if lire() is None:
            break
    sys.exit(0)
if MODE == "mort":
    sys.exit(3)

reponses_serveur = []
while True:
    m = lire()
    if m is None:
        break
    methode = m.get("method")
    if "id" in m and methode is None:
        reponses_serveur.append(m)
        continue
    if methode == "initialize":
        envoyer({"jsonrpc": "2.0", "id": m["id"],
                 "result": {"capabilities": {"completionProvider": {}}}})
    elif methode == "textDocument/didOpen":
        d = m["params"]["textDocument"]
        envoyer({"jsonrpc": "2.0", "method": "textDocument/publishDiagnostics",
                 "params": {"uri": d["uri"], "diagnostics": [
                     {"range": {"start": {"line": 0, "character": 2},
                                "end": {"line": 0, "character": 5}},
                      "severity": 1, "message": "erreur de test",
                      "code": "T1", "source": "faux-lsp"},
                     {"range": {"start": {"line": 1, "character": 0},
                                "end": {"line": 1, "character": 1}},
                      "severity": 2, "message": "avertissement"},
                     {"range": {"start": {"line": 2, "character": 0},
                                "end": {"line": 2, "character": 1}},
                      "severity": 4, "message": "indice"},
                     {"range": {"start": {"line": 3, "character": 0},
                                "end": {"line": 3, "character": 1}},
                      "message": "sans gravité"}]}})
        envoyer({"jsonrpc": "2.0", "id": 987,
                 "method": "client/registerCapability", "params": {}})
    elif methode == "textDocument/didChange":
        pass
    elif methode == "textDocument/completion":
        envoyer({"jsonrpc": "2.0", "id": m["id"],
                 "result": {"isIncomplete": False,
                            "items": [{"label": "bonjour", "kind": 1},
                                      {"label": "au_revoir", "kind": 1}]}})
    elif methode == "textDocument/diagnostic":
        envoyer({"jsonrpc": "2.0", "id": m["id"], "result": {"items": []}})
    elif methode == "shutdown":
        envoyer({"jsonrpc": "2.0", "id": m["id"], "result": None})
    elif methode == "exit":
        break
'''

MUET = r'''#!/usr/bin/env python3
import sys, time
time.sleep(30)
'''


def ecrire_serveur(dossier, nom, source, mode='normal'):
    chemin = Path(dossier) / nom
    texte = source.replace('@@MODE@@', mode) if '@@MODE@@' in source else source
    chemin.write_text(texte, encoding='utf8')
    chemin.chmod(chemin.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return chemin


class CasLsp(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        # Les délais réels (12 s, 6 s, 3 s) rendraient la suite interminable.
        # Ils sont liés tardivement dans lsp_client, donc on peut les raccourcir
        # ici sans toucher au comportement testé.
        cls._delais = (lsp_client.DELAI_DEMARRAGE, lsp_client.DELAI_REQUETE,
                       lsp_client.DELAI_DIAGNOSTICS)
        lsp_client.DELAI_DEMARRAGE = 2
        lsp_client.DELAI_REQUETE = 2
        lsp_client.DELAI_DIAGNOSTICS = 0.6

    @classmethod
    def tearDownClass(cls):
        (lsp_client.DELAI_DEMARRAGE, lsp_client.DELAI_REQUETE,
         lsp_client.DELAI_DIAGNOSTICS) = cls._delais

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='ps-lsp-')
        self.dossier = Path(self.temporary.name)
        self.projet = self.dossier / 'projet'
        self.projet.mkdir()
        self.fichier = self.projet / 'essai.py'
        self.fichier.write_text('print(1)\n', encoding='utf8')
        self.serveur = ecrire_serveur(self.dossier, 'faux-lsp', FAUX_SERVEUR)
        self.spec = lsp_client.langages.ServeurLsp(
            str(self.serveur), 'python', (), 'installez-le')
        # shutil.which doit trouver notre faux serveur.
        self.patcheur = mock.patch.object(lsp_client.shutil, 'which',
                                          side_effect=lambda n: str(self.serveur)
                                          if n == str(self.serveur) else None)
        self.patcheur.start()

    def tearDown(self):
        self.patcheur.stop()
        self.temporary.cleanup()

    def nouveau(self):
        s = lsp_client.ServeurLsp(self.spec, self.projet)
        self.addCleanup(s.fermer)
        return s


class TestDemarrage(CasLsp):
    def test_disponible(self):
        self.assertTrue(self.nouveau().disponible())

    def test_demarrage_et_negociation(self):
        s = self.nouveau()
        self.assertTrue(s.demarrer())
        self.assertTrue(s.vivant())

    def test_binaire_absent(self):
        with mock.patch.object(lsp_client.shutil, 'which', return_value=None):
            s = lsp_client.ServeurLsp(self.spec, self.projet)
            self.assertFalse(s.disponible())
            self.assertFalse(s.demarrer())
            self.assertIn('absent', s.erreur)
            self.assertFalse(s.vivant())

    def test_serveur_qui_meurt(self):
        mort = ecrire_serveur(self.dossier, 'mort-lsp', FAUX_SERVEUR, mode='mort')
        spec = lsp_client.langages.ServeurLsp(str(mort), 'python', (), '')
        with mock.patch.object(lsp_client.shutil, 'which',
                               side_effect=lambda n: str(mort)):
            s = lsp_client.ServeurLsp(spec, self.projet)
            self.addCleanup(s.fermer)
            self.assertFalse(s.demarrer())
            self.assertEqual(s.completer(self.fichier, 'x', 1, 1), [])
            self.assertIsNone(s.diagnostiquer(self.fichier, 'x'))

    def test_serveur_muet_ne_bloque_pas(self):
        muet = ecrire_serveur(self.dossier, 'muet-lsp', MUET)
        spec = lsp_client.langages.ServeurLsp(str(muet), 'python', (), '')
        with mock.patch.object(lsp_client.shutil, 'which',
                               side_effect=lambda n: str(muet)):
            s = lsp_client.ServeurLsp(spec, self.projet)
            self.addCleanup(s.fermer)
            debut = time.monotonic()
            self.assertFalse(s.demarrer())
            self.assertLess(time.monotonic() - debut, lsp_client.DELAI_DEMARRAGE + 3)
            self.assertEqual(s.completer(self.fichier, 'x', 1, 1), [])
            self.assertIsNone(s.diagnostiquer(self.fichier, 'x'))

    def test_fermer_est_idempotent(self):
        s = self.nouveau()
        self.assertTrue(s.demarrer())
        s.fermer(); s.fermer()
        self.assertFalse(s.vivant())


class TestCompletions(CasLsp):
    def test_items_renvoyes(self):
        s = self.nouveau()
        items = s.completer(self.fichier, 'print(', 1, 7)
        self.assertEqual([i['label'] for i in items], ['bonjour', 'au_revoir'])

    def test_position_convertie_en_base_zero(self):
        s = self.nouveau()
        captures = []
        original = s._requete

        def espion(methode, params, delai=lsp_client.DELAI_REQUETE):
            if methode == 'textDocument/completion':
                captures.append(params['position'])
            return original(methode, params, delai)

        s._requete = espion
        s.completer(self.fichier, 'abc', 3, 5)
        self.assertEqual(captures[0], {'line': 2, 'character': 4})

    def test_position_negative_redressee(self):
        s = self.nouveau()
        captures = []
        original = s._requete

        def espion(methode, params, delai=lsp_client.DELAI_REQUETE):
            if methode == 'textDocument/completion':
                captures.append(params['position'])
            return original(methode, params, delai)

        s._requete = espion
        s.completer(self.fichier, 'abc', 0, 0)
        self.assertEqual(captures[0], {'line': 0, 'character': 0})

    def test_tampon_trop_volumineux(self):
        s = self.nouveau()
        self.assertEqual(s.completer(self.fichier, 'x' * (lsp_client.LIMITE_OCTETS + 1),
                                     1, 1), [])

    def test_contenu_non_textuel(self):
        s = self.nouveau()
        self.assertEqual(s.completer(self.fichier, None, 1, 1), [])

    def test_ouverture_puis_modification(self):
        s = self.nouveau()
        s.completer(self.fichier, 'a', 1, 2)
        s.completer(self.fichier, 'ab', 1, 3)
        uri = self.fichier.resolve().as_uri()
        self.assertEqual(s.documents[uri], 2)


class TestDiagnostics(CasLsp):
    def test_diagnostics_pousses_sont_recus(self):
        s = self.nouveau()
        rows = s.diagnostiquer(self.fichier, 'print(1)\nx\ny\nz\n', cle='essai.py')
        self.assertIsNotNone(rows)
        self.assertEqual(len(rows), 4)

    def test_gravites_converties(self):
        s = self.nouveau()
        rows = s.diagnostiquer(self.fichier, 'a\nb\nc\nd\n', cle='e.py')
        self.assertEqual([r['severity'] for r in rows],
                         ['error', 'warning', 'hint', 'warning'])

    def test_lignes_et_colonnes_passent_en_base_un(self):
        s = self.nouveau()
        rows = s.diagnostiquer(self.fichier, 'a\nb\nc\nd\n', cle='e.py')
        premier = rows[0]
        self.assertEqual(premier['line'], 1)
        self.assertEqual(premier['column'], 3)
        self.assertEqual(premier['endColumn'], 6)
        self.assertEqual(premier['file'], 'e.py')

    def test_code_et_source_accoles_au_message(self):
        s = self.nouveau()
        rows = s.diagnostiquer(self.fichier, 'a\nb\nc\nd\n', cle='e.py')
        self.assertIn('T1', rows[0]['message'])
        self.assertIn('faux-lsp', rows[0]['message'])

    def test_plage_inversée_redressée(self):
        d = lsp_client._convertir({'range': {'start': {'line': 5, 'character': 9},
                                             'end': {'line': 1, 'character': 1}},
                                   'severity': 1, 'message': 'x'}, 'f')
        self.assertEqual(d['line'], 6)
        self.assertEqual(d['endLine'], 6)
        self.assertGreaterEqual(d['endColumn'], d['column'])

    def test_diagnostic_sans_gravité(self):
        d = lsp_client._convertir({'range': {}, 'message': 'x'}, 'f')
        self.assertEqual(d['severity'], 'warning')
        self.assertEqual(d['line'], 1)

    def test_diagnostic_sans_message(self):
        d = lsp_client._convertir({'range': {'start': {'line': 0, 'character': 0}},
                                   'severity': 1}, 'f')
        self.assertTrue(d['message'])

    def test_requete_explicite_si_aucune_poussée(self):
        s = self.nouveau()
        # didChange ne déclenche aucune publication : la requête prend le relais.
        s.diagnostiquer(self.fichier, 'a\n', cle='e.py')
        rows = s.diagnostiquer(self.fichier, 'ab\n', cle='e.py')
        self.assertEqual(rows, [])


class TestRequeteServeur(CasLsp):
    def test_requête_initiée_par_le_serveur_reçoit_une_réponse(self):
        s = self.nouveau()
        self.assertTrue(s.demarrer())
        s.diagnostiquer(self.fichier, 'a\n', cle='e.py')
        # Le faux serveur envoie client/registerCapability avec l'id 987.
        # Si le client ne répondait pas, le serveur pourrait se bloquer ; on
        # vérifie qu'une seconde requête aboutit encore.
        items = s.completer(self.fichier, 'a', 1, 2)
        self.assertEqual(len(items), 2)


class TestGestionnaire(CasLsp):
    def setUp(self):
        super().setUp()
        spec = self.spec

        def faux_serveurs(kind):
            return (spec,) if kind == 'python' else ()

        patcheur = mock.patch.object(lsp_client.langages, 'serveurs_lsp',
                                     side_effect=faux_serveurs)
        patcheur.start()
        self.addCleanup(patcheur.stop)

    def test_serveur_mis_en_cache(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        self.addCleanup(g.fermer)
        premier = g.serveur('python')
        second = g.serveur('python')
        self.assertIs(premier, second)

    def test_langage_sans_serveur(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        self.assertIsNone(g.serveur('plaintext'))

    def test_langage_inconnu(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        self.assertIsNone(g.serveur('inexistant'))

    def test_reinitialiser_ferme_les_serveurs(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        s = g.serveur('python')
        self.assertIsNotNone(s, 'le faux serveur doit être visible du registre')
        self.assertTrue(s.demarrer())
        self.assertTrue(s.vivant())
        g.reinitialiser(self.dossier)
        self.assertFalse(s.vivant())
        self.assertEqual(g.serveurs, {})

    def test_etat_disponible(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        e = g.etat('python')
        self.assertTrue(e['disponible'])
        self.assertEqual(e['binaire'], str(self.serveur))
        self.assertEqual(e['installation'], 'installez-le')

    def test_etat_langage_sans_serveur(self):
        g = lsp_client.GestionnaireLsp(self.projet)
        e = g.etat('plaintext')
        self.assertFalse(e['disponible'])
        self.assertIsNone(e['binaire'])

    def test_etat_indisponible(self):
        with mock.patch.object(lsp_client.shutil, 'which', return_value=None):
            g = lsp_client.GestionnaireLsp(self.projet)
            e = g.etat('python')
            self.assertFalse(e['disponible'])
            self.assertIsNone(e['binaire'])
            self.assertEqual(e['installation'], 'installez-le')


class TestConversionRegistre(unittest.TestCase):
    def test_language_id_explicite(self):
        spec = langages.ServeurLsp('x', 'javascript', ())
        s = lsp_client.ServeurLsp(spec, '/tmp')
        self.assertEqual(s._language_id('/tmp/a.txt'), 'javascript')

    def test_language_id_déduit(self):
        spec = langages.ServeurLsp('x', '', ())
        s = lsp_client.ServeurLsp(spec, '/tmp')
        self.assertEqual(s._language_id('/tmp/a.rs'), 'rust')
        self.assertEqual(s._language_id('/tmp/sans_extension'), 'plaintext')


if __name__ == '__main__':
    unittest.main(verbosity=2)
