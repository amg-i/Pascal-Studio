"""Tests du moteur de complétion : bibliothèques, index, contextes, façade."""

import os
import re
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

import bibliotheques_completion as bib
import langages
import lsp_client
import moteur_completion as M


class CasProjet(unittest.TestCase):
    """Un petit projet multi-langages, recréé pour chaque test."""

    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='ps-compl-')
        self.racine = Path(self.temporary.name)
        (self.racine / 'app').mkdir()
        self.ecrire('app/main.py',
                    'def calculer_total(prix, quantite):\n'
                    '    return prix * quantite\n\n'
                    'CLASSE_IVA = 0.20\n')
        self.ecrire('app/util.py',
                    'class GestionnaireStock:\n'
                    '    def ajouter(self, article):\n        pass\n')
        self.ecrire('styles.css',
                    ':root { --couleur-primaire: #3366cc; }\n'
                    '.boite { color: var(--couleur-primaire); }\n'
                    '#entete { }\n')
        self.ecrire('index.html',
                    '<div class="boite carte" id="entete">'
                    '<h2>Mon titre de section</h2></div>\n')
        self.ecrire('doc.md', '# Introduction\n\n## Installation rapide\n')
        self.ecrire('rapport.tex', '\\section{Méthode}\n\\label{sec:methode}\n')
        self.ecrire('build.sh', 'mise_a_jour() {\n  echo ok\n}\n')

    def tearDown(self):
        self.temporary.cleanup()

    def ecrire(self, relatif, contenu):
        chemin = self.racine / relatif
        chemin.parent.mkdir(parents=True, exist_ok=True)
        chemin.write_text(contenu, encoding='utf8')
        return chemin

    def moteur(self):
        c = M.CompletionUniverselle(self.racine)
        self.addCleanup(c.fermer)
        return c

    def labels(self, items):
        return [i['label'] for i in items]


class TestBibliotheques(unittest.TestCase):
    def test_toutes_les_clefs_du_registre_existent(self):
        clefs = {langages.langage(i).bibliotheque for i in langages.tous()}
        self.assertEqual(sorted(clefs - set(bib.noms())), [])

    def test_aucune_bibliothèque_orpheline(self):
        clefs = {langages.langage(i).bibliotheque for i in langages.tous()}
        self.assertEqual(sorted(set(bib.noms()) - clefs), [])

    def test_aucun_élément_mal_découpé(self):
        """Un mot-clef contenant une espace trahirait un oubli de _m()."""
        for nom in bib.noms():
            b = bib.bibliotheque(nom)
            for champ in ('mots_clefs', 'types'):
                for element in getattr(b, champ):
                    self.assertNotIn(' ', element, '%s.%s : %r' % (nom, champ, element))

    def test_tous_les_motifs_sont_compilés_et_multilignes(self):
        for nom in bib.noms():
            for motif in bib.motifs(nom):
                self.assertTrue(hasattr(motif.expression, 'finditer'), nom)
                self.assertTrue(motif.expression.flags & re.MULTILINE,
                                '%s : motif non MULTILINE' % nom)
                self.assertGreaterEqual(motif.groupe, 1)

    def test_extraits_bien_formés(self):
        for nom in bib.noms():
            for e in bib.extraits(nom):
                self.assertTrue(e.libelle, nom)
                self.assertTrue(e.insertion, '%s : %s' % (nom, e.libelle))
                self.assertEqual(e.genre, bib.EXTRAIT)

    def test_langages_sans_bibliothèque_utile(self):
        self.assertEqual(len(bib.mots_clefs('plaintext')), 0)
        self.assertEqual(len(bib.extraits('plaintext')), 0)

    def test_repli_sur_plaintext(self):
        self.assertEqual(bib.bibliotheque('inexistant').nom, 'plaintext')
        self.assertEqual(bib.bibliotheque(None).nom, 'plaintext')
        self.assertEqual(bib.bibliotheque('').nom, 'plaintext')

    def test_tables_css_et_html_réutilisées(self):
        """La complétion ne doit pas proposer ce que l'analyseur rejette."""
        import verificateurs_statiques as V
        self.assertEqual(set(bib.mots_clefs('css')), set(V.PROPRIETES_CSS))
        self.assertEqual(set(bib.mots_clefs('csharp')), set(V.MOTS_CLEFS_CS))
        self.assertIn('if', bib.mots_clefs('cmake'))
        for commande in V.COMMANDES_CMAKE:
            self.assertIn(commande, bib.mots_clefs('cmake'))

    def test_valeurs_css_couvrantes(self):
        v = bib.valeurs('css')
        self.assertIn('flex', v['display'].split())
        self.assertIn('sticky', v['position'].split())
        self.assertIn('border-box', v['box-sizing'].split())

    def test_valeurs_html_couvrantes(self):
        v = bib.valeurs('html')
        self.assertIn('password', v['type'].split())
        self.assertIn('_blank', v['target'].split())

    def test_volume_minimal(self):
        """Garde-fou : une bibliothèque vidée par erreur se verrait ici."""
        for nom in ('pascal', 'c', 'cpp', 'python', 'javascript', 'html', 'css',
                    'latex', 'rust', 'go', 'swift', 'kotlin', 'bash'):
            self.assertGreaterEqual(len(bib.mots_clefs(nom)), 20, nom)
            self.assertGreaterEqual(len(bib.extraits(nom)), 5, nom)


class TestNomsExtraits(unittest.TestCase):
    def test_noms_valides(self):
        for nom in ('sec:methode', '--couleur-primaire', 'Foo::Bar', 'List.map',
                    'calculer_total', 'flow-root', 'GestionnaireStock'):
            self.assertEqual(M._noms_extraits(nom, 1, ''), [nom], nom)

    def test_noms_rejetés(self):
        for nom in ('-e', '--', '', '1abc', '.boite', '#x', 'x' * 70,
                    'a\nb', 'a\tb', '   '):
            self.assertEqual(M._noms_extraits(nom, 1, ''), [], repr(nom))

    def test_classes_découpées(self):
        self.assertEqual(M._noms_extraits('boite carte', bib.CLASSE, 'classe'),
                         ['boite', 'carte'])

    def test_titre_devient_une_ancre_sans_dièse(self):
        self.assertEqual(M._noms_extraits('Mon titre de section', bib.REFERENCE, 'titre'),
                         ['mon-titre-de-section'])

    def test_ancre_avec_dièse(self):
        self.assertEqual(M._noms_extraits('Installation rapide', bib.REFERENCE, 'ancre'),
                         ['#installation-rapide'])

    def test_ancre_normalise_les_accents_et_la_ponctuation(self):
        # « : » et « ! » sont retirés, les espaces fusionnent en UN tiret.
        self.assertEqual(M._noms_extraits('Méthode : Résultats !', bib.REFERENCE, 'ancre'),
                         ['#méthode-résultats'])

    def test_pas_de_doublon(self):
        self.assertEqual(M._noms_extraits('a a b', bib.CLASSE, 'classe'), ['a', 'b'])

    def test_morceaux_trop_longs_écartés(self):
        self.assertEqual(M._noms_extraits('a ' + 'x' * 70, bib.CLASSE, 'classe'), ['a'])


class TestPertinence(unittest.TestCase):
    def test_préfixe_exact(self):
        self.assertEqual(M._pertinence('while', 'whi'), 0)
        self.assertEqual(M._pertinence('While', 'whi'), 0)

    def test_contient(self):
        self.assertEqual(M._pertinence('audio', 'di'), 1)

    def test_préfixe_d_un_mot(self):
        self.assertEqual(M._pertinence('background-color', 'color'), 1)

    def test_acronyme(self):
        self.assertEqual(M._pertinence('calculer_total', 'ct'), 2)
        self.assertEqual(M._pertinence('GestionnaireStock', 'gs'), 2)

    def test_sans_correspondance(self):
        self.assertIsNone(M._pertinence('while', 'xyz'))

    def test_préfixe_vide(self):
        self.assertEqual(M._pertinence('n_importe', ''), 0)


class TestPositionnement(unittest.TestCase):
    def test_texte_avant_curseur(self):
        self.assertEqual(M._positionner('abc\ndef\n', 2, 3), 'de')

    def test_ligne_hors_texte(self):
        self.assertEqual(M._positionner('abc\n', 99, 1), '')

    def test_ligne_zéro(self):
        self.assertEqual(M._positionner('abc\n', 0, 1), '')

    def test_colonne_hors_ligne(self):
        self.assertEqual(M._positionner('abc', 1, 99), 'abc')

    def test_colonne_zéro(self):
        self.assertEqual(M._positionner('abc', 1, 0), '')

    def test_préfixe(self):
        self.assertEqual(M._prefixe('x = calc'), 'calc')
        self.assertEqual(M._prefixe('var(--co'), '--co')
        self.assertEqual(M._prefixe('<di'), 'di')
        self.assertEqual(M._prefixe('a b '), '')
        self.assertEqual(M._prefixe(''), '')


class TestContexte(unittest.TestCase):
    def test_html_balise(self):
        self.assertEqual(M._contexte('html', '<di'), M.CTX_BALISE_HTML)
        self.assertEqual(M._contexte('html', '</di'), M.CTX_BALISE_HTML)

    def test_html_attribut(self):
        self.assertEqual(M._contexte('html', '<div cl'), M.CTX_ATTRIBUT_HTML)

    def test_html_valeur(self):
        self.assertEqual(M._contexte('html', '<input type="pa'), M.CTX_VALEUR_ATTRIBUT)

    def test_html_code(self):
        self.assertEqual(M._contexte('html', '<div>texte'), M.CTX_CODE)

    def test_css_propriete(self):
        self.assertEqual(M._contexte('css', '.x { colo'), M.CTX_PROPRIETE_CSS)
        self.assertEqual(M._contexte('css', 'color: red; back'), M.CTX_PROPRIETE_CSS)

    def test_css_valeur(self):
        self.assertEqual(M._contexte('css', '.x { display: fl'), M.CTX_VALEUR_CSS)

    def test_css_selecteur(self):
        self.assertEqual(M._contexte('css', '.bo'), M.CTX_SELECTEUR_CSS)

    def test_latex_commande(self):
        self.assertEqual(M._contexte('latex', '\\sec'), M.CTX_COMMANDE_LATEX)

    def test_latex_argument(self):
        self.assertEqual(M._contexte('latex', '\\ref{sec'), M.CTX_ARGUMENT_LATEX)
        self.assertEqual(M._contexte('latex', '\\cite[p. 12]{cle'),
                         M.CTX_ARGUMENT_LATEX)

    def test_latex_texte(self):
        self.assertEqual(M._contexte('latex', 'du texte'), M.CTX_CODE)

    def test_markdown_lien(self):
        self.assertEqual(M._contexte('markdown', 'Voir [x](#ins'),
                         M.CTX_LIEN_MARKDOWN)

    def test_markdown_code(self):
        self.assertEqual(M._contexte('markdown', '# Titre'), M.CTX_CODE)

    def test_json_clef(self):
        self.assertEqual(M._contexte('json', '{"a'), M.CTX_CLE_JSON)
        self.assertEqual(M._contexte('json', '{"a": 1, "b'), M.CTX_CLE_JSON)

    def test_xml(self):
        self.assertEqual(M._contexte('xml', '<roo'), M.CTX_BALISE_HTML)
        self.assertEqual(M._contexte('xml', '<root att="v'), M.CTX_VALEUR_ATTRIBUT)

    def test_python_toujours_code(self):
        self.assertEqual(M._contexte('python', 'x = '), M.CTX_CODE)

    def test_attribut_courant(self):
        self.assertEqual(M._attribut_courant('<input type="pa'), 'type')
        self.assertEqual(M._attribut_courant('<div data-x="1'), 'data-x')
        self.assertEqual(M._attribut_courant('<div'), '')

    def test_propriete_courante(self):
        self.assertEqual(M._propriete_courante('.x { display: fl'), 'display')
        self.assertEqual(M._propriete_courante('color: red; margin: 0'), 'margin')

    def test_commande_latex_courante(self):
        self.assertEqual(M._commande_latex_courante('\\ref{sec'), 'ref')
        self.assertEqual(M._commande_latex_courante('\\cite[p.1]{x'), 'cite')


class TestExtraction(CasProjet):
    def setUp(self):
        super().setUp()
        self.index = M.IndexProjet(self.racine)

    def test_symboles_python(self):
        noms = sorted(self.index.symboles('python', force=True))
        self.assertIn('calculer_total', noms)
        self.assertIn('GestionnaireStock', noms)
        self.assertIn('CLASSE_IVA', noms)

    def test_symboles_css(self):
        noms = sorted(self.index.symboles('css', force=True))
        self.assertIn('--couleur-primaire', noms)
        self.assertIn('boite', noms)
        self.assertIn('entete', noms)

    def test_symboles_html(self):
        noms = sorted(self.index.symboles('html', force=True))
        self.assertIn('boite', noms)
        self.assertIn('carte', noms)
        self.assertIn('entete', noms)
        self.assertIn('mon-titre-de-section', noms)
        # Les balises standard ne sont pas des symboles du projet.
        self.assertNotIn('div', noms)

    def test_etiquettes_latex_avec_deux_points(self):
        self.assertIn('sec:methode', self.index.symboles('latex', force=True))

    def test_ancres_markdown(self):
        noms = sorted(self.index.symboles('markdown', force=True))
        self.assertIn('#installation-rapide', noms)
        self.assertIn('#introduction', noms)

    def test_fonctions_shell(self):
        self.assertIn('mise_a_jour', self.index.symboles('bash', force=True))

    def test_numero_de_ligne(self):
        symboles = self.index.symboles('python', force=True)
        self.assertEqual(symboles['calculer_total'].ligne, 1)
        self.assertEqual(symboles['CLASSE_IVA'].ligne, 4)

    def test_fichier_source_du_symbole(self):
        symbole = self.index.symboles('python', force=True)['GestionnaireStock']
        self.assertTrue(symbole.fichier.endswith('util.py'))
        self.assertIn('util.py', symbole.detail)

    def test_dossiers_ignorés(self):
        self.ecrire('node_modules/paquet/index.js', 'function indésirable() {}')
        self.ecrire('.git/config', 'function indésirable() {}')
        self.ecrire('__pycache__/x.py', 'def indésirable(): pass')
        index = M.IndexProjet(self.racine)
        noms = index.symboles('javascript', force=True)
        self.assertNotIn('indésirable', noms)
        self.assertNotIn('indésirable', index.symboles('python', force=True))

    def test_fichier_trop_volumineux_ignoré(self):
        gros = self.racine / 'gros.py'
        gros.write_text('def petit():\n    pass\n' + '#' * (M.LIMITE_OCTETS_INDEX + 10),
                        encoding='utf8')
        index = M.IndexProjet(self.racine)
        self.assertNotIn('petit', index.symboles('python', force=True))

    def test_fichier_binaire_ne_plante_pas(self):
        (self.racine / 'donnees.py').write_bytes(b'\x00\x01\x02\xff\xfe')
        index = M.IndexProjet(self.racine)
        self.assertIsInstance(index.symboles('python', force=True), dict)

    def test_fichier_inconnu_non_indexable(self):
        self.ecrire('archive.xyz', 'def mystere(): pass')
        index = M.IndexProjet(self.racine)
        index.symboles('python', force=True)
        self.assertNotIn('mystere', index.symboles('python', force=True))


class TestCache(CasProjet):
    def test_le_cache_évite_une_relecture(self):
        index = M.IndexProjet(self.racine)
        index.symboles('python', force=True)
        with mock.patch.object(index, 'extraire', wraps=index.extraire) as espion:
            index.symboles('python', force=True)
            self.assertEqual(espion.call_count, 0)

    def test_modification_prise_en_compte(self):
        index = M.IndexProjet(self.racine)
        self.assertNotIn('nouveau_symbole', index.symboles('python', force=True))
        chemin = self.ecrire('app/main.py', 'def nouveau_symbole():\n    pass\n')
        # La signature du cache repose sur st_mtime_ns : on la force à changer,
        # au cas où le système de fichiers aurait une résolution trop faible.
        instant = time.time_ns() + 10 ** 9
        os.utime(chemin, ns=(instant, instant))
        self.assertIn('nouveau_symbole', index.symboles('python', force=True))

    def test_suppression_prise_en_compte(self):
        index = M.IndexProjet(self.racine)
        self.assertIn('GestionnaireStock', index.symboles('python', force=True))
        (self.racine / 'app' / 'util.py').unlink()
        self.assertNotIn('GestionnaireStock', index.symboles('python', force=True))

    def test_fraîcheur_respectée(self):
        index = M.IndexProjet(self.racine)
        index.symboles('python', force=True)
        with mock.patch.object(index, 'fichiers', wraps=index.fichiers) as espion:
            index.symboles('python')
            self.assertEqual(espion.call_count, 0, 'le cache devait servir')

    def test_budget_de_lecture(self):
        """Un projet plus grand que le budget est parcouru en plusieurs fois."""
        for i in range(6):
            self.ecrire('app/extra%d.py' % i, 'def sym_%d():\n    pass\n' % i)
        index = M.IndexProjet(self.racine)
        with mock.patch.object(M, 'BUDGET_LECTURES', 3):
            self.assertFalse(index._analyser(3), 'le parcours devait être incomplet')
            self.assertTrue(index._analyser(100), 'le second devait aboutir')
        noms = index.symboles('python', force=True)
        for i in range(6):
            self.assertIn('sym_%d' % i, noms)

    def test_cache_non_élagué_sur_parcours_incomplet(self):
        """Sinon les fichiers non visités seraient relus indéfiniment."""
        for i in range(6):
            self.ecrire('app/extra%d.py' % i, 'def sym_%d():\n    pass\n' % i)
        index = M.IndexProjet(self.racine)
        index.symboles('python', force=True)
        taille_avant = len(index.cache)
        index._analyser(0)
        self.assertEqual(len(index.cache), taille_avant)

    def test_reinitialiser_vide_tout(self):
        index = M.IndexProjet(self.racine)
        index.symboles('python', force=True)
        self.assertTrue(index.cache)
        index.reinitialiser(self.racine / 'app')
        self.assertEqual(index.cache, {})
        self.assertEqual(index.par_langage, {})
        index.vider()
        self.assertEqual(index.cache, {})

    def test_racine_inexistante(self):
        index = M.IndexProjet(self.racine / 'introuvable')
        self.assertEqual(index.fichiers(), [])
        self.assertEqual(index.symboles('python', force=True), {})

    def test_limite_de_fichiers(self):
        index = M.IndexProjet(self.racine)
        with mock.patch.object(M, 'LIMITE_FICHIERS', 3):
            self.assertLessEqual(len(index.fichiers()), 3)


class TestMoteurLocal(CasProjet):
    def setUp(self):
        super().setUp()
        self.moteur = M.MoteurLocal(self.racine)

    def complete(self, fichier, texte, ligne=1, colonne=None):
        return self.moteur.completer(
            langages.resoudre(Path(fichier).suffix), self.racine / fichier,
            texte, ligne, colonne if colonne is not None else len(texte) + 1)

    def test_symbole_du_projet(self):
        self.assertIn('calculer_total', self.labels(self.complete('x.py', 'cal')))

    def test_symbole_d_un_autre_fichier(self):
        self.assertIn('GestionnaireStock', self.labels(self.complete('x.py', 'Gest')))

    def test_mot_clef(self):
        self.assertEqual(self.labels(self.complete('x.py', 'whi')), ['while'])

    def test_le_préfixe_filtre(self):
        """Sans filtrage, chaque frappe renverrait des centaines d'items."""
        self.assertLessEqual(len(self.complete('x.py', 'whi')), 5)
        self.assertLess(len(self.complete('x.py', 'whi')),
                        len(self.complete('x.py', '')))

    def test_acronyme(self):
        self.assertIn('calculer_total', self.labels(self.complete('x.py', 'ct')))

    def test_extrait_avec_tabulations(self):
        items = self.complete('x.py', 'def')
        extrait = next((i for i in items if i['kind'] == bib.EXTRAIT
                        and i['label'] == 'def'), None)
        self.assertIsNotNone(extrait)
        self.assertEqual(extrait['insertTextFormat'], 2)
        self.assertIn('${1:nom}', extrait['insertText'])
        self.assertEqual(extrait['filterText'], 'def')

    def test_mot_clef_inséré_tel_quel(self):
        item = next(i for i in self.complete('x.py', 'whi') if i['label'] == 'while')
        self.assertEqual(item['insertTextFormat'], 1)
        self.assertEqual(item['insertText'], 'while')

    def test_html_balise(self):
        items = self.complete('index.html', '<di')
        self.assertIn('div', self.labels(items))
        div = next(i for i in items if i['label'] == 'div')
        # Sans le « < » : Monaco remplace le mot, qui commence après lui.
        self.assertEqual(div['insertText'], 'div>$0</div>')

    def test_html_balise_auto_fermante(self):
        items = self.complete('index.html', '<im')
        img = next(i for i in items if i['label'] == 'img')
        self.assertEqual(img['insertText'], 'img>')

    def test_html_pas_d_attributs_après_une_balise(self):
        """Après « < », proposer 117 attributs noierait les balises."""
        items = self.complete('index.html', '<di')
        self.assertNotIn('accesskey', self.labels(items))

    def test_html_attribut(self):
        self.assertIn('class', self.labels(self.complete('index.html', '<div cl')))

    def test_html_valeur_d_attribut(self):
        self.assertEqual(self.labels(self.complete('index.html', '<input type="pa')),
                         ['password'])

    def test_html_fichier_pour_src(self):
        self.assertIn('styles.css', self.labels(self.complete('index.html', '<img src="st')))

    def test_css_propriété(self):
        items = self.complete('styles.css', '.x { colo')
        self.assertEqual(items[0]['label'], 'color')
        self.assertEqual(items[0]['insertText'], 'color: $0;')

    def test_css_valeur(self):
        self.assertIn('flex', self.labels(self.complete('styles.css', '.x { display: fl')))

    def test_css_pas_de_propriétés_après_les_deux_points(self):
        self.assertNotIn('align-content',
                         self.labels(self.complete('styles.css', '.x { display: ')))

    def test_css_variable_personnalisée(self):
        self.assertIn('--couleur-primaire',
                      self.labels(self.complete('styles.css', '.x { color: var(--cou')))

    def test_css_sélecteur_depuis_le_html(self):
        self.assertIn('.boite', self.labels(self.complete('styles.css', '.')))
        self.assertIn('#entete', self.labels(self.complete('styles.css', '.')))

    def test_latex_commande(self):
        item = next(i for i in self.complete('rapport.tex', '\\sec')
                    if i['label'] == 'section')
        self.assertEqual(item['insertText'], 'section')
        self.assertEqual(item['filterText'], 'section')

    def test_latex_étiquette(self):
        self.assertIn('sec:methode', self.labels(self.complete('rapport.tex', '\\ref{sec')))

    def test_markdown_ancre(self):
        self.assertIn('#installation-rapide',
                      self.labels(self.complete('doc.md', 'Voir [x](#ins')))

    def test_symboles_du_tampon_non_enregistré(self):
        # Le fichier x.py n'existe pas sur le disque : seuls comptent les
        # symboles du texte en cours d'édition.
        items = self.complete('x.py', 'def fonction_du_tampon():\n    pass\nfonc',
                              ligne=3, colonne=5)
        self.assertIn('fonction_du_tampon', self.labels(items))

    def test_tampon_prioritaire_sur_le_projet(self):
        items = self.complete('x.py', 'def fonction_locale():\n    pass\nfonc',
                              ligne=3, colonne=5)
        self.assertEqual(items[0]['label'], 'fonction_locale')
        self.assertEqual(items[0]['sortText'][0], M.RANG_TAMPON)

    def test_plaintext_ne_propose_rien_de_spécifique(self):
        self.assertEqual(self.moteur.completer('plaintext', self.racine / 'a.txt',
                                               'abc', 1, 4), [])

    def test_contenu_non_textuel(self):
        self.assertEqual(self.moteur.completer('python', self.racine / 'a.py',
                                               None, 1, 1), [])

    def test_langage_inconnu(self):
        self.assertEqual(self.moteur.completer('inexistant', self.racine / 'a.x',
                                               'abc', 1, 4), [])

    def test_index_injoignable_ne_plante_pas(self):
        with mock.patch.object(self.moteur.index, 'symboles',
                               side_effect=OSError('disque')):
            self.assertIsInstance(self.complete('x.py', 'cal'), list)


class TestFaçade(CasProjet):
    def test_contrat_position_invalide(self):
        c = self.moteur()
        for ligne, colonne in ((0, 1), (1, 0), (-1, 1), (1, -1)):
            with self.assertRaises(ValueError):
                c.complete(self.racine / 'a.py', 'x', ligne, colonne)

    def test_contrat_position_non_entière(self):
        c = self.moteur()
        with self.assertRaises(ValueError):
            c.complete(self.racine / 'a.py', 'x', '1', 1)

    def test_contrat_tampon_manquant(self):
        c = self.moteur()
        with self.assertRaises(ValueError):
            c.complete(self.racine / 'a.py', None, 1, 1)

    def test_contrat_tampon_trop_volumineux(self):
        c = self.moteur()
        with self.assertRaises(ValueError):
            c.complete(self.racine / 'a.py', 'x' * (M.LIMITE_OCTETS + 1), 1, 1)

    def test_repli_local_quand_aucun_serveur(self):
        c = self.moteur()
        items = c.complete(self.racine / 'app' / 'main.py', 'cal', 1, 4)
        self.assertIn('calculer_total', self.labels(items))
        self.assertEqual(c.source_derniere(), 'locale')

    def test_serveur_lsp_prioritaire(self):
        c = self.moteur()
        spec = langages.ServeurLsp('faux-lsp', 'python', (), '')
        faux = mock.Mock(spec=lsp_client.ServeurLsp)
        faux.spec = spec
        faux.completer.return_value = [{'label': 'depuis_le_serveur', 'kind': 1}]
        with mock.patch.object(c.lsp, 'serveur', return_value=faux):
            items = c.complete(self.racine / 'app' / 'main.py', 'cal', 1, 4)
        self.assertEqual(self.labels(items), ['depuis_le_serveur'])
        self.assertEqual(c.source_derniere(), 'lsp:faux-lsp')

    def test_repli_local_si_le_serveur_ne_renvoie_rien(self):
        c = self.moteur()
        faux = mock.Mock(spec=lsp_client.ServeurLsp)
        faux.spec = langages.ServeurLsp('faux-lsp', 'python', (), '')
        faux.completer.return_value = []
        with mock.patch.object(c.lsp, 'serveur', return_value=faux):
            items = c.complete(self.racine / 'app' / 'main.py', 'cal', 1, 4)
        self.assertIn('calculer_total', self.labels(items))
        self.assertEqual(c.source_derniere(), 'locale')

    def test_plafond_d_items(self):
        c = self.moteur()
        faux = mock.Mock(spec=lsp_client.ServeurLsp)
        faux.spec = langages.ServeurLsp('faux-lsp', 'python', (), '')
        faux.completer.return_value = [{'label': 'i%d' % i, 'kind': 1}
                                       for i in range(500)]
        with mock.patch.object(c.lsp, 'serveur', return_value=faux):
            self.assertEqual(len(c.complete(self.racine / 'a.py', 'x', 1, 2)),
                             M.LIMITE_ITEMS)

    def test_langage_déduit_de_l_extension(self):
        c = self.moteur()
        with mock.patch.object(c.local, 'completer', wraps=c.local.completer) as espion:
            c.complete(self.racine / 'app' / 'main.py', 'cal', 1, 4)
            self.assertEqual(espion.call_args[0][0], 'python')
            c.complete(self.racine / 'styles.css', '.x { colo', 1, 10)
            self.assertEqual(espion.call_args[0][0], 'css')

    def test_extension_inconnue(self):
        c = self.moteur()
        self.assertEqual(c.complete(self.racine / 'a.zzz', 'x', 1, 2), [])

    def test_etat(self):
        c = self.moteur()
        e = c.etat(self.racine / 'app' / 'main.py')
        self.assertEqual(e['langage'], 'python')
        self.assertEqual(e['libelle'], 'Python')
        self.assertEqual(e['source'], 'moteur local')
        self.assertIsNone(e['binaire'])
        self.assertGreater(e['mots_clefs'], 50)
        self.assertGreater(e['extraits'], 5)

    def test_etat_avec_serveur_disponible(self):
        c = self.moteur()
        with mock.patch.object(c.lsp, 'etat', return_value={
                'disponible': True, 'binaire': 'pylsp', 'installation': 'apt'}):
            self.assertEqual(c.etat('a.py')['source'], 'serveur')

    def test_reinitialiser(self):
        c = self.moteur()
        c.complete(self.racine / 'app' / 'main.py', 'cal', 1, 4)
        self.assertTrue(c.local.index.cache)
        c.reinitialiser(self.racine / 'app')
        self.assertEqual(c.local.index.cache, {})
        self.assertEqual(c.racine, (self.racine / 'app').resolve())

    def test_fermer_est_idempotent(self):
        c = M.CompletionUniverselle(self.racine)
        c.close(); c.fermer()

    def test_close_et_fermer_sont_le_même(self):
        self.assertIs(M.CompletionUniverselle.close, M.CompletionUniverselle.fermer)


class TestAncrage(CasProjet):
    """La plage explicite évite que Monaco devine le mot à remplacer."""

    def test_plage_du_préfixe(self):
        plage = M._plage_prefixe(3, 8, 'colo')
        self.assertEqual(plage, {'start': {'line': 2, 'character': 3},
                                 'end': {'line': 2, 'character': 7}})

    def test_plage_sans_débordement(self):
        plage = M._plage_prefixe(1, 1, 'abc')
        self.assertEqual(plage['start']['character'], 0)
        self.assertEqual(plage['end']['character'], 0)

    def test_balise_html_ancrée(self):
        items = self.moteur().local.completer('html', self.racine / 'x.html',
                                              '<di', 1, 4)
        div = next(i for i in items if i['label'] == 'div')
        self.assertIn('textEdit', div)
        self.assertEqual(div['textEdit']['newText'], 'div>$0</div>')
        self.assertEqual(div['textEdit']['range']['start']['character'], 1)
        self.assertEqual(div['textEdit']['range']['end']['character'], 3)

    def test_commande_latex_ancrée(self):
        items = self.moteur().local.completer('latex', self.racine / 'x.tex',
                                              '\\sec', 1, 5)
        section = next(i for i in items if i['label'] == 'section')
        self.assertEqual(section['textEdit']['range']['start']['character'], 1)

    def test_contexte_ordinaire_non_ancré(self):
        """Un mot-clef se remplace naturellement : pas besoin de plage."""
        items = self.moteur().local.completer('python', self.racine / 'x.py',
                                              'whi', 1, 4)
        self.assertNotIn('textEdit', items[0])

    def test_préfixe_vide_non_ancré(self):
        items = self.moteur().local.completer('html', self.racine / 'x.html',
                                              '<', 1, 2)
        self.assertTrue(items)
        self.assertNotIn('textEdit', items[0])

    def test_ancrer_renvoie_les_items(self):
        items = [M._item('a', bib.MOT_CLEF)]
        self.assertIs(M._ancrer(items, M._plage_prefixe(1, 2, 'a')), items)


class TestDédoublonnage(unittest.TestCase):
    def test_le_meilleur_rang_gagne(self):
        items = [
            M._item('nom', bib.VARIABLE, 'projet', rang=M.RANG_PROJET),
            M._item('nom', bib.FONCTION, 'ce fichier', rang=M.RANG_TAMPON),
        ]
        resultat = M._dedoublonner(items)
        self.assertEqual(len(resultat), 1)
        self.assertEqual(resultat[0]['detail'], 'ce fichier')

    def test_insertions_différentes_conservées(self):
        items = [M._item('div', bib.MODULE, 'balise', insertion='<div>$0</div>'),
                 M._item('div', bib.VARIABLE, 'variable')]
        self.assertEqual(len(M._dedoublonner(items)), 2)

    def test_tri_par_sorttext(self):
        items = [M._item('z', bib.MOT_CLEF, rang='3'),
                 M._item('a', bib.MOT_CLEF, rang='1')]
        self.assertEqual([i['label'] for i in M._dedoublonner(items)], ['a', 'z'])

    def test_filtrer_préfixe_vide(self):
        items = [M._item('while', bib.MOT_CLEF, rang='3')]
        self.assertIs(M._filtrer(items, ''), items)

    def test_filtrer_reconstruit_le_tri(self):
        items = [M._item('while', bib.MOT_CLEF, rang='3'),
                 M._item('switch', bib.MOT_CLEF, rang='3')]
        gardes = M._filtrer(items, 'whi')
        self.assertEqual(len(gardes), 1)
        self.assertEqual(gardes[0]['sortText'], '30while')

    def test_filtrer_utilise_filtertext(self):
        items = [M._item('section', bib.FONCTION, insertion='\\section',
                         filtre='section', rang='0')]
        self.assertEqual(len(M._filtrer(items, '\\sec')), 0)
        self.assertEqual(len(M._filtrer(items, 'sec')), 1)

    def test_filtrer_ne_modifie_pas_l_original(self):
        items = [M._item('while', bib.MOT_CLEF, rang='3')]
        avant = items[0].get('sortText')
        M._filtrer(items, 'whi')
        self.assertEqual(items[0].get('sortText'), avant)


if __name__ == '__main__':
    unittest.main(verbosity=2)
