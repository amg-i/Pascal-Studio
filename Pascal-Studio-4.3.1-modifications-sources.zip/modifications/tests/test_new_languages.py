"""Intégration Rust, Go et Ruby : compilation, entrées, diagnostics et TODO."""
import json,os,shutil,socket,subprocess,sys,tempfile,time,unittest,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import polyglot,project_tools,scripting

class SupportTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.build=self.root/'build';self.build.mkdir()
 def tearDown(self):self.temp.cleanup()
 def build_file(self,name,text):
  p=self.root/name;p.write_text(text,encoding='utf8');k=polyglot.kind(p)
  return scripting.build(k,p,name) if k=='ruby' else polyglot.build(self.root,self.build,p,{})
 def test_extensions(self):
  for name,k in [('a.rs','rust'),('a.go','go'),('a.rb','ruby')]:self.assertEqual(polyglot.kind(name),k)
 @unittest.skipUnless(shutil.which('rustc'),'rustc absent')
 def test_rust_compile_execute_and_diagnostic(self):
  r=self.build_file('hello-world.rs','fn main() { println!("Bonjour Rust"); }\n');self.assertTrue(r['ok'],r);self.assertIn('Bonjour Rust',subprocess.check_output([r['binary']],text=True))
  bad=self.build_file('hello-world.rs','fn main() { let x = ; }\n');self.assertFalse(bad['ok']);self.assertFalse(Path(r['binary']).exists());self.assertEqual(bad['diagnostics'][0]['line'],1)
 @unittest.skipUnless(shutil.which('go'),'go absent')
 def test_go_compile_execute_and_diagnostic(self):
  r=self.build_file('main.go','package main\nimport "fmt"\nfunc main() { fmt.Println("Bonjour Go") }\n');self.assertTrue(r['ok'],r);self.assertIn('Bonjour Go',subprocess.check_output([r['binary']],text=True))
  bad=self.build_file('main.go','package main\nfunc main() { inconnue() }\n');self.assertFalse(bad['ok']);self.assertFalse(Path(r['binary']).exists());self.assertEqual((bad['diagnostics'][0]['file'],bad['diagnostics'][0]['line']),('main.go',2))
 @unittest.skipUnless(shutil.which('ruby'),'ruby absent')
 def test_ruby_live_without_execution_and_execute(self):
  f=self.root/'marqueur';src=f'File.write({str(f)!r}, "non")\nputs "Bonjour Ruby"\n'
  a=scripting.analyze('ruby',self.root/'main.rb','main.rb',src);self.assertTrue(a['ok']);self.assertFalse(f.exists())
  bad=scripting.analyze('ruby',self.root/'main.rb','main.rb','def salut(\n');self.assertFalse(bad['ok']);self.assertEqual(bad['diagnostics'][0]['line'],1)
  r=self.build_file('main.rb','puts "Bonjour Ruby"\n');self.assertTrue(r['ok']);self.assertIn('Bonjour Ruby',subprocess.check_output(r['command'],text=True))
 def test_todos_in_comments_not_strings(self):
  for n,t in [('a.rs','let s = "TODO non"; // TODO Rust\n'),('b.go','var x = "TODO non" // FIXME Go\n'),('c.rb','puts "TODO non" # TODO Ruby\n')]: (self.root/n).write_text(t)
  r=project_tools.todos(self.root);self.assertEqual({x['path'] for x in r['items']},{'a.rs','b.go','c.rb'});self.assertEqual(len(r['items']),3)

class InteractiveTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();self.base=f'http://127.0.0.1:{port}/api/'
  env={**os.environ,'PASCAL_WORKSPACE':str(self.root),'PASCAL_PORT':str(port),'XDG_CACHE_HOME':str(self.root/'cache')};self.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(100):
   try:self.req('status');break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('API indisponible')
 def tearDown(self):
  self.proc.terminate();self.proc.wait(timeout=6);self.tmp.cleanup()
 def req(self,path,data=None):
  r=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
  with urllib.request.urlopen(r,timeout=180) as response:return json.load(response)
 def test_interactive_all_languages(self):
  tests=[('rustc','a.rs','use std::io;\nfn main(){ let mut s=String::new(); println!("PRET"); io::stdin().read_line(&mut s).unwrap(); println!("Salut {}",s.trim()); }\n'),('go','a.go','package main\nimport ("fmt"; "bufio"; "os"; "strings")\nfunc main(){fmt.Println("PRET"); s,_:=bufio.NewReader(os.Stdin).ReadString(\'\\n\');fmt.Println("Salut",strings.TrimSpace(s))}\n'),('ruby','a.rb','puts "PRET"\nSTDOUT.flush\nnom = gets\nputs "Salut #{nom.strip}"\n')]
  for exe,name,source in tests:
   if not shutil.which(exe):continue
   with self.subTest(lang=exe):
    (self.root/name).write_text(source);result=self.req('run',{'path':name});self.assertTrue(result['ok'],result)
    for _ in range(200):
     p=self.req('process')
     if 'PRET' in p['output']:break
     time.sleep(.05)
    else:self.fail('Entrée non attendue pour '+exe)
    self.req('input',{'text':'Alice'})
    for _ in range(200):
     p=self.req('process')
     if not p['running']:break
     time.sleep(.05)
    self.assertEqual(p['exitCode'],0,p);self.assertIn('Salut Alice',p['output'])

if __name__=='__main__':unittest.main()
