"""Comptes GitHub/GitLab : identité publiée, persistance chiffrée, expiration."""
import os, tempfile, time, unittest
from pathlib import Path
from unittest import mock
import account_store
import oauth_accounts as oa

GH_USER = {'login': 'alice', 'name': 'Alice Martin', 'email': 'alice@example.com',
           'id': 1234, 'avatar_url': 'https://avatars.example/a.png'}
GH_PRIVATE = {'login': 'bob', 'name': '', 'email': None, 'id': 42}
GL_USER = {'username': 'carol', 'name': 'Carol', 'commit_email': 'carol@commit.example',
           'email': 'carol@prive.example', 'public_email': 'carol@publique.example', 'id': 7}
GL_BARE = {'username': 'dave', 'name': None, 'id': 9}


def fake_request(payload):
    """Remplace oa.request : renvoie le profil sans aucun appel réseau."""
    def inner(url, *, form=None, body=None, token=None):
        if url.endswith('/user'):
            return dict(payload), {}
        raise AssertionError('URL inattendue : ' + url)
    return inner


class StoreTestCase(unittest.TestCase):
    """Isole le coffre dans un dossier temporaire pour chaque test."""

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        env = mock.patch.dict(os.environ, {'PS_GIT_ACCOUNTS_DIR': self.tmp.name,
                                           'PS_GIT_ACCOUNTS_PERSIST': '1'})
        env.start()
        self.addCleanup(env.stop)
        # account_store.store est un singleton créé à l'import : on le re-pointe.
        self.store = account_store.AccountStore()
        self.patch_store = mock.patch.object(oa.account_store, 'store', self.store)
        self.patch_store.start()
        self.addCleanup(self.patch_store.stop)


class ProfileTests(unittest.TestCase):
    def test_github_public_email_and_name(self):
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            info = oa.profile('github', 'ghp_token')
        self.assertEqual(info['login'], 'alice')
        self.assertEqual(info['name'], 'Alice Martin')
        self.assertEqual(info['email'], 'alice@example.com')
        self.assertEqual(info['emailSource'], 'compte')

    def test_github_private_email_falls_back_to_noreply(self):
        with mock.patch.object(oa, 'request', fake_request(GH_PRIVATE)):
            info = oa.profile('github', 'ghp_token')
        self.assertEqual(info['email'], '42+bob@users.noreply.github.com')
        self.assertEqual(info['emailSource'], 'noreply')
        # Sans nom publié, l'identifiant sert de nom d'auteur.
        self.assertEqual(info['name'], 'bob')

    def test_gitlab_prefers_commit_email(self):
        with mock.patch.object(oa, 'request', fake_request(GL_USER)):
            info = oa.profile('gitlab', 'glpat_token')
        self.assertEqual(info['email'], 'carol@commit.example')
        self.assertEqual(info['emailSource'], 'commit')

    def test_gitlab_without_any_email_falls_back_to_noreply(self):
        with mock.patch.object(oa, 'request', fake_request(GL_BARE)):
            info = oa.profile('gitlab', 'glpat_token')
        self.assertEqual(info['email'], 'dave@users.noreply.gitlab.com')
        self.assertEqual(info['emailSource'], 'noreply')
        self.assertEqual(info['name'], 'dave')

    def test_missing_login_is_refused(self):
        with mock.patch.object(oa, 'request', fake_request({'id': 1})):
            with self.assertRaises(ValueError):
                oa.profile('github', 'x')

    def test_github_noreply_needs_a_numeric_id(self):
        with mock.patch.object(oa, 'request', fake_request({'login': 'bob', 'email': None})):
            with self.assertRaises(ValueError):
                oa.profile('github', 'x')

    def test_unknown_provider_is_refused(self):
        with self.assertRaises(ValueError):
            oa.profile('bitbucket', 'x')

    def test_malformed_email_is_refused(self):
        with mock.patch.object(oa, 'request', fake_request({'login': 'a', 'name': 'A',
                                                           'email': 'pas-une-adresse', 'id': 1})):
            with self.assertRaises(ValueError):
                oa.profile('github', 'x')


class PersistenceTests(StoreTestCase):
    def connect(self, provider='github', payload=GH_USER, token='ghp_token_abcdefgh'):
        with mock.patch.object(oa, 'request', fake_request(payload)):
            m = oa.AccountManager()
            result = m.add_token(provider, token)
        return m, result['account']

    def test_account_survives_a_new_manager(self):
        m, public = self.connect()
        self.assertEqual(public['login'], 'alice')
        self.assertTrue(public['persisted'])
        again = oa.AccountManager()
        self.assertEqual([a['login'] for a in again.all()], ['alice'])
        self.assertEqual(again.identity(public['id'])['email'], 'alice@example.com')

    def test_identity_exposes_the_commit_address(self):
        m, public = self.connect(payload=GH_PRIVATE, token='ghp_bob_token')
        info = m.identity(public['id'])
        self.assertEqual(info['name'], 'bob')
        self.assertEqual(info['email'], '42+bob@users.noreply.github.com')
        self.assertEqual(info['emailSource'], 'noreply')
        self.assertEqual(info['provider'], 'github')

    def test_public_never_exposes_the_token(self):
        m, public = self.connect()
        for field in public:
            self.assertNotIn('token', field.lower())
        self.assertNotIn('ghp_token_abcdefgh', str(public))

    def test_reconnecting_the_same_account_does_not_duplicate(self):
        self.connect()
        self.connect()
        m = oa.AccountManager()
        self.assertEqual(len(m.all()), 1, m.all())

    def test_logout_removes_from_disk(self):
        m, public = self.connect()
        m.logout(public['id'])
        self.assertEqual(oa.AccountManager().all(), [])

    def test_purge_empties_the_store(self):
        self.connect()
        oa.account_store.store.purge()
        self.assertEqual(oa.AccountManager().all(), [])

    def test_disabled_persistence_keeps_accounts_in_memory_only(self):
        with mock.patch.dict(os.environ, {'PS_GIT_ACCOUNTS_PERSIST': '0'}):
            m, public = self.connect()
            self.assertFalse(public['persisted'])
            self.assertEqual(len(m.all()), 1)
            self.assertEqual(oa.AccountManager().all(), [])

    def test_expired_account_without_refresh_is_dropped(self):
        stored = {'x': {'id': 'x', 'provider': 'github', 'login': 'alice', 'name': 'A',
                        'email': 'a@b.co', 'token': 'ghp_expired_token',
                        'expiry': time.time() - 10, 'refresh': None}}
        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        self.assertEqual(m.all(), [])

    def test_expired_account_with_refresh_is_kept(self):
        stored = {'x': {'id': 'x', 'provider': 'github', 'login': 'alice', 'name': 'A',
                        'email': 'a@b.co', 'token': 'ghp_expired_token',
                        'expiry': time.time() - 10, 'refresh': 'rt_x', 'client_id': 'cid'}}
        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        self.assertEqual([a['login'] for a in m.all()], ['alice'])

    def test_invalid_stored_token_is_ignored(self):
        stored = {'x': {'id': 'x', 'provider': 'github', 'login': 'alice',
                        'token': 'court'}}
        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        self.assertEqual(m.all(), [])

    def test_unknown_provider_in_store_is_ignored(self):
        stored = {'x': {'id': 'x', 'provider': 'bitbucket', 'login': 'a',
                        'token': 'un_jeton_valide'}}
        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        self.assertEqual(m.all(), [])

    def test_refreshed_token_is_persisted(self):
        stored = {'x': {'id': 'x', 'provider': 'github', 'login': 'alice', 'name': 'A',
                        'email': 'a@b.co', 'emailSource': 'compte', 'token': 'ghp_old_token_x',
                        'expiry': time.time() - 10, 'refresh': 'rt_x', 'client_id': 'cid'}}

        def fake(url, *, form=None, body=None, token=None):
            if url.endswith('/login/oauth/access_token'):
                return {'access_token': 'ghp_new_token_y', 'refresh_token': 'rt_y',
                        'expires_in': 7200}, {}
            if url.endswith('/user'):
                return dict(GH_USER), {}
            raise AssertionError(url)

        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        with mock.patch.object(oa, 'request', fake):
            m._account('x')
        reloaded = oa.AccountManager()
        self.assertEqual(reloaded.accounts['x']['token'], 'ghp_new_token_y')
        self.assertEqual(reloaded.accounts['x']['refresh'], 'rt_y')

    def test_refresh_failure_drops_the_account_from_disk(self):
        stored = {'x': {'id': 'x', 'provider': 'github', 'login': 'alice', 'name': 'A',
                        'email': 'a@b.co', 'token': 'ghp_old_token_x',
                        'expiry': time.time() - 10, 'refresh': 'rt_x', 'client_id': 'cid'}}

        def deny(url, *, form=None, body=None, token=None):
            return {'error': 'invalid_grant'}, {}

        with mock.patch.object(account_store.AccountStore, 'load', return_value=stored):
            m = oa.AccountManager()
        with mock.patch.object(oa, 'request', deny):
            with self.assertRaises(ValueError):
                m._account('x')
        self.assertEqual(oa.AccountManager().all(), [])

    def test_two_providers_coexist(self):
        self.connect('github', GH_USER, 'ghp_token_abcdefgh')
        self.connect('gitlab', GL_USER, 'glpat_token_abcdef')
        m = oa.AccountManager()
        self.assertEqual(sorted(a['provider'] for a in m.all()), ['github', 'gitlab'])


class DispatchTests(StoreTestCase):
    def test_accounts_action_lists_without_secrets(self):
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            raw = oa.dispatch('{"action":"token","provider":"github","token":"ghp_token_abcdefgh"}')
        self.assertIn('"ok": true', raw)
        self.assertNotIn('ghp_token_abcdefgh', raw)
        listed = oa.dispatch('{"action":"accounts"}')
        self.assertIn('alice', listed)
        self.assertNotIn('ghp_token_abcdefgh', listed)

    def test_identity_action(self):
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            import json
            account = json.loads(oa.dispatch('{"action":"token","provider":"github","token":"ghp_token_abcdefgh"}'))['account']
        raw = oa.dispatch('{"action":"identity","id":"%s"}' % account['id'])
        self.assertIn('alice@example.com', raw)

    def test_persist_status_action(self):
        raw = oa.dispatch('{"action":"persist-status"}')
        self.assertIn('"enabled": true', raw)

    def test_persist_purge_forgets_accounts_and_removes_files(self):
        store = oa.account_store.store
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            oa.dispatch('{"action":"token","provider":"github","token":"ghp_token_abcdefgh"}')
        self.assertEqual(len(oa.manager.all()), 1)
        self.assertTrue(store.path.exists(), 'les comptes doivent être conservés')
        self.assertTrue(store.auto_path.exists(), 'la clé locale doit exister')
        raw = oa.dispatch('{"action":"persist-purge"}')
        self.assertIn('"ok": true', raw)
        self.assertIn('"accounts": []', raw)
        self.assertFalse(store.path.exists())
        self.assertFalse(store.auto_path.exists())
        self.assertIsNone(store.key, 'la clé en mémoire doit être oubliée')
        # Une connexion suivante repart d'une clé neuve et se conserve à nouveau.
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            oa.dispatch('{"action":"token","provider":"github","token":"ghp_token_abcdefgh"}')
        self.assertEqual(len(oa.manager.all()), 1)
        self.assertTrue(store.path.exists())
        self.assertTrue(store.auto_path.exists())

    def test_persist_purge_sur_un_store_vide_ne_casse_rien(self):
        raw = oa.dispatch('{"action":"persist-purge"}')
        self.assertIn('"ok": true', raw)
        self.assertIn('"accounts": []', raw)

    def test_unknown_action_still_refused(self):
        raw = oa.dispatch('{"action":"inconnue"}')
        self.assertIn('"ok": false', raw)

    def test_credentials_reject_a_foreign_host(self):
        with mock.patch.object(oa, 'request', fake_request(GH_USER)):
            import json
            account = json.loads(oa.dispatch('{"action":"token","provider":"github","token":"ghp_token_abcdefgh"}'))['account']
        with self.assertRaises(ValueError):
            oa.manager.credentials(account['id'], 'https://gitlab.com/alice/x.git')


if __name__ == '__main__':
    unittest.main()
