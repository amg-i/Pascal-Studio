import base64,os,tempfile,unittest,urllib.error,urllib.request
from pathlib import Path
from publication import Publisher
import test_stop_and_save as support

class PublisherTest(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.source=self.root/'Mon texte.tex';self.source.write_text('src');self.out=self.source.with_suffix('.pdf');self.cache=self.root/'cache';self.p=Publisher(self.cache)
 def tearDown(self):self.tmp.cleanup()
 def put(self,data=b'%PDF-1.4\nPremier',expected=None):return self.p.publish(self.source,data,expected)
 def test_new_update_restart_and_manual_change(self):
  r=self.put();self.assertEqual(r['status'],'saved');self.assertEqual(self.out.read_bytes(),b'%PDF-1.4\nPremier');self.assertEqual(self.put(b'%PDF-1.4\nDeuxieme')['status'],'saved');self.p=Publisher(self.cache);self.assertEqual(self.put(b'%PDF-1.4\nTroisieme')['status'],'saved');self.out.write_bytes(b'%PDF-1.4\nManuel');r=self.put();self.assertEqual(r['status'],'conflict');self.assertEqual(self.out.read_bytes(),b'%PDF-1.4\nManuel');self.assertEqual(self.put(expected='incorrect')['status'],'conflict');self.assertEqual(self.put(expected=r['existingHash'])['status'],'saved')
 def test_source_ownership(self):
  self.put();note=self.source.with_suffix('.psnote');note.write_text('note');r=self.p.publish(note,b'%PDF-1.4\nNote');self.assertEqual(r['status'],'conflict');self.assertEqual(self.out.read_bytes(),b'%PDF-1.4\nPremier');self.assertEqual(self.p.publish(note,b'%PDF-1.4\nNote',r['existingHash'])['status'],'saved');self.assertEqual(self.put()['status'],'conflict')
 def test_never_overwrite_symlink_or_invalid(self):
  victim=self.root/'victime.pdf';victim.write_bytes(b'%PDF-1.4\nVictime');self.out.symlink_to(victim)
  with self.assertRaisesRegex(ValueError,'lien symbolique'):self.put()
  self.assertEqual(victim.read_bytes(),b'%PDF-1.4\nVictime');self.out.unlink()
  with self.assertRaises(ValueError):self.put(b'not a PDF')
  self.source.unlink()
  with self.assertRaises(ValueError):self.put()
 def test_filesystem_without_hardlinks(self):
  from unittest.mock import patch
  import errno
  with patch('publication.os.link',side_effect=OSError(errno.EOPNOTSUPP,'pas de lien')):result=self.put()
  self.assertEqual(result['status'],'saved');self.assertEqual(self.out.read_bytes(),b'%PDF-1.4\nPremier')
 def test_conflict_after_destination_changes(self):
  self.out.write_bytes(b'%PDF-1.4\nExistant');r=self.put();self.out.write_bytes(b'%PDF-1.4\nChangee');self.assertEqual(self.put(expected=r['existingHash'])['status'],'conflict');self.assertEqual(self.out.read_bytes(),b'%PDF-1.4\nChangee')

class PublicationApiTest(support.ApiStopTests):
 def test_psnote_publish(self):
  status,r=support.request(self.base,'handwriting/create',{'path':'notes.psnote'});self.assertEqual(status,200,r)
  payload={'kind':'psnote','path':'notes.psnote','data':base64.b64encode(b'%PDF-1.4\nPDF').decode()};status,r=support.request(self.base,'pdf/publish',payload);self.assertEqual(status,200,r);self.assertEqual(r['status'],'saved');self.assertEqual((self.project/'notes.pdf').read_bytes(),b'%PDF-1.4\nPDF');self.assertEqual(r['openPath'],'notes.pdf')
  request=urllib.request.Request(self.base+'/api/pdf/publish',data=b'{}',headers={'Content-Type':'application/json','Origin':'https://malicious.example'})
  with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(request)
 def test_external_source(self):
  outside=self.dir/'externe.psnote';outside.write_text('{}');status,r=support.request(self.base,'external/open',{'path':str(outside)});key=r['path'];payload={'kind':'psnote','path':key,'data':base64.b64encode(b'%PDF-1.4\nPDF').decode()};status,r=support.request(self.base,'pdf/publish',payload);self.assertEqual(status,200,r);self.assertTrue((self.dir/'externe.pdf').exists());self.assertTrue(r['openPath'].startswith('@external:'))
 def test_latex_id_is_bound_to_source(self):
  main=self.project/'a.tex';other=self.project/'b.tex';text='\\documentclass{article}\n\\begin{document}Bonjour\\end{document}\n';main.write_text(text);other.write_text(text);status,r=support.request(self.base,'compile',{'path':'a.tex'});self.assertEqual(status,200,r);self.assertTrue(r['ok'],r.get('output'));ident=r['pdfId'];status,r=support.request(self.base,'pdf/publish',{'kind':'latex','path':'b.tex','id':ident});self.assertEqual(status,400,r);self.assertFalse((self.project/'b.pdf').exists());status,r=support.request(self.base,'pdf/publish',{'kind':'latex','path':'a.tex','id':ident});self.assertEqual(status,200,r);self.assertTrue((self.project/'a.pdf').read_bytes().startswith(b'%PDF-'))
if __name__=='__main__':unittest.main()
