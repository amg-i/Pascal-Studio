"""Python live analysis, real execution semantics and runtime problem locations."""
import json,os,socket,subprocess,sys,tempfile,time,unittest,urllib.error,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
import scripting

def req(base,path,payload=None):
 r=urllib.request.Request(base+'/api/'+path,data=json.dumps(payload).encode() if payload is not None else None,headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(r,timeout=10) as response:return response.status,json.load(response)
 except urllib.error.HTTPError as e:return e.code,json.load(e)

class PythonAnalysisTests(unittest.TestCase):
 def check(self,text):return scripting.analyze('python','/tmp/test.py','test.py',text)
 def test_undefined_unused_and_locations(self):
  text="import os\ntexte = '😀é'; print(inconnue)\n";r=self.check(text);self.assertTrue(r['ok']);self.assertEqual(r['state'],'ready')
  warning=next(x for x in r['diagnostics'] if x['code']=='UnusedImport');self.assertEqual(warning['severity'],'warning');self.assertEqual((warning['line'],warning['column'],warning['endColumn']),(1,8,10))
  error=next(x for x in r['diagnostics'] if x['code']=='UndefinedName');expected=len(text.splitlines()[1].split('inconnue')[0].encode('utf-16-le'))//2+1
  self.assertEqual((error['severity'],error['line'],error['column'],error['endColumn']),('error',2,expected,expected+len('inconnue')))
 def test_syntax_is_hard_error_even_return_outside_function(self):
  for text in ('if True\n    print(1)\n','return 5\n','break\n'):
   with self.subTest(text=text):r=self.check(text);self.assertFalse(r['ok']);self.assertEqual(r['diagnostics'][0]['severity'],'error')
 def test_unreachable_static_diagnostic_never_prevents_run(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'demo.py';p.write_text("if False:\n    print(1 / 0)\nprint('OK')\n")
   r=scripting.build('python',p,'demo.py');self.assertTrue(r['ok']);self.assertEqual(r['command'][0],sys.executable);self.assertTrue(any(x['code']=='ZeroDivisionLiteral' for x in r['diagnostics']))
 def test_no_false_string_interpolation_warning(self):
  r=self.check("print('%s' % 0)\n");self.assertTrue(r['ok']);self.assertFalse(any(x['code']=='ZeroDivisionLiteral' for x in r['diagnostics']))
 def test_analysis_never_executes_import_or_user_code(self):
  with tempfile.TemporaryDirectory() as d:
   sentinel=Path(d)/'DO_NOT_CREATE';r=self.check(f"open({str(sentinel)!r}, 'w').write('x')\nimport imaginaire\n")
   self.assertTrue(r['ok']);self.assertFalse(sentinel.exists())
 def test_builtin_exception_warning(self):
  r=self.check('if 1 is 1:\n    pass\n');self.assertTrue(any(x['severity']=='warning' for x in r['diagnostics']))

class PythonRuntimeTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();self.base=f'http://127.0.0.1:{port}'
  env={**os.environ,'PASCAL_WORKSPACE':str(self.root),'PASCAL_PORT':str(port),'XDG_CACHE_HOME':str(self.root/'cache')};self.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(150):
   try:req(self.base,'status');break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('API non démarrée')
 def tearDown(self):
  self.proc.terminate()
  try:self.proc.wait(timeout=6)
  except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait()
  self.temp.cleanup()
 def run_code(self,text):
  (self.root/'main.py').write_text(text);status,r=req(self.base,'run',{'path':'main.py'});self.assertEqual(status,200,r);self.assertTrue(r['ok'],r)
  for _ in range(150):
   _,p=req(self.base,'process')
   if not p['running'] and p['exitCode'] is not None:return p
   time.sleep(.05)
  self.fail('Processus trop long')
 def test_executes_prior_instructions_then_reports_runtime_line(self):
  p=self.run_code("print('DEBUT',flush=True)\nif False:\n    print(1 / 0)\nprint('SUITE',flush=True)\nvalue = 0\nprint(1 / value)\n")
  self.assertEqual(p['exitCode'],1);self.assertLess(p['output'].index('DEBUT'),p['output'].index('SUITE'));self.assertLess(p['output'].index('SUITE'),p['output'].index('Traceback'))
  error=next(d for d in p['diagnostics'] if d['code']=='PythonRuntime');self.assertEqual((error['file'],error['line'],error['severity']),('main.py',6,'error'));self.assertIn('ZeroDivisionError',error['message']);self.assertEqual(len(error['sourceHash']),64)
 def test_caught_exception_is_not_a_runtime_problem(self):
  p=self.run_code("try:\n    1 / 0\nexcept ZeroDivisionError:\n    print('interceptee')\n")
  self.assertEqual(p['exitCode'],0);self.assertFalse(any(d['code']=='PythonRuntime' for d in p['diagnostics']))
 def test_imported_project_file_location(self):
  (self.root/'helper.py').write_text("def f():\n    a = 0\n    return 3 / a\n")
  p=self.run_code('import helper\nhelper.f()\n');d=next(d for d in p['diagnostics'] if d['code']=='PythonRuntime');self.assertEqual((d['file'],d['line']),('helper.py',3))
 def test_runtime_warning(self):
  p=self.run_code("import warnings\nwarnings.warn('attention', RuntimeWarning)\nprint('suite')\n");self.assertEqual(p['exitCode'],0)
  d=next(d for d in p['diagnostics'] if d['code']=='PythonRuntimeWarning');self.assertEqual((d['file'],d['line'],d['severity']),('main.py',2,'warning'))
 def test_changed_source_does_not_receive_stale_runtime_marker(self):
  f=self.root/'main.py';f.write_text("import time\nprint('pret',flush=True)\ntime.sleep(.7)\nx=0\nprint(1/x)\n");status,r=req(self.base,'run',{'path':'main.py'});self.assertEqual(status,200,r)
  for _ in range(100):
   _,p=req(self.base,'process')
   if 'pret' in p['output']:break
   time.sleep(.02)
  else:self.fail('Programme non démarré')
  f.write_text("print('fichier changé')\n")
  for _ in range(100):
   _,p=req(self.base,'process')
   if not p['running']:break
   time.sleep(.03)
  self.assertIn('ZeroDivisionError',p['output']);self.assertFalse(p['diagnostics'])
if __name__=='__main__':unittest.main()
