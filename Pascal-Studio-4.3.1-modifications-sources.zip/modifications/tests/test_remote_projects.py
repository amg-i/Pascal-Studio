import os,tempfile,unittest
from pathlib import Path
from remote_projects import Project

class LocalTransport:
 def __init__(self,root):self.root=root;self.offline=False
 def scan(self,include_git=False):
  if self.offline:raise OSError('réseau indisponible')
  fs={};ds=set()
  for p in self.root.rglob('*'):
   r=p.relative_to(self.root).as_posix()
   if not include_git and '.git' in r.split('/'):continue
   if p.is_file():fs[r]=[p.stat().st_size,int(p.stat().st_mtime),0,None]
   elif p.is_dir():ds.add(r)
  return fs,ds
 def read(self,path):
  if self.offline:raise OSError('réseau indisponible')
  return (self.root/path).read_bytes()
 def mkdir(self,path):(self.root/path).mkdir(parents=True,exist_ok=True)
 def write_new(self,path,data):
  p=self.root/path;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(data)
 def publish(self,path,data,expected):
  from remote_projects import digest
  p=self.root/path
  if expected is None:return self.write_new(path,data)
  if digest(p.read_bytes())!=expected:raise ValueError('modifié')
  p.write_bytes(data)

class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.tmpdir=Path(self.tmp.name);self.s=self.tmpdir/'serveur';self.s.mkdir();(self.s/'folder').mkdir();(self.s/'folder/a.tex').write_text('base');(self.s/'n.psnote').write_bytes(b'\x00\xfftest')
  self.t=LocalTransport(self.s);self.p=Project(self.t,self.tmpdir/'mirror','folder','ftp://test');self.p.initialize()
 def tearDown(self):self.p.release();self.tmp.cleanup()
 def test_initial_binary_nested_and_upload(self):
  self.assertEqual((self.p.workspace/'n.psnote').read_bytes(),b'\x00\xfftest')
  (self.p.workspace/'folder/a.tex').write_text('edit');(self.p.workspace/'new').write_bytes(b'new');self.p.sync()
  self.assertEqual((self.s/'folder/a.tex').read_text(),'edit');self.assertEqual((self.s/'new').read_bytes(),b'new')
 def test_conflict_both_and_choose_local_with_backup(self):
  l=self.p.workspace/'folder/a.tex';r=self.s/'folder/a.tex';l.write_text('local');r.write_text('server');self.p.sync();self.assertEqual(len(self.p.conflicts),1);self.assertEqual(l.read_text(),'local');self.assertEqual(r.read_text(),'server')
  result=self.p.resolve_conflict('folder/a.tex','local',[]);self.assertEqual(r.read_text(),'local');self.assertEqual((self.s/result['backup']).read_text(),'server');self.assertEqual((self.p.workspace/result['backup']).read_text(),'server');self.p.sync();self.assertFalse(self.p.conflicts)
 def test_choose_server_refuses_open_then_backs_up(self):
  l=self.p.workspace/'folder/a.tex';r=self.s/'folder/a.tex';l.write_text('local');r.write_text('server');self.p.sync()
  with self.assertRaises(ValueError):self.p.resolve_conflict('folder/a.tex','server',['folder/a.tex'])
  x=self.p.resolve_conflict('folder/a.tex','server',[]);self.assertEqual(l.read_text(),'server');self.assertEqual((self.s/x['backup']).read_text(),'local');self.assertEqual((self.p.workspace/x['backup']).read_text(),'local')
 def test_server_change_while_open_is_not_downloaded(self):
  self.p.mark_open('folder/a.tex');(self.s/'folder/a.tex').write_text('on server');self.p.sync();self.assertEqual((self.p.workspace/'folder/a.tex').read_text(),'base');self.assertEqual(len(self.p.conflicts),1)
  self.p.update_open([]);self.p.sync();self.assertEqual((self.p.workspace/'folder/a.tex').read_text(),'on server')
 def test_deletions_not_propagated(self):
  (self.p.workspace/'folder/a.tex').unlink();self.p.sync();self.assertTrue((self.s/'folder/a.tex').exists());self.assertTrue(self.p.conflicts)
 def test_offline_and_restart_preserve_local(self):
  path=self.p.workspace/'folder/a.tex';path.write_text('offline');self.t.offline=True
  with self.assertRaises(OSError):self.p.sync()
  self.p.release();self.t.offline=False;self.p=Project(self.t,self.tmpdir/'mirror','folder','ftp://test');self.p.initialize();self.assertEqual(path.read_text(),'offline');self.p.sync();self.assertEqual((self.s/'folder/a.tex').read_text(),'offline')
 def test_git_is_copied_initially_but_never_synchronized(self):
  self.p.release();(self.s/'.git').mkdir();(self.s/'.git/config').write_text('initial');self.p=Project(self.t,self.tmpdir/'another','folder','ftp://test');self.p.initialize()
  self.assertEqual((self.p.workspace/'.git/config').read_text(),'initial')
  (self.p.workspace/'.git/config').write_text('local git');(self.s/'.git/config').write_text('serveur git');self.p.sync()
  self.assertEqual((self.s/'.git/config').read_text(),'serveur git');self.assertEqual((self.p.workspace/'.git/config').read_text(),'local git');self.assertFalse(self.p.conflicts)
 def test_git_worktree_file_is_local_only(self):
  (self.p.workspace/'.git').write_text('gitdir: /some/path')
  (self.s/'.git').write_text('gitdir: /server/path')
  self.p.sync();self.assertEqual((self.s/'.git').read_text(),'gitdir: /server/path');self.assertFalse(self.p.conflicts)
 def test_symlink_blocks(self):
  (self.p.workspace/'bad').symlink_to('/etc/passwd')
  with self.assertRaises(ValueError):self.p.sync()
if __name__=='__main__':unittest.main()
