import os,tempfile,unittest
from pathlib import Path
from remote_vault import Vault,OpenSSL,AADS

class VaultTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.old=os.environ.get('XDG_CONFIG_HOME');os.environ['XDG_CONFIG_HOME']=self.tmp.name;self.addCleanup(self.restore)
 def restore(self):
  if self.old is None:os.environ.pop('XDG_CONFIG_HOME',None)
  else:os.environ['XDG_CONFIG_HOME']=self.old
  self.tmp.cleanup()
 def test_encryption_restart_no_plaintext_and_permissions(self):
  v=Vault();self.assertEqual(v.status(),{'exists':False,'unlocked':False,'mode':'none'});v.unlock('mot de passe maître long');v.put('ftp://alice@server/','alice','','secretS3rv!')
  raw=v.path.read_bytes();self.assertNotIn(b'secretS3rv!',raw);self.assertNotIn(b'alice',raw);self.assertEqual(v.path.stat().st_mode&0o777,0o600)
  other=Vault()
  with self.assertRaises(ValueError):other.unlock('wrong password long')
  self.assertFalse(other.status()['unlocked']);other.last_failure=0;other.unlock('mot de passe maître long');self.assertEqual(other.get('ftp://alice@server/','alice',''),'secretS3rv!')
  other.remove_uri('ftp://alice@server/');self.assertEqual(other.get('ftp://alice@server/','alice',''),'')
 def test_new_auto_vault_and_restart(self):
  v=Vault();v.enable_auto();v.put('ftp://h/','alice','','secret')
  self.assertEqual(v.auto_path.stat().st_mode&0o777,0o600);self.assertNotIn(b'secret',v.path.read_bytes());self.assertNotIn(b'secret',v.auto_path.read_bytes())
  restarted=Vault();self.assertEqual(restarted.status()['mode'],'auto');self.assertTrue(restarted.status()['unlocked']);self.assertEqual(restarted.get('ftp://h/','alice',''),'secret')
 def test_migrate_master_vault_without_storing_master_or_reencrypting(self):
  old=Vault();master='mon mot de passe maître personnel';old.unlock(master);old.put('ftp://a/','u','','secret');original=old.path.read_bytes()
  migrated=Vault();self.assertEqual(migrated.status()['mode'],'master')
  with self.assertRaises(ValueError):migrated.enable_auto('mot de passe incorrect')
  migrated.last_failure=0;migrated.enable_auto(master);self.assertEqual(migrated.path.read_bytes(),original);self.assertNotIn(master.encode(),migrated.auto_path.read_bytes())
  self.assertEqual(Vault().status()['mode'],'auto');self.assertEqual(Vault().status()['unlocked'],True);fresh=Vault();fresh.status();self.assertEqual(fresh.get('ftp://a/','u',''),'secret')
 def test_auto_key_permissions_and_wrong_key_are_rejected(self):
  v=Vault();v.enable_auto();v.put('ftp://a/','u','','secret');v.auto_path.chmod(0o644)
  with self.assertRaises(ValueError):Vault().status()
  v.auto_path.chmod(0o600);old=v.path.read_bytes();v.auto_path.write_text('{"version":1,"salt":"AAAAAAAAAAAAAAAAAAAAAA==","key":"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="}')
  with self.assertRaises(ValueError):Vault().status()
  self.assertEqual(v.path.read_bytes(),old)
 def test_tampering_is_rejected(self):
  v=Vault();v.unlock('0123456789abcde');v.put('ftp://h/','x','','private')
  import json,base64
  d=json.loads(v.path.read_text());b=bytearray(base64.b64decode(d['ciphertext']));b[0]^=1;d['ciphertext']=base64.b64encode(b).decode();v.path.write_text(json.dumps(d))
  with self.assertRaises(ValueError):Vault().unlock('0123456789abcde')
 def test_two_instances_preserve_each_others_secrets(self):
  a=Vault();a.unlock('0123456789abcde');b=Vault();b.unlock('0123456789abcde');a.put('ftp://one/','one','','111');b.put('ftp://two/','two','','222')
  self.assertEqual(a.get('ftp://one/','one',''),'111');self.assertEqual(a.get('ftp://two/','two',''),'222')
  a.remove_uri('ftp://one/');self.assertEqual(b.get('ftp://two/','two',''),'222');self.assertEqual(b.get('ftp://one/','one',''),'')
 def test_short_master_and_locked_access(self):
  v=Vault()
  with self.assertRaises(ValueError):v.unlock('short')
  self.assertFalse(v.path.exists())
  with self.assertRaises(ValueError):v.get('ftp://h/','u','')
  with self.assertRaises(ValueError):v.put('ftp://h/','u','','pass')
 def test_gcm_independent_known_vector(self):
  # Precomputed with cryptography AESGCM, with this application's fixed AAD.
  key=bytes(range(32));iv=bytes(range(12));data=b'Pascal Studio: chiffrement du coffre'
  cipher,tag=OpenSSL().crypt(key,iv,data)
  self.assertEqual((cipher+tag).hex(),'1763a578a489e248f934f3e2ded3580eebbfe152821e32195613c5e1684963dd6776dc992a38bd1877e6fe2819439b79ba8a1cf8')
  self.assertEqual(OpenSSL().crypt(key,iv,cipher,tag),data)
  with self.assertRaises(ValueError):OpenSSL().crypt(key,iv,cipher,bytes([tag[0]^1])+tag[1:])
if __name__=='__main__':unittest.main()
