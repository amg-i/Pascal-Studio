# -*- coding: utf-8 -*-
"""Les dix langages ésotériques vus par les routes HTTP du serveur.

Le registre, les moteurs et le multiplexeur de débogage ont chacun leurs tests.
Ce qui manquait, c'était la couture : server.py résout un fichier avec
polyglot.kind(), qui était un SECOND tableau d'extensions, incomplet. Résultat
mesuré avant correction, pour les dix langages :

    Piet        refusé par « if capacite['visuel']: raise »
    les 9 autres détournés vers compile_file(path, debug=True)

et /api/analyze passait None à l'analyseur, donc aucune détection d'erreur en
direct sur un .bf ouvert dans l'éditeur — alors que debogueur_universel.
capacites() annonçait le pas à pas, les variables et la pile pour les dix.

Ces tests passent par un vrai serveur, parce que c'est la route qui était fausse,
pas les fonctions qu'elle appelle.
"""

import base64
import http.client
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import unittest
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

RACINE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RACINE))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from test_inspecteur_visuel import ecrire_png

import debug_mux
import langages
import langages_esoteriques
import polyglot


def octets_png(data_uri):
    return base64.b64decode(data_uri.split(',', 1)[1])


def requete(base, chemin, payload=None):
    demande = urllib.request.Request(
        base + '/api/' + chemin,
        data=json.dumps(payload).encode() if payload is not None else None,
        headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(demande, timeout=30) as reponse:
            return reponse.status, json.load(reponse)
    except urllib.error.HTTPError as erreur:
        return erreur.code, json.load(erreur)


class TestResolutionDesExtensions(unittest.TestCase):
    """polyglot.kind() doit répondre comme le registre, pas à côté."""

    def test_les_dix_extensions_sont_reconnues(self):
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            for extension in langages.extensions(identifiant):
                with self.subTest(extension=extension):
                    self.assertEqual(polyglot.kind('programme' + extension),
                                     identifiant)

    def test_les_langages_existants_ne_bougent_pas(self):
        attendus = {'a.py': 'python', 'a.pas': 'pascal', 'a.tex': 'latex',
                    'a.html': 'html', 'a.c': 'c', 'a.cpp': 'cpp',
                    'a.rs': 'rust', 'a.go': 'go', 'a.rb': 'ruby',
                    'a.php': 'php', 'a.css': 'css', 'a.cs': 'cs',
                    'a.csproj': 'csproj', 'Makefile': 'make',
                    'CMakeLists.txt': 'cmake', 'a.js': 'javascript'}
        for nom, identifiant in attendus.items():
            with self.subTest(fichier=nom):
                self.assertEqual(polyglot.kind(nom), identifiant)

    def test_ce_qui_n_est_pas_du_code_reste_inconnu(self):
        # Une photo du projet n'a pas à devenir un programme : seules les
        # extensions que le registre confie au débogueur ésotérique sont prises.
        for nom in ('photo.jpg', 'notes.txt', 'archive.zip', 'donnees.csv'):
            with self.subTest(fichier=nom):
                self.assertIsNone(polyglot.kind(nom))

    def test_le_predicat_public_du_multiplexeur(self):
        # La route HTTP et le routage interne doivent répondre la même chose,
        # sinon l'un accepte ce que l'autre refuse.
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                self.assertTrue(debug_mux.esoterique(identifiant))
                self.assertTrue(debug_mux.esoterique(langages.libelle(identifiant)))
        for identifiant in ('python', 'pascal', 'html', 'latex', 'markdown'):
            with self.subTest(langage=identifiant):
                self.assertFalse(debug_mux.esoterique(identifiant))

    def test_le_predicat_survit_a_l_absence_du_module(self):
        # Un module ésotérique absent ne doit pas priver les 29 autres langages
        # de débogage : le prédicat rend faux au lieu de lever.
        import builtins
        importeur = builtins.__import__

        def refuser(nom, *args, **kwargs):
            if nom == 'langages_esoteriques':
                raise ImportError('module absent')
            return importeur(nom, *args, **kwargs)

        builtins.__import__ = refuser
        self.addCleanup(setattr, builtins, '__import__', importeur)
        sys.modules.pop('langages_esoteriques', None)
        self.assertFalse(debug_mux.esoterique('brainfuck'))


class _ServeurEsoterique(unittest.TestCase):
    """Un vrai serveur, un vrai projet, les dix programmes d'aperçu.

    Classe de base sans test : elle porte le socle commun au parcours HTTP des
    dix langages et à celui de l'aperçu Piet, pour qu'un seul serveur démarre.
    """

    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(prefix='ps-routes-eso-')
        dossier = Path(cls.tmp.name)
        cls.projet = dossier / 'project'
        cls.projet.mkdir()
        socle = socket.socket()
        socle.bind(('127.0.0.1', 0))
        port = socle.getsockname()[1]
        socle.close()
        cls.base = 'http://127.0.0.1:%d' % port
        environnement = {**os.environ,
                         'PASCAL_WORKSPACE': str(cls.projet),
                         'PASCAL_PORT': str(port),
                         'PASCAL_HOST': '127.0.0.1',
                         'XDG_CACHE_HOME': str(dossier / 'cache')}
        cls.proc = subprocess.Popen(
            [sys.executable, str(RACINE / 'server.py')], env=environnement,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(200):
            try:
                requete(cls.base, 'status')
                break
            except OSError:
                time.sleep(0.05)
        else:
            cls.proc.kill()
            raise RuntimeError('Le serveur ne démarre pas.')
        # Les dix programmes d'aperçu, écrits sous leur extension réelle.
        cls.clefs = {}
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            code = langages_esoteriques.apercu_programme(identifiant)
            extension = langages.extensions(identifiant)[0]
            cle = 'apercu' + extension
            chemin = cls.projet / cle
            if identifiant == 'piet':
                # Le programme Piet EST un PNG binaire : l'écrire en texte le
                # détruirait, et c'est précisément ce que la route doit savoir.
                chemin.write_bytes(octets_png(code))
            else:
                chemin.write_text(code, encoding='utf8')
            cls.clefs[identifiant] = cle
        (cls.projet / 'script.py').write_text('x = 1\nprint(x)\n', encoding='utf8')
        (cls.projet / 'page.html').write_text(
            '<!doctype html><html><body><p>bonjour</p></body></html>\n',
            encoding='utf8')

    @classmethod
    def tearDownClass(cls):
        cls.proc.terminate()
        try:
            cls.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            cls.proc.kill()
            cls.proc.wait()
        cls.tmp.cleanup()

    def instantane(self):
        return requete(self.base, 'debug')[1]


class TestServeurEsoterique(_ServeurEsoterique):
    """Le parcours complet, en HTTP, pour les dix langages."""

    def test_les_dix_se_deboguent_sans_point_d_arret(self):
        # Un programme Brainfuck ou Piet tient souvent sur une seule ligne : y
        # exiger un point d'arrêt interdirait justement le pas à pas là où il est
        # le plus utile. La session s'ouvre avant la première instruction.
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                cle = self.clefs[identifiant]
                statut, resultat = requete(
                    self.base, 'debug/start', {'path': cle})
                self.assertEqual(statut, 200, resultat)
                self.assertEqual(resultat['mode'], 'esoterique')
                depart = self.instantane()
                self.assertEqual(depart['state'], 'paused', depart['message'])
                self.assertTrue(depart['active'])
                requete(self.base, 'debug/action', {'action': 'continue'})
                fin = self.instantane()
                self.assertEqual(fin['state'], 'exited', fin['message'])
                # La sortie du pas à pas doit être celle de l'exécution directe :
                # c'est l'invariant qui prouve que la session pilote le vrai
                # moteur, et il se tient tout seul quand un aperçu évolue.
                self.assertEqual(
                    fin['output'],
                    langages_esoteriques.executer(
                        langages_esoteriques.apercu_programme(identifiant),
                        identifiant)['sortie'])
                requete(self.base, 'debug/stop', {})
                self.assertEqual(self.instantane()['state'], 'idle')

    def test_le_pas_a_pas_de_piet_suit_les_blocs(self):
        statut, resultat = requete(self.base, 'debug/start',
                                   {'path': self.clefs['piet']})
        self.assertEqual(statut, 200, resultat)
        try:
            avant = self.instantane()['visuel']
            self.assertIsNotNone(avant, 'l’inspecteur n’a rien à surligner')
            self.assertEqual(avant['index'], 0)
            self.assertEqual(avant['rectangle'], [0, 0, 65, 1])
            requete(self.base, 'debug/action', {'action': 'step'})
            apres = self.instantane()['visuel']
            self.assertEqual(apres['index'], 1)
            self.assertEqual(apres['commande'], 'push')
            self.assertNotEqual(apres['rectangle'], avant['rectangle'])
        finally:
            requete(self.base, 'debug/stop', {})

    def test_l_inspecteur_lit_le_png_en_octets(self):
        statut, resultat = requete(self.base, 'inspecteur',
                                   {'path': self.clefs['piet']})
        self.assertEqual(statut, 200, resultat)
        self.assertEqual(resultat['langage'], 'piet')
        self.assertEqual(resultat['geometrie']['blocs'], 3)
        self.assertEqual(len(resultat['codels']), 3)
        self.assertEqual(resultat['codels'][0]['rvb'], '#FF0000')
        self.assertEqual(resultat['codels'][0]['rectangle'], [0, 0, 65, 1])
        self.assertEqual(resultat['diagnostics'], [])

    def test_l_analyse_en_direct_voit_les_fichiers_esoteriques(self):
        cas = (('apercu.bf', '++++++++[>+++++++++<-]>.', 0),
               ('apercu.bf', '+++[>+', 1),
               ('apercu.fra', 'n = 2\n3/2 5/7', 2))
        for cle, contenu, attendues in cas:
            with self.subTest(cle=cle, contenu=contenu):
                statut, resultat = requete(
                    self.base, 'analyze',
                    {'path': cle, 'buffers': [{'path': cle, 'content': contenu}]})
                self.assertEqual(statut, 200, resultat)
                self.assertEqual(resultat['state'], 'ready')
                self.assertEqual(len(resultat['diagnostics']), attendues,
                                 resultat['diagnostics'])

    def test_l_analyse_d_un_png_relit_le_disque(self):
        # Le tampon de l'éditeur est du texte : pour un PNG il est déjà détruit
        # par la lecture en 'replace'. L'analyse doit repartir des octets du
        # fichier, sinon toute image du projet signale une signature absente.
        statut, resultat = requete(
            self.base, 'analyze',
            {'path': self.clefs['piet'],
             'buffers': [{'path': self.clefs['piet'], 'content': '\ufffd\ufffdPNG\r\n'}]})
        self.assertEqual(statut, 200, resultat)
        self.assertEqual(resultat['diagnostics'], [])

    def test_un_langage_ordinaire_exige_toujours_un_point_d_arret(self):
        statut, resultat = requete(self.base, 'debug/start',
                                   {'path': 'script.py'})
        self.assertEqual(statut, 400)
        self.assertIn('point d’arrêt', resultat['error'])

    def test_un_langage_de_rendu_reste_reserve_a_l_inspecteur(self):
        # HTML n'a pas de moteur à pas : le refus doit rester, et son message
        # orienter vers l'inspecteur. Piet, lui, a les deux.
        statut, resultat = requete(
            self.base, 'debug/start',
            {'path': 'page.html',
             'breakpoints': [{'path': 'page.html', 'line': 1}]})
        self.assertEqual(statut, 400)
        self.assertIn('inspecteur visuel', resultat['error'])

    def test_des_points_d_arret_mal_formes_sont_refuses(self):
        statut, resultat = requete(self.base, 'debug/start',
                                   {'path': 'apercu.bf', 'breakpoints': 'x'})
        self.assertEqual(statut, 400)
        self.assertIn('invalides', resultat['error'])

    def test_l_index_d_aide_obtient_les_fonctionnalites_reelles(self):
        # /api/aide/capacites alimente les facettes de l'index de l'aide : c'est
        # ce qui permet de chercher « quels langages puis-je déboguer » sans
        # qu'une liste soit recopiée à la main dans l'aide.
        statut, resultat = requete(self.base, 'aide/capacites', {})
        self.assertEqual(statut, 200, resultat)
        self.assertEqual(resultat['total'], len(langages.tous()))
        facettes = {f['id'] for f in resultat['fonctionnalites']}
        self.assertIn('debogage', facettes)
        self.assertIn('apercu', facettes)
        par_langage = {f['langage']: f for f in resultat['langages']}
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                fiche = par_langage[identifiant]
                self.assertEqual(fiche['categorie'], 'esoterique')
                self.assertIn('debogage', fiche['facettes'])
        self.assertEqual(par_langage['piet']['categorie'], 'esoterique')
        self.assertIn('apercu', par_langage['piet']['facettes'])
        self.assertNotIn('apercu', par_langage['brainfuck']['facettes'])

    def test_l_index_peut_demander_une_seule_fonctionnalite(self):
        statut, resultat = requete(self.base, 'aide/capacites',
                                   {'fonctionnalite': 'debogage'})
        self.assertEqual(statut, 200, resultat)
        self.assertIn('Brainfuck', resultat['selection'])
        self.assertIn('Piet', resultat['selection'])
        self.assertNotIn('JSON', resultat['selection'])
        statut, resultat = requete(self.base, 'aide/capacites',
                                   {'fonctionnalite': 'inexistant'})
        self.assertEqual(statut, 200, resultat)
        self.assertEqual(resultat['selection'], [])

    def test_les_capacites_couvrent_les_trente_neuf_langages(self):
        statut, resultat = requete(self.base, 'debug/capacites', {})
        self.assertEqual(statut, 200, resultat)
        # La route rend {'langages': {id: capacités}, 'demande': capacités} :
        # c'est ce que lit le panneau de débogage pour griser ses boutons.
        par_langage = resultat['langages']
        self.assertEqual(sorted(par_langage), sorted(langages.tous()))
        for identifiant in langages_esoteriques.ORDRE_ESOTERIQUES:
            with self.subTest(langage=identifiant):
                annonce = par_langage[identifiant]
                self.assertTrue(annonce['disponible'])
                self.assertTrue(annonce['pas_a_pas'])
                self.assertTrue(annonce['variables'])
                self.assertTrue(annonce['pile'])


class TestApercuPiet(_ServeurEsoterique):
    """L'aperçu d'un programme Piet, du bouton jusqu'au bloc surligné.

    Le programme Piet est un PNG. Trois maillons doivent s'emboîter pour que
    l'inspecteur visuel existe vraiment : web_preview doit accepter le .png,
    servir une PAGE qui porte la surcouche au lieu de l'image nue, et server.py
    doit publier dans cette page le bloc que la session de pas à pas exécute.
    Ces tests passent par le vrai serveur et le vrai serveur d'aperçu.
    """

    def inspecteur_json(self, apercu):
        """Le JSON que la surcouche télécharge, avec le cookie d'aperçu."""
        parts = urllib.parse.urlsplit(apercu['url'])
        entetes = {'Host': '127.0.0.1:%d' % apercu['port']}
        connexion = http.client.HTTPConnection('127.0.0.1', apercu['port'],
                                               timeout=30)
        self.addCleanup(connexion.close)
        connexion.request('GET', parts.path, headers=entetes)
        reponse = connexion.getresponse()
        reponse.read()
        self.assertEqual(reponse.status, 302, 'l\'URL d\'aperçu doit rediriger')
        cookie = reponse.getheader('Set-Cookie').split(';')[0]
        connexion.request('GET', '/__ps_inspecteur_data',
                          headers=dict(entetes, Cookie=cookie))
        reponse = connexion.getresponse()
        self.assertEqual(reponse.status, 200)
        return json.loads(reponse.read().decode('utf8')), cookie

    def page(self, apercu, cookie, chemin):
        entetes = {'Host': '127.0.0.1:%d' % apercu['port'], 'Cookie': cookie}
        connexion = http.client.HTTPConnection('127.0.0.1', apercu['port'],
                                               timeout=30)
        self.addCleanup(connexion.close)
        connexion.request('GET', chemin, headers=entetes)
        reponse = connexion.getresponse()
        return reponse.status, reponse.getheader('Content-Type'), reponse.read()

    def test_l_apercu_publie_le_bloc_actif_de_la_session(self):
        statut, resultat = requete(self.base, 'debug/start',
                                   {'path': self.clefs['piet']})
        self.assertEqual(statut, 200, resultat)
        try:
            statut, apercu = requete(self.base, 'web/start',
                                     {'path': self.clefs['piet']})
            self.assertEqual(statut, 200, apercu)
            self.assertTrue(apercu['url'].endswith('__ps_piet_demo'),
                            'un programme Piet doit passer par sa page : '
                            + apercu['url'])
            donnees, cookie = self.inspecteur_json(apercu)
            self.assertEqual(donnees['langage'], 'piet')
            self.assertEqual(donnees['geometrie']['blocs'], 3)
            self.assertEqual(donnees['geometrie']['actif']['index'], 0,
                             'aucun bloc actif publié alors que la session est '
                             'en pause sur le premier')
            requete(self.base, 'debug/action', {'action': 'step'})
            donnees, _ = self.inspecteur_json(apercu)
            actif = donnees['geometrie']['actif']
            self.assertEqual(actif['index'], 1)
            self.assertEqual(actif['commande'], 'push')
            # La page elle-même doit porter l'image et la surcouche.
            statut, type_mime, corps = self.page(apercu, cookie,
                                                 '/__ps_piet_demo')
            self.assertEqual(statut, 200)
            self.assertIn('text/html', type_mime)
            self.assertIn(b'id="__ps_piet_image"', corps)
            self.assertIn(b'__ps_inspecteur_js', corps)
            # Et l'image du programme reste servie à sa propre adresse.
            statut, type_mime, corps = self.page(apercu, cookie,
                                                 '/' + self.clefs['piet'])
            self.assertEqual(statut, 200)
            self.assertEqual(type_mime, 'image/png')
            self.assertEqual(len(corps),
                             (self.projet / self.clefs['piet']).stat().st_size)
        finally:
            requete(self.base, 'debug/stop', {})
            requete(self.base, 'web/stop', {})

    def test_apres_l_arret_du_debogueur_plus_aucun_bloc_actif(self):
        statut, apercu = requete(self.base, 'web/start',
                                 {'path': self.clefs['piet']})
        self.assertEqual(statut, 200, apercu)
        try:
            donnees, _ = self.inspecteur_json(apercu)
            self.assertNotIn('actif', donnees['geometrie'],
                             'sans session, la surcouche ne doit rien surligner')
            self.assertEqual(len(donnees['codels']), 3,
                             'les blocs doivent rester visibles hors session')
        finally:
            requete(self.base, 'web/stop', {})

    def test_l_apercu_refuse_une_photo(self):
        (self.projet / 'photo.png').write_bytes(ecrire_png(
            [[(1, 2, 3), (255, 0, 0), (7, 8, 9)],
             [(11, 12, 13), (14, 15, 16), (17, 18, 19)]]))
        try:
            statut, resultat = requete(self.base, 'web/start',
                                       {'path': 'photo.png'})
            self.assertEqual(statut, 400, resultat)
            self.assertIn('Piet', resultat['error'])
        finally:
            (self.projet / 'photo.png').unlink(missing_ok=True)

    def test_l_apercu_des_autres_langages_ne_bouge_pas(self):
        statut, apercu = requete(self.base, 'web/start', {'path': 'page.html'})
        self.assertEqual(statut, 200, apercu)
        try:
            self.assertTrue(apercu['url'].endswith('/page.html'), apercu['url'])
            donnees, cookie = self.inspecteur_json(apercu)
            self.assertEqual(donnees['langage'], 'html')
            self.assertNotIn('actif', donnees.get('geometrie', {}))
            statut, type_mime, corps = self.page(apercu, cookie, '/page.html')
            self.assertEqual(statut, 200)
            self.assertIn(b'bonjour', corps)
            self.assertIn(b'__ps_inspecteur_js', corps,
                          'la surcouche doit rester injectée dans le HTML')
        finally:
            requete(self.base, 'web/stop', {})


if __name__ == '__main__':
    unittest.main(verbosity=2)
