"""Real nonzero exits and traceback location; captured failures remain normal."""
import os,json,shutil,socket,subprocess,sys,tempfile,time,unittest,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class RuntimeTest(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();self.base=f'http://127.0.0.1:{port}/api/'
  env={**os.environ,'PASCAL_WORKSPACE':str(self.root),'PASCAL_PORT':str(port),'XDG_CACHE_HOME':str(self.root/'cache')};self.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(100):
   try:self.req('status');break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('API non démarrée')
 def tearDown(self):self.proc.terminate();self.proc.wait(timeout=6);self.temp.cleanup()
 def req(self,path,data=None):
  r=urllib.request.Request(self.base+path,data=json.dumps(data).encode() if data is not None else None,headers={'content-type':'application/json'})
  with urllib.request.urlopen(r,timeout=180) as response:return json.load(response)
 def test_uncaught_panics_and_exceptions(self):
  tests=[('rustc','main.rs','fn main(){\n let v = vec![1];\n println!("AVANT");\n println!("{}",v[3]);\n}\n',4,'RuntimeRust'),('go','main.go','package main\nimport "fmt"\nfunc main(){\n x:=0\n fmt.Println("AVANT")\n fmt.Println(1/x)\n}\n',6,'RuntimeGo'),('ruby','main.rb','n = 0\nputs "AVANT"\nputs 1 / n\n',3,'RuntimeRuby')]
  for exe,name,source,line,code in tests:
   if not shutil.which(exe):continue
   with self.subTest(lang=exe):
    (self.root/name).write_text(source);r=self.req('run',{'path':name});self.assertTrue(r['ok'],r)
    for _ in range(300):
     p=self.req('process')
     if not p['running'] and p['exitCode'] is not None:break
     time.sleep(.05)
    self.assertNotEqual(p['exitCode'],0,p);self.assertIn('AVANT',p['output']);d=next(x for x in p['diagnostics'] if x['code']==code);self.assertEqual((d['file'],d['line']),(name,line));self.assertEqual(len(d['sourceHash']),64)
 def test_ruby_caught_error_not_reported(self):
  if not shutil.which('ruby'):self.skipTest('ruby absent')
  (self.root/'main.rb').write_text('begin\n  raise "oops"\nrescue\n  puts "récupéré"\nend\n');self.assertTrue(self.req('run',{'path':'main.rb'})['ok'])
  for _ in range(100):
   p=self.req('process')
   if not p['running']:break
   time.sleep(.05)
  self.assertEqual(p['exitCode'],0);self.assertEqual(p['diagnostics'],[])
if __name__=='__main__':unittest.main()
