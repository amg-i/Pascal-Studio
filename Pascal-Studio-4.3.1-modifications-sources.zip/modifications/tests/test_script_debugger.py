import sys,time,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from script_debugger import ScriptDebugger

def wait(d,condition,timeout=10):
 end=time.time()+timeout
 while time.time()<end:
  s=d.snapshot()
  if condition(s):return s
  time.sleep(.05)
 raise AssertionError('Timeout: '+str(d.snapshot()))
class TestScripts(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.d=ScriptDebugger(self.root)
 def tearDown(self):self.d.stop();self.tmp.cleanup()
 def test_python(self):
  (self.root/'main.py').write_text('nom = input("Nom: ")\nnombre = 41\nprint("Bonjour", nom, nombre+1)\n')
  self.d.start('python','main.py',[{'path':'main.py','line':2}]);wait(self.d,lambda s:'Nom:' in s['output']);self.d.input('Ada');s=wait(self.d,lambda s:s['state']=='paused');self.assertEqual(s['frame']['line'],2);self.assertIn('Ada',self.d.evaluate('nom'));self.d.action('next');wait(self.d,lambda s:s['state']=='paused' and s['frame']['line']==3);self.assertEqual(self.d.evaluate('nombre'),'41');self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('Bonjour Ada 42',s['output']);self.assertEqual(s['state'],'finished')
 def test_node(self):
  (self.root/'main.js').write_text('const nombre = 41;\nconst message = "bonjour";\nconsole.log(message, nombre + 1);\n')
  self.d.start('javascript','main.js',[{'path':'main.js','line':2}]);s=wait(self.d,lambda s:s['state']=='paused');self.assertEqual(s['frame']['line'],2);self.assertEqual(self.d.evaluate('nombre'),'41');self.d.action('next');wait(self.d,lambda s:s['state']=='paused' and s['frame']['line']==3);self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('bonjour 42',s['output']);self.assertEqual(s['state'],'finished')

from php_debugger import PhpDebugger
class TestPhp(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.d=PhpDebugger(self.root)
 def tearDown(self):self.d.stop();self.tmp.cleanup()
 def test_php(self):
  (self.root/'main.php').write_text('<?php\n$nom = trim(fgets(STDIN));\n$nombre = 41;\necho "Salut $nom ".($nombre+1)."\\n";\n')
  self.d.start('main.php',[{'path':'main.php','line':3}]);self.d.input('Ada');s=wait(self.d,lambda s:s['state']=='paused');self.assertEqual(s['frame']['line'],3);self.assertIn('Ada',self.d.evaluate('$nom'));self.d.action('next');wait(self.d,lambda s:s['state']=='paused' and s['frame']['line']==4);self.assertEqual(self.d.evaluate('$nombre'),'41');self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('Salut Ada 42',s['output'])

class TestMore(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.d=ScriptDebugger(self.root)
 def tearDown(self):self.d.stop();self.tmp.cleanup()
 def test_node_module_and_first_line(self):
  (self.root/'module accent é.mjs').write_text('const a = 3;\nconsole.log(a);\n')
  self.d.start('javascript','module accent é.mjs',[{'path':'module accent é.mjs','line':1}]);s=wait(self.d,lambda s:s['state']=='paused');self.assertEqual(s['frame']['line'],1);self.d.action('next');wait(self.d,lambda s:s['state']=='paused' and s['frame']['line']==2);self.assertEqual(self.d.evaluate('a'),'3');self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('3',s['output'])
 def test_python_breakpoints_in_project_import(self):
  (self.root/'main.py').write_text('import helper\nprint(helper.compute())\n');(self.root/'helper.py').write_text('def compute():\n    value=42\n    return value\n')
  self.d.start('python','main.py',[{'path':'helper.py','line':3}]);s=wait(self.d,lambda s:s['state']=='paused');self.assertEqual(s['frame']['file'],'helper.py');self.assertEqual(self.d.evaluate('value'),'42');self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('42',s['output'])
 def test_stop_and_restart(self):
  (self.root/'main.py').write_text('x=input("input: ")\nprint(x)\n');self.d.start('python','main.py',[{'path':'main.py','line':2}]);wait(self.d,lambda s:'input:' in s['output']);self.d.stop();self.assertFalse(self.d.snapshot()['active']);self.d.start('python','main.py',[{'path':'main.py','line':2}]);wait(self.d,lambda s:'input:' in s['output']);self.d.input('ok');wait(self.d,lambda s:s['state']=='paused');self.d.action('continue');s=wait(self.d,lambda s:not s['active']);self.assertIn('ok',s['output'])
if __name__=='__main__':unittest.main()
