"""Regression tests for execution/debug stop and external deletion safety."""
import json,os,socket,subprocess,sys,tempfile,time,unittest,urllib.error,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def request(base,path,payload=None):
 req=urllib.request.Request(base+'/api/'+path, data=json.dumps(payload).encode() if payload is not None else None, headers={'Content-Type':'application/json'})
 try:
  with urllib.request.urlopen(req,timeout=12) as r:return r.status,json.load(r)
 except urllib.error.HTTPError as e:return e.code,json.load(e)
class ApiStopTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.dir=Path(self.tmp.name);self.project=self.dir/'project';self.project.mkdir();s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close();self.base=f'http://127.0.0.1:{port}';env={**os.environ,'PASCAL_WORKSPACE':str(self.project),'PASCAL_PORT':str(port),'XDG_CACHE_HOME':str(self.dir/'cache')};self.proc=subprocess.Popen([sys.executable,str(ROOT/'server.py')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  for _ in range(120):
   try:request(self.base,'status');break
   except OSError:time.sleep(.05)
  else:raise RuntimeError('Le serveur ne démarre pas')
 def tearDown(self):
  self.proc.terminate()
  try:self.proc.wait(timeout=8)
  except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait()
  self.tmp.cleanup()
 def wait(self,path,predicate):
  for _ in range(140):
   _,data=request(self.base,path)
   if predicate(data):return data
   time.sleep(.05)
  self.fail('Délai dépassé : '+str(data))
 def test_stop_ignores_sigterm_and_can_restart(self):
  (self.project/'loop.py').write_text("import signal,time\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\nprint('pret',flush=True)\nwhile True: time.sleep(.05)\n")
  for i in range(2):
   status,result=request(self.base,'run',{'path':'loop.py'});self.assertEqual(status,200,result);self.assertTrue(result['ok'])
   self.wait('process',lambda d:d['running'] and 'pret' in d['output']);status,result=request(self.base,'stop',{});self.assertEqual(status,200,result)
   d=self.wait('process',lambda x:not x['running']);self.assertEqual(d['exitCode'],-9)
 def test_stop_debug_and_restart(self):
  (self.project/'debug.py').write_text('value=42\nprint(value)\n')
  for i in range(2):
   status,r=request(self.base,'debug/start',{'path':'debug.py','breakpoints':[{'path':'debug.py','line':2}]});self.assertEqual(status,200,r);self.wait('debug',lambda d:d['state']=='paused');status,r=request(self.base,'stop',{});self.assertEqual(status,200,r);self.wait('debug',lambda d:not d['active'])
 def test_shutdown_stops_stubborn_program(self):
  (self.project/'loop.py').write_text("import signal,time,os\nsignal.signal(signal.SIGTERM,signal.SIG_IGN)\nprint('PID',os.getpid(),flush=True)\nwhile True: time.sleep(.05)\n")
  status,result=request(self.base,'run',{'path':'loop.py'});self.assertEqual(status,200,result);data=self.wait('process',lambda x:'PID' in x['output']);pid=int(data['output'].split('PID')[1].strip().split()[0]);self.proc.terminate();self.proc.wait(timeout=8)
  for _ in range(40):
   if not Path('/proc/'+str(pid)).exists():break
   time.sleep(.05)
  self.assertFalse(Path('/proc/'+str(pid)).exists(),'Le programme a survécu à la fermeture du serveur')
 def test_external_delete_never_recreated_by_save(self):
  f=self.project/'existing.py';f.write_text('old');f.unlink();status,result=request(self.base,'save',{'path':'existing.py','content':'unsaved'});self.assertEqual(status,400,result);self.assertFalse(f.exists());self.assertIn('non recréé',result['error']);f.write_text('old');status,result=request(self.base,'save',{'path':'existing.py','content':'new'});self.assertEqual(status,200,result);self.assertEqual(f.read_text(),'new')
if __name__=='__main__':unittest.main()
