"""Tests Swift/Kotlin : logique pure toujours, compilation seulement si l'outil est présent."""
import shutil, subprocess, tempfile, unittest
from pathlib import Path
from unittest import mock
import polyglot
import swift_kotlin as sk

SWIFTC = shutil.which('swiftc')
KOTLINC = shutil.which('kotlinc')
JAVA = shutil.which('java')


class ExtensionTests(unittest.TestCase):
    def test_kind_from_extension(self):
        for name, expected in [('a.swift', 'swift'), ('a.kt', 'kotlin'), ('a.kts', 'kotlin'),
                               ('a.SWIFT', 'swift'), ('a.KT', 'kotlin')]:
            self.assertEqual(sk.kind(name), expected, name)
            self.assertEqual(polyglot.kind(name), expected, name)

    def test_existing_kinds_unchanged(self):
        # L'ajout ne doit rien voler aux langages déjà gérés.
        for name, expected in [('a.pas', 'pascal'), ('a.py', 'python'), ('a.rs', 'rust'),
                               ('a.go', 'go'), ('a.lua', 'lua'), ('a.ml', 'ocaml'),
                               ('a.pl', 'perl'), ('a.f90', 'fortran'), ('a.bas', 'basic'),
                               ('a.c', 'c'), ('a.cpp', 'cpp'), ('a.txt', None)]:
            self.assertEqual(polyglot.kind(name), expected, name)


class DiagnosticParsingTests(unittest.TestCase):
    def test_swift_diagnostics(self):
        content = 'let a = 1\nlet b = unknownSymbol\nprint(a)\n'
        out = ("/tmp/ps-swift-x/main.swift:2:9: error: use of unresolved identifier 'unknownSymbol'\n"
               "/tmp/ps-swift-x/main.swift:1:5: warning: immutable value 'a' was never used\n")
        rows = sk.parse_diagnostics('swift', out, 'main.swift', content)
        self.assertEqual(len(rows), 2, rows)
        self.assertEqual((rows[0]['line'], rows[0]['column'], rows[0]['severity']), (2, 9, 'error'))
        self.assertEqual(rows[0]['file'], 'main.swift')
        self.assertEqual(rows[1]['severity'], 'warning')

    def test_kotlin_diagnostics(self):
        content = 'fun main() {\n    println(inconnu)\n}\n'
        out = "hello.kt:2:13: error: unresolved reference: inconnu\n"
        rows = sk.parse_diagnostics('kotlin', out, 'hello.kt', content)
        self.assertEqual(len(rows), 1, rows)
        self.assertEqual((rows[0]['line'], rows[0]['column']), (2, 13))
        self.assertEqual(rows[0]['severity'], 'error')

    def test_kotlin_global_error_without_location(self):
        rows = sk.parse_diagnostics('kotlin', "error: could not find or load main class\n", 'a.kt', 'fun main(){}\n')
        self.assertEqual(len(rows), 1, rows)
        self.assertEqual((rows[0]['line'], rows[0]['column']), (1, 1))

    def test_out_of_range_line_is_clamped(self):
        rows = sk.parse_diagnostics('swift', "a.swift:999:3: error: boom\n", 'a.swift', 'let x = 1\n')
        self.assertEqual(rows[0]['line'], 1, rows)

    def test_utf16_column_for_astral_prefix(self):
        # Un émoji compte 1 caractère mais 2 unités UTF-16 : la colonne doit suivre.
        content = 'let 😀 = inconnu\n'
        rows = sk.parse_diagnostics('swift', "a.swift:1:9: error: x\n", 'a.swift', content)
        self.assertEqual(rows[0]['column'], 10, rows)

    def test_column_unchanged_for_bmp_accent(self):
        # « é » (U+00E9) reste sur une unité UTF-16 : la colonne ne bouge pas.
        content = 'let é = inconnu\n'
        rows = sk.parse_diagnostics('swift', "a.swift:1:9: error: x\n", 'a.swift', content)
        self.assertEqual(rows[0]['column'], 9, rows)

    def test_diagnostics_capped_at_100(self):
        out = ''.join('a.swift:%d:1: error: e\n' % i for i in range(1, 400))
        content = '\n'.join('let x%d = %d' % (i, i) for i in range(1, 400))
        self.assertEqual(len(sk.parse_diagnostics('swift', out, 'a.swift', content)), 100)


class AvailabilityTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.build = self.root / 'cache'
        self.build.mkdir()

    def test_missing_toolchain_reports_the_debian_package(self):
        with mock.patch.object(sk.shutil, 'which', return_value=None):
            r = sk.analyze('swift', self.root / 'a.swift', 'a.swift', 'let x = 1\n')
        self.assertEqual(r['state'], 'unavailable', r)
        self.assertIn('swiftlang', r['message'])

    def test_kotlin_requires_launcher_and_jvm(self):
        def fake(name):
            return '/usr/bin/kotlinc' if name == 'kotlinc' else None
        with mock.patch.object(sk.shutil, 'which', side_effect=fake):
            with self.assertRaises(ValueError) as ctx:
                sk.executable('kotlin')
        self.assertIn('kotlin', str(ctx.exception))

    def test_kotlin_has_no_live_analysis(self):
        # Documenté : la compilation JVM est trop lente pour un suivi en direct.
        r = sk.analyze('kotlin', self.root / 'a.kt', 'a.kt', 'fun main(){}\n')
        self.assertEqual(r['state'], 'unsupported', r)
        self.assertIn('Kotlin', r['message'])

    def test_oversized_buffer_rejected(self):
        with self.assertRaises(ValueError):
            sk.analyze('swift', self.root / 'a.swift', 'a.swift', 'x' * 2_100_000)


@unittest.skipUnless(SWIFTC, 'swiftc absent : sudo apt install swiftlang')
class SwiftToolchainTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.build = self.root / 'cache'
        self.build.mkdir()

    def test_valid_program_compiles_and_runs(self):
        p = self.root / 'hello.swift'
        src = 'print("Bonjour Swift")\n'
        p.write_text(src, encoding='utf8')
        r = sk.analyze('swift', p, p.name, src)
        self.assertEqual(r['state'], 'ready', r)
        self.assertTrue(r['ok'], r)
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertIn('Bonjour Swift', subprocess.check_output([b['binary']], text=True))

    def test_toplevel_code_in_non_main_file_is_accepted(self):
        # Swift refuse le code de haut niveau hors main.swift : on réessaie sur une copie.
        p = self.root / 'programme.swift'
        src = 'let n = 21\nprint(n * 2)\n'
        p.write_text(src, encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertIn('42', subprocess.check_output([b['binary']], text=True))

    def test_invalid_program_reports_diagnostics_on_the_project_file(self):
        p = self.root / 'hello.swift'
        src = 'let x = symboleInconnu\n'
        p.write_text(src, encoding='utf8')
        r = sk.analyze('swift', p, p.name, src)
        self.assertEqual(r['state'], 'ready', r)
        self.assertFalse(r['ok'], r)
        self.assertTrue(r['diagnostics'], r)
        self.assertEqual(r['diagnostics'][0]['file'], 'hello.swift')
        self.assertEqual(r['diagnostics'][0]['line'], 1)

    def test_analysis_never_runs_the_program(self):
        p = self.root / 'danger.swift'
        src = 'import Foundation\ntry? "ECRIT".write(toFile: "danger.txt", atomically: true, encoding: .utf8)\n'
        p.write_text(src, encoding='utf8')
        sk.analyze('swift', p, p.name, src)
        self.assertFalse((self.root / 'danger.txt').exists())

    def test_no_intermediate_files_next_to_the_source(self):
        p = self.root / 'hello.swift'
        p.write_text('print("x")\n', encoding='utf8')
        sk.analyze('swift', p, p.name, p.read_text())
        sk.build(self.root, self.build, p, p.name)
        leftovers = [x.name for x in self.root.iterdir() if x.name not in ('hello.swift', 'cache')]
        self.assertEqual(leftovers, [], leftovers)


@unittest.skipUnless(KOTLINC and JAVA, 'kotlinc/java absents : sudo apt install kotlin default-jre-headless')
class KotlinToolchainTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.build = self.root / 'cache'
        self.build.mkdir()

    def test_valid_program_compiles_and_runs(self):
        p = self.root / 'hello.kt'
        p.write_text('fun main() {\n    println("Bonjour Kotlin")\n}\n', encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertIn('Bonjour Kotlin', subprocess.check_output(b['command'], text=True))

    def test_invalid_program_reports_diagnostics(self):
        p = self.root / 'hello.kt'
        src = 'fun main() {\n    println(inconnu)\n}\n'
        p.write_text(src, encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertFalse(b['ok'], b)
        self.assertTrue(b['diagnostics'], b)
        self.assertEqual(b['diagnostics'][0]['line'], 2)

    def test_script_kts_runs_without_a_separate_compile(self):
        p = self.root / 'script.kts'
        p.write_text('println("Script Kotlin")\n', encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertIn('script', b['command'][1])

    def test_no_jar_left_next_to_the_source(self):
        p = self.root / 'hello.kt'
        p.write_text('fun main() { println("x") }\n', encoding='utf8')
        sk.build(self.root, self.build, p, p.name)
        self.assertFalse(list(self.root.glob('*.jar')))


if __name__ == '__main__':
    unittest.main()
