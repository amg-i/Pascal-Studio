"""Valide la logique Swift/Kotlin avec des compilateurs factices.

Les vraies toolchains pèsent plusieurs centaines de Mo ; ces bouchons vérifient
ici ce que le module garantit : réessai sur « main.swift », recopie des chemins
de diagnostic, nommage des artefacts dans le cache, commande d'exécution et
absence d'écriture à côté des sources.
"""
import os, stat, subprocess, tempfile, unittest
from pathlib import Path
from unittest import mock
import swift_kotlin as sk

# swiftc factice : refuse le code de haut niveau hors main.swift, comme le vrai.
FAKE_SWIFTC = r'''#!/bin/sh
out=""; mode="typecheck"; src=""
while [ $# -gt 0 ]; do
  case "$1" in
    -typecheck) mode="typecheck"; shift;;
    -o) out="$2"; mode="compile"; shift 2;;
    -I) shift 2;;
    -O|-Onone|-g) shift;;
    *) src="$1"; shift;;
  esac
done
[ -n "$src" ] || { echo "swiftc: no input files" >&2; exit 1; }
base=$(basename "$src")
if grep -q 'FORCE_ERROR' "$src"; then
  echo "$src:1:9: error: use of unresolved identifier 'FORCE_ERROR'" >&2
  exit 1
fi
# Le vrai Swift n'accepte les instructions de haut niveau que dans main.swift.
if [ "$base" != "main.swift" ] && grep -qE '^(print|let|var) ' "$src"; then
  echo "$src:1:1: error: expressions are not allowed at the top level" >&2
  exit 1
fi
if [ "$mode" = "typecheck" ]; then exit 0; fi
printf '#!/bin/sh\necho "Bonjour Swift"\n' > "$out"
chmod +x "$out"
exit 0
'''

# kotlinc factice : -d produit un jar, -script exécute directement.
FAKE_KOTLINC = r'''#!/bin/sh
out=""; script=""; src=""
while [ $# -gt 0 ]; do
  case "$1" in
    -d) out="$2"; shift 2;;
    -script) script="$1"; shift; src="$1"; shift;;
    -g|-nowarn|-include-runtime) shift;;
    *) src="$1"; shift;;
  esac
done
[ -n "$src" ] || { echo "kotlinc: no input files" >&2; exit 1; }
if grep -q 'FORCE_ERROR' "$src"; then
  echo "$src:2:13: error: unresolved reference: FORCE_ERROR" >&2
  exit 1
fi
if [ -n "$script" ]; then echo "Script Kotlin"; exit 0; fi
printf 'fake-jar' > "$out"
exit 0
'''

FAKE_LAUNCHER = r'''#!/bin/sh
echo "Bonjour Kotlin (jar=$1)"
'''


def write_exe(directory, name, body):
    p = Path(directory) / name
    p.write_text(body, encoding='utf8')
    p.chmod(p.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    return str(p)


class StubToolchainTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        root = Path(self.tmp.name)
        self.bin = root / 'bin'
        self.bin.mkdir()
        self.root = root / 'project'
        self.root.mkdir()
        self.build = self.root / 'cache'
        self.build.mkdir()
        self.swiftc = write_exe(self.bin, 'swiftc', FAKE_SWIFTC)
        self.kotlinc = write_exe(self.bin, 'kotlinc', FAKE_KOTLINC)
        self.kotlin = write_exe(self.bin, 'kotlin', FAKE_LAUNCHER)
        self.java = write_exe(self.bin, 'java', FAKE_LAUNCHER)
        self.which = mock.patch.object(sk.shutil, 'which',
                                       side_effect=lambda n: str(self.bin / n)
                                       if (self.bin / n).exists() else None)
        self.which.start()
        self.addCleanup(self.which.stop)

    # --- Swift -------------------------------------------------------------
    def test_swift_toplevel_program_is_retried_on_a_main_swift_copy(self):
        p = self.root / 'programme.swift'
        src = 'let n = 21\nprint(n * 2)\n'
        p.write_text(src, encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertTrue(Path(b['binary']).is_file(), b)
        self.assertIn('Bonjour Swift', subprocess.check_output([b['binary']], text=True))

    def test_swift_diagnostics_point_at_the_project_file_not_the_copy(self):
        p = self.root / 'programme.swift'
        src = 'let n = FORCE_ERROR\nprint(n)\n'
        p.write_text(src, encoding='utf8')
        r = sk.analyze('swift', p, p.name, src)
        self.assertEqual(r['state'], 'ready', r)
        self.assertFalse(r['ok'], r)
        self.assertTrue(r['diagnostics'], r)
        self.assertEqual(r['diagnostics'][0]['file'], 'programme.swift')
        # Le chemin temporaire ne doit jamais fuir dans l'affichage.
        self.assertNotIn('ps-swift', r['output'])

    def test_swift_main_file_is_not_retried(self):
        p = self.root / 'main.swift'
        src = 'print("direct")\n'
        p.write_text(src, encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)

    def test_swift_binary_lands_in_the_cache_only(self):
        p = self.root / 'programme.swift'
        p.write_text('print("x")\n', encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertEqual(Path(b['binary']).parent.resolve(), self.build.resolve())
        leftovers = sorted(x.name for x in self.root.iterdir() if x.name != 'cache')
        self.assertEqual(leftovers, ['programme.swift'], leftovers)

    def test_swift_artifact_name_is_stable_for_a_given_path(self):
        p = self.root / 'programme.swift'
        p.write_text('print("x")\n', encoding='utf8')
        first = sk.build(self.root, self.build, p, p.name)['binary']
        second = sk.build(self.root, self.build, p, p.name)['binary']
        self.assertEqual(first, second)

    # --- Kotlin ------------------------------------------------------------
    def test_kotlin_build_produces_a_jar_in_the_cache_and_a_run_command(self):
        p = self.root / 'hello.kt'
        p.write_text('fun main() { println("x") }\n', encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertIsNone(b['binary'], b)
        jar = Path(b['command'][1])
        self.assertEqual(jar.suffix, '.jar')
        self.assertEqual(jar.parent.resolve(), self.build.resolve())
        self.assertEqual(b['command'][0], self.kotlin)
        self.assertIn('Bonjour Kotlin', subprocess.check_output(b['command'], text=True))

    def test_kotlin_diagnostics_are_parsed_with_line_and_column(self):
        p = self.root / 'hello.kt'
        src = 'fun main() {\n    println(FORCE_ERROR)\n}\n'
        p.write_text(src, encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertFalse(b['ok'], b)
        self.assertTrue(b['diagnostics'], b)
        self.assertEqual(b['diagnostics'][0]['line'], 2)
        self.assertEqual(b['diagnostics'][0]['file'], 'hello.kt')
        self.assertIsNone(b['command'], b)

    def test_kotlin_script_kts_runs_without_producing_a_jar(self):
        p = self.root / 'script.kts'
        p.write_text('println("hi")\n', encoding='utf8')
        b = sk.build(self.root, self.build, p, p.name)
        self.assertTrue(b['ok'], b)
        self.assertEqual(b['command'][1], '-script')
        self.assertEqual(list(self.build.glob('*.jar')), [])

    def test_kotlin_debug_build_passes_the_debug_flag(self):
        seen = {}
        real = sk.invoke

        def spy(cmd, cwd, timeout=30):
            seen['cmd'] = cmd
            return real(cmd, cwd, timeout)
        p = self.root / 'hello.kt'
        p.write_text('fun main() { println("x") }\n', encoding='utf8')
        with mock.patch.object(sk, 'invoke', side_effect=spy):
            sk.build(self.root, self.build, p, p.name, debug=True)
        self.assertIn('-g', seen['cmd'], seen['cmd'])

    def test_missing_java_is_reported(self):
        os.remove(self.java)
        with self.assertRaises(ValueError) as ctx:
            sk.executable('kotlin')
        self.assertIn('java', str(ctx.exception))

    def test_timeout_is_reported_as_a_timeout_state(self):
        p = self.root / 'a.swift'
        p.write_text('print("x")\n', encoding='utf8')
        with mock.patch.object(sk, 'invoke', side_effect=ValueError('Compilation interrompue après 25 secondes.')):
            r = sk.analyze('swift', p, p.name, p.read_text())
        self.assertEqual(r['state'], 'timeout', r)


if __name__ == '__main__':
    unittest.main()
