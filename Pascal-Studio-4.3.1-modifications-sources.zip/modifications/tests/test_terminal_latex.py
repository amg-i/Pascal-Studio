"""Tests du PTY et des documents LaTeX, y compris les routes locales."""
import base64,os,signal,subprocess,tempfile,time,unittest,urllib.request,urllib.error,json
from pathlib import Path
from integrated_terminal import Terminal
from latex_tools import LatexManager
from project_tools import todos
import test_stop_and_save as support
request=support.request

class TermTests(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.t=Terminal();self.s=self.t.start(self.tmp.name,80,20);self.pos=0
 def tearDown(self):self.t.stop();self.tmp.cleanup()
 def write(self,x):self.t.write(self.s['id'],base64.b64encode(x).decode())
 def wait(self,s):
  output=b'';end=time.time()+5
  while time.time()<end:
   r=self.t.read(self.s['id'],self.pos);self.pos=r['next'];output+=base64.b64decode(r['data'])
   if s in output:return output
   time.sleep(.05)
  self.fail(f'sortie manquante {s!r}: {output!r}')
 def test_shell_cwd_color_interactive_interrupt_and_resize(self):
  self.write(b'pwd\n');self.assertIn(self.tmp.name.encode(),self.wait(self.tmp.name.encode()))
  self.write(b'printf "\\033[31mRED\\033[0m\\n"\n');self.assertIn(b'\x1b[31mRED\x1b[0m',self.wait(b'\x1b[31mRED\x1b[0m'))
  self.t.resize(self.s['id'],91,23);self.write(b'stty size\n');self.wait(b'23 91')
  self.write(b'cat\n');time.sleep(.2);self.write(b'interactif 123\n');self.wait(b'interactif 123\r\ninteractif 123')
  self.write(b'\x03');self.write(b'echo APRES_CTRL_C\n');self.wait(b'APRES_CTRL_C')
 def test_stop_foreground_ignoring_hup(self):
  self.write(b"python3 -c 'import os,signal,time; signal.signal(signal.SIGHUP,signal.SIG_IGN); print(\"STUBBORN_PID\",os.getpid(),flush=True); time.sleep(300)'\n")
  import re
  data=self.wait(b'STUBBORN_PID ')
  for _ in range(80):
   match=re.search(rb'STUBBORN_PID (\d+)',data)
   if match:break
   r=self.t.read(self.s['id'],self.pos);self.pos=r['next'];data+=base64.b64decode(r['data']);time.sleep(.05)
  self.assertTrue(match,data);pid=int(match.group(1));self.t.stop(self.s['id'])
  for _ in range(60):
   try:
    state=Path('/proc/'+str(pid)+'/stat').read_text().split()[2]
    if state=='Z':break
   except FileNotFoundError:break
   time.sleep(.05)
  else:self.fail('Le programme ignorant SIGHUP est encore actif')
 def test_session_id_and_invalid_dimensions(self):
  with self.assertRaises(ValueError):self.t.write('autre',base64.b64encode(b'echo hi').decode())
  with self.assertRaises(ValueError):self.t.resize(self.s['id'],99999,10)
 def test_exit_and_restart(self):
  self.write(b'exit\n');end=time.time()+4
  while time.time()<end and self.t.info()['running']:time.sleep(.05)
  self.assertFalse(self.t.info()['running']);fresh=self.t.start(self.tmp.name);self.assertNotEqual(fresh['id'],self.s['id'])
  self.s=fresh;self.pos=0;self.write(b'echo REPRISE\n');self.wait(b'REPRISE')
 def test_background_buffer_is_bounded(self):
  self.write(b"python3 -c \"print('A'*2100000)\"\n");end=time.time()+10
  while time.time()<end:
   with self.t.lock:n=self.t.offset
   if n>0:break
   time.sleep(.05)
  self.assertGreater(n,0);r=self.t.read(self.s['id'],0);self.assertTrue(r['skipped']);self.assertLessEqual(len(base64.b64decode(r['data'])),262144)

class LatexTests(unittest.TestCase):
 def test_compile_cache_and_errors(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);file=p/'principal.tex';(p/'style.sty').write_text('\\ProvidesPackage{style}\n\\newcommand{\\salut}{Bonjour}\n');file.write_text('\\documentclass{article}\n\\usepackage{style}\n\\begin{document}\n\\salut\n\\end{document}\n');(p/'principal.pdf').write_bytes(b'ne pas ecraser');m=LatexManager();r=m.compile(p,p/'cache',file,'principal.tex',{});self.assertTrue(r['ok'],r['output']);self.assertTrue(m.get(r['pdfId']).read_bytes().startswith(b'%PDF'));self.assertEqual((p/'principal.pdf').read_bytes(),b'ne pas ecraser');file.write_text('\\documentclass{article}\n\\begin{document}\n\\commandeinexistante\n\\end{document}\n');r=m.compile(p,p/'cache',file,'principal.tex',{});self.assertFalse(r['ok']);self.assertTrue(any(x['file']=='principal.tex' and x['line']==3 for x in r['diagnostics']),r['output']);m.close()
 def test_todo_tex(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);(p/'doc.tex').write_text('10\\% TODO pas un commentaire\n% TODO: revoir\n');(p/'style.sty').write_text('% FIXME: style\n');found=todos(p)['items'];self.assertEqual([(x['kind'],x['message']) for x in found],[('TODO','revoir'),('FIXME','style')])

class TerminalApiTests(support.ApiStopTests):
 # Inherited regression tests are useful but not run twice in discovery.
 def test_same_origin_and_json_required(self):
  req=urllib.request.Request(self.base+'/api/terminal/start',data=b'{}',headers={'Content-Type':'application/json','Origin':'https://untrusted.example'})
  with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(req)
  self.assertEqual(e.exception.code,400)
  req=urllib.request.Request(self.base+'/api/terminal/start',data=b'{}',headers={'Content-Type':'text/plain'})
  with self.assertRaises(urllib.error.HTTPError):urllib.request.urlopen(req)
  status,r=request(self.base,'terminal/start',{'rows':20,'cols':80});self.assertEqual(status,200);self.assertTrue(r['running']);request(self.base,'terminal/stop',{'id':r['id']})
 def test_shutdown_stops_shell_and_foreground(self):
  status,r=request(self.base,'terminal/start',{});self.assertEqual(status,200);sid=r['id'];cmd=b"python3 -c 'import os,time; print(\"CHILDPID\",os.getpid(),flush=True); time.sleep(300)'\n";request(self.base,'terminal/write',{'id':sid,'data':base64.b64encode(cmd).decode()});data=b'';offset=0
  for _ in range(100):
   _,out=request(self.base,'terminal/read?id='+sid+'&offset='+str(offset));offset=out['next'];data+=base64.b64decode(out['data']);
   import re
   match=re.search(rb'CHILDPID (\d+)',data)
   if match:break
   time.sleep(.05)
  self.assertTrue(match,data);pid=int(match.group(1));self.proc.terminate();self.proc.wait(timeout=8)
  for _ in range(60):
   try:
    status=Path('/proc/'+str(pid)+'/stat').read_text().split()[2]
    if status=='Z':break
   except FileNotFoundError:break
   time.sleep(.05)
  else:self.fail('Commande au premier plan encore active après fermeture du serveur')
if __name__=='__main__':unittest.main()
