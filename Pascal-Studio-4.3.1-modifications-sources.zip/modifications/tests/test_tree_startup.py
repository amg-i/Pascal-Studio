"""Arborescence rapide : contenu, invalidation et coalescence."""
import os,sys,tempfile,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server
class TreeTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.old=server.ROOT;server.ROOT=Path(self.tmp.name);server.invalidate_tree()
 def tearDown(self):server.ROOT=self.old;server.invalidate_tree();self.tmp.cleanup()
 def test_paths_order_hidden_and_links(self):
  p=server.ROOT;(p/'zdir').mkdir();(p/'Adir').mkdir();(p/'zdir'/'code.pas').write_text('');(p/'a.pas').write_text('');(p/'.hidden').write_text('');(p/'link').symlink_to(p/'zdir',target_is_directory=True)
  t=server.tree();self.assertEqual([x['name'] for x in t],['Adir','zdir','a.pas']);self.assertEqual(t[1]['children'][0]['path'],'zdir/code.pas')
 def test_coalesced_and_invalidation(self):
  original=server._scan_tree;calls=[]
  def slow(*args):calls.append(1);time.sleep(.12);return original(*args)
  with patch.object(server,'_scan_tree',side_effect=slow):
   threads=[threading.Thread(target=server.tree) for _ in range(6)]
   for t in threads:t.start()
   for t in threads:t.join()
   self.assertEqual(len(calls),1)
   (server.ROOT/'a').write_text('');server.invalidate_tree();self.assertEqual(server.tree()[0]['name'],'a');self.assertEqual(len(calls),2)
 def test_external_changes_after_ttl(self):
  self.assertEqual(server.tree(),[]);(server.ROOT/'outside').write_text('');time.sleep(.8);self.assertEqual(server.tree()[0]['name'],'outside')
 def test_switch_project_does_not_wait_on_old_scan(self):
  oldroot=server.ROOT;second=Path(tempfile.mkdtemp(dir=oldroot));(second/'nouveau.pas').write_text('');started=threading.Event();cont=threading.Event();original=server._scan_tree
  def pause(root,*args):
   if root==oldroot:started.set();cont.wait(3)
   return original(root,*args)
  with patch.object(server,'_scan_tree',side_effect=pause):
   t=threading.Thread(target=server.tree);t.start();self.assertTrue(started.wait(3));server.ROOT=second;server.invalidate_tree();t0=time.monotonic();result=server.tree();self.assertLess(time.monotonic()-t0,1);self.assertEqual(result[0]['name'],'nouveau.pas');cont.set();t.join(3)
 def test_invalidation_during_scan_not_cached(self):
  started=threading.Event();cont=threading.Event();original=server._scan_tree
  def pause(*args):
   result=original(*args);started.set();cont.wait(3);return result
  with patch.object(server,'_scan_tree',side_effect=pause):
   t=threading.Thread(target=server.tree);t.start();self.assertTrue(started.wait(3));(server.ROOT/'new').write_text('');server.invalidate_tree();cont.set();t.join(3)
  self.assertEqual(server.tree()[0]['name'],'new')
if __name__=='__main__':unittest.main()
