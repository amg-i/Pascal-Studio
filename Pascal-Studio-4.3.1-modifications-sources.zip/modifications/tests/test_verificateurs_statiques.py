"""Tests des vérificateurs statiques locaux et du registre des langages.

Aucun de ces tests n'exécute le code analysé : les vérificateurs ne doivent
jamais le faire. Les outils externes optionnels (bash -n, shellcheck, make,
csc) sont absents de la machine de test ou remplacés par des doubles, afin que
la suite donne le même résultat partout.
"""

import unittest
from unittest import mock

import langages
import verificateurs_statiques as V

CLE = 'test'
CHEMIN = '/projet/test'


def analyser(kind, texte, chemin=CHEMIN):
    return V.analyze(kind, chemin, CLE, texte)


def severites(resultat):
    return [d['severity'] for d in resultat['diagnostics']]


def messages(resultat):
    return [d['message'] for d in resultat['diagnostics']]


class ContratCommun(unittest.TestCase):
    """Le contrat doit être identique à celui de scripting.analyze."""

    def test_resultat_complet(self):
        r = analyser('json', '{"a":1}')
        for champ in ('state', 'ok', 'diagnostics', 'message', 'output'):
            self.assertIn(champ, r)
        self.assertEqual(r['state'], 'ready')

    def test_diagnostic_complet(self):
        r = analyser('json', '{"a":1,}')
        d = r['diagnostics'][0]
        for champ in ('file', 'line', 'column', 'endLine', 'endColumn',
                      'severity', 'message'):
            self.assertIn(champ, d)
        self.assertEqual(d['file'], CLE)
        self.assertGreaterEqual(d['endColumn'], d['column'])

    def test_langage_inconnu(self):
        r = analyser('langage_inexistant', 'x')
        self.assertEqual(r['state'], 'unsupported')
        self.assertFalse(r['ok'])

    def test_tampon_trop_volumineux(self):
        with self.assertRaises(ValueError):
            analyser('json', '1' * (V.LIMITE_OCTETS + 1))

    def test_contenu_non_textuel(self):
        with self.assertRaises(ValueError):
            analyser('json', None)

    def test_nombre_de_diagnostics_borne(self):
        texte = ''.join('{\n' + '"k%d":1,\n' % i for i in range(400))
        r = analyser('css', '\n'.join('a%d { couleur: x }' % i for i in range(400)))
        self.assertLessEqual(len(r['diagnostics']), V.LIMITE_DIAGNOSTICS)

    def test_ok_reflete_les_erreurs_pas_les_avertissements(self):
        self.assertTrue(analyser('css', 'a { couleur: red }')['ok'])
        self.assertFalse(analyser('css', 'a {') ['ok'])


class ColonnesUtf16(unittest.TestCase):
    def test_accent_ne_decale_pas(self):
        base = analyser('html', '<p id="x"></p><p id="x"></p>')
        accent = analyser('html', '<p id="x"></p><p id="é"></p>')
        self.assertEqual(base['diagnostics'][0]['column'],
                         accent['diagnostics'][0]['column'])

    def test_caractere_astral_decale(self):
        # L'émoji doit rester DANS une chaîne : hors chaîne, le JSON devient
        # invalide et le diagnostic ne serait plus celui de la clef en double.
        sans = analyser('json', '{"a":"x","a":2}')
        avec = analyser('json', '{"a":"\U0001F600","a":2}')
        self.assertEqual(avec['diagnostics'][0]['column'],
                         sans['diagnostics'][0]['column'] + 1)

    def test_utf16col_hors_ligne(self):
        self.assertEqual(V.utf16col('abc', 99, 2), 2)


class Json(unittest.TestCase):
    def test_valide(self):
        r = analyser('json', '{"a":1,"b":[1,2,3]}')
        self.assertTrue(r['ok'])
        self.assertEqual(r['diagnostics'], [])

    def test_invalide(self):
        r = analyser('json', '{"a":1,,}')
        self.assertFalse(r['ok'])
        self.assertIn('error', severites(r))

    def test_clef_en_double(self):
        r = analyser('json', '{"a":1,\n "b":2,\n "a":3}')
        self.assertTrue(r['ok'], 'une clef en double n’invalide pas le JSON')
        self.assertIn('warning', severites(r))
        self.assertIn('ligne 1', messages(r)[0])

    def test_clef_en_double_imbriquee(self):
        r = analyser('json', '{"x":{"k":1,"k":2}}')
        self.assertEqual(len(r['diagnostics']), 1)

    def test_tableaux_ignorés(self):
        r = analyser('json', '[{"k":1},{"k":2}]')
        self.assertEqual(r['diagnostics'], [])

    def test_guillemet_échappé(self):
        r = analyser('json', '{"a\\"b":1,"c":2}')
        self.assertTrue(r['ok'])


class XmlEtSvg(unittest.TestCase):
    def test_xml_valide(self):
        self.assertTrue(analyser('xml', '<a><b/></a>')['ok'])

    def test_xml_baloises_inversées(self):
        r = analyser('xml', '<a><b></a></b>')
        self.assertFalse(r['ok'])
        self.assertIn('mal formé', messages(r)[0])

    def test_svg_sans_xmlns(self):
        r = analyser('svg', '<svg width="10"><rect/></svg>')
        self.assertIn('warning', severites(r))
        self.assertIn('xmlns', messages(r)[0])

    def test_svg_sans_racine(self):
        r = analyser('svg', '<rect/>')
        self.assertFalse(r['ok'])

    def test_svg_couleur_invalide(self):
        r = analyser('svg', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1">'
                            '<rect fill="#12345"/></svg>')
        self.assertTrue(any('Couleur' in m for m in messages(r)))

    def test_svg_couleur_valide(self):
        r = analyser('svg', '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1 1">'
                            '<rect fill="#abc" stroke="currentColor"/></svg>')
        self.assertFalse(any('Couleur' in m for m in messages(r)))


class Html(unittest.TestCase):
    def test_document_valide(self):
        r = analyser('html', '<!DOCTYPE html><html><head><title>t</title></head>'
                             '<body><p>ok</p></body></html>')
        self.assertTrue(r['ok'])
        self.assertEqual(r['diagnostics'], [])

    def test_balise_jamais_fermée(self):
        r = analyser('html', '<!DOCTYPE html><div><p>texte</div>')
        self.assertFalse(r['ok'])
        self.assertTrue(any('jamais fermé' in m for m in messages(r)))

    def test_fermeture_sans_ouverture(self):
        r = analyser('html', '<!DOCTYPE html></span>')
        self.assertFalse(r['ok'])

    def test_éléments_vides_ne_se_ferment_pas(self):
        r = analyser('html', '<!DOCTYPE html><br></br>')
        self.assertTrue(any('ne se ferme pas' in m for m in messages(r)))

    def test_id_en_double(self):
        r = analyser('html', '<div id="x"></div><span id="x"></span>')
        self.assertFalse(r['ok'])
        self.assertIn('en double', messages(r)[0])

    def test_img_sans_alt(self):
        r = analyser('html', '<img src="a.png" alt="">')
        self.assertFalse(any('alt' in m for m in messages(r)))
        r = analyser('html', '<img src="a.png">')
        self.assertTrue(any('alt' in m for m in messages(r)))

    def test_doctype_absent(self):
        r = analyser('html', '<html><body>x</body></html>')
        self.assertTrue(any('DOCTYPE' in m for m in messages(r)))

    def test_script_non_analysé_comme_html(self):
        r = analyser('html', '<script>if (a < b) { x(); }</script>')
        self.assertTrue(r['ok'], 'le contenu de <script> n’est pas du HTML')

    def test_cible_locale_manquante(self):
        r = analyser('html', '<img src="absent.png" alt="">', '/projet/page.html')
        self.assertTrue(any('introuvable' in m for m in messages(r)))

    def test_cible_distante_ignorée(self):
        r = analyser('html', '<img src="https://exemple.fr/a.png" alt="">')
        self.assertFalse(any('introuvable' in m for m in messages(r)))


class Css(unittest.TestCase):
    def test_valide(self):
        self.assertEqual(analyser('css', 'body { color: #abc; margin: 0 auto; }')
                         ['diagnostics'], [])

    def test_accolade_ouverte(self):
        r = analyser('css', 'body { color: red;\n')
        self.assertFalse(r['ok'])
        self.assertIn('jamais fermé', messages(r)[0])

    def test_accolade_fermante_seule(self):
        self.assertFalse(analyser('css', '}')['ok'])

    def test_propriété_inconnue(self):
        r = analyser('css', 'body { colour: red }')
        self.assertIn('warning', severites(r))
        self.assertIn('inconnue', messages(r)[0])

    def test_propriété_valide(self):
        r = analyser('css', 'body { color: red; display: flex }')
        self.assertEqual(r['diagnostics'], [])

    def test_préfixe_vendeur_ignoré(self):
        r = analyser('css', 'body { -webkit-box-reflect: none }')
        self.assertEqual(r['diagnostics'], [])

    def test_couleur_mal_formée(self):
        self.assertFalse(analyser('css', 'a { color: #12345 }')['ok'])

    def test_couleur_valide(self):
        self.assertTrue(analyser('css', 'a { color: #123456 }')['ok'])

    def test_unité_inconnue(self):
        self.assertFalse(analyser('css', 'a { width: 10zorkmids }')['ok'])

    def test_espace_entre_valeur_et_unité(self):
        r = analyser('css', 'a { width: 10 px }')
        self.assertFalse(r['ok'])
        self.assertIn('Espace entre la valeur', messages(r)[0])

    def test_mots_clés_après_un_nombre_non_visés(self):
        self.assertTrue(analyser('css', 'a { margin: 0 auto; flex: 1 1 auto }')['ok'])

    def test_unité_valide(self):
        self.assertTrue(analyser('css', 'a { width: 10rem; height: 50% }')['ok'])

    def test_var_non_jugée(self):
        self.assertTrue(analyser('css', 'a { color: var(--inconnu) }')['ok'])

    def test_parenthèses_déséquilibrées(self):
        self.assertFalse(analyser('css', 'a { background: url(x.png }')['ok'])

    def test_commentaire_non_fermé(self):
        r = analyser('css', '/* début\na { color: red }')
        self.assertTrue(any('jamais fermé' in m for m in messages(r)))

    def test_commentaire_ne_fausse_pas_les_lignes(self):
        r = analyser('css', '/* commentaire\n   sur deux lignes */\na {')
        self.assertEqual(r['diagnostics'][0]['line'], 3)

    def test_règle_vide(self):
        r = analyser('css', 'a { }')
        self.assertIn('info', severites(r))

    def test_at_rule_reconnue(self):
        r = analyser('css', '@media (min-width: 10px) { a { color: red } }')
        self.assertEqual(r['diagnostics'], [])


class Markdown(unittest.TestCase):
    def test_valide(self):
        self.assertEqual(analyser('markdown', '# Titre\n\nTexte.\n')['diagnostics'], [])

    def test_bloc_de_code_non_fermé(self):
        r = analyser('markdown', '# T\n\n```python\nprint(1)\n')
        self.assertFalse(r['ok'])
        self.assertIn('jamais refermé', messages(r)[0])

    def test_bloc_fermé(self):
        r = analyser('markdown', '```python\nprint(1)\n```\n')
        self.assertTrue(r['ok'])

    def test_code_intérieur_ignoré(self):
        r = analyser('markdown', '```\n# ceci n’est pas un titre\n```\n')
        self.assertEqual(r['diagnostics'], [])

    def test_saut_de_niveau(self):
        r = analyser('markdown', '# Un\n\n### Trois\n')
        self.assertTrue(any('Saute du niveau' in m for m in messages(r)))

    def test_descente_progressive_ok(self):
        r = analyser('markdown', '# Un\n\n## Deux\n\n### Trois\n')
        self.assertFalse(any('Saute' in m for m in messages(r)))

    def test_titre_en_double(self):
        r = analyser('markdown', '## Même titre\n\n## Même titre\n')
        self.assertTrue(any('en double' in m for m in messages(r)))

    def test_lien_local_manquant(self):
        r = analyser('markdown', '[texte](absent.md)\n', '/projet/doc.md')
        self.assertTrue(any('introuvable' in m for m in messages(r)))

    def test_lien_interne_ignoré(self):
        r = analyser('markdown', '[texte](#ancre)\n')
        self.assertFalse(any('introuvable' in m for m in messages(r)))

    def test_lien_absolu_ignoré(self):
        r = analyser('markdown', '[texte](https://exemple.fr/x)\n')
        self.assertFalse(any('introuvable' in m for m in messages(r)))


class Shell(unittest.TestCase):
    def test_syntaxe_invalide(self):
        with mock.patch.object(V.shutil, 'which',
                               side_effect=lambda n: '/bin/bash' if n == 'bash' else None):
            r = analyser('shell', 'if [ 1 ]; then\n  echo ok\n', '/projet/s.sh')
        self.assertFalse(r['ok'])

    def test_syntaxe_valide(self):
        with mock.patch.object(V.shutil, 'which',
                               side_effect=lambda n: '/bin/bash' if n == 'bash' else None):
            r = analyser('shell', '#!/bin/sh\nset -eu\necho ok\n', '/projet/s.sh')
        self.assertTrue(r['ok'])

    def test_shebang_absent(self):
        with mock.patch.object(V.shutil, 'which', return_value=None):
            r = analyser('shell', 'echo ok\n', '/projet/s.sh')
        self.assertEqual(r['state'], 'unavailable')

    def test_rm_rf_sur_variable(self):
        with mock.patch.object(V.shutil, 'which',
                               side_effect=lambda n: '/bin/bash' if n == 'bash' else None):
            r = analyser('shell', '#!/bin/sh\nrm -rf $DOSSIER\n', '/projet/s.sh')
        self.assertTrue(any('rm -rf' in m for m in messages(r)))

    def test_shellcheck_consommé(self):
        sortie = ('s.sh:2:1: warning: Utilisez shellcheck [SC2086]\n'
                  's.sh:3:5: error: chose [SC1000]\n')
        rows = V._analyser_shellcheck(CLE, '#!/bin/sh\nx\ny\n', sortie)
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[0]['severity'], 'warning')
        self.assertEqual(rows[1]['severity'], 'error')
        self.assertIn('SC2086', rows[0]['message'])

    def test_aucun_outil_ne_silence_pas_tout(self):
        with mock.patch.object(V.shutil, 'which', return_value=None):
            r = analyser('shell', 'echo x', '/projet/s.sh')
        self.assertEqual(r['state'], 'unavailable')
        self.assertIn('Bash', r['message'])


class Makefile(unittest.TestCase):
    def test_recette_avec_espaces(self):
        r = analyser('make', 'all:\n    echo bonjour\n', '/projet/Makefile')
        self.assertFalse(r['ok'])
        self.assertIn('tabulation', messages(r)[0])

    def test_recette_avec_tabulation(self):
        r = analyser('make', 'all:\n\techo bonjour\n', '/projet/Makefile')
        self.assertFalse(any('tabulation' in m for m in messages(r)))

    def test_variable_non_affectée(self):
        r = analyser('make', 'all:\n\techo $(JAMAIS_DEFINIE)\n', '/projet/Makefile')
        self.assertTrue(any('jamais affectée' in m for m in messages(r)))

    def test_variable_affectée(self):
        r = analyser('make', 'X = 1\nall:\n\techo $(X)\n', '/projet/Makefile')
        self.assertFalse(any('jamais affectée' in m for m in messages(r)))

    def test_variable_prédéfinie_ignorée(self):
        r = analyser('make', 'all:\n\techo $(MAKE)\n', '/projet/Makefile')
        self.assertFalse(any('jamais affectée' in m for m in messages(r)))

    def test_directives_avec_espaces_ok(self):
        r = analyser('make', 'ifeq (a,b)\n  X = 1\nendif\nall:\n\techo ok\n',
                     '/projet/Makefile')
        self.assertFalse(any('tabulation' in m for m in messages(r)))

    def test_parenthèse_non_fermée(self):
        r = analyser('make', 'all:\n\techo $(X\n', '/projet/Makefile')
        self.assertTrue(any('jamais fermée' in m for m in messages(r)))

    def test_make_absent_ne_bloque_pas(self):
        with mock.patch.object(V.shutil, 'which', return_value=None):
            r = analyser('make', 'all:\n\techo ok\n', '/projet/Makefile')
        self.assertEqual(r['state'], 'ready')


class Cmake(unittest.TestCase):
    def test_valide(self):
        r = analyser('cmake', 'cmake_minimum_required(VERSION 3.20)\nproject(demo)\n',
                    '/projet/CMakeLists.txt')
        self.assertEqual(r['diagnostics'], [])

    def test_parenthèse_non_fermée(self):
        r = analyser('cmake', 'project(demo\n', '/projet/CMakeLists.txt')
        self.assertFalse(r['ok'])
        self.assertIn('jamais fermé', messages(r)[0])

    def test_parenthèse_fermante_seule(self):
        self.assertFalse(analyser('cmake', ')', '/projet/CMakeLists.txt')['ok'])

    def test_commande_inconnue(self):
        r = analyser('cmake', 'projet(demo)\n', '/projet/CMakeLists.txt')
        self.assertTrue(any('inconnue' in m for m in messages(r)))

    def test_casse_insensible(self):
        r = analyser('cmake', 'cmake_minimum_required(VERSION 3.20)\nPROJECT(demo)\n',
                    '/projet/CMakeLists.txt')
        self.assertFalse(any('inconnue' in m for m in messages(r)))

    def test_minimum_requis_absent(self):
        r = analyser('cmake', 'project(demo)\n', '/projet/CMakeLists.txt')
        self.assertIn('info', severites(r))

    def test_commentaire_ignoré(self):
        r = analyser('cmake', '# project(casse)\nproject(demo)\n',
                    '/projet/CMakeLists.txt')
        self.assertFalse(any('inconnue' in m for m in messages(r)))

    def test_variable_non_définie(self):
        r = analyser('cmake', 'project(demo)\nmessage(${INCONNUE})\n',
                    '/projet/CMakeLists.txt')
        self.assertTrue(any('jamais définie' in m for m in messages(r)))

    def test_variable_prédéfinie_ignorée(self):
        r = analyser('cmake', 'project(demo)\nmessage(${CMAKE_SOURCE_DIR})\n',
                    '/projet/CMakeLists.txt')
        self.assertFalse(any('jamais définie' in m for m in messages(r)))


class Csharp(unittest.TestCase):
    def test_valide(self):
        r = analyser('cs', 'using System;\nclass A { static void Main() { } }',
                    '/projet/a.cs')
        self.assertFalse(any(d['severity'] == 'error' for d in r['diagnostics']))

    def test_accolade_ouverte(self):
        r = analyser('cs', 'class A { void M() { }', '/projet/a.cs')
        self.assertFalse(r['ok'])

    def test_accolade_fermante_seule(self):
        self.assertFalse(analyser('cs', '}', '/projet/a.cs')['ok'])

    def test_chaîne_non_fermée(self):
        r = analyser('cs', 'class A { string s = "abc; } }', '/projet/a.cs')
        self.assertTrue(any('Chaîne littérale' in m for m in messages(r)))

    def test_guillemet_échappé_ignoré(self):
        r = analyser('cs', 'class A { string s = "a\\"b"; }', '/projet/a.cs')
        self.assertFalse(any('Chaîne littérale' in m for m in messages(r)))

    def test_chaîne_verbatim_ignorée(self):
        r = analyser('cs', 'class A { string p = @"C:\\temp\\"; }', '/projet/a.cs')
        self.assertFalse(any('Chaîne littérale' in m for m in messages(r)))

    def test_commentaire_ne_compte_pas_les_accolades(self):
        r = analyser('cs', '// {\nclass A { }\n', '/projet/a.cs')
        self.assertFalse(any('accolade' in m.lower() for m in messages(r)))

    def test_compilateur_absent_signale(self):
        with mock.patch.object(V.shutil, 'which', return_value=None):
            r = analyser('cs', 'class A { }', '/projet/a.cs')
        self.assertTrue(any('structurelle' in m for m in messages(r)))

    def test_instruction_sans_point_virgule(self):
        r = analyser('cs', 'class A\n{\n    void M()\n    {\n        int x = 1\n    }\n}',
                     '/projet/a.cs')
        self.assertTrue(any('point-virgule' in m for m in messages(r)))


class RegistreDesLangages(unittest.TestCase):
    def test_résolution_des_alias(self):
        for alias, attendu in (('csharp', 'cs'), ('makefile', 'make'),
                               ('html5', 'html'), ('golang', 'go'),
                               ('yabasic', 'basic'), ('freepascal', 'pascal'),
                               ('md', 'markdown'), ('bash', 'shell')):
            self.assertEqual(langages.resoudre(alias), attendu, alias)

    def test_résolution_des_extensions(self):
        for ext, attendu in (('.cpp', 'cpp'), ('.kt', 'kotlin'), ('.swift', 'swift'),
                             ('.f90', 'fortran'), ('.mli', 'ocaml'), ('.tex', 'latex')):
            self.assertEqual(langages.resoudre(ext), attendu, ext)

    def test_inconnu(self):
        self.assertIsNone(langages.resoudre('langage_inexistant'))
        self.assertIsNone(langages.resoudre(''))
        self.assertIsNone(langages.resoudre(None))

    def test_alias_sans_conflit(self):
        vus = {}
        for identifiant, langage in langages.LANGAGES.items():
            for nom in (identifiant,) + langage.alias:
                self.assertNotIn(nom.lower(), vus,
                                 'alias en conflit : %s' % nom)
                vus[nom.lower()] = identifiant

    def test_extensions_sans_conflit(self):
        vus = {}
        for identifiant, langage in langages.LANGAGES.items():
            for ext in langage.extensions:
                self.assertNotIn(ext, vus, 'extension %s disputée' % ext)
                vus[ext] = identifiant

    def test_tout_langage_a_un_libellé(self):
        for identifiant, langage in langages.LANGAGES.items():
            self.assertTrue(langage.libelle, identifiant)

    def test_débogueurs_valides(self):
        # « esoterique » désigne les moteurs écrits dans langages_esoteriques.py :
        # ce sont des machines à pas natives, donc du débogage réel sans aucun
        # binaire externe à installer.
        admis = {'gdb', 'script', 'php', 'dap', 'visuel', 'instrumente',
                 'esoterique', ''}
        for identifiant, langage in langages.LANGAGES.items():
            self.assertIn(langage.debogueur, admis, identifiant)

    def test_essais_valides(self):
        admis = {'compile', 'interprete', 'graphique', 'non'}
        for identifiant, langage in langages.LANGAGES.items():
            self.assertIn(langage.essai, admis, identifiant)

    def test_langages_graphiques(self):
        graphiques = {i for i in langages.tous() if langages.est_graphique(i)}
        # Piet s'ajoute en 3.8.0 : son programme EST une image PNG.
        # « piet_texte » s'ajoute en 4.3.0 : la source .piett est compilée en PNG
        # et son aperçu est cette image, donc elle est graphique elle aussi.
        # C'est ce qui la tient hors de MODE_AUCUN dans le débogueur.
        self.assertEqual(graphiques, {'html', 'css', 'svg', 'latex', 'markdown',
                                      'xml', 'piet', 'piet_texte'})

    # ------------------------------------------------------------------
    # Les dix langages ésotériques (3.8.0).
    # ------------------------------------------------------------------

    ESOTERIQUES = ('brainfuck', 'whitespace', 'piet', 'lolcode', 'arnoldc',
                   'chef', 'shakespeare', 'intercal', 'fractran', 'malbolge')

    def test_les_dix_langages_esoteriques_sont_enregistres(self):
        for identifiant in self.ESOTERIQUES:
            with self.subTest(identifiant):
                self.assertIsNotNone(langages.langage(identifiant))

    def test_registre_complet(self):
        # Le compte est épinglé volontairement : une suppression accidentelle de
        # langage doit faire échouer la suite. Le nom du test ne porte plus le
        # chiffre, pour qu'un ajout ne change que cette ligne.
        # 39 en 3.8.0 et 3.9.0 ; 40 en 4.0.0 avec l'assembleur ; 41 en 4.3.0 avec
        # la source texte Piet (.piett), entrée distincte de « piet » (.png).
        self.assertEqual(len(langages.tous()), 41)
        self.assertIsNotNone(langages.langage('asm'))

    def test_esoteriques_n_exigent_aucune_installation(self):
        for identifiant in self.ESOTERIQUES:
            langage = langages.langage(identifiant)
            with self.subTest(identifiant):
                # Aucun serveur de langage ni interpréteur externe n'existe pour
                # ces langages : le registre ne doit donc rien promettre à
                # installer et aucune commande d'essai n'est proposée.
                self.assertEqual(langage.lsp, ())
                self.assertEqual(langages.installer_lsp(identifiant), '')
                self.assertEqual(langage.commande_essai, ())

    def test_esoteriques_sont_debogables_en_mode_reel(self):
        import debogueur_universel
        for identifiant in self.ESOTERIQUES:
            capacites = debogueur_universel.capacites(identifiant)
            with self.subTest(identifiant):
                self.assertTrue(capacites['disponible'])
                self.assertTrue(capacites['pas_a_pas'])
                self.assertTrue(capacites['variables'])
                self.assertTrue(capacites['pile'])

    def test_piet_est_graphique_et_les_autres_non(self):
        for identifiant in self.ESOTERIQUES:
            attendu = identifiant == 'piet'
            with self.subTest(identifiant):
                self.assertEqual(langages.est_graphique(identifiant), attendu)
                self.assertEqual(langages.essayable(identifiant),
                                 'graphique' if attendu else 'interprete')

    def test_extensions_des_esoteriques_sont_uniques(self):
        vus = {}
        for identifiant in langages.tous():
            for extension in langages.extensions(identifiant):
                self.assertNotIn(extension, vus,
                                 '%s et %s partagent %s'
                                 % (vus.get(extension), identifiant, extension))
                vus[extension] = identifiant

    def test_chaque_esoterique_a_une_bibliotheque_de_completion(self):
        import bibliotheques_completion
        for identifiant in self.ESOTERIQUES:
            clef = langages.bibliotheque(identifiant)
            with self.subTest(identifiant):
                self.assertEqual(clef, identifiant)
                self.assertTrue(bibliotheques_completion.existe(clef))

    def test_analyse_statique_disponible_pour_les_esoteriques(self):
        import verificateurs_statiques
        for identifiant in self.ESOTERIQUES:
            resultat = verificateurs_statiques.analyze(
                identifiant, '/tmp/x', 'x', '')
            with self.subTest(identifiant):
                # Même sur un document vide l'analyse doit répondre, et non
                # déclarer le langage non pris en charge.
                self.assertNotEqual(resultat.get('state'), 'unsupported')

    def test_tout_vérificateur_désigné_existe(self):
        import importlib
        for identifiant in langages.tous():
            v = langages.verificateur(identifiant)
            if not v:
                continue
            module, fonction = v
            m = importlib.import_module(module)
            self.assertTrue(hasattr(m, fonction),
                            '%s : %s.%s absent' % (identifiant, module, fonction))

    def test_chaque_vérificateur_local_est_dispatché(self):
        for identifiant in ('json', 'xml', 'svg', 'html', 'css', 'markdown',
                            'shell', 'make', 'cmake', 'cs'):
            self.assertIn(identifiant, V.DISPATCH, identifiant)

    def test_etat_dun_langage(self):
        e = langages.etat('python')
        self.assertEqual(e['langage'], 'python')
        self.assertIn('lsp', e)
        self.assertIn('debogueur', e)
        self.assertEqual(e['debogueur'], 'script')

    def test_etat_inconnu(self):
        self.assertIsNone(langages.etat('inexistant')['langage'])

    def test_installation_lsp(self):
        self.assertIn('clangd', langages.installer_lsp('c'))
        self.assertEqual(langages.installer_lsp('plaintext'), '')

    def test_kotlin_reste_sans_analyse_en_direct(self):
        self.assertIsNone(langages.verificateur('kotlin'))
        self.assertIn('JVM', langages.remarque('kotlin'))


class AucuneExécution(unittest.TestCase):
    """Les vérificateurs ne doivent jamais lancer le code analysé."""

    def test_jamais_de_shell(self):
        texte_dangereux = (
            '{"a":1}\n'
        )
        with mock.patch.object(V.subprocess, 'run',
                               side_effect=AssertionError('subprocess.run appelé')):
            for kind in ('json', 'xml', 'svg', 'html', 'css', 'markdown', 'cmake'):
                analyser(kind, texte_dangereux, '/projet/t')

    def test_html_ne_valide_pas_le_script(self):
        r = analyser('html', '<script>rm -rf /</script>')
        self.assertTrue(r['ok'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
