"""Vérificateurs statiques locaux, sans exécution ni installation.

Ces vérificateurs couvrent les langages qui n'avaient aucune analyse en
direct : HTML, CSS, SVG, Markdown, Shell, JSON, XML, Makefile, CMake et C#.
Ils ne lancent jamais le code : ils lisent le texte et signalent ce qui est
structurellement faux. Ils constituent la seconde voie du registre des
langages, celle qui fonctionne sans rien installer ; un serveur de langage,
quand il est présent, reste préféré.

Contrat, identique à celui de scripting.analyze et de live_new_languages.analyze :

    analyze(kind, path, key, content) -> {
        'state': 'ready' | 'unavailable' | 'timeout' | 'unsupported',
        'ok': bool,
        'diagnostics': [{'file','line','column','endLine','endColumn',
                         'severity','message'}, ...],
        'message': str,
        'output': str,
    }

Les colonnes sont exprimées en unités UTF-16, comme partout ailleurs dans
Pascal Studio, parce que l'éditeur est Monaco.

Garde-fous communs : tampon borné à 2 Mo, 100 diagnostics au plus, aucune
commande construite via un shell, délai maximal court pour les rares outils
externes optionnels (bash -n, shellcheck, make --dry-run).
"""

import json
import os
import re
import shutil
import subprocess
from html.parser import HTMLParser
from pathlib import Path
from xml.etree import ElementTree

LIMITE_OCTETS = 2_000_000
LIMITE_DIAGNOSTICS = 100
DELAI_OUTIL = 8

# Éléments HTML qui ne portent jamais de contenu et ne se ferment pas.
VIDES = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link',
         'meta', 'param', 'source', 'track', 'wbr'}
# Éléments dont le contenu brut n'est pas du HTML analysable.
BRUTS = {'script', 'style', 'textarea', 'title'}
# Propriétés CSS courantes. Une propriété absente de cette liste produit un
# avertissement et non une erreur : la liste n'est pas exhaustive.
PROPRIETES_CSS = {
    'align-content', 'align-items', 'align-self', 'all', 'animation',
    'animation-delay', 'animation-direction', 'animation-duration',
    'animation-fill-mode', 'animation-iteration-count', 'animation-name',
    'animation-play-state', 'animation-timing-function', 'appearance',
    'aspect-ratio', 'backdrop-filter', 'backface-visibility', 'background',
    'background-attachment', 'background-blend-mode', 'background-clip',
    'background-color', 'background-image', 'background-origin',
    'background-position', 'background-repeat', 'background-size',
    'border', 'border-bottom', 'border-bottom-color', 'border-bottom-left-radius',
    'border-bottom-right-radius', 'border-bottom-style', 'border-bottom-width',
    'border-collapse', 'border-color', 'border-image', 'border-left',
    'border-radius', 'border-right', 'border-spacing', 'border-style',
    'border-top', 'border-width', 'bottom', 'box-shadow', 'box-sizing',
    'break-after', 'break-before', 'break-inside', 'caption-side', 'caret-color',
    'clear', 'clip', 'clip-path', 'color', 'color-scheme', 'column-count',
    'column-gap', 'column-rule', 'column-width', 'columns', 'contain',
    'content', 'counter-increment', 'counter-reset', 'cursor', 'direction',
    'display', 'empty-cells', 'fill', 'filter', 'flex', 'flex-basis',
    'flex-direction', 'flex-flow', 'flex-grow', 'flex-shrink', 'flex-wrap',
    'float', 'font', 'font-family', 'font-feature-settings', 'font-kerning',
    'font-size', 'font-stretch', 'font-style', 'font-variant',
    'font-variation-settings', 'font-weight', 'gap', 'grid', 'grid-area',
    'grid-auto-columns', 'grid-auto-flow', 'grid-auto-rows', 'grid-column',
    'grid-gap', 'grid-row', 'grid-template', 'grid-template-areas',
    'grid-template-columns', 'grid-template-rows', 'height', 'hyphens',
    'inline-size', 'isolation', 'justify-content', 'justify-items',
    'justify-self', 'left', 'letter-spacing', 'line-break', 'line-height',
    'list-style', 'list-style-image', 'list-style-position', 'list-style-type',
    'margin', 'margin-block', 'margin-bottom', 'margin-inline', 'margin-left',
    'margin-right', 'margin-top', 'mask', 'mask-image', 'max-height',
    'max-inline-size', 'max-width', 'min-block-size', 'min-height',
    'min-inline-size', 'min-width', 'mix-blend-mode', 'object-fit',
    'object-position', 'opacity', 'order', 'orphans', 'outline',
    'outline-color', 'outline-offset', 'outline-style', 'outline-width',
    'overflow', 'overflow-anchor', 'overflow-wrap', 'overflow-x', 'overflow-y',
    'overscroll-behavior', 'padding', 'padding-block', 'padding-bottom',
    'padding-inline', 'padding-left', 'padding-right', 'padding-top',
    'page-break-after', 'page-break-before', 'page-break-inside',
    'paint-order', 'perspective', 'place-content', 'place-items', 'place-self',
    'pointer-events', 'position', 'quotes', 'resize', 'right', 'rotate',
    'row-gap', 'scale', 'scroll-behavior', 'scroll-margin', 'scroll-padding',
    'scroll-snap-align', 'scroll-snap-type', 'shape-outside', 'src',
    'stroke', 'stroke-dasharray', 'stroke-linecap', 'stroke-linejoin',
    'stroke-width', 'tab-size', 'table-layout', 'text-align',
    'text-align-last', 'text-decoration', 'text-decoration-color',
    'text-decoration-line', 'text-decoration-style', 'text-decoration-thickness',
    'text-emphasis', 'text-indent', 'text-justify', 'text-orientation',
    'text-overflow', 'text-rendering', 'text-shadow', 'text-transform',
    'text-underline-offset', 'text-underline-position', 'top', 'touch-action',
    'transform', 'transform-box', 'transform-origin', 'transform-style',
    'transition', 'transition-delay', 'transition-duration',
    'transition-property', 'transition-timing-function', 'translate',
    'unicode-bidi', 'user-select', 'vertical-align', 'view-transition-name',
    'visibility', 'white-space', 'widows', 'width', 'will-change',
    'word-break', 'word-spacing', 'word-wrap', 'writing-mode', 'z-index',
    'zoom',
}
# Variables et at-rules CSS acceptées sans vérification de propriété.
AT_RULES = {'charset', 'import', 'media', 'supports', 'font-face', 'keyframes',
            'page', 'namespace', 'layer', 'container', 'property',
            'counter-style', 'scope', 'starting-style', 'view-transition'}
COMMANDES_CMAKE = {
    'add_compile_definitions', 'add_compile_options', 'add_custom_command',
    'add_custom_target', 'add_definitions', 'add_dependencies', 'add_executable',
    'add_library', 'add_link_options', 'add_subdirectory', 'add_test',
    'build_command', 'build_name', 'cmake_host_system_information',
    'cmake_language', 'cmake_minimum_required', 'cmake_parse_arguments',
    'cmake_path', 'cmake_policy', 'configure_file', 'create_test_sourcelist',
    'define_property', 'enable_language', 'enable_testing', 'endforeach',
    'endfunction', 'endif', 'endmacro', 'endwhile', 'exec_program',
    'execute_process', 'export', 'export_library_dependencies', 'file',
    'find_file', 'find_library', 'find_package', 'find_path', 'find_program',
    'fltk_wrap_ui', 'foreach', 'function', 'get_cmake_property',
    'get_directory_property', 'get_filename_component', 'get_property',
    'get_source_file_property', 'get_target_property', 'get_test_property',
    'if', 'include', 'include_directories', 'include_external_msproject',
    'include_guard', 'include_regular_expression', 'install', 'link_directories',
    'link_libraries', 'list', 'load_cache', 'load_command', 'macro', 'make_directory',
    'mark_as_advanced', 'math', 'message', 'option', 'output_required_files',
    'project', 'qt_wrap_cpp', 'qt_wrap_ui', 'remove', 'remove_definitions',
    'return', 'separate_arguments', 'set', 'set_directory_properties',
    'set_property', 'set_source_files_properties', 'set_target_properties',
    'set_tests_properties', 'site_name', 'source_group', 'string', 'subdir_depends',
    'subdirs', 'target_compile_definitions', 'target_compile_features',
    'target_compile_options', 'target_include_directories', 'target_link_directories',
    'target_link_libraries', 'target_link_options', 'target_precompile_headers',
    'target_sources', 'try_compile', 'try_run', 'unset', 'use_mangled_mesa',
    'variable_requires', 'variable_watch', 'while', 'write_file',
}


# --------------------------------------------------------------------------
# Utilitaires partagés
# --------------------------------------------------------------------------

def utf16col(content, line, column):
    """Convertit une colonne en caractères Python en unités UTF-16.

    Monaco compte en UTF-16 : un caractère hors plan multilingue occupe deux
    unités. Les accents courants n'en occupent qu'une et ne changent donc pas
    la colonne.
    """
    try:
        texte = content.splitlines()[line - 1]
    except IndexError:
        return max(1, column)
    return len(texte[:max(0, column - 1)].encode('utf-16-le')) // 2 + 1


def _diag(key, content, line, column, severity, message, longueur=1):
    ligne = max(1, int(line))
    colonne = max(1, int(column))
    return {'file': key, 'line': ligne, 'column': utf16col(content, ligne, colonne),
            'endLine': ligne, 'endColumn': utf16col(content, ligne, colonne + longueur),
            'severity': severity, 'message': message}


def _pret(key, rows, content, libelle, output=''):
    """Résultat uniforme d'une analyse terminée."""
    rows = rows[:LIMITE_DIAGNOSTICS]
    erreurs = sum(1 for r in rows if r['severity'] == 'error')
    if erreurs:
        message = '%s : %d erreur(s) signalée(s).' % (libelle, erreurs)
    elif rows:
        message = '%s : %d remarque(s), aucune erreur.' % (libelle, len(rows))
    else:
        message = '%s : aucune erreur détectée.' % libelle
    return {'state': 'ready', 'ok': not erreurs, 'diagnostics': rows,
            'message': message, 'output': output or '\n'.join(
                '%s:%d:%d: %s: %s' % (r['file'], r['line'], r['column'],
                                      r['severity'], r['message']) for r in rows)}


def _indisponible(message):
    return {'state': 'unavailable', 'ok': False, 'diagnostics': [],
            'message': message, 'output': ''}


def _non_pris_en_charge(kind):
    return {'state': 'unsupported', 'ok': False, 'diagnostics': [],
            'message': 'Aucune analyse statique locale pour « %s ».' % kind,
            'output': ''}


def _verifier(content):
    """Garde-fou commun : taille du tampon."""
    if not isinstance(content, str):
        raise ValueError('Le contenu doit être du texte.')
    if len(content.encode('utf8')) > LIMITE_OCTETS:
        raise ValueError('Tampon trop volumineux.')


def _lignes(content):
    return content.splitlines()


def _colonne_de(ligne, offset):
    return offset - ligne.rfind('\n', 0, offset)


# --------------------------------------------------------------------------
# JSON
# --------------------------------------------------------------------------

def analyser_json(key, content, path):
    rows = []
    valide = True
    try:
        json.loads(content)
    except json.JSONDecodeError as e:
        valide = False
        rows.append(_diag(key, content, e.lineno, e.colno, 'error',
                          'JSON invalide : %s.' % e.msg))
    if valide:
        rows.extend(_json_clefs_en_double(key, content))
    return _pret(key, rows, content, 'JSON')


def _json_clefs_en_double(key, content):
    """Repère les clefs répétées d'un objet, par profondeur d'accolades.

    Une clef en double n'invalide pas le JSON : la dernière valeur écrase
    simplement les précédentes. C'est presque toujours une faute de frappe.
    """
    rows = []
    # Pile des ensembles de clefs, un par objet ouvert ; les tableaux ne
    # comptent pas leurs clefs mais occupent la pile pour garder la profondeur.
    pile = []
    dans_tableau = False
    index = 0
    n = len(content)
    while index < n:
        caractere = content[index]
        if caractere == '"':
            fin = index + 1
            while fin < n:
                if content[fin] == '\\':
                    fin += 2
                    continue
                if content[fin] == '"':
                    break
                fin += 1
            texte = content[index:fin + 1]
            apres = content[fin + 1:fin + 20].lstrip()
            try:
                clef = json.loads(texte)
            except ValueError:
                clef = None
            if clef is not None and apres.startswith(':') and pile and not dans_tableau:
                vus = pile[-1]
                numero = _ligne_de(content, index)
                colonne = index - content.rfind('\n', 0, index)
                if clef in vus:
                    rows.append(_diag(
                        key, content, numero, colonne + 1, 'warning',
                        'Clef « %s » déjà présente ligne %d : la dernière valeur '
                        'écrase les précédentes.' % (clef, vus[clef]),
                        len(clef) + 2))
                else:
                    vus[clef] = numero
            index = fin + 1
            continue
        if caractere == '{':
            pile.append({})
            dans_tableau = False
        elif caractere == '[':
            pile.append(None)
            dans_tableau = True
        elif caractere in '}]':
            if pile:
                pile.pop()
            dans_tableau = bool(pile) and pile[-1] is None
        index += 1
    return rows


# --------------------------------------------------------------------------
# XML et SVG
# --------------------------------------------------------------------------

def analyser_xml(key, content, path, kind='xml'):
    rows = []
    try:
        ElementTree.fromstring(content)
    except ElementTree.ParseError as e:
        position = getattr(e, 'position', (1, 1)) or (1, 1)
        rows.append(_diag(key, content, position[0], position[1] + 1, 'error',
                          'XML mal formé : %s.' % e.msg))
    if kind == 'svg':
        rows.extend(_svg_specifique(key, content))
    return _pret(key, rows, content, 'SVG' if kind == 'svg' else 'XML')


def _svg_specifique(key, content):
    rows = []
    racine = re.search(r'<svg\b[^>]*>', content)
    if not racine:
        rows.append(_diag(key, content, 1, 1, 'error',
                          'Aucun élément <svg> : un fichier .svg doit en commencer un.'))
        return rows
    if 'xmlns' not in racine.group(0):
        numero = content[:racine.start()].count('\n') + 1
        rows.append(_diag(key, content, numero, 1, 'warning',
                          'Attribut xmlns="http://www.w3.org/2000/svg" absent : '
                          'le fichier ne sera pas reconnu comme SVG hors du '
                          'navigateur.', 4))
    if not re.search(r'\b(viewBox|width|height)\s*=', racine.group(0)):
        numero = content[:racine.start()].count('\n') + 1
        rows.append(_diag(key, content, numero, 1, 'info',
                          'Ni viewBox ni largeur/hauteur : la mise à l’échelle '
                          'sera imprévisible.', 4))
    for m in re.finditer(r'\b(fill|stroke)\s*=\s*"([^"]*)"', content):
        valeur = m.group(2).strip()
        if valeur in ('none', 'currentColor', '') or valeur.startswith('url('):
            continue
        if not re.fullmatch(r'#[0-9a-fA-F]{3}|#[0-9a-fA-F]{6}|#[0-9a-fA-F]{8}'
                            r'|[a-zA-Z]+|rgb\([^)]*\)|rgba\([^)]*\)|hsl\([^)]*\)',
                            valeur):
            numero = content[:m.start()].count('\n') + 1
            rows.append(_diag(key, content, numero, m.start(2) - content.rfind('\n', 0, m.start(2)),
                              'warning', 'Couleur « %s » non reconnue.' % valeur,
                              len(valeur)))
    return rows


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------

class _AnalyseurHtml(HTMLParser):
    """Suit l'imbrication des balises et collecte les anomalies."""

    def __init__(self, key, content):
        super().__init__(convert_charrefs=True)
        self.key = key
        self.content = content
        self.rows = []
        self.pile = []
        self.ids = {}
        self.brut = None

    def _ici(self):
        ligne, colonne = self.getpos()
        return max(1, ligne), max(1, colonne + 1)

    def _ajouter(self, severity, message, longueur=1):
        ligne, colonne = self._ici()
        self.rows.append(_diag(self.key, self.content, ligne, colonne,
                               severity, message, longueur))

    def handle_starttag(self, nom, attrs):
        if nom in VIDES:
            self._attributs(nom, attrs)
            return
        if self.pile and self.pile[-1][0] in BRUTS:
            return
        self._attributs(nom, attrs)
        self.pile.append((nom, self.getpos()))

    def handle_startendtag(self, nom, attrs):
        self._attributs(nom, attrs)

    def _attributs(self, nom, attrs):
        for cle, valeur in attrs:
            if cle == 'id':
                if not valeur:
                    self._ajouter('warning', 'Attribut id vide.', 2)
                elif valeur in self.ids:
                    ligne, colonne = self._ici()
                    self.rows.append(_diag(
                        self.key, self.content, self.ids[valeur][0],
                        self.ids[valeur][1], 'error',
                        'Identifiant « %s » en double : il est déjà utilisé '
                        'ligne %d. Un id doit être unique dans le document.'
                        % (valeur, ligne), len(valeur) + 2))
                else:
                    self.ids[valeur] = self._ici()
            if nom == 'img' and cle == 'src' and valeur:
                self._cible_locale(valeur, 'Image')
        if nom == 'img' and not any(c == 'alt' for c, _ in attrs):
            self._ajouter('warning',
                          '<img> sans attribut alt : inaccessible aux lecteurs '
                          'd’écran. Utilisez alt="" pour une image décorative.', 4)
        if nom == 'a' and not any(c == 'href' for c, _ in attrs):
            self._ajouter('warning', '<a> sans attribut href : ce n’est pas un '
                                     'lien navigable.', 2)
        if nom == 'meta' and any(c == 'charset' for c, _ in attrs) \
                and self.getpos()[0] > 12:
            self._ajouter('info',
                          'La déclaration de jeu de caractères devrait figurer '
                          'dans les premiers octets du document.', 5)

    def _cible_locale(self, valeur, libelle):
        if re.match(r'^(?:[a-z][a-z0-9+.-]*:|#|//|data:|mailto:|tel:)', valeur, re.I):
            return
        cible = (Path(self.path).parent / valeur.split('#')[0].split('?')[0])
        if valeur.split('#')[0] and not cible.exists():
            self._ajouter('warning', '%s introuvable : %s' % (libelle, valeur),
                          len(valeur))

    def handle_endtag(self, nom):
        if nom in VIDES:
            self._ajouter('warning',
                          '</%s> : cet élément ne porte pas de contenu et ne se '
                          'ferme pas.' % nom, len(nom) + 3)
            return
        if not self.pile:
            self._ajouter('error', '</%s> sans balise ouvrante correspondante.' % nom,
                          len(nom) + 3)
            return
        if self.pile[-1][0] == nom:
            self.pile.pop()
            return
        for indice in range(len(self.pile) - 1, -1, -1):
            if self.pile[indice][0] == nom:
                for oublie in self.pile[indice + 1:]:
                    ligne, colonne = oublie[1][0], oublie[1][1] + 1
                    self.rows.append(_diag(
                        self.key, self.content, ligne, colonne, 'error',
                        '<%s> jamais fermé avant </%s>.' % (oublie[0], nom),
                        len(oublie[0]) + 2))
                del self.pile[indice:]
                return
        self._ajouter('error',
                      '</%s> inattendu : aucune balise <%s> n’est ouverte.'
                      % (nom, nom), len(nom) + 3)

    def handle_data(self, donnee):
        if self.pile and self.pile[-1][0] in BRUTS:
            return
        if '\x00' in donnee:
            self._ajouter('error', 'Caractère nul dans le texte.')

    def error(self, message):  # pragma: no cover - HTMLParser n'appelle plus
        self._ajouter('error', message)

    def cloture(self):
        for nom, position in self.pile:
            ligne, colonne = position[0], position[1] + 1
            self.rows.append(_diag(self.key, self.content, ligne, colonne, 'error',
                                   '<%s> jamais fermé.' % nom, len(nom) + 2))
        self.pile = []


def analyser_html(key, content, path):
    analyseur = _AnalyseurHtml(key, content)
    analyseur.path = path
    try:
        analyseur.feed(content)
        analyseur.close()
    except AssertionError as e:
        ligne, colonne = analyseur.getpos()
        analyseur.rows.append(_diag(key, content, ligne, colonne + 1, 'error',
                                    'HTML illisible : %s' % e))
    analyseur.cloture()
    if not analyseur.rows:
        texte = content.lower()
        if '<!doctype' not in texte:
            analyseur.rows.append(_diag(key, content, 1, 1, 'info',
                                        'Aucune déclaration <!DOCTYPE html> : le '
                                        'navigateur passera en mode quirks.', 9))
    return _pret(key, analyseur.rows, content, 'HTML')


# --------------------------------------------------------------------------
# CSS
# --------------------------------------------------------------------------

def analyser_css(key, content, path):
    rows = []
    # Supprimer les commentaires en gardant les positions, pour que les numéros
    # de ligne restent exacts.
    texte = _masquer_commentaires(content, '/*', '*/')
    if content.count('/*') != content.count('*/'):
        numero = _ligne_de(content, content.rfind('/*'))
        rows.append(_diag(key, content, numero, 1, 'error',
                          'Commentaire /* jamais fermé.'))
    profondeur = 0
    debut_bloc = None
    selecteur = ''
    for numero, ligne in enumerate(_lignes(texte), 1):
        for position, caractere in enumerate(ligne, 1):
            if caractere == '{':
                profondeur += 1
                if profondeur == 1:
                    debut_bloc = numero
                    selecteur = _selecteur_avant(texte, numero, position)
                elif profondeur > 6:
                    rows.append(_diag(key, content, numero, position, 'warning',
                                      'Imbrication profonde (%d niveaux) : '
                                      'vérifiez les accolades.' % profondeur))
            elif caractere == '}':
                if profondeur == 0:
                    rows.append(_diag(key, content, numero, position, 'error',
                                      'Accolade fermante sans ouvrante.'))
                else:
                    profondeur -= 1
                    if profondeur == 0:
                        debut_bloc = None
    if profondeur > 0:
        rows.append(_diag(key, content, debut_bloc or 1, 1, 'error',
                          'Bloc « %s » jamais fermé : %d accolade(s) en trop '
                          'ouverte(s).' % (selecteur.strip()[:40] or 'règle',
                                           profondeur)))
    rows.extend(_declarations_css(key, content, texte))
    return _pret(key, rows, content, 'CSS')


def _masquer_commentaires(content, ouvre, ferme):
    resultat = []
    index = 0
    while index < len(content):
        debut = content.find(ouvre, index)
        if debut < 0:
            resultat.append(content[index:])
            break
        fin = content.find(ferme, debut + len(ouvre))
        fin = len(content) if fin < 0 else fin + len(ferme)
        resultat.append(content[index:debut])
        resultat.append(re.sub(r'[^\n]', ' ', content[debut:fin]))
        index = fin
    return ''.join(resultat)


def _ligne_de(content, offset):
    return max(1, content[:max(0, offset)].count('\n') + 1)


def _selecteur_avant(texte, numero, position):
    lignes = _lignes(texte)[:numero]
    if lignes:
        lignes[-1] = lignes[-1][:position - 1]
    return ' '.join(l.strip() for l in lignes[-4:])


def _declarations_css(key, content, texte):
    rows = []
    # Chaque déclaration « propriété: valeur » hors bloc @… sans accolade.
    for m in re.finditer(r'(^|[;{}])\s*([-a-zA-Z_*][-\w]*)\s*:([^;{}]*)', texte):
        tete = m.group(1)
        propriete = m.group(2).strip()
        valeur = m.group(3).strip()
        if tete == '{' and propriete.lower() in AT_RULES:
            continue
        offset = m.start(2)
        numero = _ligne_de(texte, offset)
        ligne = _lignes(content)[numero - 1] if numero <= len(_lignes(content)) else ''
        colonne = ligne.find(propriete) + 1 if propriete in ligne else 1
        basse = propriete.lower()
        if basse.startswith('-'):
            continue                       # préfixes vendeurs, non jugés
        if basse not in PROPRIETES_CSS:
            rows.append(_diag(key, content, numero, colonne, 'warning',
                              'Propriété « %s » inconnue : elle sera ignorée par '
                              'les navigateurs.' % propriete, len(propriete)))
        if valeur == '' and tete != '{':
            rows.append(_diag(key, content, numero, colonne, 'error',
                              'Propriété « %s » sans valeur.' % propriete,
                              len(propriete)))
            continue
        if not _valeur_css_valide(valeur):
            rows.append(_diag(key, content, numero, colonne, 'error',
                              'Valeur « %s » mal formée pour « %s ».'
                              % (valeur[:40], propriete), len(valeur)))
    # Espace entre le nombre et l'unité : « width: 10 px » est invalide, alors
    # que « margin: 0 auto » est correct. On ne vise que les vraies unités.
    for m in re.finditer(r'\b(\d+(?:\.\d+)?)\s+'
                         r'(px|em|rem|vh|vw|vmin|vmax|pt|pc|cm|mm|ex|ch|'
                         r'deg|rad|ms|fr)\b', texte):
        numero = _ligne_de(texte, m.start())
        colonne = m.start(1) - texte.rfind('\n', 0, m.start(1))
        rows.append(_diag(key, content, numero, colonne, 'error',
                          'Espace entre la valeur « %s » et l\'unité « %s » : '
                          'l\'ensemble sera ignoré. Écrivez « %s%s ».'
                          % (m.group(1), m.group(2), m.group(1), m.group(2)),
                          len(m.group(0))))
    # Point-virgule manquant avant une accolade fermante.
    for m in re.finditer(r'([^\s;{}@/])\s*\n\s*\}', texte):
        numero = _ligne_de(texte, m.start(1))
        rows.append(_diag(key, content, numero, 1, 'warning',
                          'Point-virgule manquant en fin de déclaration.'))
    # Règle vide.
    for m in re.finditer(r'\{\s*\}', texte):
        numero = _ligne_de(texte, m.start())
        rows.append(_diag(key, content, numero, 1, 'info',
                          'Règle vide : elle n’a aucun effet.'))
    return rows


def _valeur_css_valide(valeur):
    if valeur.startswith('var(') or 'attr(' in valeur or valeur.startswith('env('):
        return True
    if valeur.count('(') != valeur.count(')'):
        return False
    for m in re.finditer(r'#([0-9a-zA-Z]+)\b', valeur):
        if len(m.group(1)) not in (3, 4, 6, 8):
            return False
        if not re.fullmatch(r'[0-9a-fA-F]+', m.group(1)):
            return False
    for m in re.finditer(r'\b\d+(?:\.\d+)?([a-zA-Z%]+)\b', valeur):
        unite = m.group(1)
        if unite and unite.lower() not in (
                'px', 'em', 'rem', '%', 'vh', 'vw', 'vmin', 'vmax', 'pt', 'pc',
                'in', 'cm', 'mm', 'ex', 'ch', 'deg', 'rad', 'grad', 'turn', 's',
                'ms', 'hz', 'khz', 'dpi', 'dpcm', 'dppx', 'fr', 'lh', 'rlh',
                'svh', 'lvh', 'dvh', 'svw', 'lvw', 'dvw', 'q'):
            return False
    return True


# --------------------------------------------------------------------------
# Markdown
# --------------------------------------------------------------------------

def analyser_markdown(key, content, path):
    rows = []
    lignes = _lignes(content)
    clotures = []
    dans_le_code = False
    titres = {}
    precedent = 0
    for numero, ligne in enumerate(lignes, 1):
        m = re.match(r'^(\s{0,3})(`{3,}|~{3,})\s*([\w+-]*)', ligne)
        if m:
            if not dans_le_code:
                dans_le_code = True
                clotures.append((numero, m.group(2)[0] * 3))
            else:
                dans_le_code = False
                clotures.pop()
            continue
        if dans_le_code:
            continue
        m = re.match(r'^(#{1,6})\s+(.*?)\s*#*\s*$', ligne)
        if m:
            niveau = len(m.group(1))
            texte = m.group(2).strip()
            if precedent and niveau > precedent + 1:
                rows.append(_diag(key, content, numero, 1, 'warning',
                                  'Saute du niveau %d au niveau %d : les '
                                  'lecteurs d’écran et les tables des matières '
                                  's’attendent à une descente progressive.'
                                  % (precedent, niveau)))
            precedent = niveau
            ancre = re.sub(r'[^\w\s-]', '', texte.lower()).strip().replace(' ', '-')
            if ancre in titres:
                rows.append(_diag(key, content, numero, 3, 'info',
                                  'Titre « %s » en double : il produit la même '
                                  'ancre que la ligne %d.' % (texte, titres[ancre]),
                                  len(texte)))
            else:
                titres[ancre] = numero
            continue
        for m in re.finditer(r'!?\[[^\]]*\]\(\s*([^)\s]+)[^)]*\)', ligne):
            cible = m.group(1)
            if re.match(r'^(?:[a-z][a-z0-9+.-]*:|#|//|mailto:|tel:)', cible, re.I):
                continue
            fichier = cible.split('#')[0].split('?')[0]
            if fichier and not (Path(path).parent / fichier).exists():
                rows.append(_diag(key, content, numero,
                                  ligne.find(cible) + 1, 'warning',
                                  'Lien local introuvable : %s' % cible,
                                  len(cible)))
        if re.search(r'\[([^\]]+)\]\s*$', ligne.rstrip()) and '[' in ligne:
            pass  # lien sur plusieurs lignes, non jugé
    if dans_le_code and clotures:
        numero, marque = clotures[0]
        rows.append(_diag(key, content, numero, 1, 'error',
                          'Bloc de code ouvert par %s jamais refermé : tout le '
                          'reste du document est considéré comme du code.'
                          % marque))
    if lignes and lignes[0].strip() and not re.match(r'^(#|<)', lignes[0].strip()):
        premier_titre = next((n for n, l in enumerate(lignes, 1)
                              if re.match(r'^#{1,6}\s', l)), None)
        if premier_titre and premier_titre > 12:
            rows.append(_diag(key, content, premier_titre, 1, 'info',
                              'Le premier titre apparaît ligne %d : un document '
                              'Markdown commence habituellement par son titre.'
                              % premier_titre))
    return _pret(key, rows, content, 'Markdown')


# --------------------------------------------------------------------------
# Shell
# --------------------------------------------------------------------------

def analyser_shell(key, content, path):
    ecrit = _ecrire_temporaire(content, '.sh')
    if ecrit is None:
        return _indisponible('Analyse Shell indisponible : aucun interpréteur trouvé.')
    rows = []
    output = ''
    bash = shutil.which('bash')
    if bash:
        code, output = _lancer([bash, '-n', str(ecrit)])
        if code != 0:
            rows.extend(_analyser_sortie_shell(key, content, output))
    shellcheck = shutil.which('shellcheck')
    if shellcheck:
        code, sortie = _lancer([shellcheck, '--format=gcc', '--severity=style',
                                str(ecrit)])
        rows.extend(_analyser_shellcheck(key, content, sortie))
    elif not bash:
        _effacer(ecrit)
        return _indisponible('Installez Bash : sudo apt install bash.')
    if not rows:
        lignes = _lignes(content)
        if lignes and re.match(r'^#!', lignes[0]) is None:
            rows.append(_diag(key, content, 1, 1, 'info',
                              'Aucune ligne « #!… » : l’interpréteur utilisé '
                              'dépendra de ce qui lance le script.', 2))
        if re.search(r'\brm\s+-rf\s+\$', content):
            rows.append(_diag(key, content, 1, 1, 'warning',
                              '« rm -rf » sur une variable : si la variable est '
                              'vide, la commande supprime le dossier courant.'))
    _effacer(ecrit)
    return _pret(key, rows, content, 'Shell', output)


def _ecrire_temporaire(content, suffixe):
    import tempfile
    try:
        fd, nom = tempfile.mkstemp(prefix='ps-statique-', suffix=suffixe)
        with os.fdopen(fd, 'w', encoding='utf8') as f:
            f.write(content)
        return Path(nom)
    except OSError:
        return None


def _effacer(chemin):
    try:
        Path(chemin).unlink()
    except OSError:
        pass


def _lancer(cmd, entree=None):
    try:
        r = subprocess.run(cmd, input=entree, capture_output=True, text=True,
                           errors='replace', timeout=DELAI_OUTIL,
                           env={**os.environ, 'LC_ALL': 'C.UTF-8', 'TERM': 'dumb'})
    except (subprocess.TimeoutExpired, OSError) as e:
        return 124, str(e)
    return r.returncode, (r.stdout + r.stderr)[-8000:]


def _analyser_sortie_shell(key, content, output):
    rows = []
    for m in re.finditer(r'ligne (\d+)|line (\d+)', output):
        numero = int(m.group(1) or m.group(2))
        detail = re.search(r'(?:erreur de syntaxe|syntax error)[^\n]*', output, re.I)
        rows.append(_diag(key, content, numero, 1, 'error',
                          detail.group(0) if detail else 'Erreur de syntaxe.'))
    if not rows:
        rows.append(_diag(key, content, 1, 1, 'error',
                          output.strip().splitlines()[0] if output.strip()
                          else 'Erreur de syntaxe Shell.'))
    return rows[:3]


def _analyser_shellcheck(key, content, sortie):
    rows = []
    for ligne in sortie.splitlines():
        m = re.match(r'^[^:]+:(\d+):(\d+):\s*(error|warning|note|style):\s*'
                     r'(.*?)(?:\s*\[([A-Z]+\d+)\])?$', ligne)
        if not m:
            continue
        numero, colonne, niveau, message, code = m.groups()
        severity = {'error': 'error', 'warning': 'warning',
                    'note': 'info', 'style': 'hint'}[niveau]
        rows.append(_diag(key, content, int(numero), int(colonne), severity,
                          (message + (' [%s]' % code if code else ''))))
    return rows


# --------------------------------------------------------------------------
# Makefile
# --------------------------------------------------------------------------

def analyser_make(key, content, path):
    rows = []
    lignes = _lignes(content)
    dans_recette = False
    for numero, ligne in enumerate(lignes, 1):
        if re.match(r'^[^\t#\s].*:\s*(?!=)', ligne) and not ligne.startswith('\t'):
            dans_recette = True
            continue
        if ligne.strip() == '' or re.match(r'^[^\t#\s]', ligne):
            if not ligne.startswith('\t'):
                dans_recette = False
        if dans_recette and ligne.strip() and not ligne.startswith('\t'):
            if ligne.startswith(' ') and not re.match(r'^\s*(ifeq|ifneq|ifdef|'
                                                      r'ifndef|else|endif|'
                                                      r'define|endef|include|'
                                                      r'-include|export|unexport|'
                                                      r'override|vpath)\b', ligne):
                rows.append(_diag(key, content, numero, 1, 'error',
                                  'Ligne de recette indentée avec des espaces : '
                                  'make exige une tabulation. Erreur classique '
                                  '« missing separator ».', 2))
        if ligne.startswith('\t') and not dans_recette:
            rows.append(_diag(key, content, numero, 1, 'error',
                              'Tabulation hors de toute recette : make attend '
                              'ici une règle ou une affectation.', 2))
    if re.search(r'\$\((?![\w)]*\))', content):
        rows.append(_diag(key, content, 1, 1, 'warning',
                          'Référence de variable « $( » jamais fermée.'))
    for m in re.finditer(r'\$[({]([A-Za-z_][\w.-]*)[)}]', content):
        nom = m.group(1)
        if nom in ('MAKE', 'MAKEFLAGS', 'MAKEFILE_LIST', 'CURDIR', 'SHELL',
                   'VPATH', 'AR', 'AS', 'CC', 'CXX', 'CPP', 'RM', 'LD',
                   'CFLAGS', 'CXXFLAGS', 'CPPFLAGS', 'LDFLAGS', 'LDLIBS',
                   'TARGET_ARCH', 'PREFIX', 'DESTDIR', 'SOURCES', 'OBJECTS',
                   'DEPS', 'EXEC', 'BIN', 'BUILD', 'SRC', 'OUT', 'VERSION'):
            continue
        if not re.search(r'^\s*%s\s*[:?+]?=' % re.escape(nom), content, re.M) \
                and 'export %s' % nom not in content:
            numero = _ligne_de(content, m.start())
            rows.append(_diag(key, content, numero, 1, 'warning',
                              'Variable « %s » utilisée mais jamais affectée : '
                              'elle se développera en texte vide.' % nom,
                              len(nom) + 3))
    make = shutil.which('make')
    output = ''
    if make and Path(path).is_file():
        code, output = _lancer([make, '--dry-run', '--no-print-directory',
                                '--always-make', '-f', str(path)],
                               )
        if code != 0:
            for m in re.finditer(r'[^:\s]+:(\d+):\s*\*\*\*\s*(.*)', output):
                rows.append(_diag(key, content, int(m.group(1)), 1, 'error',
                                  m.group(2).strip()))
    return _pret(key, rows, content, 'Makefile', output)


# --------------------------------------------------------------------------
# CMake
# --------------------------------------------------------------------------

def analyser_cmake(key, content, path):
    rows = []
    texte = _commentaires_cmake(content)
    profondeur = 0
    debut = None
    commande = ''
    for numero, ligne in enumerate(_lignes(texte), 1):
        for position, caractere in enumerate(ligne, 1):
            if caractere == '(':
                if profondeur == 0:
                    debut = (numero, position)
                    commande = _commande_avant(ligne, position)
                profondeur += 1
            elif caractere == ')':
                profondeur -= 1
                if profondeur < 0:
                    rows.append(_diag(key, content, numero, position, 'error',
                                      'Parenthèse fermante sans ouvrante.'))
                    profondeur = 0
                elif profondeur == 0 and debut:
                    debut = None
    if profondeur > 0 and debut:
        rows.append(_diag(key, content, debut[0], debut[1], 'error',
                          'Appel « %s » jamais fermé : %d parenthèse(s) en trop.'
                          % (commande or 'commande', profondeur),
                          len(commande) + 2))
    for m in re.finditer(r'(?m)^\s*([A-Za-z_][\w]*)\s*\(', texte):
        nom = m.group(1)
        # CMake est insensible à la casse : PROJECT et project sont la même
        # commande. Une commande inconnue est signalée quelle que soit sa casse.
        if nom.lower() in COMMANDES_CMAKE:
            continue
        if nom.lower() == 'else' or nom.lower().startswith(('else', 'elseif')):
            continue
        numero = _ligne_de(texte, m.start())
        rows.append(_diag(key, content, numero, m.start(1) - texte.rfind('\n', 0, m.start(1)),
                          'warning', 'Commande CMake « %s » inconnue.' % nom,
                          len(nom)))
    if not re.search(r'(?im)^\s*cmake_minimum_required\s*\(', texte):
        rows.append(_diag(key, content, 1, 1, 'info',
                          'Pas de cmake_minimum_required() : la politique de '
                          'compatibilité dépendra de la version de CMake.'))
    for m in re.finditer(r'\$\{(\w+)\}', texte):
        nom = m.group(1)
        if nom in ('CMAKE_SOURCE_DIR', 'CMAKE_BINARY_DIR', 'CMAKE_CURRENT_SOURCE_DIR',
                   'CMAKE_CURRENT_BINARY_DIR', 'PROJECT_NAME', 'PROJECT_SOURCE_DIR',
                   'PROJECT_BINARY_DIR', 'CMAKE_VERSION', 'CMAKE_SYSTEM_NAME',
                   'CMAKE_BUILD_TYPE', 'CMAKE_CXX_COMPILER', 'CMAKE_C_COMPILER',
                   'CMAKE_INSTALL_PREFIX', 'CMAKE_MODULE_PATH', 'ARGN',
                   'CMAKE_CURRENT_LIST_DIR', 'CMAKE_CURRENT_LIST_FILE'):
            continue
        if not re.search(r'\b(?:set|option|foreach|function|macro)\s*\(\s*%s\b'
                         % re.escape(nom), texte, re.I) \
                and not re.search(r'\bfind_package\s*\([^)]*\b%s\b' % re.escape(nom),
                                  texte, re.I):
            numero = _ligne_de(texte, m.start())
            rows.append(_diag(key, content, numero, 1, 'warning',
                              'Variable « %s » utilisée mais jamais définie.' % nom,
                              len(nom) + 3))
    return _pret(key, rows, content, 'CMake')


def _commentaires_cmake(content):
    return re.sub(r'(?m)#.*$', lambda m: ' ' * len(m.group(0)), content)


def _commande_avant(ligne, position):
    avant = ligne[:position - 1].strip()
    m = re.search(r'([A-Za-z_][\w]*)$', avant)
    return m.group(1) if m else ''


# --------------------------------------------------------------------------
# C# : analyse structurelle, sans compilateur
# --------------------------------------------------------------------------

MOTS_CLEFS_CS = {
    'abstract', 'as', 'base', 'bool', 'break', 'byte', 'case', 'catch', 'char',
    'checked', 'class', 'const', 'continue', 'decimal', 'default', 'delegate',
    'do', 'double', 'else', 'enum', 'event', 'explicit', 'extern', 'false',
    'finally', 'fixed', 'float', 'for', 'foreach', 'goto', 'if', 'implicit',
    'in', 'int', 'interface', 'internal', 'is', 'lock', 'long', 'namespace',
    'new', 'null', 'object', 'operator', 'out', 'override', 'params', 'private',
    'protected', 'public', 'readonly', 'record', 'ref', 'return', 'sbyte',
    'sealed', 'short', 'sizeof', 'stackalloc', 'static', 'string', 'struct',
    'switch', 'this', 'throw', 'true', 'try', 'typeof', 'uint', 'ulong',
    'unchecked', 'unsafe', 'ushort', 'using', 'var', 'virtual', 'void',
    'volatile', 'while', 'yield',
}


def analyser_cs(key, content, path):
    rows = []
    texte = _masquer_chaines_cs(content)
    profondeur = 0
    debut = None
    for numero, ligne in enumerate(_lignes(texte), 1):
        for position, caractere in enumerate(ligne, 1):
            if caractere == '{':
                if profondeur == 0:
                    debut = numero
                profondeur += 1
            elif caractere == '}':
                profondeur -= 1
                if profondeur < 0:
                    rows.append(_diag(key, content, numero, position, 'error',
                                      'Accolade fermante sans ouvrante.'))
                    profondeur = 0
                elif profondeur == 0:
                    debut = None
    if profondeur > 0:
        rows.append(_diag(key, content, debut or 1, 1, 'error',
                          '%d accolade(s) ouverte(s) jamais refermée(s).' % profondeur))
    # Chaîne littérale non terminée : nombre impair de guillemets non échappés
    # sur une ligne qui n'ouvre ni chaîne verbatim (@") ni chaîne brute (\"\"\").
    for numero, ligne in enumerate(_lignes(content), 1):
        if '@"' in ligne or '"""' in ligne:
            continue
        non_echappes = len(re.findall(r'(?<!\\)"', ligne))
        if non_echappes % 2 == 1:
            rows.append(_diag(key, content, numero, ligne.rfind('"') + 1,
                              'error', 'Chaîne littérale jamais fermée sur cette '
                                       'ligne : un guillemet manque.', 1))
    # Points-virgules oubliés sur les instructions simples.
    for numero, ligne in enumerate(_lignes(_masquer_commentaires(content, '//', '\n')), 1):
        propre = ligne.strip()
        if not propre or propre.startswith(('//', '/*', '*', '#', '[')):
            continue
        if propre.endswith(('{', '}', ';', ':', ',', ')')) or propre.endswith('=>'):
            continue
        if re.match(r'^(using|namespace|public|private|protected|internal|static|'
                    r'abstract|sealed|partial|class|struct|interface|enum|record|'
                    r'if|else|for|foreach|while|do|switch|case|try|catch|finally|'
                    r'lock|get|set|add|remove|async|extern|unsafe|return\b.*)\b',
                    propre):
            continue
        if re.match(r'^[A-Za-z_][\w.<>\[\]]*\s+\w+\s*=', propre) and not propre.endswith(';'):
            rows.append(_diag(key, content, numero, len(ligne) - len(ligne.lstrip()) + 1,
                              'warning', 'Instruction probablement sans '
                                         'point-virgule final.'))
    csc = shutil.which('csc') or shutil.which('mcs')
    output = ''
    if csc:
        ecrit = _ecrire_temporaire(content, '.cs')
        if ecrit is not None:
            code, output = _lancer([csc, '-target:library', '-nologo',
                                    '-out:/dev/null', str(ecrit)])
            for m in re.finditer(r'[^\s(]+\((\d+),(\d+)\):\s*(error|warning)\s+'
                                 r'([A-Z]+\d+):\s*(.*)', output):
                rows.append(_diag(key, content, int(m.group(1)), int(m.group(2)),
                                  'error' if m.group(3) == 'error' else 'warning',
                                  '%s : %s' % (m.group(4), m.group(5).strip())))
            _effacer(ecrit)
    elif not rows:
        rows.append(_diag(key, content, 1, 1, 'info',
                          'Analyse structurelle seulement : aucun compilateur C# '
                          '(csc, mcs) n’est installé. Les erreurs de type '
                          'n’apparaîtront qu’avec dotnet build.'))
    return _pret(key, rows, content, 'C#', output)


def _masquer_chaines_cs(content):
    """Remplace le contenu des chaînes et des commentaires par des espaces."""
    resultat = []
    index = 0
    n = len(content)
    while index < n:
        caractere = content[index]
        if content.startswith('//', index):
            fin = content.find('\n', index)
            fin = n if fin < 0 else fin
            resultat.append(re.sub(r'[^\n]', ' ', content[index:fin]))
            index = fin
        elif content.startswith('/*', index):
            fin = content.find('*/', index + 2)
            fin = n if fin < 0 else fin + 2
            resultat.append(re.sub(r'[^\n]', ' ', content[index:fin]))
            index = fin
        elif caractere == '@' and index + 1 < n and content[index + 1] == '"':
            fin = index + 2
            while fin < n:
                if content[fin] == '"':
                    if fin + 1 < n and content[fin + 1] == '"':
                        fin += 2
                        continue
                    break
                fin += 1
            fin = min(n, fin + 1)
            resultat.append(re.sub(r'[^\n]', ' ', content[index:fin]))
            index = fin
        elif caractere == '"':
            fin = index + 1
            while fin < n:
                if content[fin] == '\\':
                    fin += 2
                    continue
                if content[fin] == '"' or content[fin] == '\n':
                    break
                fin += 1
            fin = min(n, fin + 1)
            resultat.append(' ' * (fin - index))
            index = fin
        elif caractere == "'":
            fin = index + 1
            while fin < n and content[fin] not in ("'\n"):
                fin += 2 if content[fin] == '\\' else 1
            fin = min(n, fin + 1)
            resultat.append(' ' * (fin - index))
            index = fin
        else:
            resultat.append(caractere)
            index += 1
    return ''.join(resultat)


# --------------------------------------------------------------------------
# Point d'entrée
# --------------------------------------------------------------------------

ESOTERIQUES = frozenset((
    'brainfuck', 'whitespace', 'piet', 'lolcode', 'arnoldc', 'chef',
    'shakespeare', 'intercal', 'fractran', 'malbolge',
))


def analyser_esoterique(key, content, path, identifiant):
    """Analyse statique d'un langage ésotérique.

    Aucun de ces langages n'est empaqueté pour Debian 13 : l'analyse s'appuie sur
    les moteurs écrits dans langages_esoteriques.py, qui chargent le programme
    SANS l'exécuter. C'est ce qui permet de signaler les erreurs en direct
    pendant la frappe, comme pour les autres langages.
    """
    try:
        import langages_esoteriques
    except ImportError:
        return _indisponible('Module langages_esoteriques introuvable.')
    if identifiant == 'piet' and not content.strip():
        # Le programme Piet EST une image : l'éditeur texte n'a rien à analyser.
        return _pret(key, [_diag(key, content, 1, 1, 'info',
                                 'Un programme Piet est une image PNG : '
                                 'utilisez l\'aperçu et l\'inspecteur visuel.',
                                 1)], content, 'Piet')
    libelle = identifiant.capitalize()
    try:
        import langages
        langage_ = langages.langage(identifiant)
        if langage_:
            libelle = langage_.libelle
    except ImportError:
        pass
    diagnostics = langages_esoteriques.analyser(content, identifiant, chemin=path)
    rows = [_diag(key, content, d.get('line', 1), d.get('column', 1),
                  d.get('severity', 'error'), d.get('message', ''), 1)
            for d in diagnostics]
    return _pret(key, rows, content, libelle)


def analyser_asm(key, content, path):
    """Analyse statique d'un source assembleur x86-64.

    Déléguée à assembleur.py, qui commence par reconnaître la SYNTAXE — AT&T
    pour « as », Intel pour nasm — parce que les deux ne se mélangent pas et que
    cette confusion est la première cause d'échec d'assemblage. Les colonnes
    passent par _diag pour la conversion UTF-16 qu'attend Monaco, exactement
    comme pour les autres analyseurs : un analyseur qui rend des colonnes brutes
    décale les soulignements dès qu'une ligne contient un caractère non latin.

    Les mnémoniques absents de la table locale produisent une REMARQUE et non une
    erreur : x86-64 compte des milliers d'instructions et la table n'en couvre
    qu'un sous-ensemble. Accuser à tort du code valide ferait cesser de lire
    l'analyseur, ce qui serait pire que de ne rien dire.
    """
    try:
        import assembleur
    except ImportError:
        return _indisponible('Module assembleur introuvable.')
    resultat = assembleur.analyser(content, path, cle=key)
    if resultat.get('state') != 'ready':
        return _indisponible(resultat.get('message') or 'Analyse impossible.')
    rows = [_diag(key, content, d.get('line', 1), d.get('column', 1),
                  d.get('severity', 'error'), d.get('message', ''), 1)
            for d in resultat.get('diagnostics', [])]
    syntaxe = assembleur.LIBELLES_SYNTAXE.get(resultat.get('syntaxe'), '')
    libelle = ('Assembleur ' + syntaxe).strip() if syntaxe else 'Assembleur'
    return _pret(key, rows, content, libelle, resultat.get('output', ''))


def analyser_piet_texte(key, content, path):
    """Analyse statique d'une source Piet texte (.piett), ajout 4.3.0.

    Déléguée à piet_texte.decoder(), qui NE LÈVE JAMAIS et rend des diagnostics
    avec ligne et colonne : une couleur inconnue est donc signalée pendant la
    frappe, comme pour les autres langages. Le PNG n'est pas recompilé ici —
    l'analyse porte sur la source, qui est ce que l'utilisateur écrit. Un
    programme valide reçoit une remarque de structure (nombre de blocs, taille
    du codel) : dire « aucune erreur » sans rien montrer laisse douter que
    l'analyseur ait vraiment lu le fichier.
    """
    try:
        import piet_texte
    except ImportError:
        return _indisponible('Module piet_texte introuvable.')
    resultat = piet_texte.decoder(content)
    libelle = 'Piet (source texte)'
    rows = [_diag(key, content, d.get('line') or 1, d.get('column') or 1,
                  d.get('severity', 'error'), d.get('message', ''), 1)
            for d in resultat.get('diagnostics', [])]
    if resultat.get('ok'):
        structure = piet_texte.analyser(content)
        rows.append(_diag(key, content, 1, 1, 'info',
                          '%d bloc(s) de couleur, codel de %s px, grille de '
                          '%s × %s : la source se compile en PNG.' % (
                              structure.get('nombre_blocs', 0),
                              resultat.get('codel', 1),
                              resultat.get('largeur', 0),
                              resultat.get('hauteur', 0)), 1))
    return _pret(key, rows, content, libelle)


DISPATCH = {
    'piet_texte': analyser_piet_texte,
    'asm': analyser_asm,
    'json': analyser_json,
    'xml': analyser_xml,
    'svg': analyser_xml,
    'html': analyser_html,
    'css': analyser_css,
    'markdown': analyser_markdown,
    'shell': analyser_shell,
    'make': analyser_make,
    'cmake': analyser_cmake,
    'cs': analyser_cs,
}


def analyze(kind, path, key, content):
    """Analyse statique locale. Même contrat que scripting.analyze."""
    _verifier(content)
    try:
        import langages
        identifiant = langages.resoudre(kind) or kind
    except ImportError:
        identifiant = kind
    if identifiant in ESOTERIQUES:
        return analyser_esoterique(key, content, path, identifiant)
    fonction = DISPATCH.get(identifiant)
    if fonction is None:
        return _non_pris_en_charge(identifiant)
    if identifiant == 'xml':
        return fonction(key, content, path, 'xml')
    if identifiant == 'svg':
        return fonction(key, content, path, 'svg')
    return fonction(key, content, path)
