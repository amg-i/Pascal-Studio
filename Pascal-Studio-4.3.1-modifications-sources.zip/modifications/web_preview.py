"""Local-only, separate-origin HTML/CSS preview and opt-in PHP server.

These servers are development tools, not sandboxes. PHP code runs with the user's
rights. A random cookie and loopback-only bind avoid casual external access.
"""
import html, http.cookies, json, mimetypes, os, secrets, shutil, socket, subprocess, threading, time, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

CSS_PAGE='''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Aperçu CSS</title><link rel="stylesheet" href="{href}"></head><body><header><h1>Aperçu de la feuille de style</h1><nav><a href="#contenu">Navigation</a> <a href="#formulaire">Formulaire</a></nav></header><main id="contenu"><h2>Un titre de section</h2><p>Voici un paragraphe avec <strong>du texte important</strong>, <em>du texte accentué</em> et <a href="#contenu">un lien</a>.</p><div class="card"><h3>Carte d’exemple</h3><p>Les classes propres à votre projet apparaissent seulement si elles sont utilisées dans ce document.</p><button type="button">Un bouton</button></div><ul><li>Premier élément</li><li>Second élément</li></ul><form id="formulaire"><label>Nom <input placeholder="Votre nom"></label><button type="button">Envoyer</button></form></main><footer>Pied de page</footer></body></html>'''

PIET_PAGE='''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Programme Piet</title><style>html,body{{margin:0;background:#1e1e2e;color:#cdd6f4;font:13px/1.55 system-ui,sans-serif}}header{{padding:8px 12px;border-bottom:1px solid #45475a;background:#181825}}header b{{color:#f9e2af}}main{{padding:14px;overflow:auto}}img#__ps_piet_image{{image-rendering:pixelated;display:block;background:#fff;border:1px solid #45475a}}</style></head><body><header><b>Programme Piet</b> — {nom} · chaque bloc de couleur est une instruction : survolez-les pour lire leur teinte, et lancez le pas à pas pour voir le bloc actif se déplacer.</header><main><img id="__ps_piet_image" src="{href}" alt="Programme Piet"></main></body></html>'''

# Stored outside the project. The token is supplied through the environment,
# not interpolated in PHP source or passed on its command line.
PHP_ROUTER=r'''<?php
$token = getenv('PS_PREVIEW_TOKEN'); $port = getenv('PS_PREVIEW_PORT');
$host = $_SERVER['HTTP_HOST'] ?? '';
if ($host !== '127.0.0.1:' . $port && $host !== 'localhost:' . $port) { http_response_code(403); exit('Hôte interdit'); }
$uri = $_SERVER['REQUEST_URI'] ?? '/'; $path = parse_url($uri, PHP_URL_PATH) ?: '/';
$auth = '/__ps_auth/' . $token . '/';
if (str_starts_with($path, $auth)) {
 setcookie('__ps_preview', $token, ['path'=>'/', 'httponly'=>true, 'samesite'=>'Strict']);
 $next = '/' . substr($path, strlen($auth));
 if (str_starts_with($next, '//')) { http_response_code(400); exit; }
 if (!empty($_SERVER['QUERY_STRING'])) $next .= '?' . $_SERVER['QUERY_STRING'];
 header('Cache-Control: no-store'); header('Location: ' . $next, true, 302); exit;
}
if (!isset($_COOKIE['__ps_preview']) || !hash_equals($token, $_COOKIE['__ps_preview'])) { http_response_code(403); exit('Aperçu non autorisé'); }
$decoded = rawurldecode($path);
if (strpos($decoded, "\0") !== false || strpos($decoded, '\\') !== false) { http_response_code(403); exit; }
foreach (explode('/', $decoded) as $part) { if ($part === '..' || (strlen($part)>0 && $part[0]==='.')) { http_response_code(403); exit; } }
$root = realpath(getenv('PS_PREVIEW_ROOT')); $candidate = $root . '/' . ltrim($decoded, '/');
$probe = $candidate;
while (!file_exists($probe) && dirname($probe) !== $probe) $probe = dirname($probe);
$real = realpath($probe);
if ($real === false || ($real !== $root && !str_starts_with($real, $root . DIRECTORY_SEPARATOR))) { http_response_code(403); exit; }
header('X-Content-Type-Options: nosniff');
return false;
'''

class Preview:
 def __init__(self,cache):self.cache=Path(cache);self.lock=threading.RLock();self.server=None;self.thread=None;self.proc=None;self.port=None;self.kind=None;self.inspecteur=None;self._piet_cache={}
 def stop(self):
  with self.lock:
   srv,p=self.server,self.proc;self.server=self.proc=None;self.port=self.kind=None
   if srv:srv.shutdown();srv.server_close()
   if p and p.poll() is None:
    p.terminate()
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:p.kill();p.wait()
 def start(self,workspace,path,mode=None):
  path=Path(path).resolve();workspace=Path(workspace).resolve()
  suffixe=path.suffix.lower()
  # Un programme Piet EST un PNG : il est accepté, mais seulement s'il est
  # reconnu comme tel (voir _est_piet_chemin). Sans cette condition, n'importe
  # quelle photo du projet pourrait être publiée dans la page Piet.
  if not path.is_file() or (suffixe not in ('.html','.htm','.css','.php','.svg','.xml')
     and not (suffixe=='.png' and self._est_piet_chemin(path))):
   raise ValueError('Choisissez un fichier HTML, CSS, SVG, XML, PHP ou un programme Piet (.png).')
  mode=mode or ('php' if path.suffix.lower()=='.php' else 'static')
  if mode not in ('php','static'):raise ValueError('Mode de serveur invalide.')
  if path.suffix.lower()=='.php' and mode!='php':raise ValueError('PHP nécessite son serveur local.')
  root=workspace if path.is_relative_to(workspace) else path.parent
  # Never serve hidden files, including project metadata and credentials.
  rel=path.relative_to(root)
  if any(x.startswith('.') for x in rel.parts):raise ValueError('Un fichier caché ne peut pas être publié dans l’aperçu.')
  token=secrets.token_urlsafe(32)
  with self.lock:
   self.stop()
   # Un nouvel aperçu repart d'un journal vide. Sans cela, les messages de la
   # page précédente resteraient mélangés à ceux de la nouvelle, et une erreur
   # déjà résolue serait attribuée à la page qu'on vient d'ouvrir. L'échec est
   # avalé : le journal dev web est un confort, il ne doit jamais empêcher un
   # aperçu de démarrer.
   try:
    import devweb
    devweb.journal_vider('Aperçu démarré : '+rel.as_posix())
   except Exception:pass
   if mode=='static': self._static(root,token,rel)
   else: self._php(root,token)
   quoted=urllib.parse.quote(rel.as_posix(),safe='/')
   if path.suffix.lower()=='.css' and mode=='static':quoted='__ps_css_demo'
   if path.suffix.lower()=='.png' and mode=='static' and self._est_piet(root,rel):quoted='__ps_piet_demo'
   return {'url':f'http://127.0.0.1:{self.port}/__ps_auth/{token}/{quoted}','mode':mode,'port':self.port,'root':str(root),'path':str(path)}
 def _est_piet(self,root,selected):
  """Même verdict que _est_piet_chemin, à partir du dossier et du chemin relatif."""
  return self._est_piet_chemin((Path(root)/selected).resolve())
 def _est_piet_chemin(self,chemin):
  """Un .png n'est un programme Piet que s'il se découpe en blocs de la palette.

  Deux conditions : au moins un bloc de couleur, et AUCUNE couleur hors des 20
  couleurs de Piet. La seconde est ce qui distingue un programme d'une photo ou
  d'une icône qui contiendrait par hasard un rouge pur : une telle image serait
  couverte d'avertissements « couleur hors palette » et n'a rien à faire dans la
  page Piet. Le verdict est mis en cache par
  (chemin, taille, date de modification) : décoder un PNG n'est pas gratuit et
  l'aperçu est relancé à chaque sélection de fichier.
  """
  chemin=Path(chemin)
  try:etat=chemin.stat()
  except OSError:return False
  if etat.st_size>4_000_000:return False
  clef=(str(chemin),etat.st_size,etat.st_mtime)
  if clef in self._piet_cache:return self._piet_cache[clef]
  verdict=False
  try:
   import base64,langages_esoteriques
   uri='data:image/png;base64,'+base64.b64encode(chemin.read_bytes()).decode('ascii')
   moteur=langages_esoteriques.Piet(uri)
   moteur.charger()
   verdict=bool(moteur.blocs) and not moteur.couleurs_inconnues()
  except Exception:verdict=False
  if len(self._piet_cache)>64:self._piet_cache.clear()
  self._piet_cache[clef]=verdict
  return verdict
 def inspection(self,root,selected):
  """Le chemin, le langage, le contenu et les diagnostics à inspecter.

  server.py peut brancher self.inspecteur sur l'analyse en direct, pour que
  l'aperçu reflète le tampon en cours d'édition et non le seul fichier enregistré.
  """
  chemin=(Path(root)/selected).resolve()
  import langages
  kind=langages.resoudre(chemin.suffix.lower()) or 'plaintext'
  contenu='';diagnostics=[];supplement=()
  if self.inspecteur:
   # L'inspecteur branché par server.py rend (contenu, diagnostics), et une
   # valeur de plus pour Piet : le bloc de couleur en cours d'exécution. Le
   # supplément est transmis tel quel à inspecteur_visuel.donnees_json().
   try:
    reponse=tuple(self.inspecteur(str(chemin)))
    contenu,diagnostics=reponse[0],reponse[1];supplement=reponse[2:]
   except Exception:contenu='';diagnostics=[];supplement=()
  if not isinstance(contenu,str) or not contenu:
   contenu=self._lire_repli(chemin,kind)
  return (kind,str(chemin),contenu,diagnostics)+supplement
 def _lire_repli(self,chemin,kind):
  """Le contenu à inspecter quand server.py n'a branché aucun inspecteur.

  C'est le cas tant qu'aucun projet n'est ouvert : l'aperçu fonctionne, il se
  débrouille seul. Le repli ordinaire est une lecture en texte, mais elle est
  INTERDITE pour Piet : son programme est un PNG, et read_text(..., 'replace')
  remplace les octets invalides, donc l'image — l'inspecteur ne verrait plus
  aucun bloc de couleur. Les octets sont portés en data URI, exactement comme
  le fait contenu_binaire() dans server.py.
  """
  try:
   if kind=='piet':
    import base64
    return 'data:image/png;base64,'+base64.b64encode(chemin.read_bytes()).decode('ascii')
   return chemin.read_text('utf8','replace')
  except OSError:return ''
 def _static(self,root,token,selected):
  # Dans H, « self » désigne le gestionnaire de requête : l'instance Preview
  # doit être capturée explicitement pour accéder à inspection().
  apercu=self
  class H(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_GET(self):self.handle_it(False)
   def do_HEAD(self):self.handle_it(True)
   def do_POST(self):self.capture()
   def capture(self):
    # Collecte du journal dev web : le script injecté dans la page aperçue
    # envoie ses lots ici, sur l'origine de l'aperçu (adresse relative, jamais
    # une adresse absolue construite côté Python). Les trois gardes sont celles
    # déjà appliquées pour servir un fichier : sans le cookie d'aperçu, tout
    # processus de la machine pourrait remplir le journal de l'utilisateur.
    if self.headers.get('Host') not in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'):
     self.send_error(403);return
    if urllib.parse.urlsplit(self.path).path!='/__ps_devweb_capture':self.send_error(404);return
    c=http.cookies.SimpleCookie()
    try:c.load(self.headers.get('Cookie',''))
    except http.cookies.CookieError:pass
    if '__ps_preview' not in c or not secrets.compare_digest(c['__ps_preview'].value,token):self.send_error(403);return
    try:longueur=int(self.headers.get('Content-Length') or 0)
    except ValueError:longueur=0
    if longueur<=0:self.send_error(411,'Longueur manquante');return
    if longueur>200_000:self.send_error(413,'Lot trop volumineux');return
    try:corps=self.rfile.read(longueur)
    except OSError:self.send_error(400);return
    # Une page qui produit du journal ne doit jamais voir sa propre collecte
    # casser son affichage : l'échec est rendu en JSON, pas levé.
    try:
     import devweb
     resultat=devweb.capturer(corps)
    except Exception as exc:resultat={'acceptees':0,'refusees':0,'total':0,'erreur':str(exc)}
    data=json.dumps(resultat).encode('utf8')
    self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(data)));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(data)
   def handle_it(self,head):
    if self.headers.get('Host') not in (f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'):
     self.send_error(403);return
    raw=urllib.parse.urlsplit(self.path);prefix='/__ps_auth/'+token+'/'
    if raw.path.startswith(prefix):
     location='/'+raw.path[len(prefix):]
     if raw.query:location+='?'+raw.query
     if location.startswith('//') or '\r' in location or '\n' in location:self.send_error(400);return
     self.send_response(302);self.send_header('Set-Cookie','__ps_preview='+token+'; HttpOnly; SameSite=Strict; Path=/');self.send_header('Location',location);self.send_header('Cache-Control','no-store');self.end_headers();return
    c=http.cookies.SimpleCookie()
    try:c.load(self.headers.get('Cookie',''))
    except http.cookies.CookieError:pass
    if '__ps_preview' not in c or not secrets.compare_digest(c['__ps_preview'].value,token):self.send_error(403);return
    if raw.path=='/__ps_inspecteur_js':
     import inspecteur_visuel
     self.reply(inspecteur_visuel.SCRIPT.encode('utf8'),'application/javascript; charset=utf-8',head);return
    if raw.path=='/__ps_inspecteur_css':
     import inspecteur_visuel
     self.reply(inspecteur_visuel.STYLE.encode('utf8'),'text/css; charset=utf-8',head);return
    if raw.path=='/__ps_inspecteur_data':
     import inspecteur_visuel
     self.reply(inspecteur_visuel.donnees_json(*(apercu.inspection(root,selected))).encode('utf8'),'application/json; charset=utf-8',head);return
    if raw.path=='/__ps_css_demo':
     import inspecteur_visuel
     href='/'+urllib.parse.quote(selected.as_posix(),safe='/');data=CSS_PAGE.format(href=html.escape(href,quote=True))
     data=inspecteur_visuel.injecter(data).encode('utf8');self.reply(data,'text/html; charset=utf-8',head);return
    if raw.path=='/__ps_piet_demo':
     # L'image reste servie par cette même origine, avec le cookie d'aperçu : la
     # page ne fait que l'encadrer et porter la surcouche de l'inspecteur, qui
     # dessine les blocs de couleur par-dessus.
     import inspecteur_visuel
     href='/'+urllib.parse.quote(selected.as_posix(),safe='/')
     data=PIET_PAGE.format(href=html.escape(href,quote=True),nom=html.escape(selected.name))
     data=inspecteur_visuel.injecter(data).encode('utf8');self.reply(data,'text/html; charset=utf-8',head);return
    value=urllib.parse.unquote(raw.path)
    if '\x00' in value or '\\' in value:self.send_error(403);return
    parts=[x for x in value.split('/') if x]
    if any(x.startswith('.') for x in parts):self.send_error(403);return
    p=(root.joinpath(*parts)).resolve()
    if not p.is_relative_to(root):self.send_error(403);return
    if p.is_dir():
     p=(p/'index.html').resolve()
     if not p.is_relative_to(root):self.send_error(403);return
    # Never expose server-side source through the static preview.
    if p.suffix.lower() in ('.php','.phtml','.phar','.php3','.php4','.php5','.php7','.php8','.phps'):self.send_error(403,'Utilisez le serveur PHP.');return
    if not p.is_file():self.send_error(404);return
    try:
     if p.stat().st_size>50_000_000:self.send_error(413,'Fichier trop volumineux');return
     data=p.read_bytes()
    except OSError:self.send_error(404);return
    mime=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
    if mime=='text/html' or p.suffix.lower() in ('.svg','.xml'):
     # L'inspecteur visuel doit être présent dès le premier affichage.
     try:
      import inspecteur_visuel
      data=inspecteur_visuel.injecter(data)
      if mime!='text/html':mime='text/html'
     except Exception:pass
     # La capture dev web est un bloc SÉPARÉ de celui de l'inspecteur : un échec
     # de l'un ne doit pas priver de l'autre. Le script est placé en premier
     # enfant de <head> pour voir les erreurs des scripts d'en-tête ; injecter
     # ici, c'est-à-dire après lecture du fichier, garantit qu'il est présent
     # dès le premier affichage.
     try:
      import devweb
      data=devweb.injecter_capture(data)
     except Exception:pass
    if mime.startswith('text/') or mime in ('application/javascript','application/json'):mime+='; charset=utf-8'
    self.reply(data,mime,head)
   def reply(self,data,mime,head):
    self.send_response(200);self.send_header('Content-Type',mime);self.send_header('Content-Length',str(len(data)));self.send_header('X-Content-Type-Options','nosniff');self.send_header('Cache-Control','no-store');self.end_headers()
    if not head:self.wfile.write(data)
  with self.lock:
   self.server=ThreadingHTTPServer(('127.0.0.1',0),H);self.server.daemon_threads=True;self.port=self.server.server_port;self.kind='static';self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
 def _php(self,root,token):
  php=shutil.which('php')
  if not php:raise ValueError('Installez PHP : sudo apt install php-cli')
  self.cache.mkdir(parents=True,exist_ok=True);router=self.cache/'preview-router.php';router.write_text(PHP_ROUTER,encoding='utf8');os.chmod(router,0o600)
  with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
  env={**os.environ,'PS_PREVIEW_ROOT':str(root),'PS_PREVIEW_TOKEN':token,'PS_PREVIEW_PORT':str(port)}
  p=subprocess.Popen([php,'-d','display_errors=1','-d','log_errors=1','-S',f'127.0.0.1:{port}','-t',str(root),str(router)],cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
  try:
   deadline=time.monotonic()+5
   while time.monotonic()<deadline:
    if p.poll() is not None:raise ValueError('Impossible de démarrer PHP : port ou configuration indisponible.')
    try:
     with socket.create_connection(('127.0.0.1',port),timeout=.15):break
    except OSError:time.sleep(.06)
   else:raise ValueError('Le serveur PHP ne répond pas.')
  except Exception:
   p.terminate();p.wait(timeout=2);raise
  with self.lock:self.proc=p;self.port=port;self.kind='php'
