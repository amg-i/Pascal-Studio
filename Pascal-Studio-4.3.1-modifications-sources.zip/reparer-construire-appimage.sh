#!/bin/sh
# ============================================================================
# reparer-construire-appimage.sh — remplace vos exemplaires périmés de
#                                  construire-appimage.py par celui de cette
#                                  archive.
# ============================================================================
#
# POURQUOI CET OUTIL
#
#   construire-appimage.py se recopie à côté de vos AppImage. L'exemplaire d'une
#   livraison précédente y reste, et on le relance sans y penser. Or un
#   exemplaire ancien ne connaît pas les scripts reconditionner-*.sh plus
#   récents : il ne peut que mal conseiller. C'est ce qui est arrivé deux fois,
#   avec la 3.7.0 puis la 3.8.0 :
#
#       sans --strict  ->  « contrôle d'empreinte introuvable…
#                           Relancez avec --strict »
#       avec --strict  ->  « aucune construction possible avec --strict…
#                           Retirez --strict »
#
#   Chaque message renvoyait vers l'autre : cul-de-sac. La panne ne vient ni de
#   vos AppImage, ni des sources, ni du script de reconditionnement — seulement
#   de l'âge de l'exécutable qui les orchestre.
#
#   Depuis la 3.8.0, construire-appimage.py porte VERSION_SCRIPT, se compare aux
#   sources trouvées et passe la main tout seul à un exemplaire plus récent.
#   Mais un exemplaire ANTÉRIEUR à la 3.8.0 n'a pas cette logique : il ne peut
#   pas se réparer lui-même. C'est le rôle de cet outil.
#
# EMPLOI
#
#   sh reparer-construire-appimage.sh --verifier
#       ne touche à rien : liste chaque exemplaire trouvé, son âge, son état.
#
#   sh reparer-construire-appimage.sh --reparer
#       remplace chaque exemplaire périmé par celui de cette archive. L'ancien
#       est conservé à côté sous le nom
#       construire-appimage.py.perime-<version>-<date>, rien n'est perdu.
#
#   sh reparer-construire-appimage.sh --verifier DOSSIER [DOSSIER…]
#       cherche aussi dans ces dossiers (en plus de votre dossier personnel).
#
#   Commencez par --verifier. Lancez --reparer après avoir lu la liste.
#
# APRÈS
#
#   cd <dossier de vos AppImage>
#   ./construire-appimage.py --diagnostic     # état complet, en une sortie
#   ./construire-appimage.py                  # puis construction, normalement
#
# ============================================================================

set -u

ICI=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
MOI=$(readlink -f "$0" 2>/dev/null || echo "$0")
FRAIS="$ICI/construire-appimage.py"
NOM=construire-appimage.py
MODE=verifier
PROFONDEUR=6

LISTE=$(mktemp) || exit 1
RACINES_FICHIER=$(mktemp) || { rm -f "$LISTE"; exit 1; }
trap 'rm -f "$LISTE" "$RACINES_FICHIER"' EXIT INT TERM

# --------------------------------------------------------------------------
# Arguments
# --------------------------------------------------------------------------
while [ $# -gt 0 ]; do
    cas=$1
    shift
    case "$cas" in
        --verifier) MODE=verifier ;;
        --reparer)  MODE=reparer ;;
        --profondeur)
            [ $# -gt 0 ] || { echo "ERREUR : --profondeur attend un nombre." >&2; exit 2; }
            PROFONDEUR=$1; shift ;;
        --aide|-h)
            sed -n '2,50p' "$0" | sed 's/^# \{0,1\}//'
            exit 0 ;;
        -*)
            echo "ERREUR : option inconnue : $cas" >&2
            echo "       Utilisez --verifier, --reparer, --profondeur N ou --aide." >&2
            exit 2 ;;
        *)
            [ -d "$cas" ] || { echo "ERREUR : dossier introuvable : $cas" >&2; exit 2; }
            printf '%s\n' "$cas" >> "$RACINES_FICHIER" ;;
    esac
done

# --------------------------------------------------------------------------
# L'exemplaire de référence : celui de cette archive
# --------------------------------------------------------------------------
if [ ! -f "$FRAIS" ]; then
    echo "ERREUR : $NOM est absent à côté de ce script." >&2
    echo "       Attendu : $FRAIS" >&2
    echo "       Placez cet outil à la racine de l'archive décompressée." >&2
    exit 1
fi

# Lit VERSION_SCRIPT dans un exemplaire, sans l'exécuter.
version_de() {
    sed -n "s/^VERSION_SCRIPT = '\([0-9][0-9.]*\)'.*/\1/p" "$1" 2>/dev/null | head -n 1
}

VERSION_FRAIS=$(version_de "$FRAIS")
if [ -z "$VERSION_FRAIS" ]; then
    echo "ERREUR : l'exemplaire de référence ne porte pas VERSION_SCRIPT :" >&2
    echo "       $FRAIS" >&2
    echo "       Il est donc antérieur à la 3.8.0 : prenez celui d'une archive" >&2
    echo "       plus récente, cet outil ne peut pas servir de référence." >&2
    exit 1
fi

# Compare deux versions à points. Renvoie 0 si $1 < $2.
plus_ancienne() {
    a=$1; b=$2
    while :; do
        case "$a" in '' ) a=0 ;; esac
        case "$b" in '' ) b=0 ;; esac
        pa=${a%%.*}; pb=${b%%.*}
        [ -n "$pa" ] || pa=0
        [ -n "$pb" ] || pb=0
        if [ "$pa" -lt "$pb" ] 2>/dev/null; then return 0; fi
        if [ "$pa" -gt "$pb" ] 2>/dev/null; then return 1; fi
        case "$a" in *.*) a=${a#*.} ;; *) a='' ;; esac
        case "$b" in *.*) b=${b#*.} ;; *) b='' ;; esac
        [ -n "$a$b" ] || return 1
    done
}

echo
echo "Réparation des exemplaires de $NOM"
echo "=============================================="
echo
echo "  référence   : $FRAIS"
echo "  version     : $VERSION_FRAIS"
echo "  mode        : $MODE"
echo

# --------------------------------------------------------------------------
# Recherche
# --------------------------------------------------------------------------
# Sans dossier indiqué, on cherche dans votre dossier personnel.
if [ ! -s "$RACINES_FICHIER" ]; then
    printf '%s\n' "$HOME" > "$RACINES_FICHIER"
fi

echo "  recherché dans :"
while IFS= read -r racine; do
    [ -n "$racine" ] && echo "    $racine"
done < "$RACINES_FICHIER"
echo "  profondeur maximale : $PROFONDEUR"
echo

# Les sauvegardes créées par cet outil ne sont pas des exemplaires actifs :
# elles ne portent plus le nom exact, donc find ne les retient pas.
# `while read` dans un sous-shell perdrait les compteurs : la liste passe par
# un fichier temporaire et la boucle tourne dans le shell courant.
: > "$LISTE"
while IFS= read -r racine; do
    [ -n "$racine" ] || continue
    find "$racine" -maxdepth "$PROFONDEUR" \
        \( -name node_modules -o -name .git -o -name .cache -o -name .npm \
           -o -name .venv -o -name .local \) -prune -o \
        -type f -name "$NOM" -print 2>/dev/null >> "$LISTE"
done < "$RACINES_FICHIER"
sort -u "$LISTE" -o "$LISTE"

if [ ! -s "$LISTE" ]; then
    echo "Aucun exemplaire trouvé."
    echo "Rien à faire."
    exit 0
fi

NB=0; NB_PERIMES=0; NB_REPARES=0; NB_INTACTS=0
RESTES=""

while IFS= read -r chemin; do
    [ -n "$chemin" ] || continue
    NB=$((NB + 1))
    reel=$(readlink -f "$chemin" 2>/dev/null || echo "$chemin")

    if [ "$reel" = "$(readlink -f "$FRAIS" 2>/dev/null || echo "$FRAIS")" ]; then
        echo "  [référence] $chemin"
        echo "              version $VERSION_FRAIS — c'est l'exemplaire de cette archive"
        NB_INTACTS=$((NB_INTACTS + 1))
        continue
    fi

    version=$(version_de "$chemin")
    if [ -z "$version" ]; then
        etat="PERIME"
        detail="antérieure à la 3.8.0 (ne porte pas VERSION_SCRIPT)"
    elif plus_ancienne "$version" "$VERSION_FRAIS"; then
        etat="PERIME"
        detail="version $version"
    else
        etat="OK"
        detail="version $version, pas plus ancienne que la référence"
    fi

    if [ "$etat" = "OK" ]; then
        echo "  [à jour]    $chemin"
        echo "              $detail"
        NB_INTACTS=$((NB_INTACTS + 1))
        continue
    fi

    NB_PERIMES=$((NB_PERIMES + 1))
    echo "  [périmé]    $chemin"
    echo "              $detail"

    if [ "$MODE" != "reparer" ]; then
        RESTES="$RESTES $chemin"
        continue
    fi

    date_courante=$(date +%Y%m%d-%H%M%S)
    ancienne="${version:-avant-3.8.0}"
    sauvegarde="$chemin.perime-$ancienne-$date_courante"
    if cp -p "$chemin" "$sauvegarde" 2>/dev/null; then
        echo "              sauvegardé : $(basename "$sauvegarde")"
    else
        echo "              AVERTISSEMENT : sauvegarde impossible, remplacement direct"
    fi
    if cp "$FRAIS" "$chemin" 2>/dev/null && chmod +x "$chemin" 2>/dev/null; then
        echo "              remplacé par la version $VERSION_FRAIS"
        NB_REPARES=$((NB_REPARES + 1))
    else
        echo "              ÉCHEC du remplacement (droits d'écriture ?)"
        RESTES="$RESTES $chemin"
    fi
done < "$LISTE"

# --------------------------------------------------------------------------
# Bilan
# --------------------------------------------------------------------------
echo
echo "Bilan"
echo "  exemplaires trouvés : $NB"
echo "  déjà à jour         : $NB_INTACTS"
echo "  périmés             : $NB_PERIMES"
if [ "$MODE" = "reparer" ]; then
    echo "  remplacés           : $NB_REPARES"
fi

if [ "$MODE" != "reparer" ] && [ "$NB_PERIMES" -gt 0 ]; then
    echo
    echo "Rien n'a été modifié (mode --verifier). Pour remplacer ces exemplaires :"
    echo
    echo "  sh \"$MOI\" --reparer"
    echo
    echo "Chaque exemplaire remplacé est d'abord sauvegardé à côté de lui."
    exit 0
fi

if [ -n "$RESTES" ]; then
    echo
    echo "Restent à traiter (droits d'écriture insuffisants, probablement) :"
    for chemin in $RESTES; do
        echo "  $chemin"
    done
    echo
    echo "Pour ceux-là, remplacez-les à la main :"
    echo "  cp \"$FRAIS\" <chemin> && chmod +x <chemin>"
    echo "  (avec sudo si le dossier appartient à root)"
    exit 1
fi

echo
echo "Terminé. Vous pouvez maintenant construire :"
echo
echo "  cd <dossier de vos AppImage>"
echo "  ./$NOM --diagnostic     # vérifie l'état avant de construire"
echo "  ./$NOM                  # liste ce qui est constructible, puis construit"
echo
exit 0
