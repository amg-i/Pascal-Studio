# Pascal Studio

Un environnement de développement local pour Object Pascal, inspiré visuellement de Darcula (JetBrains). Il utilise Monaco Editor et le compilateur Free Pascal installé sur votre machine. Ce n'est pas un produit JetBrains et il ne reproduit pas l'ensemble des fonctions d'un IDE commercial.

## Installation sur Debian 13

```bash
sudo apt update
sudo apt install python3 nodejs npm fp-compiler
cd pascal-studio
./start.sh
```

Ouvrez l'adresse affichée par Vite, normalement **http://127.0.0.1:5173**. Le premier démarrage télécharge les dépendances avec npm. Laissez le terminal ouvert, et utilisez Ctrl+C pour arrêter l'application. Node.js 20.19+ ou 22.12+ est recommandé. Si le port 8765 est occupé, libérez-le avant de démarrer.

Le projet est dans `workspace/` : vos modifications y sont enregistrées. Pour utiliser un autre dossier :

```bash
PASCAL_WORKSPACE="$HOME/mes-projets-pascal" ./start.sh
```

## Fonctions

- Onglets, coloration Pascal, complétion par extraits, indentation, recherche et remplacement, numéros de ligne, minicarte et options d'édition.
- Explorateur, création de fichiers et dossiers, renommage et suppression par clic droit, recherche de fichiers et accès rapide.
- Enregistrement Ctrl+S, compilation Ctrl+B, compilation et exécution F9, arrêt du programme.
- Sortie de compilation, diagnostics cliquables et console d'exécution interactive (les entrées sont envoyées ligne par ligne).
- Les fichiers modifiés sont enregistrés avant compilation. L'exécutable et les fichiers intermédiaires sont dans `workspace/.pascal-studio/build`.

## Limites et sécurité

Le compilateur et les programmes s'exécutent avec les droits de votre compte, **sans bac à sable**. N'exécutez pas de code non fiable. L'API donne accès en lecture/écriture au dossier du projet et permet de lancer du code : ne l'exposez pas sur Internet ou sur un réseau non fiable. Le lancement standard écoute uniquement sur `127.0.0.1`. La console n'est pas un terminal complet : elle accepte du texte ligne par ligne, sans gestion des interfaces plein écran ni des séquences de contrôle. Il n'y a pas de débogueur pas-à-pas, de gestionnaire de projets multiples, ni d'analyse sémantique en temps réel. Les erreurs sont fournies par FPC après compilation.
