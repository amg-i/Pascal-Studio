#!/usr/bin/env python3
"""Local Pascal Studio API. Run only on a trusted machine/network."""
import json, os, re, shutil, subprocess, threading, time, urllib.parse, pty, termios
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(os.environ.get('PASCAL_WORKSPACE', Path(__file__).parent / 'workspace')).resolve()
ROOT.mkdir(parents=True, exist_ok=True)
BUILD = ROOT / '.pascal-studio' / 'build'
BUILD.mkdir(parents=True, exist_ok=True)
lock = threading.RLock()
state = {'process': None, 'output': '', 'running': False, 'exitCode': None}

def resolve(name, allow_root=False):
    if not isinstance(name, str) or '\x00' in name: raise ValueError('Chemin invalide')
    p = (ROOT / name).resolve()
    if not p.is_relative_to(ROOT) or (not allow_root and p == ROOT) or (ROOT / '.pascal-studio') in p.parents or p == ROOT / '.pascal-studio': raise ValueError('Chemin interdit')
    return p

def tree(folder=ROOT):
    result = []
    for p in sorted(folder.iterdir(), key=lambda x:(not x.is_dir(), x.name.lower())):
        if p.name.startswith('.') or p.is_symlink(): continue
        item = {'name':p.name, 'path':p.relative_to(ROOT).as_posix(), 'type':'folder' if p.is_dir() else 'file'}
        if p.is_dir(): item['children'] = tree(p)
        result.append(item)
    return result

def compile_file(name):
    path = resolve(name)
    if not path.is_file() or path.suffix.lower() not in ('.pas', '.pp', '.p'): raise ValueError('Choisissez un fichier Pascal à compiler.')
    fpc = shutil.which('fpc')
    if not fpc: return {'ok':False, 'output':'Free Pascal (fpc) est introuvable. Installez-le avec : sudo apt install fp-compiler', 'diagnostics':[]}
    binary = BUILD / ('program-' + str(abs(hash(str(path)))))
    # Never allow a failed compilation to leave a stale executable runnable.
    binary.unlink(missing_ok=True)
    cmd = [fpc, '-Mobjfpc', '-gl', '-Fu'+str(ROOT), '-Fu'+str(path.parent), '-FU'+str(BUILD), '-FE'+str(BUILD), '-o'+str(binary), str(path)]
    try:
        p = subprocess.run(cmd, cwd=path.parent, capture_output=True, text=True, errors='replace', timeout=60)
        out = p.stdout + p.stderr
    except subprocess.TimeoutExpired: return {'ok':False, 'output':'Compilation interrompue après 60 secondes.', 'diagnostics':[]}
    diagnostics=[]
    for line in out.splitlines():
        match = re.match(r'^(.*?)\((\d+),(\d+)\)\s+(Fatal|Error|Warning|Note|Hint):\s*(.*)', line, re.I)
        if match:
            filename, row, col, severity, message = match.groups()
            candidate = Path(filename)
            if not candidate.is_absolute(): candidate = path.parent / candidate
            try: rel = candidate.resolve().relative_to(ROOT).as_posix()
            except ValueError: rel = name
            diagnostics.append({'file':rel,'line':int(row),'column':int(col),'severity':severity,'message':message})
    return {'ok':p.returncode == 0 and binary.is_file(), 'output':out, 'diagnostics':diagnostics, 'binary':str(binary) if binary.is_file() else None}

def run_file(name):
    result = compile_file(name)
    if not result['ok']: return result
    with lock:
        if state['running']: raise ValueError('Un programme est déjà en cours. Arrêtez-le avant de relancer.')
        master, slave = pty.openpty()
        attrs = termios.tcgetattr(slave)
        attrs[3] &= ~termios.ECHO
        termios.tcsetattr(slave, termios.TCSANOW, attrs)
        try:
            p = subprocess.Popen([result['binary']], cwd=ROOT, stdin=slave, stdout=slave, stderr=slave, start_new_session=True)
        finally: os.close(slave)
        state.update(process=p, master=master, output='', running=True, exitCode=None)
    def reader():
        try:
            while True:
                try: b = os.read(master, 4096)
                except OSError: break
                if not b: break
                with lock: state['output'] += b.decode('utf-8', errors='replace')
        finally:
            os.close(master)
            code = p.wait()
            with lock:
                if state['process'] is p: state.update(running=False, exitCode=code)
    threading.Thread(target=reader, daemon=True).start()
    return result

class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args): pass
    def send_json(self, obj, status=200):
        data=json.dumps(obj, ensure_ascii=False).encode(); self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def do_GET(self):
        try:
            url=urllib.parse.urlparse(self.path); q=urllib.parse.parse_qs(url.query)
            if url.path == '/api/status': self.send_json({'fpc':shutil.which('fpc'), 'workspace':str(ROOT)})
            elif url.path == '/api/tree': self.send_json({'tree':tree()})
            elif url.path == '/api/file':
                p=resolve(q.get('path',[''])[0]); self.send_json({'content':p.read_text(encoding='utf-8')})
            elif url.path == '/api/process':
                with lock: self.send_json({k:state[k] for k in ('output','running','exitCode')})
            else: self.send_json({'error':'Introuvable'},404)
        except Exception as e: self.send_json({'error':str(e)},400)
    def do_POST(self):
        try:
            if self.headers.get_content_type() != 'application/json': raise ValueError('Content-Type application/json requis')
            length=int(self.headers.get('Content-Length','0'))
            if length > 5_000_000: raise ValueError('Requête trop volumineuse')
            d=json.loads(self.rfile.read(length) or b'{}'); action=urllib.parse.urlparse(self.path).path
            if action == '/api/save':
                p=resolve(d.get('path')); p.parent.mkdir(parents=True, exist_ok=True); p.write_text(d.get('content',''),encoding='utf-8'); result={'ok':True}
            elif action == '/api/create':
                p=resolve(d.get('path')); p.parent.mkdir(parents=True,exist_ok=True)
                if d.get('type') == 'folder': p.mkdir()
                else:
                    with p.open('x',encoding='utf-8') as f: f.write(d.get('content',''))
                result={'ok':True}
            elif action == '/api/rename':
                p=resolve(d.get('path')); dest=resolve(d.get('target'))
                if dest.exists(): raise ValueError('La destination existe déjà.')
                p.rename(dest); result={'ok':True}
            elif action == '/api/delete':
                p=resolve(d.get('path'))
                if p.is_dir(): shutil.rmtree(p)
                else: p.unlink()
                result={'ok':True}
            elif action == '/api/compile': result=compile_file(d.get('path'))
            elif action == '/api/run': result=run_file(d.get('path'))
            elif action == '/api/input':
                with lock:
                    if not state['running']: raise ValueError("Aucun programme en cours d'exécution.")
                    text=d.get('text',''); os.write(state['master'], (text+'\n').encode()); state['output'] += text+'\n'
                result={'ok':True}
            elif action == '/api/stop':
                import signal
                with lock:
                    if state['running']:
                        try: os.killpg(state['process'].pid, signal.SIGTERM)
                        except ProcessLookupError: pass
                result={'ok':True}
            else: return self.send_json({'error':'Introuvable'},404)
            self.send_json(result)
        except Exception as e: self.send_json({'error':str(e)},400)

if __name__=='__main__':
    host=os.environ.get('PASCAL_HOST','127.0.0.1'); port=int(os.environ.get('PASCAL_PORT','8765'))
    print(f'Pascal Studio API: http://{host}:{port} | workspace: {ROOT}', flush=True)
    ThreadingHTTPServer((host,port),Handler).serve_forever()
