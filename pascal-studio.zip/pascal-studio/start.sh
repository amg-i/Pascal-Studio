#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v node >/dev/null || ! command -v npm >/dev/null; then echo 'Node.js et npm sont nécessaires.'; exit 1; fi
if ! command -v fpc >/dev/null; then echo 'Attention : Free Pascal est absent. Installez-le avec sudo apt install fp-compiler'; fi
if [ ! -d node_modules ]; then npm install; fi
python3 server.py &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT INT TERM
npm run dev -- --host 127.0.0.1
