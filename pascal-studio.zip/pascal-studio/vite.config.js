import { defineConfig } from 'vite';
import { execSync } from 'node:child_process';
export default defineConfig({ server: { host: '0.0.0.0', allowedHosts: true, proxy: { '/api': 'http://127.0.0.1:8765' } }, preview: {host: '0.0.0.0', allowedHosts: true, proxy: { '/api': 'http://127.0.0.1:8765' }}, build: { chunkSizeWarningLimit: 3000 } });
