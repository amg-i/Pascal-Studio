# Mon projet Pascal

Bienvenue dans votre espace de travail. Ouvrez `main.pas`, modifiez-le, puis lancez le programme avec le bouton Exécuter.

Les fichiers de ce dossier sont conservés sur votre ordinateur. Le compilateur utilisé est Free Pascal (FPC).
