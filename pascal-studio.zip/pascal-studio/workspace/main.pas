program BonjourPascal;

{$mode objfpc}{$H+}

uses
  SysUtils;

{ Un premier programme pour prendre en main Pascal Studio. }
procedure DireBonjour(const Nom: string);
begin
  WriteLn('Bonjour, ', Nom, ' !');
  WriteLn('Bienvenue dans Pascal Studio.');
end;

var
  Nom: string;
begin
  Write('Comment vous appelez-vous ? ');
  ReadLn(Nom);

  if Trim(Nom) = '' then
    Nom := 'monde';

  DireBonjour(Nom);
end.
